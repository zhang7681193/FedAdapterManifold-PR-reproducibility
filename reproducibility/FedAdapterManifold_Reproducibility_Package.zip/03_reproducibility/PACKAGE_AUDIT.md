# Pattern Recognition resubmission package audit

- Build mode: **FINAL**.
- Static validation: **PASS**.
- Final evidence status: **READY**.
- Core evidence registry SHA-256: `563afef0c6b1e657a612dbc304af48baa2bba4dbd334a8046684e639e0c36ad1`.
- Untouched-confirmation provider registry SHA-256: `03c38d946075d261ed48c3ab3f258be22ff5529812c780434ff999d9c586adc1`.
- Training-only expert-ablation protocol SHA-256: `436854ac0461fe830f8d2e8f7dfbf8349bb23045acf8357c01d59b453fa2b04d`.
- Frozen evidence files copied: 446.
- Frozen geometry snapshots: 45 registered core snapshots plus 5 untouched OfficeHome-65 confirmation snapshots.
- Machine-specific paths: absent from the new confirmation evidence and provider payload.

## Document checks

- fedadaptermanifold_pr_resubmit.pdf: 35 pages, 612.0 x 792.0 pt
- fedadaptermanifold_pr_resubmit_supplement.pdf: 67 pages, 612.0 x 792.0 pt
- PR_D_26_08222_resubmission_cover_letter.pdf: 2 pages, 612.0 x 792.0 pt
- title words: 11 (FedAdapterManifold: Deciding When Federated Visual LoRA Adapters Are Safe to Share)
- references: 55
- keywords: 6
- highlights: 5
- test suite: 303/303 passed
- packaged replay suite: 282 passed, 3 expected skips (two optional runtime/resource checks and one non-redistributed official-source parity check)
- untouched confirmation audit: 35/35 checks pass on seeds 10--14
- training-only FAM-given-Geo audit: 20/20 receiver-seed effects and 5/5 seed means positive; exact one-sided seed sign `p=.03125`; no calibration/test forward
- frozen geometry payload: 459 files across core and confirmation records

## Required active entries

- None.

## Errors

- None.

## Evidence policy

Only submission-eligible frozen registry entries that pass every declared file/count check are copied. Active, development, and explicitly ineligible roots cannot populate manuscript tables or the final package. The OfficeHome-65 confirmation protocol, geometry hashes, candidate construction, certificate thresholds, and success gate were frozen before confirmation outputs were opened; the weak seed and nonsignificant exact five-seed sign test remain disclosed. The additional expert ablation was separately frozen and uses only training-side out-of-fold receiver regret; calibration and test tensors are inaccessible to its construction, scoring, and evaluation path.
