# Core Evidence Table Validation

- Intrinsic source: `results\fam_pr_evidence_pack_v15\main_accuracy_with_strong_baselines.csv`
- Backbone source: `results\fam_pr_stability_audit_v1\key_method_seed_stability.csv`
- Diagnostic source: `results\fam_admit_clustered_stats_v1\clustered_subspace_failure_correlation.csv`
- Controlled source: `results\fam_incremental_subspace_diagnostic_20260805\incremental_effect_summary.csv`
- Opportunity source: `results\fam_opportunity_certificates_20260629\opportunity_certificate_combined_summary.csv`
- Canonical admission source: `results\fam_canonical_admission_gate_20260810\canonical_admission_setting_summary.csv`
- Main safety/utility table: `results\core_manuscript_tables_20260812\canonical_safety_utility.csv`
- Main end-to-end table: `results\core_manuscript_tables_20260812\end_to_end_clip_admission.csv`
- Recent-method admission table: `results\recent_lora_receiver_admission_overlay_20260812\receiver_admission_setting_summary.csv`
- Status: PASS

## Checks

- PACS canonical safety/utility row -> pass
- Office-Caltech canonical safety/utility row -> pass
- DomainNetMini canonical safety/utility row -> pass
- BloodMNIST canonical safety/utility row -> pass
- OfficeHome-DINOv2 canonical safety/utility row -> pass
- OfficeHome-CLIP canonical safety/utility row -> pass
- PACS-7 end-to-end admission row -> pass
- OfficeCaltech-10 end-to-end admission row -> pass
- DomainNetMini-60 end-to-end admission row -> pass
- PACS-R18 recent-method admission row -> pass
- OfficeHome-CLIP recent-method admission row -> pass
- DomainNetMini-CLIP recent-method admission row -> pass
- PACS FedAvg: 0.5891 -> pass
- PACS Geo-only: 0.7547 -> pass
- PACS Canonical Admit: 0.7547 -> pass
- PACS d_sub: r=0.264, CI=[-0.079,0.535] -> pass
- Office-Caltech FedAvg: 0.8866 -> pass
- Office-Caltech Geo-only: 0.9050 -> pass
- Office-Caltech Canonical Admit: 0.9455 -> pass
- Office-Caltech d_sub: r=0.085, CI=[-0.268,0.390] -> pass
- DomainNetMini FedAvg: 0.7915 -> pass
- DomainNetMini Geo-only: 0.8044 -> pass
- DomainNetMini Canonical Admit: 0.8068 -> pass
- DomainNetMini d_sub: r=0.294, CI=[0.046,0.471] -> pass
- BloodMNIST FedAvg: 0.4253 -> pass
- BloodMNIST Geo-only: 0.7635 -> pass
- BloodMNIST Canonical Admit: 0.7645 -> pass
- BloodMNIST d_sub: r=0.129, CI=[0.004,0.257] -> pass
- OfficeHome-DINOv2 FedAvg: 0.7276 -> pass
- OfficeHome-DINOv2 Geo-only: 0.7506 -> pass
- OfficeHome-DINOv2 Canonical Admit: 0.7506 -> pass
- OfficeHome-DINOv2 d_sub: r=0.656, CI=[0.473,0.803] -> pass
- OfficeHome-CLIP FedAvg: 0.7081 -> pass
- OfficeHome-CLIP Geo-only: 0.7280 -> pass
- OfficeHome-CLIP Canonical Admit: 0.7280 -> pass
- OfficeHome-CLIP d_sub: r=0.440, CI=[0.227,0.648] -> pass
- OfficeHome-DINOv2 expanded pool: units/fallback/admit=20/20/0, gain vs selected anchor=0.0000 -> pass
- OfficeHome-CLIP expanded pool: units/fallback/admit=20/20/0, gain vs selected anchor=0.0000 -> pass
- All-setting d_sub effect: r=0.215, CI=[0.068,0.413], families/settings/seeds=5/11/55, p=0.03125 -> pass
- Controlled d_sub effect: rows/settings/families=730/7/5, beta=0.2228, CI=[0.0873,0.4600], partial-r=0.2163, dR2=0.0457 -> pass

## Errors

- None
