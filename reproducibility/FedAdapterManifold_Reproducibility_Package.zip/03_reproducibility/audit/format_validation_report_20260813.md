# Elsevier Pattern Recognition Format Validation

- Main PDF: `paper_resubmit\fedadaptermanifold_pr_resubmit.pdf`
- Page count: 35
- Page size sample: 612.0 x 792.0 pt
- Consecutive page numbers: checked on 35/35 pages
- Title word count: 11
- Abstract word count: 206
- Keyword count: 6
- Bibliography count: 53
- Embedded fonts: AKHCZK+txmiaX, BZIVMZ+TeXGyreTermesX-Italic-Identity-H, CAFSZL+NewTXMI7, DDIEWW+NewTXMI5, FKPJSN+txexs, IHAIZV+TeXGyreTermesX-Regular-Identity-H, IXFAWU+TeXGyreTermesX-Bold-Identity-H, PVTTLK+txsyb, TQTHRL+txsys, VDVGTR+TeXGyreTermesX-Regular, YEUUOC+NewTXMI

## Errors
- None

## Warnings
- None
