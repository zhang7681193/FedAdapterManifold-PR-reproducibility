# Theory Consistency Audit

## Errors
- None

## Warnings
- None

## Geometry-provider drift theorem

- Fixed-support Gibbs bound checked on 390/390 receiver units.
- Maximum route-weight L1 drift at 1%, 5%, and 10% distance perturbation:
  0.0055, 0.0275, and 0.0548.
- Top-donor changes under controlled perturbation: 0/390.
- Actual PACS/OfficeCaltech cross-provider receiver comparisons: 72.
- Cross-provider support changes: 0/72; top-donor changes: 0/72.
- Automatic inheritance of an old deployment certificate for a non-identical
  provider hash: 0/72. Certificate replay is required by the theorem.
- Frozen geometry snapshots/files: 45/365; every snapshot records round,
  client order, evidence references, and SHA-256.
