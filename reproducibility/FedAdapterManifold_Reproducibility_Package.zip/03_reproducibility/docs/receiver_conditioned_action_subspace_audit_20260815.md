# Receiver-conditioned action-subspace audit

## 1. Failure mode exposed by the untouched confirmation

The untouched OfficeHome-65 confirmation is intentionally difficult for a raw
parameter-space diagnostic.  The provider graph is nearly self-only and the 60
directional donor pairs occupy a narrow high-distance band.  In this setting,
the pooled raw Grassmann distance is positively correlated with pairwise
aggregation failure, but receiver-seed demeaning removes that association.  A
closest-geometry donor-pair comparison is also not positive.  These exploratory
numbers are a boundary diagnosis, not positive evidence and not a deployment
rule.

The diagnosis is structural.  A distribution-free principal angle measures
whether two update subspaces are different, but not whether the differing
directions are excited by the receiver's inputs.  Summing angles across layers
can therefore saturate when every external adapter is far from the receiver.

## 2. Receiver-conditioned functional mismatch

For a linear adapted module with receiver representation `h`, let

```
E_ij = Delta W_j - Delta W_i,
Sigma_i = E_i[h h^T].
```

The receiver-conditioned action mismatch is

```
d_act^2(i,j) = E_i[||E_ij h||_2^2]
             = ||E_ij Sigma_i^(1/2)||_F^2.
```

This quantity is gauge invariant and separates two effects that the raw
Grassmann distance conflates: adapter orientation and receiver excitation.  If
the loss is `L`-smooth in the module output, then for a locally stationary
receiver adapter,

```
R_i(Delta W_j) - R_i(Delta W_i)
    <= (L/2) d_act^2(i,j) + epsilon_stationarity ||E_ij||_F.
```

Thus raw subspace mismatch is a distribution-free warning, while receiver
action mismatch is the risk-relevant refinement.  Geometry may propose a donor,
but neither geometry nor a saturated raw angle proves that its function is
beneficial for the receiver.

## 3. Solution implied by the decomposition

The method should not force a new parameter-space mixture when all external
directions are first-order unsafe or indistinguishable.  It instead constructs
four gauge-invariant function experts from training-only, out-of-fold receiver
predictions:

1. Local;
2. geometry-conditioned probability transport;
3. geometry-plus-subspace-conditioned FAM probability transport;
4. class-conditional prototype/FAM probability transport.

A convex receiver teacher is fitted on two folds and scored on the held-out
fold.  Only an endpoint with negative held-out regret on every fold is distilled
into the receiver LoRA.  Calibration certifies the already fixed endpoint; test
data are not used for construction or selection.

This is not a post-hoc temperature change.  It is the functional consequence of
the action-risk decomposition: when raw parameter directions are saturated,
compare their receiver functions and retain Local as an immutable anchor.

## 4. Frozen training-only expert ablation

The following estimands are fixed before the ablation outputs are opened.  For
each receiver and each of the three deterministic cross-fit folds, refit the
same entropy-regularized convex teacher using these fixed expert subsets:

- `local_geo`: Local and the geometry-only function expert;
- `local_fam`: Local and the subspace-conditioned FAM function expert;
- `local_geo_fam`: Local, Geo, and FAM function experts;
- `all`: the deployed four-expert bank.

The primary incremental estimand is

```
Delta_FAM|Geo = heldout_regret(local_geo)
              - heldout_regret(local_geo_fam).
```

Positive values mean that the subspace-conditioned endpoint adds
training-held-out value beyond geometry.  Secondary estimands compare
`local_fam` with `local_geo`, count receiver-seed units with positive
`Delta_FAM|Geo`, and report seed means with a seed-cluster bootstrap.  No test
metric is used in this audit.  Results are reported whether positive, null, or
negative; the untouched confirmation remains frozen.

## 5. Claim gate

The paper may claim confirmation-specific incremental function-space utility
only if the five-seed mean `Delta_FAM|Geo` is positive and at least four of five
seed means are positive.  A positive bootstrap lower bound is required for the
word "stable".  Otherwise this experiment is reported as a boundary case and
the broader pre-existing multi-dataset subspace diagnostic remains the only
incremental subspace claim.
