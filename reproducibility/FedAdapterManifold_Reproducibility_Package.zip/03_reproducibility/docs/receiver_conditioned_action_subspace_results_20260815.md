# Receiver-conditioned action-subspace result

## Frozen protocol

- Dataset: OfficeHome-65.
- Seeds: 10--14.
- Backbone: CLIP ViT-B/32 attention LoRA.
- Geometry: untouched FedAvg/ResNet18 provider snapshots at round 4.
- Estimation: three-fold nested cross-fit on adapter-training data only.
- Outer-split use: no calibration or test forward pass.
- Frozen protocol SHA-256: `436854ac0461fe830f8d2e8f7dfbf8349bb23045acf8357c01d59b453fa2b04d`.

## Primary result

The primary estimand is the reduction in held-out receiver regret obtained by
adding the subspace-conditioned FAM function expert to the fixed Local+Geo
expert set:

```
Delta_FAM|Geo = regret(Local+Geo) - regret(Local+Geo+FAM).
```

- Mean `Delta_FAM|Geo`: `+0.0019616569642656183`.
- Seed-bootstrap 95% interval: `[+0.0016790967800542679,
  +0.0021962648437449687]`.
- Positive seed means: `5/5`.
- Exact one-sided seed sign test: `p=0.03125`.
- Positive receiver-seed units: `20/20`.
- Stable claim gate: passed.

The direct Local+FAM versus Local+Geo comparison is smaller, with mean gain
`+0.0004025848428206538` and `18/20` positive receiver-seed units.  The stronger
conditional result therefore supports complementarity: geometry and subspace
experts are most useful together, rather than one universally replacing the
other.

## Seed means

| Seed | FAM increment given Geo | FAM endpoint vs Geo | Positive receivers |
|---:|---:|---:|---:|
| 10 | +0.002155 | +0.000849 | 4/4 |
| 11 | +0.001863 | +0.000083 | 4/4 |
| 12 | +0.002065 | +0.000299 | 4/4 |
| 13 | +0.001422 | +0.000213 | 4/4 |
| 14 | +0.002303 | +0.000568 | 4/4 |

## Claim boundary

This audit does not convert the small untouched-confirmation test-accuracy gain
into a large SOTA claim.  It answers a narrower causal-design question under a
fixed function bank: subspace-conditioned receiver functions add stable
training-held-out information beyond geometry alone.  Deployment remains
protected by the independent exact receiver certificate.
