# Class-Conditional Prototype-Bank Confirmation

Seeds 5--9 are an independent, fixed-protocol confirmation block. Every seed consumes FedAvg-generated visual geometry. Routing uses training-only class prototypes and unlabelled test inputs; test labels never enter routing or admission.

- Receiver units: `30`
- Local / raw route / certified deploy accuracy: `0.8271` / `0.7896` / `0.8271`
- Raw route gain: `-0.0375`; hierarchical 95% CI `[-0.0482, -0.0274]`
- Certified gain: `+0.0000`; hierarchical 95% CI `[+0.0000, +0.0000]`
- Certified admissions / harmful admissions: `0` / `0`
- Mean external route fraction: `1.0000`
- Seed-level one-sided exact sign-flip p: `1.0000`
- Safety confirmation: `True`
- Positive hierarchical-CI confirmation: `False`
- Strict seed-exact confirmation: `False`

The block supports exact safety fallback but does not support positive non-local utility.
