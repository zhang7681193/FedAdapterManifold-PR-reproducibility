# FedAdapterManifold Protocol Audit

| Dataset | Pass | Warn | Fail | Overall |
|---|---:|---:|---:|---|
| DomainNetMini | 126 | 0 | 0 | pass |
| OfficeHome | 126 | 0 | 0 | pass |
| PACS | 126 | 0 | 0 | pass |
