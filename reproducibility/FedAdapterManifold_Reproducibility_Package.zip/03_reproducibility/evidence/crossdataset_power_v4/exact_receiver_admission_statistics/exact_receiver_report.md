# Immutable-Local Exact Receiver Admission Audit

| Run | Seeds | Units | Accuracy gain vs Local | 95% CI | Non-local | Harmful | Uncertified | Serial-Holm | Pred./realized loss r | Safety | Positive confirmation |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| domainnetmini_clip_60class | 5 | 30 | 0.0000 | [0.0000, 0.0000] | 0 | 0 | 0 | True | nan | True | False |
| officehome_clip_full | 5 | 20 | 0.0000 | [0.0000, 0.0000] | 0 | 0 | 0 | True | nan | True | False |
