# Generator-admission power-v4 validation

- Checks: 534
- Passed: 534
- Failed: 0
- Frozen receiver--seed units: 50
- Certified non-local deployments: 0

## Failures

- None.

## Interpretation

This validator checks the frozen power-v4 protocol, whose generator screen is training-only and whose deployment certificate sees exactly three fixed endpoints. It does not reuse the signed-tangent files required by the distinct exact-v3 protocol.
