# DomainNetMini-60 end-to-end pooled-projector confirmation

Seeds 5--9, round weights, uncertainty scale, geometry sources, and success criteria were frozen before the confirmation outputs were inspected.

**Conclusion:** The confirmation does not establish a positive pooled-projector diagnostic, retains zero-harm certified fallback, does not establish non-local routing utility, does not show a stable FedAvg gain.

- The routing implementation uses an empirical dispersion/eigengap penalty; it does not instantiate the theorem's formal Matrix-Bernstein confidence radius.
- Round-1 empirical penalty identifiable: False. Its one-projector dispersion is algebraically zero, so the predeclared round-1-to-round-5 radius-reduction criterion is unresolved rather than positive.
- Descriptive receiver-level empirical penalty: round 2 = 2.7333; round 5 = 2.2772; decreased = True (not a confirmatory claim).
- Pooled subspace/failure r = +0.0008, hierarchical CI [-0.2470, +0.3071].
- Final-update subspace/failure r = +0.0267.
- Certified harmful client-seed units versus Local: 0/30.
- Certified non-local client-seed units: 0/30; retrospective +/0/- = 0/0/0.
- FAM mean accuracy: 0.7986.

A safe fallback is not counted as a positive routing gain. The diagnostic is called positive only when its seed/receiver hierarchical lower bound is above zero and it exceeds the raw final-update correlation. The empirical penalty is kept separate from the theorem's conditional confidence radius.
