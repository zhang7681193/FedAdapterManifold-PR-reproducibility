# DomainNetMini-60 end-to-end CLIP-LoRA confirmation

The five seeds, four-shot training budget, five communication rounds, candidate set, and exact Local-anchored certificate were fixed before test evaluation.

- Deployed gain versus FedAvg-LoRA: +0.0365, seed CI [+0.0308, +0.0421].
- Deployed gain versus Geo-only: +0.0298, seed CI [+0.0257, +0.0340].
- Certified non-local deployments: 0/30; harmful: 0/30.
- Final-round subspace/failure r: +0.0167, hierarchical CI [-0.2316, +0.2642].
- Controlled final-round subspace coefficient: +0.0288, seed CI [-0.1081, +0.1657].

Interpretation is claim-bounded: a zero-harm fallback supports deployment safety, but it is not counted as positive non-local routing utility. A non-positive final-round diagnostic motivates the separately frozen pooled-projector confirmation rather than being hidden.
