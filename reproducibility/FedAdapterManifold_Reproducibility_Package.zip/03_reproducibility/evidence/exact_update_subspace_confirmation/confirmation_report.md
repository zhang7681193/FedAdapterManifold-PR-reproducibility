# Independent-seed exact-update subspace confirmation

## Estimand

The endpoint is the increase in receiver cross-entropy after averaging the exact full LoRA updates. This endpoint and its implementation existed before the seed-5--9 diagnostics were generated. Unlike factor-wise averaging, it is invariant to a change of LoRA factor gauge.

The controlled coefficient is the standardized d_sub coefficient after controlling for d_geo, normalized full-update distance, and receiver Fisher action distance. Seeds are resampled as clusters.

- DINOv2-PACS: raw r=0.4128; controlled beta=0.2966, 95% seed-cluster CI [0.0309, 0.3700].
- CLIP-DomainNetMini: raw r=0.3259; controlled beta=0.2375, 95% seed-cluster CI [0.1336, 0.3907].
- Equal-setting mean controlled beta=0.2671, 95% CI [0.1468, 0.3545].
- Confirmation supported: True.

## Protocol note

A separate opportunity-threshold analysis was frozen before these outputs but failed because development and confirmation artifacts used non-commensurate multi-layer and equivalent-update distance scales. That failed analysis remains archived and is not used as positive evidence. The present audit uses the pre-existing gauge-invariant exact-update endpoint without transferring numeric thresholds across implementations.
