# FedALT same-protocol visual fairness audit

FedALT is retrained on the identical PACS splits, initialization family, upload rank, local epochs, communication rounds, and evaluation partition. Its released leave-one-out server recurrence is pinned and runtime-parity tested; no native NLP accuracy is imported.

| Method | Mean accuracy | Seed SD | Worst-client accuracy | Mean loss |
|---|---:|---:|---:|---:|
| FedAdapterManifold-Admit | 0.7769 | 0.0270 | 0.6000 | 0.6936 |
| FedALT-OfficialVisualPort | 0.3741 | 0.0275 | 0.2125 | 1.4616 |
| FedAvg-LoRA | 0.5047 | 0.0451 | 0.3325 | 1.3405 |
| FedGeo-Agg | 0.6487 | 0.0068 | 0.4987 | 1.0201 |
| Local-LoRA | 0.6487 | 0.0068 | 0.4987 | 1.0201 |

| Comparison | Gain [hierarchical 95% CI] | Seed +/0/- | Exact one-sided p |
|---|---:|---:|---:|
| FedAdapterManifold-Admit vs FedALT-OfficialVisualPort | +0.4028 [+0.3337,+0.4697] | 5/0/0 | 0.0312 |
| FedAdapterManifold-Admit vs FedAvg-LoRA | +0.2722 [+0.2200,+0.3225] | 5/0/0 | 0.0312 |
| FedAdapterManifold-Admit vs FedGeo-Agg | +0.1281 [+0.0912,+0.1616] | 5/0/0 | 0.0312 |
| FedAdapterManifold-Admit vs Local-LoRA | +0.1281 [+0.0912,+0.1612] | 5/0/0 | 0.0312 |
| FedALT-OfficialVisualPort vs FedAvg-LoRA | -0.1306 [-0.1975,-0.0600] | 0/0/5 | 1.0000 |
| FedALT-OfficialVisualPort vs FedGeo-Agg | -0.2747 [-0.3250,-0.2206] | 0/0/5 | 1.0000 |
| FedALT-OfficialVisualPort vs Local-LoRA | -0.2747 [-0.3253,-0.2206] | 0/0/5 | 1.0000 |
