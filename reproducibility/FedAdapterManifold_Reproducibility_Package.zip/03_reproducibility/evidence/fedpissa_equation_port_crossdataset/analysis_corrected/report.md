# Corrected FedPissa equation-port confirmation

The frozen analyzer compared sign-flipped statistics with zero, which is symmetric by construction. This corrected audit compares every sign-flipped statistic with the observed mean and reports both one- and two-sided exact randomization values. Training outputs are unchanged.

| Dataset | Method | Baseline | Mean gain | Hierarchical 95% CI | +/=/- seeds | Exact p (one/two sided) |
|---|---|---|---:|---:|---:|---:|
| domainnetmini_clip_60class | FedPissa-EquationPort | FedAvg-LoRA | +0.0048 | [-0.0044, +0.0151] | 5/0/0 | 0.0312/0.0625 |
| domainnetmini_clip_60class | FedAdapterManifold-Selective | FedPissa-EquationPort | +0.0048 | [-0.0041, +0.0126] | 4/0/1 | 0.0625/0.1250 |
| pacs_resnet18 | FedPissa-EquationPort | FedAvg-LoRA | +0.1541 | [+0.1178, +0.1900] | 5/0/0 | 0.0312/0.0625 |
| pacs_resnet18 | FedAdapterManifold-Selective | FedPissa-EquationPort | -0.0100 | [-0.0428, +0.0216] | 2/0/3 | 0.1875/0.3750 |
