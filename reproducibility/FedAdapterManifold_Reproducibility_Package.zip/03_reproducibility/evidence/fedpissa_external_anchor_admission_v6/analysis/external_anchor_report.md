# FedPissa-Anchored FAM Confirmation

The candidate pool and single directed FAM-vs-FedPissa edge were frozen before seeds 5--9 were evaluated. Test labels never enter selection.

| Setting | Seeds | Units | Anchor acc. | FAM candidate acc. | Deployed acc. | Gain | Hierarchical 95% CI | Admissions | Harm | Uncertified | Exact p | Safety | Positive |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| pacs_resnet18 | 5 | 20 | 0.6706 | 0.7684 | 0.7263 | +0.0556 | [+0.0169, +0.0978] | 8 | 0 | 0 | 0.0625 | True | False |
| domainnetmini_clip_60class | 5 | 30 | 0.7894 | 0.8092 | 0.7894 | +0.0000 | [+0.0000, +0.0000] | 0 | 0 | 0 | 1.0000 | True | False |

A zero-admission result is a valid strong-anchor ceiling result, not evidence of positive FAM utility. Positive utility is reported only when the pre-registered confirmation flag is true.
