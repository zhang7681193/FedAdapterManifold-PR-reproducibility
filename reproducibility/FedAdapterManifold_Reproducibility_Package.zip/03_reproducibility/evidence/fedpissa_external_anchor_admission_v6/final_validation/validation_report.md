# FedPissa-anchor v6 validation

- Checks: 298
- Passed: 298
- Failed: 0
- Receiver units: 50

All frozen protocol, provenance, selection, and unit-coverage checks pass.
