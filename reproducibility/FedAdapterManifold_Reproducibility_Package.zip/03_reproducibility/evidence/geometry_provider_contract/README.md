# Frozen geometry contract

This directory contains the exact visual-geometry summaries used by the audited
FedAdapterManifold evidence. It deliberately freezes inputs rather than following
later changes in any geometry-provider implementation.

## Replacement rule

1. An exact snapshot SHA-256 match may reuse the frozen result.
2. A non-identical snapshot with the same client order and graph support must replay
   the receiver certificate before use.
3. A changed client order or graph support must regenerate the semantic endpoint and
   replay the receiver certificate.
4. No provider revision is automatically substituted into a reported table.

`geometry_snapshot_manifest.csv` records dataset, seed, round, client order, evidence
references, and snapshot hash. `geometry_file_manifest.csv` records every file hash.
The `provider_drift_audit` directory contains controlled perturbation and actual
multi-provider comparisons. Local absolute source paths are intentionally excluded.
