# Geometry-provider drift audit

The audit follows the theory-first contract: provider outputs are separated into client order, graph support, distance values, and prototype anchors. Exact snapshot hashes are reusable. Any non-identical provider output must be re-certified; support or client-order changes additionally require endpoint regeneration.

- Controlled fixed-support receiver units: 390.
- Softmax stability-bound failures: 0.
- Cross-provider receiver units: 72.
- Automatically interchangeable cross-provider units: 0.

This is not a claim that every FedGeo revision is harmful. It is evidence that a provider revision is an experimental-condition change, not a software patch that can silently replace the frozen geometry used by the paper.
