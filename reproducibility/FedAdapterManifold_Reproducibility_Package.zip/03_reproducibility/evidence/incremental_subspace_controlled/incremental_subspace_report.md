# Incremental Adapter-Subspace Diagnostic

This audit uses directional transfer records and treats the federated seed, not each client pair, as the independent resampling unit. Predictors and failure are standardized within each backbone setting. The strict complete-case model controls visual geometry distance, label discrepancy, and receiver Local-LoRA loss before adding Grassmannian adapter distance.

## Controlled continuous effect

- Complete rows/settings/families: 730/7/5
- Standardized d_sub coefficient: 0.2228
- Hierarchical 95% interval: [0.0873, 0.4600]
- Partial correlation after controls: 0.2163
- Incremental R2: 0.0457
- Difficult-receiver partial correlation: 0.1928

## Leave-one-dataset-family-out generalization

| Held-out family | Rows | Context RMSE | Context+d_sub RMSE | RMSE reduction |
|---|---:|---:|---:|---:|
| BloodMNIST | 280 | 1.0181 | 1.0203 | -0.0022 |
| DomainNetMini | 150 | 1.0504 | 0.9944 | +0.0560 |
| OfficeCaltech | 60 | 1.0953 | 1.0599 | +0.0354 |
| OfficeHome | 120 | 0.9651 | 0.8944 | +0.0707 |
| PACS | 120 | 0.9848 | 1.0104 | -0.0256 |

## Leave-one-seed-out harmful-transfer prediction

| Model | Macro ROC-AUC | Macro PR-AUC | Macro Brier |
|---|---:|---:|---:|
| context_only | 0.6778 | 0.7442 | 0.1764 |
| context_plus_subspace | 0.6856 | 0.7488 | 0.1764 |
| subspace_only | 0.5080 | 0.5805 | 0.2487 |

## Equal-setting d_sub quartiles

| Quartile | Settings | Harmful-transfer rate | Mean directional failure |
|---|---:|---:|---:|
| Q1 | 11 | 0.6717 | 0.0776 |
| Q2 | 11 | 0.6552 | 0.0976 |
| Q3 | 11 | 0.6997 | 0.1108 |
| Q4 | 11 | 0.6925 | 0.1127 |

The analysis is diagnostic rather than causal. A positive controlled coefficient and improved out-of-family prediction support incremental information beyond geometry, labels, and receiver difficulty; mixed held-out families define the claim boundary.
