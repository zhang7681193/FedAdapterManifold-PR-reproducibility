# OfficeHome-65 FunctionTransport Confirmation Quality Audit

- Overall: `PASS`
- Checks: `35/35` passed
- Receiver-seed units: `20`
- Raw student top-1 gain: `0.001542007`; seed-bootstrap CI `[0.000594796, 0.002364928]`
- Positive seeds: `4/5`
- Deployed proper-loss gain: `0.022668003`; seed-bootstrap CI `[0.014986590, 0.028362840]`
- Certified non-local deployments: `12/20`; harmful: `0`

## Checks

- [x] confirmation protocol is frozen: `officehome65_clip_function_transport_untouched_confirmation_v1`
- [x] confirmation seed set: `[10, 11, 12, 13, 14]`
- [x] baseline seed set: `[10, 11, 12, 13, 14]`
- [x] provider registry seed set: `[10, 11, 12, 13, 14]`
- [x] provider registry hash: `03c38d946075d261ed48c3ab3f258be22ff5529812c780434ff999d9c586adc1`
- [x] provider snapshots are training-only: `{10: ['split_manifest.json', 'calibration rows', 'test rows'], 11: ['split_manifest.json', 'calibration rows', 'test rows'], 12: ['split_manifest.json', 'calibration rows', 'test rows'], 13: ['split_manifest.json', 'calibration rows', 'test rows'], 14: ['split_manifest.json', 'calibration rows', 'test rows']}`
- [x] provider snapshots are frozen: `{10: 'frozen', 11: 'frozen', 12: 'frozen', 13: 'frozen', 14: 'frozen'}`
- [x] receiver-seed grain is complete: `{'rows': 20, 'unique_keys': 20}`
- [x] receiver-seed grain is unique: `{'rows': 20, 'unique_keys': 20}`
- [x] required columns are present: `[]`
- [x] client-domain order is stable: `[('0', 'Art'), ('1', 'Clipart'), ('2', 'Product'), ('3', 'Real_World')]`
- [x] candidate pool fixed before calibration: `20`
- [x] no test construction: `0`
- [x] all deployments frozen before test: `20`
- [x] no test construction or selection: `0`
- [x] seed 10 provenance forbids test selection: `{'baseline': False, 'transport': False}`
- [x] seed 11 provenance forbids test selection: `{'baseline': False, 'transport': False}`
- [x] seed 12 provenance forbids test selection: `{'baseline': False, 'transport': False}`
- [x] seed 13 provenance forbids test selection: `{'baseline': False, 'transport': False}`
- [x] seed 14 provenance forbids test selection: `{'baseline': False, 'transport': False}`
- [x] baseline and transport split manifests match: `{10: {'baseline': '13517290a6d169981b91421d3f459364e82c280c75e58d89515249d562f90e83', 'transport': '13517290a6d169981b91421d3f459364e82c280c75e58d89515249d562f90e83', 'rows': 3983}, 11: {'baseline': '6ceef9241097028c66c3a924daea8a53127449d50e11b757fa5173521c1c8571', 'transport': '6ceef9241097028c66c3a924daea8a53127449d50e11b757fa5173521c1c8571', 'rows': 3983}, 12: {'baseline': '436b83665776404d5047cc47f725b6b28f201ebe69310ede08d94d2fd380e5e0', 'transport': '436b83665776404d5047cc47f725b6b28f201ebe69310ede08d94d2fd380e5e0', 'rows': 3983}, 13: {'baseline': 'bd1b3559c8d7a7f65537bfaf5e8076024f38122d74296bfb04131db49751ddfd', 'transport': 'bd1b3559c8d7a7f65537bfaf5e8076024f38122d74296bfb04131db49751ddfd', 'rows': 3983}, 14: {'baseline': 'db58cb92e49786de5f1b754e55977e8da10004c6206662300174b19a7cc1a9a6', 'transport': 'db58cb92e49786de5f1b754e55977e8da10004c6206662300174b19a7cc1a9a6', 'rows': 3983}}`
- [x] provider output hashes match transport provenance: `{10: True, 11: True, 12: True, 13: True, 14: True}`
- [x] local replay accuracy is exact: `0.0`
- [x] local replay sample counts are exact: `0`
- [x] local replay loss is within frozen tolerance: `{'difference': 1.0636964420385198e-08, 'tolerance': 1e-07}`
- [x] zero harmful certified admissions: `0`
- [x] at least one non-local deployment: `12`
- [x] deployed top-1 is pointwise preserved: `0.0`
- [x] deployed proper loss never increases: `0`
- [x] raw student mean is positive: `{10: 0.0019570378090440765, 11: -0.0001554639814423664, 12: 0.0009746588693957114, 13: 0.002468088748237063, 14: 0.0024657125473281083}`
- [x] raw student seed-bootstrap lower bound is positive: `[0.0005947958944793441, 0.0023649280800348838]`
- [x] raw student is positive in at least four seeds: `{'count': 4, 'seed_values': {10: 0.0019570378090440765, 11: -0.0001554639814423664, 12: 0.0009746588693957114, 13: 0.002468088748237063, 14: 0.0024657125473281083}}`
- [x] deployed proper-loss improvement is stable: `{'mean': 0.022668003321182222, 'ci': [0.014986589785642079, 0.02836284048215376], 'seed_values': {10: 0.028322981958994214, 11: 0.028825184600709486, 12: 0.019957088968518555, 13: 0.027517869291361408, 14: 0.008716891786327452}}`
- [x] raw student domain means are all positive: `{'Art': 0.0010471204188481353, 'Clipart': 0.002385685884691835, 'Product': 0.0003960396039603964, 'Real_World': 0.0023391812865497076}`
- [x] confirmation gate passed: `{'stage_passed': True, 'confirmation_passed': True}`
