# Function-Space Semantic Transport for FedAdapterManifold

Status: frozen development theory and implementation contract. This document
does not create a manuscript claim until the pre-registered confirmation stage
passes.

## 1. Problem exposed by the failed parameter-space transports

Let receiver `i` have a locally trained LoRA update `Delta_i`, and let donor
`j` have update `Delta_j`. Existing signed-span and common-descent experiments
removed factor gauge ambiguity and optimized training-fold descent, but they
still produced harmful held-out candidates on OfficeHome CLIP. The remaining
failure is therefore not merely

1. factor rotation (`BA = (BQ)(Q^{-1}A)`), or
2. low-rank refactorization error.

It is a receiver action mismatch: an update can be a descent direction in the
donor chart, or even on one receiver training fold, without defining a stable
receiver function away from that fold.

The new endpoint consequently transports functions, not donor parameters.
Geometry and prototypes propose fixed input-conditioned routing experts;
adapter subspace compatibility controls their support; receiver labels fit a
robust mixture on the adapter-training split; and the resulting teacher is
distilled back into one receiver-local LoRA adapter.

## 2. Leakage-free data boundary

For every receiver, data are separated before constructing any endpoint:

- `D_fit`: local LoRA training and function-teacher fitting;
- `D_cal`: independent outer admission certificate;
- `D_test`: one final evaluation after deployment is frozen.

The function-teacher API accepts only donor logits on `D_fit`, receiver labels
on `D_fit`, fixed fold identifiers, and precomputed routing priors. It has no
argument for `D_cal` or `D_test`. The outer certificate remains unchanged.

## 3. Fixed semantic routing experts

Let `p_j(x)` denote donor `j`'s predictive distribution on receiver input
`x`. Before seeing receiver calibration or test outcomes, construct `M`
routing experts

```text
q_m(x) = sum_j rho_mj(x) p_j(x),
e_m(x) = log q_m(x),                 m = 1,...,M.
```

Every scalar Geo/FAM expert is mixed in probability space and then converted
to log probabilities. This makes the expert invariant to donor-specific
additive logit gauges. The prototype expert further uses class-dependent
weights `rho_mjc(x)` and renormalizes the resulting class evidence. Thus it
can represent complementary class expertise that no scalar donor route can.

Each `rho_mj(x)` is fixed by a declared mechanism such as:

- Local-only anchor;
- geometry-neighbor routing;
- class-prototype routing;
- geometry plus adapter-subspace support;
- shared/domain/personal adapter-bank routing.

The subspace signal is a support condition, not a replacement for visual
geometry. A donor with incompatible Grassmannian row/column spaces receives
zero or reduced support even when visual geometry proposes it as a neighbor.
Input-conditioned prototype routing is therefore contained inside each fixed
expert `e_m`; the learned coefficients below mix a finite set of declared
expert functions rather than changing the protocol after observing test data.

## 4. Why function transport addresses the remaining mismatch

Let `F_i(Delta; x)` be receiver `i`'s logits after inserting update `Delta`.
Let `bar_Delta = sum_j beta_j Delta_j`. Assume each logit coordinate is
twice differentiable and its Hessian with respect to `Delta` has operator norm
at most `H_i(x)` on the convex hull of the donor updates.

### Theorem FT1: parameter-mixture curvature gap

For every input `x`,

```text
|| F_i(bar_Delta; x) - sum_j beta_j F_i(Delta_j; x) ||_infinity
  <= H_i(x)/2 * sum_j beta_j ||Delta_j - bar_Delta||_F^2.
```

Proof. Expand every scalar logit `F_ic(Delta_j; x)` to second order around
`bar_Delta`. The weighted first-order terms vanish because
`sum_j beta_j(Delta_j-bar_Delta)=0`. The Hessian bound controls the weighted
remainders. Taking the largest coordinate gives the result.

Interpretation. Rotational alignment and full-rank lifting can remove algebraic
factor mismatch, but they cannot remove this semantic curvature term. It grows
with receiver-specific donor dispersion. A function mixture evaluates each
donor endpoint before combination and therefore avoids creating these parameter
cross-terms. Distillation subsequently compresses that function into the
receiver chart.

## 5. Receiver-relative robust teacher

The receiver anchor must not be evaluated on examples used to fit it. Split
`D_fit` into three fixed class-stratified folds. Train a receiver Local anchor
on `D_fit` without fold `s` and construct every fixed expert prediction on the
held-out fold. These predictions form an out-of-fold expert tensor.

Let the teacher score be `z_beta(x) = sum_m beta_m e_m(x)`, where `beta` lies
in the simplex and the
cross-fitted Local expert is included. For each held-out fold `s`, fit `beta`
on the other two out-of-fold blocks and evaluate it once on block `s`. Define
the nested held-out receiver regret

```text
r_s(beta) = Rhat_s(q_beta) - Rhat_s(Local).
```

On each inner fit, optimize `beta` with

```text
J_tau(beta)
  = tau log [(1/S) sum_s exp(r_s(beta)/tau)]
    + lambda KL(beta || pi),
```

where `pi` is a declared geometry/prototype prior over the fixed experts. A
teacher is proposal-positive only when all three unseen-fold regrets are
strictly negative. Final deployment weights are then fitted on all out-of-fold
predictions; they are never selected from outer calibration or test outcomes.

This objective differs from the failed common-descent formulation in two
crucial ways: it minimizes worst-fold regret relative to a cross-fitted
receiver Local-LoRA, not absolute loss, and every reported proposal-side
regret is measured on a fold unused for both receiver training and route
fitting. A difficult fold cannot dominate merely because all models have high
loss there, while full-data Local training optimism cannot force every route
back to the Local vertex.

### Theorem FT2: convex robust routing and fold certificate

For fixed expert logits and multiclass cross entropy, `J_tau(beta)` is convex
on the simplex. If `lambda > 0` and `pi` is positive on the active support, the
entropy term gives a unique active-support optimum whenever the remaining loss
does not destroy strict convexity. The centered smooth maximum has the same
minimizer as its unnormalized form and satisfies

```text
max_s r_s(beta) - tau log S
  <= tau log[(1/S) sum_s exp(r_s(beta)/tau)]
  <= max_s r_s(beta).
```

Proof. Logits are affine in `beta`; cross entropy is convex in logits, hence
each `r_s` is convex. Log-sum-exp is convex and coordinatewise nondecreasing,
so its composition with the fold regrets is convex. KL is convex. The displayed
bounds follow from bounding the exponential sum by its maximum term and by `S`
times that term. Positive utility is certified by the exact condition
`max_s r_s(beta) < 0`; neither the harmless centering constant nor the KL
regularizer is treated as receiver risk.

The implementation also supports a shared-bias restriction
`rho_j(x) proportional to pi_j(x) exp(b_j)`. That restricted router preserves
prototype support and transfers to unseen inputs, but the formal convex claim
above applies to mixtures of fixed input-conditioned experts. Official
confirmation must use the fixed-expert form; the shared-bias form remains a
development ablation.

## 6. Distillation into one receiver adapter

Let teacher logits be `q(x)` and let `s_theta(x)` be a receiver-local LoRA
student initialized from Local-LoRA. Fit only on `D_fit` using

```text
L_student(theta)
  = CE(y, s_theta(x))
    + mu KL(softmax(q/T) || softmax(s_theta/T))
    + eta KL(softmax(Local/T) || softmax(s_theta/T)).
```

The final term anchors the student when teacher evidence is weak. Adapter rank
may be allocated by the already declared novelty/conflict rule, but it cannot
be selected from `D_cal` or `D_test`.

### Theorem FT3: positive-utility decomposition

Multiclass cross entropy is 2-Lipschitz in the logit infinity norm. Define

```text
gamma = R(Local) - R(q),
delta = E ||s_theta(x) - q(x)||_infinity.
```

Then

```text
R(s_theta) - R(Local) <= -gamma + 2 delta.
```

Proof. The gradient of cross entropy with respect to logits is `p-y`; its
one-norm is at most 2. The mean-value theorem and duality between the one- and
infinity-norms give `R(s_theta)-R(q) <= 2 delta`. Add
`R(q)-R(Local) = -gamma`.

On labeled training folds, a tighter identity is available:

```text
Rhat_s(s_theta)-Rhat_s(Local)
  = -hat_gamma_s + [Rhat_s(s_theta)-Rhat_s(q)].
```

The implementation therefore reports both the conservative logit-Lipschitz
bound and the full-training student regret as diagnostics. Neither is used as
proposal evidence because the full-data Local and distilled student have seen
those same examples. Candidate construction instead requires negative nested
held-out teacher regret on all three cross-fit directions. Population safety
for the distilled student comes from independent calibration under FT4.

With empirical margin `hat_gamma`, empirical distillation error `hat_delta`, a
valid margin radius `epsilon_gamma`, and distillation radius `epsilon_delta`,
a sufficient observable condition is

```text
-hat_gamma + epsilon_gamma
  + 2(hat_delta + epsilon_delta) < 0.
```

This decomposition diagnoses two different failure modes instead of hiding
them in a single accuracy number:

- `hat_gamma <= 0`: the declared semantic expert hull contains no robustly
  useful external function for this receiver;
- `hat_gamma > 0` but the bound is nonnegative: the receiver LoRA rank or
  optimization cannot faithfully distill the useful teacher.

The first failure calls for better prototype/subspace experts. The second calls
for conflict/novelty-aware receiver capacity, not a new donor-weight sweep.

## 7. Independent deployment safety

The inner bound above is a proposal-side diagnostic. Deployment is decided on
independent `D_cal`. A proper-loss improvement does not imply top-1 accuracy
noninferiority, even when the two empirical calibration accuracies are equal.
The fixed endpoint set therefore contains two explicitly different paths:

1. A class-changing endpoint is admissible only after strict paired accuracy
   superiority and lower proper loss are certified.
2. A score-refinement endpoint applies the pointwise projection

```text
P_Local(z)(x) = z(x),       if argmax z(x) = argmax z_Local(x),
                z_Local(x), otherwise.
```

Its top-1 decision is identical to Local for every possible input, so its
accuracy is exactly Local's accuracy without a statistical noninferiority
assumption. It may still improve calibrated probability quality and is
admitted only after a paired proper-loss test.

The direct function bank and the distilled single-adapter student each expose
both paths. Their four hypotheses are fixed before calibration, and the
receiver-level alpha is divided across them. Selection among simultaneously
certified paths is deterministic: calibration accuracy first, proper loss
second, and a declared endpoint order last.

### Theorem FT4: pointwise top-1 identity and simultaneous anchored safety

For every distribution, the score-refinement path satisfies

```text
R_01(P_Local(z)) = R_01(Local)
```

exactly. For class-changing candidates, if the simultaneous bounds satisfy

```text
P(for all k: R(k)-R(Local) <= U_k) >= 1-delta,
```

then a class-changing selected deployment obeys

```text
R(selected) <= R(Local)
```

with probability at least `1-delta`.

Proof. The projection has the same argmax as Local pointwise, hence the same
0-1 loss for every labeled example and every population. If no candidate is
admitted, equality holds because Local is deployed. If class-changing
candidate `k` is admitted, the simultaneous event gives
`R(k)-R(Local) <= U_k < 0`. Bonferroni control over the four fixed endpoints
preserves the receiver-level error budget. Candidate construction and
candidate-count hashes must be frozen before calibration for the event to be
valid.

This theorem protects top-1 accuracy against the specific false inference
observed in development: equal empirical calibration accuracy is not treated
as population noninferiority. It does not manufacture a positive gain.
Positive accuracy gain must come from a strictly certified class-changing
path, while score refinement can only preserve accuracy and improve proper
loss. Both claims must be validated on untouched confirmation seeds.

### Corollary FT4.1: finite-calibration detection floor

For an exact one-sided paired sign test with `B` beneficial and zero harmful
discordances, the smallest attainable p-value is `2^{-B}`. With `K` fixed
endpoints and Bonferroni receiver budget `alpha`, strict accuracy superiority
therefore requires

```text
B >= ceil(log2(K / alpha)).
```

For the declared OfficeHome protocol, `K=4`, `alpha=0.0125`, and
`n_cal=130`, so at least nine beneficial flips are required even with no
harmful flip. The corresponding empirical accuracy effect is `9/130=6.92%`.
Consequently, a genuine one-percent accuracy improvement cannot be certified
per receiver under this calibration budget. It must be evaluated as a
multi-seed experimental effect, while deployment uses the pointwise
top-1-preserving path. Relaxing the test would not solve the power limitation;
it would only weaken the safety claim.

## 8. Combined mechanism and falsifiable predictions

The complete theory predicts:

1. Function teachers should improve nested held-out cross-fit regret more
   often than parameter-span candidates when donor updates occupy separated
   charts.
2. Teacher-positive/student-negative cases should correlate with distillation
   error and insufficient receiver rank.
3. Subspace filtering should reduce harmful teacher admissions beyond
   geometry/prototype routing alone, even when mean accuracy is tied.
4. If no external expert improves every fold, the method must fall back to
   Local; additional coefficient tuning should not reverse the conclusion.
5. On accepted endpoints, the independent calibration certificate should have
   zero harmful admissions within its declared confidence level.

Any official experiment must report all four counts: constructed teachers,
fold-positive teachers, distilled candidates satisfying FT3, and outer-admitted
deployments. Reporting only the final selected accuracy would not test the
mechanism.

## 9. Frozen development gate before confirmation seeds

No untouched confirmation seed is run until all of the following hold on the
already declared development units:

- the training code has no access path to outer calibration or test arrays;
- the fixed-expert objective and numerical gradient tests pass;
- at least one nontrivial receiver has negative regret on all three unseen
  cross-fit folds;
- at least one distilled receiver is admitted by the independent FT4 outer
  certificate;
- the outer certificate falls back exactly to Local for harmful candidates;
- the function endpoint is compared with Local, FedAvg-LoRA, Geo-only,
  parameter-space FAM, and the strongest declared recent LoRA baseline under
  identical data, rounds, rank, and calibration budget.

If the gate passes, confirmation seeds are executed once and all units are
reported. If it fails, the result is a scientifically useful boundary: the
available donor function hull lacks transferable receiver utility, and the
manuscript is not expanded with this endpoint.
