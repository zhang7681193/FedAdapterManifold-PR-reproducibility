# OfficeHome-65 FunctionTransport Untouched Confirmation

## Decision

The pre-registered confirmation passed. FedAdapterManifold may present
FunctionTransport as a confirmed extension, with a bounded claim: a small but
stable raw distilled-student accuracy improvement, stable proper-loss
improvement, and zero harmful certified deployment. It is not evidence of a
large universal accuracy gain.

## Frozen protocol

- Dataset: OfficeHome-65, clients Art, Clipart, Product, Real_World.
- Model: CLIP ViT-B/32 with attention LoRA.
- Training: rank 4, five federated rounds, one local epoch.
- Confirmation seeds: 10, 11, 12, 13, 14, unused during development.
- Geometry: FedAvg/frozen-ResNet18 training-only snapshots, round 4.
- Provider graph: original `graph_tau=1.0`, no post-hoc rescaling.
- Candidate construction: three-fold cross-fitted function teacher followed by
  distillation into one receiver-local LoRA.
- Deployment: fixed four-endpoint family, receiver alpha 0.0125, pointwise
  Local top-1-preserving score-refinement path.
- Test order: endpoint construction, calibration certificate, and all hashes
  are frozen before the test pass.

## Confirmation results

| Quantity | Result |
|---|---:|
| Receiver-seed units | 20 |
| Cross-fit positive on every held-out fold | 17/20 |
| Certified non-local deployments | 12/20 |
| Harmful certified deployments | 0/20 |
| Raw student top-1 gain over Local | +0.0015420 |
| Seed-bootstrap 95% CI | [+0.0005948, +0.0023649] |
| Positive seed means | 4/5 |
| Exact one-sided seed-sign p | 0.1875 |
| Deployed proper-loss gain | +0.0226680 |
| Proper-loss seed-bootstrap 95% CI | [+0.0149866, +0.0283628] |
| Deployed top-1 gain over Local | 0.0, by pointwise identity |
| Deployed top-1 gain over Geo-only | +0.0066406 |
| Raw direct-bank top-1 gain | -0.0011240 |

Raw student seed means are `+0.0019570`, `-0.0001555`, `+0.0009747`,
`+0.0024681`, and `+0.0024657`. The negative seed is retained. Mean raw
student gains are positive for every domain: Art `+0.0010471`, Clipart
`+0.0023857`, Product `+0.0003960`, and Real_World `+0.0023392`.

## Interpretation

The confirmation separates three statements.

1. Direct parameter/graph aggregation does not exceed the Local ceiling in
   this untouched setting.
2. Direct function-bank mixing is also insufficient on average.
3. The cross-fitted receiver teacher plus receiver-chart distillation produces
   a small positive effect that repeats on untouched seeds, while independent
   deployment certification prevents top-1 harm.

This is evidence for receiver-specific semantic transport, not for arbitrary
adapter averaging and not for replacing the adapter-subspace signal with the
FedGeo graph. The near-diagonal graph makes this a strict test: the method must
use raw visual distances, prototypes, adapter support, and receiver fitting
rather than obtaining gain from dense neighbor averaging.

## Audit trail

- Baselines: `results/function_transport_untouched_confirmation_v1_20260815/baselines`
- FunctionTransport outputs: `results/function_transport_untouched_confirmation_v1_20260815/function_transport`
- Quality audit: `results/function_transport_untouched_confirmation_v1_20260815/quality_audit`
- Provider registry: `results/office_home_confirmation_geometry_20260815/provider_snapshot_registry.json`
- Audit command: `scripts/audit_function_transport_confirmation.py`

The independent audit passes 35/35 checks covering receiver-seed grain,
duplicates, mandatory fields, provider hashes, training-only provider access,
split identity, test-free construction/selection, Local replay, certificate
safety, bootstrap reproduction, and the frozen success gate.
