# Training-only function-expert ablation

- receiver_seed_units: `20`
- mean_fam_increment_given_geo: `0.0019616569642656183`
- seed_bootstrap_ci_fam_increment_given_geo: `[0.0016790967800542679, 0.0021962648437449687]`
- positive_seed_means: `5`
- one_sided_seed_sign_p: `0.03125`
- mean_fam_endpoint_gain_vs_geo: `0.0004025848428206538`
- claim_gate_passed: `True`
- stable_claim_gate_passed: `True`
- test_used_for_construction_selection_or_evaluation: `False`
