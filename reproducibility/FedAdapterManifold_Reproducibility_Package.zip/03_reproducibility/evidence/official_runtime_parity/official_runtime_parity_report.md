# Official-code runtime parity audit

Official server-side functions are executed directly from pinned source files whenever their recurrence is separable from the native task pipeline. The visual benchmark still retrains every method on the same client splits and budget; incompatible native-task accuracies are never imported.

| Method | Checks | Max abs. error | Status |
|---|---:|---:|---|
| FedALT | 8 | 0.000e+00 | PASS |
| FedEx-LoRA | 3 | 2.220e-16 | PASS |
| FedLEASE | 20 | 0.000e+00 | PASS |
| FedRot-LoRA | 6 | 6.715e-07 | PASS |
| FedSA-LoRA | 1 | 0.000e+00 | PASS |
| FedSmoothLoRA | 5 | 1.332e-15 | PASS |
| FedTreeLoRA | 16 | 0.000e+00 | PASS |
| LoRA-FAIR | 5 | 2.220e-16 | PASS |

FedSA-LoRA is the explicit exception: its official implementation is embedded in a FederatedScope GLUE pipeline. We execute our shared-A/local-B recurrence under the visual protocol and audit its defining official configuration, rather than claiming an execution of the incompatible native pipeline.

Overall: PASS.
