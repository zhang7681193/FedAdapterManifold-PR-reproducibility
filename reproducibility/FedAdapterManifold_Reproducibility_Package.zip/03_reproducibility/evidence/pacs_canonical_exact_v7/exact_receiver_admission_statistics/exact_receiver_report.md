# Immutable-Local Exact Receiver Admission Audit

| Run | Seeds | Units | Accuracy gain vs Local | 95% CI | Non-local | Harmful | Uncertified | Pred./realized loss r | Safety | Positive confirmation |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| pacs_resnet18 | 5 | 20 | 0.0506 | [0.0131, 0.0953] | 6 | 0 | 0 | nan | True | True |
