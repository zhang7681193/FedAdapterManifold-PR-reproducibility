# Subspace-Reg anchor endpoint-admission confirmation

The anchor, internal FAM endpoint, residual endpoint, candidate order, and exact serial-Holm certificate were frozen before the seed-5--9 test outputs were inspected.

- Non-anchor admissions: 3/20 (internal=3, residual=0).
- Harmful client-seed units versus immutable Subspace-Reg: 0/20.
- Mean gain versus Subspace-Reg: +0.0141.
- 95% seed-clustered CI: [+0.0022, +0.0259].
- 95% seed/client hierarchical CI: [+0.0000, +0.0366].
- Exact one-sided seed sign-flip p: 0.12500.
- Protocol valid: True.

**Interpretation:** Supports positive FAM endpoint admission beyond the strong Subspace-Reg anchor.

A safe fallback is not relabeled as an accuracy gain. Positive confirmation requires at least one non-anchor admission, zero negative client-seed units, and a strictly positive seed-clustered lower confidence bound.
