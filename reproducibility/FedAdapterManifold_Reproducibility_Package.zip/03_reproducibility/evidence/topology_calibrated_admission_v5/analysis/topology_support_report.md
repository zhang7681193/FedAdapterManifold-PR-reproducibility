# Topology-calibrated graph-support confirmation

The graph support map and all numerical parameters were fixed before these runs. Test labels were attached only after exact receiver deployment was frozen.

## domainnetmini_clip_60class
- Candidate generation: 30/30 receiver-seed units.
- Certified non-local deployment: 0/30.
- Gain over Local: +0.0000, hierarchical CI [+0.0000, +0.0000].
- Gain over Geo-only: +0.0000, hierarchical CI [+0.0000, +0.0000].
- Harmful / uncertified / invented-edge counts: 0 / 0 / 0.
- Generator decoupling passes: True; positive confirmation passes: False.

## officehome_clip_full
- Candidate generation: 20/20 receiver-seed units.
- Certified non-local deployment: 0/20.
- Gain over Local: +0.0000, hierarchical CI [+0.0000, +0.0000].
- Gain over Geo-only: +0.0000, hierarchical CI [+0.0000, +0.0000].
- Harmful / uncertified / invented-edge counts: 0 / 0 / 0.
- Generator decoupling passes: True; positive confirmation passes: False.
