# Topology Holm Replay Validation

- Checks: 120
- Failures: 0
- Endpoint-weight maximum absolute error vs legacy topology replay: 0.000e+00
- Selected units / non-local / harmful / uncertified: 50 / 0 / 0 / 0

## Status

PASS
