from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .adapters import LoRAAdapter, pad_factors


Array = np.ndarray


def _normalized_weights(weights: Array | None, n: int) -> Array:
    if weights is None:
        out = np.ones(n, dtype=np.float64) / float(n)
    else:
        out = np.asarray(weights, dtype=np.float64)
        out = out / np.clip(out.sum(), 1e-12, None)
    return out


def fedavg_lora(
    adapters: list[LoRAAdapter],
    weights: Array | None = None,
    target_rank: int | None = None,
    name: str = "fedavg_lora",
) -> LoRAAdapter:
    """Directly average LoRA factors, preserving the known baseline flaw."""

    if not adapters:
        raise ValueError("fedavg_lora requires at least one adapter")
    n = len(adapters)
    weights = _normalized_weights(weights, n)
    target_rank = int(target_rank or max(a.rank for a in adapters))
    input_dim = adapters[0].input_dim
    output_dim = adapters[0].output_dim
    avg_a = np.zeros((target_rank, input_dim), dtype=np.float64)
    avg_b = np.zeros((output_dim, target_rank), dtype=np.float64)
    for adapter, weight in zip(adapters, weights):
        a, b = pad_factors(adapter, target_rank)
        avg_a += weight * a
        avg_b += weight * b
    return LoRAAdapter(input_dim, output_dim, target_rank, avg_a, avg_b, alpha=float(target_rank), name=name)


def fedavg_lift(
    adapters: list[LoRAAdapter],
    weights: Array | None = None,
    target_rank: int | None = None,
    name: str = "fedavg_lift",
) -> LoRAAdapter:
    """Average merged Delta W updates, then project back with SVD."""

    if not adapters:
        raise ValueError("fedavg_lift requires at least one adapter")
    n = len(adapters)
    weights = _normalized_weights(weights, n)
    target_rank = int(target_rank or max(a.rank for a in adapters))
    delta = np.zeros_like(adapters[0].delta())
    for adapter, weight in zip(adapters, weights):
        delta += weight * adapter.delta()
    return LoRAAdapter.from_delta(delta, rank=target_rank, alpha=float(target_rank), name=name)


def fedrot_lora(
    adapters: list[LoRAAdapter],
    weights: Array | None = None,
    target_rank: int | None = None,
    name: str = "fedrot_lora",
) -> LoRAAdapter:
    """FedRot-style factor averaging after orthogonal gauge alignment.

    LoRA factors are rotation/gauge ambiguous: ``B @ A == (B Q) @ (Q.T A)``
    for any orthogonal ``Q``.  This lightweight control aligns each client's
    padded factorization to the first nonzero adapter's gauge before averaging
    factors.  It tests whether rotational misalignment alone explains the
    negative transfer that FedAdapterManifold targets.
    """

    if not adapters:
        raise ValueError("fedrot_lora requires at least one adapter")
    n = len(adapters)
    weights = _normalized_weights(weights, n)
    target_rank = int(target_rank or max(a.rank for a in adapters))
    input_dim = adapters[0].input_dim
    output_dim = adapters[0].output_dim
    padded = [pad_factors(adapter, target_rank) for adapter in adapters]
    ref_idx = _reference_factor_index(padded)
    ref_a, _ = padded[ref_idx]
    avg_a = np.zeros((target_rank, input_dim), dtype=np.float64)
    avg_b = np.zeros((output_dim, target_rank), dtype=np.float64)
    for (a, b), weight in zip(padded, weights):
        q = _orthogonal_gauge_alignment(a, ref_a)
        avg_a += weight * (q.T @ a)
        avg_b += weight * (b @ q)
    return LoRAAdapter(input_dim, output_dim, target_rank, avg_a, avg_b, alpha=float(target_rank), name=name)


def fedrot_align_to_reference(
    adapter: LoRAAdapter,
    reference: LoRAAdapter,
    align_factor: str,
    strength: float = 0.4,
    name: str | None = None,
) -> LoRAAdapter:
    """Apply the alternating soft rotation used by FedRot-LoRA.

    The independent implementation follows Eqs. (3)--(6) of FedRot-LoRA:
    align to the previous global A or B factor, interpolate the Procrustes
    rotation with the identity, project back to SO(r), and transform both
    factors so that ``B @ A`` is unchanged.
    """

    if adapter.rank != reference.rank:
        raise ValueError("FedRot-LoRA requires a common LoRA rank")
    factor = str(align_factor).upper()
    if factor == "A":
        correlation = adapter.A @ reference.A.T
    elif factor == "B":
        correlation = adapter.B.T @ reference.B
    else:
        raise ValueError("align_factor must be 'A' or 'B'")

    rotation = _proper_orthogonal_factor(correlation)
    strength = float(np.clip(strength, 0.0, 1.0))
    if strength < 1.0:
        interpolated = (1.0 - strength) * np.eye(adapter.rank, dtype=np.float64) + strength * rotation
        rotation = _proper_orthogonal_factor(interpolated)
    return LoRAAdapter(
        input_dim=adapter.input_dim,
        output_dim=adapter.output_dim,
        rank=adapter.rank,
        A=rotation.T @ adapter.A,
        B=adapter.B @ rotation,
        alpha=adapter.alpha,
        name=name or adapter.name,
    )


def _proper_orthogonal_factor(matrix: Array) -> Array:
    """Return the closest proper rotation (determinant +1)."""

    matrix = np.nan_to_num(np.asarray(matrix, dtype=np.float64), nan=0.0, posinf=0.0, neginf=0.0)
    rank = int(matrix.shape[0])
    if matrix.shape != (rank, rank):
        raise ValueError(f"Expected a square correlation matrix, got {matrix.shape}")
    try:
        u, _, vt = np.linalg.svd(matrix, full_matrices=False)
        if np.linalg.det(u @ vt) < 0.0:
            vt = vt.copy()
            vt[-1, :] *= -1.0
        rotation = u @ vt
    except np.linalg.LinAlgError:
        rotation = np.eye(rank, dtype=np.float64)
    if not np.all(np.isfinite(rotation)):
        rotation = np.eye(rank, dtype=np.float64)
    return rotation


def _reference_factor_index(factors: list[tuple[Array, Array]]) -> int:
    norms = [float(np.linalg.norm(a) + np.linalg.norm(b)) for a, b in factors]
    return int(np.argmax(norms)) if norms else 0


def _orthogonal_gauge_alignment(source_a: Array, reference_a: Array) -> Array:
    """Return Q so that Q.T @ source_a is close to reference_a."""

    rank = int(source_a.shape[0])
    if rank == 0:
        return np.zeros((0, 0), dtype=np.float64)
    cross = np.nan_to_num(source_a @ reference_a.T, nan=0.0, posinf=0.0, neginf=0.0)
    try:
        u, _, vt = np.linalg.svd(cross, full_matrices=False)
        q = u @ vt
    except np.linalg.LinAlgError:
        q = np.eye(rank, dtype=np.float64)
    if q.shape != (rank, rank) or not np.all(np.isfinite(q)):
        q = np.eye(rank, dtype=np.float64)
    return q


def compatibility_matrix(
    d_sub: Array,
    d_geo: Array,
    d_label: Array,
    lambda_geo: float = 0.5,
    lambda_label: float = 0.25,
    tau: float = 1.0,
) -> Array:
    score = np.asarray(d_sub) + lambda_geo * np.asarray(d_geo) + lambda_label * np.asarray(d_label)
    tau = max(float(tau), 1e-8)
    compat = np.exp(-score / tau)
    np.fill_diagonal(compat, 1.0)
    return compat


def normalize_rows(matrix: Array) -> Array:
    matrix = np.asarray(matrix, dtype=np.float64)
    return matrix / np.clip(matrix.sum(axis=1, keepdims=True), 1e-12, None)


def subspace_compatible_aggregate(
    adapters: list[LoRAAdapter],
    compatibility: Array,
    target_ranks: list[int] | None = None,
) -> list[LoRAAdapter]:
    """Client-specific compatibility weighted aggregation."""

    beta = normalize_rows(compatibility)
    if target_ranks is None:
        target_ranks = [a.rank for a in adapters]
    out = []
    for i in range(len(adapters)):
        out.append(
            fedavg_lift(
                adapters,
                weights=beta[i],
                target_rank=target_ranks[i],
                name=f"subspace_compatible_client_{i}",
            )
        )
    return out


def graph_weight_matrix(
    graph: Array,
    distance: Array | None = None,
    tau: float = 1.0,
    self_weight: float = 1.0,
) -> Array:
    """Normalize FedGeo graph adjacency into client-specific sharing weights."""

    graph = np.asarray(graph, dtype=np.float64)
    if graph.ndim != 2 or graph.shape[0] != graph.shape[1]:
        raise ValueError(f"graph must be square, got {graph.shape}")
    n = graph.shape[0]
    weights = np.maximum(graph, 0.0).copy()
    np.fill_diagonal(weights, 0.0)
    if distance is not None:
        dist = np.asarray(distance, dtype=np.float64)
        if dist.shape != graph.shape:
            raise ValueError(f"distance shape {dist.shape} does not match graph {graph.shape}")
        tau = max(float(tau), 1e-8)
        weights *= np.exp(-dist / tau)
    for i in range(n):
        weights[i, i] = max(float(self_weight), weights[i, i])
        if weights[i].sum() <= 1e-12:
            weights[i, i] = 1.0
    return normalize_rows(weights)


def graph_compatible_aggregate(
    adapters: list[LoRAAdapter],
    graph: Array,
    compatibility: Array | None = None,
    distance: Array | None = None,
    target_ranks: list[int] | None = None,
    tau: float = 1.0,
    self_weight: float = 1.0,
    name_prefix: str = "graph_compatible",
) -> list[LoRAAdapter]:
    """Aggregate adapters only along the FedGeo client manifold graph."""

    weights = graph_weight_matrix(graph, distance=distance, tau=tau, self_weight=self_weight)
    if compatibility is not None:
        compat = np.asarray(compatibility, dtype=np.float64)
        if compat.shape != weights.shape:
            raise ValueError(f"compatibility shape {compat.shape} does not match graph weights {weights.shape}")
        weights = normalize_rows(weights * np.maximum(compat, 0.0))
    if target_ranks is None:
        target_ranks = [a.rank for a in adapters]
    out = []
    for i in range(len(adapters)):
        out.append(
            fedavg_lift(
                adapters,
                weights=weights[i],
                target_rank=target_ranks[i],
                name=f"{name_prefix}_client_{i}",
            )
        )
    return out


def semantic_admissible_lift_aggregate(
    adapters: list[LoRAAdapter],
    graph: Array,
    d_sub: Array,
    d_geo: Array,
    d_label: Array,
    d_local_risk: Array,
    target_ranks: list[int] | None = None,
    lambda_geo: float = 0.5,
    lambda_label: float = 0.25,
    lambda_risk: float = 1.0,
    tau: float = 1.0,
    self_weight: float = 1.0,
    receiver_self_weights: Array | None = None,
    graph_mass_temperature: float = 10.0,
    minimum_tempered_neighbor_mass: float = 0.1,
    name_prefix: str = "semantic_admit",
) -> tuple[list[LoRAAdapter], Array]:
    """Aggregate exact updates after receiver-specific semantic admission.

    The method first removes LoRA gauge/factorization ambiguity by operating on
    full ``Delta W`` updates.  For receiver ``i``, its graph prior is
    temperature-calibrated and then tempered by subspace, visual,
    label-support, and training-side local-risk costs.
    The resulting Gibbs weights solve an entropy-regularized local mismatch
    surrogate; only then is the exact weighted update projected to the
    receiver's deployment rank.
    """

    n = len(adapters)
    graph = np.asarray(graph, dtype=np.float64)
    matrices = {
        "d_sub": np.asarray(d_sub, dtype=np.float64),
        "d_geo": np.asarray(d_geo, dtype=np.float64),
        "d_label": np.asarray(d_label, dtype=np.float64),
        "d_local_risk": np.asarray(d_local_risk, dtype=np.float64),
    }
    if graph.shape != (n, n):
        raise ValueError(f"graph shape {graph.shape} does not match {n} adapters")
    for name, matrix in matrices.items():
        if matrix.shape != (n, n):
            raise ValueError(f"{name} shape {matrix.shape} does not match {n} adapters")
    if target_ranks is None:
        target_ranks = [adapter.rank for adapter in adapters]
    if len(target_ranks) != n:
        raise ValueError(f"Expected {n} target ranks, got {len(target_ranks)}")
    if receiver_self_weights is None:
        self_weights = np.full(n, max(float(self_weight), 1e-12), dtype=np.float64)
    else:
        self_weights = np.asarray(receiver_self_weights, dtype=np.float64)
        if self_weights.shape != (n,):
            raise ValueError(f"receiver_self_weights shape {self_weights.shape} does not match {(n,)}")
        self_weights = np.maximum(self_weights, 1e-12)

    cost = _off_diagonal_minmax(matrices["d_sub"])
    cost += max(0.0, float(lambda_geo)) * _off_diagonal_minmax(matrices["d_geo"])
    cost += max(0.0, float(lambda_label)) * _off_diagonal_minmax(matrices["d_label"])
    cost += max(0.0, float(lambda_risk)) * _off_diagonal_minmax(matrices["d_local_risk"])
    support = np.maximum(graph, 0.0).copy()
    np.fill_diagonal(support, 0.0)
    for i in range(n):
        neighbor_mass = float(support[i].sum())
        if neighbor_mass > 1e-12:
            # The interface supplies an adjacency, and providers may normalize
            # its self-loop to nearly one.  Preserve relative neighbor weights
            # while tempering, rather than erasing, its absolute neighbor mass.
            support[i] /= neighbor_mass
            temperature = max(float(graph_mass_temperature), 1e-8)
            tempered_neighbor_mass = min(1.0, neighbor_mass ** (1.0 / temperature))
            if tempered_neighbor_mass >= max(0.0, float(minimum_tempered_neighbor_mass)):
                support[i] *= tempered_neighbor_mass
            else:
                support[i] *= 0.0
        support[i, i] = float(self_weights[i])
        if neighbor_mass <= 1e-12:
            support[i] *= 0.0
            support[i, i] = 1.0
    logits = -cost / max(float(tau), 1e-8)
    logits -= np.max(logits, axis=1, keepdims=True)
    weights = support * np.exp(logits)
    weights = normalize_rows(weights)

    deltas = [adapter.delta() for adapter in adapters]
    output: list[LoRAAdapter] = []
    for i in range(n):
        exact_delta = np.zeros_like(deltas[0])
        for weight, delta in zip(weights[i], deltas):
            exact_delta += float(weight) * delta
        rank = int(target_ranks[i])
        output.append(
            LoRAAdapter.from_delta(
                exact_delta,
                rank=rank,
                alpha=float(rank),
                name=f"{name_prefix}_client_{i}",
            )
        )
    return output, weights


def receiver_subspace_projected_aggregate(
    adapters: list[LoRAAdapter],
    graph: Array,
    d_sub: Array,
    d_geo: Array,
    d_label: Array,
    d_local_risk: Array,
    target_ranks: list[int] | None = None,
    lambda_geo: float = 0.5,
    lambda_label: float = 0.25,
    lambda_risk: float = 1.0,
    tau: float = 1.0,
    self_weight: float = 1.0,
    projection_mode: str = "core",
    projection_cost_mode: str = "full",
    projection_support_mode: str = "graph",
    projection_knn: int = 2,
    client_weights: Array | None = None,
    name_prefix: str = "receiver_projected",
) -> tuple[list[LoRAAdapter], Array]:
    """Share only donor components inside each receiver's LoRA action space.

    This branch is distinct from full-update semantic admission.  The graph is
    used only to rank possible donors; every donor update is first projected
    through the receiver's column and row subspaces.  Consequently the mixed
    update remains in the receiver's rank-constrained semantic action space,
    even when the provider gives low absolute confidence to full-update
    sharing.  Training-side and held-out gates remain responsible for deciding
    whether the projected candidate is useful.
    """

    n = len(adapters)
    graph = np.asarray(graph, dtype=np.float64)
    matrices = {
        "d_sub": np.asarray(d_sub, dtype=np.float64),
        "d_geo": np.asarray(d_geo, dtype=np.float64),
        "d_label": np.asarray(d_label, dtype=np.float64),
        "d_local_risk": np.asarray(d_local_risk, dtype=np.float64),
    }
    if graph.shape != (n, n):
        raise ValueError(f"graph shape {graph.shape} does not match {n} adapters")
    for name, matrix in matrices.items():
        if matrix.shape != (n, n):
            raise ValueError(f"{name} shape {matrix.shape} does not match {n} adapters")
    if target_ranks is None:
        target_ranks = [adapter.rank for adapter in adapters]
    if len(target_ranks) != n:
        raise ValueError(f"Expected {n} target ranks, got {len(target_ranks)}")

    projection_support_mode = str(projection_support_mode).strip().lower()
    if projection_support_mode == "graph":
        support = np.maximum(graph, 0.0).copy()
        np.fill_diagonal(support, 0.0)
        for i in range(n):
            neighbor_mass = float(support[i].sum())
            if neighbor_mass > 0.0:
                support[i] /= neighbor_mass
            support[i, i] = max(float(self_weight), 1e-12)
    elif projection_support_mode == "soft-dgeo":
        # The hard graph remains the authority for full-update admission.  A
        # projected component changes the admissible object, so its proposal
        # neighborhood is built explicitly from d_geo instead of amplifying
        # tiny numerical tails in a nearly disconnected hard graph.
        donor_prior = _normalized_weights(client_weights, n)
        distance = np.asarray(matrices["d_geo"], dtype=np.float64)
        off_diagonal = distance[~np.eye(n, dtype=bool)]
        positive = off_diagonal[np.isfinite(off_diagonal) & (off_diagonal > 0.0)]
        scale = float(np.median(positive)) if positive.size else 1.0
        scale = max(scale, 1e-12)
        support = np.zeros((n, n), dtype=np.float64)
        k = max(1, min(int(projection_knn), max(n - 1, 1)))
        for i in range(n):
            order = np.argsort(distance[i])
            neighbors = [int(j) for j in order if int(j) != i and np.isfinite(distance[i, j])][:k]
            for j in neighbors:
                support[i, j] = float(np.exp(-max(0.0, float(distance[i, j])) / scale)) * donor_prior[j]
            support[i, i] = max(float(self_weight), 1e-12) * donor_prior[i]
    elif projection_support_mode == "shared-axis-all":
        # A hard visual graph can be too conservative after the receiver has
        # projected out its conflicted LoRA axis. Keep every training client as
        # a proposal and let the post-projection shared-axis, geometry, label,
        # and local-risk costs determine receiver-specific compatibility.
        donor_prior = _normalized_weights(client_weights, n)
        support = np.broadcast_to(donor_prior[None, :], (n, n)).copy()
        for i in range(n):
            support[i, i] *= max(float(self_weight), 1e-12)
    else:
        raise ValueError("projection_support_mode must be 'graph', 'soft-dgeo', or 'shared-axis-all'")
    projection_mode = str(projection_mode).strip().lower()
    valid_projection_modes = {
        "core",
        "left",
        "right",
        "tangent",
        "left_gauge",
        "right_gauge",
        "axis_gauge",
        "axis_factor",
    }
    if projection_mode not in valid_projection_modes:
        raise ValueError(f"projection_mode must be one of {sorted(valid_projection_modes)}")
    deltas = [adapter.delta() for adapter in adapters]
    u_bases = [_orthonormal_columns(adapter.B) for adapter in adapters]
    v_bases = [_orthonormal_columns(adapter.A.T) for adapter in adapters]
    d_u = np.zeros((n, n), dtype=np.float64)
    d_v = np.zeros((n, n), dtype=np.float64)
    for i in range(n):
        for j in range(i + 1, n):
            d_u[i, j] = d_u[j, i] = _basis_grassmann_distance(u_bases[i], u_bases[j])
            d_v[i, j] = d_v[j, i] = _basis_grassmann_distance(v_bases[i], v_bases[j])
    auxiliary_cost = max(0.0, float(lambda_geo)) * _off_diagonal_minmax(matrices["d_geo"])
    auxiliary_cost += max(0.0, float(lambda_label)) * _off_diagonal_minmax(matrices["d_label"])
    auxiliary_cost += max(0.0, float(lambda_risk)) * _off_diagonal_minmax(matrices["d_local_risk"])
    provisional_cost = _off_diagonal_minmax(matrices["d_sub"]) + auxiliary_cost
    provisional_logits = -provisional_cost / max(float(tau), 1e-8)
    provisional_logits -= np.max(provisional_logits, axis=1, keepdims=True)
    provisional_weights = normalize_rows(support * np.exp(provisional_logits))

    receiver_modes = [projection_mode] * n
    if projection_mode in {"axis_gauge", "axis_factor"}:
        for i in range(n):
            donor_weights = provisional_weights[i].copy()
            donor_weights[i] = 0.0
            donor_mass = float(donor_weights.sum())
            if donor_mass > 0.0:
                donor_weights /= donor_mass
            column_conflict = float(np.dot(donor_weights, d_u[i]))
            row_conflict = float(np.dot(donor_weights, d_v[i]))
            if projection_mode == "axis_factor":
                receiver_modes[i] = "left_factor" if column_conflict >= row_conflict else "right_factor"
            else:
                receiver_modes[i] = "left_gauge" if column_conflict >= row_conflict else "right_gauge"

    projection_cost_mode = str(projection_cost_mode).strip().lower()
    if projection_cost_mode not in {"full", "shared-axis"}:
        raise ValueError("projection_cost_mode must be 'full' or 'shared-axis'")
    semantic_cost = matrices["d_sub"].copy()
    if projection_cost_mode == "shared-axis":
        for i, receiver_mode in enumerate(receiver_modes):
            if receiver_mode in {"left", "left_gauge", "left_factor"}:
                # U is personalized/projected out; only the actually shared V
                # axis remains relevant to semantic compatibility.
                semantic_cost[i] = d_v[i]
            elif receiver_mode in {"right", "right_gauge", "right_factor"}:
                semantic_cost[i] = d_u[i]
    cost = _off_diagonal_minmax(semantic_cost) + auxiliary_cost
    logits = -cost / max(float(tau), 1e-8)
    logits -= np.max(logits, axis=1, keepdims=True)
    weights = normalize_rows(support * np.exp(logits))

    output: list[LoRAAdapter] = []
    for i, receiver in enumerate(adapters):
        u_i = u_bases[i]
        v_i = v_bases[i]
        receiver_mode = receiver_modes[i]
        rank = int(target_ranks[i])
        if receiver_mode == "left_factor":
            shared_a = np.zeros((rank, receiver.input_dim), dtype=np.float64)
            _, receiver_b = pad_factors(receiver, rank)
            for weight, donor in zip(weights[i], adapters):
                donor_a, _ = pad_factors(donor, rank)
                shared_a += float(weight) * donor_a
            output.append(
                LoRAAdapter(
                    input_dim=receiver.input_dim,
                    output_dim=receiver.output_dim,
                    rank=rank,
                    A=shared_a,
                    B=receiver_b,
                    alpha=float(rank),
                    name=f"{name_prefix}_left_factor_client_{i}",
                )
            )
            continue
        if receiver_mode == "right_factor":
            receiver_a, _ = pad_factors(receiver, rank)
            shared_b = np.zeros((receiver.output_dim, rank), dtype=np.float64)
            for weight, donor in zip(weights[i], adapters):
                _, donor_b = pad_factors(donor, rank)
                shared_b += float(weight) * donor_b
            output.append(
                LoRAAdapter(
                    input_dim=receiver.input_dim,
                    output_dim=receiver.output_dim,
                    rank=rank,
                    A=receiver_a,
                    B=shared_b,
                    alpha=float(rank),
                    name=f"{name_prefix}_right_factor_client_{i}",
                )
            )
            continue
        projected_delta = np.zeros_like(deltas[i])
        for weight, donor_delta in zip(weights[i], deltas):
            core = u_i @ (u_i.T @ donor_delta @ v_i) @ v_i.T
            left = u_i @ (u_i.T @ donor_delta)
            right = (donor_delta @ v_i) @ v_i.T
            if receiver_mode == "core":
                donor_in_receiver = core
            elif receiver_mode in {"left", "left_gauge"}:
                donor_in_receiver = left
            elif receiver_mode in {"right", "right_gauge"}:
                donor_in_receiver = right
            else:
                donor_in_receiver = left + right - core
            projected_delta += float(weight) * donor_in_receiver
        if receiver_mode == "left_gauge" and rank == receiver.rank:
            scale = max(float(receiver.scale), 1e-12)
            shared_a = np.linalg.pinv(receiver.B) @ (projected_delta / scale)
            output.append(
                LoRAAdapter(
                    input_dim=receiver.input_dim,
                    output_dim=receiver.output_dim,
                    rank=receiver.rank,
                    A=shared_a,
                    B=receiver.B.copy(),
                    alpha=receiver.alpha,
                    name=f"{name_prefix}_left_gauge_client_{i}",
                )
            )
        elif receiver_mode == "right_gauge" and rank == receiver.rank:
            scale = max(float(receiver.scale), 1e-12)
            shared_b = (projected_delta / scale) @ np.linalg.pinv(receiver.A)
            output.append(
                LoRAAdapter(
                    input_dim=receiver.input_dim,
                    output_dim=receiver.output_dim,
                    rank=receiver.rank,
                    A=receiver.A.copy(),
                    B=shared_b,
                    alpha=receiver.alpha,
                    name=f"{name_prefix}_right_gauge_client_{i}",
                )
            )
        else:
            output.append(
                LoRAAdapter.from_delta(
                    projected_delta,
                    rank=rank,
                    alpha=float(rank),
                    name=f"{name_prefix}_client_{i}",
                )
            )
    return output, weights


def _orthonormal_columns(matrix: Array) -> Array:
    matrix = np.asarray(matrix, dtype=np.float64)
    if matrix.ndim != 2:
        raise ValueError(f"Expected a matrix, got shape {matrix.shape}")
    if matrix.shape[1] == 0:
        return np.zeros((matrix.shape[0], 0), dtype=np.float64)
    u, singular_values, _ = np.linalg.svd(matrix, full_matrices=False)
    if singular_values.size == 0:
        return np.zeros((matrix.shape[0], 0), dtype=np.float64)
    tolerance = max(matrix.shape) * np.finfo(np.float64).eps * float(singular_values[0])
    keep = singular_values > tolerance
    return u[:, keep]


def _basis_grassmann_distance(basis_a: Array, basis_b: Array) -> float:
    if basis_a.shape[1] == 0 and basis_b.shape[1] == 0:
        return 0.0
    if basis_a.shape[1] == 0 or basis_b.shape[1] == 0:
        return float(0.5 * np.pi * np.sqrt(max(basis_a.shape[1], basis_b.shape[1], 1)))
    singular_values = np.linalg.svd(basis_a.T @ basis_b, compute_uv=False)
    angles = np.arccos(np.clip(singular_values, -1.0, 1.0))
    return float(np.sqrt(np.sum(angles**2)))


def _off_diagonal_minmax(matrix: Array) -> Array:
    matrix = np.asarray(matrix, dtype=np.float64)
    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError(f"distance matrix must be square, got {matrix.shape}")
    mask = ~np.eye(matrix.shape[0], dtype=bool)
    values = matrix[mask]
    if values.size == 0:
        return np.zeros_like(matrix)
    low = float(np.min(values))
    high = float(np.max(values))
    if high - low <= 1e-12:
        output = np.zeros_like(matrix)
    else:
        output = (matrix - low) / (high - low)
    np.fill_diagonal(output, 0.0)
    return output


def geo_weighted_aggregate(
    adapters: list[LoRAAdapter],
    d_geo: Array,
    graph: Array | None = None,
    target_ranks: list[int] | None = None,
    tau: float = 1.0,
    self_weight: float = 1.0,
) -> list[LoRAAdapter]:
    """FedGeo-Agg: visual-geometry weighted sharing over the FedGeo graph."""

    d_geo = np.asarray(d_geo, dtype=np.float64)
    if graph is None:
        graph = np.ones_like(d_geo) - np.eye(d_geo.shape[0])
    return graph_compatible_aggregate(
        adapters,
        graph=graph,
        distance=d_geo,
        target_ranks=target_ranks,
        tau=tau,
        self_weight=self_weight,
        name_prefix="fedgeo_agg",
    )


@dataclass
class AdapterBank:
    shared_adapter: LoRAAdapter
    domain_adapters: list[LoRAAdapter]
    routing_weights: Array
    cluster_assignments: Array
    medoids: list[int]
    personal_adapters: list[LoRAAdapter] | None = None
    smoothing_adapters: list[LoRAAdapter] | None = None
    cluster_prototypes: Array | None = None
    shared_weight: float = 0.25
    personal_weight: float = 0.0
    smoothing_weight: float = 0.0
    smoothing_weights: Array | None = None
    route_tau: float = 1.0
    routing_prior_weight: float = 0.5

    def smoothing_weight_for_client(self, client_index: int) -> float:
        if self.smoothing_weights is not None:
            return float(np.clip(self.smoothing_weights[client_index], 0.0, 1.0))
        return float(np.clip(self.smoothing_weight, 0.0, 1.0))

    def delta_for_client(self, client_index: int) -> Array:
        domain_delta = np.zeros_like(self.shared_adapter.delta())
        for k, adapter in enumerate(self.domain_adapters):
            domain_delta += self.routing_weights[client_index, k] * adapter.delta()
        personal_delta = np.zeros_like(domain_delta)
        if self.personal_adapters is not None and self.personal_weight > 0.0:
            personal_delta = self.personal_adapters[client_index].delta()
        domain_weight = max(0.0, 1.0 - self.shared_weight - self.personal_weight)
        delta = (
            self.shared_weight * self.shared_adapter.delta()
            + domain_weight * domain_delta
            + self.personal_weight * personal_delta
        )
        weight = self.smoothing_weight_for_client(client_index)
        if self.smoothing_adapters is not None and weight > 0.0:
            delta = (1.0 - weight) * delta + weight * self.smoothing_adapters[client_index].delta()
        return delta

    def adapter_for_client(self, client_index: int, rank: int | None = None) -> LoRAAdapter:
        rank = int(rank or self.shared_adapter.rank)
        return LoRAAdapter.from_delta(
            self.delta_for_client(client_index),
            rank=rank,
            alpha=float(rank),
            name=f"fedadaptermanifold_client_{client_index}",
        )

    def routing_for_samples(self, x: Array, client_index: int, mode: str = "client") -> Array:
        x = np.asarray(x, dtype=np.float64)
        if mode in {"feature", "feature-prior"} and self.cluster_prototypes is not None:
            feature_route = feature_routing_weights(x, self.cluster_prototypes, tau=self.route_tau)
            if mode == "feature-prior":
                return blend_routing_with_client_prior(
                    feature_route,
                    self.routing_weights[client_index],
                    prior_weight=self.routing_prior_weight,
                )
            return feature_route
        if mode not in {"client", "feature", "feature-prior"}:
            raise ValueError(f"Unknown adapter-bank routing mode: {mode}")
        return np.repeat(self.routing_weights[client_index : client_index + 1], x.shape[0], axis=0)

    def logits_for_client(self, x: Array, base_weight: Array, client_index: int, mode: str = "client") -> Array:
        x = np.asarray(x, dtype=np.float64)
        logits = x @ np.asarray(base_weight, dtype=np.float64).T
        adapter_logits = self.shared_weight * (x @ self.shared_adapter.delta().T)
        route = self.routing_for_samples(x, client_index, mode=mode)
        domain_weight = max(0.0, 1.0 - self.shared_weight - self.personal_weight)
        for k, adapter in enumerate(self.domain_adapters):
            adapter_logits += domain_weight * route[:, k : k + 1] * (x @ adapter.delta().T)
        if self.personal_adapters is not None and self.personal_weight > 0.0:
            adapter_logits += self.personal_weight * (x @ self.personal_adapters[client_index].delta().T)
        weight = self.smoothing_weight_for_client(client_index)
        if self.smoothing_adapters is not None and weight > 0.0:
            smooth_logits = x @ self.smoothing_adapters[client_index].delta().T
            adapter_logits = (1.0 - weight) * adapter_logits + weight * smooth_logits
        return logits + adapter_logits


def build_adapter_bank(
    adapters: list[LoRAAdapter],
    d_geo: Array,
    combined_distance: Array,
    k: int,
    target_rank: int,
    route_tau: float = 1.0,
    shared_weight: float = 0.25,
    personal_weight: float = 0.0,
    cluster_prototypes: Array | None = None,
    routing_prior_weight: float = 0.5,
    personal_adapters: list[LoRAAdapter] | None = None,
    smoothing_adapters: list[LoRAAdapter] | None = None,
    smoothing_weight: float = 0.0,
    smoothing_weights: Array | None = None,
) -> AdapterBank:
    n = len(adapters)
    k = int(max(1, min(k, n)))
    medoids, assignments = k_medoids(combined_distance, k)
    sample_weights = np.ones(n, dtype=np.float64) / float(n)
    shared = fedavg_lift(adapters, weights=sample_weights, target_rank=target_rank, name="adapter_bank_shared")
    domain_adapters = []
    for cluster_id in range(k):
        members = np.flatnonzero(assignments == cluster_id)
        if members.size == 0:
            members = np.array([medoids[cluster_id]])
        weights = np.ones(members.size, dtype=np.float64) / float(members.size)
        domain_adapters.append(
            fedavg_lift(
                [adapters[int(i)] for i in members],
                weights=weights,
                target_rank=target_rank,
                name=f"adapter_bank_domain_{cluster_id}",
            )
        )
    route_dist = np.zeros((n, k), dtype=np.float64)
    for cluster_id, medoid in enumerate(medoids):
        route_dist[:, cluster_id] = combined_distance[:, medoid]
    routing = _softmax_negative(route_dist, tau=route_tau)
    personal_source = adapters if personal_adapters is None else personal_adapters
    smoothing_source = None if smoothing_adapters is None else [
        adapter.copy(name=f"adapter_bank_smoothing_{idx}") for idx, adapter in enumerate(smoothing_adapters)
    ]
    return AdapterBank(
        shared_adapter=shared,
        domain_adapters=domain_adapters,
        routing_weights=routing,
        cluster_assignments=assignments,
        medoids=medoids,
        personal_adapters=[adapter.copy(name=f"adapter_bank_personal_{idx}") for idx, adapter in enumerate(personal_source)],
        smoothing_adapters=smoothing_source,
        cluster_prototypes=cluster_prototypes,
        shared_weight=shared_weight,
        personal_weight=personal_weight,
        smoothing_weight=smoothing_weight,
        smoothing_weights=None if smoothing_weights is None else np.asarray(smoothing_weights, dtype=np.float64),
        route_tau=route_tau,
        routing_prior_weight=routing_prior_weight,
    )


def select_adapter_bank_k(
    distance: Array,
    max_k: int = 4,
    min_silhouette: float = 0.05,
) -> tuple[int, list[dict]]:
    """Select the number of adapter-bank clusters from a distance matrix.

    K=1 is the null hypothesis: one semantic adapter manifold is enough.
    For K>1 we use k-medoids plus a small-sample silhouette score and pick
    the smallest K within 95% of the best score.
    """

    distance = np.asarray(distance, dtype=np.float64)
    if distance.ndim != 2 or distance.shape[0] != distance.shape[1]:
        raise ValueError(f"distance must be square, got {distance.shape}")
    n = distance.shape[0]
    max_k = int(max(1, min(max_k, n)))
    rows = []
    null_cost = _medoid_cost(distance, np.zeros(n, dtype=np.int64), [int(np.argmin(distance.sum(axis=1)))])
    rows.append(
        {
            "candidate_k": 1,
            "silhouette": 0.0,
            "within_cluster_cost": null_cost,
            "relative_cost": 1.0,
            "selected": False,
        }
    )
    if n <= 2 or max_k <= 1:
        rows[0]["selected"] = True
        return 1, rows

    best_score = -np.inf
    candidate_rows: list[tuple[int, dict]] = []
    for k in range(2, max_k + 1):
        medoids, assignments = k_medoids(distance, k)
        silhouette = _silhouette_score(distance, assignments)
        cost = _medoid_cost(distance, assignments, medoids)
        row = {
            "candidate_k": k,
            "silhouette": silhouette,
            "within_cluster_cost": cost,
            "relative_cost": cost / max(null_cost, 1e-12),
            "selected": False,
        }
        rows.append(row)
        candidate_rows.append((k, row))
        best_score = max(best_score, silhouette)

    if not np.isfinite(best_score) or best_score < min_silhouette:
        selected = 1
    else:
        selected = min(k for k, row in candidate_rows if float(row["silhouette"]) >= 0.95 * best_score)
    for row in rows:
        row["selected"] = int(row["candidate_k"]) == selected
    return selected, rows


def k_medoids(distance: Array, k: int, iterations: int = 10) -> tuple[list[int], Array]:
    distance = np.asarray(distance, dtype=np.float64)
    n = distance.shape[0]
    if k >= n:
        return list(range(n)), np.arange(n, dtype=np.int64)
    medoids = [int(np.argmin(distance.sum(axis=1)))]
    while len(medoids) < k:
        nearest = np.min(distance[:, medoids], axis=1)
        nearest[medoids] = -1.0
        medoids.append(int(np.argmax(nearest)))
    assignments = np.zeros(n, dtype=np.int64)
    for _ in range(iterations):
        assignments = np.argmin(distance[:, medoids], axis=1).astype(np.int64)
        changed = False
        for cluster_id in range(k):
            members = np.flatnonzero(assignments == cluster_id)
            if members.size == 0:
                continue
            candidate_costs = distance[np.ix_(members, members)].sum(axis=1)
            best = int(members[np.argmin(candidate_costs)])
            if best != medoids[cluster_id]:
                medoids[cluster_id] = best
                changed = True
        if not changed:
            break
    assignments = np.argmin(distance[:, medoids], axis=1).astype(np.int64)
    return medoids, assignments


def _medoid_cost(distance: Array, assignments: Array, medoids: list[int]) -> float:
    cost = 0.0
    for i, cluster_id in enumerate(assignments):
        cost += float(distance[i, medoids[int(cluster_id)]])
    return cost / max(1, len(assignments))


def _silhouette_score(distance: Array, assignments: Array) -> float:
    distance = np.asarray(distance, dtype=np.float64)
    assignments = np.asarray(assignments, dtype=np.int64)
    n = distance.shape[0]
    if n <= 2 or np.unique(assignments).size <= 1:
        return 0.0
    scores = []
    for i in range(n):
        same = np.flatnonzero(assignments == assignments[i])
        same = same[same != i]
        if same.size == 0:
            scores.append(0.0)
            continue
        a = float(distance[i, same].mean())
        b = float("inf")
        for cluster_id in np.unique(assignments):
            if cluster_id == assignments[i]:
                continue
            other = np.flatnonzero(assignments == cluster_id)
            if other.size:
                b = min(b, float(distance[i, other].mean()))
        if not np.isfinite(b):
            scores.append(0.0)
        else:
            scores.append((b - a) / max(a, b, 1e-12))
    return float(np.mean(scores))


def _softmax_negative(distance: Array, tau: float) -> Array:
    tau = max(float(tau), 1e-8)
    logits = -np.asarray(distance, dtype=np.float64) / tau
    logits = logits - logits.max(axis=1, keepdims=True)
    exp = np.exp(logits)
    return exp / np.clip(exp.sum(axis=1, keepdims=True), 1e-12, None)


def feature_routing_weights(x: Array, cluster_prototypes: Array, tau: float = 1.0) -> Array:
    """Route each feature to the nearest semantic prototype bank."""

    x = np.asarray(x, dtype=np.float64)
    prototypes = np.asarray(cluster_prototypes, dtype=np.float64)
    if prototypes.ndim != 3:
        raise ValueError(f"cluster_prototypes must have shape K x C x D, got {prototypes.shape}")
    if x.ndim != 2 or x.shape[1] != prototypes.shape[2]:
        raise ValueError(f"x shape {x.shape} is incompatible with prototypes {prototypes.shape}")
    diff = x[:, None, None, :] - prototypes[None, :, :, :]
    class_distances = np.sqrt(np.sum(diff * diff, axis=-1))
    cluster_distances = class_distances.min(axis=2)
    return _softmax_negative(cluster_distances, tau=tau)


def blend_routing_with_client_prior(feature_route: Array, client_prior: Array, prior_weight: float = 0.5) -> Array:
    """Blend input-conditioned routing with the client geometry prior."""

    feature_route = np.asarray(feature_route, dtype=np.float64)
    prior = np.asarray(client_prior, dtype=np.float64)
    if feature_route.ndim != 2:
        raise ValueError(f"feature_route must be a 2D matrix, got {feature_route.shape}")
    if prior.shape != (feature_route.shape[1],):
        raise ValueError(f"client_prior shape {prior.shape} does not match routing width {feature_route.shape[1]}")
    weight = max(0.0, float(prior_weight))
    log_route = np.log(np.clip(feature_route, 1e-12, None)) + weight * np.log(np.clip(prior, 1e-12, None))[None, :]
    log_route = log_route - log_route.max(axis=1, keepdims=True)
    blended = np.exp(log_route)
    return blended / np.clip(blended.sum(axis=1, keepdims=True), 1e-12, None)
