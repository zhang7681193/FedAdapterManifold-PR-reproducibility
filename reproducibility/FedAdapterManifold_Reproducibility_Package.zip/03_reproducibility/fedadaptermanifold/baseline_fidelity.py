from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class BaselineFidelity:
    run_key: str
    paper_label: str
    category: str
    external_method_claim_allowed: bool
    implementation_scope: str
    source_url: str = ""
    source_revision: str = ""

    def as_row(self) -> dict:
        row = asdict(self)
        row["external_method_claim_allowed"] = int(self.external_method_claim_allowed)
        return row


BASELINE_FIDELITY: tuple[BaselineFidelity, ...] = (
    BaselineFidelity(
        "Local-LoRA",
        "Local-LoRA",
        "canonical baseline",
        True,
        "Independent client LoRA training with the same data, rank, optimizer, and local-update budget.",
    ),
    BaselineFidelity(
        "FedAvg-LoRA",
        "FedAvg-LoRA",
        "faithful protocol adaptation",
        True,
        "Synchronous sample-weighted factor averaging under the shared visual LoRA protocol.",
    ),
    BaselineFidelity(
        "FedProx-LoRA",
        "FedProx-LoRA",
        "faithful protocol adaptation",
        True,
        "FedAvg-LoRA local training with the FedProx proximal objective; mu=0 is regression-tested against FedAvg-LoRA.",
    ),
    BaselineFidelity(
        "Ditto-LoRA",
        "Ditto-LoRA",
        "faithful protocol adaptation",
        True,
        "A FedAvg-LoRA global branch and a client-personal branch with a proximal penalty to the current global adapter.",
    ),
    BaselineFidelity(
        "FedAvg-Lift",
        "Full-update lift/SVD control",
        "internal algebraic control",
        False,
        "Reconstructs each full update, averages updates, and projects the result to the target rank by SVD.",
    ),
    BaselineFidelity(
        "FedEx-LoRA",
        "FedEx-LoRA",
        "same-protocol visual port of pinned source recurrence",
        True,
        "Retains the exact full-update residual in the frozen base so the effective server update equals the sample-weighted mean of client BA updates without SVD truncation.",
        "https://github.com/CERT-Lab/fedex-lora",
        "2fa2e4a243f93c829e2b601e459e45aa748e4149",
    ),
    BaselineFidelity(
        "FedSA-LoRA",
        "FedSA-LoRA",
        "same-protocol visual port of pinned source recurrence",
        True,
        "Trains both LoRA factors, aggregates only A, and retains B as persistent client-local state under a common fixed-rank protocol.",
        "https://github.com/Pengxin-Guo/FedSA-LoRA",
        "5e616a06e806a8804e09820ddebfcbd2363f0a2f",
    ),
    BaselineFidelity(
        "FedPissa-EquationPort",
        "FedPissa equation-level visual port",
        "paper-equation same-protocol port",
        False,
        "Implements the published sample-weighted selective B aggregation, leave-one-client-out A-covariance tail projection, and sample-weighted decorrelation compensation under the common visual data, rank, optimizer, and round budget. Clients upload A and B for server covariance/aggregation, only B is aggregated and broadcast, and A remains personalized. No public reference implementation was identifiable at the protocol freeze, so this run is explicitly not labeled an official-code reproduction.",
        "https://openreview.net/forum?id=ZEWN40uNEh",
        "ICML-2026-camera-ready-equations-4-to-6",
    ),
    BaselineFidelity(
        "LoRA-FAIR",
        "LoRA-FAIR",
        "same-protocol visual port of pinned source recurrence",
        True,
        "Uniformly averages A, B, and BA, then applies the released Xavier-initialized residual-B SGD refinement with column-wise cosine reconstruction and L2 regularization.",
        "https://github.com/jmbian/LoRA-FAIR",
        "6afb36c4d8ff9f7b5dce5fd4be7728d4f9467d5a",
    ),
    BaselineFidelity(
        "Te-LoRA-Eq6-Audit",
        "Te-LoRA literal Eq. (6) audit",
        "equation-fidelity negative control",
        False,
        "Alternates frozen A/B training and applies the published PAA Eq. (6) plus T2M2. The literal PAA cost is separable and therefore yields a feature-independent Sinkhorn coupling; the authors' public repository contains no executable code at the pinned revision.",
        "https://github.com/Lizhixuan121/Te-LoRA",
        "eb8aa50ff1d44eae43b584d82aefe476be91922b",
    ),
    BaselineFidelity(
        "FedSmoothLoRA",
        "FedSmoothLoRA",
        "same-protocol visual port of pinned source recurrence",
        True,
        "Implements gradient-aligned initialization, cosine-decayed round matching, full-update aggregation with rank-r SVD, and cumulative server merge under the shared visual protocol.",
        "https://github.com/wangzehao0704/FedSmoothLoRA",
        "41404dfa372b82e101660eb68979d383f63efc0d",
    ),
    BaselineFidelity(
        "FedSmoothLoRA-RankMatched",
        "FedSmoothLoRA (deployment-rank matched)",
        "internal resource-matched control",
        False,
        "Runs the identical official-equation recurrence and then projects its cumulative effective update to the common deployment rank; this separates cumulative full-rank capacity from optimization and aggregation effects.",
        "https://github.com/wangzehao0704/FedSmoothLoRA",
        "41404dfa372b82e101660eb68979d383f63efc0d",
    ),
    BaselineFidelity(
        "FedLEASE-OfficialPort",
        "FedLEASE visual recurrence port",
        "same-protocol visual port of pinned source recurrence",
        True,
        "Ports the released local warm-up, B-factor cosine and silhouette expert allocation, assigned-expert factor updates, 2K-1 adaptive top-K routing, and group-wise expert/router aggregation to the common visual protocol.",
        "https://github.com/lei-wang-link/FedLEASE",
        "3376b0f70dd1799b208e76e123f6e92bd9b945ca",
    ),
    BaselineFidelity(
        "FedALT-OfficialVisualPort",
        "FedALT visual recurrence port",
        "same-protocol visual port of pinned source recurrence",
        True,
        "Preserves the released persistent local LoRA, frozen receiver-specific Rest-of-World LoRA, input-level two-expert softmax router, and unweighted leave-one-client-out factor aggregation under the common visual protocol.",
        "https://github.com/jmbian/FedALT",
        "8be3dde2569cef47ecab2d7d931667606a921a47",
    ),
    BaselineFidelity(
        "Subspace-Reg-LoRA-Visual-Port",
        "Subspace-Reg-LoRA visual port",
        "same-protocol visual port of pinned source equations",
        True,
        "Retains the released full-update proximity, B-basis proximity, and factor regularizers, followed by full-update averaging and orthogonal-B SVD refactorization.",
        "https://github.com/sadia-sigma-lab/Subspace-Constrained-Federated-learning-with-Lora",
        "5951c298efa2b2fbc73cd2c9b93d6aa1e9ea3892",
    ),
    BaselineFidelity(
        "Dysco-FrozenFeature-Visual-Port",
        "Dysco frozen-feature visual port",
        "paper-equation same-protocol port",
        False,
        "Implements activation-nullspace SVD, leave-one-receiver-out projector merging, shared left-factor aggregation, and cumulative round-wise deployment. The linked repository was unavailable, and frozen visual features cannot express encoder representation drift.",
        "https://arxiv.org/abs/2607.14367",
    ),
    BaselineFidelity(
        "HiLoRA-Visual",
        "HiLoRA-compatible hierarchical visual baseline",
        "mechanism-matched budget-matched visual adaptation",
        False,
        "Splits the common rank budget across root, principal-angle cluster, and orthogonal leaf tiers. No official implementation was available for exact reproduction.",
        "https://arxiv.org/abs/2603.02785",
    ),
    BaselineFidelity(
        "FedTreeLoRA-Visual-Port",
        "FedTreeLoRA visual recurrence port",
        "same-protocol visual port of pinned source recurrence",
        True,
        "Specializes the released layer-wise B-factor hierarchy search and own-cluster/rest-of-clusters two-expert server recurrence to the common single-layer visual LoRA protocol.",
        "https://github.com/jmbian/FedTreeLoRA",
        "0586fea07f071e4358599e4ab664a250a7a0f2d9",
    ),
    BaselineFidelity(
        "SeFoRA-Literature-Only",
        "SeFoRA",
        "literature-only horizon coverage",
        False,
        "Studies heterogeneous-rank bilinear mismatch through update sketches on RoBERTa/GLUE. No executable source was linked at the protocol freeze, so no incompatible native-task accuracy is imported.",
        "https://arxiv.org/abs/2608.10144",
    ),
    BaselineFidelity(
        "FedGSA-Literature-Only",
        "FedGSA",
        "literature-only horizon coverage",
        False,
        "Studies differentially private projection-matrix aggregation on language tasks; it is cited for aggregation/privacy scope rather than treated as a visual receiver-admission execution.",
        "https://arxiv.org/abs/2608.03267",
    ),
    BaselineFidelity(
        "FraQ-Literature-Only",
        "FraQ",
        "literature-only horizon coverage",
        False,
        "Recompresses exact aggregates in coordinate space on text tasks. Its algebraic mechanism is discussed without importing native-task accuracy into the visual protocol.",
        "https://arxiv.org/abs/2608.03605",
    ),
    BaselineFidelity(
        "SDFLoRA-Literature-Only",
        "SDFLoRA",
        "literature-only horizon coverage",
        False,
        "Separates shared and private LoRA modules under rank and privacy heterogeneity. No verifiable executable repository was identified at the protocol freeze.",
    ),
    BaselineFidelity(
        "CLAIR-Literature-Only",
        "CLAIR",
        "literature-only horizon coverage",
        False,
        "Recovers a collaborative shared row space under low-rank plus block-sparse contamination. No verifiable executable repository was identified at the protocol freeze.",
    ),
    BaselineFidelity(
        "FedRot-LoRA",
        "FedRot-LoRA",
        "same-protocol visual port of pinned source recurrence",
        True,
        "Uses the previous global factors as reference, skips rotation in round one, alternates A/B alignment, and applies the paper's proper soft Procrustes rotation before factor averaging.",
        "https://github.com/haoran-zh/FedRot-LoRA",
        "36a67ef205818c292cf9ff361a80f969de16cedd",
    ),
    BaselineFidelity(
        "SCAFFOLD-LoRA",
        "Control-variate LoRA control",
        "mechanism control",
        False,
        "Tests control-variate drift correction in the common adapter protocol; it is not a line-by-line reproduction of the original SCAFFOLD optimizer.",
    ),
    BaselineFidelity(
        "pFedMe-LoRA",
        "Proximal-personalization control",
        "mechanism control",
        False,
        "Uses a personalized proximal LoRA branch; it does not reproduce the complete pFedMe inner-loop solver.",
    ),
    BaselineFidelity(
        "FedPer-LoRA",
        "Personal/shared LoRA anchor",
        "mechanism control",
        False,
        "Combines a shared LoRA update with a locally calibrated personal update; it is not the original FedPer network partition.",
    ),
    BaselineFidelity(
        "FedAMP-LoRA",
        "Affinity-weighted adapter control",
        "mechanism control",
        False,
        "Uses a receiver-specific adapter-distance kernel; it does not reproduce the complete iterative FedAMP objective.",
    ),
    BaselineFidelity(
        "FedProto-LoRA",
        "Prototype-kernel adapter control",
        "mechanism control",
        False,
        "Aggregates adapters with a prototype-geometry kernel and is used only to isolate prototype conditioning.",
    ),
    BaselineFidelity(
        "Clustered-LoRA",
        "K-medoids clustered-adapter control",
        "mechanism control",
        False,
        "Clusters trained adapters in a fixed distance space and averages within clusters; it is not a reproduction of a specific clustered-FL package.",
    ),
    BaselineFidelity(
        "FedGeo-Agg",
        "Geo-only adapter aggregation",
        "internal geometry control",
        False,
        "Uses the same geometry provider without the proposed adapter-subspace admissibility test.",
    ),
)


def fidelity_by_run_key() -> dict[str, BaselineFidelity]:
    return {item.run_key: item for item in BASELINE_FIDELITY}
