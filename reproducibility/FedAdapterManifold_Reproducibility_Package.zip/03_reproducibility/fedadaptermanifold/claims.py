from __future__ import annotations

from typing import Any


PRIMARY_METHOD_CANDIDATES = (
    "FedAdapterManifold-Admit",
    "FedAdapterManifold-Selective",
    "FedAdapterManifold",
)


MULTISEED_CLAIM_SPECS = [
    {
        "claim_id": "adapter_incompatibility_failure_correlation",
        "claim_tier": "core",
        "test": "distance_receiver_residual_failure_correlation",
        "fallback_test": "distance_failure_correlation",
        "method": "",
        "baseline": "",
        "measure": "d_adapter_incompatibility",
        "interpretation": "Dynamically calibrated adapter incompatibility correlates with receiver-normalized FedAvg-LoRA aggregation failure.",
    },
    {
        "claim_id": "raw_adapter_incompatibility_directional_failure_correlation",
        "claim_tier": "secondary_caveat",
        "test": "distance_failure_correlation",
        "method": "",
        "baseline": "",
        "measure": "d_adapter_incompatibility",
        "interpretation": "Raw directional aggregation failure is reported as a caveat because receiver-client difficulty can confound symmetric adapter distances.",
    },
    {
        "claim_id": "raw_subspace_failure_correlation",
        "claim_tier": "secondary_caveat",
        "test": "distance_failure_correlation",
        "method": "",
        "baseline": "",
        "measure": "d_sub",
        "interpretation": "Raw Grassmannian subspace distance is reported as a proxy caveat, not as the sole failure mechanism.",
    },
    {
        "claim_id": "geometry_failure_correlation",
        "claim_tier": "supporting",
        "test": "distance_receiver_residual_failure_correlation",
        "fallback_test": "distance_failure_correlation",
        "method": "",
        "baseline": "",
        "measure": "d_geo",
        "interpretation": "FedGeo visual geometry is reported as a complementary conditioning signal for receiver-normalized failure; raw standalone correlation may be dataset-dependent.",
    },
    {
        "claim_id": "adapter_bank_gain_vs_fedavg",
        "claim_tier": "core",
        "test": "paired_accuracy_gain",
        "method": "FedAdapterManifold",
        "baseline": "FedAvg-LoRA",
        "measure": "mean_accuracy_gain",
        "interpretation": "Geometry-conditioned adapter mixing improves over single global LoRA averaging.",
    },
    {
        "claim_id": "adapter_bank_gain_vs_fedgeo_agg",
        "claim_tier": "core",
        "test": "paired_accuracy_gain",
        "method": "FedAdapterManifold",
        "baseline": "FedGeo-Agg",
        "measure": "mean_accuracy_gain",
        "interpretation": "Adapter manifold routing adds value beyond geometry-only aggregation.",
    },
    {
        "claim_id": "update_conflict_reduction_vs_fedavg",
        "claim_tier": "core",
        "test": "paired_risk_reduction",
        "method": "FedAdapterManifold",
        "baseline": "FedAvg-LoRA",
        "measure": "mean_update_conflict_vs_local",
        "interpretation": "Geometry-conditioned adapter routing lowers update conflict relative to single global LoRA averaging.",
    },
    {
        "claim_id": "worst_client_risk_reduction_vs_fedgeo_agg",
        "claim_tier": "supporting",
        "test": "paired_risk_reduction",
        "method": "FedAdapterManifold",
        "baseline": "FedGeo-Agg",
        "measure": "worst_client_risk",
        "interpretation": "Adapter bank routing reduces worst-client risk against the geometry-only baseline.",
    },
    {
        "claim_id": "update_conflict_reduction_vs_fedgeo_agg",
        "claim_tier": "secondary_caveat",
        "test": "paired_risk_reduction",
        "method": "FedAdapterManifold",
        "baseline": "FedGeo-Agg",
        "measure": "mean_update_conflict_vs_local",
        "interpretation": "Conflict versus FedGeo-Agg is reported as a saturation/no-regret diagnostic because geometry-only aggregation can already be a conservative conflict controller.",
    },
    {
        "claim_id": "client_drift_reduction_vs_fedavg",
        "claim_tier": "supporting",
        "test": "paired_risk_reduction",
        "method": "FedAdapterManifold",
        "baseline": "FedAvg-LoRA",
        "measure": "mean_client_drift_vs_local",
        "interpretation": "Client-specific adapter routing reduces drift relative to global LoRA averaging.",
    },
    {
        "claim_id": "client_drift_reduction_vs_fedgeo_agg",
        "claim_tier": "secondary_caveat",
        "test": "paired_risk_reduction",
        "method": "FedAdapterManifold",
        "baseline": "FedGeo-Agg",
        "measure": "mean_client_drift_vs_local",
        "interpretation": "Drift versus FedGeo-Agg is useful to report, but not required for the main theory.",
    },
    {
        "claim_id": "graph_neighbor_conflict_reduction_vs_fedgeo_agg",
        "claim_tier": "secondary_caveat",
        "test": "paired_risk_reduction",
        "method": "FedAdapterManifold",
        "baseline": "FedGeo-Agg",
        "measure": "mean_graph_neighbor_update_conflict",
        "interpretation": "Graph-neighbor conflict is a locality tradeoff diagnostic, not a core contribution claim.",
    },
]


def build_multiseed_claim_report(summary_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = [_claim_row_from_summary(summary_rows, spec) for spec in MULTISEED_CLAIM_SPECS]
    rows.insert(0, _overall_row(rows))
    return rows


def build_single_run_claim_report(
    metrics_rows: list[dict[str, Any]],
    risk_rows: list[dict[str, Any]],
    idea_support_rows: list[dict[str, Any]],
    statistical_rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    rows = [
        _single_distance_claim(statistical_rows, "d_adapter_incompatibility", "adapter_incompatibility_failure_correlation", "core"),
        _single_distance_claim(
            statistical_rows,
            "d_adapter_incompatibility",
            "raw_adapter_incompatibility_directional_failure_correlation",
            "secondary_caveat",
        ),
        _single_distance_claim(statistical_rows, "d_sub", "raw_subspace_failure_correlation", "secondary_caveat"),
        _single_distance_claim(statistical_rows, "d_geo", "geometry_failure_correlation", "supporting"),
        _single_gain_claim(idea_support_rows, "adapter_bank_minus_fedavg_lora", "adapter_bank_gain_vs_fedavg", "FedAvg-LoRA", "core"),
        _single_gain_claim(idea_support_rows, "adapter_bank_minus_fedgeo_agg", "adapter_bank_gain_vs_fedgeo_agg", "FedGeo-Agg", "core"),
        _single_risk_claim(risk_rows, "mean_update_conflict_vs_local", "update_conflict_reduction_vs_fedavg", "FedAvg-LoRA", "core"),
        _single_risk_claim(risk_rows, "worst_client_risk", "worst_client_risk_reduction_vs_fedgeo_agg", "FedGeo-Agg", "supporting"),
        _single_risk_claim(
            risk_rows,
            "mean_update_conflict_vs_local",
            "update_conflict_reduction_vs_fedgeo_agg",
            "FedGeo-Agg",
            "secondary_caveat",
        ),
        _single_risk_claim(risk_rows, "mean_client_drift_vs_local", "client_drift_reduction_vs_fedavg", "FedAvg-LoRA", "supporting"),
        _single_risk_claim(risk_rows, "mean_client_drift_vs_local", "client_drift_reduction_vs_fedgeo_agg", "FedGeo-Agg", "secondary_caveat"),
        _single_risk_claim(
            risk_rows,
            "mean_graph_neighbor_update_conflict",
            "graph_neighbor_conflict_reduction_vs_fedgeo_agg",
            "FedGeo-Agg",
            "secondary_caveat",
        ),
    ]
    _fill_interpretations(rows)
    rows.insert(0, _overall_row(rows))
    return rows


def core_claims_supported(rows: list[dict[str, Any]]) -> bool:
    core = [row for row in rows if row.get("claim_tier") == "core"]
    return bool(core) and all(_truthy(row.get("supports")) for row in core)


def _claim_row_from_summary(summary_rows: list[dict[str, Any]], spec: dict[str, Any]) -> dict[str, Any]:
    match = _find_summary(summary_rows, spec)
    if spec.get("fallback_test"):
        fallback = _find_summary(summary_rows, {**spec, "test": spec["fallback_test"]})
        if match is None or (fallback is not None and not _truthy(match.get("supports")) and _truthy(fallback.get("supports"))):
            match = fallback
    row = _base_row(spec)
    if match is None:
        row.update({"observed": False, "supports": False, "narrative_action": "missing_evidence"})
        return row
    row.update(
        {
            "observed": True,
            "test": match.get("test", row.get("test", "")),
            "method": match.get("method", row.get("method", "")),
            "baseline": match.get("baseline", row.get("baseline", "")),
            "measure": match.get("measure", row.get("measure", "")),
            "estimate": match.get("estimate", ""),
            "ci_low": match.get("ci_low", ""),
            "ci_high": match.get("ci_high", ""),
            "num_observations": match.get("num_observations", ""),
            "supports": _truthy(match.get("supports")),
            "narrative_action": _narrative_action(spec["claim_tier"], _truthy(match.get("supports"))),
        }
    )
    return row


def _single_distance_claim(statistical_rows, measure: str, claim_id: str, tier: str) -> dict[str, Any]:
    spec = _spec_by_id(claim_id)
    row = _base_row({**spec, "claim_tier": tier})
    match = _find_summary(
        statistical_rows,
        {"test": spec.get("test", "distance_failure_correlation"), "method": "", "baseline": "", "measure": measure},
    )
    if spec.get("fallback_test"):
        fallback = _find_summary(
            statistical_rows,
            {"test": spec["fallback_test"], "method": "", "baseline": "", "measure": measure},
        )
        if match is None or (fallback is not None and not _truthy(match.get("supports")) and _truthy(fallback.get("supports"))):
            match = fallback
    if match is None:
        row.update({"observed": False, "supports": False, "narrative_action": "missing_evidence"})
        return row
    row.update(
        {
            "observed": True,
            "test": match.get("test", row.get("test", "")),
            "method": match.get("method", row.get("method", "")),
            "baseline": match.get("baseline", row.get("baseline", "")),
            "measure": match.get("measure", row.get("measure", "")),
            "estimate": match.get("estimate", ""),
            "ci_low": match.get("ci_low", ""),
            "ci_high": match.get("ci_high", ""),
            "supports": _truthy(match.get("supports")),
            "narrative_action": _narrative_action(tier, _truthy(match.get("supports"))),
        }
    )
    return row


def _single_gain_claim(idea_rows, field: str, claim_id: str, baseline: str, tier: str) -> dict[str, Any]:
    spec = _spec_by_id(claim_id)
    row = _base_row({**spec, "claim_tier": tier, "baseline": baseline})
    idea = idea_rows[0] if idea_rows else {}
    if field not in idea or idea.get(field, "") == "":
        row.update({"observed": False, "supports": False, "narrative_action": "missing_evidence"})
        return row
    estimate = _float(idea.get(field))
    supports = estimate > 0
    row.update(
        {
            "observed": True,
            "method": idea.get("primary_adapter_method", row.get("method", "")),
            "estimate": estimate,
            "supports": supports,
            "narrative_action": _narrative_action(tier, supports),
        }
    )
    return row


def _single_risk_claim(risk_rows, measure: str, claim_id: str, baseline: str, tier: str) -> dict[str, Any]:
    spec = _spec_by_id(claim_id)
    row = _base_row({**spec, "claim_tier": tier, "baseline": baseline, "measure": measure})
    by_method = {risk.get("method"): risk for risk in risk_rows}
    method_name, method_row = _primary_method_row(by_method)
    baseline_row = by_method.get(baseline)
    if method_row is None or baseline_row is None:
        row.update({"observed": False, "supports": False, "narrative_action": "missing_evidence"})
        return row
    method_value = method_row.get(measure, "")
    baseline_value = baseline_row.get(measure, "")
    if method_value == "" or baseline_value == "":
        row.update({"observed": False, "supports": False, "narrative_action": "missing_evidence"})
        return row
    estimate = _float(baseline_value) - _float(method_value)
    supports = estimate > 0
    row.update(
        {
            "observed": True,
            "method": method_name,
            "estimate": estimate,
            "supports": supports,
            "narrative_action": _narrative_action(tier, supports),
        }
    )
    return row


def _overall_row(rows: list[dict[str, Any]]) -> dict[str, Any]:
    supported = core_claims_supported(rows)
    weak = [row["claim_id"] for row in rows if row.get("claim_tier") != "core" and not _truthy(row.get("supports"))]
    return {
        "claim_id": "overall_core_support",
        "claim_tier": "overall",
        "affects_main_theory": True,
        "observed": True,
        "supports": supported,
        "narrative_action": "proceed" if supported else "stop_or_revise_core_claims",
        "interpretation": "Core FedAdapterManifold claims are supported." if supported else "One or more core claims need revision.",
        "secondary_caveats": ";".join(weak),
    }


def _base_row(spec: dict[str, Any]) -> dict[str, Any]:
    tier = spec.get("claim_tier", "")
    return {
        "claim_id": spec.get("claim_id", ""),
        "claim_tier": tier,
        "affects_main_theory": tier == "core",
        "test": spec.get("test", ""),
        "method": spec.get("method", "FedAdapterManifold"),
        "baseline": spec.get("baseline", ""),
        "measure": spec.get("measure", ""),
        "estimate": "",
        "ci_low": "",
        "ci_high": "",
        "num_observations": "",
        "observed": "",
        "supports": "",
        "narrative_action": "",
        "interpretation": spec.get("interpretation", ""),
    }


def _find_summary(rows: list[dict[str, Any]], spec: dict[str, Any]) -> dict[str, Any] | None:
    method_candidates = _method_candidates(spec)
    search_methods = method_candidates or ("",)
    for method in search_methods:
        match = _find_summary_for_method(rows, spec, method if method_candidates else "")
        if match is not None:
            return match
    return None


def _find_summary_for_method(rows: list[dict[str, Any]], spec: dict[str, Any], method: str) -> dict[str, Any] | None:
    for row in rows:
        if row.get("test", "") != spec.get("test", ""):
            continue
        if row.get("measure", "") != spec.get("measure", ""):
            continue
        if method and row.get("method", "") != method:
            continue
        if spec.get("baseline", "") and row.get("baseline", "") != spec.get("baseline", ""):
            continue
        return row
    return None


def _method_candidates(spec: dict[str, Any]) -> tuple[str, ...]:
    method = spec.get("method", "")
    if not method:
        return ()
    if method == "FedAdapterManifold":
        return PRIMARY_METHOD_CANDIDATES
    return (method,)


def _primary_method_row(by_method: dict[str, dict[str, Any]]) -> tuple[str, dict[str, Any] | None]:
    for method in PRIMARY_METHOD_CANDIDATES:
        row = by_method.get(method)
        if row is not None:
            return method, row
    return "FedAdapterManifold", None


def _spec_by_id(claim_id: str) -> dict[str, Any]:
    for spec in MULTISEED_CLAIM_SPECS:
        if spec["claim_id"] == claim_id:
            return spec
    raise KeyError(claim_id)


def _fill_interpretations(rows: list[dict[str, Any]]) -> None:
    by_id = {spec["claim_id"]: spec for spec in MULTISEED_CLAIM_SPECS}
    for row in rows:
        spec = by_id.get(row.get("claim_id", ""))
        if spec is not None:
            row["interpretation"] = spec["interpretation"]


def _narrative_action(tier: str, supports: bool) -> str:
    if supports:
        return "claim_as_supported"
    if tier == "core":
        return "revise_or_rerun_core_claim"
    if tier == "supporting":
        return "report_as_mixed_support"
    return "report_as_caveat"


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() == "true"


def _float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")
