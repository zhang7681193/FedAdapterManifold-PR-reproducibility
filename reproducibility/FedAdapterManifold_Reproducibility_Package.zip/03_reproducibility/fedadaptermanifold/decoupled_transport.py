from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import math
from types import SimpleNamespace

import numpy as np

from .adapters import LoRAAdapter
from .training import (
    cross_entropy_per_sample,
    cross_entropy_and_grad,
    evaluate_adapter,
    evaluate_adapter_error_vector,
    evaluate_adapter_loss_vector,
    predict_with_weight,
    softmax,
)


Array = np.ndarray


@dataclass(frozen=True)
class ReceiverActionBlocks:
    """Orthogonal donor blocks induced by one receiver's LoRA action spaces."""

    core: Array
    column_only: Array
    row_only: Array
    normal: Array

    @property
    def tangent(self) -> Array:
        return self.core + self.column_only + self.row_only

    @property
    def column_anchored(self) -> Array:
        """Keep the receiver output/column space while expanding row action."""

        return self.core + self.column_only

    @property
    def row_anchored(self) -> Array:
        """Keep the receiver input/row space while expanding column action."""

        return self.core + self.row_only

    @property
    def reconstructed(self) -> Array:
        return self.tangent + self.normal


@dataclass
class JointPathAdmissionResult:
    client_adapters: list[LoRAAdapter]
    per_client_metrics: list[dict]
    admission_rows: list[dict]


@dataclass
class RoutedAdmissionResult:
    per_client_metrics: list[dict]
    admission_rows: list[dict]
    routing_rows: list[dict]


def zero_discordance_required_sample_size(
    risk_tolerance: float,
    delta: float,
    num_comparisons: int = 1,
) -> int | float:
    """Minimum sample size for a zero-discordance exact certificate.

    The paired certificate splits its corrected error probability between the
    discordance-mass and conditional-harm components.  With no observed
    discordance, the Clopper--Pearson upper bound is
    ``1 - alpha**(1/n)``.  This helper exposes when a requested deployment
    tolerance is statistically unresolvable instead of labeling every such
    case as semantic incompatibility.
    """

    tolerance = float(risk_tolerance)
    if tolerance == 0.0:
        return math.inf
    if not 0.0 < tolerance < 1.0:
        raise ValueError("risk_tolerance must lie between zero (inclusive) and one")
    adjusted = float(np.clip(delta / max(int(num_comparisons), 1), 1e-12, 1.0))
    alpha = adjusted / 2.0
    return int(math.ceil(math.log(alpha) / math.log1p(-tolerance)))


def select_fixed_intrinsic_candidate_pool(
    selector_clients: list,
    eval_clients: list,
    base_weight: Array,
    anchor_adapters: list[LoRAAdapter],
    candidate_families: dict[str, list[LoRAAdapter]],
    candidate_priority: tuple[str, ...] | None = None,
    tie_tolerance: float = 1e-3,
    delta: float = 0.05,
    diagnostic_risk_tolerance: float = 0.02,
    seed: int = 0,
    dataset: str = "",
    heterogeneity_setting: str = "",
    round_id: int = 0,
    method: str = "FedAdapterManifold-ReceiverRelativeGate",
    selection_policy: str = "log_loss",
) -> JointPathAdmissionResult:
    """Select one training-fixed intrinsic candidate on held-out calibration.

    The pool contains the local anchor plus intrinsic candidates supplied by
    the caller; external personalized baselines are not accepted.  Candidate
    construction must finish before this routine is called.  The calibration
    split is used once with an anchor-first fixed priority.  ``log_loss``
    minimizes proper log loss inside ``tie_tolerance``.  ``pareto`` admits an
    external candidate only when it strictly improves log loss while neither
    empirical classification error nor bounded Brier risk increases.  Test
    labels are evaluated only after the choice is frozen.

    For a pool of size ``K`` and cross entropy bounded by the implementation's
    probability floor, the logged finite-class slack gives the standard
    oracle inequality ``R(h_hat) <= min_h R(h) + slack``.  This is deliberately
    distinct from the stricter zero-slack paired 0--1 certificate.
    """

    n = len(selector_clients)
    if len(eval_clients) != n or len(anchor_adapters) != n:
        raise ValueError("selector, evaluation, and anchor lists must align")
    if not candidate_families:
        raise ValueError("At least one intrinsic candidate family is required")
    if selection_policy not in {"log_loss", "pareto", "target_pareto"}:
        raise ValueError(
            "selection_policy must be 'log_loss', 'pareto', or 'target_pareto'"
        )
    for family, adapters in candidate_families.items():
        if family == "local_anchor":
            raise ValueError("local_anchor is reserved by the selector")
        if len(adapters) != n:
            raise ValueError(f"Candidate family {family!r} does not align with clients")

    family_order = ["local_anchor", *candidate_families.keys()]
    if candidate_priority is None:
        priority = family_order
    else:
        priority = list(candidate_priority)
        missing = [family for family in family_order if family not in priority]
        priority.extend(missing)
    priority_index = {family: index for index, family in enumerate(priority)}
    pool_size = len(family_order)
    loss_cap = float(-math.log(1e-12))

    selected_adapters: list[LoRAAdapter] = []
    metrics_rows: list[dict] = []
    admission_rows: list[dict] = []
    for client_index, (selector, evaluator, anchor) in enumerate(
        zip(selector_clients, eval_clients, anchor_adapters)
    ):
        candidates = {"local_anchor": anchor}
        candidates.update(
            {family: adapters[client_index] for family, adapters in candidate_families.items()}
        )
        records: list[tuple[dict, LoRAAdapter]] = []
        for family in family_order:
            adapter = candidates[family]
            logits = predict_with_weight(selector.x_train, adapter.weight(base_weight))
            losses = cross_entropy_per_sample(logits, selector.y_train.astype(np.int64))
            errors = (
                logits.argmax(axis=1) != selector.y_train.astype(np.int64)
            ).astype(np.float64)
            probabilities = softmax(logits)
            targets = np.zeros_like(probabilities)
            targets[np.arange(selector.y_train.size), selector.y_train.astype(np.int64)] = 1.0
            brier = np.sum((probabilities - targets) ** 2, axis=1)
            records.append(
                (
                    {
                        "candidate_family": family,
                        "calibration_log_loss": float(np.mean(losses)),
                        "calibration_error": float(np.mean(errors)),
                        "calibration_brier": float(np.mean(brier)),
                    },
                    adapter,
                )
            )

        anchor_record = records[0][0]
        for record, _ in records:
            record["log_loss_gain_vs_anchor"] = float(
                anchor_record["calibration_log_loss"] - record["calibration_log_loss"]
            )
            record["error_difference_vs_anchor"] = float(
                record["calibration_error"] - anchor_record["calibration_error"]
            )
            record["brier_difference_vs_anchor"] = float(
                record["calibration_brier"] - anchor_record["calibration_brier"]
            )
            record["pareto_admissible"] = bool(
                record["candidate_family"] == "local_anchor"
                or (
                    record["log_loss_gain_vs_anchor"] > float(tie_tolerance) + 1e-12
                    and record["error_difference_vs_anchor"] <= 1e-12
                    and record["brier_difference_vs_anchor"] <= 1e-12
                )
            )
            record["target_pareto_admissible"] = bool(
                record["candidate_family"] == "local_anchor"
                or (
                    record["log_loss_gain_vs_anchor"] > float(tie_tolerance) + 1e-12
                    and record["error_difference_vs_anchor"] < -1e-12
                    and record["brier_difference_vs_anchor"] <= 1e-12
                )
            )

        eligible_indices = list(range(len(records)))
        if selection_policy == "pareto":
            eligible_indices = [
                index
                for index, (record, _) in enumerate(records)
                if bool(record["pareto_admissible"])
            ]
        elif selection_policy == "target_pareto":
            eligible_indices = [
                index
                for index, (record, _) in enumerate(records)
                if bool(record["target_pareto_admissible"])
            ]
        best_loss = min(
            float(records[index][0]["calibration_log_loss"])
            for index in eligible_indices
        )
        near_best = [
            index
            for index in eligible_indices
            if float(records[index][0]["calibration_log_loss"])
            <= best_loss + float(tie_tolerance) + 1e-12
        ]
        selected_index = min(
            near_best,
            key=lambda index: priority_index[str(records[index][0]["candidate_family"])],
        )
        selected_record, selected_adapter = records[selected_index]
        selected_adapters.append(selected_adapter.copy(name=f"{method}-client-{client_index}"))
        test_metrics = evaluate_adapter(
            evaluator.x_test,
            evaluator.y_test,
            base_weight,
            selected_adapter,
        )
        calibration_size = int(selector.y_train.size)
        epsilon = loss_cap * math.sqrt(
            math.log(2.0 * pool_size / max(float(delta), 1e-12))
            / max(2.0 * calibration_size, 1.0)
        )
        oracle_slack = 2.0 * epsilon + float(tie_tolerance)
        required_n = zero_discordance_required_sample_size(
            diagnostic_risk_tolerance,
            delta,
            num_comparisons=pool_size - 1,
        )
        candidate_test_metrics = {
            family: evaluate_adapter(
                evaluator.x_test,
                evaluator.y_test,
                base_weight,
                adapter,
            )
            for family, adapter in candidates.items()
        }
        metrics_rows.append(
            {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": evaluator.client_id,
                "domain": evaluator.domain,
                "accuracy": float(test_metrics["accuracy"]),
                "loss": float(test_metrics["loss"]),
                "rank": int(selected_adapter.rank),
                "selected_transport_family": str(selected_record["candidate_family"]),
                "selection_policy": selection_policy,
                "calibration_pool_size": int(pool_size),
                "calibration_oracle_slack": float(oracle_slack),
                "test_used_for_selection": False,
            }
        )
        for record_index, (record, adapter) in enumerate(records):
            admission_rows.append(
                {
                    "method": method,
                    "seed": int(seed),
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": int(round_id),
                    "client_id": evaluator.client_id,
                    "domain": evaluator.domain,
                    "selection_split": "heldout_calibration",
                    "candidate_pool_fixed_pretest": True,
                    "test_used_for_selection": False,
                    "candidate_pool_size": int(pool_size),
                    "candidate_priority": ",".join(priority),
                    "selection_policy": selection_policy,
                    "tie_tolerance": float(tie_tolerance),
                    "calibration_size": calibration_size,
                    "finite_class_oracle_slack": float(oracle_slack),
                    "diagnostic_risk_tolerance": float(diagnostic_risk_tolerance),
                    "zero_discordance_required_n": (
                        int(required_n) if math.isfinite(required_n) else "inf"
                    ),
                    "zero_discordance_power_sufficient": bool(
                        math.isfinite(required_n) and calibration_size >= required_n
                    ),
                    "candidate_rank": int(adapter.rank),
                    **record,
                    "candidate_test_accuracy_audit": float(
                        candidate_test_metrics[str(record["candidate_family"])]["accuracy"]
                    ),
                    "candidate_test_loss_audit": float(
                        candidate_test_metrics[str(record["candidate_family"])]["loss"]
                    ),
                    "selected": bool(record_index == selected_index),
                }
            )
    return JointPathAdmissionResult(selected_adapters, metrics_rows, admission_rows)


def receiver_action_blocks(receiver: LoRAAdapter, donor_delta: Array) -> ReceiverActionBlocks:
    """Split a donor update into four Frobenius-orthogonal receiver blocks.

    The first three blocks form the tangent-space projection at the receiver's
    rank-r row/column subspaces.  The final block is normal to that tangent
    space and is the semantic component that algebraic gauge alignment or
    exact-update lifting cannot remove.
    """

    donor = np.asarray(donor_delta, dtype=np.float64)
    if donor.shape != receiver.delta().shape:
        raise ValueError(f"Donor shape {donor.shape} does not match receiver shape {receiver.delta().shape}")
    u = _orthonormal_basis(receiver.B)
    v = _orthonormal_basis(receiver.A.T)
    p = u @ u.T
    q = v @ v.T
    identity_out = np.eye(receiver.output_dim, dtype=np.float64)
    identity_in = np.eye(receiver.input_dim, dtype=np.float64)
    core = p @ donor @ q
    column_only = p @ donor @ (identity_in - q)
    row_only = (identity_out - p) @ donor @ q
    normal = (identity_out - p) @ donor @ (identity_in - q)
    return ReceiverActionBlocks(core, column_only, row_only, normal)


def receiver_action_energy_summary(receiver: LoRAAdapter, donor_delta: Array) -> dict[str, float | int]:
    """Return the observable energy decomposition induced by one receiver.

    Squared Frobenius energies add exactly because the four action blocks are
    orthogonal.  The ratios therefore distinguish capacity in the receiver's
    current bilinear action space, first-order transport directions, and the
    normal component that requires a genuinely new semantic action direction.
    """

    blocks = receiver_action_blocks(receiver, donor_delta)
    energies = {
        "core_energy": float(np.linalg.norm(blocks.core, ord="fro") ** 2),
        "column_only_energy": float(np.linalg.norm(blocks.column_only, ord="fro") ** 2),
        "row_only_energy": float(np.linalg.norm(blocks.row_only, ord="fro") ** 2),
        "normal_energy": float(np.linalg.norm(blocks.normal, ord="fro") ** 2),
    }
    total = float(sum(energies.values()))
    tangent = float(total - energies["normal_energy"])
    core = float(energies["core_energy"])
    scale = max(total, np.finfo(np.float64).tiny)
    return {
        **energies,
        "tangent_energy": tangent,
        "total_energy": total,
        "core_energy_ratio": core / scale,
        "tangent_energy_ratio": tangent / scale,
        "normal_energy_ratio": float(energies["normal_energy"]) / scale,
        "receiver_rank": int(receiver.rank),
        "donor_matrix_rank": int(np.linalg.matrix_rank(np.asarray(donor_delta, dtype=np.float64))),
    }


def local_quadratic_action_risk(
    x: Array,
    y: Array,
    anchor_weight: Array,
    action_delta: Array,
) -> dict[str, float]:
    """Second-order receiver risk for admitting one parameter-space action.

    For multinomial cross entropy and a frozen feature map, the directional
    curvature can be computed exactly without materializing the full Hessian.
    The returned surrogate is the second-order Taylor term around the
    receiver's current anchor. A cubic logit-magnitude proxy is logged so the
    approximation regime can be audited rather than silently assumed.
    """

    features = np.asarray(x, dtype=np.float64)
    labels = np.asarray(y, dtype=np.int64)
    anchor = np.asarray(anchor_weight, dtype=np.float64)
    action = np.asarray(action_delta, dtype=np.float64)
    if features.ndim != 2 or labels.ndim != 1 or features.shape[0] != labels.shape[0]:
        raise ValueError("x and y must be aligned feature and label arrays")
    if action.shape != anchor.shape or features.shape[1] != anchor.shape[1]:
        raise ValueError("anchor/action dimensions do not match the feature matrix")

    logits = predict_with_weight(features, anchor)
    probabilities = softmax(logits)
    directions = predict_with_weight(features, action)
    residual = probabilities.copy()
    residual[np.arange(labels.size), labels] -= 1.0
    first_order = float(np.mean(np.sum(residual * directions, axis=1)))
    expected_direction = np.sum(probabilities * directions, axis=1)
    directional_variance = np.sum(probabilities * directions * directions, axis=1) - expected_direction**2
    curvature = float(np.mean(np.maximum(directional_variance, 0.0)))
    centered_direction = directions - expected_direction[:, None]
    cubic_proxy = float(np.mean(np.sum(probabilities * np.abs(centered_direction) ** 3, axis=1)) / 6.0)
    return {
        "first_order": first_order,
        "curvature": curvature,
        "quadratic_risk": first_order + 0.5 * curvature,
        "cubic_remainder_proxy": cubic_proxy,
    }


def build_curvature_semantic_candidates(
    training_clients: list,
    base_weight: Array,
    receivers: list[LoRAAdapter],
    donor_cumulative_deltas: list[Array],
    algebraic_residual: Array,
    prior_weights: Array,
    graph: Array,
    d_geo: Array,
    label_distance: Array,
    tau: float = 1.0,
    lambda_subspace: float = 1.0,
    lambda_geo: float = 0.5,
    lambda_label: float = 0.25,
    lambda_risk: float = 1.0,
    self_weight: float = 1.0,
    top_k_neighbors: int = 0,
    correction_scale: float = 0.25,
    optimize_joint_mixture: bool = True,
    mixture_kl_strength: float = 0.05,
    mixture_max_iterations: int = 250,
    mixture_clients: list | None = None,
    semantic_anchor_deltas: list[Array] | None = None,
    target_ranks: list[int] | int | None = None,
    name_prefix: str = "FedAdapterManifold-CurvatureSemantic",
) -> tuple[list[LoRAAdapter], list[dict]]:
    """Build intrinsic receiver-conditioned semantic endpoints.

    Geometry proposes graph-supported donors. Grassmann normal energy measures
    whether a donor introduces a new bilinear action direction, while the
    receiver's local quadratic risk predicts whether that direction is useful
    or harmful. These signals remain separate in the audit rows and are only
    combined in the transparent Gibbs objective.
    """

    n = len(receivers)
    if len(training_clients) != n or len(donor_cumulative_deltas) != n:
        raise ValueError("training clients, receivers, and cumulative donor streams must align")
    mixture_views = training_clients if mixture_clients is None else mixture_clients
    if len(mixture_views) != n:
        raise ValueError("mixture_clients must align with receivers")
    matrices = {
        "graph": np.asarray(graph, dtype=np.float64),
        "d_geo": np.asarray(d_geo, dtype=np.float64),
        "d_label": np.asarray(label_distance, dtype=np.float64),
    }
    for name, matrix in matrices.items():
        if matrix.shape != (n, n):
            raise ValueError(f"{name} shape {matrix.shape} does not match {(n, n)}")
    base = np.asarray(base_weight, dtype=np.float64)
    residual = np.asarray(algebraic_residual, dtype=np.float64)
    if residual.shape != base.shape:
        raise ValueError("algebraic_residual shape does not match base_weight")
    donor_streams = [np.asarray(delta, dtype=np.float64) for delta in donor_cumulative_deltas]
    if any(delta.shape != base.shape for delta in donor_streams):
        raise ValueError("Every cumulative donor stream must match base_weight")
    prior = np.asarray(prior_weights, dtype=np.float64)
    if prior.shape != (n,) or np.any(prior < 0.0) or float(prior.sum()) <= 0.0:
        raise ValueError("prior_weights must be a nonnegative vector with positive mass")
    prior /= prior.sum()
    prior_center_stream = sum(float(weight) * stream for weight, stream in zip(prior, donor_streams))
    center_delta = residual + prior_center_stream
    if semantic_anchor_deltas is None:
        semantic_anchors = [center_delta for _ in range(n)]
        anchor_mode = "cumulative_center"
    else:
        if len(semantic_anchor_deltas) != n:
            raise ValueError("semantic_anchor_deltas must align with receivers")
        semantic_anchors = [np.asarray(delta, dtype=np.float64) for delta in semantic_anchor_deltas]
        if any(delta.shape != base.shape for delta in semantic_anchors):
            raise ValueError("Every semantic anchor delta must match base_weight")
        anchor_mode = "receiver_local"
    if target_ranks is None:
        ranks = [int(min(base.shape))] * n
    elif isinstance(target_ranks, int):
        ranks = [int(target_ranks)] * n
    else:
        ranks = [int(value) for value in target_ranks]
    if len(ranks) != n or any(rank <= 0 for rank in ranks):
        raise ValueError("target_ranks must provide one positive rank per receiver")

    scale = float(np.clip(correction_scale, 0.0, 1.0))
    normal_cost = np.zeros((n, n), dtype=np.float64)
    quadratic_cost = np.zeros((n, n), dtype=np.float64)
    first_order = np.zeros((n, n), dtype=np.float64)
    curvature = np.zeros((n, n), dtype=np.float64)
    cubic_proxy = np.zeros((n, n), dtype=np.float64)
    donor_rank = np.zeros((n, n), dtype=np.int64)
    for receiver_index, (client, receiver) in enumerate(zip(training_clients, receivers)):
        anchor_weight = base + semantic_anchors[receiver_index]
        action_reference = (
            semantic_anchors[receiver_index]
            if anchor_mode == "receiver_local"
            else prior_center_stream
        )
        for donor_index, donor_stream in enumerate(donor_streams):
            action = donor_stream - action_reference
            energy = receiver_action_energy_summary(receiver, action)
            risk = local_quadratic_action_risk(
                client.x_train,
                client.y_train,
                anchor_weight,
                scale * action,
            )
            normal_cost[receiver_index, donor_index] = float(energy["normal_energy_ratio"])
            quadratic_cost[receiver_index, donor_index] = float(risk["quadratic_risk"])
            first_order[receiver_index, donor_index] = float(risk["first_order"])
            curvature[receiver_index, donor_index] = float(risk["curvature"])
            cubic_proxy[receiver_index, donor_index] = float(risk["cubic_remainder_proxy"])
            donor_rank[receiver_index, donor_index] = int(energy["donor_matrix_rank"])

    normalized_subspace = _row_minmax(normal_cost)
    normalized_geo = _row_minmax(matrices["d_geo"])
    normalized_label = _row_minmax(matrices["d_label"])
    normalized_risk = _row_minmax(quadratic_cost)
    total_cost = (
        max(float(lambda_subspace), 0.0) * normalized_subspace
        + max(float(lambda_geo), 0.0) * normalized_geo
        + max(float(lambda_label), 0.0) * normalized_label
        + max(float(lambda_risk), 0.0) * normalized_risk
    )

    temperature = max(float(tau), 1e-8)
    adapters: list[LoRAAdapter] = []
    rows: list[dict] = []
    for receiver_index, receiver in enumerate(receivers):
        # FedGeo graph values are adjacency evidence, not a second distance
        # kernel. Their magnitudes can already contain exp(-d_geo), so using
        # them as probabilities here would count geometry twice and collapse
        # sharing to the diagonal. Keep only graph support; d_geo remains the
        # separately logged within-support cost.
        support = (matrices["graph"][receiver_index] > 0.0).astype(np.float64)
        support[receiver_index] = max(float(self_weight), support[receiver_index])
        proposal_prior = prior * support
        if float(proposal_prior.sum()) <= 0.0:
            proposal_prior[receiver_index] = 1.0
        neighbor_limit = int(max(top_k_neighbors, 0))
        if neighbor_limit > 0:
            allowed = {receiver_index}
            eligible = [index for index in range(n) if index != receiver_index and proposal_prior[index] > 0.0]
            eligible.sort(key=lambda index: (float(total_cost[receiver_index, index]), index))
            allowed.update(eligible[:neighbor_limit])
            mask = np.ones(n, dtype=bool)
            mask[list(allowed)] = False
            proposal_prior[mask] = 0.0
        logits = np.full(n, -np.inf, dtype=np.float64)
        positive = proposal_prior > 0.0
        logits[positive] = np.log(proposal_prior[positive]) - total_cost[receiver_index, positive] / temperature
        finite_logits = logits[np.isfinite(logits)]
        logits[np.isfinite(logits)] -= float(np.max(finite_logits))
        gibbs_prior = np.zeros(n, dtype=np.float64)
        gibbs_prior[np.isfinite(logits)] = np.exp(logits[np.isfinite(logits)])
        gibbs_prior /= np.clip(gibbs_prior.sum(), 1e-12, None)
        action_reference = (
            semantic_anchors[receiver_index]
            if anchor_mode == "receiver_local"
            else prior_center_stream
        )
        if optimize_joint_mixture:
            weights, mixture_audit = _optimize_receiver_donor_mixture(
                mixture_views[receiver_index].x_train,
                mixture_views[receiver_index].y_train,
                base + semantic_anchors[receiver_index],
                donor_streams,
                prior,
                gibbs_prior,
                action_reference=action_reference,
                correction_scale=scale,
                kl_strength=max(float(mixture_kl_strength), 0.0),
                max_iterations=int(mixture_max_iterations),
            )
        else:
            weights = gibbs_prior
            mixture_audit = {
                "mixture_initial_loss": float("nan"),
                "mixture_final_loss": float("nan"),
                "mixture_initial_objective": float("nan"),
                "mixture_final_objective": float("nan"),
                "mixture_kl_divergence": 0.0,
                "mixture_optimizer_iterations": 0,
            }
        centered_correction = sum(
            float(weight) * (donor_stream - action_reference)
            for weight, donor_stream in zip(weights, donor_streams)
        )
        semantic_delta = semantic_anchors[receiver_index] + scale * centered_correction
        rank = int(min(ranks[receiver_index], min(base.shape)))
        adapters.append(
            LoRAAdapter.from_delta(
                semantic_delta,
                rank=rank,
                alpha=float(rank),
                name=f"{name_prefix}-client-{receiver_index}",
            )
        )
        for donor_index, weight in enumerate(weights):
            rows.append(
                {
                    "receiver_index": int(receiver_index),
                    "donor_index": int(donor_index),
                    "prior_weight": float(prior[donor_index]),
                    "graph_support": float(support[donor_index]),
                    "gibbs_prior_weight": float(gibbs_prior[donor_index]),
                    "semantic_weight": float(weight),
                    "normal_energy_ratio": float(normal_cost[receiver_index, donor_index]),
                    "quadratic_first_order": float(first_order[receiver_index, donor_index]),
                    "quadratic_curvature": float(curvature[receiver_index, donor_index]),
                    "quadratic_risk": float(quadratic_cost[receiver_index, donor_index]),
                    "cubic_remainder_proxy": float(cubic_proxy[receiver_index, donor_index]),
                    "d_geo": float(matrices["d_geo"][receiver_index, donor_index]),
                    "d_label": float(matrices["d_label"][receiver_index, donor_index]),
                    "combined_cost": float(total_cost[receiver_index, donor_index]),
                    "semantic_correction_scale": scale,
                    "semantic_correction_norm": float(np.linalg.norm(centered_correction)),
                    "semantic_step_norm": float(scale * np.linalg.norm(centered_correction)),
                    "semantic_anchor_mode": anchor_mode,
                    "action_reference": anchor_mode,
                    "donor_matrix_rank": int(donor_rank[receiver_index, donor_index]),
                    "selected_by_top_k": bool(proposal_prior[donor_index] > 0.0),
                    "joint_mixture_optimized": bool(optimize_joint_mixture),
                    **mixture_audit,
                }
            )
    return adapters, rows


def _optimize_receiver_donor_mixture(
    x: Array,
    y: Array,
    center_weight: Array,
    donor_streams: list[Array],
    sample_prior: Array,
    gibbs_prior: Array,
    action_reference: Array | None,
    correction_scale: float,
    kl_strength: float,
    max_iterations: int,
    tolerance: float = 1e-9,
) -> tuple[Array, dict[str, float | int]]:
    """Solve the convex receiver mixture problem by mirror descent."""

    features = np.asarray(x, dtype=np.float64)
    labels = np.asarray(y, dtype=np.int64)
    prior = np.asarray(sample_prior, dtype=np.float64)
    prior /= np.clip(prior.sum(), 1e-12, None)
    q = np.asarray(gibbs_prior, dtype=np.float64)
    support = q > 0.0
    if not np.any(support):
        raise ValueError("gibbs_prior must have positive support")
    q = np.where(support, q, 0.0)
    q /= q.sum()
    scale = float(np.clip(correction_scale, 0.0, 1.0))
    center_logits = predict_with_weight(features, np.asarray(center_weight, dtype=np.float64))
    if action_reference is None:
        donor_logits = np.stack(
            [
                predict_with_weight(features, scale * np.asarray(stream, dtype=np.float64))
                for stream in donor_streams
            ],
            axis=0,
        )
        reference_logits = np.tensordot(prior, donor_logits, axes=(0, 0))
    else:
        reference = np.asarray(action_reference, dtype=np.float64)
        donor_logits = np.stack(
            [
                predict_with_weight(
                    features,
                    scale * (np.asarray(stream, dtype=np.float64) - reference),
                )
                for stream in donor_streams
            ],
            axis=0,
        )
        reference_logits = np.zeros_like(center_logits)

    def objective(beta: Array) -> tuple[float, float, float, Array]:
        logits = center_logits + np.tensordot(beta, donor_logits, axes=(0, 0)) - reference_logits
        loss, grad_logits = cross_entropy_and_grad(logits.copy(), labels)
        ratio = np.ones_like(beta)
        ratio[support] = np.clip(beta[support], 1e-15, None) / np.clip(q[support], 1e-15, None)
        kl = float(np.sum(beta[support] * np.log(ratio[support])))
        gradient = np.einsum("jnc,nc->j", donor_logits, grad_logits, optimize=True)
        if kl_strength > 0.0:
            gradient[support] += float(kl_strength) * (np.log(ratio[support]) + 1.0)
        gradient[~support] = 0.0
        return float(loss + kl_strength * kl), float(loss), kl, gradient

    beta = q.copy()
    initial_objective, initial_loss, _, gradient = objective(beta)
    current_objective = initial_objective
    current_loss = initial_loss
    current_kl = 0.0
    iterations = 0
    for iterations in range(1, max(int(max_iterations), 1) + 1):
        centered_gradient = gradient.copy()
        centered_gradient[support] -= float(np.sum(beta[support] * gradient[support]))
        step = 1.0
        accepted = False
        while step >= 1e-10:
            exponent = np.clip(-step * centered_gradient[support], -50.0, 50.0)
            proposal = np.zeros_like(beta)
            proposal[support] = beta[support] * np.exp(exponent)
            proposal[support] /= np.clip(proposal[support].sum(), 1e-15, None)
            proposal_objective, proposal_loss, proposal_kl, proposal_gradient = objective(proposal)
            if proposal_objective <= current_objective + 1e-12:
                accepted = True
                break
            step *= 0.5
        if not accepted or float(np.linalg.norm(proposal - beta, ord=1)) <= tolerance:
            break
        beta = proposal
        current_objective = proposal_objective
        current_loss = proposal_loss
        current_kl = proposal_kl
        gradient = proposal_gradient
    return beta, {
        "mixture_initial_loss": float(initial_loss),
        "mixture_final_loss": float(current_loss),
        "mixture_initial_objective": float(initial_objective),
        "mixture_final_objective": float(current_objective),
        "mixture_kl_divergence": float(current_kl),
        "mixture_optimizer_iterations": int(iterations),
    }


def _row_minmax(matrix: Array) -> Array:
    values = np.asarray(matrix, dtype=np.float64)
    minimum = np.nanmin(values, axis=1, keepdims=True)
    shifted = values - minimum
    maximum = np.nanmax(shifted, axis=1, keepdims=True)
    return np.divide(shifted, maximum, out=np.zeros_like(shifted), where=maximum > 1e-12)


def build_receiver_action_candidates(
    receivers: list[LoRAAdapter],
    donors: list[LoRAAdapter],
    donor_weights: Array,
    target_ranks: list[int] | int,
    modes: tuple[str, ...] = ("core", "column", "row", "tangent", "full"),
    name_prefix: str = "FedAdapterManifold-Decoupled",
) -> dict[str, list[LoRAAdapter]]:
    """Build intrinsic transport candidates without importing external models."""

    n = len(receivers)
    if len(donors) != n:
        raise ValueError("receivers and donors must have the same length")
    weights = np.asarray(donor_weights, dtype=np.float64)
    if weights.shape != (n, n):
        raise ValueError(f"donor_weights shape {weights.shape} does not match {(n, n)}")
    row_sums = weights.sum(axis=1, keepdims=True)
    weights = np.divide(weights, row_sums, out=np.zeros_like(weights), where=row_sums > 0.0)
    ranks = [int(target_ranks)] * n if isinstance(target_ranks, int) else [int(value) for value in target_ranks]
    if len(ranks) != n:
        raise ValueError(f"Expected {n} target ranks, got {len(ranks)}")
    valid_modes = {"core", "column", "row", "tangent", "full"}
    if not modes or any(mode not in valid_modes for mode in modes):
        raise ValueError(f"modes must be a nonempty subset of {sorted(valid_modes)}")

    output = {mode: [] for mode in modes}
    donor_deltas = [donor.delta() for donor in donors]
    for receiver_index, receiver in enumerate(receivers):
        accumulated = {mode: np.zeros_like(donor_deltas[0]) for mode in modes}
        for donor_index, donor_delta in enumerate(donor_deltas):
            blocks = receiver_action_blocks(receiver, donor_delta)
            candidates = {
                "core": blocks.core,
                "column": blocks.column_anchored,
                "row": blocks.row_anchored,
                "tangent": blocks.tangent,
                "full": donor_delta,
            }
            for mode in modes:
                accumulated[mode] += float(weights[receiver_index, donor_index]) * candidates[mode]
        for mode in modes:
            output[mode].append(
                LoRAAdapter.from_delta(
                    accumulated[mode],
                    rank=ranks[receiver_index],
                    alpha=float(ranks[receiver_index]),
                    name=f"{name_prefix}-{mode}-client-{receiver_index}",
                )
            )
    return output


def build_anchored_receiver_action_path_candidates(
    receivers: list[LoRAAdapter],
    donors: list[LoRAAdapter],
    donor_weights: Array,
    target_ranks: list[int] | int,
    modes: tuple[str, ...] = ("core", "column", "row", "tangent", "full"),
    steps: tuple[float, ...] = (0.25, 0.5, 0.75, 1.0),
    name_prefix: str = "FedAdapterManifold-AnchoredAction",
) -> dict[str, list[LoRAAdapter]]:
    """Build receiver-anchored residual paths in LoRA action space.

    Raw donor projection can erase a useful local update.  This construction
    instead decomposes the residual between the weighted donor center and the
    receiver update, then transports only that residual from the immutable
    local endpoint.  Candidate search remains training-only; the independent
    receiver certificate is applied later.
    """

    n = len(receivers)
    if len(donors) != n:
        raise ValueError("receivers and donors must have the same length")
    weights = np.asarray(donor_weights, dtype=np.float64)
    if weights.shape != (n, n):
        raise ValueError(f"donor_weights shape {weights.shape} does not match {(n, n)}")
    row_sums = weights.sum(axis=1, keepdims=True)
    weights = np.divide(weights, row_sums, out=np.zeros_like(weights), where=row_sums > 0.0)
    ranks = [int(target_ranks)] * n if isinstance(target_ranks, int) else [int(value) for value in target_ranks]
    if len(ranks) != n:
        raise ValueError(f"Expected {n} target ranks, got {len(ranks)}")
    valid_modes = {"core", "column", "row", "tangent", "full"}
    if not modes or any(mode not in valid_modes for mode in modes):
        raise ValueError(f"modes must be a nonempty subset of {sorted(valid_modes)}")
    path = tuple(sorted({float(step) for step in steps}))
    if not path or any(not 0.0 < step <= 1.0 for step in path):
        raise ValueError("steps must be unique values in (0, 1]")

    output = {f"anchored-{mode}-step-{step:.2f}": [] for mode in modes for step in path}
    donor_deltas = [np.asarray(donor.delta(), dtype=np.float64) for donor in donors]
    for receiver_index, receiver in enumerate(receivers):
        local_delta = np.asarray(receiver.delta(), dtype=np.float64)
        donor_center = sum(
            float(weights[receiver_index, donor_index]) * donor_delta
            for donor_index, donor_delta in enumerate(donor_deltas)
        )
        residual = donor_center - local_delta
        blocks = receiver_action_blocks(receiver, residual)
        directions = {
            "core": blocks.core,
            "column": blocks.column_anchored,
            "row": blocks.row_anchored,
            "tangent": blocks.tangent,
            "full": residual,
        }
        for mode in modes:
            for step in path:
                family = f"anchored-{mode}-step-{step:.2f}"
                candidate_delta = local_delta + float(step) * directions[mode]
                output[family].append(
                    LoRAAdapter.from_delta(
                        candidate_delta,
                        rank=ranks[receiver_index],
                        alpha=float(ranks[receiver_index]),
                        name=f"{name_prefix}-{mode}-{step:.2f}-client-{receiver_index}",
                    )
                )
    return output


def build_cumulative_semantic_candidates(
    receivers: list[LoRAAdapter],
    donor_cumulative_deltas: list[Array],
    algebraic_residual: Array,
    prior_weights: Array,
    label_distance: Array | None = None,
    tau: float = 1.0,
    lambda_label: float = 0.0,
    name_prefix: str = "FedAdapterManifold-CumulativeSemantic",
) -> tuple[list[LoRAAdapter], list[dict]]:
    """Reweight cumulative donor streams by directional semantic mismatch.

    The exact shared center is ``E_alg + sum_j p_j S_j``.  This construction
    keeps the same algebraic residual and cumulative deployment capacity but
    replaces the sample prior ``p`` by a receiver-specific Gibbs posterior.
    Its data term is the receiver-normal energy ratio of ``S_j``; optional
    label distance is a separate, explicitly logged conditioning term.
    """

    n = len(receivers)
    if len(donor_cumulative_deltas) != n:
        raise ValueError("donor_cumulative_deltas must align with receivers")
    prior = np.asarray(prior_weights, dtype=np.float64).reshape(-1)
    if prior.size != n or np.any(prior < 0.0) or float(prior.sum()) <= 0.0:
        raise ValueError("prior_weights must be nonnegative, nonzero, and align with receivers")
    prior = prior / prior.sum()
    labels = np.zeros((n, n), dtype=np.float64) if label_distance is None else np.asarray(label_distance, dtype=np.float64)
    if labels.shape != (n, n):
        raise ValueError(f"label_distance shape {labels.shape} does not match {(n, n)}")
    temperature = max(float(tau), 1e-8)
    residual = np.asarray(algebraic_residual, dtype=np.float64)
    expected_shape = receivers[0].delta().shape
    if residual.shape != expected_shape:
        raise ValueError("algebraic_residual shape does not match receiver updates")

    adapters: list[LoRAAdapter] = []
    rows: list[dict] = []
    full_rank = int(min(expected_shape))
    for receiver_index, receiver in enumerate(receivers):
        mismatches: list[float] = []
        summaries: list[dict[str, float | int]] = []
        for donor_delta in donor_cumulative_deltas:
            summary = receiver_action_energy_summary(receiver, donor_delta)
            summaries.append(summary)
            mismatches.append(float(summary["normal_energy_ratio"]))
        mismatch_array = np.asarray(mismatches, dtype=np.float64)
        total_distance = mismatch_array + max(float(lambda_label), 0.0) * labels[receiver_index]
        logits = np.log(np.clip(prior, 1e-300, None)) - total_distance / temperature
        logits -= float(np.max(logits))
        weights = np.exp(logits)
        weights /= np.clip(weights.sum(), 1e-12, None)
        semantic_delta = residual.copy()
        for donor_weight, donor_delta in zip(weights, donor_cumulative_deltas):
            semantic_delta += float(donor_weight) * np.asarray(donor_delta, dtype=np.float64)
        adapters.append(
            LoRAAdapter.from_delta(
                semantic_delta,
                rank=full_rank,
                alpha=float(full_rank),
                name=f"{name_prefix}-client-{receiver_index}",
            )
        )
        for donor_index, (weight, mismatch, summary) in enumerate(zip(weights, mismatches, summaries)):
            rows.append(
                {
                    "receiver_index": int(receiver_index),
                    "donor_index": int(donor_index),
                    "prior_weight": float(prior[donor_index]),
                    "semantic_weight": float(weight),
                    "normal_energy_ratio": float(mismatch),
                    "label_distance": float(labels[receiver_index, donor_index]),
                    "combined_distance": float(total_distance[donor_index]),
                    "donor_total_energy": float(summary["total_energy"]),
                    "donor_matrix_rank": int(summary["donor_matrix_rank"]),
                }
            )
    return adapters, rows


def screen_action_family_on_training_data(
    training_clients: list,
    base_weight: Array,
    anchor_adapters: list[LoRAAdapter],
    manifold_families: dict[str, list[LoRAAdapter]],
    ranks: list[int] | int,
    path: list[float] | str | None = None,
    method: str = "FedAdapterManifold-CumulativeScreenedAdmit",
) -> tuple[list[LoRAAdapter], list[dict]]:
    """Preselect one structural family without touching calibration labels.

    Screening and certification use disjoint training-side splits.  The
    screen chooses the family whose best predeclared path point has minimum
    adapter-training loss.  The returned endpoint is subsequently certified
    over the full path on held-out calibration data.
    """

    n = len(training_clients)
    if len(anchor_adapters) != n or not manifold_families:
        raise ValueError("training clients, anchors, and nonempty families must align")
    for family, endpoints in manifold_families.items():
        if len(endpoints) != n:
            raise ValueError(f"Family {family!r} does not align with training clients")
    rank_list = [int(ranks)] * n if isinstance(ranks, int) else [int(value) for value in ranks]
    if len(rank_list) != n:
        raise ValueError(f"Expected {n} ranks, got {len(rank_list)}")
    positive_steps = [value for value in _parse_path(path) if value > 0.0]
    selected_endpoints: list[LoRAAdapter] = []
    rows: list[dict] = []
    for client_index, (client, anchor, rank) in enumerate(zip(training_clients, anchor_adapters, rank_list)):
        family_records: list[tuple[float, str, float, LoRAAdapter]] = []
        for family in sorted(manifold_families):
            endpoint = manifold_families[family][client_index]
            best_loss = float("inf")
            best_strength = 0.0
            for strength in positive_steps:
                candidate = _interpolate(anchor, endpoint, strength, rank, client_index, family, method)
                loss = float(evaluate_adapter(client.x_train, client.y_train, base_weight, candidate)["loss"])
                if (loss, -strength) < (best_loss, -best_strength):
                    best_loss = loss
                    best_strength = float(strength)
            family_records.append((best_loss, family, best_strength, endpoint))
        _, selected_family, selected_strength, selected_endpoint = min(
            family_records,
            key=lambda record: (record[0], record[1]),
        )
        selected_endpoints.append(selected_endpoint)
        for loss, family, best_strength, _ in family_records:
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "screen_split": "adapter_training",
                    "screen_objective": "cross_entropy",
                    "transport_family": family,
                    "best_training_strength": float(best_strength),
                    "best_training_loss": float(loss),
                    "selected_family": bool(family == selected_family),
                    "selected_family_name": selected_family,
                    "selected_family_training_strength": float(selected_strength),
                }
            )
    return selected_endpoints, rows


def fit_blockwise_action_endpoints(
    training_clients: list,
    base_weight: Array,
    receiver_adapters: list[LoRAAdapter],
    source_families: dict[str, list[LoRAAdapter]],
    ranks: list[int] | int,
    max_iterations: int = 250,
    tolerance: float = 1e-9,
    name_prefix: str = "FedAdapterManifold-CumulativeBlockwise",
) -> tuple[list[LoRAAdapter], list[LoRAAdapter], list[dict]]:
    """Fit receiver-specific coefficients for the four orthogonal action blocks.

    For a frozen feature head, logits are affine in the four coefficients and
    cross entropy is convex on the coefficient box ``[0, 1]^4``.  Source
    family and block coefficients are fitted only on adapter-training data.
    The returned endpoint is still certified on an independent calibration
    split, while ``matched_sources`` provides the scalar, unmodified-source
    control for isolating anisotropic blockwise transport.
    """

    n = len(training_clients)
    if len(receiver_adapters) != n or not source_families:
        raise ValueError("training clients, receivers, and nonempty source families must align")
    for family, adapters in source_families.items():
        if len(adapters) != n:
            raise ValueError(f"Source family {family!r} does not align with training clients")
    rank_list = [int(ranks)] * n if isinstance(ranks, int) else [int(value) for value in ranks]
    if len(rank_list) != n:
        raise ValueError(f"Expected {n} ranks, got {len(rank_list)}")

    fitted: list[LoRAAdapter] = []
    matched_sources: list[LoRAAdapter] = []
    rows: list[dict] = []
    for client_index, (client, receiver, rank) in enumerate(
        zip(training_clients, receiver_adapters, rank_list)
    ):
        records: list[tuple[float, str, Array, Array, LoRAAdapter, int, float]] = []
        for family in sorted(source_families):
            source = source_families[family][client_index]
            blocks = receiver_action_blocks(receiver, source.delta())
            block_matrices = np.stack(
                [blocks.core, blocks.column_only, blocks.row_only, blocks.normal], axis=0
            )
            coefficients, loss, iterations = _fit_convex_block_coefficients(
                client.x_train,
                client.y_train,
                base_weight,
                block_matrices,
                max_iterations=max_iterations,
                tolerance=tolerance,
            )
            delta = np.tensordot(coefficients, block_matrices, axes=(0, 0))
            endpoint = LoRAAdapter.from_delta(
                delta,
                rank=rank,
                alpha=float(rank),
                name=f"{name_prefix}-{family}-client-{client_index}",
            )
            source_loss = float(
                evaluate_adapter(client.x_train, client.y_train, base_weight, source)["loss"]
            )
            records.append(
                (float(loss), family, coefficients, delta, source, int(iterations), source_loss)
            )
        best_loss, best_family, best_coefficients, best_delta, best_source, best_iterations, _ = min(
            records,
            key=lambda item: (item[0], item[1]),
        )
        fitted.append(
            LoRAAdapter.from_delta(
                best_delta,
                rank=rank,
                alpha=float(rank),
                name=f"{name_prefix}-selected-client-{client_index}",
            )
        )
        matched_sources.append(best_source.copy(name=f"{name_prefix}-source-control-client-{client_index}"))
        for loss, family, coefficients, _, _, iterations, source_loss in records:
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "screen_split": "adapter_training",
                    "screen_objective": "convex_block_cross_entropy",
                    "source_family": family,
                    "core_coefficient": float(coefficients[0]),
                    "column_only_coefficient": float(coefficients[1]),
                    "row_only_coefficient": float(coefficients[2]),
                    "normal_coefficient": float(coefficients[3]),
                    "training_loss": float(loss),
                    "source_training_loss": float(source_loss),
                    "training_gain_vs_source": float(source_loss - loss),
                    "optimizer_iterations": int(iterations),
                    "selected_source": bool(family == best_family),
                    "selected_source_name": best_family,
                    "selected_training_loss": float(best_loss),
                    "selected_optimizer_iterations": int(best_iterations),
                }
            )
    return fitted, matched_sources, rows


def fit_residual_blockwise_action_endpoints(
    training_clients: list,
    base_weight: Array,
    receiver_adapters: list[LoRAAdapter],
    center_endpoints: list[LoRAAdapter],
    residual_source_families: dict[str, list[LoRAAdapter]],
    ranks: list[int] | int,
    max_iterations: int = 250,
    tolerance: float = 1e-9,
    name_prefix: str = "FedAdapterManifold-ResidualBlockwise",
) -> tuple[list[LoRAAdapter], list[LoRAAdapter], list[dict]]:
    """Fit semantic residuals around a fixed cumulative center.

    The center is never re-estimated by this routine.  For each receiver and
    source family, only ``source - center`` is split into receiver action
    blocks.  This separates cumulative optimization stability from semantic
    admission.  A scalar residual fit is returned as a same-source control,
    so any blockwise gain cannot be attributed merely to adding the source
    endpoint or increasing deployment rank.
    """

    n = len(training_clients)
    if len(receiver_adapters) != n or len(center_endpoints) != n or not residual_source_families:
        raise ValueError("training clients, receivers, centers, and residual families must align")
    for family, adapters in residual_source_families.items():
        if len(adapters) != n:
            raise ValueError(f"Residual family {family!r} does not align with training clients")
    rank_list = [int(ranks)] * n if isinstance(ranks, int) else [int(value) for value in ranks]
    if len(rank_list) != n:
        raise ValueError(f"Expected {n} ranks, got {len(rank_list)}")

    fitted: list[LoRAAdapter] = []
    scalar_controls: list[LoRAAdapter] = []
    rows: list[dict] = []
    for client_index, (client, receiver, center, rank) in enumerate(
        zip(training_clients, receiver_adapters, center_endpoints, rank_list)
    ):
        records: list[dict] = []
        center_delta = center.delta()
        center_loss = float(evaluate_adapter(client.x_train, client.y_train, base_weight, center)["loss"])
        for family in sorted(residual_source_families):
            source = residual_source_families[family][client_index]
            residual_delta = source.delta() - center_delta
            blocks = receiver_action_blocks(receiver, residual_delta)
            block_matrices = np.stack(
                [blocks.core, blocks.column_only, blocks.row_only, blocks.normal], axis=0
            )
            coefficients, block_loss, block_iterations = _fit_convex_block_coefficients(
                client.x_train,
                client.y_train,
                np.asarray(base_weight, dtype=np.float64) + center_delta,
                block_matrices,
                max_iterations=max_iterations,
                tolerance=tolerance,
            )
            fitted_residual = np.tensordot(coefficients, block_matrices, axes=(0, 0))
            fitted_delta = center_delta + fitted_residual

            zero = np.zeros_like(residual_delta)
            scalar_blocks = np.stack([residual_delta, zero, zero, zero], axis=0)
            scalar_coefficients, scalar_loss, scalar_iterations = _fit_convex_block_coefficients(
                client.x_train,
                client.y_train,
                np.asarray(base_weight, dtype=np.float64) + center_delta,
                scalar_blocks,
                max_iterations=max_iterations,
                tolerance=tolerance,
            )
            scalar_strength = float(scalar_coefficients[0])
            scalar_delta = center_delta + scalar_strength * residual_delta
            records.append(
                {
                    "family": family,
                    "coefficients": coefficients,
                    "block_loss": float(block_loss),
                    "block_iterations": int(block_iterations),
                    "fitted_delta": fitted_delta,
                    "scalar_strength": scalar_strength,
                    "scalar_loss": float(scalar_loss),
                    "scalar_iterations": int(scalar_iterations),
                    "scalar_delta": scalar_delta,
                    "source_loss": float(
                        evaluate_adapter(client.x_train, client.y_train, base_weight, source)["loss"]
                    ),
                    "residual_norm": float(np.linalg.norm(residual_delta, ord="fro")),
                }
            )

        best_block = min(records, key=lambda record: (record["block_loss"], record["family"]))
        best_scalar = min(records, key=lambda record: (record["scalar_loss"], record["family"]))
        fitted.append(
            LoRAAdapter.from_delta(
                best_block["fitted_delta"],
                rank=rank,
                alpha=float(rank),
                name=f"{name_prefix}-selected-client-{client_index}",
            )
        )
        scalar_controls.append(
            LoRAAdapter.from_delta(
                best_scalar["scalar_delta"],
                rank=rank,
                alpha=float(rank),
                name=f"{name_prefix}-scalar-control-client-{client_index}",
            )
        )
        for record in records:
            coefficients = record["coefficients"]
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "screen_split": "adapter_training",
                    "screen_objective": "centered_residual_cross_entropy",
                    "source_family": record["family"],
                    "center_training_loss": center_loss,
                    "core_coefficient": float(coefficients[0]),
                    "column_only_coefficient": float(coefficients[1]),
                    "row_only_coefficient": float(coefficients[2]),
                    "normal_coefficient": float(coefficients[3]),
                    "training_loss": float(record["block_loss"]),
                    "training_gain_vs_center": float(center_loss - record["block_loss"]),
                    "source_training_loss": float(record["source_loss"]),
                    "training_gain_vs_source": float(record["source_loss"] - record["block_loss"]),
                    "scalar_residual_strength": float(record["scalar_strength"]),
                    "scalar_training_loss": float(record["scalar_loss"]),
                    "blockwise_gain_vs_scalar": float(record["scalar_loss"] - record["block_loss"]),
                    "residual_norm": float(record["residual_norm"]),
                    "optimizer_iterations": int(record["block_iterations"]),
                    "scalar_optimizer_iterations": int(record["scalar_iterations"]),
                    "selected_block_source": bool(record is best_block),
                    "selected_block_source_name": str(best_block["family"]),
                    "selected_scalar_source": bool(record is best_scalar),
                    "selected_scalar_source_name": str(best_scalar["family"]),
                }
            )
    return fitted, scalar_controls, rows


def _fit_convex_block_coefficients(
    x: Array,
    y: Array,
    base_weight: Array,
    block_matrices: Array,
    max_iterations: int,
    tolerance: float,
) -> tuple[Array, float, int]:
    """Projected-gradient solver for the four-dimensional convex subproblem."""

    features = np.asarray(x, dtype=np.float64)
    labels = np.asarray(y, dtype=np.int64)
    blocks = np.asarray(block_matrices, dtype=np.float64)
    if blocks.ndim != 3 or blocks.shape[0] != 4:
        raise ValueError(f"Expected four action blocks, got shape {blocks.shape}")
    base_logits = predict_with_weight(features, np.asarray(base_weight, dtype=np.float64))
    block_logits = np.stack([predict_with_weight(features, block) for block in blocks], axis=0)
    vertices = np.asarray(
        [
            [0.0, 0.0, 0.0, 0.0],
            [1.0, 0.0, 0.0, 0.0],
            [1.0, 1.0, 0.0, 0.0],
            [1.0, 0.0, 1.0, 0.0],
            [1.0, 1.0, 1.0, 0.0],
            [1.0, 1.0, 1.0, 1.0],
        ],
        dtype=np.float64,
    )

    def objective(coefficients: Array) -> tuple[float, Array]:
        logits = base_logits + np.tensordot(coefficients, block_logits, axes=(0, 0))
        loss, grad_logits = cross_entropy_and_grad(logits.copy(), labels)
        gradient = np.einsum("knc,nc->k", block_logits, grad_logits, optimize=True)
        return float(loss), np.asarray(gradient, dtype=np.float64)

    vertex_losses = [objective(vertex)[0] for vertex in vertices]
    coefficients = vertices[int(np.argmin(vertex_losses))].copy()
    loss, gradient = objective(coefficients)
    iterations = 0
    for iterations in range(1, max(int(max_iterations), 1) + 1):
        step = 1.0
        accepted = False
        while step >= 1e-10:
            proposal = np.clip(coefficients - step * gradient, 0.0, 1.0)
            if float(np.linalg.norm(proposal - coefficients)) <= tolerance:
                break
            proposal_loss, proposal_gradient = objective(proposal)
            if proposal_loss <= loss + 1e-12:
                coefficients = proposal
                loss = proposal_loss
                gradient = proposal_gradient
                accepted = True
                break
            step *= 0.5
        projected_gradient = coefficients - np.clip(coefficients - gradient, 0.0, 1.0)
        if not accepted or float(np.linalg.norm(projected_gradient)) <= tolerance:
            break
    return coefficients, float(loss), int(iterations)


def select_joint_empirical_bernstein_paths(
    selector_clients: list,
    eval_clients: list,
    base_weight: Array,
    anchor_adapters: list[LoRAAdapter],
    manifold_families: dict[str, list[LoRAAdapter]],
    ranks: list[int] | int,
    path: list[float] | str | None = None,
    delta: float = 0.05,
    risk_tolerance: float = 0.0,
    seed: int = 0,
    dataset: str = "",
    heterogeneity_setting: str = "",
    round_id: int = 0,
    method: str = "FedAdapterManifold-DecoupledAdmit",
    confidence_bound: str = "paired-discordance",
    num_comparisons_override: int | None = None,
) -> JointPathAdmissionResult:
    """Jointly certify endpoint family and transport strength.

    Every endpoint family and path point is fixed before calibration.  A
    single Bonferroni-corrected empirical-Bernstein event covers the complete
    family-by-strength grid, avoiding a hidden endpoint-selection stage.
    """

    n = len(selector_clients)
    if len(eval_clients) != n or len(anchor_adapters) != n:
        raise ValueError("selector, evaluation, and anchor lists must align")
    if not manifold_families:
        raise ValueError("At least one intrinsic manifold family is required")
    for family, adapters in manifold_families.items():
        if len(adapters) != n:
            raise ValueError(f"Family {family!r} has {len(adapters)} adapters; expected {n}")
    rank_list = [int(ranks)] * n if isinstance(ranks, int) else [int(value) for value in ranks]
    if len(rank_list) != n:
        raise ValueError(f"Expected {n} ranks, got {len(rank_list)}")
    path_values = _parse_path(path)
    positive_steps = [value for value in path_values if value > 0.0]
    natural_comparison_count = max(len(positive_steps) * len(manifold_families), 1)
    comparison_count = (
        natural_comparison_count
        if num_comparisons_override is None
        else max(int(num_comparisons_override), natural_comparison_count)
    )
    confidence_bound = str(confidence_bound).strip().lower()
    if confidence_bound not in {"paired-discordance", "empirical-bernstein"}:
        raise ValueError("confidence_bound must be 'paired-discordance' or 'empirical-bernstein'")

    selected_adapters: list[LoRAAdapter] = []
    metrics_rows: list[dict] = []
    admission_rows: list[dict] = []
    for client_index, (selector, evaluator, anchor, rank) in enumerate(
        zip(selector_clients, eval_clients, anchor_adapters, rank_list)
    ):
        anchor_errors = evaluate_adapter_error_vector(selector.x_train, selector.y_train, base_weight, anchor)
        anchor_losses = evaluate_adapter_loss_vector(selector.x_train, selector.y_train, base_weight, anchor)
        records: list[tuple[dict, LoRAAdapter]] = []
        # The anchor appears once, not once per family.
        records.append(
            (
                {
                    "transport_family": "anchor",
                    "admission_strength": 0.0,
                    "paired_error_difference": 0.0,
                    "paired_log_loss_difference": 0.0,
                    "empirical_bernstein_margin": 0.0,
                    "risk_upper_bound": 0.0,
                    "certified_safe": True,
                },
                anchor.copy(name=f"{method}-anchor-client-{client_index}"),
            )
        )
        for family in sorted(manifold_families):
            endpoint = manifold_families[family][client_index]
            for strength in positive_steps:
                candidate = _interpolate(anchor, endpoint, strength, rank, client_index, family, method)
                candidate_errors = evaluate_adapter_error_vector(
                    selector.x_train,
                    selector.y_train,
                    base_weight,
                    candidate,
                )
                candidate_losses = evaluate_adapter_loss_vector(
                    selector.x_train,
                    selector.y_train,
                    base_weight,
                    candidate,
                )
                differences = candidate_errors - anchor_errors
                log_loss_difference = float(np.mean(candidate_losses - anchor_losses))
                if confidence_bound == "paired-discordance":
                    mean, margin, upper, bound_details = paired_discordance_upper_bound(
                        candidate_errors,
                        anchor_errors,
                        delta=delta,
                        num_comparisons=comparison_count,
                    )
                else:
                    mean, margin, upper = _empirical_bernstein(
                        differences,
                        delta=delta,
                        num_comparisons=comparison_count,
                    )
                    bound_details = {
                        "harm_discordances": int(np.sum(differences > 0.0)),
                        "benefit_discordances": int(np.sum(differences < 0.0)),
                        "total_discordances": int(np.sum(differences != 0.0)),
                    }
                records.append(
                    (
                        {
                            "transport_family": family,
                            "admission_strength": float(strength),
                            "paired_error_difference": float(mean),
                            "paired_log_loss_difference": log_loss_difference,
                            "empirical_bernstein_margin": float(margin),
                            "risk_upper_bound": float(upper),
                            "confidence_bound": confidence_bound,
                            **bound_details,
                            "certified_safe": bool(upper <= float(risk_tolerance) + 1e-12),
                        },
                        candidate,
                    )
                )
        safe_indices = [index for index, (record, _) in enumerate(records) if record["certified_safe"]]
        selected_index = min(
            safe_indices,
            key=lambda index: (
                float(records[index][0]["paired_error_difference"]),
                -float(records[index][0]["admission_strength"]),
                str(records[index][0]["transport_family"]),
            ),
        )
        selected_record, selected_adapter = records[selected_index]
        selected_adapters.append(selected_adapter)
        test_metrics = evaluate_adapter(evaluator.x_test, evaluator.y_test, base_weight, selected_adapter)
        metrics_rows.append(
            {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": evaluator.client_id,
                "domain": evaluator.domain,
                "accuracy": float(test_metrics["accuracy"]),
                "loss": float(test_metrics["loss"]),
                "rank": int(rank),
                "selected_transport_family": str(selected_record["transport_family"]),
                "selected_admission_strength": float(selected_record["admission_strength"]),
                "certified_risk_upper_bound": float(selected_record["risk_upper_bound"]),
            }
        )
        for record_index, (record, _) in enumerate(records):
            admission_rows.append(
                {
                    "method": method,
                    "seed": int(seed),
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": int(round_id),
                    "client_id": evaluator.client_id,
                    "domain": evaluator.domain,
                    "selection_split": "heldout_calibration",
                    "selector_loss": "paired_0_1_error",
                    "selector_delta": float(delta),
                    "selector_num_comparisons": int(comparison_count),
                    "selector_confidence_bound": confidence_bound,
                    "risk_tolerance": float(risk_tolerance),
                    **record,
                    "selected": bool(record_index == selected_index),
                }
            )
    return JointPathAdmissionResult(selected_adapters, metrics_rows, admission_rows)


def select_competitive_safe_blockwise_paths(
    selector_clients: list,
    eval_clients: list,
    base_weight: Array,
    anchor_adapters: list[LoRAAdapter],
    full_endpoints: list[LoRAAdapter],
    blockwise_endpoints: list[LoRAAdapter],
    ranks: list[int] | int,
    path: list[float] | str | None = None,
    delta: float = 0.05,
    risk_tolerance: float = 0.0,
    seed: int = 0,
    dataset: str = "",
    heterogeneity_setting: str = "",
    round_id: int = 0,
    method: str = "FedAdapterManifold-CumulativeCompetitiveAdmit",
    control_method: str = "CumulativeFull-CompetitiveBudget-Control",
) -> tuple[JointPathAdmissionResult, JointPathAdmissionResult]:
    """Admit blockwise transport only when it directly dominates full.

    The full path is first selected with a uniform correction covering the
    complete two-stage procedure. Every blockwise path point is then compared
    directly with the selected full control. The multiplicity

    ``|F| + |B| + |F||B|``

    covers all anchor comparisons and every possible blockwise/full pair, so
    the direct certificate remains valid although the full reference is
    selected on the same calibration split.
    """

    n = len(selector_clients)
    if not (
        len(eval_clients) == n
        and len(anchor_adapters) == n
        and len(full_endpoints) == n
        and len(blockwise_endpoints) == n
    ):
        raise ValueError("selector, evaluation, anchor, full, and blockwise lists must align")
    rank_list = [int(ranks)] * n if isinstance(ranks, int) else [int(value) for value in ranks]
    if len(rank_list) != n:
        raise ValueError(f"Expected {n} ranks, got {len(rank_list)}")
    positive_steps = [value for value in _parse_path(path) if value > 0.0]
    if not positive_steps:
        raise ValueError("At least one positive path strength is required")
    full_count = len(positive_steps)
    blockwise_count = len(positive_steps)
    comparison_count = full_count + blockwise_count + full_count * blockwise_count

    full_control = select_joint_empirical_bernstein_paths(
        selector_clients=selector_clients,
        eval_clients=eval_clients,
        base_weight=base_weight,
        anchor_adapters=anchor_adapters,
        manifold_families={"full": full_endpoints},
        ranks=rank_list,
        path=path,
        delta=delta,
        risk_tolerance=risk_tolerance,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=round_id,
        method=control_method,
        confidence_bound="paired-discordance",
        num_comparisons_override=comparison_count,
    )

    selected_adapters: list[LoRAAdapter] = []
    metrics_rows: list[dict] = []
    admission_rows: list[dict] = []
    for client_index, (selector, evaluator, anchor, blockwise_endpoint, full_reference, rank) in enumerate(
        zip(
            selector_clients,
            eval_clients,
            anchor_adapters,
            blockwise_endpoints,
            full_control.client_adapters,
            rank_list,
        )
    ):
        reference_errors = evaluate_adapter_error_vector(
            selector.x_train,
            selector.y_train,
            base_weight,
            full_reference,
        )
        reference_losses = evaluate_adapter_loss_vector(
            selector.x_train,
            selector.y_train,
            base_weight,
            full_reference,
        )
        full_metadata = full_control.per_client_metrics[client_index]
        records: list[tuple[dict, LoRAAdapter]] = [
            (
                {
                    "transport_family": "full_control",
                    "admission_strength": float(full_metadata["selected_admission_strength"]),
                    "paired_error_difference_vs_full": 0.0,
                    "paired_log_loss_difference_vs_full": 0.0,
                    "competitive_margin": 0.0,
                    "competitive_risk_upper_bound": 0.0,
                    "harm_discordances_vs_full": 0,
                    "benefit_discordances_vs_full": 0,
                    "total_discordances_vs_full": 0,
                    "certified_competitive": True,
                },
                full_reference.copy(name=f"{method}-full-control-client-{client_index}"),
            )
        ]
        for strength in positive_steps:
            candidate = _interpolate(
                anchor,
                blockwise_endpoint,
                strength,
                rank,
                client_index,
                "blockwise",
                method,
            )
            candidate_errors = evaluate_adapter_error_vector(
                selector.x_train,
                selector.y_train,
                base_weight,
                candidate,
            )
            candidate_losses = evaluate_adapter_loss_vector(
                selector.x_train,
                selector.y_train,
                base_weight,
                candidate,
            )
            mean, margin, upper, details = paired_discordance_upper_bound(
                candidate_errors,
                reference_errors,
                delta=delta,
                num_comparisons=comparison_count,
            )
            records.append(
                (
                    {
                        "transport_family": "blockwise",
                        "admission_strength": float(strength),
                        "paired_error_difference_vs_full": float(mean),
                        "paired_log_loss_difference_vs_full": float(
                            np.mean(candidate_losses - reference_losses)
                        ),
                        "competitive_margin": float(margin),
                        "competitive_risk_upper_bound": float(upper),
                        "harm_discordances_vs_full": int(details["harm_discordances"]),
                        "benefit_discordances_vs_full": int(details["benefit_discordances"]),
                        "total_discordances_vs_full": int(details["total_discordances"]),
                        "certified_competitive": bool(upper <= float(risk_tolerance) + 1e-12),
                    },
                    candidate,
                )
            )
        admissible = [
            index for index, (record, _) in enumerate(records) if record["certified_competitive"]
        ]
        selected_index = min(
            admissible,
            key=lambda index: (
                float(records[index][0]["paired_error_difference_vs_full"]),
                float(records[index][0]["paired_log_loss_difference_vs_full"]),
                -float(records[index][0]["admission_strength"]),
            ),
        )
        selected_record, selected_adapter = records[selected_index]
        selected_adapters.append(selected_adapter)
        test_metrics = evaluate_adapter(evaluator.x_test, evaluator.y_test, base_weight, selected_adapter)
        metrics_rows.append(
            {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": evaluator.client_id,
                "domain": evaluator.domain,
                "accuracy": float(test_metrics["accuracy"]),
                "loss": float(test_metrics["loss"]),
                "rank": int(rank),
                "selected_transport_family": str(selected_record["transport_family"]),
                "selected_admission_strength": float(selected_record["admission_strength"]),
                "certified_risk_upper_bound": float(
                    selected_record["competitive_risk_upper_bound"]
                ),
                "competitive_reference": control_method,
            }
        )
        for record_index, (record, _) in enumerate(records):
            admission_rows.append(
                {
                    "method": method,
                    "seed": int(seed),
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": int(round_id),
                    "client_id": evaluator.client_id,
                    "domain": evaluator.domain,
                    "selection_split": "heldout_calibration",
                    "selector_loss": "paired_0_1_error_vs_full_control",
                    "selector_delta": float(delta),
                    "selector_num_comparisons": int(comparison_count),
                    "risk_tolerance": float(risk_tolerance),
                    "full_control_family": str(full_metadata["selected_transport_family"]),
                    "full_control_strength": float(full_metadata["selected_admission_strength"]),
                    **record,
                    "selected": bool(record_index == selected_index),
                }
            )
    return JointPathAdmissionResult(selected_adapters, metrics_rows, admission_rows), full_control


def select_split_certified_residual_paths(
    selector_clients: list,
    eval_clients: list,
    base_weight: Array,
    anchor_adapters: list[LoRAAdapter],
    full_endpoints: list[LoRAAdapter],
    residual_endpoints: list[LoRAAdapter],
    ranks: list[int] | int,
    path: list[float] | str | None = None,
    delta: float = 0.05,
    risk_tolerance: float = 0.02,
    competitive_tolerance: float | None = None,
    selection_fraction: float = 0.5,
    selection_clients: list | None = None,
    certification_clients: list | None = None,
    seed: int = 0,
    dataset: str = "",
    heterogeneity_setting: str = "",
    round_id: int = 0,
    method: str = "FedAdapterManifold-SplitCertifiedResidual",
    control_method: str = "IntrinsicFull-SplitCertifiedControl",
) -> tuple[JointPathAdmissionResult, JointPathAdmissionResult]:
    """Select path strengths and certify them on disjoint calibration data.

    The first calibration partition selects one full-center path point and one
    residual path point by log loss.  The second partition is untouched until
    it certifies three fixed comparisons: full versus local, residual versus
    local, and residual versus full.  Thus multiplicity is three rather than
    the Cartesian path-search correction required when the same observations
    perform both selection and certification.

    ``risk_tolerance`` is an explicit bounded-regret budget, not a zero-regret
    claim.  The residual is deployed only when its empirical error and log
    loss do not exceed the full control and its upper bounds satisfy both the
    local-safety and full-competitiveness budgets.
    """

    n = len(selector_clients)
    if not (
        len(eval_clients) == n
        and len(anchor_adapters) == n
        and len(full_endpoints) == n
        and len(residual_endpoints) == n
    ):
        raise ValueError("selector, evaluation, anchor, full, and residual lists must align")
    if not 0.0 < float(selection_fraction) < 1.0:
        raise ValueError("selection_fraction must lie strictly between zero and one")
    if (selection_clients is None) != (certification_clients is None):
        raise ValueError("selection_clients and certification_clients must be provided together")
    if selection_clients is not None and (
        len(selection_clients) != n or len(certification_clients) != n
    ):
        raise ValueError("pre-split calibration client views must align with selector clients")
    rank_list = [int(ranks)] * n if isinstance(ranks, int) else [int(value) for value in ranks]
    if len(rank_list) != n:
        raise ValueError(f"Expected {n} ranks, got {len(rank_list)}")
    path_values = _parse_path(path)
    competitive_budget = (
        float(risk_tolerance) if competitive_tolerance is None else float(competitive_tolerance)
    )
    comparison_count = 3

    method_adapters: list[LoRAAdapter] = []
    method_metrics: list[dict] = []
    method_rows: list[dict] = []
    control_adapters: list[LoRAAdapter] = []
    control_metrics: list[dict] = []
    control_rows: list[dict] = []

    for client_index, (selector, evaluator, anchor, full_endpoint, residual_endpoint, rank) in enumerate(
        zip(
            selector_clients,
            eval_clients,
            anchor_adapters,
            full_endpoints,
            residual_endpoints,
            rank_list,
        )
    ):
        if selection_clients is None:
            selection_indices, certification_indices = _stratified_calibration_partition(
                selector.y_train,
                fraction=float(selection_fraction),
                seed=int(seed) * 1009 + client_index,
            )
            x_select = selector.x_train[selection_indices]
            y_select = selector.y_train[selection_indices]
            x_cert = selector.x_train[certification_indices]
            y_cert = selector.y_train[certification_indices]
        else:
            selection_view = selection_clients[client_index]
            certification_view = certification_clients[client_index]
            x_select = selection_view.x_train
            y_select = selection_view.y_train
            x_cert = certification_view.x_train
            y_cert = certification_view.y_train
            selection_indices = np.arange(y_select.size, dtype=np.int64)
            certification_indices = np.arange(y_cert.size, dtype=np.int64)

        full_strength, full_candidate, full_selection_loss = _select_path_by_log_loss(
            x_select,
            y_select,
            base_weight,
            anchor,
            full_endpoint,
            rank,
            path_values,
            client_index,
            "full",
            control_method,
        )
        residual_strength, residual_candidate, residual_selection_loss = _select_path_by_log_loss(
            x_select,
            y_select,
            base_weight,
            anchor,
            residual_endpoint,
            rank,
            path_values,
            client_index,
            "residual_blockwise",
            method,
        )

        anchor_errors = evaluate_adapter_error_vector(x_cert, y_cert, base_weight, anchor)
        full_errors = evaluate_adapter_error_vector(x_cert, y_cert, base_weight, full_candidate)
        residual_errors = evaluate_adapter_error_vector(x_cert, y_cert, base_weight, residual_candidate)
        anchor_losses = evaluate_adapter_loss_vector(x_cert, y_cert, base_weight, anchor)
        full_losses = evaluate_adapter_loss_vector(x_cert, y_cert, base_weight, full_candidate)
        residual_losses = evaluate_adapter_loss_vector(x_cert, y_cert, base_weight, residual_candidate)

        full_vs_anchor = paired_discordance_upper_bound(
            full_errors,
            anchor_errors,
            delta=delta,
            num_comparisons=comparison_count,
        )
        residual_vs_anchor = paired_discordance_upper_bound(
            residual_errors,
            anchor_errors,
            delta=delta,
            num_comparisons=comparison_count,
        )
        residual_vs_full = paired_discordance_upper_bound(
            residual_errors,
            full_errors,
            delta=delta,
            num_comparisons=comparison_count,
        )
        full_safe = bool(full_vs_anchor[2] <= float(risk_tolerance) + 1e-12)
        residual_safe = bool(residual_vs_anchor[2] <= float(risk_tolerance) + 1e-12)
        residual_competitive = bool(
            residual_vs_full[0] <= 1e-12
            and float(np.mean(residual_losses - full_losses)) <= 1e-12
            and residual_vs_full[2] <= competitive_budget + 1e-12
        )

        if full_safe:
            selected_control = full_candidate
            control_family = "full"
            control_strength = float(full_strength)
            control_upper = float(full_vs_anchor[2])
        else:
            selected_control = anchor.copy(name=f"{control_method}-anchor-client-{client_index}")
            control_family = "anchor"
            control_strength = 0.0
            control_upper = 0.0
        if residual_safe and residual_competitive:
            selected_method = residual_candidate
            method_family = "residual_blockwise"
            method_strength = float(residual_strength)
            method_upper = float(residual_vs_anchor[2])
        else:
            selected_method = selected_control.copy(name=f"{method}-control-client-{client_index}")
            method_family = "full_control" if control_family == "full" else "anchor"
            method_strength = float(control_strength)
            method_upper = float(control_upper)

        control_adapters.append(selected_control)
        method_adapters.append(selected_method)
        control_test = evaluate_adapter(evaluator.x_test, evaluator.y_test, base_weight, selected_control)
        method_test = evaluate_adapter(evaluator.x_test, evaluator.y_test, base_weight, selected_method)
        anchor_test = evaluate_adapter(evaluator.x_test, evaluator.y_test, base_weight, anchor)
        full_candidate_test = evaluate_adapter(
            evaluator.x_test,
            evaluator.y_test,
            base_weight,
            full_candidate,
        )
        residual_candidate_test = evaluate_adapter(
            evaluator.x_test,
            evaluator.y_test,
            base_weight,
            residual_candidate,
        )
        common = {
            "seed": int(seed),
            "dataset": dataset,
            "heterogeneity_setting": heterogeneity_setting,
            "round": int(round_id),
            "client_id": evaluator.client_id,
            "domain": evaluator.domain,
            "rank": int(rank),
            "selection_calibration_size": int(selection_indices.size),
            "certification_calibration_size": int(certification_indices.size),
        }
        control_metrics.append(
            {
                "method": control_method,
                **common,
                "accuracy": float(control_test["accuracy"]),
                "loss": float(control_test["loss"]),
                "selected_transport_family": control_family,
                "selected_admission_strength": control_strength,
                "certified_risk_upper_bound": control_upper,
            }
        )
        method_metrics.append(
            {
                "method": method,
                **common,
                "accuracy": float(method_test["accuracy"]),
                "loss": float(method_test["loss"]),
                "selected_transport_family": method_family,
                "selected_admission_strength": method_strength,
                "certified_risk_upper_bound": method_upper,
                "competitive_reference": control_method,
            }
        )

        audit = {
            **common,
            "selection_split": "heldout_calibration_selection",
            "certification_split": "heldout_calibration_certification",
            "selector_num_comparisons": comparison_count,
            "selector_delta": float(delta),
            "risk_tolerance": float(risk_tolerance),
            "competitive_tolerance": competitive_budget,
            "full_selection_strength": float(full_strength),
            "full_selection_loss": float(full_selection_loss),
            "residual_selection_strength": float(residual_strength),
            "residual_selection_loss": float(residual_selection_loss),
            "full_vs_anchor_error": float(full_vs_anchor[0]),
            "full_vs_anchor_upper": float(full_vs_anchor[2]),
            "residual_vs_anchor_error": float(residual_vs_anchor[0]),
            "residual_vs_anchor_upper": float(residual_vs_anchor[2]),
            "residual_vs_full_error": float(residual_vs_full[0]),
            "residual_vs_full_log_loss": float(np.mean(residual_losses - full_losses)),
            "residual_vs_full_upper": float(residual_vs_full[2]),
            "full_safe": full_safe,
            "residual_safe": residual_safe,
            "residual_competitive": residual_competitive,
            # These post-selection test outcomes are audit-only. They are
            # written after all selection and certification decisions and are
            # never read by the gate.
            "anchor_test_accuracy_audit": float(anchor_test["accuracy"]),
            "anchor_test_loss_audit": float(anchor_test["loss"]),
            "full_candidate_test_accuracy_audit": float(full_candidate_test["accuracy"]),
            "full_candidate_test_loss_audit": float(full_candidate_test["loss"]),
            "residual_candidate_test_accuracy_audit": float(
                residual_candidate_test["accuracy"]
            ),
            "residual_candidate_test_loss_audit": float(residual_candidate_test["loss"]),
            "residual_candidate_accuracy_gain_vs_full_audit": float(
                residual_candidate_test["accuracy"] - full_candidate_test["accuracy"]
            ),
            "residual_candidate_loss_gain_vs_full_audit": float(
                full_candidate_test["loss"] - residual_candidate_test["loss"]
            ),
            "selected_transport_family": method_family,
            "selected_admission_strength": method_strength,
        }
        method_rows.append({"method": method, **audit})
        control_rows.append(
            {
                "method": control_method,
                **audit,
                "selected_transport_family": control_family,
                "selected_admission_strength": control_strength,
            }
        )

    return (
        JointPathAdmissionResult(method_adapters, method_metrics, method_rows),
        JointPathAdmissionResult(control_adapters, control_metrics, control_rows),
    )


def _select_path_by_log_loss(
    x: Array,
    y: Array,
    base_weight: Array,
    anchor: LoRAAdapter,
    endpoint: LoRAAdapter,
    rank: int,
    path_values: list[float],
    client_index: int,
    family: str,
    method: str,
) -> tuple[float, LoRAAdapter, float]:
    records: list[tuple[float, float, LoRAAdapter]] = []
    for strength in path_values:
        candidate = _interpolate(
            anchor,
            endpoint,
            strength,
            rank,
            client_index,
            family,
            method,
        )
        loss = float(evaluate_adapter(x, y, base_weight, candidate)["loss"])
        records.append((loss, float(strength), candidate))
    loss, strength, candidate = min(records, key=lambda record: (record[0], -record[1]))
    return strength, candidate, loss


def _stratified_calibration_partition(y: Array, fraction: float, seed: int) -> tuple[Array, Array]:
    labels = np.asarray(y, dtype=np.int64)
    rng = np.random.default_rng(int(seed))
    first: list[int] = []
    second: list[int] = []
    for label in np.unique(labels):
        indices = np.flatnonzero(labels == label)
        rng.shuffle(indices)
        if indices.size == 1:
            (first if len(first) <= len(second) else second).append(int(indices[0]))
            continue
        count = int(np.clip(round(float(fraction) * indices.size), 1, indices.size - 1))
        first.extend(int(index) for index in indices[:count])
        second.extend(int(index) for index in indices[count:])
    if not first or not second:
        permutation = rng.permutation(labels.size)
        count = int(np.clip(round(float(fraction) * labels.size), 1, labels.size - 1))
        first = [int(index) for index in permutation[:count]]
        second = [int(index) for index in permutation[count:]]
    return np.asarray(sorted(first), dtype=np.int64), np.asarray(sorted(second), dtype=np.int64)


def split_calibration_client_views(
    clients: list,
    fraction: float = 0.5,
    seed: int = 0,
) -> tuple[list, list, list[dict]]:
    """Create disjoint stratified selection and certification client views."""

    selection_views: list = []
    certification_views: list = []
    rows: list[dict] = []
    for client_index, client in enumerate(clients):
        first, second = _stratified_calibration_partition(
            client.y_train,
            fraction=float(fraction),
            seed=int(seed) * 1009 + client_index,
        )
        selection_views.append(
            SimpleNamespace(
                x_train=client.x_train[first],
                y_train=client.y_train[first],
                client_id=client.client_id,
                domain=client.domain,
            )
        )
        certification_views.append(
            SimpleNamespace(
                x_train=client.x_train[second],
                y_train=client.y_train[second],
                client_id=client.client_id,
                domain=client.domain,
            )
        )
        rows.append(
            {
                "client_id": client.client_id,
                "domain": client.domain,
                "selection_size": int(first.size),
                "certification_size": int(second.size),
                "selection_fraction": float(fraction),
                "split_seed": int(seed) * 1009 + client_index,
            }
        )
    return selection_views, certification_views, rows


def select_disagreement_localized_routes(
    training_clients: list,
    selector_clients: list,
    eval_clients: list,
    base_weight: Array,
    anchor_adapters: list[LoRAAdapter],
    full_endpoints: list[LoRAAdapter],
    blockwise_endpoints: list[LoRAAdapter],
    full_control: JointPathAdmissionResult,
    ranks: list[int] | int,
    prototype_maps: dict | None = None,
    path: list[float] | str | None = None,
    quantiles: tuple[float, ...] = (0.0, 0.25, 0.5, 0.75),
    delta: float = 0.05,
    risk_tolerance: float = 0.0,
    seed: int = 0,
    dataset: str = "",
    heterogeneity_setting: str = "",
    round_id: int = 0,
    method: str = "FedAdapterManifold-DisagreementRoute",
    safety_reference: str = "full",
    calibration_shift_mode: str = "marginal",
    calibration_shift_bins: int = 2,
    calibration_shift_min_stratum_size: int = 16,
    candidate_search_mode: str = "calibration-grid",
) -> RoutedAdmissionResult:
    """Route only certified full/blockwise prediction disagreements.

    Thresholds are training-side quantiles of a fixed score combining margin
    advantage and predicted-class prototype affinity. In ``calibration-grid``
    mode, calibration labels certify the full path-by-threshold family with a
    simultaneous correction. In ``training-fixed`` mode, adapter-training data
    select one path and threshold before calibration is inspected, so the
    independent calibration split certifies a single fixed candidate. The
    latter is the search/certification-decoupled protocol used for finite-sample
    power audits. ``safety_reference='anchor'`` measures deployment safety
    directly against the declared anchor.
    """

    n = len(training_clients)
    if not (
        len(selector_clients) == n
        and len(eval_clients) == n
        and len(anchor_adapters) == n
        and len(full_endpoints) == n
        and len(blockwise_endpoints) == n
        and len(full_control.client_adapters) == n
    ):
        raise ValueError("training, selector, evaluation, adapter, and control lists must align")
    rank_list = [int(ranks)] * n if isinstance(ranks, int) else [int(value) for value in ranks]
    if len(rank_list) != n:
        raise ValueError(f"Expected {n} ranks, got {len(rank_list)}")
    safety_reference = str(safety_reference).strip().lower()
    if safety_reference not in {"full", "anchor", "both"}:
        raise ValueError("safety_reference must be 'full', 'anchor', or 'both'")
    calibration_shift_mode = str(calibration_shift_mode).strip().lower()
    if calibration_shift_mode not in {"marginal", "confidence-stratified"}:
        raise ValueError("calibration_shift_mode must be 'marginal' or 'confidence-stratified'")
    candidate_search_mode = str(candidate_search_mode).strip().lower()
    if candidate_search_mode not in {"calibration-grid", "training-fixed"}:
        raise ValueError(
            "candidate_search_mode must be 'calibration-grid' or 'training-fixed'"
        )
    positive_steps = [value for value in _parse_path(path) if value > 0.0]
    fixed_quantiles = tuple(float(np.clip(value, 0.0, 1.0)) for value in quantiles)
    if not positive_steps or not fixed_quantiles:
        raise ValueError("Positive path strengths and routing quantiles are required")
    if candidate_search_mode == "training-fixed":
        route_comparison_count = 1
        anchor_comparison_count = 1
    else:
        route_comparison_count = len(positive_steps) ** 2 * len(fixed_quantiles)
        anchor_comparison_count = route_comparison_count + len(positive_steps)
    comparison_count = route_comparison_count if safety_reference == "full" else anchor_comparison_count

    metrics_rows: list[dict] = []
    admission_rows: list[dict] = []
    routing_rows: list[dict] = []
    for client_index, (training, selector, evaluator, anchor, block_endpoint, full_reference, rank) in enumerate(
        zip(
            training_clients,
            selector_clients,
            eval_clients,
            anchor_adapters,
            blockwise_endpoints,
            full_control.client_adapters,
            rank_list,
        )
    ):
        num_classes = int(base_weight.shape[0])
        prototypes = _routing_prototype_matrix(
            training,
            prototype_maps,
            num_classes=num_classes,
        )
        full_train_logits = predict_with_weight(training.x_train, full_reference.weight(base_weight))
        full_selector_logits = predict_with_weight(selector.x_train, full_reference.weight(base_weight))
        full_selector_errors = (
            full_selector_logits.argmax(axis=1) != selector.y_train.astype(np.int64)
        ).astype(np.float64)
        full_selector_losses = cross_entropy_per_sample(
            full_selector_logits,
            selector.y_train.astype(np.int64),
        )
        anchor_selector_logits = predict_with_weight(
            selector.x_train,
            anchor.weight(base_weight),
        )
        anchor_selector_errors = (
            anchor_selector_logits.argmax(axis=1) != selector.y_train.astype(np.int64)
        ).astype(np.float64)
        anchor_selector_losses = cross_entropy_per_sample(
            anchor_selector_logits,
            selector.y_train.astype(np.int64),
        )
        calibration_strata = None
        expected_calibration_strata = None
        calibration_stratum_count = 1
        if calibration_shift_mode == "confidence-stratified":
            anchor_train_logits = predict_with_weight(
                training.x_train,
                anchor.weight(base_weight),
            )
            train_confidence = np.max(softmax(anchor_train_logits), axis=1)
            selector_confidence = np.max(softmax(anchor_selector_logits), axis=1)
            bin_count = max(int(calibration_shift_bins), 1)
            quantiles = np.linspace(0.0, 1.0, bin_count + 1, dtype=np.float64)[1:-1]
            thresholds = np.unique(np.quantile(train_confidence, quantiles)) if quantiles.size else np.zeros(0)
            calibration_strata = np.digitize(selector_confidence, thresholds, right=False)
            expected_calibration_strata = np.arange(len(thresholds) + 1, dtype=np.int64)
            calibration_stratum_count = int(np.unique(calibration_strata).size)
        training_fixed_spec = None
        if candidate_search_mode == "training-fixed":
            training_search_records = []
            for strength in positive_steps:
                block_adapter = _interpolate(
                    anchor,
                    block_endpoint,
                    strength,
                    rank,
                    client_index,
                    "blockwise",
                    method,
                )
                block_train_logits = predict_with_weight(
                    training.x_train,
                    block_adapter.weight(base_weight),
                )
                score_parameters, thresholds = _fit_disagreement_score(
                    training.x_train,
                    full_train_logits,
                    block_train_logits,
                    prototypes,
                    fixed_quantiles,
                )
                train_score, train_disagreement = _disagreement_score(
                    training.x_train,
                    full_train_logits,
                    block_train_logits,
                    prototypes,
                    score_parameters,
                )
                for quantile, threshold in zip(fixed_quantiles, thresholds):
                    train_route = train_disagreement & (train_score >= float(threshold))
                    routed_train_logits = np.where(
                        train_route[:, None],
                        block_train_logits,
                        full_train_logits,
                    )
                    training_search_records.append(
                        {
                            "strength": float(strength),
                            "quantile": float(quantile),
                            "threshold": float(threshold),
                            "adapter": block_adapter,
                            "score_parameters": score_parameters,
                            "training_error": float(
                                np.mean(
                                    routed_train_logits.argmax(axis=1)
                                    != training.y_train.astype(np.int64)
                                )
                            ),
                            "training_loss": float(
                                np.mean(
                                    cross_entropy_per_sample(
                                        routed_train_logits,
                                        training.y_train.astype(np.int64),
                                    )
                                )
                            ),
                            "training_route_fraction": float(np.mean(train_route)),
                        }
                    )
            routed_records = [
                row for row in training_search_records if row["training_route_fraction"] > 0.0
            ]
            search_pool = routed_records if routed_records else training_search_records
            training_fixed_spec = min(
                search_pool,
                key=lambda row: (
                    row["training_error"],
                    row["training_loss"],
                    -row["training_route_fraction"],
                    -row["strength"],
                    row["quantile"],
                ),
            )
        full_metadata = full_control.per_client_metrics[client_index]
        full_anchor_mean, _, full_anchor_upper, full_anchor_details = (
            stratified_paired_risk_upper_bound(
                full_selector_errors,
                anchor_selector_errors,
                strata=calibration_strata,
                expected_strata=expected_calibration_strata,
                delta=delta,
                num_comparisons=anchor_comparison_count,
                min_stratum_size=calibration_shift_min_stratum_size,
            )
        )
        inherited_full_anchor_upper = float(
            full_metadata.get("certified_risk_upper_bound", full_anchor_upper)
        )
        anchor_full_mean, _, anchor_full_upper, anchor_full_details = (
            stratified_paired_risk_upper_bound(
                anchor_selector_errors,
                full_selector_errors,
                strata=calibration_strata,
                expected_strata=expected_calibration_strata,
                delta=delta,
                num_comparisons=route_comparison_count,
                min_stratum_size=calibration_shift_min_stratum_size,
            )
        )
        records: list[tuple[dict, LoRAAdapter | None, dict | None]] = [
            (
                {
                    "transport_family": "full_control",
                    "admission_strength": float(full_metadata["selected_admission_strength"]),
                    "routing_quantile": "",
                    "routing_threshold": "",
                    "paired_error_difference_vs_full": 0.0,
                    "paired_log_loss_difference_vs_full": 0.0,
                    "route_fraction_calibration": 0.0,
                    "disagreement_fraction_calibration": 0.0,
                    "harm_discordances_vs_full": 0,
                    "benefit_discordances_vs_full": 0,
                    "total_discordances_vs_full": 0,
                    "competitive_risk_upper_bound": 0.0,
                    "certified_competitive": True,
                    "paired_error_difference_vs_anchor": float(full_anchor_mean),
                    "paired_log_loss_difference_vs_anchor": float(
                        np.mean(full_selector_losses - anchor_selector_losses)
                    ),
                    "harm_discordances_vs_anchor": int(
                        full_anchor_details["harm_discordances"]
                    ),
                    "benefit_discordances_vs_anchor": int(
                        full_anchor_details["benefit_discordances"]
                    ),
                    "total_discordances_vs_anchor": int(
                        full_anchor_details["total_discordances"]
                    ),
                    "anchor_risk_upper_bound": inherited_full_anchor_upper,
                    "certified_anchor_safe": bool(
                        inherited_full_anchor_upper <= float(risk_tolerance) + 1e-12
                    ),
                    "calibration_minimum_stratum_size": int(
                        full_anchor_details["minimum_stratum_size"]
                    ),
                    "calibration_undersampled_strata": int(
                        full_anchor_details["undersampled_strata"]
                    ),
                    "calibration_worst_stratum": full_anchor_details["worst_stratum"],
                },
                None,
                None,
            ),
        ]
        if safety_reference in {"anchor", "both"}:
            records.append(
                (
                    {
                    "transport_family": "local_anchor",
                    "admission_strength": 0.0,
                    "routing_quantile": "",
                    "routing_threshold": "",
                    "paired_error_difference_vs_full": float(anchor_full_mean),
                    "paired_log_loss_difference_vs_full": float(
                        np.mean(anchor_selector_losses - full_selector_losses)
                    ),
                    "route_fraction_calibration": 0.0,
                    "disagreement_fraction_calibration": 0.0,
                    "harm_discordances_vs_full": int(
                        anchor_full_details["harm_discordances"]
                    ),
                    "benefit_discordances_vs_full": int(
                        anchor_full_details["benefit_discordances"]
                    ),
                    "total_discordances_vs_full": int(
                        anchor_full_details["total_discordances"]
                    ),
                    "competitive_risk_upper_bound": float(anchor_full_upper),
                    "certified_competitive": bool(
                        anchor_full_upper <= float(risk_tolerance) + 1e-12
                    ),
                    "paired_error_difference_vs_anchor": 0.0,
                    "paired_log_loss_difference_vs_anchor": 0.0,
                    "harm_discordances_vs_anchor": 0,
                    "benefit_discordances_vs_anchor": 0,
                    "total_discordances_vs_anchor": 0,
                    "anchor_risk_upper_bound": 0.0,
                    "certified_anchor_safe": True,
                    "calibration_minimum_stratum_size": int(
                        anchor_full_details["minimum_stratum_size"]
                    ),
                    "calibration_undersampled_strata": int(
                        anchor_full_details["undersampled_strata"]
                    ),
                    "calibration_worst_stratum": anchor_full_details["worst_stratum"],
                    },
                    None,
                    None,
                )
            )
        for strength in positive_steps:
            if (
                training_fixed_spec is not None
                and abs(float(strength) - float(training_fixed_spec["strength"])) > 1e-12
            ):
                continue
            block_adapter = _interpolate(
                anchor,
                block_endpoint,
                strength,
                rank,
                client_index,
                "blockwise",
                method,
            )
            block_train_logits = predict_with_weight(training.x_train, block_adapter.weight(base_weight))
            score_parameters, thresholds = _fit_disagreement_score(
                training.x_train,
                full_train_logits,
                block_train_logits,
                prototypes,
                fixed_quantiles,
            )
            threshold_pairs = list(zip(fixed_quantiles, thresholds))
            if training_fixed_spec is not None:
                score_parameters = training_fixed_spec["score_parameters"]
                threshold_pairs = [
                    (
                        float(training_fixed_spec["quantile"]),
                        float(training_fixed_spec["threshold"]),
                    )
                ]
            block_selector_logits = predict_with_weight(
                selector.x_train,
                block_adapter.weight(base_weight),
            )
            selector_score, selector_disagreement = _disagreement_score(
                selector.x_train,
                full_selector_logits,
                block_selector_logits,
                prototypes,
                score_parameters,
            )
            for quantile, threshold in threshold_pairs:
                route = selector_disagreement & (selector_score >= float(threshold))
                routed_logits = np.where(route[:, None], block_selector_logits, full_selector_logits)
                routed_errors = (
                    routed_logits.argmax(axis=1) != selector.y_train.astype(np.int64)
                ).astype(np.float64)
                routed_losses = cross_entropy_per_sample(
                    routed_logits,
                    selector.y_train.astype(np.int64),
                )
                mean, _, upper, details = paired_discordance_upper_bound(
                    routed_errors,
                    full_selector_errors,
                    delta=delta,
                    num_comparisons=route_comparison_count,
                )
                anchor_mean, _, anchor_upper, anchor_details = stratified_paired_risk_upper_bound(
                    routed_errors,
                    anchor_selector_errors,
                    strata=calibration_strata,
                    expected_strata=expected_calibration_strata,
                    delta=delta,
                    num_comparisons=anchor_comparison_count,
                    min_stratum_size=calibration_shift_min_stratum_size,
                )
                records.append(
                    (
                        {
                            "transport_family": "disagreement_blockwise",
                            "admission_strength": float(strength),
                            "routing_quantile": float(quantile),
                            "routing_threshold": float(threshold),
                            "paired_error_difference_vs_full": float(mean),
                            "paired_log_loss_difference_vs_full": float(
                                np.mean(routed_losses - full_selector_losses)
                            ),
                            "route_fraction_calibration": float(np.mean(route)),
                            "disagreement_fraction_calibration": float(
                                np.mean(selector_disagreement)
                            ),
                            "harm_discordances_vs_full": int(details["harm_discordances"]),
                            "benefit_discordances_vs_full": int(details["benefit_discordances"]),
                            "total_discordances_vs_full": int(details["total_discordances"]),
                            "competitive_risk_upper_bound": float(upper),
                            "certified_competitive": bool(
                                upper <= float(risk_tolerance) + 1e-12
                            ),
                            "paired_error_difference_vs_anchor": float(anchor_mean),
                            "paired_log_loss_difference_vs_anchor": float(
                                np.mean(routed_losses - anchor_selector_losses)
                            ),
                            "harm_discordances_vs_anchor": int(
                                anchor_details["harm_discordances"]
                            ),
                            "benefit_discordances_vs_anchor": int(
                                anchor_details["benefit_discordances"]
                            ),
                            "total_discordances_vs_anchor": int(
                                anchor_details["total_discordances"]
                            ),
                            "anchor_risk_upper_bound": float(anchor_upper),
                            "certified_anchor_safe": bool(
                                anchor_upper <= float(risk_tolerance) + 1e-12
                            ),
                            "calibration_minimum_stratum_size": int(
                                anchor_details["minimum_stratum_size"]
                            ),
                            "calibration_undersampled_strata": int(
                                anchor_details["undersampled_strata"]
                            ),
                            "calibration_worst_stratum": anchor_details["worst_stratum"],
                            "candidate_search_mode": candidate_search_mode,
                            "training_search_error": (
                                float(training_fixed_spec["training_error"])
                                if training_fixed_spec is not None
                                else ""
                            ),
                            "training_search_loss": (
                                float(training_fixed_spec["training_loss"])
                                if training_fixed_spec is not None
                                else ""
                            ),
                            "training_search_route_fraction": (
                                float(training_fixed_spec["training_route_fraction"])
                                if training_fixed_spec is not None
                                else ""
                            ),
                        },
                        block_adapter,
                        score_parameters,
                    )
                )
        if safety_reference == "both":
            admissible = [
                index
                for index, (record, _, _) in enumerate(records)
                if record["certified_anchor_safe"]
                and record["certified_competitive"]
                and float(record["paired_log_loss_difference_vs_full"]) <= 1e-12
            ]
        else:
            certificate_field = (
                "certified_competitive"
                if safety_reference == "full"
                else "certified_anchor_safe"
            )
            admissible = [
                index for index, (record, _, _) in enumerate(records) if record[certificate_field]
            ]
        selected_index = min(
            admissible,
            key=lambda index: (
                float(records[index][0]["paired_error_difference_vs_full"]),
                float(records[index][0]["paired_log_loss_difference_vs_full"]),
                -float(records[index][0]["route_fraction_calibration"]),
            ),
        )
        selected_record, selected_block, selected_parameters = records[selected_index]
        full_test_logits = predict_with_weight(evaluator.x_test, full_reference.weight(base_weight))
        anchor_test_logits = predict_with_weight(evaluator.x_test, anchor.weight(base_weight))
        if selected_record["transport_family"] == "local_anchor":
            test_logits = anchor_test_logits
            test_route = np.zeros(evaluator.y_test.shape[0], dtype=bool)
            test_disagreement = np.zeros(evaluator.y_test.shape[0], dtype=bool)
        elif selected_block is None or selected_parameters is None:
            test_logits = full_test_logits
            test_route = np.zeros(evaluator.y_test.shape[0], dtype=bool)
            test_disagreement = np.zeros(evaluator.y_test.shape[0], dtype=bool)
        else:
            block_test_logits = predict_with_weight(
                evaluator.x_test,
                selected_block.weight(base_weight),
            )
            test_score, test_disagreement = _disagreement_score(
                evaluator.x_test,
                full_test_logits,
                block_test_logits,
                prototypes,
                selected_parameters,
            )
            test_route = test_disagreement & (
                test_score >= float(selected_record["routing_threshold"])
            )
            test_logits = np.where(test_route[:, None], block_test_logits, full_test_logits)
        test_losses = cross_entropy_per_sample(test_logits, evaluator.y_test.astype(np.int64))
        test_accuracy = float(
            np.mean(test_logits.argmax(axis=1) == evaluator.y_test.astype(np.int64))
        )
        full_test_losses = cross_entropy_per_sample(
            full_test_logits,
            evaluator.y_test.astype(np.int64),
        )
        anchor_test_losses = cross_entropy_per_sample(
            anchor_test_logits,
            evaluator.y_test.astype(np.int64),
        )
        full_test_accuracy = float(
            np.mean(full_test_logits.argmax(axis=1) == evaluator.y_test.astype(np.int64))
        )
        anchor_test_accuracy = float(
            np.mean(anchor_test_logits.argmax(axis=1) == evaluator.y_test.astype(np.int64))
        )
        if safety_reference == "full":
            selected_risk_upper_bound = selected_record["competitive_risk_upper_bound"]
        elif safety_reference == "anchor":
            selected_risk_upper_bound = selected_record["anchor_risk_upper_bound"]
        else:
            selected_risk_upper_bound = max(
                float(selected_record["competitive_risk_upper_bound"]),
                float(selected_record["anchor_risk_upper_bound"]),
            )
        metrics_rows.append(
            {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": evaluator.client_id,
                "domain": evaluator.domain,
                "accuracy": test_accuracy,
                "loss": float(np.mean(test_losses)),
                "rank": int(rank),
                "selected_transport_family": str(selected_record["transport_family"]),
                "selected_admission_strength": float(selected_record["admission_strength"]),
                "certified_risk_upper_bound": float(
                    selected_risk_upper_bound
                ),
                "competitive_reference": str(full_metadata["method"]),
                "safety_reference": safety_reference,
                "calibration_shift_mode": calibration_shift_mode,
                "candidate_search_mode": candidate_search_mode,
                "calibration_shift_strata": calibration_stratum_count,
                "calibration_minimum_stratum_size": int(
                    selected_record["calibration_minimum_stratum_size"]
                ),
                "calibration_undersampled_strata": int(
                    selected_record["calibration_undersampled_strata"]
                ),
                "calibration_worst_stratum": selected_record["calibration_worst_stratum"],
                "accuracy_gain_vs_full": float(test_accuracy - full_test_accuracy),
                "accuracy_gain_vs_anchor": float(test_accuracy - anchor_test_accuracy),
                "loss_difference_vs_full": float(np.mean(test_losses - full_test_losses)),
                "loss_difference_vs_anchor": float(
                    np.mean(test_losses - anchor_test_losses)
                ),
                "route_fraction": float(np.mean(test_route)),
                "disagreement_fraction": float(np.mean(test_disagreement)),
            }
        )
        routing_rows.append(
            {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": evaluator.client_id,
                "domain": evaluator.domain,
                "selected_transport_family": str(selected_record["transport_family"]),
                "selected_admission_strength": float(selected_record["admission_strength"]),
                "selected_routing_quantile": selected_record["routing_quantile"],
                "selected_routing_threshold": selected_record["routing_threshold"],
                "calibration_route_fraction": float(selected_record["route_fraction_calibration"]),
                "calibration_disagreement_fraction": float(
                    selected_record["disagreement_fraction_calibration"]
                ),
                "test_route_fraction": float(np.mean(test_route)),
                "test_disagreement_fraction": float(np.mean(test_disagreement)),
                "selector_num_comparisons": int(comparison_count),
                "safety_reference": safety_reference,
                "calibration_shift_mode": calibration_shift_mode,
                "candidate_search_mode": candidate_search_mode,
                "calibration_shift_strata": calibration_stratum_count,
                "calibration_minimum_stratum_size": int(
                    selected_record["calibration_minimum_stratum_size"]
                ),
                "calibration_undersampled_strata": int(
                    selected_record["calibration_undersampled_strata"]
                ),
                "calibration_worst_stratum": selected_record["calibration_worst_stratum"],
            }
        )
        for record_index, (record, _, _) in enumerate(records):
            admission_rows.append(
                {
                    "method": method,
                    "seed": int(seed),
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": int(round_id),
                    "client_id": evaluator.client_id,
                    "domain": evaluator.domain,
                    "selection_split": "heldout_calibration",
                    "threshold_source": "adapter_training_quantiles",
                    "routing_score": "standardized_margin_plus_prototype_advantage",
                    "selector_delta": float(delta),
                    "selector_num_comparisons": int(comparison_count),
                    "route_selector_num_comparisons": int(route_comparison_count),
                    "anchor_selector_num_comparisons": int(anchor_comparison_count),
                    "risk_tolerance": float(risk_tolerance),
                    "safety_reference": safety_reference,
                    "calibration_shift_mode": calibration_shift_mode,
                    "candidate_search_mode": candidate_search_mode,
                    "calibration_shift_strata": calibration_stratum_count,
                    "full_control_family": str(full_metadata["selected_transport_family"]),
                    "full_control_strength": float(full_metadata["selected_admission_strength"]),
                    **record,
                    "selected": bool(record_index == selected_index),
                }
            )
    return RoutedAdmissionResult(metrics_rows, admission_rows, routing_rows)


def select_dual_certified_prototype_bank_routes(
    selection_clients: list,
    certification_clients: list,
    eval_clients: list,
    base_weight: Array,
    anchor_adapters: list[LoRAAdapter],
    full_control: JointPathAdmissionResult,
    bank_families: dict[str, list[LoRAAdapter]],
    donor_costs: Array,
    donor_support: Array,
    ranks: list[int] | int,
    prototype_maps: dict | None = None,
    threshold_quantiles: tuple[float, ...] = (0.0, 0.25, 0.5, 0.75),
    delta: float = 0.05,
    risk_tolerance: float = 0.02,
    competitive_tolerance: float | None = None,
    compatibility_cost_weight: float = 0.25,
    seed: int = 0,
    dataset: str = "",
    heterogeneity_setting: str = "",
    round_id: int = 0,
    method: str = "FedAdapterManifold-DualCertifiedPrototypeBank",
) -> RoutedAdmissionResult:
    """Route among donor-specific adapters with a fixed prototype policy.

    The selection split fixes one threshold for the prototype advantage of a
    donor-specific adapter over the receiver.  The untouched certification
    split then tests the resulting complete policy against both Local-LoRA and
    the same-capacity full-update control.  Donor identity is therefore an
    input-conditioned bank decision, not a post-hoc model choice.
    """

    n = len(selection_clients)
    if not (
        len(certification_clients) == n
        and len(eval_clients) == n
        and len(anchor_adapters) == n
        and len(full_control.client_adapters) == n
    ):
        raise ValueError("selection, certification, evaluation, and adapter lists must align")
    if not bank_families or any(len(adapters) != n for adapters in bank_families.values()):
        raise ValueError("bank_families must contain one adapter per receiver")
    costs = np.asarray(donor_costs, dtype=np.float64)
    support = np.asarray(donor_support, dtype=bool)
    if costs.shape != (n, n) or support.shape != (n, n):
        raise ValueError("donor_costs and donor_support must be square client matrices")
    rank_list = [int(ranks)] * n if isinstance(ranks, int) else [int(value) for value in ranks]
    if len(rank_list) != n:
        raise ValueError(f"Expected {n} ranks, got {len(rank_list)}")
    quantiles = tuple(float(np.clip(value, 0.0, 1.0)) for value in threshold_quantiles)
    if not quantiles:
        raise ValueError("At least one prototype routing quantile is required")
    competitive_budget = (
        float(risk_tolerance) if competitive_tolerance is None else float(competitive_tolerance)
    )
    comparison_count = 2
    num_classes = int(base_weight.shape[0])
    prototype_bank = [
        _routing_prototype_matrix(client, prototype_maps, num_classes)
        for client in selection_clients
    ]

    metrics_rows: list[dict] = []
    admission_rows: list[dict] = []
    routing_rows: list[dict] = []
    family_names = sorted(bank_families)
    donor_indices = [int(name.rsplit("_", 1)[-1]) for name in family_names]

    for receiver_index, (selection, certification, evaluator, anchor, full_reference, rank) in enumerate(
        zip(
            selection_clients,
            certification_clients,
            eval_clients,
            anchor_adapters,
            full_control.client_adapters,
            rank_list,
        )
    ):
        candidates = [bank_families[name][receiver_index] for name in family_names]

        def policy_logits(x: Array, threshold: float) -> tuple[Array, Array, Array, Array]:
            full_logits = predict_with_weight(x, full_reference.weight(base_weight))
            predicted_class = full_logits.argmax(axis=1)
            receiver_proto = prototype_bank[receiver_index][predicted_class]
            receiver_distance = np.mean((np.asarray(x) - receiver_proto) ** 2, axis=1)
            raw_advantages = np.full((len(candidates), x.shape[0]), np.nan, dtype=np.float64)
            candidate_logits = []
            for family_index, (donor_index, candidate) in enumerate(zip(donor_indices, candidates)):
                logits = predict_with_weight(x, candidate.weight(base_weight))
                candidate_logits.append(logits)
                if donor_index == receiver_index or not support[receiver_index, donor_index]:
                    continue
                donor_proto = prototype_bank[donor_index][predicted_class]
                donor_distance = np.mean((np.asarray(x) - donor_proto) ** 2, axis=1)
                raw_advantages[family_index] = receiver_distance - donor_distance
            valid = np.isfinite(raw_advantages)
            finite_values = np.where(valid, raw_advantages, np.nan)
            scale = np.nanstd(finite_values, axis=0)
            scale = np.where(np.isfinite(scale) & (scale > 1e-8), scale, 1.0)
            advantages = raw_advantages / scale[None, :]
            for family_index, donor_index in enumerate(donor_indices):
                if donor_index == receiver_index or not support[receiver_index, donor_index]:
                    advantages[family_index] = -np.inf
                else:
                    advantages[family_index] -= (
                        max(float(compatibility_cost_weight), 0.0)
                        * float(costs[receiver_index, donor_index])
                    )
            best_family = np.argmax(advantages, axis=0)
            best_advantage = advantages[best_family, np.arange(x.shape[0])]
            route = np.isfinite(best_advantage) & (best_advantage >= float(threshold))
            routed = full_logits.copy()
            for family_index, logits in enumerate(candidate_logits):
                mask = route & (best_family == family_index)
                routed[mask] = logits[mask]
            return routed, route, best_family, best_advantage

        _, _, _, selection_advantage = policy_logits(selection.x_train, np.inf)
        finite_advantage = selection_advantage[np.isfinite(selection_advantage)]
        thresholds = (
            np.quantile(finite_advantage, np.asarray(quantiles, dtype=np.float64))
            if finite_advantage.size
            else np.full(len(quantiles), np.inf, dtype=np.float64)
        )
        selection_records = []
        for quantile, threshold in zip(quantiles, thresholds):
            logits, route, _, _ = policy_logits(selection.x_train, float(threshold))
            losses = cross_entropy_per_sample(logits, selection.y_train.astype(np.int64))
            errors = (logits.argmax(axis=1) != selection.y_train.astype(np.int64)).astype(np.float64)
            selection_records.append(
                (float(errors.mean()), float(losses.mean()), -float(route.mean()), quantile, float(threshold))
            )
        selected_selection = min(selection_records)
        _, _, _, selected_quantile, selected_threshold = selected_selection

        routed_cert_logits, cert_route, cert_family, _ = policy_logits(
            certification.x_train,
            selected_threshold,
        )
        full_cert_logits = predict_with_weight(
            certification.x_train,
            full_reference.weight(base_weight),
        )
        anchor_cert_logits = predict_with_weight(
            certification.x_train,
            anchor.weight(base_weight),
        )
        labels = certification.y_train.astype(np.int64)
        routed_errors = (routed_cert_logits.argmax(axis=1) != labels).astype(np.float64)
        full_errors = (full_cert_logits.argmax(axis=1) != labels).astype(np.float64)
        anchor_errors = (anchor_cert_logits.argmax(axis=1) != labels).astype(np.float64)
        routed_losses = cross_entropy_per_sample(routed_cert_logits, labels)
        full_losses = cross_entropy_per_sample(full_cert_logits, labels)
        anchor_losses = cross_entropy_per_sample(anchor_cert_logits, labels)
        versus_anchor = paired_discordance_upper_bound(
            routed_errors,
            anchor_errors,
            delta=delta,
            num_comparisons=comparison_count,
        )
        versus_full = paired_discordance_upper_bound(
            routed_errors,
            full_errors,
            delta=delta,
            num_comparisons=comparison_count,
        )
        log_loss_vs_full = float(np.mean(routed_losses - full_losses))
        certified_anchor = bool(versus_anchor[2] <= float(risk_tolerance) + 1e-12)
        certified_full = bool(
            versus_full[0] <= 1e-12
            and versus_full[2] <= competitive_budget + 1e-12
            and log_loss_vs_full <= 1e-12
        )
        deploy_route = bool(certified_anchor and certified_full)

        if deploy_route:
            test_logits, test_route, test_family, _ = policy_logits(
                evaluator.x_test,
                selected_threshold,
            )
            selected_family = "prototype_bank"
        else:
            test_logits = predict_with_weight(evaluator.x_test, full_reference.weight(base_weight))
            test_route = np.zeros(evaluator.y_test.size, dtype=bool)
            test_family = np.zeros(evaluator.y_test.size, dtype=np.int64)
            selected_family = "full_control"
        test_labels = evaluator.y_test.astype(np.int64)
        test_losses = cross_entropy_per_sample(test_logits, test_labels)
        test_accuracy = float(np.mean(test_logits.argmax(axis=1) == test_labels))
        full_test_logits = predict_with_weight(evaluator.x_test, full_reference.weight(base_weight))
        anchor_test_logits = predict_with_weight(evaluator.x_test, anchor.weight(base_weight))
        full_accuracy = float(np.mean(full_test_logits.argmax(axis=1) == test_labels))
        anchor_accuracy = float(np.mean(anchor_test_logits.argmax(axis=1) == test_labels))
        metrics_rows.append(
            {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": evaluator.client_id,
                "domain": evaluator.domain,
                "accuracy": test_accuracy,
                "loss": float(test_losses.mean()),
                "rank": int(rank),
                "selected_transport_family": selected_family,
                "selected_routing_quantile": float(selected_quantile),
                "selected_routing_threshold": float(selected_threshold),
                "certified_risk_upper_bound": float(max(versus_anchor[2], versus_full[2])),
                "accuracy_gain_vs_full": float(test_accuracy - full_accuracy),
                "accuracy_gain_vs_anchor": float(test_accuracy - anchor_accuracy),
                "route_fraction": float(test_route.mean()),
            }
        )
        admission_rows.append(
            {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": evaluator.client_id,
                "domain": evaluator.domain,
                "selection_split": "heldout_calibration_selection",
                "certification_split": "heldout_calibration_certification",
                "selector_num_comparisons": comparison_count,
                "selector_delta": float(delta),
                "risk_tolerance": float(risk_tolerance),
                "competitive_tolerance": competitive_budget,
                "compatibility_cost_weight": float(compatibility_cost_weight),
                "selected_routing_quantile": float(selected_quantile),
                "selected_routing_threshold": float(selected_threshold),
                "route_fraction_calibration": float(cert_route.mean()),
                "paired_error_difference_vs_full": float(versus_full[0]),
                "paired_log_loss_difference_vs_full": log_loss_vs_full,
                "competitive_risk_upper_bound": float(versus_full[2]),
                "paired_error_difference_vs_anchor": float(versus_anchor[0]),
                "paired_log_loss_difference_vs_anchor": float(
                    np.mean(routed_losses - anchor_losses)
                ),
                "anchor_risk_upper_bound": float(versus_anchor[2]),
                "certified_competitive": certified_full,
                "certified_anchor_safe": certified_anchor,
                "selected_transport_family": selected_family,
            }
        )
        family_counts = np.bincount(
            test_family[test_route],
            minlength=len(family_names),
        )
        for family_index, (family, donor_index) in enumerate(zip(family_names, donor_indices)):
            routing_rows.append(
                {
                    "method": method,
                    "seed": int(seed),
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": int(round_id),
                    "client_id": evaluator.client_id,
                    "domain": evaluator.domain,
                    "bank_family": family,
                    "donor_index": donor_index,
                    "selected_transport_family": selected_family,
                    "test_routed_samples": int(family_counts[family_index]),
                    "test_route_fraction": float(
                        family_counts[family_index] / max(test_labels.size, 1)
                    ),
                }
            )
    return RoutedAdmissionResult(metrics_rows, admission_rows, routing_rows)


def joint_path_comparison_count(path: list[float] | str | None, family_count: int) -> int:
    """Return the predeclared family-by-positive-path multiplicity."""

    positive_steps = [value for value in _parse_path(path) if value > 0.0]
    return max(len(positive_steps) * max(int(family_count), 1), 1)


def paired_discordance_upper_bound(
    candidate_errors: Array,
    anchor_errors: Array,
    delta: float,
    num_comparisons: int = 1,
) -> tuple[float, float, float, dict]:
    """Exact paired-classification upper bound for candidate excess risk.

    Let ``p+`` denote candidate-harm discordance and ``p-`` candidate-benefit
    discordance.  Conditional on discordance, the observed harm count is
    binomial.  Clopper--Pearson bounds on its conditional probability and on
    the discordance mass yield a finite-sample upper bound on ``p+ - p-``.
    """

    candidate = np.asarray(candidate_errors, dtype=np.float64).reshape(-1)
    anchor = np.asarray(anchor_errors, dtype=np.float64).reshape(-1)
    if candidate.shape != anchor.shape:
        raise ValueError("candidate_errors and anchor_errors must have the same shape")
    finite = np.isfinite(candidate) & np.isfinite(anchor)
    candidate = candidate[finite]
    anchor = anchor[finite]
    n = int(candidate.size)
    if n == 0:
        details = {
            "harm_discordances": 0,
            "benefit_discordances": 0,
            "total_discordances": 0,
            "discordance_rate_lower": 0.0,
            "discordance_rate_upper": 1.0,
            "conditional_harm_upper": 1.0,
        }
        return float("inf"), float("inf"), float("inf"), details
    harm = int(np.sum((candidate > 0.5) & (anchor <= 0.5)))
    benefit = int(np.sum((candidate <= 0.5) & (anchor > 0.5)))
    discordant = harm + benefit
    mean = float((harm - benefit) / n)
    adjusted = float(np.clip(delta / max(int(num_comparisons), 1), 1e-12, 1.0))
    component_alpha = adjusted / 2.0
    discordance_lower = _clopper_pearson_lower(discordant, n, component_alpha)
    discordance_upper = _clopper_pearson_upper(discordant, n, component_alpha)
    if discordant == 0:
        conditional_harm_upper = 1.0
        upper = discordance_upper
    else:
        conditional_harm_upper = _clopper_pearson_upper(harm, discordant, component_alpha)
        signed_upper = 2.0 * conditional_harm_upper - 1.0
        if signed_upper < 0.0:
            upper = discordance_lower * signed_upper
        else:
            upper = discordance_upper * signed_upper
    margin = float(upper - mean)
    details = {
        "harm_discordances": harm,
        "benefit_discordances": benefit,
        "total_discordances": discordant,
        "discordance_rate_lower": float(discordance_lower),
        "discordance_rate_upper": float(discordance_upper),
        "conditional_harm_upper": float(conditional_harm_upper),
    }
    return mean, margin, float(upper), details


def stratified_paired_risk_upper_bound(
    candidate_errors: Array,
    anchor_errors: Array,
    strata: Array | None,
    delta: float,
    num_comparisons: int = 1,
    min_stratum_size: int = 16,
    expected_strata: Array | None = None,
) -> tuple[float, float, float, dict]:
    """Bound excess error under arbitrary shifts in predeclared stratum mass.

    With ``strata=None`` this is exactly the marginal paired-discordance
    certificate. Otherwise, a simultaneous bound is built inside every
    observed stratum and the largest conditional upper bound is returned.
    Any target distribution that only changes the mixture weights of these
    strata has excess risk no larger than that maximum. An undersampled
    stratum makes the certificate unresolved and forces an anchored caller to
    fall back instead of silently assuming calibration representativeness.
    """

    candidate = np.asarray(candidate_errors, dtype=np.float64).reshape(-1)
    anchor = np.asarray(anchor_errors, dtype=np.float64).reshape(-1)
    if candidate.shape != anchor.shape:
        raise ValueError("candidate_errors and anchor_errors must have the same shape")
    if strata is None:
        mean, margin, upper, details = paired_discordance_upper_bound(
            candidate,
            anchor,
            delta=delta,
            num_comparisons=num_comparisons,
        )
        return mean, margin, upper, {
            **details,
            "stratified": False,
            "stratum_count": 1,
            "minimum_stratum_size": int(candidate.size),
            "undersampled_strata": 0,
            "worst_stratum": 0,
        }

    groups = np.asarray(strata).reshape(-1)
    if groups.shape != candidate.shape:
        raise ValueError("strata must align with candidate_errors")
    finite = np.isfinite(candidate) & np.isfinite(anchor) & np.isfinite(groups.astype(np.float64))
    candidate = candidate[finite]
    anchor = anchor[finite]
    groups = groups[finite]
    observed = np.unique(groups)
    unique = (
        np.asarray(expected_strata).reshape(-1)
        if expected_strata is not None
        else observed
    )
    if unique.size == 0:
        return float("inf"), float("inf"), float("inf"), {
            "harm_discordances": 0,
            "benefit_discordances": 0,
            "total_discordances": 0,
            "stratified": True,
            "stratum_count": 0,
            "minimum_stratum_size": 0,
            "undersampled_strata": 1,
            "worst_stratum": "",
        }

    simultaneous_comparisons = max(int(num_comparisons), 1) * int(unique.size)
    conditional = []
    sizes = []
    for group in unique:
        mask = groups == group
        size = int(mask.sum())
        sizes.append(size)
        if size == 0:
            conditional.append(
                {
                    "group": group.item() if hasattr(group, "item") else group,
                    "size": 0,
                    "mean": float("inf"),
                    "margin": float("inf"),
                    "upper": float("inf"),
                    "harm_discordances": 0,
                    "benefit_discordances": 0,
                    "total_discordances": 0,
                    "discordance_rate_lower": 0.0,
                    "discordance_rate_upper": 1.0,
                    "conditional_harm_upper": 1.0,
                }
            )
            continue
        mean, margin, upper, details = paired_discordance_upper_bound(
            candidate[mask],
            anchor[mask],
            delta=delta,
            num_comparisons=simultaneous_comparisons,
        )
        conditional.append(
            {
                "group": group.item() if hasattr(group, "item") else group,
                "size": size,
                "mean": float(mean),
                "margin": float(margin),
                "upper": float(upper),
                **details,
            }
        )
    undersampled = [row for row in conditional if row["size"] < max(int(min_stratum_size), 1)]
    global_mean = float(np.mean(candidate - anchor)) if candidate.size else float("inf")
    worst = max(conditional, key=lambda row: row["upper"])
    robust_upper = float("inf") if undersampled else float(worst["upper"])
    details = {
        "harm_discordances": int(sum(row["harm_discordances"] for row in conditional)),
        "benefit_discordances": int(sum(row["benefit_discordances"] for row in conditional)),
        "total_discordances": int(sum(row["total_discordances"] for row in conditional)),
        "stratified": True,
        "stratum_count": int(unique.size),
        "minimum_stratum_size": int(min(sizes)),
        "undersampled_strata": int(len(undersampled)),
        "worst_stratum": worst["group"],
        "worst_stratum_mean": float(worst["mean"]),
        "worst_stratum_upper": float(worst["upper"]),
        "stratum_details": conditional,
    }
    return global_mean, float(robust_upper - global_mean), robust_upper, details


def _orthonormal_basis(matrix: Array) -> Array:
    u, singular_values, _ = np.linalg.svd(np.asarray(matrix, dtype=np.float64), full_matrices=False)
    if singular_values.size == 0:
        return np.zeros((matrix.shape[0], 0), dtype=np.float64)
    tolerance = np.finfo(np.float64).eps * max(matrix.shape) * max(float(singular_values[0]), 1.0)
    rank = int(np.sum(singular_values > tolerance))
    return u[:, :rank]


def _parse_path(path: list[float] | str | None) -> list[float]:
    if path is None or path == "":
        values = [0.0, 0.25, 0.5, 0.75, 1.0]
    elif isinstance(path, str):
        values = [float(part.strip()) for part in path.split(",") if part.strip()]
    else:
        values = [float(value) for value in path]
    return sorted({float(np.clip(value, 0.0, 1.0)) for value in values} | {0.0, 1.0})


def _interpolate(
    anchor: LoRAAdapter,
    endpoint: LoRAAdapter,
    strength: float,
    rank: int,
    client_index: int,
    family: str,
    method: str,
) -> LoRAAdapter:
    strength = float(np.clip(strength, 0.0, 1.0))
    delta = (1.0 - strength) * anchor.delta() + strength * endpoint.delta()
    return LoRAAdapter.from_delta(
        delta,
        rank=int(rank),
        alpha=float(rank),
        name=f"{method}-{family}-client-{client_index}-strength-{strength:.3f}",
    )


def _routing_prototype_matrix(client, prototype_maps: dict | None, num_classes: int) -> Array:
    x = np.asarray(client.x_train, dtype=np.float64)
    y = np.asarray(client.y_train, dtype=np.int64)
    global_mean = x.mean(axis=0) if x.shape[0] else np.zeros(x.shape[1], dtype=np.float64)
    matrix = np.repeat(global_mean[None, :], int(num_classes), axis=0)
    for cls in range(int(num_classes)):
        mask = y == cls
        if np.any(mask):
            matrix[cls] = x[mask].mean(axis=0)
    mapping = None
    if prototype_maps:
        for key in (client.client_id, str(client.client_id)):
            if key in prototype_maps:
                mapping = prototype_maps[key]
                break
    if isinstance(mapping, dict):
        for cls in range(int(num_classes)):
            value = mapping.get(cls, mapping.get(str(cls)))
            if value is None:
                continue
            vector = np.asarray(value, dtype=np.float64).reshape(-1)
            if vector.shape == (x.shape[1],) and np.all(np.isfinite(vector)):
                matrix[cls] = vector
    return matrix


def _fit_disagreement_score(
    x: Array,
    full_logits: Array,
    block_logits: Array,
    prototypes: Array,
    quantiles: tuple[float, ...],
) -> tuple[dict, Array]:
    raw_margin, raw_prototype, disagreement = _raw_disagreement_scores(
        x,
        full_logits,
        block_logits,
        prototypes,
    )
    mask = disagreement if np.any(disagreement) else np.ones(disagreement.shape[0], dtype=bool)
    margin_mean = float(np.mean(raw_margin[mask]))
    prototype_mean = float(np.mean(raw_prototype[mask]))
    margin_scale = max(float(np.std(raw_margin[mask])), 1e-8)
    prototype_scale = max(float(np.std(raw_prototype[mask])), 1e-8)
    parameters = {
        "margin_mean": margin_mean,
        "margin_scale": margin_scale,
        "prototype_mean": prototype_mean,
        "prototype_scale": prototype_scale,
    }
    score = 0.5 * (
        (raw_margin - margin_mean) / margin_scale
        + (raw_prototype - prototype_mean) / prototype_scale
    )
    if np.any(disagreement):
        thresholds = np.quantile(score[disagreement], np.asarray(quantiles, dtype=np.float64))
    else:
        thresholds = np.full(len(quantiles), np.inf, dtype=np.float64)
    return parameters, np.asarray(thresholds, dtype=np.float64)


def _disagreement_score(
    x: Array,
    full_logits: Array,
    block_logits: Array,
    prototypes: Array,
    parameters: dict,
) -> tuple[Array, Array]:
    raw_margin, raw_prototype, disagreement = _raw_disagreement_scores(
        x,
        full_logits,
        block_logits,
        prototypes,
    )
    score = 0.5 * (
        (raw_margin - float(parameters["margin_mean"])) / float(parameters["margin_scale"])
        + (raw_prototype - float(parameters["prototype_mean"]))
        / float(parameters["prototype_scale"])
    )
    return score, disagreement


def _raw_disagreement_scores(
    x: Array,
    full_logits: Array,
    block_logits: Array,
    prototypes: Array,
) -> tuple[Array, Array, Array]:
    full_logits = np.asarray(full_logits, dtype=np.float64)
    block_logits = np.asarray(block_logits, dtype=np.float64)
    full_prediction = full_logits.argmax(axis=1)
    block_prediction = block_logits.argmax(axis=1)
    disagreement = full_prediction != block_prediction
    full_margin = _top_two_margin(full_logits)
    block_margin = _top_two_margin(block_logits)
    features = np.asarray(x, dtype=np.float64)
    full_distance = np.mean((features - prototypes[full_prediction]) ** 2, axis=1)
    block_distance = np.mean((features - prototypes[block_prediction]) ** 2, axis=1)
    return block_margin - full_margin, full_distance - block_distance, disagreement


def _top_two_margin(logits: Array) -> Array:
    values = np.asarray(logits, dtype=np.float64)
    if values.ndim != 2 or values.shape[1] < 2:
        raise ValueError("Routing logits must have at least two classes")
    top_two = np.partition(values, kth=values.shape[1] - 2, axis=1)[:, -2:]
    return np.max(top_two, axis=1) - np.min(top_two, axis=1)


def _empirical_bernstein(
    differences: Array,
    delta: float,
    num_comparisons: int,
) -> tuple[float, float, float]:
    values = np.asarray(differences, dtype=np.float64).reshape(-1)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return float("inf"), float("inf"), float("inf")
    mean = float(values.mean())
    if values.size <= 1:
        return mean, float("inf"), float("inf")
    variance = float(values.var(ddof=1))
    adjusted_delta = float(np.clip(delta / max(int(num_comparisons), 1), 1e-12, 1.0))
    log_term = float(np.log(3.0 / adjusted_delta))
    margin = float(
        np.sqrt(2.0 * variance * log_term / float(values.size))
        + 6.0 * log_term / float(values.size)
    )
    return mean, margin, mean + margin


def _clopper_pearson_lower(successes: int, trials: int, alpha: float) -> float:
    if successes <= 0:
        return 0.0
    if successes > trials or trials <= 0:
        raise ValueError("Invalid binomial counts")
    target = 1.0 - float(np.clip(alpha, 1e-15, 1.0 - 1e-15))
    low, high = 0.0, 1.0
    for _ in range(60):
        middle = (low + high) / 2.0
        if _binomial_cdf(successes - 1, trials, middle) > target:
            low = middle
        else:
            high = middle
    return (low + high) / 2.0


def _clopper_pearson_upper(successes: int, trials: int, alpha: float) -> float:
    if successes >= trials:
        return 1.0
    if successes < 0 or trials <= 0:
        raise ValueError("Invalid binomial counts")
    target = float(np.clip(alpha, 1e-15, 1.0 - 1e-15))
    low, high = 0.0, 1.0
    for _ in range(60):
        middle = (low + high) / 2.0
        if _binomial_cdf(successes, trials, middle) > target:
            low = middle
        else:
            high = middle
    return (low + high) / 2.0


def _binomial_cdf(k: int, n: int, probability: float) -> float:
    if k < 0:
        return 0.0
    if k >= n:
        return 1.0
    p = float(np.clip(probability, 0.0, 1.0))
    if p <= 0.0:
        return 1.0
    if p >= 1.0:
        return 0.0
    logs = []
    log_p = math.log(p)
    log_q = math.log1p(-p)
    log_coefficients = _log_binomial_coefficients(n, k)
    for value, log_coefficient in enumerate(log_coefficients):
        logs.append(
            log_coefficient
            + value * log_p
            + (n - value) * log_q
        )
    maximum = max(logs)
    return float(math.exp(maximum) * sum(math.exp(value - maximum) for value in logs))


@lru_cache(maxsize=1024)
def _log_binomial_coefficients(n: int, k: int) -> tuple[float, ...]:
    base = math.lgamma(n + 1)
    return tuple(
        base - math.lgamma(value + 1) - math.lgamma(n - value + 1)
        for value in range(k + 1)
    )
