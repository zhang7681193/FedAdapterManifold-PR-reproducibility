from __future__ import annotations

from dataclasses import dataclass

import numpy as np


Array = np.ndarray


@dataclass(frozen=True)
class RobustFunctionTeacher:
    """Training-fixed function-space teacher and its optimization audit."""

    routing_bias: Array
    routing_weights: Array
    teacher_logits: Array
    fold_losses: Array
    fold_anchor_losses: Array
    fold_regrets: Array
    smooth_worst_fold_regret: float
    routing_kl: float
    objective: float
    iterations: int
    converged: bool
    improves_every_training_fold: bool


@dataclass(frozen=True)
class FunctionTransportRiskAudit:
    """Observable terms in the function-transport positive-utility bound."""

    local_loss: float
    teacher_loss: float
    student_loss: float
    teacher_margin: float
    mean_logit_distillation_error: float
    empirical_student_gap: float
    positive_utility_upper_bound: float
    certified_positive_utility: bool
    fold_upper_bounds: Array
    fold_student_regrets: Array
    improves_every_training_fold: bool


@dataclass(frozen=True)
class ConvexExpertTeacher:
    """Globally audited mixture of fixed input-conditioned expert functions."""

    expert_weights: Array
    teacher_logits: Array
    fold_losses: Array
    fold_anchor_losses: Array
    fold_regrets: Array
    smooth_worst_fold_regret: float
    prior_kl: float
    objective: float
    optimality_gap: float
    iterations: int
    converged: bool
    improves_every_training_fold: bool


@dataclass(frozen=True)
class CrossFittedExpertAudit:
    """Nested held-out audit for a teacher fitted from out-of-fold experts."""

    final_teacher: ConvexExpertTeacher
    heldout_folds: Array
    heldout_losses: Array
    heldout_anchor_losses: Array
    heldout_regrets: Array
    heldout_expert_weights: Array
    heldout_optimality_gaps: Array
    all_heldout_regrets_negative: bool


def cross_entropy_from_logits(logits: Array, labels: Array) -> float:
    values = np.asarray(logits, dtype=np.float64)
    targets = np.asarray(labels, dtype=np.int64)
    _validate_logits_and_labels(values, targets)
    losses, _ = _cross_entropy_losses_and_gradient(values, targets)
    return float(np.mean(losses))


def log_probabilities_from_logits(logits: Array) -> Array:
    """Return gauge-invariant log probabilities for one or more predictors."""

    values = np.asarray(logits, dtype=np.float64)
    if values.ndim < 2 or values.shape[-1] < 2:
        raise ValueError("logits must have a class axis with at least two classes")
    if np.any(~np.isfinite(values)):
        raise ValueError("logits must be finite")
    shifted = values - np.max(values, axis=-1, keepdims=True)
    log_normalizer = np.log(np.sum(np.exp(shifted), axis=-1, keepdims=True))
    return shifted - log_normalizer


def probability_mixture_teacher(donor_logits: Array, donor_weights: Array) -> Array:
    """Mix donor predictive distributions instead of gauge-dependent logits."""

    logits = np.asarray(donor_logits, dtype=np.float64)
    weights = np.asarray(donor_weights, dtype=np.float64)
    if logits.ndim != 3:
        raise ValueError("donor_logits must have shape [samples, donors, classes]")
    if weights.shape != (logits.shape[1],):
        raise ValueError("donor_weights must provide one value per donor")
    if np.any(weights < 0.0) or np.any(~np.isfinite(weights)) or np.sum(weights) <= 0.0:
        raise ValueError("donor_weights must be finite, nonnegative, and nonzero")
    weights = weights / np.sum(weights)
    log_probabilities = log_probabilities_from_logits(logits)
    probabilities = np.exp(log_probabilities)
    mixture = np.einsum("d,ndc->nc", weights, probabilities)
    mixture = np.clip(mixture, 1e-15, None)
    mixture /= np.sum(mixture, axis=1, keepdims=True)
    return np.log(mixture)


def class_conditional_probability_teacher(
    donor_logits: Array,
    receiver_features: Array,
    class_prototypes: Array,
    prototype_mask: Array,
    compatibility: Array,
    receiver_index: int,
    *,
    temperature: float = 0.1,
    exclude_receiver: bool = True,
) -> tuple[Array, Array]:
    """Route donor evidence separately for every class in probability space.

    Probability routing is invariant to donor-specific additive logit offsets,
    which is necessary when different clients have unrelated logit gauges.
    Returned routes have shape ``[samples, donors, classes]``.
    """

    logits = np.asarray(donor_logits, dtype=np.float64)
    features = np.asarray(receiver_features, dtype=np.float64)
    prototypes = np.asarray(class_prototypes, dtype=np.float64)
    mask = np.asarray(prototype_mask, dtype=bool)
    support_values = np.asarray(compatibility, dtype=np.float64)
    if logits.ndim != 3:
        raise ValueError("donor_logits must have shape [samples, donors, classes]")
    n, donors, classes = logits.shape
    if features.ndim != 2 or features.shape[0] != n:
        raise ValueError("receiver_features must align with donor_logits samples")
    if prototypes.shape != (donors, classes, features.shape[1]):
        raise ValueError("class_prototypes must have shape [donors, classes, features]")
    if mask.shape != (donors, classes):
        raise ValueError("prototype_mask must have shape [donors, classes]")
    if support_values.shape != (donors,):
        raise ValueError("compatibility must provide one value per donor")
    if not 0 <= int(receiver_index) < donors:
        raise ValueError("receiver_index is outside the donor axis")
    if float(temperature) <= 0.0:
        raise ValueError("temperature must be positive")
    if np.any(~np.isfinite(logits)) or np.any(~np.isfinite(features)):
        raise ValueError("logits and features must be finite")
    if np.any(support_values < 0.0) or np.any(~np.isfinite(support_values)):
        raise ValueError("compatibility must be finite and nonnegative")

    feature_norms = np.linalg.norm(features, axis=1, keepdims=True)
    normalized_features = features / np.maximum(feature_norms, 1e-12)
    prototype_norms = np.linalg.norm(prototypes, axis=2, keepdims=True)
    normalized_prototypes = prototypes / np.maximum(prototype_norms, 1e-12)
    active = (support_values[:, None] > 0.0) & mask
    if exclude_receiver:
        active[int(receiver_index), :] = False

    routes = np.zeros((n, donors, classes), dtype=np.float64)
    for class_index in range(classes):
        donors_for_class = np.flatnonzero(active[:, class_index])
        if donors_for_class.size == 0:
            routes[:, int(receiver_index), class_index] = 1.0
            continue
        similarities = (
            normalized_features
            @ normalized_prototypes[donors_for_class, class_index, :].T
        )
        scores = similarities / float(temperature)
        scores += np.log(np.maximum(support_values[donors_for_class], 1e-15))[None, :]
        scores -= np.max(scores, axis=1, keepdims=True)
        weights = np.exp(scores)
        weights /= np.sum(weights, axis=1, keepdims=True)
        routes[:, donors_for_class, class_index] = weights

    donor_probabilities = np.exp(log_probabilities_from_logits(logits))
    evidence = np.sum(routes * donor_probabilities, axis=1)
    evidence = np.clip(evidence, 1e-15, None)
    evidence /= np.sum(evidence, axis=1, keepdims=True)
    teacher_logits = np.log(evidence)
    return teacher_logits, routes


def crossfit_convex_expert_screen(
    expert_logits: Array,
    labels: Array,
    fold_ids: Array,
    anchor_logits: Array,
    expert_prior: Array | None = None,
    *,
    kl_strength: float = 0.01,
    fold_temperature: float = 0.05,
    max_iterations: int = 2000,
    tolerance: float = 1e-8,
) -> CrossFittedExpertAudit:
    """Learn fixed-expert weights without scoring them on their fitting folds.

    ``expert_logits`` and ``anchor_logits`` must already be out-of-fold model
    predictions.  For every held-out fold, weights are fitted on all remaining
    folds and evaluated once on the unseen fold.  The final weights are then
    fitted on all out-of-fold predictions for later deployment.  At least
    three folds are required so every inner fit still contains two folds for
    robust worst-fold optimization.
    """

    logits = np.asarray(expert_logits, dtype=np.float64)
    targets = np.asarray(labels, dtype=np.int64)
    folds = np.asarray(fold_ids, dtype=np.int64)
    anchor = np.asarray(anchor_logits, dtype=np.float64)
    if logits.ndim != 3:
        raise ValueError("expert_logits must have shape [samples, experts, classes]")
    n, experts, classes = logits.shape
    if targets.shape != (n,) or folds.shape != (n,):
        raise ValueError("labels and fold_ids must align with expert_logits")
    if anchor.shape != (n, classes):
        raise ValueError("anchor_logits must have shape [samples, classes]")
    unique_folds = np.unique(folds)
    if unique_folds.size < 3:
        raise ValueError("nested cross-fitted screening requires at least three folds")

    heldout_losses: list[float] = []
    heldout_anchor_losses: list[float] = []
    heldout_regrets: list[float] = []
    heldout_weights: list[Array] = []
    heldout_gaps: list[float] = []
    for heldout_fold in unique_folds:
        fit_mask = folds != heldout_fold
        score_mask = ~fit_mask
        fitted = fit_convex_expert_teacher(
            logits[fit_mask],
            targets[fit_mask],
            folds[fit_mask],
            anchor[fit_mask],
            expert_prior=expert_prior,
            kl_strength=kl_strength,
            fold_temperature=fold_temperature,
            max_iterations=max_iterations,
            tolerance=tolerance,
        )
        heldout_teacher = np.einsum(
            "e,nec->nc", fitted.expert_weights, logits[score_mask]
        )
        teacher_loss = cross_entropy_from_logits(
            heldout_teacher, targets[score_mask]
        )
        anchor_loss = cross_entropy_from_logits(anchor[score_mask], targets[score_mask])
        heldout_losses.append(teacher_loss)
        heldout_anchor_losses.append(anchor_loss)
        heldout_regrets.append(teacher_loss - anchor_loss)
        heldout_weights.append(fitted.expert_weights.copy())
        heldout_gaps.append(float(fitted.optimality_gap))

    final_teacher = fit_convex_expert_teacher(
        logits,
        targets,
        folds,
        anchor,
        expert_prior=expert_prior,
        kl_strength=kl_strength,
        fold_temperature=fold_temperature,
        max_iterations=max_iterations,
        tolerance=tolerance,
    )
    regret_values = np.asarray(heldout_regrets, dtype=np.float64)
    return CrossFittedExpertAudit(
        final_teacher=final_teacher,
        heldout_folds=unique_folds.copy(),
        heldout_losses=np.asarray(heldout_losses, dtype=np.float64),
        heldout_anchor_losses=np.asarray(heldout_anchor_losses, dtype=np.float64),
        heldout_regrets=regret_values,
        heldout_expert_weights=np.stack(heldout_weights, axis=0).reshape(
            unique_folds.size, experts
        ),
        heldout_optimality_gaps=np.asarray(heldout_gaps, dtype=np.float64),
        all_heldout_regrets_negative=bool(np.max(regret_values) < 0.0),
    )


def fit_convex_expert_teacher(
    expert_logits: Array,
    labels: Array,
    fold_ids: Array,
    anchor_logits: Array,
    expert_prior: Array | None = None,
    *,
    kl_strength: float = 0.01,
    fold_temperature: float = 0.05,
    max_iterations: int = 2000,
    tolerance: float = 1e-8,
) -> ConvexExpertTeacher:
    """Solve the theorem-backed fixed-expert routing problem.

    Every expert may already contain input-conditioned prototype routing.  The
    learned simplex weights only mix these fixed functions.  The objective is
    convex, and ``optimality_gap`` is the Frank-Wolfe gap, which upper-bounds
    primal suboptimality for this differentiable convex program.
    """

    logits = np.asarray(expert_logits, dtype=np.float64)
    targets = np.asarray(labels, dtype=np.int64)
    folds = np.asarray(fold_ids, dtype=np.int64)
    anchor = np.asarray(anchor_logits, dtype=np.float64)
    if logits.ndim != 3:
        raise ValueError("expert_logits must have shape [samples, experts, classes]")
    n, experts, classes = logits.shape
    if n == 0 or experts == 0 or classes < 2:
        raise ValueError("expert_logits must contain samples, experts, and classes")
    if targets.shape != (n,) or folds.shape != (n,):
        raise ValueError("labels and fold_ids must align with expert_logits")
    if anchor.shape != (n, classes):
        raise ValueError("anchor_logits must have shape [samples, classes]")
    _validate_logits_and_labels(anchor, targets)
    if np.any(~np.isfinite(logits)):
        raise ValueError("expert_logits must be finite")
    unique_folds = np.unique(folds)
    if unique_folds.size < 2:
        raise ValueError("at least two training folds are required")
    if float(kl_strength) < 0.0:
        raise ValueError("kl_strength must be nonnegative")
    if float(fold_temperature) <= 0.0:
        raise ValueError("fold_temperature must be positive")

    if expert_prior is None:
        prior = np.full(experts, 1.0 / experts, dtype=np.float64)
    else:
        prior = np.asarray(expert_prior, dtype=np.float64)
        if prior.shape != (experts,):
            raise ValueError("expert_prior must provide one value per expert")
        if np.any(prior < 0.0) or np.any(~np.isfinite(prior)) or np.sum(prior) <= 0.0:
            raise ValueError("expert_prior must be finite, nonnegative, and nonzero")
        prior = prior / np.sum(prior)
    active = prior > 0.0
    weights = prior.copy()
    anchor_losses, _ = _cross_entropy_losses_and_gradient(anchor, targets)
    anchor_fold_losses = np.asarray(
        [float(np.mean(anchor_losses[folds == fold])) for fold in unique_folds],
        dtype=np.float64,
    )
    current = _convex_expert_objective(
        logits,
        targets,
        folds,
        unique_folds,
        anchor_fold_losses,
        prior,
        weights,
        kl_strength=float(kl_strength),
        fold_temperature=float(fold_temperature),
    )
    converged = False
    iterations = 0
    for iterations in range(1, max(1, int(max_iterations)) + 1):
        gradient = current[1]
        gap = _simplex_optimality_gap(weights, gradient, active)
        if gap <= float(tolerance):
            converged = True
            break
        centered = gradient - float(np.sum(weights * gradient))
        step = 1.0
        accepted = False
        while step >= 1e-10:
            log_proposal = np.full(experts, -np.inf, dtype=np.float64)
            log_proposal[active] = (
                np.log(np.clip(weights[active], 1e-15, None))
                - step * centered[active]
            )
            maximum = float(np.max(log_proposal[active]))
            proposal = np.zeros(experts, dtype=np.float64)
            proposal[active] = np.exp(log_proposal[active] - maximum)
            proposal[active] = np.clip(proposal[active], 1e-15, None)
            proposal /= np.sum(proposal)
            evaluated = _convex_expert_objective(
                logits,
                targets,
                folds,
                unique_folds,
                anchor_fold_losses,
                prior,
                proposal,
                kl_strength=float(kl_strength),
                fold_temperature=float(fold_temperature),
            )
            if evaluated[0] < current[0] - 1e-12:
                accepted = True
                break
            step *= 0.5
        if not accepted:
            converged = gap <= max(float(tolerance), 1e-6)
            break
        weights = proposal
        current = evaluated

    (
        objective,
        gradient,
        teacher,
        fold_losses,
        fold_regrets,
        smooth_regret,
        prior_kl,
    ) = current
    gap = _simplex_optimality_gap(weights, gradient, active)
    return ConvexExpertTeacher(
        expert_weights=weights.copy(),
        teacher_logits=teacher.copy(),
        fold_losses=fold_losses.copy(),
        fold_anchor_losses=anchor_fold_losses.copy(),
        fold_regrets=fold_regrets.copy(),
        smooth_worst_fold_regret=float(smooth_regret),
        prior_kl=float(prior_kl),
        objective=float(objective),
        optimality_gap=float(gap),
        iterations=int(iterations),
        converged=bool(converged),
        improves_every_training_fold=bool(np.max(fold_regrets) < 0.0),
    )


def fit_robust_function_teacher(
    donor_logits: Array,
    labels: Array,
    fold_ids: Array,
    routing_prior: Array | None = None,
    anchor_logits: Array | None = None,
    *,
    kl_strength: float = 0.05,
    fold_temperature: float = 0.05,
    max_iterations: int = 500,
    tolerance: float = 1e-9,
) -> RobustFunctionTeacher:
    """Fit a receiver teacher without mixing donor adapter parameters.

    ``donor_logits[n, j]`` is donor ``j``'s prediction on receiver sample
    ``n``.  ``routing_prior`` may be a global donor prior or an input-specific
    prototype prior.  A single receiver bias is learned on adapter-training
    folds.  When ``anchor_logits`` is provided, the objective is a smooth
    maximum of receiver-relative fold regrets plus a KL penalty to the
    geometry/prototype prior.  This targets improvement over Local rather than
    low absolute loss on folds of unequal difficulty.  The free routing-weight
    problem is convex for fixed expert functions.  The shared-bias
    parameterization preserves prior support and defines an input-conditioned
    route at inference time.

    Outer calibration and test arrays are intentionally absent from the API.
    """

    logits = np.asarray(donor_logits, dtype=np.float64)
    targets = np.asarray(labels, dtype=np.int64)
    folds = np.asarray(fold_ids, dtype=np.int64)
    if logits.ndim != 3:
        raise ValueError("donor_logits must have shape [samples, donors, classes]")
    n, donors, classes = logits.shape
    if n == 0 or donors == 0 or classes < 2:
        raise ValueError("donor_logits must contain samples, donors, and at least two classes")
    if targets.shape != (n,) or folds.shape != (n,):
        raise ValueError("labels and fold_ids must align with donor_logits samples")
    if np.any(targets < 0) or np.any(targets >= classes):
        raise ValueError("labels contain a class outside donor_logits")
    unique_folds = np.unique(folds)
    if unique_folds.size < 2:
        raise ValueError("at least two training folds are required")
    if float(kl_strength) < 0.0:
        raise ValueError("kl_strength must be nonnegative")
    if float(fold_temperature) <= 0.0:
        raise ValueError("fold_temperature must be positive")

    if anchor_logits is None:
        anchor_fold_losses = np.zeros(unique_folds.size, dtype=np.float64)
    else:
        anchor = np.asarray(anchor_logits, dtype=np.float64)
        if anchor.shape != (n, classes):
            raise ValueError("anchor_logits must have shape [samples, classes]")
        _validate_logits_and_labels(anchor, targets)
        anchor_losses, _ = _cross_entropy_losses_and_gradient(anchor, targets)
        anchor_fold_losses = np.asarray(
            [float(np.mean(anchor_losses[folds == fold])) for fold in unique_folds],
            dtype=np.float64,
        )

    prior = _routing_prior(routing_prior, n=n, donors=donors)
    active = np.any(prior > 0.0, axis=0)
    if not np.any(active):
        raise ValueError("routing_prior has no active donor")
    bias = np.zeros(donors, dtype=np.float64)
    current = _teacher_objective(
        logits,
        targets,
        folds,
        unique_folds,
        prior,
        bias,
        anchor_fold_losses=anchor_fold_losses,
        kl_strength=float(kl_strength),
        fold_temperature=float(fold_temperature),
    )
    converged = False
    iterations = 0
    for iterations in range(1, max(1, int(max_iterations)) + 1):
        gradient = current[1]
        gradient = gradient - float(np.mean(gradient[active])) * active.astype(np.float64)
        gradient_norm_sq = float(np.sum(gradient[active] ** 2))
        if gradient_norm_sq <= float(tolerance) ** 2:
            converged = True
            break
        step = 1.0
        accepted = False
        while step >= 1e-10:
            proposal = bias - step * gradient
            proposal[active] -= float(np.mean(proposal[active]))
            proposal[~active] = 0.0
            evaluated = _teacher_objective(
                logits,
                targets,
                folds,
                unique_folds,
                prior,
                proposal,
                anchor_fold_losses=anchor_fold_losses,
                kl_strength=float(kl_strength),
                fold_temperature=float(fold_temperature),
            )
            if evaluated[0] <= current[0] - 1e-4 * step * gradient_norm_sq:
                accepted = True
                break
            step *= 0.5
        if not accepted:
            converged = gradient_norm_sq <= max(float(tolerance), 1e-7) ** 2
            break
        change = float(np.linalg.norm(proposal - bias))
        bias = proposal
        current = evaluated
        if change <= float(tolerance):
            converged = True
            break

    (
        objective,
        _,
        weights,
        teacher,
        fold_losses,
        fold_regrets,
        smooth_regret,
        routing_kl,
    ) = current
    return RobustFunctionTeacher(
        routing_bias=bias.copy(),
        routing_weights=weights.copy(),
        teacher_logits=teacher.copy(),
        fold_losses=fold_losses.copy(),
        fold_anchor_losses=anchor_fold_losses.copy(),
        fold_regrets=fold_regrets.copy(),
        smooth_worst_fold_regret=float(smooth_regret),
        routing_kl=float(routing_kl),
        objective=float(objective),
        iterations=int(iterations),
        converged=bool(converged),
        improves_every_training_fold=bool(np.max(fold_regrets) < 0.0),
    )


def apply_function_teacher(
    donor_logits: Array,
    routing_prior: Array,
    routing_bias: Array,
) -> tuple[Array, Array]:
    """Apply a training-fixed routing bias to new receiver samples."""

    logits = np.asarray(donor_logits, dtype=np.float64)
    if logits.ndim != 3:
        raise ValueError("donor_logits must have shape [samples, donors, classes]")
    n, donors, _ = logits.shape
    prior = _routing_prior(routing_prior, n=n, donors=donors)
    bias = np.asarray(routing_bias, dtype=np.float64)
    if bias.shape != (donors,):
        raise ValueError("routing_bias must provide one value per donor")
    weights = _biased_routing_weights(prior, bias)
    teacher = np.einsum("nj,njc->nc", weights, logits, optimize=True)
    return teacher, weights


def audit_function_transport_risk(
    local_logits: Array,
    teacher_logits: Array,
    student_logits: Array,
    labels: Array,
    fold_ids: Array,
    *,
    pairwise_generalization_radius: float = 0.0,
) -> FunctionTransportRiskAudit:
    """Evaluate the sufficient condition for positive receiver utility.

    Multiclass cross entropy is 2-Lipschitz in the logit infinity norm.  If
    the teacher improves over Local by ``gamma`` and the distilled student has
    mean teacher logit error ``epsilon``, then

    ``R(student)-R(local) <= -gamma + 2*epsilon + 2*radius``.

    ``radius`` bounds each of the two pairwise empirical-to-population gaps.
    This is a proposal-side certificate only.  Deployment must still use the
    independent receiver calibration certificate.
    """

    local = np.asarray(local_logits, dtype=np.float64)
    teacher = np.asarray(teacher_logits, dtype=np.float64)
    student = np.asarray(student_logits, dtype=np.float64)
    targets = np.asarray(labels, dtype=np.int64)
    folds = np.asarray(fold_ids, dtype=np.int64)
    if local.shape != teacher.shape or local.shape != student.shape:
        raise ValueError("local, teacher, and student logits must have identical shapes")
    _validate_logits_and_labels(local, targets)
    if folds.shape != targets.shape:
        raise ValueError("fold_ids must align with labels")
    radius = float(pairwise_generalization_radius)
    if radius < 0.0:
        raise ValueError("pairwise_generalization_radius must be nonnegative")

    local_losses, _ = _cross_entropy_losses_and_gradient(local, targets)
    teacher_losses, _ = _cross_entropy_losses_and_gradient(teacher, targets)
    student_losses, _ = _cross_entropy_losses_and_gradient(student, targets)
    errors = np.max(np.abs(student - teacher), axis=1)
    teacher_margin = float(np.mean(local_losses - teacher_losses))
    mean_error = float(np.mean(errors))
    upper = float(-teacher_margin + 2.0 * mean_error + 2.0 * radius)
    fold_bounds = []
    fold_student_regrets = []
    for fold in np.unique(folds):
        mask = folds == fold
        margin = float(np.mean(local_losses[mask] - teacher_losses[mask]))
        error = float(np.mean(errors[mask]))
        fold_bounds.append(-margin + 2.0 * error + 2.0 * radius)
        fold_student_regrets.append(
            float(np.mean(student_losses[mask] - local_losses[mask]))
        )
    return FunctionTransportRiskAudit(
        local_loss=float(np.mean(local_losses)),
        teacher_loss=float(np.mean(teacher_losses)),
        student_loss=float(np.mean(student_losses)),
        teacher_margin=teacher_margin,
        mean_logit_distillation_error=mean_error,
        empirical_student_gap=float(np.mean(student_losses - local_losses)),
        positive_utility_upper_bound=upper,
        certified_positive_utility=bool(upper < 0.0 and max(fold_bounds) < 0.0),
        fold_upper_bounds=np.asarray(fold_bounds, dtype=np.float64),
        fold_student_regrets=np.asarray(fold_student_regrets, dtype=np.float64),
        improves_every_training_fold=bool(max(fold_student_regrets) < 0.0),
    )


def _teacher_objective(
    donor_logits: Array,
    labels: Array,
    fold_ids: Array,
    unique_folds: Array,
    prior: Array,
    bias: Array,
    *,
    anchor_fold_losses: Array | None = None,
    kl_strength: float,
    fold_temperature: float,
) -> tuple[float, Array, Array, Array, Array, float, float]:
    weights = _biased_routing_weights(prior, bias)
    teacher = np.einsum("nj,njc->nc", weights, donor_logits, optimize=True)
    losses, logit_gradient = _cross_entropy_losses_and_gradient(teacher, labels)
    fold_losses = np.asarray(
        [float(np.mean(losses[fold_ids == fold])) for fold in unique_folds],
        dtype=np.float64,
    )
    if anchor_fold_losses is None:
        anchor_values = np.zeros_like(fold_losses)
    else:
        anchor_values = np.asarray(anchor_fold_losses, dtype=np.float64)
        if anchor_values.shape != fold_losses.shape:
            raise ValueError("anchor_fold_losses must align with unique_folds")
    fold_regrets = fold_losses - anchor_values
    shifted = fold_regrets / fold_temperature
    maximum = float(np.max(shifted))
    fold_mass = np.exp(shifted - maximum)
    fold_mass /= np.sum(fold_mass)
    smooth_regret = float(
        fold_temperature
        * (
            maximum
            + np.log(np.sum(np.exp(shifted - maximum)))
            - np.log(max(1, fold_losses.size))
        )
    )

    sample_mass = np.zeros(labels.size, dtype=np.float64)
    for fold_index, fold in enumerate(unique_folds):
        mask = fold_ids == fold
        sample_mass[mask] = float(fold_mass[fold_index]) / max(1, int(np.sum(mask)))
    weighted_gradient = logit_gradient * sample_mass[:, None]
    derivative_weights = np.einsum(
        "nc,njc->nj", weighted_gradient, donor_logits, optimize=True
    )
    centered_derivative = derivative_weights - np.sum(
        weights * derivative_weights, axis=1, keepdims=True
    )
    gradient = np.sum(weights * centered_derivative, axis=0)

    positive = prior > 0.0
    ratio = np.ones_like(weights)
    ratio[positive] = np.clip(weights[positive], 1e-15, None) / np.clip(
        prior[positive], 1e-15, None
    )
    routing_kl = float(np.mean(np.sum(np.where(positive, weights * np.log(ratio), 0.0), axis=1)))
    if kl_strength > 0.0:
        derivative_kl = np.where(positive, np.log(ratio) + 1.0, 0.0)
        centered_kl = derivative_kl - np.sum(weights * derivative_kl, axis=1, keepdims=True)
        gradient += float(kl_strength) * np.mean(weights * centered_kl, axis=0)
    objective = float(smooth_regret + kl_strength * routing_kl)
    return (
        objective,
        gradient,
        weights,
        teacher,
        fold_losses,
        fold_regrets,
        smooth_regret,
        routing_kl,
    )


def _convex_expert_objective(
    expert_logits: Array,
    labels: Array,
    fold_ids: Array,
    unique_folds: Array,
    anchor_fold_losses: Array,
    prior: Array,
    weights: Array,
    *,
    kl_strength: float,
    fold_temperature: float,
) -> tuple[float, Array, Array, Array, Array, float, float]:
    teacher = np.einsum("m,nmc->nc", weights, expert_logits, optimize=True)
    losses, logit_gradient = _cross_entropy_losses_and_gradient(teacher, labels)
    fold_losses = np.asarray(
        [float(np.mean(losses[fold_ids == fold])) for fold in unique_folds],
        dtype=np.float64,
    )
    fold_regrets = fold_losses - anchor_fold_losses
    shifted = fold_regrets / fold_temperature
    maximum = float(np.max(shifted))
    exponentials = np.exp(shifted - maximum)
    fold_mass = exponentials / np.sum(exponentials)
    smooth_regret = float(
        fold_temperature
        * (
            maximum
            + np.log(np.sum(exponentials))
            - np.log(max(1, fold_losses.size))
        )
    )
    sample_mass = np.zeros(labels.size, dtype=np.float64)
    for fold_index, fold in enumerate(unique_folds):
        mask = fold_ids == fold
        sample_mass[mask] = float(fold_mass[fold_index]) / max(1, int(np.sum(mask)))
    gradient = np.einsum(
        "nc,nmc,n->m",
        logit_gradient,
        expert_logits,
        sample_mass,
        optimize=True,
    )

    active = prior > 0.0
    if np.any(weights[~active] > 0.0):
        return float("inf"), np.full_like(weights, np.nan), teacher, fold_losses, fold_regrets, smooth_regret, float("inf")
    ratio = np.clip(weights[active], 1e-15, None) / prior[active]
    prior_kl = float(np.sum(weights[active] * np.log(ratio)))
    if kl_strength > 0.0:
        gradient[active] += float(kl_strength) * (np.log(ratio) + 1.0)
    objective = float(smooth_regret + kl_strength * prior_kl)
    return objective, gradient, teacher, fold_losses, fold_regrets, smooth_regret, prior_kl


def _simplex_optimality_gap(weights: Array, gradient: Array, active: Array) -> float:
    return float(np.sum(weights * gradient) - np.min(gradient[active]))


def _routing_prior(prior: Array | None, *, n: int, donors: int) -> Array:
    if prior is None:
        values = np.ones((n, donors), dtype=np.float64)
    else:
        values = np.asarray(prior, dtype=np.float64)
        if values.shape == (donors,):
            values = np.broadcast_to(values[None, :], (n, donors)).copy()
        elif values.shape != (n, donors):
            raise ValueError("routing_prior must have shape [donors] or [samples, donors]")
    if np.any(values < 0.0) or np.any(~np.isfinite(values)):
        raise ValueError("routing_prior must be finite and nonnegative")
    totals = np.sum(values, axis=1, keepdims=True)
    if np.any(totals <= 0.0):
        raise ValueError("every sample must have positive routing prior mass")
    return values / totals


def _biased_routing_weights(prior: Array, bias: Array) -> Array:
    scores = np.full_like(prior, -np.inf, dtype=np.float64)
    positive = prior > 0.0
    expanded_bias = np.broadcast_to(np.asarray(bias, dtype=np.float64), prior.shape)
    scores[positive] = np.log(prior[positive]) + expanded_bias[positive]
    maximum = np.max(scores, axis=1, keepdims=True)
    weights = np.zeros_like(scores)
    weights[positive] = np.exp((scores - maximum)[positive])
    weights /= np.sum(weights, axis=1, keepdims=True)
    return weights


def _cross_entropy_losses_and_gradient(logits: Array, labels: Array) -> tuple[Array, Array]:
    shifted = logits - np.max(logits, axis=1, keepdims=True)
    exponentials = np.exp(shifted)
    probabilities = exponentials / np.sum(exponentials, axis=1, keepdims=True)
    losses = -np.log(np.clip(probabilities[np.arange(labels.size), labels], 1e-15, None))
    gradient = probabilities.copy()
    gradient[np.arange(labels.size), labels] -= 1.0
    return losses, gradient


def _validate_logits_and_labels(logits: Array, labels: Array) -> None:
    if logits.ndim != 2 or labels.ndim != 1 or logits.shape[0] != labels.size:
        raise ValueError("logits and labels must be aligned rank-2/rank-1 arrays")
    if logits.shape[1] < 2 or np.any(labels < 0) or np.any(labels >= logits.shape[1]):
        raise ValueError("labels contain a class outside logits")
    if np.any(~np.isfinite(logits)):
        raise ValueError("logits must be finite")
