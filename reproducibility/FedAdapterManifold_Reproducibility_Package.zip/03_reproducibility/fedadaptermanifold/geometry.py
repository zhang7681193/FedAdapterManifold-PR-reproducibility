from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import csv
import pickle

import numpy as np


Array = np.ndarray


@dataclass
class GeometryOutputs:
    client_ids: list[str]
    client_signatures: list[dict]
    prototypes: dict[str, dict[int, Array]]
    visual_signatures: Array
    d_geo: Array
    graph: Array
    novelty: Array
    coverage: Array
    provider: str
    risk_geo_scores: Array | None = None
    feature_energy_deficit: Array | None = None


class GeometryProvider:
    def build(self, clients: list, num_classes: int, round_id: int = 0) -> GeometryOutputs:
        raise NotImplementedError


def class_prototypes(x: Array, y: Array, num_classes: int) -> Array:
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.int64)
    prototypes = np.zeros((num_classes, x.shape[1]), dtype=np.float64)
    for cls in range(num_classes):
        mask = y == cls
        if mask.any():
            prototypes[cls] = x[mask].mean(axis=0)
    return prototypes


def semantic_prototype_signature(prototypes: Array, counts: dict[int, int] | Array | None = None) -> Array:
    """Return a centered prototype signature for temporary visual geometry.

    Raw prototype vectors can be dominated by a client-wide style offset. For the
    FedAdapterManifold diagnostic we want the semantic layout of class prototypes,
    so we center observed class prototypes inside each client before flattening.
    """

    proto = _as_float_array(prototypes).copy()
    if proto.ndim != 2:
        raise ValueError(f"prototypes must be a 2D matrix, got {proto.shape}")
    if counts is None:
        observed = np.any(np.abs(proto) > 1e-12, axis=1)
    elif isinstance(counts, dict):
        observed = np.asarray([int(counts.get(cls, 0)) > 0 for cls in range(proto.shape[0])], dtype=bool)
    else:
        observed = np.asarray(counts, dtype=np.float64) > 0
    if observed.any():
        proto[observed] -= proto[observed].mean(axis=0, keepdims=True)
    proto[~observed] = 0.0
    return proto.reshape(-1)


def cluster_prototypes_from_clients(clients: list, assignments: Array, num_classes: int) -> Array:
    """Build class prototypes for each adapter-bank cluster.

    The output has shape ``K x C x D`` and can be used for input-conditioned
    routing without depending on labels at inference time.
    """

    assignments = np.asarray(assignments, dtype=np.int64)
    if assignments.shape[0] != len(clients):
        raise ValueError(f"Expected {len(clients)} assignments, got {assignments.shape[0]}")
    k = int(assignments.max()) + 1 if assignments.size else 0
    if k <= 0:
        raise ValueError("At least one cluster assignment is required")
    feature_dim = clients[0].x_train.shape[1]
    out = np.zeros((k, int(num_classes), feature_dim), dtype=np.float64)
    counts = np.zeros((k, int(num_classes)), dtype=np.float64)
    for client_idx, client in enumerate(clients):
        cluster_id = int(assignments[client_idx])
        proto = class_prototypes(client.x_train, client.y_train, num_classes)
        label_counts = np.bincount(client.y_train.astype(np.int64), minlength=num_classes).astype(np.float64)
        for cls in range(num_classes):
            if label_counts[cls] > 0:
                out[cluster_id, cls] += label_counts[cls] * proto[cls]
                counts[cluster_id, cls] += label_counts[cls]
    out /= np.clip(counts[:, :, None], 1e-12, None)
    return out


def cluster_prototypes_from_geometry(
    prototypes: dict[str, dict[int, Array]],
    client_ids: list[str],
    assignments: Array,
    num_classes: int,
    fallback_clients: list | None = None,
) -> Array:
    """Build adapter-bank routing anchors from FedGeo class prototypes."""

    assignments = np.asarray(assignments, dtype=np.int64)
    if assignments.shape[0] != len(client_ids):
        raise ValueError(f"Expected {len(client_ids)} assignments, got {assignments.shape[0]}")
    if not prototypes:
        if fallback_clients is None:
            raise ValueError("FedGeo prototypes are empty and no fallback clients were provided")
        return cluster_prototypes_from_clients(fallback_clients, assignments, num_classes)

    feature_dim = _prototype_feature_dim(prototypes)
    if feature_dim <= 0:
        if fallback_clients is None:
            raise ValueError("Could not infer prototype feature dimension")
        return cluster_prototypes_from_clients(fallback_clients, assignments, num_classes)
    if fallback_clients is not None and feature_dim != int(fallback_clients[0].x_train.shape[1]):
        return cluster_prototypes_from_clients(fallback_clients, assignments, num_classes)

    k = int(assignments.max()) + 1 if assignments.size else 0
    out = np.zeros((k, int(num_classes), feature_dim), dtype=np.float64)
    counts = np.zeros((k, int(num_classes)), dtype=np.float64)
    for idx, cid in enumerate(client_ids):
        proto_map = _lookup_client_mapping(prototypes, cid) or {}
        cluster_id = int(assignments[idx])
        for cls in range(num_classes):
            if cls in proto_map:
                value = _as_float_array(proto_map[cls]).reshape(-1)
                if value.size == feature_dim:
                    out[cluster_id, cls] += value
                    counts[cluster_id, cls] += 1.0
    observed = counts > 0
    out /= np.clip(counts[:, :, None], 1e-12, None)
    if fallback_clients is not None and not observed.all():
        fallback = cluster_prototypes_from_clients(fallback_clients, assignments, num_classes)
        if fallback.shape == out.shape:
            out[~observed] = fallback[~observed]
    return out


def pairwise_euclidean(values: Array) -> Array:
    values = np.asarray(values, dtype=np.float64)
    diff = values[:, None, :] - values[None, :, :]
    distances = np.sqrt(np.sum(diff * diff, axis=-1))
    positive = distances[distances > 0]
    if positive.size:
        distances = distances / np.median(positive)
    return distances


def knn_graph(distances: Array, k: int = 2) -> Array:
    n = distances.shape[0]
    graph = np.zeros((n, n), dtype=np.float64)
    for i in range(n):
        order = np.argsort(distances[i])
        for j in order[1 : min(n, k + 1)]:
            graph[i, j] = 1.0
            graph[j, i] = 1.0
    return graph


class LocalPrototypeGeometry(GeometryProvider):
    """Temporary local stand-in for FedGeo client visual geometry.

    It emits the same contract expected from FedGeo: client signatures,
    d_geo, graph, novelty, and coverage. Replace this class with a
    FedGeo-backed provider when FedGeo outputs are available.
    """

    def __init__(self, graph_k: int = 2) -> None:
        self.graph_k = graph_k

    def build(self, clients: list, num_classes: int, round_id: int = 0) -> GeometryOutputs:
        signatures = []
        client_ids = []
        client_signatures = []
        prototype_payload: dict[str, dict[int, Array]] = {}
        for client in clients:
            proto = class_prototypes(client.x_train, client.y_train, num_classes)
            variances = _class_variances(client.x_train, client.y_train, proto, num_classes)
            counts = {
                cls: int(np.sum(client.y_train.astype(np.int64) == cls))
                for cls in range(num_classes)
            }
            radii = {cls: float(np.sqrt(np.mean(variances[cls]))) for cls in range(num_classes)}
            uncertainties = {cls: 1.0 / np.sqrt(max(counts[cls], 1)) for cls in range(num_classes)}
            label_hist = np.bincount(client.y_train.astype(np.int64), minlength=num_classes).astype(np.float64)
            signature = {
                "client_id": _client_numeric_id(client.client_id),
                "round_id": int(round_id),
                "prototypes": {cls: proto[cls].copy() for cls in range(num_classes)},
                "variances": {cls: variances[cls].copy() for cls in range(num_classes)},
                "radii": radii,
                "uncertainties": uncertainties,
                "counts": counts,
                "label_histogram": label_hist,
            }
            client_signatures.append(signature)
            prototype_payload[client.client_id] = signature["prototypes"]
            signatures.append(semantic_prototype_signature(proto, counts))
            client_ids.append(client.client_id)
        visual_signatures = np.vstack(signatures)
        d_geo = pairwise_euclidean(visual_signatures)
        graph = knn_graph(d_geo, k=self.graph_k)
        masked = d_geo + np.eye(d_geo.shape[0]) * np.nanmax(d_geo + 1.0)
        novelty = np.min(masked, axis=1)
        coverage = 1.0 / (1.0 + np.mean(d_geo, axis=1))
        return GeometryOutputs(
            client_ids=client_ids,
            client_signatures=client_signatures,
            prototypes=prototype_payload,
            visual_signatures=visual_signatures,
            d_geo=d_geo,
            graph=graph,
            novelty=novelty,
            coverage=coverage,
            provider="local_prototype",
        )


class FedGeoFileGeometryProvider(GeometryProvider):
    """Read the shared FedGeo geometry contract for FedAdapterManifold.

    The preferred path is FedGeo's interop loader:
    ``fedgeo.interop.load_fedadaptermanifold_inputs``.  When FedGeo is not
    importable in a local debug environment, this provider falls back to reading
    the same shared files directly.
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)

    def build(self, clients: list, num_classes: int, round_id: int = 0) -> GeometryOutputs:
        try:
            from fedgeo.interop import load_fedadaptermanifold_inputs  # type: ignore
        except (ImportError, ModuleNotFoundError):
            return self._build_from_files(clients, num_classes=num_classes, round_id=round_id)

        inputs = load_fedadaptermanifold_inputs(str(self.path), round_id)
        return _geometry_outputs_from_fedgeo_inputs(
            inputs,
            clients=clients,
            num_classes=num_classes,
            round_id=round_id,
        )

    def _build_from_files(self, clients: list, num_classes: int, round_id: int = 0) -> GeometryOutputs:
        client_ids = [c.client_id for c in clients]
        d_geo_npy = self.path / f"d_geo_round_{round_id}.npy"
        if d_geo_npy.exists():
            d_geo = np.load(d_geo_npy)
        else:
            d_geo = _read_square_csv(self.path / "d_geo.csv", client_ids)
        signatures_pkl = self.path / f"client_signatures_round_{round_id}.pkl"
        client_signatures = []
        prototypes = {}
        signatures_unavailable = False
        if signatures_pkl.exists():
            loaded = _try_pickle_load(signatures_pkl)
            if loaded is None:
                signatures_unavailable = True
                visual_signatures = np.zeros((len(client_ids), 1), dtype=np.float64)
            else:
                client_signatures = _order_signatures(loaded, client_ids)
                prototypes = {
                    cid: signature.get("prototypes", {})
                    for cid, signature in zip(client_ids, client_signatures)
                }
                visual_signatures = _signatures_to_matrix(client_signatures)
        else:
            signatures_path = self.path / "client_visual_signatures.npy"
            if signatures_path.exists():
                visual_signatures = np.load(signatures_path)
            else:
                visual_signatures = np.zeros((len(client_ids), 1), dtype=np.float64)
        prototypes_pkl = self.path / f"prototypes_round_{round_id}.pkl"
        if not prototypes and prototypes_pkl.exists():
            loaded_prototypes = _try_pickle_load(prototypes_pkl)
            if loaded_prototypes is None:
                raise RuntimeError(
                    f"Could not deserialize explicit FedGeo prototypes: {prototypes_pkl}. "
                    "The run is stopped to prevent a silent local-prototype fallback."
                )
            prototypes = _normalize_prototypes(loaded_prototypes, client_ids)
        if prototypes and visual_signatures.shape[1] == 1:
            visual_signatures = _prototypes_to_matrix(prototypes, client_ids, num_classes)
        if not prototypes:
            if signatures_unavailable or prototypes_pkl.exists():
                raise RuntimeError(
                    "Explicit FedGeo geometry was found, but neither its signatures nor its "
                    "prototype artifact could be deserialized. The run is stopped to prevent "
                    "mixing FedGeo distances with local fallback prototypes."
                )
            prototypes = _local_prototypes_from_clients(clients, num_classes)
            if visual_signatures.shape[1] == 1:
                visual_signatures = _prototypes_to_matrix(prototypes, client_ids, num_classes)
        graph_npy = self.path / f"geometry_graph_round_{round_id}.npy"
        graph_path = self.path / "geometry_graph.csv"
        if graph_npy.exists():
            graph = np.load(graph_npy)
        elif graph_path.exists():
            graph = _read_square_csv(graph_path, client_ids)
        else:
            graph = knn_graph(d_geo)
        novelty = np.mean(d_geo, axis=1)
        coverage = 1.0 / (1.0 + novelty)
        novelty_path = self.path / f"novelty_scores_round_{round_id}.csv"
        coverage_path = self.path / f"coverage_deficit_round_{round_id}.csv"
        risk_geo_path = self.path / f"risk_geo_scores_round_{round_id}.csv"
        feature_energy_path = self.path / f"feature_energy_deficit_round_{round_id}.csv"
        if novelty_path.exists():
            novelty = _read_single_score_csv(novelty_path, client_ids, "novelty", novelty, aliases=["novelty_score"])
        if coverage_path.exists():
            coverage_deficit = _read_single_score_csv(coverage_path, client_ids, "coverage_deficit", 1.0 - coverage)
            coverage = 1.0 - coverage_deficit
        risk_geo_scores = (
            _read_single_score_csv(
                risk_geo_path,
                client_ids,
                "risk_geo_score",
                np.full(len(client_ids), np.nan, dtype=np.float64),
                aliases=["risk_geo", "score", "client_risk"],
            )
            if risk_geo_path.exists()
            else None
        )
        feature_energy_deficit = (
            _read_single_score_csv(
                feature_energy_path,
                client_ids,
                "feature_energy_deficit",
                np.full(len(client_ids), np.nan, dtype=np.float64),
                aliases=["energy_deficit", "score"],
            )
            if feature_energy_path.exists()
            else None
        )
        nc_path = self.path / "novelty_coverage.csv"
        if not novelty_path.exists() and nc_path.exists():
            novelty, coverage = _read_novelty_coverage(nc_path, client_ids, novelty, coverage)
        return GeometryOutputs(
            client_ids=client_ids,
            client_signatures=client_signatures,
            prototypes=prototypes,
            visual_signatures=visual_signatures,
            d_geo=d_geo,
            graph=graph,
            novelty=novelty,
            coverage=coverage,
            provider="fedgeo_files",
            risk_geo_scores=risk_geo_scores,
            feature_energy_deficit=feature_energy_deficit,
        )


def write_geometry_outputs(path: str | Path, geometry: GeometryOutputs, round_id: int = 0) -> None:
    """Write shared FedGeo-compatible geometry outputs."""

    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    with (path / f"client_signatures_round_{round_id}.pkl").open("wb") as handle:
        pickle.dump(geometry.client_signatures, handle)
    with (path / f"prototypes_round_{round_id}.pkl").open("wb") as handle:
        pickle.dump(geometry.prototypes, handle)
    np.save(path / f"d_geo_round_{round_id}.npy", geometry.d_geo)
    np.save(path / f"geometry_graph_round_{round_id}.npy", geometry.graph)
    with (path / f"novelty_scores_round_{round_id}.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["client_id", "round_id", "novelty"])
        writer.writeheader()
        for cid, score in zip(geometry.client_ids, geometry.novelty):
            writer.writerow({"client_id": cid, "round_id": round_id, "novelty": float(score)})
    with (path / f"coverage_deficit_round_{round_id}.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["client_id", "round_id", "coverage_deficit"])
        writer.writeheader()
        for cid, score in zip(geometry.client_ids, 1.0 - geometry.coverage):
            writer.writerow({"client_id": cid, "round_id": round_id, "coverage_deficit": float(score)})
    if geometry.risk_geo_scores is not None:
        with (path / f"risk_geo_scores_round_{round_id}.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=["client_id", "round_id", "risk_geo_score"])
            writer.writeheader()
            for cid, score in zip(geometry.client_ids, geometry.risk_geo_scores):
                writer.writerow({"client_id": cid, "round_id": round_id, "risk_geo_score": float(score)})
    if geometry.feature_energy_deficit is not None:
        with (path / f"feature_energy_deficit_round_{round_id}.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=["client_id", "round_id", "feature_energy_deficit"])
            writer.writeheader()
            for cid, score in zip(geometry.client_ids, geometry.feature_energy_deficit):
                writer.writerow({"client_id": cid, "round_id": round_id, "feature_energy_deficit": float(score)})


def _geometry_outputs_from_fedgeo_inputs(
    inputs: dict[str, Any],
    clients: list,
    num_classes: int,
    round_id: int,
) -> GeometryOutputs:
    target_client_ids = [c.client_id for c in clients]
    source_client_ids = inputs.get("client_ids")
    if source_client_ids is None:
        source_client_ids = _client_ids_from_signatures(inputs.get("client_signatures"))
    order = _order_indices(source_client_ids, target_client_ids)

    if "d_geo" not in inputs:
        raise KeyError("FedGeo inputs must include d_geo")
    d_geo = _reorder_square(_as_float_array(inputs["d_geo"]), order, len(target_client_ids), "d_geo")

    raw_graph = inputs.get("geometry_graph")
    if raw_graph is None:
        graph = knn_graph(d_geo)
    else:
        graph = _reorder_square(_as_float_array(raw_graph), order, len(target_client_ids), "geometry_graph")

    raw_signatures = inputs.get("client_signatures", [])
    client_signatures = _order_signatures(raw_signatures, target_client_ids) if raw_signatures else []

    prototypes = _normalize_prototypes(inputs.get("prototypes", {}), target_client_ids, source_client_ids, order)
    if not prototypes and client_signatures:
        prototypes = {
            cid: _prototype_map(signature.get("prototypes", {}))
            for cid, signature in zip(target_client_ids, client_signatures)
        }

    if client_signatures:
        visual_signatures = _signatures_to_matrix(client_signatures)
    elif prototypes:
        visual_signatures = _prototypes_to_matrix(prototypes, target_client_ids, num_classes)
    else:
        visual_signatures = np.zeros((len(target_client_ids), 1), dtype=np.float64)

    default_novelty = np.mean(d_geo, axis=1)
    default_coverage = 1.0 / (1.0 + default_novelty)
    novelty = _scores_from_any(inputs.get("novelty_scores"), target_client_ids, "novelty", default_novelty, order=order)
    coverage_deficit = _scores_from_any(
        inputs.get("coverage_deficit"),
        target_client_ids,
        "coverage_deficit",
        1.0 - default_coverage,
        order=order,
    )
    coverage = 1.0 - coverage_deficit
    if "coverage_scores" in inputs:
        coverage = _scores_from_any(inputs.get("coverage_scores"), target_client_ids, "coverage", coverage, order=order)
    risk_geo_scores = _optional_scores_from_any(
        inputs.get("risk_geo_scores"),
        target_client_ids,
        "risk_geo_score",
        order=order,
        aliases=["risk_geo", "score", "client_risk"],
    )
    feature_energy_deficit = _optional_scores_from_any(
        inputs.get("feature_energy_deficit"),
        target_client_ids,
        "feature_energy_deficit",
        order=order,
        aliases=["energy_deficit", "score"],
    )

    return GeometryOutputs(
        client_ids=target_client_ids,
        client_signatures=client_signatures,
        prototypes=prototypes,
        visual_signatures=visual_signatures,
        d_geo=d_geo,
        graph=graph,
        novelty=novelty,
        coverage=coverage,
        provider="fedgeo_interop",
        risk_geo_scores=risk_geo_scores,
        feature_energy_deficit=feature_energy_deficit,
    )


def _read_square_csv(path: Path, client_ids: list[str]) -> Array:
    if not path.exists():
        raise FileNotFoundError(path)
    rows: list[list[str]] = []
    with path.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.reader(handle)
        rows = [row for row in reader if row]
    if not rows:
        raise ValueError(f"Empty matrix file: {path}")
    first = rows[0]
    has_header = not _is_float(first[0]) or len(first) == len(client_ids) + 1
    if has_header:
        rows = rows[1:]
    values = []
    row_ids = []
    for row in rows:
        if len(row) == len(client_ids) + 1:
            row_ids.append(row[0])
            row = row[1:]
        values.append([float(v) for v in row])
    matrix = np.asarray(values, dtype=np.float64)
    if matrix.shape != (len(client_ids), len(client_ids)):
        raise ValueError(f"{path} shape {matrix.shape} does not match {len(client_ids)} clients")
    if row_ids and row_ids != client_ids:
        index = {cid: idx for idx, cid in enumerate(row_ids)}
        order = [index[cid] for cid in client_ids]
        matrix = matrix[np.ix_(order, order)]
    return matrix


def _read_novelty_coverage(
    path: Path,
    client_ids: list[str],
    default_novelty: Array,
    default_coverage: Array,
) -> tuple[Array, Array]:
    novelty = default_novelty.copy()
    coverage = default_coverage.copy()
    with path.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        by_id = {row["client_id"]: row for row in reader}
    for idx, cid in enumerate(client_ids):
        if cid in by_id:
            row = by_id[cid]
            novelty[idx] = float(row.get("novelty", novelty[idx]))
            coverage[idx] = float(row.get("coverage", coverage[idx]))
    return novelty, coverage


def _read_single_score_csv(
    path: Path,
    client_ids: list[str],
    column: str,
    default: Array,
    aliases: list[str] | None = None,
) -> Array:
    out = np.asarray(default, dtype=np.float64).copy()
    columns = [column, *(aliases or [])]
    with path.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        by_id = {str(row["client_id"]): row for row in reader}
    for idx, cid in enumerate(client_ids):
        row = by_id.get(str(cid)) or by_id.get(str(_client_numeric_id(cid)))
        if row:
            for key in columns:
                if key in row:
                    out[idx] = float(row[key])
                    break
    return out


def _as_float_array(value: Any) -> Array:
    """Convert numpy/tensor-like FedGeo payloads to CPU float64 arrays."""

    obj = value
    if hasattr(obj, "detach"):
        obj = obj.detach()
    if hasattr(obj, "cpu"):
        obj = obj.cpu()
    if hasattr(obj, "numpy"):
        try:
            obj = obj.numpy()
        except TypeError:
            pass
    return np.asarray(obj, dtype=np.float64)


def _try_pickle_load(path: Path) -> Any | None:
    try:
        with path.open("rb") as handle:
            return pickle.load(handle)
    except (ImportError, ModuleNotFoundError, AttributeError):
        return None


def _local_prototypes_from_clients(clients: list, num_classes: int) -> dict[str, dict[int, Array]]:
    return {
        client.client_id: {
            cls: proto[cls].copy()
            for cls in range(int(num_classes))
        }
        for client in clients
        for proto in [class_prototypes(client.x_train, client.y_train, num_classes)]
    }


def _normalize_signature(signature: Any) -> dict:
    if not isinstance(signature, dict):
        return {}
    out = dict(signature)
    for field in ["prototypes", "variances"]:
        value = out.get(field)
        if isinstance(value, dict):
            normalized = {}
            for key, arr in value.items():
                try:
                    normalized[int(key)] = _as_float_array(arr)
                except (TypeError, ValueError):
                    normalized[key] = _as_float_array(arr)
            out[field] = normalized
    if "label_histogram" in out:
        out["label_histogram"] = _as_float_array(out["label_histogram"])
    return out


def _client_ids_from_signatures(signatures: Any) -> list[Any] | None:
    if not signatures:
        return None
    if isinstance(signatures, dict):
        return list(signatures.keys())
    out = []
    for signature in list(signatures):
        if isinstance(signature, dict) and "client_id" in signature:
            out.append(signature["client_id"])
    return out or None


def _order_indices(source_client_ids: Any, target_client_ids: list[str]) -> list[int]:
    if source_client_ids is None:
        return list(range(len(target_client_ids)))
    source = list(source_client_ids)
    if len(source) != len(target_client_ids):
        raise ValueError(f"FedGeo client_ids length {len(source)} does not match {len(target_client_ids)} clients")
    by_key: dict[str, int] = {}
    for idx, cid in enumerate(source):
        for key in _client_key_variants(cid):
            by_key[key] = idx
    order = []
    for fallback_idx, cid in enumerate(target_client_ids):
        found = None
        for key in _client_key_variants(cid):
            if key in by_key:
                found = by_key[key]
                break
        order.append(fallback_idx if found is None else found)
    return order


def _client_key_variants(client_id: Any) -> set[str]:
    variants = {str(client_id)}
    try:
        variants.add(str(_client_numeric_id(client_id)))
    except Exception:
        pass
    return variants


def _reorder_square(matrix: Array, order: list[int], n: int, name: str) -> Array:
    matrix = np.asarray(matrix, dtype=np.float64)
    if matrix.shape != (n, n):
        raise ValueError(f"FedGeo {name} shape {matrix.shape} does not match {n} clients")
    return matrix[np.ix_(order, order)]


def _normalize_prototypes(
    raw: Any,
    target_client_ids: list[str],
    source_client_ids: Any | None = None,
    order: list[int] | None = None,
) -> dict[str, dict[int, Array]]:
    if raw is None:
        return {}
    if isinstance(raw, dict):
        out = {}
        for cid in target_client_ids:
            value = _lookup_client_mapping(raw, cid)
            if value is not None:
                out[cid] = _prototype_map(value)
        if out:
            return out
        if _looks_like_prototype_map(raw):
            return {cid: _prototype_map(raw) for cid in target_client_ids}
        return {}
    values = list(raw) if isinstance(raw, (list, tuple)) else _as_float_array(raw)
    if len(values) != len(target_client_ids):
        return {}
    if order is None:
        order = _order_indices(source_client_ids, target_client_ids)
    return {
        cid: _prototype_map(values[int(source_idx)])
        for cid, source_idx in zip(target_client_ids, order)
    }


def _lookup_client_mapping(mapping: dict, client_id: Any) -> Any | None:
    for key in _client_key_variants(client_id):
        if key in mapping:
            return mapping[key]
    numeric = _client_numeric_id(client_id)
    if numeric in mapping:
        return mapping[numeric]
    return None


def _looks_like_prototype_map(value: dict) -> bool:
    if not value:
        return False
    keys = list(value.keys())
    try:
        [int(k) for k in keys]
    except (TypeError, ValueError):
        return False
    first = value[keys[0]]
    arr = _as_float_array(first)
    return arr.ndim >= 1 and arr.size > 1


def _prototype_map(value: Any) -> dict[int, Array]:
    if value is None:
        return {}
    if isinstance(value, dict):
        out = {}
        for cls, proto in value.items():
            try:
                cls_id = int(cls)
            except (TypeError, ValueError):
                continue
            out[cls_id] = _as_float_array(proto)
        return out
    arr = _as_float_array(value)
    if arr.ndim == 2:
        return {int(cls): arr[int(cls)].copy() for cls in range(arr.shape[0])}
    return {}


def _prototype_feature_dim(prototypes: dict[str, dict[int, Array]]) -> int:
    for proto_map in prototypes.values():
        for proto in proto_map.values():
            return int(_as_float_array(proto).reshape(-1).size)
    return 0


def _prototypes_to_matrix(prototypes: dict[str, dict[int, Array]], client_ids: list[str], num_classes: int) -> Array:
    feature_dim = _prototype_feature_dim(prototypes)
    if feature_dim <= 0:
        return np.zeros((len(client_ids), 1), dtype=np.float64)
    rows = []
    for cid in client_ids:
        proto_map = _lookup_client_mapping(prototypes, cid) or {}
        row = []
        for cls in range(num_classes):
            value = _as_float_array(proto_map.get(cls, np.zeros(feature_dim))).reshape(-1)
            if value.size != feature_dim:
                value = np.zeros(feature_dim, dtype=np.float64)
            row.append(value)
        rows.append(np.concatenate(row))
    return np.vstack(rows)


def _scores_from_any(
    values: Any,
    client_ids: list[str],
    column: str,
    default: Array,
    order: list[int] | None = None,
) -> Array:
    out = np.asarray(default, dtype=np.float64).copy()
    if values is None:
        return out
    if hasattr(values, "to_dict") and hasattr(values, "columns"):
        values = values.to_dict("records")
    if isinstance(values, dict):
        if "client_id" in values and column in values:
            records = [
                {"client_id": cid, column: score}
                for cid, score in zip(values["client_id"], values[column])
            ]
            return _scores_from_any(records, client_ids, column, out)
        if column in values:
            return _scores_from_any(values[column], client_ids, column, out, order=order)
        for idx, cid in enumerate(client_ids):
            value = _lookup_client_mapping(values, cid)
            if isinstance(value, dict):
                value = value.get(column, value.get("score", out[idx]))
            if value is not None:
                out[idx] = float(value)
        return out
    if isinstance(values, (list, tuple)):
        if values and isinstance(values[0], dict):
            by_id = {str(row.get("client_id")): row for row in values}
            for idx, cid in enumerate(client_ids):
                row = by_id.get(str(cid)) or by_id.get(str(_client_numeric_id(cid)))
                if row and column in row:
                    out[idx] = float(row[column])
            return out
        arr = _as_float_array(values)
    else:
        arr = _as_float_array(values)
    if arr.ndim >= 1 and arr.shape[0] == len(client_ids):
        arr = arr.reshape(-1).astype(np.float64)
        if arr.size != len(client_ids):
            return out
        if order is not None:
            arr = arr[np.asarray(order, dtype=np.int64)]
        out = arr
    return out


def _optional_scores_from_any(
    values: Any,
    client_ids: list[str],
    column: str,
    order: list[int] | None = None,
    aliases: list[str] | None = None,
) -> Array | None:
    if values is None:
        return None
    default = np.full(len(client_ids), np.nan, dtype=np.float64)
    for key in [column, *(aliases or [])]:
        scores = _scores_from_any(values, client_ids, key, default, order=order)
        if np.isfinite(scores).any():
            return scores
    return None


def _class_variances(x: Array, y: Array, prototypes: Array, num_classes: int) -> Array:
    variances = np.zeros_like(prototypes)
    y = y.astype(np.int64)
    for cls in range(num_classes):
        mask = y == cls
        if mask.any():
            diff = x[mask] - prototypes[cls]
            variances[cls] = np.mean(diff * diff, axis=0)
    return variances


def _client_numeric_id(client_id) -> int:
    if isinstance(client_id, (int, np.integer)):
        return int(client_id)
    text = str(client_id)
    digits = "".join(ch for ch in text if ch.isdigit())
    return int(digits) if digits else abs(hash(text)) % (10**8)


def _order_signatures(loaded, client_ids: list[str]) -> list[dict]:
    if isinstance(loaded, dict):
        if all(cid in loaded for cid in client_ids):
            return [_normalize_signature(loaded[cid]) for cid in client_ids]
        out = []
        for cid in client_ids:
            numeric = _client_numeric_id(cid)
            if numeric in loaded:
                out.append(_normalize_signature(loaded[numeric]))
            elif str(numeric) in loaded:
                out.append(_normalize_signature(loaded[str(numeric)]))
            else:
                raise KeyError(f"Missing FedGeo signature for client {cid}")
        return out
    signatures = list(loaded)
    by_id = {str(sig.get("client_id")): sig for sig in signatures}
    out = []
    for cid in client_ids:
        out.append(_normalize_signature(by_id.get(str(cid)) or by_id.get(str(_client_numeric_id(cid))) or signatures[len(out)]))
    return out


def _signatures_to_matrix(signatures: list[dict]) -> Array:
    rows = []
    for signature in signatures:
        protos = signature.get("prototypes", {})
        if isinstance(protos, dict) and protos:
            rows.append(np.concatenate([_as_float_array(protos[k]).reshape(-1) for k in sorted(protos.keys())]))
        else:
            rows.append(_as_float_array(signature.get("label_histogram", [0.0])).reshape(-1))
    return np.vstack(rows)


def _is_float(value: str) -> bool:
    try:
        float(value)
        return True
    except ValueError:
        return False


def label_distributions(clients: list, num_classes: int) -> Array:
    distributions = np.zeros((len(clients), num_classes), dtype=np.float64)
    for i, client in enumerate(clients):
        counts = np.bincount(client.y_train.astype(np.int64), minlength=num_classes).astype(np.float64)
        distributions[i] = counts / np.clip(counts.sum(), 1e-12, None)
    return distributions


def label_distance_matrix(clients: list, num_classes: int) -> Array:
    dist = label_distributions(clients, num_classes)
    n = dist.shape[0]
    out = np.zeros((n, n), dtype=np.float64)
    for i in range(n):
        for j in range(i + 1, n):
            out[i, j] = out[j, i] = _jensen_shannon_distance(dist[i], dist[j])
    return out


def _jensen_shannon_distance(p: Array, q: Array) -> float:
    p = np.clip(p, 1e-12, None)
    q = np.clip(q, 1e-12, None)
    p = p / p.sum()
    q = q / q.sum()
    m = 0.5 * (p + q)
    js = 0.5 * np.sum(p * np.log(p / m)) + 0.5 * np.sum(q * np.log(q / m))
    return float(np.sqrt(max(js, 0.0)))
