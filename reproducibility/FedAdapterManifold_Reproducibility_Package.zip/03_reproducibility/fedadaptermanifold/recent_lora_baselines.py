from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from .adapters import LoRAAdapter, pad_factors
from .aggregation import fedavg_lora
from .subspace import subspace_distance_matrix
from .training import (
    _clip_pair_by_norm,
    _stabilize_adapter,
    cross_entropy_and_grad,
    evaluate_adapter,
    evaluate_weight,
    softmax,
    train_lora_adapter,
)


Array = np.ndarray


@dataclass
class FedExLoRAResult:
    effective_adapter: LoRAAdapter
    factor_adapter: LoRAAdapter
    base_residual: Array
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class FedSALoRAResult:
    shared_a: Array
    personal_adapters: list[LoRAAdapter]
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class FedPissaResult:
    shared_b: Array
    personal_adapters: list[LoRAAdapter]
    projection_matrices: list[Array]
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class ClusteredExpertLoRAResult:
    client_adapters: list[LoRAAdapter]
    assignments: Array
    per_client_metrics: list[dict]
    round_history: list[dict]
    experts: list[LoRAAdapter] | None = None
    route_matrices: list[Array] | None = None


@dataclass
class FedALTVisualResult:
    local_adapters: list[LoRAAdapter]
    rest_of_world_adapters: list[LoRAAdapter]
    route_matrices: list[Array]
    effective_adapters: list[LoRAAdapter]
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class FedSmoothLoRAResult:
    effective_adapter: LoRAAdapter
    rank_matched_adapter: LoRAAdapter
    cumulative_base_delta: Array
    client_cumulative_deltas: list[Array]
    cumulative_projection_residual: Array
    per_client_metrics: list[dict]
    rank_matched_per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class LoRAFAIRResult:
    global_adapter: LoRAAdapter
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class TeLoRAResult:
    global_adapter: LoRAAdapter
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class SubspaceRegLoRAResult:
    global_adapter: LoRAAdapter
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class DyscoLoRAResult:
    client_adapters: list[LoRAAdapter]
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass(frozen=True)
class SubspaceRegularizer:
    value: float
    grad_a: Array
    grad_b: Array


def fedex_exact_aggregate(
    local_adapters: list[LoRAAdapter],
    previous_residual: Array,
    weights: Array | None = None,
    name: str = "fedex_lora_global",
) -> tuple[LoRAAdapter, Array, float]:
    """FedEx-LoRA aggregation with an exact residual folded into the base.

    The returned state satisfies

    ``new_residual + B_bar @ A_bar == old_residual + sum_i p_i B_i @ A_i``.

    This is the visual linear-head counterpart of the official residual-base
    update; no SVD truncation is applied.
    """

    if not local_adapters:
        raise ValueError("fedex_exact_aggregate requires at least one adapter")
    ranks = {int(adapter.rank) for adapter in local_adapters}
    if len(ranks) != 1:
        raise ValueError("FedEx-LoRA fidelity runs require a common LoRA rank")
    rank = int(next(iter(ranks)))
    weights = _normalized_weights(weights, len(local_adapters))
    previous_residual = np.asarray(previous_residual, dtype=np.float64)
    if previous_residual.shape != local_adapters[0].delta().shape:
        raise ValueError("previous_residual shape does not match the LoRA update")

    averaged_update = np.zeros_like(previous_residual)
    for weight, adapter in zip(weights, local_adapters):
        averaged_update += float(weight) * adapter.delta()
    factor_adapter = fedavg_lora(local_adapters, weights=weights, target_rank=rank, name=name)
    new_residual = previous_residual + averaged_update - factor_adapter.delta()
    exact_target = previous_residual + averaged_update
    exact_error = float(np.linalg.norm(new_residual + factor_adapter.delta() - exact_target))
    return factor_adapter, new_residual, exact_error


def run_fedex_lora_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "FedEx-LoRA",
    trainer_seed_offset: int = 300,
    weight_decay: float = 1e-4,
) -> FedExLoRAResult:
    """Run the official FedEx-LoRA residual-base update in the visual protocol."""

    rank_list = _common_rank_list(ranks, len(clients), method)
    rank = rank_list[0]
    trainer_seed = int(seed + trainer_seed_offset)
    global_adapter = _shared_initial_adapter(base_weight, rank, trainer_seed, "fedex_lora")
    residual = np.zeros_like(base_weight, dtype=np.float64)
    sample_weights = _client_sample_weights(clients)
    history: list[dict] = []

    for round_idx in range(int(rounds)):
        local_adapters: list[LoRAAdapter] = []
        effective_base = np.asarray(base_weight, dtype=np.float64) + residual
        for client_idx, client in enumerate(clients):
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                effective_base,
                rank=rank,
                init_adapter=global_adapter,
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=trainer_seed + 1000 * round_idx + client_idx,
                name=f"fedex_lora_{client.client_id}_r{round_idx}",
            )
            local_adapters.append(adapter)
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "trainer_seed": trainer_seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": rank,
                }
            )
        global_adapter, residual, exact_error = fedex_exact_aggregate(
            local_adapters,
            residual,
            weights=sample_weights,
            name=f"fedex_lora_global_r{round_idx + 1}",
        )
        for client_idx, row in enumerate(history[-len(clients) :]):
            row["exact_aggregation_error"] = exact_error
            row["base_residual_fro_norm"] = float(np.linalg.norm(residual))

    effective_delta = residual + global_adapter.delta()
    effective_rank = int(min(effective_delta.shape))
    effective_adapter = LoRAAdapter.from_delta(
        effective_delta,
        rank=effective_rank,
        alpha=float(effective_rank),
        name="fedex_lora_effective_update",
    )
    per_client_metrics = _evaluate_weight_for_clients(
        method,
        clients,
        np.asarray(base_weight, dtype=np.float64) + effective_delta,
        seed,
        dataset,
        heterogeneity_setting,
        rounds,
        rank,
        {
            "effective_rank": int(np.linalg.matrix_rank(effective_delta)),
            "base_residual_fro_norm": float(np.linalg.norm(residual)),
        },
    )
    return FedExLoRAResult(
        effective_adapter=effective_adapter,
        factor_adapter=global_adapter,
        base_residual=residual,
        per_client_metrics=per_client_metrics,
        round_history=history,
    )


def run_fedsa_lora_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "FedSA-LoRA",
    trainer_seed_offset: int = 300,
    weight_decay: float = 1e-4,
    shared_axis_donor_mask: Array | None = None,
) -> FedSALoRAResult:
    """Run FedSA-LoRA: aggregate A while retaining each client's B locally."""

    rank_list = _common_rank_list(ranks, len(clients), method)
    rank = rank_list[0]
    trainer_seed = int(seed + trainer_seed_offset)
    initial = _shared_initial_adapter(base_weight, rank, trainer_seed, "fedsa_lora")
    shared_a = initial.A.copy()
    personal_b = [initial.B.copy() for _ in clients]
    sample_weights = _client_sample_weights(clients)
    if shared_axis_donor_mask is None:
        shared_axis_weights = sample_weights.copy()
    else:
        donor_mask = np.asarray(shared_axis_donor_mask, dtype=bool)
        if donor_mask.shape != (len(clients),):
            raise ValueError(
                f"shared_axis_donor_mask shape {donor_mask.shape} does not match {(len(clients),)}"
            )
        shared_axis_weights = sample_weights * donor_mask.astype(np.float64)
        if float(shared_axis_weights.sum()) <= 0.0:
            raise ValueError("shared_axis_donor_mask must retain at least one client")
        shared_axis_weights /= shared_axis_weights.sum()
    history: list[dict] = []

    for round_idx in range(int(rounds)):
        local_adapters: list[LoRAAdapter] = []
        for client_idx, client in enumerate(clients):
            init_adapter = LoRAAdapter(
                input_dim=base_weight.shape[1],
                output_dim=base_weight.shape[0],
                rank=rank,
                A=shared_a.copy(),
                B=personal_b[client_idx].copy(),
                alpha=float(rank),
                name=f"fedsa_lora_init_{client.client_id}_r{round_idx}",
            )
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                base_weight,
                rank=rank,
                init_adapter=init_adapter,
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=trainer_seed + 1000 * round_idx + client_idx,
                name=f"fedsa_lora_{client.client_id}_r{round_idx}",
            )
            local_adapters.append(adapter)
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "trainer_seed": trainer_seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": rank,
                }
            )
        shared_a = sum(float(weight) * adapter.A for weight, adapter in zip(shared_axis_weights, local_adapters))
        personal_b = [adapter.B.copy() for adapter in local_adapters]
        a_dispersion = float(
            sum(
                float(weight) * np.linalg.norm(adapter.A - shared_a) ** 2
                for weight, adapter in zip(sample_weights, local_adapters)
            )
        )
        for client_idx, row in enumerate(history[-len(clients) :]):
            row["shared_a_dispersion"] = a_dispersion
            row["uploaded_factor"] = "A"
            row["retained_local_factor"] = "B"
            row["shared_axis_donor"] = bool(shared_axis_weights[client_idx] > 0.0)

    personal_adapters = [
        LoRAAdapter(
            input_dim=base_weight.shape[1],
            output_dim=base_weight.shape[0],
            rank=rank,
            A=shared_a.copy(),
            B=client_b.copy(),
            alpha=float(rank),
            name=f"fedsa_lora_client_{client.client_id}",
        )
        for client, client_b in zip(clients, personal_b)
    ]
    per_client_metrics = []
    for client, adapter in zip(clients, personal_adapters):
        metrics = evaluate_adapter(client.x_test, client.y_test, base_weight, adapter)
        per_client_metrics.append(
            {
                "method": method,
                "seed": seed,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": rounds,
                "client_id": client.client_id,
                "domain": client.domain,
                "accuracy": metrics["accuracy"],
                "loss": metrics["loss"],
                "rank": rank,
                "uploaded_factor": "A",
                "retained_local_factor": "B",
            }
        )
    return FedSALoRAResult(
        shared_a=shared_a,
        personal_adapters=personal_adapters,
        per_client_metrics=per_client_metrics,
        round_history=history,
    )


def fedpissa_decorrelated_aggregate(
    local_adapters: list[LoRAAdapter],
    weights: Array | None = None,
    decorrelation_strength: float = 0.05,
    tail_start: int | None = None,
) -> tuple[Array, list[Array], list[dict]]:
    """Apply FedPissa's paper-defined B aggregation and tail projection.

    This is an equation-level port of Eqs. (4)--(6) in the ICML 2026
    paper.  The released paper has no public reference implementation at
    the time of this audit, so the function intentionally exposes every
    projection and algebraic diagnostic needed to verify the port.

    ``tail_start`` is one-indexed, matching the paper's ``Rank x`` notation.
    The default starts at the second half of the LoRA spectrum (e.g. Rank 5
    for rank 8), which is the paper's stable setting.  Eigenvectors are
    returned by ``eigh`` in ascending order, hence the first ``tail_dim``
    vectors are the least-significant components of the covariance.
    """

    if len(local_adapters) < 2:
        raise ValueError("FedPissa requires at least two clients")
    rank_list = [int(adapter.rank) for adapter in local_adapters]
    if len(set(rank_list)) != 1:
        raise ValueError("FedPissa equation-port runs require a common LoRA rank")
    rank = rank_list[0]
    shapes = {(adapter.A.shape, adapter.B.shape) for adapter in local_adapters}
    if len(shapes) != 1:
        raise ValueError("FedPissa requires aligned LoRA factor shapes")
    strength = float(decorrelation_strength)
    if not np.isfinite(strength) or strength < 0.0:
        raise ValueError("decorrelation_strength must be finite and nonnegative")

    sample_weights = _normalized_weights(weights, len(local_adapters))
    b_average = sum(
        float(weight) * adapter.B
        for weight, adapter in zip(sample_weights, local_adapters)
    )
    start = int(rank // 2 + 1 if tail_start is None else tail_start)
    if start < 1 or start > rank:
        raise ValueError(f"tail_start must lie in [1, {rank}], got {start}")
    tail_dim = rank - start + 1

    projections: list[Array] = []
    diagnostics: list[dict] = []
    correction = np.zeros_like(b_average, dtype=np.float64)
    for receiver_idx, receiver in enumerate(local_adapters):
        other_mass = float(1.0 - sample_weights[receiver_idx])
        if other_mass <= 1e-12:
            raise ValueError("FedPissa leave-one-client-out covariance has zero mass")
        covariance = np.zeros((rank, rank), dtype=np.float64)
        for donor_idx, donor in enumerate(local_adapters):
            if donor_idx == receiver_idx:
                continue
            alpha = float(sample_weights[donor_idx] / other_mass)
            covariance += alpha * (donor.A @ donor.A.T)
        covariance = 0.5 * (covariance + covariance.T)
        eigenvalues, eigenvectors = np.linalg.eigh(covariance)
        tail_basis = eigenvectors[:, :tail_dim]
        projection = tail_basis @ tail_basis.T
        projections.append(projection)
        residual = (receiver.B - b_average) @ projection
        # FedPissa Eq. (4) weights every projected residual by the same
        # sample proportion used in B_avg.
        correction += float(sample_weights[receiver_idx]) * residual
        diagnostics.append(
            {
                "receiver_index": receiver_idx,
                "aggregation_weight": float(sample_weights[receiver_idx]),
                "tail_start": start,
                "tail_dimension": tail_dim,
                "smallest_covariance_eigenvalue": float(eigenvalues[0]),
                "largest_tail_covariance_eigenvalue": float(eigenvalues[tail_dim - 1]),
                "projection_rank": int(np.linalg.matrix_rank(projection, tol=1e-10)),
                "projection_symmetry_error": float(np.linalg.norm(projection - projection.T)),
                "projection_idempotence_error": float(np.linalg.norm(projection @ projection - projection)),
                "personalized_residual_norm": float(np.linalg.norm(residual)),
            }
        )
    aggregated_b = b_average + strength * correction
    return aggregated_b, projections, diagnostics


def run_fedpissa_visual_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "FedPissa-EquationPort",
    decorrelation_strength: float = 0.05,
    tail_start: int | None = None,
    trainer_seed_offset: int = 2300,
    weight_decay: float = 1e-4,
) -> FedPissaResult:
    """Fair visual port of FedPissa under the shared client protocol.

    Clients train and upload ``A`` and ``B`` because the server requires
    ``A A^T`` to construct each leave-one-client-out covariance. Only ``B`` is
    aggregated and broadcast, while ``A`` remains personalized across rounds.
    The visual default ``lambda=0.05`` follows the paper's DomainNet
    sensitivity study. No test labels are used by the aggregation rule.
    """

    rank = _common_rank_list(ranks, len(clients), method)[0]
    trainer_seed = int(seed + trainer_seed_offset)
    initial = _shared_initial_adapter(base_weight, rank, trainer_seed, "fedpissa")
    shared_b = initial.B.copy()
    personal_a = [initial.A.copy() for _ in clients]
    sample_weights = _client_sample_weights(clients)
    projections = [np.eye(rank, dtype=np.float64) for _ in clients]
    history: list[dict] = []

    for round_idx in range(int(rounds)):
        local_adapters: list[LoRAAdapter] = []
        local_stats: list = []
        for client_idx, client in enumerate(clients):
            init_adapter = LoRAAdapter(
                input_dim=base_weight.shape[1],
                output_dim=base_weight.shape[0],
                rank=rank,
                A=personal_a[client_idx].copy(),
                B=shared_b.copy(),
                alpha=float(rank),
                name=f"fedpissa_init_{client.client_id}_r{round_idx}",
            )
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                base_weight,
                rank=rank,
                init_adapter=init_adapter,
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=trainer_seed + 1000 * round_idx + client_idx,
                name=f"fedpissa_{client.client_id}_r{round_idx + 1}",
            )
            local_adapters.append(adapter)
            local_stats.append(stats)

        shared_b, projections, aggregate_stats = fedpissa_decorrelated_aggregate(
            local_adapters,
            weights=sample_weights,
            decorrelation_strength=decorrelation_strength,
            tail_start=tail_start,
        )
        personal_a = [adapter.A.copy() for adapter in local_adapters]
        for client_idx, (client, stats, projection_stats) in enumerate(
            zip(clients, local_stats, aggregate_stats)
        ):
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "trainer_seed": trainer_seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": rank,
                    "uploaded_factors": "A,B",
                    "aggregated_factor": "B",
                    "broadcast_factor": "B",
                    "retained_local_factor": "A",
                    "decorrelation_strength": float(decorrelation_strength),
                    "implementation_fidelity": "paper-equation-port-no-public-code",
                    **projection_stats,
                }
            )

    personal_adapters = [
        LoRAAdapter(
            input_dim=base_weight.shape[1],
            output_dim=base_weight.shape[0],
            rank=rank,
            A=client_a.copy(),
            B=shared_b.copy(),
            alpha=float(rank),
            name=f"fedpissa_client_{client.client_id}",
        )
        for client, client_a in zip(clients, personal_a)
    ]
    per_client_metrics = _evaluate_adapters_for_clients(
        method,
        clients,
        base_weight,
        personal_adapters,
        seed,
        dataset,
        heterogeneity_setting,
        rounds,
        rank,
    )
    for row in per_client_metrics:
        row.update(
            {
                "uploaded_factors": "A,B",
                "aggregated_factor": "B",
                "broadcast_factor": "B",
                "retained_local_factor": "A",
                "decorrelation_strength": float(decorrelation_strength),
                "tail_start": int(rank // 2 + 1 if tail_start is None else tail_start),
                "implementation_fidelity": "paper-equation-port-no-public-code",
            }
        )
    return FedPissaResult(
        shared_b=shared_b,
        personal_adapters=personal_adapters,
        projection_matrices=projections,
        per_client_metrics=per_client_metrics,
        round_history=history,
    )


def run_fedlease_visual_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "FedLEASE-OfficialPort",
    max_experts: int = 4,
    warmup_rounds: int = 5,
    trainer_seed_offset: int = 1300,
    weight_decay: float = 1e-4,
) -> ClusteredExpertLoRAResult:
    """Official-source visual port of FedLEASE's defining recurrence.

    The port keeps the released local warm-up, B-cosine/silhouette allocation,
    assigned-expert factor training, ``2K-1`` adaptive top-K router, group-wise
    expert aggregation, and within-group router aggregation.  Only the native
    language model and task pipeline are replaced by the shared visual head.
    """

    rank = _common_rank_list(ranks, len(clients), method)[0]
    trainer_seed = int(seed + trainer_seed_offset)
    shared = _shared_initial_adapter(base_weight, rank, trainer_seed, "fedlease_visual")
    personal = [shared.copy(name=f"fedlease_warmup_{client.client_id}") for client in clients]
    assignments = np.zeros(len(clients), dtype=np.int64)
    experts = [shared]
    sample_counts = np.asarray([len(client.y_train) for client in clients], dtype=np.float64)
    history: list[dict] = []
    warmup_cap = int(rounds) if int(rounds) <= 1 else int(rounds) - 1
    warmup_rounds = min(max(1, int(warmup_rounds)), warmup_cap)

    for round_idx in range(warmup_rounds):
        next_personal: list[LoRAAdapter] = []
        for client_idx, client in enumerate(clients):
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                base_weight,
                rank=rank,
                init_adapter=personal[client_idx],
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=trainer_seed + 1000 * round_idx + client_idx,
                name=f"fedlease_visual_{client.client_id}_r{round_idx + 1}",
            )
            next_personal.append(adapter)
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": rank,
                    "phase": "warmup",
                    "expert_id": 0,
                    "num_experts": 1,
                }
            )
        personal = next_personal

    distance = _b_cosine_distance(personal)
    assignments, selected_k, silhouette = _silhouette_agglomerative_partition(
        distance,
        max_clusters=max_experts,
    )
    experts = []
    for cluster_id in range(int(selected_k)):
        members = np.flatnonzero(assignments == cluster_id)
        experts.append(
            fedavg_lora(
                [personal[index] for index in members],
                weights=np.ones(len(members), dtype=np.float64) / float(len(members)),
                target_rank=rank,
                name=f"fedlease_visual_expert_{cluster_id}_warmup",
            )
        )

    input_dim = int(base_weight.shape[1])
    route_dim = 2 * int(selected_k) - 1
    route_matrices = []
    for client_idx in range(len(clients)):
        rng = np.random.default_rng(trainer_seed + 50000 + client_idx)
        bound = math.sqrt(6.0 / max(1, input_dim + route_dim))
        route_matrices.append(rng.uniform(-bound, bound, size=(route_dim, input_dim)))

    for round_idx in range(warmup_rounds, int(rounds)):
        trained_experts: list[LoRAAdapter] = []
        trained_routes: list[Array] = []
        train_stats: list[dict] = []
        for client_idx, client in enumerate(clients):
            trained, router, stats = _train_fedlease_routed_client(
                x=client.x_train,
                y=client.y_train,
                base_weight=base_weight,
                experts=experts,
                assigned_expert=int(assignments[client_idx]),
                route_matrix=route_matrices[client_idx],
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=trainer_seed + 1000 * round_idx + client_idx,
            )
            trained_experts.append(trained)
            trained_routes.append(router)
            train_stats.append(stats)

        experts, route_matrices = _fedlease_server_aggregate(
            trained_experts,
            trained_routes,
            assignments,
            rank=rank,
            round_id=round_idx + 1,
        )

        for client_idx, (client, stats) in enumerate(zip(clients, train_stats)):
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats["loss"],
                    "train_accuracy": stats["accuracy"],
                    "rank": rank,
                    "phase": "adaptive_route",
                    "expert_id": int(assignments[client_idx]),
                    "num_experts": int(selected_k),
                    "silhouette_score": float(silhouette),
                    "router_parameters": int(route_matrices[client_idx].size),
                }
            )

    metrics: list[dict] = []
    client_adapters: list[LoRAAdapter] = []
    for client_idx, client in enumerate(clients):
        routed = _evaluate_fedlease_route(
            client.x_test,
            client.y_test,
            base_weight,
            experts,
            route_matrices[client_idx],
            int(assignments[client_idx]),
        )
        train_weights, _, _ = _fedlease_adaptive_route_weights(
            client.x_train,
            route_matrices[client_idx],
            int(assignments[client_idx]),
            len(experts),
        )
        mean_weights = train_weights.mean(axis=0)
        effective_delta = sum(float(weight) * expert.delta() for weight, expert in zip(mean_weights, experts))
        effective_rank = min(rank * len(experts), min(base_weight.shape))
        client_adapters.append(
            LoRAAdapter.from_delta(
                effective_delta,
                rank=effective_rank,
                alpha=float(effective_rank),
                name=f"fedlease_effective_{client.client_id}",
            )
        )
        metrics.append(
            {
                "method": method,
                "seed": seed,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": rounds,
                "client_id": client.client_id,
                "domain": client.domain,
                "accuracy": routed["accuracy"],
                "loss": routed["loss"],
                "rank": rank,
                "upload_rank": rank,
                "num_experts": int(selected_k),
                "deployment_rank_upper_bound": int(effective_rank),
                "router_parameters": int(route_matrices[client_idx].size),
                "expert_or_cluster_id": int(assignments[client_idx]),
                "mean_distinct_experts_per_sample": routed["mean_distinct_experts"],
            }
        )
    return ClusteredExpertLoRAResult(
        client_adapters,
        assignments,
        metrics,
        history,
        experts=experts,
        route_matrices=route_matrices,
    )


def _fedlease_server_aggregate(
    trained_assigned_experts: list[LoRAAdapter],
    trained_routes: list[Array],
    assignments: Array,
    rank: int,
    round_id: int,
) -> tuple[list[LoRAAdapter], list[Array]]:
    """Official group-wise expert and route aggregation in visual state form."""

    assignments = np.asarray(assignments, dtype=np.int64)
    if len(trained_assigned_experts) != len(assignments) or len(trained_routes) != len(assignments):
        raise ValueError("FedLEASE server inputs must contain one assigned expert and router per client")
    next_experts: list[LoRAAdapter] = []
    next_routes = [np.asarray(matrix, dtype=np.float64).copy() for matrix in trained_routes]
    for cluster_id in range(int(assignments.max()) + 1):
        members = np.flatnonzero(assignments == cluster_id)
        next_experts.append(
            fedavg_lora(
                [trained_assigned_experts[index] for index in members],
                weights=np.ones(len(members), dtype=np.float64) / float(len(members)),
                target_rank=rank,
                name=f"fedlease_visual_expert_{cluster_id}_r{round_id}",
            )
        )
        mean_router = np.mean([trained_routes[index] for index in members], axis=0)
        for index in members:
            next_routes[int(index)] = mean_router.copy()
    return next_experts, next_routes


def _fedlease_adaptive_route_weights(
    x: Array,
    route_matrix: Array,
    own_expert: int,
    num_experts: int,
) -> tuple[Array, Array, Array]:
    """Released ``2K-1`` top-K route mapped to K LoRA experts."""

    x = np.asarray(x, dtype=np.float64)
    route_matrix = np.asarray(route_matrix, dtype=np.float64)
    num_experts = int(num_experts)
    expected = (2 * num_experts - 1, x.shape[1])
    if route_matrix.shape != expected:
        raise ValueError(f"FedLEASE route matrix {route_matrix.shape} != {expected}")
    if not 0 <= int(own_expert) < num_experts:
        raise ValueError("own_expert is outside the expert bank")
    logits = x @ route_matrix.T
    selected_dims = np.argsort(-logits, axis=1, kind="mergesort")[:, :num_experts]
    selected_logits = np.take_along_axis(logits, selected_dims, axis=1)
    selected_weights = softmax(selected_logits)
    mapping = np.arange(2 * num_experts - 1, dtype=np.int64)
    mapping[num_experts:] = int(own_expert)
    selected_experts = mapping[selected_dims]
    weights = np.zeros((x.shape[0], num_experts), dtype=np.float64)
    for slot in range(num_experts):
        np.add.at(weights, (np.arange(x.shape[0]), selected_experts[:, slot]), selected_weights[:, slot])
    return weights, selected_dims, selected_weights


def _fedlease_routed_logits(
    x: Array,
    base_weight: Array,
    experts: list[LoRAAdapter],
    route_matrix: Array,
    own_expert: int,
) -> tuple[Array, Array, Array, Array, Array]:
    weights, selected_dims, selected_weights = _fedlease_adaptive_route_weights(
        x, route_matrix, own_expert, len(experts)
    )
    expert_outputs = np.stack([np.asarray(x) @ expert.delta().T for expert in experts], axis=1)
    mixture = np.einsum("nk,nkc->nc", weights, expert_outputs)
    logits = np.asarray(x) @ np.asarray(base_weight).T + mixture
    return logits, weights, selected_dims, selected_weights, expert_outputs


def _train_fedlease_routed_client(
    x: Array,
    y: Array,
    base_weight: Array,
    experts: list[LoRAAdapter],
    assigned_expert: int,
    route_matrix: Array,
    epochs: int,
    lr: float,
    batch_size: int,
    weight_decay: float,
    seed: int,
) -> tuple[LoRAAdapter, Array, dict]:
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.int64)
    trainable = experts[int(assigned_expert)].copy(name="fedlease_local_expert")
    router = np.asarray(route_matrix, dtype=np.float64).copy()
    rng = np.random.default_rng(seed)
    batch_size = max(1, min(int(batch_size), len(y)))
    bank = [expert.copy() for expert in experts]

    for _ in range(int(epochs)):
        order = rng.permutation(len(y))
        for start in range(0, len(y), batch_size):
            indices = order[start : start + batch_size]
            xb = x[indices]
            yb = y[indices]
            bank[int(assigned_expert)] = trainable
            logits, weights, selected_dims, selected_weights, expert_outputs = _fedlease_routed_logits(
                xb, base_weight, bank, router, int(assigned_expert)
            )
            _, grad_logits = cross_entropy_and_grad(logits, yb)
            assigned_weights = weights[:, int(assigned_expert)]
            grad_delta = (grad_logits * assigned_weights[:, None]).T @ xb
            grad_b = trainable.scale * (grad_delta @ trainable.A.T) + weight_decay * trainable.B
            grad_a = trainable.scale * (trainable.B.T @ grad_delta) + weight_decay * trainable.A

            mixture = np.einsum("nk,nkc->nc", weights, expert_outputs)
            mapping = np.arange(2 * len(bank) - 1, dtype=np.int64)
            mapping[len(bank):] = int(assigned_expert)
            grad_router = weight_decay * router
            for slot in range(len(bank)):
                dims = selected_dims[:, slot]
                expert_ids = mapping[dims]
                outputs = expert_outputs[np.arange(len(xb)), expert_ids]
                grad_selected = selected_weights[:, slot] * np.sum(grad_logits * (outputs - mixture), axis=1)
                for route_dim in np.unique(dims):
                    mask = dims == route_dim
                    grad_router[int(route_dim)] += np.sum(grad_selected[mask, None] * xb[mask], axis=0)

            joint_norm = float(np.sqrt(np.sum(grad_a * grad_a) + np.sum(grad_b * grad_b)))
            if joint_norm > 5.0:
                scale = 5.0 / max(joint_norm, 1e-12)
                grad_a *= scale
                grad_b *= scale
            route_norm = float(np.linalg.norm(grad_router))
            if route_norm > 5.0:
                grad_router *= 5.0 / max(route_norm, 1e-12)
            trainable.A -= float(lr) * grad_a
            trainable.B -= float(lr) * grad_b
            router -= float(lr) * grad_router
            trainable.A = np.clip(np.nan_to_num(trainable.A), -5.0, 5.0)
            trainable.B = np.clip(np.nan_to_num(trainable.B), -5.0, 5.0)
            router = np.clip(np.nan_to_num(router), -5.0, 5.0)

    bank[int(assigned_expert)] = trainable
    metrics = _evaluate_fedlease_route(x, y, base_weight, bank, router, int(assigned_expert))
    return trainable, router, metrics


def _evaluate_fedlease_route(
    x: Array,
    y: Array,
    base_weight: Array,
    experts: list[LoRAAdapter],
    route_matrix: Array,
    own_expert: int,
) -> dict[str, float]:
    logits, weights, _, _, _ = _fedlease_routed_logits(x, base_weight, experts, route_matrix, own_expert)
    loss, _ = cross_entropy_and_grad(logits.copy(), np.asarray(y, dtype=np.int64))
    prediction = logits.argmax(axis=1)
    distinct = np.sum(weights > 1e-12, axis=1)
    return {
        "loss": float(loss),
        "accuracy": float(np.mean(prediction == np.asarray(y, dtype=np.int64))),
        "mean_distinct_experts": float(np.mean(distinct)),
    }


def run_hilora_visual_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "HiLoRA-Visual",
    max_clusters: int = 4,
    trainer_seed_offset: int = 1700,
    weight_decay: float = 1e-4,
) -> ClusteredExpertLoRAResult:
    """Budget-matched visual implementation of hierarchical LoRA sharing.

    The total reported rank is split across root, cluster, and leaf tiers.
    Principal-angle clustering and cross-tier residual projections reproduce
    the semantic hierarchy without granting three times the LoRA budget.
    """

    rank = _common_rank_list(ranks, len(clients), method)[0]
    root_rank, cluster_rank, leaf_rank = _tier_rank_split(rank)
    trainer_seed = int(seed + trainer_seed_offset)
    states = [_shared_initial_adapter(base_weight, rank, trainer_seed, "hilora_visual") for _ in clients]
    sample_weights = _client_sample_weights(clients)
    assignments = np.zeros(len(clients), dtype=np.int64)
    history: list[dict] = []

    for round_idx in range(int(rounds)):
        trained: list[LoRAAdapter] = []
        for client_idx, client in enumerate(clients):
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                base_weight,
                rank=rank,
                init_adapter=states[client_idx],
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=trainer_seed + 1000 * round_idx + client_idx,
                name=f"hilora_visual_{client.client_id}_r{round_idx + 1}",
            )
            trained.append(adapter)
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": rank,
                    "root_rank": root_rank,
                    "cluster_rank": cluster_rank,
                    "leaf_rank": leaf_rank,
                }
            )
        distance, _ = subspace_distance_matrix(trained)
        assignments, selected_k, silhouette = _silhouette_agglomerative_partition(
            distance,
            max_clusters=max_clusters,
        )
        mean_delta = sum(float(weight) * adapter.delta() for weight, adapter in zip(sample_weights, trained))
        root = LoRAAdapter.from_delta(mean_delta, rank=root_rank, alpha=float(root_rank), name="hilora_root")
        root_delta = root.delta()
        cluster_deltas: dict[int, Array] = {}
        for cluster_id in range(int(assignments.max()) + 1):
            members = np.flatnonzero(assignments == cluster_id)
            weights = sample_weights[members]
            weights /= np.clip(weights.sum(), 1e-12, None)
            residual = sum(
                float(weight) * (trained[index].delta() - root_delta)
                for weight, index in zip(weights, members)
            )
            residual = _orthogonal_residual(residual, root_delta)
            cluster_deltas[cluster_id] = LoRAAdapter.from_delta(
                residual,
                rank=cluster_rank,
                alpha=float(cluster_rank),
                name=f"hilora_cluster_{cluster_id}",
            ).delta()
        states = []
        for client_idx, adapter in enumerate(trained):
            cluster_delta = cluster_deltas[int(assignments[client_idx])]
            parent = root_delta + cluster_delta
            leaf = _orthogonal_residual(adapter.delta() - parent, parent)
            leaf_delta = LoRAAdapter.from_delta(
                leaf,
                rank=leaf_rank,
                alpha=float(leaf_rank),
                name=f"hilora_leaf_{client_idx}",
            ).delta()
            states.append(
                LoRAAdapter.from_delta(
                    parent + leaf_delta,
                    rank=rank,
                    alpha=float(rank),
                    name=f"hilora_visual_client_{client_idx}_r{round_idx + 1}",
                )
            )
        for row, cluster_id in zip(history[-len(clients) :], assignments):
            row["cluster_id"] = int(cluster_id)
            row["num_clusters"] = int(selected_k)
            row["silhouette_score"] = silhouette

    metrics = _evaluate_adapters_for_clients(
        method,
        clients,
        base_weight,
        states,
        seed,
        dataset,
        heterogeneity_setting,
        rounds,
        rank,
        assignments=assignments,
    )
    return ClusteredExpertLoRAResult(states, assignments, metrics, history)


def run_fedtree_lora_visual_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "FedTreeLoRA-Visual-Port",
    warmup_rounds: int = 5,
    max_clusters: int = 4,
    search_range_k: int = 3,
    single_cluster_score: float = 0.02,
    routing_candidates: tuple[float, ...] = (0.0, 0.25, 0.5, 0.75, 1.0),
    trainer_seed_offset: int = 2100,
    weight_decay: float = 1e-4,
) -> ClusteredExpertLoRAResult:
    """Single-layer visual port of the official FedTreeLoRA recurrence.

    The released method is a multi-layer RoBERTa/GLUE system.  For a visual
    LoRA layer, its progressive hierarchy reduces to one predeclared cluster
    count, followed by the official own-cluster/rest-of-clusters two-expert
    aggregation.  Clustering uses the released B-factor Frobenius distance,
    average linkage, silhouette selection, and single-cluster threshold.
    Routing weights are fit on client training data over a fixed grid; test
    labels never select a cluster or mixture.
    """

    rank = _common_rank_list(ranks, len(clients), method)[0]
    trainer_seed = int(seed + trainer_seed_offset)
    states = [
        _shared_initial_adapter(base_weight, rank, trainer_seed, "fedtree_visual")
        for _ in clients
    ]
    assignments = np.zeros(len(clients), dtype=np.int64)
    selected_k = 1
    silhouette = float(single_cluster_score)
    history: list[dict] = []
    warmup_rounds = int(np.clip(warmup_rounds, 0, max(int(rounds), 0)))

    for round_idx in range(int(rounds)):
        if round_idx == warmup_rounds and len(clients) > 1:
            distance = _b_frobenius_distance(states, normalize=True)
            assignments, selected_k, silhouette = _fedtree_single_layer_partition(
                distance,
                max_clusters=max_clusters,
                search_range_k=search_range_k,
                single_cluster_score=single_cluster_score,
            )

        trained: list[LoRAAdapter] = []
        for client_idx, client in enumerate(clients):
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                base_weight,
                rank=rank,
                init_adapter=states[client_idx],
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=trainer_seed + 1000 * round_idx + client_idx,
                name=f"fedtree_visual_{client.client_id}_r{round_idx + 1}",
            )
            trained.append(adapter)
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": rank,
                    "phase": "warmup" if round_idx < warmup_rounds else "two_expert",
                }
            )

        if round_idx < warmup_rounds or selected_k == 1:
            states = trained if round_idx < warmup_rounds else [
                fedavg_lora(trained, target_rank=rank, name=f"fedtree_global_r{round_idx + 1}")
                for _ in clients
            ]
            routing_weights = np.ones(len(clients), dtype=np.float64)
        else:
            cluster_centers: dict[int, LoRAAdapter] = {}
            for cluster_id in range(selected_k):
                members = np.flatnonzero(assignments == cluster_id)
                cluster_centers[cluster_id] = fedavg_lora(
                    [trained[index] for index in members],
                    target_rank=rank,
                    name=f"fedtree_cluster_{cluster_id}_r{round_idx + 1}",
                )
            states = []
            routing_weights = np.zeros(len(clients), dtype=np.float64)
            deployment_rank = min(2 * rank, min(base_weight.shape))
            for client_idx, client in enumerate(clients):
                own_id = int(assignments[client_idx])
                own = cluster_centers[own_id]
                rest = fedavg_lora(
                    [center for cluster_id, center in cluster_centers.items() if cluster_id != own_id],
                    target_rank=rank,
                    name=f"fedtree_rest_{client_idx}_r{round_idx + 1}",
                )
                candidates = []
                for own_weight in sorted({float(np.clip(value, 0.0, 1.0)) for value in routing_candidates}):
                    delta = own_weight * own.delta() + (1.0 - own_weight) * rest.delta()
                    effective = LoRAAdapter.from_delta(
                        delta,
                        rank=deployment_rank,
                        alpha=float(deployment_rank),
                        name=f"fedtree_client_{client_idx}_r{round_idx + 1}_w{own_weight:.2f}",
                    )
                    metrics = evaluate_adapter(client.x_train, client.y_train, base_weight, effective)
                    candidates.append((float(metrics["loss"]), -float(metrics["accuracy"]), -own_weight, effective))
                selected = min(candidates, key=lambda row: row[:3])
                routing_weights[client_idx] = -float(selected[2])
                states.append(selected[3])

        for row, cluster_id, own_weight in zip(history[-len(clients) :], assignments, routing_weights):
            row["cluster_id"] = int(cluster_id)
            row["num_clusters"] = int(selected_k)
            row["silhouette_score"] = float(silhouette)
            row["own_cluster_routing_weight"] = float(own_weight)
            row["deployment_rank"] = int(states[0].rank)

    metrics = _evaluate_adapters_for_clients(
        method,
        clients,
        base_weight,
        states,
        seed,
        dataset,
        heterogeneity_setting,
        rounds,
        rank,
        assignments=assignments,
    )
    for row, adapter in zip(metrics, states):
        row["deployment_rank"] = int(adapter.rank)
        row["num_clusters"] = int(selected_k)
    return ClusteredExpertLoRAResult(states, assignments, metrics, history)


def lorafair_refine_aggregate(
    local_adapters: list[LoRAAdapter],
    num_iterations: int = 1000,
    learning_rate: float = 0.01,
    lambda_reg: float = 1.0,
    seed: int = 0,
    name: str = "lorafair_global",
) -> tuple[LoRAAdapter, dict[str, float]]:
    """Apply the official LoRA-FAIR server-side B-factor refinement.

    The implementation follows the released ICCV 2025 code: uniformly
    average A, B, and BA; initialize a residual B with Xavier-uniform noise;
    and optimize column-wise cosine reconstruction plus an L2 penalty using
    plain SGD. The closed-form NumPy gradient avoids a PyTorch dependency.
    """

    if not local_adapters:
        raise ValueError("lorafair_refine_aggregate requires at least one adapter")
    rank = _common_rank_list([adapter.rank for adapter in local_adapters], len(local_adapters), "LoRA-FAIR")[0]
    a_bar = np.mean(np.stack([adapter.A for adapter in local_adapters], axis=0), axis=0)
    b_bar = np.mean(np.stack([adapter.B for adapter in local_adapters], axis=0), axis=0)
    target = np.mean(np.stack([adapter.delta() for adapter in local_adapters], axis=0), axis=0)
    rng = np.random.default_rng(int(seed))
    bound = float(np.sqrt(6.0 / max(b_bar.shape[0] + b_bar.shape[1], 1)))
    residual_b = rng.uniform(-bound, bound, size=b_bar.shape)
    lambda_reg = float(max(lambda_reg, 0.0))
    learning_rate = float(learning_rate)

    initial_loss, initial_cosine, _ = _lorafair_objective_and_gradient(
        target, a_bar, b_bar, residual_b, lambda_reg
    )
    loss = initial_loss
    cosine = initial_cosine
    for _ in range(max(int(num_iterations), 0)):
        loss, cosine, gradient = _lorafair_objective_and_gradient(
            target, a_bar, b_bar, residual_b, lambda_reg
        )
        residual_b -= learning_rate * gradient
        residual_b = np.nan_to_num(residual_b, nan=0.0, posinf=5.0, neginf=-5.0)
        residual_b = np.clip(residual_b, -5.0, 5.0)
    final_loss, final_cosine, _ = _lorafair_objective_and_gradient(
        target, a_bar, b_bar, residual_b, lambda_reg
    )
    adapter = LoRAAdapter(
        input_dim=local_adapters[0].input_dim,
        output_dim=local_adapters[0].output_dim,
        rank=rank,
        A=a_bar,
        B=b_bar + residual_b,
        alpha=float(rank),
        name=name,
    )
    return adapter, {
        "initial_refinement_loss": initial_loss,
        "final_refinement_loss": final_loss,
        "initial_reconstruction_cosine": initial_cosine,
        "final_reconstruction_cosine": final_cosine,
        "residual_b_fro_norm": float(np.linalg.norm(residual_b)),
        "factor_aggregation_bias": float(np.linalg.norm(target - b_bar @ a_bar)),
        "refined_aggregation_bias": float(np.linalg.norm(target - adapter.delta())),
    }


def run_lorafair_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    refinement_iterations: int = 1000,
    refinement_lr: float = 0.01,
    lambda_reg: float = 1.0,
    method: str = "LoRA-FAIR",
    trainer_seed_offset: int = 2600,
    weight_decay: float = 1e-4,
) -> LoRAFAIRResult:
    """Run LoRA-FAIR in the shared fixed-rank visual LoRA protocol."""

    rank = _common_rank_list(ranks, len(clients), method)[0]
    trainer_seed = int(seed + trainer_seed_offset)
    global_adapter = _shared_initial_adapter(base_weight, rank, trainer_seed, "lorafair")
    history: list[dict] = []
    for round_idx in range(int(rounds)):
        local_adapters: list[LoRAAdapter] = []
        for client_idx, client in enumerate(clients):
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                base_weight,
                rank=rank,
                init_adapter=global_adapter,
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=trainer_seed + 1000 * round_idx + client_idx,
                name=f"lorafair_{client.client_id}_r{round_idx + 1}",
            )
            local_adapters.append(adapter)
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": rank,
                }
            )
        global_adapter, server_stats = lorafair_refine_aggregate(
            local_adapters,
            num_iterations=refinement_iterations,
            learning_rate=refinement_lr,
            lambda_reg=lambda_reg,
            seed=trainer_seed + 1000 * round_idx + 997,
            name=f"lorafair_global_r{round_idx + 1}",
        )
        for row in history[-len(clients) :]:
            row.update(server_stats)
            row["refinement_iterations"] = int(refinement_iterations)
            row["refinement_lr"] = float(refinement_lr)
            row["lambda_reg"] = float(lambda_reg)

    metrics = _evaluate_adapters_for_clients(
        method,
        clients,
        base_weight,
        [global_adapter for _ in clients],
        seed,
        dataset,
        heterogeneity_setting,
        rounds,
        rank,
    )
    return LoRAFAIRResult(global_adapter, metrics, history)


def telora_paa_align(
    source: Array,
    target: Array,
    eta: float = 1.0,
    sinkhorn_iterations: int = 100,
) -> tuple[Array, Array]:
    """Align source component columns to target columns with Te-LoRA PAA."""

    source = np.asarray(source, dtype=np.float64)
    target = np.asarray(target, dtype=np.float64)
    if source.ndim != 2 or target.ndim != 2 or source.shape[0] != target.shape[0]:
        raise ValueError("PAA source and target must share a feature dimension")
    source_rank, target_rank = source.shape[1], target.shape[1]
    if source_rank <= 0 or target_rank <= 0:
        raise ValueError("PAA ranks must be positive")
    differences = source[:, :, None] - target[:, None, :]
    cost = np.sum(differences, axis=0)
    eta = max(float(eta), 1e-12)
    log_kernel = -cost / eta
    log_kernel -= float(np.max(log_kernel))
    kernel = np.exp(np.clip(log_kernel, -700.0, 0.0))
    kernel = np.clip(kernel, 1e-300, None)
    p = np.full(source_rank, 1.0 / float(source_rank), dtype=np.float64)
    q = np.full(target_rank, 1.0 / float(target_rank), dtype=np.float64)
    nu = np.ones(target_rank, dtype=np.float64)
    mu = np.ones(source_rank, dtype=np.float64)
    for _ in range(max(int(sinkhorn_iterations), 1)):
        mu = p / np.clip(kernel @ nu, 1e-300, None)
        nu = q / np.clip(kernel.T @ mu, 1e-300, None)
    transport = mu[:, None] * kernel * nu[None, :]
    return source @ transport, transport


def telora_t2m2(aligned_matrices: list[Array]) -> Array:
    """Return the rank-one client-mode Tucker core used by Te-LoRA T2M2."""

    if not aligned_matrices:
        raise ValueError("telora_t2m2 requires at least one aligned matrix")
    shape = np.asarray(aligned_matrices[0]).shape
    if any(np.asarray(matrix).shape != shape for matrix in aligned_matrices):
        raise ValueError("T2M2 matrices must have a common aligned shape")
    client_unfolding = np.stack(
        [np.asarray(matrix, dtype=np.float64).reshape(-1) for matrix in aligned_matrices], axis=0
    )
    u, singular_values, vt = np.linalg.svd(client_unfolding, full_matrices=False)
    sign = 1.0 if float(np.sum(u[:, 0])) >= 0.0 else -1.0
    return (sign * singular_values[0] * vt[0]).reshape(shape)


def run_telora_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    eta: float = 1.0,
    sinkhorn_iterations: int = 100,
    method: str = "Te-LoRA-Eq6-Audit",
    trainer_seed_offset: int = 2800,
    weight_decay: float = 1e-4,
) -> TeLoRAResult:
    """Audit the literal published Te-LoRA Eq. (6) with alternating freeze and T2M2."""

    rank = _common_rank_list(ranks, len(clients), method)[0]
    trainer_seed = int(seed + trainer_seed_offset)
    global_adapter = _shared_initial_adapter(base_weight, rank, trainer_seed, "telora")
    history: list[dict] = []
    for round_idx in range(int(rounds)):
        train_b = round_idx % 2 == 0
        local_adapters: list[LoRAAdapter] = []
        for client_idx, client in enumerate(clients):
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                base_weight,
                rank=rank,
                init_adapter=global_adapter,
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                train_a=not train_b,
                train_b=train_b,
                seed=trainer_seed + 1000 * round_idx + client_idx,
                name=f"telora_{client.client_id}_r{round_idx + 1}",
            )
            local_adapters.append(adapter)
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": rank,
                    "trained_factor": "B" if train_b else "A",
                }
            )

        if train_b:
            target = local_adapters[0].B
            aligned = [target.copy()]
            transport_entropies = [0.0]
            for adapter in local_adapters[1:]:
                matrix, transport = telora_paa_align(
                    adapter.B, target, eta=eta, sinkhorn_iterations=sinkhorn_iterations
                )
                aligned.append(matrix)
                transport_entropies.append(_transport_entropy(transport))
            aggregated_b = telora_t2m2(aligned)
            global_adapter = LoRAAdapter(
                input_dim=global_adapter.input_dim,
                output_dim=global_adapter.output_dim,
                rank=rank,
                A=global_adapter.A.copy(),
                B=aggregated_b,
                alpha=float(rank),
                name=f"telora_global_r{round_idx + 1}",
            )
        else:
            target = local_adapters[0].A.T
            aligned = [target.copy()]
            transport_entropies = [0.0]
            for adapter in local_adapters[1:]:
                matrix, transport = telora_paa_align(
                    adapter.A.T, target, eta=eta, sinkhorn_iterations=sinkhorn_iterations
                )
                aligned.append(matrix)
                transport_entropies.append(_transport_entropy(transport))
            aggregated_a = telora_t2m2(aligned).T
            global_adapter = LoRAAdapter(
                input_dim=global_adapter.input_dim,
                output_dim=global_adapter.output_dim,
                rank=rank,
                A=aggregated_a,
                B=global_adapter.B.copy(),
                alpha=float(rank),
                name=f"telora_global_r{round_idx + 1}",
            )
        for row, entropy in zip(history[-len(clients) :], transport_entropies):
            row["paa_eta"] = float(eta)
            row["paa_sinkhorn_iterations"] = int(sinkhorn_iterations)
            row["paa_transport_entropy"] = float(entropy)
            row["t2m_variant"] = "T2M2"

    metrics = _evaluate_adapters_for_clients(
        method,
        clients,
        base_weight,
        [global_adapter for _ in clients],
        seed,
        dataset,
        heterogeneity_setting,
        rounds,
        rank,
    )
    return TeLoRAResult(global_adapter, metrics, history)


def _lorafair_objective_and_gradient(
    target: Array,
    a_bar: Array,
    b_bar: Array,
    residual_b: Array,
    lambda_reg: float,
) -> tuple[float, float, Array]:
    reconstructed = (b_bar + residual_b) @ a_bar
    target_norm = np.linalg.norm(target, axis=0)
    reconstructed_norm = np.linalg.norm(reconstructed, axis=0)
    denominator = np.clip(target_norm * reconstructed_norm, 1e-8, None)
    dot = np.sum(target * reconstructed, axis=0)
    cosine = dot / denominator
    mean_cosine = float(np.mean(cosine))
    target_scale = np.clip(target_norm, 1e-8, None)
    reconstructed_scale = np.clip(reconstructed_norm, 1e-8, None)
    grad_cosine = target / (target_scale * reconstructed_scale)[None, :]
    grad_cosine -= cosine[None, :] * reconstructed / np.square(reconstructed_scale)[None, :]
    grad_reconstructed = -grad_cosine / float(max(target.shape[1], 1))
    gradient = grad_reconstructed @ a_bar.T + 2.0 * float(lambda_reg) * residual_b
    loss = 1.0 - mean_cosine + float(lambda_reg) * float(np.sum(residual_b * residual_b))
    return float(loss), mean_cosine, gradient


def _transport_entropy(transport: Array) -> float:
    values = np.asarray(transport, dtype=np.float64)
    return float(-np.sum(values * np.log(np.clip(values, 1e-300, None))))


def run_fedsmooth_lora_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "FedSmoothLoRA",
    zeta: float = 1.0,
    min_zeta: float = 0.0,
    gamma: float = 64.0,
    gradient_sample_size: int = 128,
    trainer_seed_offset: int = 2100,
    weight_decay: float = 1e-4,
) -> FedSmoothLoRAResult:
    """Official-equation adaptation of FedSmoothLoRA to a visual linear head."""

    rank = _common_rank_list(ranks, len(clients), method)[0]
    trainer_seed = int(seed + trainer_seed_offset)
    sample_weights = _client_sample_weights(clients)
    cumulative_base_delta = np.zeros_like(base_weight, dtype=np.float64)
    client_cumulative_deltas = [np.zeros_like(base_weight, dtype=np.float64) for _ in clients]
    cumulative_projection_residual = np.zeros_like(base_weight, dtype=np.float64)
    global_adapter = LoRAAdapter.zeros(base_weight.shape[1], base_weight.shape[0], rank, alpha=float(rank))
    local_previous = [global_adapter.copy() for _ in clients]
    history: list[dict] = []

    for round_idx in range(int(rounds)):
        current_base = np.asarray(base_weight, dtype=np.float64) + cumulative_base_delta
        if rounds <= 1:
            current_zeta = float(zeta)
        else:
            current_zeta = float(
                min_zeta
                + 0.5 * (zeta - min_zeta) * (1.0 + np.cos(np.pi * round_idx / float(rounds)))
            )
        uploads: list[LoRAAdapter] = []
        for client_idx, client in enumerate(clients):
            rm_delta = current_zeta * (local_previous[client_idx].delta() - global_adapter.delta())
            gradient = _full_weight_gradient(
                client.x_train,
                client.y_train,
                current_base + rm_delta,
                sample_size=gradient_sample_size,
                seed=trainer_seed + 1000 * round_idx + client_idx,
            )
            ga_delta = LoRAAdapter.from_delta(
                -gradient / max(float(gamma), 1e-12),
                rank=rank,
                alpha=float(rank),
                name=f"fedsmooth_ga_{client_idx}",
            ).delta()
            init = LoRAAdapter.from_delta(
                ga_delta + rm_delta,
                rank=rank,
                alpha=float(rank),
                name=f"fedsmooth_init_{client_idx}_r{round_idx + 1}",
            )
            trained, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                current_base - ga_delta,
                rank=rank,
                init_adapter=init,
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=trainer_seed + 1000 * round_idx + client_idx,
                name=f"fedsmooth_local_{client.client_id}_r{round_idx + 1}",
            )
            upload = LoRAAdapter.from_delta(
                trained.delta() - ga_delta,
                rank=rank,
                alpha=float(rank),
                name=f"fedsmooth_upload_{client_idx}_r{round_idx + 1}",
            )
            uploads.append(upload)
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": rank,
                    "zeta": current_zeta,
                    "gradient_norm": float(np.linalg.norm(gradient)),
                    "round_matching_norm": float(np.linalg.norm(rm_delta)),
                    "gradient_aligned_norm": float(np.linalg.norm(ga_delta)),
                }
            )
        averaged = sum(float(weight) * adapter.delta() for weight, adapter in zip(sample_weights, uploads))
        global_adapter = LoRAAdapter.from_delta(
            averaged,
            rank=rank,
            alpha=float(rank),
            name=f"fedsmooth_global_r{round_idx + 1}",
        )
        for client_idx, upload in enumerate(uploads):
            client_cumulative_deltas[client_idx] += upload.delta()
        cumulative_projection_residual += global_adapter.delta() - averaged
        cumulative_base_delta += global_adapter.delta()
        local_previous = [adapter.copy() for adapter in uploads]
        for row in history[-len(clients) :]:
            row["server_projection_error"] = float(np.linalg.norm(averaged - global_adapter.delta()))
            row["cumulative_base_delta_norm"] = float(np.linalg.norm(cumulative_base_delta))
            reconstructed = cumulative_projection_residual + sum(
                float(weight) * stream for weight, stream in zip(sample_weights, client_cumulative_deltas)
            )
            row["cumulative_stream_reconstruction_error"] = float(
                np.linalg.norm(cumulative_base_delta - reconstructed)
            )

    effective_rank = int(min(cumulative_base_delta.shape))
    effective_adapter = LoRAAdapter.from_delta(
        cumulative_base_delta,
        rank=effective_rank,
        alpha=float(effective_rank),
        name="fedsmooth_effective_update",
    )
    metrics = _evaluate_weight_for_clients(
        method,
        clients,
        np.asarray(base_weight, dtype=np.float64) + cumulative_base_delta,
        seed,
        dataset,
        heterogeneity_setting,
        rounds,
        rank,
        {"effective_rank": int(np.linalg.matrix_rank(cumulative_base_delta))},
    )
    rank_matched_adapter = LoRAAdapter.from_delta(
        cumulative_base_delta,
        rank=rank,
        alpha=float(rank),
        name="fedsmooth_rank_matched_update",
    )
    rank_matched_metrics = _evaluate_adapters_for_clients(
        f"{method}-RankMatched",
        clients,
        np.asarray(base_weight, dtype=np.float64),
        [rank_matched_adapter for _ in clients],
        seed,
        dataset,
        heterogeneity_setting,
        rounds,
        rank,
    )
    projection_error = float(np.linalg.norm(cumulative_base_delta - rank_matched_adapter.delta()))
    for row in rank_matched_metrics:
        row["official_effective_rank"] = int(np.linalg.matrix_rank(cumulative_base_delta))
        row["deployment_rank"] = int(rank)
        row["final_rank_projection_error"] = projection_error
    return FedSmoothLoRAResult(
        effective_adapter,
        rank_matched_adapter,
        cumulative_base_delta,
        client_cumulative_deltas,
        cumulative_projection_residual,
        metrics,
        rank_matched_metrics,
        history,
    )


def subspace_regularizer_and_grad(
    adapter: LoRAAdapter,
    global_adapter: LoRAAdapter,
    *,
    mu: float,
    basis_alpha: float,
    lambda_reg: float,
) -> SubspaceRegularizer:
    """Official Subspace-Constrained FL-LoRA client regularizer.

    The visual port preserves the three defining terms from the pinned
    official implementation: effective-update proximity, B-basis proximity,
    and factor regularization. ``adapter.delta()`` includes the LoRA scale.
    """

    if adapter.input_dim != global_adapter.input_dim or adapter.output_dim != global_adapter.output_dim:
        raise ValueError("adapter and global_adapter dimensions must match")
    reference = (
        global_adapter.projected(adapter.rank, name="subspace_reg_reference")
        if global_adapter.rank != adapter.rank
        else global_adapter
    )
    mu = float(max(0.0, mu))
    basis_alpha = float(max(0.0, basis_alpha))
    lambda_reg = float(max(0.0, lambda_reg))
    delta_residual = adapter.delta() - reference.delta()
    basis_residual = adapter.B - reference.B
    value = (
        0.5 * mu * float(np.sum(delta_residual * delta_residual))
        + 0.5 * basis_alpha * float(np.sum(basis_residual * basis_residual))
        + 0.5
        * lambda_reg
        * float(np.sum(adapter.A * adapter.A) + np.sum(adapter.B * adapter.B))
    )
    grad_b = (
        mu * adapter.scale * (delta_residual @ adapter.A.T)
        + basis_alpha * basis_residual
        + lambda_reg * adapter.B
    )
    grad_a = (
        mu * adapter.scale * (adapter.B.T @ delta_residual)
        + lambda_reg * adapter.A
    )
    return SubspaceRegularizer(value=value, grad_a=grad_a, grad_b=grad_b)


def train_subspace_regularized_adapter(
    x: Array,
    y: Array,
    base_weight: Array,
    *,
    rank: int,
    init_adapter: LoRAAdapter,
    global_adapter: LoRAAdapter,
    mu: float,
    basis_alpha: float,
    lambda_reg: float,
    epochs: int,
    lr: float,
    batch_size: int,
    weight_decay: float,
    seed: int,
    grad_clip_norm: float = 5.0,
    factor_clip_norm: float = 25.0,
    factor_clip_value: float = 5.0,
    name: str = "Subspace-Reg-LoRA-Visual-Port",
) -> tuple[LoRAAdapter, dict]:
    """Run the shared visual SGD protocol plus the official regularizer."""

    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.int64)
    base_weight = np.asarray(base_weight, dtype=np.float64)
    if x.ndim != 2 or y.ndim != 1 or len(y) != len(x):
        raise ValueError("x/y shapes are invalid")
    adapter = (
        init_adapter.projected(rank, name=name)
        if init_adapter.rank != int(rank)
        else init_adapter.copy(name=name)
    )
    _stabilize_adapter(adapter, max_norm=factor_clip_norm, max_abs=factor_clip_value)
    rng = np.random.default_rng(seed)
    batch_size = int(max(1, min(int(batch_size), len(y))))
    initial_metrics = evaluate_adapter(x, y, base_weight, adapter)
    for _ in range(int(epochs)):
        order = rng.permutation(len(y))
        for start in range(0, len(y), batch_size):
            indices = order[start : start + batch_size]
            xb = x[indices]
            yb = y[indices]
            logits = xb @ adapter.weight(base_weight).T
            _, grad_logits = cross_entropy_and_grad(logits, yb)
            grad_w = grad_logits.T @ xb
            grad_b = adapter.scale * (grad_w @ adapter.A.T) + float(weight_decay) * adapter.B
            grad_a = adapter.scale * (adapter.B.T @ grad_w) + float(weight_decay) * adapter.A
            regularizer = subspace_regularizer_and_grad(
                adapter,
                global_adapter,
                mu=mu,
                basis_alpha=basis_alpha,
                lambda_reg=lambda_reg,
            )
            grad_a += regularizer.grad_a
            grad_b += regularizer.grad_b
            grad_a = np.nan_to_num(grad_a, nan=0.0, posinf=0.0, neginf=0.0)
            grad_b = np.nan_to_num(grad_b, nan=0.0, posinf=0.0, neginf=0.0)
            grad_a, grad_b = _clip_pair_by_norm(grad_a, grad_b, grad_clip_norm)
            adapter.B -= float(lr) * grad_b
            adapter.A -= float(lr) * grad_a
            _stabilize_adapter(adapter, max_norm=factor_clip_norm, max_abs=factor_clip_value)
    metrics = evaluate_adapter(x, y, base_weight, adapter)
    final_regularizer = subspace_regularizer_and_grad(
        adapter,
        global_adapter,
        mu=mu,
        basis_alpha=basis_alpha,
        lambda_reg=lambda_reg,
    )
    if not np.isfinite([metrics["loss"], metrics["accuracy"], final_regularizer.value]).all():
        raise RuntimeError("subspace-regularized training produced non-finite metrics")
    return adapter, {
        "initial_loss": initial_metrics["loss"],
        "initial_accuracy": initial_metrics["accuracy"],
        "loss": metrics["loss"],
        "accuracy": metrics["accuracy"],
        "regularizer": final_regularizer.value,
    }


def orthogonal_b_full_update_aggregate(
    adapters: list[LoRAAdapter],
    *,
    weights: Array | None = None,
    target_rank: int,
    name: str = "Subspace-Reg-LoRA-Visual-Port",
) -> LoRAAdapter:
    """Average full updates and apply the official orthogonal-B refactorization."""

    if not adapters:
        raise ValueError("at least one adapter is required")
    weights = _normalized_weights(weights, len(adapters))
    shape = adapters[0].delta().shape
    if any(adapter.delta().shape != shape for adapter in adapters):
        raise ValueError("all effective updates must have the same shape")
    mean_delta = sum(float(weight) * adapter.delta() for weight, adapter in zip(weights, adapters))
    output_dim, input_dim = mean_delta.shape
    rank = int(max(1, min(int(target_rank), output_dim, input_dim)))
    u, singular_values, vt = np.linalg.svd(mean_delta, full_matrices=False)
    b = u[:, :rank]
    a = singular_values[:rank, None] * vt[:rank, :]
    return LoRAAdapter(
        input_dim=input_dim,
        output_dim=output_dim,
        rank=rank,
        A=a,
        B=b,
        alpha=float(rank),
        name=name,
    )


def run_subspace_reg_lora_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "Subspace-Reg-LoRA-Visual-Port",
    mu: float = 0.05,
    basis_alpha: float = 0.01,
    lambda_reg: float = 1e-5,
    trainer_seed_offset: int = 2600,
    weight_decay: float = 1e-4,
) -> SubspaceRegLoRAResult:
    """Fair visual protocol port of Subspace-Constrained FL-LoRA.

    Only the task interface changes from the official NLP implementation. The
    client objective and the full-update/orthogonal-B server step are retained.
    """

    rank = _common_rank_list(ranks, len(clients), method)[0]
    trainer_seed = int(seed + trainer_seed_offset)
    sample_weights = _client_sample_weights(clients)
    global_adapter = _shared_initial_adapter(base_weight, rank, trainer_seed, "subspace_reg_lora")
    history: list[dict] = []
    for round_idx in range(int(rounds)):
        local_adapters: list[LoRAAdapter] = []
        reference = global_adapter.copy(name=f"subspace_reg_reference_r{round_idx + 1}")
        for client_idx, client in enumerate(clients):
            trained, stats = train_subspace_regularized_adapter(
                client.x_train,
                client.y_train,
                base_weight,
                rank=rank,
                init_adapter=reference,
                global_adapter=reference,
                mu=mu,
                basis_alpha=basis_alpha,
                lambda_reg=lambda_reg,
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=trainer_seed + 1000 * round_idx + client_idx,
                name=f"subspace_reg_local_{client.client_id}_r{round_idx + 1}",
            )
            local_adapters.append(trained)
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats["loss"],
                    "train_accuracy": stats["accuracy"],
                    "initial_loss": stats["initial_loss"],
                    "regularizer": stats["regularizer"],
                    "rank": rank,
                    "mu": float(mu),
                    "basis_alpha": float(basis_alpha),
                    "lambda_reg": float(lambda_reg),
                    "local_to_global_update_norm": float(
                        np.linalg.norm(trained.delta() - reference.delta())
                    ),
                }
            )
        mean_delta = sum(
            float(weight) * adapter.delta()
            for weight, adapter in zip(sample_weights, local_adapters)
        )
        global_adapter = orthogonal_b_full_update_aggregate(
            local_adapters,
            weights=sample_weights,
            target_rank=rank,
            name=f"subspace_reg_global_r{round_idx + 1}",
        )
        projection_error = float(np.linalg.norm(mean_delta - global_adapter.delta()))
        orthogonality_error = float(
            np.linalg.norm(global_adapter.B.T @ global_adapter.B - np.eye(global_adapter.rank))
        )
        for row in history[-len(clients) :]:
            row["server_projection_error"] = projection_error
            row["server_b_orthogonality_error"] = orthogonality_error

    metrics = _evaluate_adapters_for_clients(
        method,
        clients,
        base_weight,
        [global_adapter for _ in clients],
        seed,
        dataset,
        heterogeneity_setting,
        rounds,
        rank,
    )
    return SubspaceRegLoRAResult(global_adapter, metrics, history)


def dysco_insensitive_basis(features: Array, rank: int) -> Array:
    """Closed-form activation-insensitive basis from Dysco Eq. (2).

    Rows are the eigenvectors associated with the smallest eigenvalues of
    ``H.T @ H`` and are therefore orthonormal.  This is an equation-faithful
    implementation from the archived arXiv source; the linked code repository
    was unavailable at the audit date.
    """

    features = np.asarray(features, dtype=np.float64)
    if features.ndim != 2:
        raise ValueError("features must be a two-dimensional activation matrix")
    rank = int(rank)
    if not 0 < rank <= features.shape[1]:
        raise ValueError("rank must lie in [1, feature_dim]")
    gram = features.T @ features
    _, eigenvectors = np.linalg.eigh(0.5 * (gram + gram.T))
    return np.asarray(eigenvectors[:, :rank].T, dtype=np.float64)


def dysco_merge_insensitive_bases(
    bases: list[Array], receiver_index: int, rank: int
) -> Array:
    """Closed-form leave-one-receiver-out projector merge from Dysco Eq. (4)."""

    if not bases:
        raise ValueError("at least one local insensitive basis is required")
    receiver_index = int(receiver_index)
    if not 0 <= receiver_index < len(bases):
        raise IndexError("receiver_index is out of range")
    rank = int(rank)
    feature_dim = int(np.asarray(bases[0]).shape[1])
    projector_sum = np.zeros((feature_dim, feature_dim), dtype=np.float64)
    donors = [index for index in range(len(bases)) if index != receiver_index]
    if not donors:
        donors = [receiver_index]
    for index in donors:
        basis = np.asarray(bases[index], dtype=np.float64)
        if basis.shape != (rank, feature_dim):
            raise ValueError("all insensitive bases must share shape (rank, feature_dim)")
        projector_sum += basis.T @ basis
    _, eigenvectors = np.linalg.eigh(0.5 * (projector_sum + projector_sum.T))
    return np.asarray(eigenvectors[:, -rank:][:, ::-1].T, dtype=np.float64)


def run_dysco_visual_port(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "Dysco-FrozenFeature-Visual-Port",
    trainer_seed_offset: int = 2900,
    weight_decay: float = 1e-4,
) -> DyscoLoRAResult:
    """Equation-faithful frozen-feature visual port of Dysco.

    The LoRA-input features serve as the latent activation matrices.  Each
    round computes local null-space bases, merges all non-receiver projectors,
    trains a fresh LoRA block, averages the left factors, and accumulates the
    receiver-specific blocks.  The logical deployment rank grows by ``r`` per
    round exactly as in the source algorithm and is reported explicitly.
    """

    rank = _common_rank_list(ranks, len(clients), method)[0]
    if rank > int(base_weight.shape[1]):
        raise ValueError("Dysco rank cannot exceed the LoRA input dimension")
    trainer_seed = int(seed + trainer_seed_offset)
    sample_weights = _client_sample_weights(clients)
    cumulative = [np.zeros_like(base_weight, dtype=np.float64) for _ in clients]
    history: list[dict] = []

    for round_idx in range(int(rounds)):
        local_bases = [dysco_insensitive_basis(client.x_train, rank) for client in clients]
        merged_bases = [
            dysco_merge_insensitive_bases(local_bases, client_idx, rank)
            for client_idx in range(len(clients))
        ]
        trained: list[LoRAAdapter] = []
        for client_idx, client in enumerate(clients):
            init = LoRAAdapter(
                input_dim=int(base_weight.shape[1]),
                output_dim=int(base_weight.shape[0]),
                rank=rank,
                A=merged_bases[client_idx].copy(),
                B=np.zeros((base_weight.shape[0], rank), dtype=np.float64),
                alpha=float(rank),
                name=f"dysco_init_{client.client_id}_r{round_idx + 1}",
            )
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                np.asarray(base_weight, dtype=np.float64) + cumulative[client_idx],
                rank=rank,
                init_adapter=init,
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=trainer_seed + 1000 * round_idx + client_idx,
                name=f"dysco_local_{client.client_id}_r{round_idx + 1}",
            )
            trained.append(adapter)
            null_energy = float(np.linalg.norm(local_bases[client_idx] @ client.x_train.T) ** 2)
            merged_overlap = float(
                sum(
                    np.linalg.norm(merged_bases[client_idx] @ local_bases[j].T) ** 2
                    for j in range(len(clients))
                    if j != client_idx
                )
            )
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "upload_rank": rank,
                    "logical_deployment_rank": (round_idx + 1) * rank,
                    "local_null_energy": null_energy,
                    "merged_insensitive_overlap": merged_overlap,
                    "merged_basis_orthogonality_error": float(
                        np.linalg.norm(
                            merged_bases[client_idx] @ merged_bases[client_idx].T
                            - np.eye(rank)
                        )
                    ),
                    "right_factor_finetune_norm": float(
                        np.linalg.norm(adapter.A - merged_bases[client_idx])
                    ),
                    "source_code_status": "paper-equation-port;linked-repository-unavailable",
                }
            )

        shared_b = sum(float(weight) * adapter.B for weight, adapter in zip(sample_weights, trained))
        for client_idx, adapter in enumerate(trained):
            cumulative[client_idx] += shared_b @ adapter.A
            history[-len(clients) + client_idx]["shared_b_fro_norm"] = float(np.linalg.norm(shared_b))
            history[-len(clients) + client_idx]["cumulative_update_fro_norm"] = float(
                np.linalg.norm(cumulative[client_idx])
            )

    effective_rank = int(min(base_weight.shape))
    adapters = [
        LoRAAdapter.from_delta(
            delta,
            rank=effective_rank,
            alpha=float(effective_rank),
            name=f"dysco_effective_client_{client_idx}",
        )
        for client_idx, delta in enumerate(cumulative)
    ]
    metrics = _evaluate_adapters_for_clients(
        method,
        clients,
        base_weight,
        adapters,
        seed,
        dataset,
        heterogeneity_setting,
        rounds,
        rank,
    )
    for row, adapter in zip(metrics, adapters):
        row["upload_rank"] = rank
        row["logical_deployment_rank"] = int(rounds) * rank
        row["effective_matrix_rank"] = int(np.linalg.matrix_rank(adapter.delta()))
        row["source_code_status"] = "paper-equation-port;linked-repository-unavailable"
    return DyscoLoRAResult(adapters, metrics, history)


def fedalt_rest_of_world_aggregate(
    local_adapters: list[LoRAAdapter],
    round_id: int = 0,
) -> list[LoRAAdapter]:
    """Apply FedALT's released leave-one-client-out factor aggregation.

    The official server averages every other client's trainable ``A1/B1``
    factors and writes them into receiver-specific ``A0/B0`` factors.  The
    aggregation is intentionally unweighted because that is the released
    recurrence.
    """

    if len(local_adapters) < 2:
        raise ValueError("FedALT requires at least two clients for Rest-of-World aggregation")
    reference = local_adapters[0]
    for adapter in local_adapters[1:]:
        if (
            adapter.rank != reference.rank
            or adapter.input_dim != reference.input_dim
            or adapter.output_dim != reference.output_dim
        ):
            raise ValueError("FedALT Rest-of-World aggregation requires common factor shapes")

    rest_of_world: list[LoRAAdapter] = []
    for receiver in range(len(local_adapters)):
        donors = [adapter for index, adapter in enumerate(local_adapters) if index != receiver]
        rest_of_world.append(
            LoRAAdapter(
                input_dim=reference.input_dim,
                output_dim=reference.output_dim,
                rank=reference.rank,
                A=np.mean([adapter.A for adapter in donors], axis=0),
                B=np.mean([adapter.B for adapter in donors], axis=0),
                alpha=float(reference.alpha),
                name=f"fedalt_rest_of_world_client_{receiver}_r{round_id}",
            )
        )
    return rest_of_world


def _fedalt_routed_logits(
    x: Array,
    base_weight: Array,
    rest_of_world: LoRAAdapter,
    local_adapter: LoRAAdapter,
    route_matrix: Array,
) -> tuple[Array, Array, Array]:
    """Visual two-expert counterpart of the released token-level router."""

    x = np.asarray(x, dtype=np.float64)
    route_matrix = np.asarray(route_matrix, dtype=np.float64)
    if route_matrix.shape != (2, x.shape[1]):
        raise ValueError(f"FedALT route matrix {route_matrix.shape} != {(2, x.shape[1])}")
    route_weights = softmax(x @ route_matrix.T)
    expert_outputs = np.stack(
        [x @ rest_of_world.delta().T, x @ local_adapter.delta().T],
        axis=1,
    )
    mixture = np.einsum("nk,nkc->nc", route_weights, expert_outputs)
    logits = x @ np.asarray(base_weight, dtype=np.float64).T + mixture
    return logits, route_weights, expert_outputs


def _evaluate_fedalt_route(
    x: Array,
    y: Array,
    base_weight: Array,
    rest_of_world: LoRAAdapter,
    local_adapter: LoRAAdapter,
    route_matrix: Array,
) -> dict[str, float]:
    logits, route_weights, _ = _fedalt_routed_logits(
        x, base_weight, rest_of_world, local_adapter, route_matrix
    )
    loss, _ = cross_entropy_and_grad(logits.copy(), np.asarray(y, dtype=np.int64))
    return {
        "loss": float(loss),
        "accuracy": float(np.mean(logits.argmax(axis=1) == np.asarray(y, dtype=np.int64))),
        "mean_rest_of_world_weight": float(route_weights[:, 0].mean()),
        "mean_local_weight": float(route_weights[:, 1].mean()),
    }


def _train_fedalt_client(
    x: Array,
    y: Array,
    base_weight: Array,
    rest_of_world: LoRAAdapter,
    local_adapter: LoRAAdapter,
    route_matrix: Array,
    epochs: int,
    lr: float,
    batch_size: int,
    weight_decay: float,
    seed: int,
) -> tuple[LoRAAdapter, Array, dict]:
    """Train only FedALT's local branch and router; keep RoW frozen."""

    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.int64)
    local = local_adapter.copy(name="fedalt_local_trainable")
    router = np.asarray(route_matrix, dtype=np.float64).copy()
    rng = np.random.default_rng(seed)
    batch_size = max(1, min(int(batch_size), len(y)))

    for _ in range(int(epochs)):
        order = rng.permutation(len(y))
        for start in range(0, len(y), batch_size):
            indices = order[start : start + batch_size]
            xb = x[indices]
            yb = y[indices]
            logits, route_weights, expert_outputs = _fedalt_routed_logits(
                xb, base_weight, rest_of_world, local, router
            )
            _, grad_logits = cross_entropy_and_grad(logits, yb)

            grad_delta = (grad_logits * route_weights[:, 1, None]).T @ xb
            grad_b = local.scale * (grad_delta @ local.A.T) + float(weight_decay) * local.B
            grad_a = local.scale * (local.B.T @ grad_delta) + float(weight_decay) * local.A

            mixture = np.einsum("nk,nkc->nc", route_weights, expert_outputs)
            grad_route_logits = np.empty_like(route_weights)
            for expert_id in range(2):
                centered = expert_outputs[:, expert_id, :] - mixture
                grad_route_logits[:, expert_id] = route_weights[:, expert_id] * np.sum(
                    grad_logits * centered, axis=1
                )
            grad_router = grad_route_logits.T @ xb + float(weight_decay) * router

            grad_a, grad_b = _clip_pair_by_norm(grad_a, grad_b, max_norm=5.0)
            router_norm = float(np.linalg.norm(grad_router))
            if router_norm > 5.0:
                grad_router *= 5.0 / max(router_norm, 1e-12)
            local.A -= float(lr) * grad_a
            local.B -= float(lr) * grad_b
            router -= float(lr) * grad_router
            _stabilize_adapter(local, max_norm=100.0, max_abs=5.0)
            router = np.clip(np.nan_to_num(router), -5.0, 5.0)

    return local, router, _evaluate_fedalt_route(
        x, y, base_weight, rest_of_world, local, router
    )


def run_fedalt_visual_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "FedALT-OfficialVisualPort",
    trainer_seed_offset: int = 2500,
    weight_decay: float = 1e-4,
) -> FedALTVisualResult:
    """Run a faithful visual-task port of FedALT's released recurrence.

    The language model and token axis are replaced by the common visual
    feature/head protocol.  The two asymmetric knowledge roles, input-level
    softmax router, trainable-local/frozen-RoW rule, and official unweighted
    leave-one-out factor aggregation are preserved exactly.
    """

    rank = _common_rank_list(ranks, len(clients), method)[0]
    trainer_seed = int(seed + trainer_seed_offset)
    shared = _shared_initial_adapter(base_weight, rank, trainer_seed, "fedalt_visual")
    local_adapters = [shared.copy(name=f"fedalt_local_{client.client_id}") for client in clients]
    rest_of_world = [shared.copy(name=f"fedalt_row_{client.client_id}") for client in clients]
    route_matrices: list[Array] = []
    for client_idx in range(len(clients)):
        rng = np.random.default_rng(trainer_seed + 50000 + client_idx)
        bound = math.sqrt(6.0 / max(1, int(base_weight.shape[1]) + 2))
        route_matrices.append(rng.uniform(-bound, bound, size=(2, int(base_weight.shape[1]))))

    history: list[dict] = []
    for round_idx in range(int(rounds)):
        trained_local: list[LoRAAdapter] = []
        trained_routes: list[Array] = []
        train_stats: list[dict] = []
        for client_idx, client in enumerate(clients):
            local, router, stats = _train_fedalt_client(
                client.x_train,
                client.y_train,
                base_weight,
                rest_of_world[client_idx],
                local_adapters[client_idx],
                route_matrices[client_idx],
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=trainer_seed + 1000 * round_idx + client_idx,
            )
            local.name = f"fedalt_local_{client.client_id}_r{round_idx + 1}"
            trained_local.append(local)
            trained_routes.append(router)
            train_stats.append(stats)

        local_adapters = trained_local
        route_matrices = trained_routes
        rest_of_world = fedalt_rest_of_world_aggregate(local_adapters, round_id=round_idx + 1)
        for client_idx, (client, stats) in enumerate(zip(clients, train_stats)):
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "trainer_seed": trainer_seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats["loss"],
                    "train_accuracy": stats["accuracy"],
                    "rank": rank,
                    "mean_rest_of_world_weight": stats["mean_rest_of_world_weight"],
                    "mean_local_weight": stats["mean_local_weight"],
                    "aggregation": "official-unweighted-leave-one-out-factor-mean",
                }
            )

    metrics: list[dict] = []
    effective_adapters: list[LoRAAdapter] = []
    for client_idx, client in enumerate(clients):
        routed = _evaluate_fedalt_route(
            client.x_test,
            client.y_test,
            base_weight,
            rest_of_world[client_idx],
            local_adapters[client_idx],
            route_matrices[client_idx],
        )
        train_route = softmax(np.asarray(client.x_train) @ route_matrices[client_idx].T).mean(axis=0)
        effective_delta = (
            float(train_route[0]) * rest_of_world[client_idx].delta()
            + float(train_route[1]) * local_adapters[client_idx].delta()
        )
        deployment_rank = min(2 * rank, min(base_weight.shape))
        effective_adapters.append(
            LoRAAdapter.from_delta(
                effective_delta,
                rank=deployment_rank,
                alpha=float(deployment_rank),
                name=f"fedalt_mean_route_effective_{client.client_id}",
            )
        )
        factor_parameters = rank * (int(base_weight.shape[0]) + int(base_weight.shape[1]))
        route_parameters = 2 * int(base_weight.shape[1])
        metrics.append(
            {
                "method": method,
                "seed": seed,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": rounds,
                "client_id": client.client_id,
                "domain": client.domain,
                "accuracy": routed["accuracy"],
                "loss": routed["loss"],
                "rank": rank,
                "upload_rank": rank,
                "deployment_rank_upper_bound": deployment_rank,
                "mean_rest_of_world_weight": routed["mean_rest_of_world_weight"],
                "mean_local_weight": routed["mean_local_weight"],
                "uploaded_parameters": factor_parameters + route_parameters,
                "broadcast_parameters": factor_parameters,
                "router_parameters": route_parameters,
                "implementation_fidelity": "official-source-visual-task-port",
                "official_source_commit": "8be3dde2569cef47ecab2d7d931667606a921a47",
                "test_used_for_routing_or_training": False,
            }
        )
    return FedALTVisualResult(
        local_adapters=local_adapters,
        rest_of_world_adapters=rest_of_world,
        route_matrices=route_matrices,
        effective_adapters=effective_adapters,
        per_client_metrics=metrics,
        round_history=history,
    )


def _shared_initial_adapter(base_weight: Array, rank: int, seed: int, name: str) -> LoRAAdapter:
    return LoRAAdapter.random(
        input_dim=base_weight.shape[1],
        output_dim=base_weight.shape[0],
        rank=rank,
        rng=np.random.default_rng(seed + 7919 * rank),
        alpha=float(rank),
        name=f"{name}_shared_init",
        zero_b=True,
    )


def _common_rank_list(ranks: list[int] | int, num_clients: int, method: str) -> list[int]:
    if isinstance(ranks, int):
        rank_list = [int(ranks)] * num_clients
    else:
        rank_list = [int(rank) for rank in ranks]
    if len(rank_list) != num_clients:
        raise ValueError(f"Expected {num_clients} ranks, got {len(rank_list)}")
    if len(set(rank_list)) != 1:
        raise ValueError(f"{method} fidelity runs require a common LoRA rank")
    return rank_list


def _client_sample_weights(clients: list) -> Array:
    return _normalized_weights(np.asarray([len(client.y_train) for client in clients], dtype=np.float64), len(clients))


def _normalized_weights(weights: Array | None, n: int) -> Array:
    if weights is None:
        return np.ones(n, dtype=np.float64) / float(n)
    out = np.asarray(weights, dtype=np.float64)
    if out.shape != (n,):
        raise ValueError(f"Expected {n} aggregation weights, got {out.shape}")
    return out / np.clip(out.sum(), 1e-12, None)


def _evaluate_weight_for_clients(
    method: str,
    clients: list,
    weight: Array,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    rank: int,
    extra: dict | None = None,
) -> list[dict]:
    rows = []
    for client in clients:
        metrics = evaluate_weight(client.x_test, client.y_test, weight)
        rows.append(
            {
                "method": method,
                "seed": seed,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": round_id,
                "client_id": client.client_id,
                "domain": client.domain,
                "accuracy": metrics["accuracy"],
                "loss": metrics["loss"],
                "rank": rank,
                **(extra or {}),
            }
        )
    return rows


def _evaluate_adapters_for_clients(
    method: str,
    clients: list,
    base_weight: Array,
    adapters: list[LoRAAdapter],
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    rank: int,
    assignments: Array | None = None,
) -> list[dict]:
    rows = []
    for idx, (client, adapter) in enumerate(zip(clients, adapters)):
        metrics = evaluate_adapter(client.x_test, client.y_test, base_weight, adapter)
        row = {
            "method": method,
            "seed": seed,
            "dataset": dataset,
            "heterogeneity_setting": heterogeneity_setting,
            "round": round_id,
            "client_id": client.client_id,
            "domain": client.domain,
            "accuracy": metrics["accuracy"],
            "loss": metrics["loss"],
            "rank": rank,
        }
        if assignments is not None:
            row["expert_or_cluster_id"] = int(assignments[idx])
        rows.append(row)
    return rows


def _b_cosine_distance(adapters: list[LoRAAdapter]) -> Array:
    factors = np.asarray([adapter.B.reshape(-1) for adapter in adapters], dtype=np.float64)
    norms = np.linalg.norm(factors, axis=1, keepdims=True)
    normalized = factors / np.clip(norms, 1e-12, None)
    similarity = np.clip(normalized @ normalized.T, -1.0, 1.0)
    distance = 1.0 - similarity
    np.fill_diagonal(distance, 0.0)
    return distance


def _b_frobenius_distance(adapters: list[LoRAAdapter], normalize: bool = True) -> Array:
    factors = np.asarray([adapter.B.reshape(-1) for adapter in adapters], dtype=np.float64)
    distance = np.linalg.norm(factors[:, None, :] - factors[None, :, :], axis=2)
    np.fill_diagonal(distance, 0.0)
    if normalize:
        positive = distance[distance > 0.0]
        if positive.size:
            lower = float(positive.min())
            upper = float(positive.max())
            if upper > lower + 1e-12:
                distance = np.where(distance > 0.0, (distance - lower) / (upper - lower), 0.0)
            else:
                distance = np.where(distance > 0.0, 1.0, 0.0)
    return distance


def _fedtree_single_layer_partition(
    distance: Array,
    max_clusters: int,
    search_range_k: int,
    single_cluster_score: float,
) -> tuple[Array, int, float]:
    """Official FedTreeLoRA progressive search specialized to one layer."""

    distance = np.asarray(distance, dtype=np.float64)
    n = int(distance.shape[0])
    if n <= 2:
        return np.zeros(n, dtype=np.int64), 1, float(single_cluster_score)
    upper = min(max(int(max_clusters), 1), max(int(search_range_k), 1), n - 1)
    best_labels = np.zeros(n, dtype=np.int64)
    best_k = 1
    best_score = float(single_cluster_score)
    for k in range(2, upper + 1):
        labels = _average_linkage_partition(distance, k)
        score = _silhouette_score(distance, labels)
        if score > best_score + 1e-12:
            best_labels = labels
            best_k = k
            best_score = score
    return best_labels, best_k, float(best_score)


def _silhouette_agglomerative_partition(distance: Array, max_clusters: int) -> tuple[Array, int, float]:
    distance = np.asarray(distance, dtype=np.float64)
    n = int(distance.shape[0])
    if distance.shape != (n, n):
        raise ValueError("distance must be square")
    if n <= 2:
        return np.arange(n, dtype=np.int64), n, 0.0
    upper = min(max(int(max_clusters), 2), n - 1)
    best_labels = np.zeros(n, dtype=np.int64)
    best_k = 1
    best_score = -float("inf")
    for k in range(2, upper + 1):
        labels = _average_linkage_partition(distance, k)
        score = _silhouette_score(distance, labels)
        if score > best_score + 1e-12:
            best_labels = labels
            best_k = k
            best_score = score
    if not np.isfinite(best_score) or best_score <= 0.0:
        return np.zeros(n, dtype=np.int64), 1, float(max(best_score, 0.0))
    return best_labels, best_k, float(best_score)


def _average_linkage_partition(distance: Array, k: int) -> Array:
    clusters = [[idx] for idx in range(distance.shape[0])]
    while len(clusters) > int(k):
        best = None
        best_distance = float("inf")
        for left in range(len(clusters)):
            for right in range(left + 1, len(clusters)):
                value = float(np.mean(distance[np.ix_(clusters[left], clusters[right])]))
                tie_key = (value, min(clusters[left]), min(clusters[right]))
                if best is None or tie_key < best_distance_key:
                    best = (left, right)
                    best_distance = value
                    best_distance_key = tie_key
        left, right = best
        clusters[left] = sorted(clusters[left] + clusters[right])
        del clusters[right]
    labels = np.zeros(distance.shape[0], dtype=np.int64)
    for cluster_id, members in enumerate(sorted(clusters, key=lambda values: min(values))):
        labels[members] = cluster_id
    return labels


def _silhouette_score(distance: Array, labels: Array) -> float:
    labels = np.asarray(labels, dtype=np.int64)
    values = []
    for idx in range(labels.size):
        own = np.flatnonzero(labels == labels[idx])
        own = own[own != idx]
        a = float(distance[idx, own].mean()) if own.size else 0.0
        b_values = [
            float(distance[idx, np.flatnonzero(labels == other)].mean())
            for other in np.unique(labels)
            if other != labels[idx]
        ]
        b = min(b_values) if b_values else 0.0
        denominator = max(a, b)
        values.append(0.0 if denominator <= 1e-12 else (b - a) / denominator)
    return float(np.mean(values))


def _tier_rank_split(rank: int) -> tuple[int, int, int]:
    rank = int(rank)
    if rank < 3:
        raise ValueError("HiLoRA-Visual budget matching requires rank >= 3")
    root = max(1, rank // 3)
    cluster = max(1, (rank - root) // 2)
    leaf = rank - root - cluster
    return root, cluster, leaf


def _orthogonal_residual(delta: Array, parent_delta: Array) -> Array:
    delta = np.asarray(delta, dtype=np.float64)
    parent_delta = np.asarray(parent_delta, dtype=np.float64)
    if float(np.linalg.norm(parent_delta)) <= 1e-12:
        return delta.copy()
    u, s, vt = np.linalg.svd(parent_delta, full_matrices=False)
    keep = s > 1e-10
    if not bool(np.any(keep)):
        return delta.copy()
    u = u[:, keep]
    v = vt[keep, :].T
    left_projection = np.eye(delta.shape[0], dtype=np.float64) - u @ u.T
    right_projection = np.eye(delta.shape[1], dtype=np.float64) - v @ v.T
    return left_projection @ delta @ right_projection


def _full_weight_gradient(
    x: Array,
    y: Array,
    weight: Array,
    sample_size: int,
    seed: int,
) -> Array:
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.int64)
    n = int(x.shape[0])
    if n == 0:
        return np.zeros_like(weight, dtype=np.float64)
    take = min(max(int(sample_size), 1), n)
    rng = np.random.default_rng(int(seed))
    indices = np.sort(rng.choice(n, size=take, replace=False))
    logits = x[indices] @ np.asarray(weight, dtype=np.float64).T
    _, grad_logits = cross_entropy_and_grad(logits, y[indices])
    return grad_logits.T @ x[indices]
