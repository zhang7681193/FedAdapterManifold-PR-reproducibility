from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .adapters import LoRAAdapter
from .subspace import principal_angles
from .training import softmax


Array = np.ndarray


@dataclass(frozen=True)
class ReceiverRiskSubspaceMetrics:
    distance: float
    column_distance: float
    row_distance: float
    normal_energy: float
    normal_energy_ratio: float


def _symmetric_psd_sqrt(matrix: Array) -> Array:
    matrix = np.asarray(matrix, dtype=np.float64)
    symmetric = 0.5 * (matrix + matrix.T)
    eigenvalues, eigenvectors = np.linalg.eigh(symmetric)
    clipped = np.maximum(eigenvalues, 0.0)
    return (eigenvectors * np.sqrt(clipped)[None, :]) @ eigenvectors.T


def _trace_ridge(matrix: Array, ratio: float) -> Array:
    matrix = np.asarray(matrix, dtype=np.float64)
    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError("Risk factors must be square matrices")
    if ratio <= 0.0:
        raise ValueError("ridge_ratio must be positive")
    scale = float(np.trace(matrix)) / max(matrix.shape[0], 1)
    scale = max(scale, np.finfo(np.float64).eps)
    return 0.5 * (matrix + matrix.T) + ratio * scale * np.eye(matrix.shape[0])


def receiver_kfac_risk_factors(
    client,
    base_weight: Array,
    local_adapter: LoRAAdapter,
    ridge_ratio: float = 1e-4,
) -> tuple[Array, Array]:
    """Estimate training-only KFAC factors at one receiver's local solution.

    The exact categorical Fisher action used elsewhere in the project is not
    replaced. These separable factors define a receiver-conditioned metric in
    which row and column action *subspaces* can be compared.
    """

    features = np.asarray(client.x_train, dtype=np.float64)
    if features.ndim != 2 or features.shape[1] != local_adapter.input_dim:
        raise ValueError("Client training features do not match the adapter input dimension")
    local_weight = np.asarray(base_weight, dtype=np.float64) + local_adapter.delta()
    probabilities = softmax(features @ local_weight.T)

    input_factor = features.T @ features / max(features.shape[0], 1)
    output_factor = np.zeros((probabilities.shape[1], probabilities.shape[1]), dtype=np.float64)
    for probability in probabilities:
        output_factor += np.diag(probability) - np.outer(probability, probability)
    output_factor /= max(features.shape[0], 1)
    return _trace_ridge(output_factor, ridge_ratio), _trace_ridge(input_factor, ridge_ratio)


def _effective_action_bases(update: Array, declared_rank: int) -> tuple[Array, Array]:
    update = np.asarray(update, dtype=np.float64)
    u, singular_values, vh = np.linalg.svd(update, full_matrices=False)
    if singular_values.size == 0:
        return np.zeros((update.shape[0], 0)), np.zeros((update.shape[1], 0))
    tolerance = max(update.shape) * np.finfo(np.float64).eps * max(float(singular_values[0]), 1.0)
    numerical_rank = int(np.sum(singular_values > tolerance))
    rank = min(max(int(declared_rank), 0), numerical_rank)
    return u[:, :rank], vh[:rank, :].T


def receiver_risk_subspace_metrics(
    receiver_update: Array,
    donor_update: Array,
    output_factor: Array,
    input_factor: Array,
    receiver_rank: int,
    donor_rank: int,
) -> ReceiverRiskSubspaceMetrics:
    """Compare two effective updates in the receiver's KFAC risk metric."""

    receiver_update = np.asarray(receiver_update, dtype=np.float64)
    donor_update = np.asarray(donor_update, dtype=np.float64)
    if receiver_update.shape != donor_update.shape:
        raise ValueError("Receiver and donor updates must have the same shape")
    output_sqrt = _symmetric_psd_sqrt(output_factor)
    input_sqrt = _symmetric_psd_sqrt(input_factor)
    if output_sqrt.shape != (receiver_update.shape[0], receiver_update.shape[0]):
        raise ValueError("Output risk factor has the wrong shape")
    if input_sqrt.shape != (receiver_update.shape[1], receiver_update.shape[1]):
        raise ValueError("Input risk factor has the wrong shape")

    whitened_receiver = output_sqrt @ receiver_update @ input_sqrt
    whitened_donor = output_sqrt @ donor_update @ input_sqrt
    receiver_column, receiver_row = _effective_action_bases(whitened_receiver, receiver_rank)
    donor_column, donor_row = _effective_action_bases(whitened_donor, donor_rank)
    column_angles = principal_angles(receiver_column, donor_column)
    row_angles = principal_angles(receiver_row, donor_row)
    column_distance = float(np.linalg.norm(np.sin(column_angles)))
    row_distance = float(np.linalg.norm(np.sin(row_angles)))

    column_projector = receiver_column @ receiver_column.T
    row_projector = receiver_row @ receiver_row.T
    whitened_residual = whitened_donor - whitened_receiver
    transported = (
        column_projector @ whitened_residual
        + whitened_residual @ row_projector
        - column_projector @ whitened_residual @ row_projector
    )
    normal = whitened_residual - transported
    total_energy = float(np.linalg.norm(whitened_residual, ord="fro") ** 2)
    normal_energy = float(np.linalg.norm(normal, ord="fro") ** 2)
    normal_ratio = normal_energy / max(total_energy, np.finfo(np.float64).tiny)
    return ReceiverRiskSubspaceMetrics(
        distance=column_distance + row_distance,
        column_distance=column_distance,
        row_distance=row_distance,
        normal_energy=normal_energy,
        normal_energy_ratio=normal_ratio,
    )


def directed_receiver_risk_subspace_distance_matrix(
    clients: list,
    base_weight: Array,
    adapters: list[LoRAAdapter],
    ridge_ratio: float = 1e-4,
) -> tuple[Array, Array]:
    """Return directed risk-subspace distance and normal-energy-ratio matrices."""

    if len(clients) != len(adapters):
        raise ValueError("Expected one adapter per client")
    n_clients = len(clients)
    distance = np.zeros((n_clients, n_clients), dtype=np.float64)
    normal_ratio = np.zeros((n_clients, n_clients), dtype=np.float64)
    updates = [np.asarray(adapter.delta(), dtype=np.float64) for adapter in adapters]
    for receiver_index, (client, receiver) in enumerate(zip(clients, adapters)):
        output_factor, input_factor = receiver_kfac_risk_factors(
            client,
            base_weight,
            receiver,
            ridge_ratio=ridge_ratio,
        )
        for donor_index, donor in enumerate(adapters):
            if donor_index == receiver_index:
                continue
            metrics = receiver_risk_subspace_metrics(
                updates[receiver_index],
                updates[donor_index],
                output_factor,
                input_factor,
                receiver_rank=receiver.rank,
                donor_rank=donor.rank,
            )
            distance[receiver_index, donor_index] = metrics.distance
            normal_ratio[receiver_index, donor_index] = metrics.normal_energy_ratio
    return distance, normal_ratio
