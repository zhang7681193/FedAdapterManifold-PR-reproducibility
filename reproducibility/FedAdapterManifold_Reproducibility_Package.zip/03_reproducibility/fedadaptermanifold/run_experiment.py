from __future__ import annotations

from pathlib import Path
import argparse
from datetime import datetime, timezone
import hashlib
import json
import platform
import sys
from dataclasses import replace

import numpy as np

from .adapters import LoRAAdapter
from .baselines import (
    run_adapter_bank_baseline,
    evaluate_client_adapters,
    run_clustered_lora_baseline,
    run_fedgeo_agg_baseline,
    run_fedgeo_diag_baseline,
    run_ditto_lora_baseline,
    run_fedavg_lift_baseline,
    run_fedavg_lora_baseline,
    run_fedamp_lora_baseline,
    run_fedper_lora_baseline,
    run_fedproto_lora_baseline,
    run_fedprox_lora_baseline,
    run_fedrot_lora_baseline,
    run_local_lora,
    run_pfedme_lora_baseline,
    run_scaffold_lora_baseline,
    run_semantic_admission_lora,
    run_subspace_compatible_baseline,
    select_loss_constrained_graph_mix,
    summarize_method,
)
from .baseline_fidelity import BASELINE_FIDELITY
from .aggregation import compatibility_matrix, graph_compatible_aggregate, select_adapter_bank_k
from .claims import build_single_run_claim_report
from .config import DEFAULT_CONFIG, merge_defaults, save_yaml_copy
from .data import load_cifar10_clients, load_image_folder_clients, load_medmnist_npz_clients, make_synthetic_manifold_clients
from .diagnostics import run_subspace_failure_diagnostic
from .geometry import (
    FedGeoFileGeometryProvider,
    LocalPrototypeGeometry,
    cluster_prototypes_from_geometry,
    label_distance_matrix,
    write_geometry_outputs,
)
from .rank import allocate_ranks
from .rank import conflict_scores_from_distance
from .recent_lora_baselines import (
    run_fedalt_visual_baseline,
    run_dysco_visual_port,
    run_fedex_lora_baseline,
    run_fedpissa_visual_baseline,
    run_fedlease_visual_baseline,
    run_fedsa_lora_baseline,
    run_fedsmooth_lora_baseline,
    run_fedtree_lora_visual_baseline,
    run_hilora_visual_baseline,
    run_lorafair_baseline,
    run_subspace_reg_lora_baseline,
    run_telora_baseline,
)
from .safe_admission import select_empirical_bernstein_path
from .decoupled_transport import (
    JointPathAdmissionResult,
    build_anchored_receiver_action_path_candidates,
    build_curvature_semantic_candidates,
    build_receiver_action_candidates,
    fit_blockwise_action_endpoints,
    fit_residual_blockwise_action_endpoints,
    joint_path_comparison_count,
    receiver_action_energy_summary,
    screen_action_family_on_training_data,
    select_competitive_safe_blockwise_paths,
    select_disagreement_localized_routes,
    select_joint_empirical_bernstein_paths,
)
from .intrinsic_cumulative import run_intrinsic_cumulative_lift
from .reporting import (
    ensure_dir,
    save_heatmap,
    save_routing_heatmap,
    save_scatter,
    write_csv,
)
from .training import evaluate_adapter, evaluate_adapter_loss_vector, train_lora_adapter
from .signed_admissibility import (
    build_fisher_signed_tangent_candidate,
    select_crossfitted_semantic_endpoint,
    select_hierarchical_exact_certified_endpoint,
    select_exact_certified_signed_tangent,
    select_training_fixed_semantic_endpoint,
    select_target_pareto_signed_tangent,
)


def build_arg_parser(defaults: dict | None = None) -> argparse.ArgumentParser:
    defaults = defaults or DEFAULT_CONFIG
    parser = argparse.ArgumentParser(description="Run FedAdapterManifold minimal diagnostics.")
    parser.add_argument("--config", type=str, default="")
    parser.add_argument(
        "--dataset",
        choices=["synthetic", "cifar10-debug", "cifar10", "pacs-debug", "image-folder", "medmnist-npz"],
        default=defaults["dataset"],
    )
    parser.add_argument("--data-root", type=str, default=defaults["data_root"])
    parser.add_argument("--domains", type=str, default=defaults.get("domains", ""))
    parser.add_argument("--test-fraction", type=float, default=defaults.get("test_fraction", 0.25))
    parser.add_argument("--output-dir", type=str, default=defaults["output_dir"])
    parser.add_argument(
        "--feature-backbone",
        choices=[
            "numpy",
            "resnet18",
            "resnet18-pretrained",
            "clip-rn50",
            "clip-vit-b32",
            "clip-vit-b16",
            "clip-vit-l14",
            "dinov2-vits14",
            "dinov2-vitb14",
            "dinov2-vitl14",
            "dinov2-small",
            "dinov2-base",
            "dinov2-large",
        ],
        default=defaults["feature_backbone"],
    )
    parser.add_argument("--feature-cache-dir", type=str, default=defaults.get("feature_cache_dir", ""))
    parser.add_argument(
        "--base-head-init",
        choices=["zero", "clip-text"],
        default=defaults.get("base_head_init", "zero"),
    )
    parser.add_argument("--base-head-scale", type=float, default=defaults.get("base_head_scale", 1.0))
    parser.add_argument(
        "--class-prompt-template",
        type=str,
        default=defaults.get("class_prompt_template", "a photo of a {label}."),
    )
    parser.add_argument("--heterogeneity-setting", type=str, default=defaults["heterogeneity_setting"])
    parser.add_argument("--num-clients", type=int, default=defaults["num_clients"])
    parser.add_argument("--num-classes", type=int, default=defaults["num_classes"])
    parser.add_argument("--feature-dim", type=int, default=defaults["feature_dim"])
    parser.add_argument("--dirichlet-alpha", type=float, default=defaults.get("dirichlet_alpha", 0.3))
    parser.add_argument("--min-train-size", type=int, default=defaults.get("min_train_size", 32))
    parser.add_argument("--align-test-with-train", action="store_true", default=defaults.get("align_test_with_train", True))
    parser.add_argument("--no-align-test-with-train", action="store_false", dest="align_test_with_train")
    parser.add_argument("--train-per-client", type=int, default=defaults["train_per_client"])
    parser.add_argument("--test-per-client", type=int, default=defaults["test_per_client"])
    parser.add_argument("--rounds", type=int, default=defaults["rounds"])
    parser.add_argument("--local-epochs", type=int, default=defaults["local_epochs"])
    parser.add_argument("--lr", type=float, default=defaults["lr"])
    parser.add_argument("--batch-size", type=int, default=defaults["batch_size"])
    parser.add_argument("--fedprox-mu", type=float, default=defaults.get("fedprox_mu", 0.01))
    parser.add_argument("--ditto-mu", type=float, default=defaults.get("ditto_mu", 0.01))
    parser.add_argument("--pfedme-mu", type=float, default=defaults.get("pfedme_mu", defaults.get("ditto_mu", 0.01)))
    parser.add_argument("--scaffold-control-lr", type=float, default=defaults.get("scaffold_control_lr", 1.0))
    parser.add_argument(
        "--run-recent-lora-baselines",
        action="store_true",
        default=defaults.get("run_recent_lora_baselines", False),
    )
    parser.add_argument(
        "--recent-lora-max-experts",
        type=int,
        default=defaults.get("recent_lora_max_experts", 4),
    )
    parser.add_argument(
        "--recent-lora-methods",
        default=defaults.get("recent_lora_methods", "all"),
        help=(
            "Comma-separated subset of fedex,fedsa,fedpissa,fedlease,fedtree,hilora,fedsmooth,"
            "lorafair,telora,subspace_reg, or all."
        ),
    )
    parser.add_argument(
        "--fedpissa-lambda",
        type=float,
        default=defaults.get("fedpissa_lambda", 0.05),
    )
    parser.add_argument(
        "--fedpissa-tail-start",
        type=int,
        default=defaults.get("fedpissa_tail_start", 0),
        help="One-indexed start of the covariance tail; 0 uses the second half.",
    )
    parser.add_argument(
        "--subspace-reg-mu",
        type=float,
        default=defaults.get("subspace_reg_mu", 0.05),
    )
    parser.add_argument(
        "--subspace-reg-basis-alpha",
        type=float,
        default=defaults.get("subspace_reg_basis_alpha", 0.01),
    )
    parser.add_argument(
        "--subspace-reg-lambda",
        type=float,
        default=defaults.get("subspace_reg_lambda", 1e-5),
    )
    parser.add_argument(
        "--fedtree-warmup-rounds",
        type=int,
        default=defaults.get("fedtree_warmup_rounds", 5),
    )
    parser.add_argument(
        "--fedtree-search-range-k",
        type=int,
        default=defaults.get("fedtree_search_range_k", 3),
    )
    parser.add_argument(
        "--fedtree-single-cluster-score",
        type=float,
        default=defaults.get("fedtree_single_cluster_score", 0.02),
    )
    parser.add_argument(
        "--fedtree-routing-candidates",
        default=defaults.get("fedtree_routing_candidates", "0,0.25,0.5,0.75,1.0"),
    )
    parser.add_argument("--fedsmooth-zeta", type=float, default=defaults.get("fedsmooth_zeta", 1.0))
    parser.add_argument(
        "--fedsmooth-min-zeta",
        type=float,
        default=defaults.get("fedsmooth_min_zeta", 0.0),
    )
    parser.add_argument("--fedsmooth-gamma", type=float, default=defaults.get("fedsmooth_gamma", 64.0))
    parser.add_argument(
        "--fedsmooth-gradient-sample-size",
        type=int,
        default=defaults.get("fedsmooth_gradient_sample_size", 128),
    )
    parser.add_argument(
        "--report-fedsmooth-rank-matched",
        action="store_true",
        default=defaults.get("report_fedsmooth_rank_matched", False),
    )
    parser.add_argument(
        "--lorafair-refinement-iterations",
        type=int,
        default=defaults.get("lorafair_refinement_iterations", 1000),
    )
    parser.add_argument(
        "--lorafair-refinement-lr",
        type=float,
        default=defaults.get("lorafair_refinement_lr", 0.01),
    )
    parser.add_argument(
        "--lorafair-lambda-reg",
        type=float,
        default=defaults.get("lorafair_lambda_reg", 1.0),
    )
    parser.add_argument("--telora-eta", type=float, default=defaults.get("telora_eta", 1.0))
    parser.add_argument(
        "--telora-sinkhorn-iterations",
        type=int,
        default=defaults.get("telora_sinkhorn_iterations", 100),
    )
    parser.add_argument(
        "--run-cumulative-action-admission",
        action="store_true",
        default=defaults.get("run_cumulative_action_admission", False),
    )
    parser.add_argument(
        "--run-intrinsic-cumulative-source",
        action="store_true",
        default=defaults.get("run_intrinsic_cumulative_source", False),
        help="Build the internal cumulative lifted-update stream without running the legacy path selector.",
    )
    parser.add_argument(
        "--cumulative-action-source",
        choices=["intrinsic-lift", "fedsmooth"],
        default=defaults.get("cumulative_action_source", "intrinsic-lift"),
    )
    parser.add_argument(
        "--cumulative-server-step-candidates",
        default=defaults.get("cumulative_server_step_candidates", "0,0.05,0.1,0.25,0.5,1.0"),
    )
    parser.add_argument(
        "--cumulative-subspace-warm-start",
        action="store_true",
        default=defaults.get("cumulative_subspace_warm_start", True),
    )
    parser.add_argument(
        "--no-cumulative-subspace-warm-start",
        action="store_false",
        dest="cumulative_subspace_warm_start",
    )
    parser.add_argument(
        "--cumulative-semantic-lambda-subspace",
        type=float,
        default=defaults.get("cumulative_semantic_lambda_subspace", 1.0),
    )
    parser.add_argument(
        "--cumulative-semantic-lambda-risk",
        type=float,
        default=defaults.get("cumulative_semantic_lambda_risk", 1.0),
    )
    parser.add_argument(
        "--cumulative-semantic-top-k",
        type=int,
        default=defaults.get("cumulative_semantic_top_k", 2),
    )
    parser.add_argument(
        "--cumulative-semantic-correction-scale",
        type=float,
        default=defaults.get("cumulative_semantic_correction_scale", 0.25),
    )
    parser.add_argument(
        "--cumulative-semantic-target-rank",
        type=int,
        default=defaults.get("cumulative_semantic_target_rank", 0),
        help="0 keeps the exact cumulative deployment rank; positive values impose a matched rank budget.",
    )
    parser.add_argument(
        "--fedrot-rotation-strength",
        type=float,
        default=defaults.get("fedrot_rotation_strength", 0.4),
    )
    parser.add_argument(
        "--run-multiround-semantic-admission",
        action="store_true",
        default=defaults.get("run_multiround_semantic_admission", False),
    )
    parser.add_argument(
        "--semantic-admission-lambda-risk",
        type=float,
        default=defaults.get("semantic_admission_lambda_risk", 1.0),
    )
    parser.add_argument(
        "--semantic-admission-graph-mass-temperature",
        type=float,
        default=defaults.get("semantic_admission_graph_mass_temperature", 10.0),
    )
    parser.add_argument(
        "--semantic-admission-minimum-tempered-neighbor-mass",
        type=float,
        default=defaults.get("semantic_admission_minimum_tempered_neighbor_mass", 0.1),
    )
    parser.add_argument(
        "--semantic-admission-graph-scale-policy",
        choices=["raw", "topology-calibrated"],
        default=defaults.get("semantic_admission_graph_scale_policy", "raw"),
        help="Use raw edge mass or a scale-invariant topological support prior for semantic admission.",
    )
    parser.add_argument(
        "--semantic-admission-topology-top-k",
        type=int,
        default=defaults.get("semantic_admission_topology_top_k", 2),
    )
    parser.add_argument(
        "--semantic-admission-topology-neighbor-mass",
        type=float,
        default=defaults.get("semantic_admission_topology_neighbor_mass", 1.0),
    )
    parser.add_argument(
        "--semantic-admission-exact-certificate",
        action="store_true",
        default=defaults.get("semantic_admission_exact_certificate", False),
        help="Post-certify the training-fixed semantic endpoint against immutable Local and admitted Geo.",
    )
    parser.add_argument(
        "--semantic-admission-familywise-alpha",
        type=float,
        default=defaults.get("semantic_admission_familywise_alpha", 0.05),
    )
    parser.add_argument(
        "--semantic-admission-generator-screening",
        action="store_true",
        default=defaults.get("semantic_admission_generator_screening", False),
        help="Select one endpoint from the external stress-test generator family using adapter-training data only.",
    )
    parser.add_argument(
        "--semantic-admission-internal-generator-screening",
        action="store_true",
        default=defaults.get("semantic_admission_internal_generator_screening", False),
        help="Select one endpoint from the internal semantic/action generator bank using adapter-training data only.",
    )
    parser.add_argument(
        "--semantic-admission-anchored-action-screening",
        action="store_true",
        default=defaults.get("semantic_admission_anchored_action_screening", False),
        help="Select one Local-anchored receiver-action residual endpoint using adapter-training data only.",
    )
    parser.add_argument(
        "--semantic-admission-crossfit-anchored-action-screening",
        action="store_true",
        default=defaults.get("semantic_admission_crossfit_anchored_action_screening", False),
        help="Select the internal semantic or anchored-action generator on a nested training-side validation split.",
    )
    parser.add_argument(
        "--semantic-admission-crossfit-fraction",
        type=float,
        default=defaults.get("semantic_admission_crossfit_fraction", 0.2),
        help="Fraction of adapter-training samples reserved for nested generator selection.",
    )
    parser.add_argument(
        "--semantic-admission-exact-mode",
        choices=["bonferroni", "hierarchical-holm-deduplicated"],
        default=defaults.get("semantic_admission_exact_mode", "bonferroni"),
    )
    parser.add_argument(
        "--run-decoupled-transport",
        action="store_true",
        default=defaults.get("run_decoupled_transport", False),
    )
    parser.add_argument(
        "--decoupled-transport-modes",
        type=str,
        default=defaults.get("decoupled_transport_modes", "core,tangent,full"),
    )
    parser.add_argument(
        "--decoupled-transport-candidates",
        type=str,
        default=defaults.get("decoupled_transport_candidates", "0,0.25,0.50,0.75,1.0"),
    )
    parser.add_argument(
        "--decoupled-transport-delta",
        type=float,
        default=defaults.get("decoupled_transport_delta", 0.05),
    )
    parser.add_argument(
        "--decoupled-transport-risk-tolerance",
        type=float,
        default=defaults.get("decoupled_transport_risk_tolerance", 0.0),
    )
    parser.add_argument(
        "--decoupled-transport-confidence-bound",
        choices=["paired-discordance", "empirical-bernstein"],
        default=defaults.get("decoupled_transport_confidence_bound", "paired-discordance"),
    )
    parser.add_argument(
        "--skip-heavy-personalized-baselines",
        action="store_true",
        default=defaults.get("skip_heavy_personalized_baselines", False),
    )
    parser.add_argument(
        "--fedper-personal-weight-candidates",
        type=str,
        default=defaults.get("fedper_personal_weight_candidates", "0,0.25,0.50,0.75,1.00"),
    )
    parser.add_argument(
        "--fedper-personal-weight-tolerance",
        type=float,
        default=defaults.get("fedper_personal_weight_tolerance", 0.005),
    )
    parser.add_argument(
        "--fedper-fam-personal-weight-candidates",
        type=str,
        default=defaults.get("fedper_fam_personal_weight_candidates", "0,0.25,0.50,0.75,1.00"),
    )
    parser.add_argument(
        "--fedper-fam-loss-tolerance",
        type=float,
        default=defaults.get("fedper_fam_loss_tolerance", 0.005),
    )
    parser.add_argument(
        "--fedper-fam-policy",
        choices=["loss-min", "loss-constrained", "personal-fallback"],
        default=defaults.get("fedper_fam_policy", "loss-min"),
    )
    parser.add_argument(
        "--ditto-fam-personal-weight-candidates",
        type=str,
        default=defaults.get("ditto_fam_personal_weight_candidates", "0,0.25,0.50,0.75,1.00"),
    )
    parser.add_argument(
        "--ditto-fam-loss-tolerance",
        type=float,
        default=defaults.get("ditto_fam_loss_tolerance", 0.005),
    )
    parser.add_argument(
        "--ditto-fam-policy",
        choices=["loss-min", "loss-constrained", "personal-fallback"],
        default=defaults.get("ditto_fam_policy", "personal-fallback"),
    )
    parser.add_argument("--rank", type=int, default=defaults["rank"])
    parser.add_argument(
        "--rank-policy",
        choices=["fixed", "random", "novelty-aware", "conflict-aware", "risk-aware"],
        default=defaults["rank_policy"],
    )
    parser.add_argument("--min-rank", type=int, default=defaults["min_rank"])
    parser.add_argument("--max-rank", type=int, default=defaults["max_rank"])
    parser.add_argument("--adapter-bank-k", type=int, default=defaults["adapter_bank_k"])
    parser.add_argument(
        "--adapter-graph-mode",
        choices=["fedgeo", "complete", "self", "random"],
        default=defaults.get("adapter_graph_mode", "fedgeo"),
    )
    parser.add_argument("--adapter-graph-self-weight", type=float, default=defaults.get("adapter_graph_self_weight", 1.0))
    parser.add_argument("--adapter-graph-mix-weight", type=float, default=defaults.get("adapter_graph_mix_weight", 1.0))
    parser.add_argument(
        "--adapter-graph-mix-policy",
        choices=["fixed", "loss-min", "loss-constrained"],
        default=defaults.get("adapter_graph_mix_policy", "fixed"),
    )
    parser.add_argument("--adapter-graph-mix-tolerance", type=float, default=defaults.get("adapter_graph_mix_tolerance", 0.005))
    parser.add_argument("--adapter-graph-mix-candidates", type=str, default=defaults.get("adapter_graph_mix_candidates", ""))
    parser.add_argument(
        "--adapter-graph-distance",
        choices=["combined", "none"],
        default=defaults.get("adapter_graph_distance", "combined"),
    )
    parser.add_argument(
        "--adapter-graph-compatibility",
        choices=["method", "none"],
        default=defaults.get("adapter_graph_compatibility", "method"),
    )
    parser.add_argument(
        "--adapter-bank-routing",
        choices=["client", "feature", "feature-prior", "feature-prior-dynamic"],
        default=defaults["adapter_bank_routing"],
    )
    parser.add_argument("--adapter-bank-prior-weight", type=float, default=defaults["adapter_bank_prior_weight"])
    parser.add_argument("--lambda-geo", type=float, default=defaults["lambda_geo"])
    parser.add_argument("--lambda-label", type=float, default=defaults["lambda_label"])
    parser.add_argument(
        "--manifold-distance-components",
        choices=["all", "d_sub", "d_geo", "d_label", "d_sub_d_geo", "d_sub_d_label", "d_geo_d_label"],
        default=defaults.get("manifold_distance_components", "all"),
    )
    parser.add_argument("--tau", type=float, default=defaults["tau"])
    parser.add_argument("--route-tau", type=float, default=defaults["route_tau"])
    parser.add_argument("--shared-weight", type=float, default=defaults["shared_weight"])
    parser.add_argument(
        "--shared-weight-policy",
        choices=["fixed", "loss-min", "loss-constrained"],
        default=defaults.get("shared_weight_policy", "fixed"),
    )
    parser.add_argument("--shared-weight-tolerance", type=float, default=defaults.get("shared_weight_tolerance", 0.005))
    parser.add_argument("--shared-weight-candidates", type=str, default=defaults.get("shared_weight_candidates", ""))
    parser.add_argument("--personal-weight", type=float, default=defaults["personal_weight"])
    parser.add_argument(
        "--personal-weight-policy",
        choices=["fixed", "loss-min", "loss-constrained", "heterogeneity-aware", "uncertainty-constrained"],
        default=defaults.get("personal_weight_policy", "fixed"),
    )
    parser.add_argument("--personal-weight-tolerance", type=float, default=defaults.get("personal_weight_tolerance", 0.005))
    parser.add_argument("--personal-weight-candidates", type=str, default=defaults.get("personal_weight_candidates", ""))
    parser.add_argument("--manifold-smoothing-weight", type=float, default=defaults.get("manifold_smoothing_weight", 0.0))
    parser.add_argument(
        "--manifold-smoothing-policy",
        choices=[
            "fixed",
            "loss-constrained",
            "cluster-loss-constrained",
            "safe-loss-constrained",
            "safe-cluster-loss-constrained",
        ],
        default=defaults.get("manifold_smoothing_policy", "fixed"),
    )
    parser.add_argument("--manifold-smoothing-tolerance", type=float, default=defaults.get("manifold_smoothing_tolerance", 0.005))
    parser.add_argument("--manifold-smoothing-candidates", type=str, default=defaults.get("manifold_smoothing_candidates", ""))
    parser.add_argument(
        "--candidate-selector-policy",
        choices=[
            "loss-min",
            "diagnostic-gated",
            "anchored-no-regret",
            "anchored-diff-lcb",
            "loss-softmax",
            "gibbs",
            "gibbs-lcb",
            "safe-gibbs",
            "safe-gibbs-lcb",
        ],
        default=defaults.get("candidate_selector_policy", "loss-min"),
    )
    parser.add_argument(
        "--strong-candidate-selector-policy",
        choices=[
            "loss-min",
            "diagnostic-gated",
            "anchored-no-regret",
            "anchored-diff-lcb",
            "loss-softmax",
            "gibbs",
            "gibbs-lcb",
            "safe-gibbs",
            "safe-gibbs-lcb",
        ],
        default=defaults.get("strong_candidate_selector_policy", "loss-min"),
    )
    parser.add_argument(
        "--candidate-selector-scope",
        choices=["all", "adapter-only"],
        default=defaults.get("candidate_selector_scope", "all"),
    )
    parser.add_argument(
        "--candidate-selector-loss-tolerance",
        type=float,
        default=defaults.get("candidate_selector_loss_tolerance", 0.005),
    )
    parser.add_argument(
        "--candidate-selector-loss-tolerance-ratio",
        type=float,
        default=defaults.get("candidate_selector_loss_tolerance_ratio", 0.20),
    )
    parser.add_argument(
        "--candidate-selector-neighbor-weight",
        type=float,
        default=defaults.get("candidate_selector_neighbor_weight", 0.0),
    )
    parser.add_argument(
        "--candidate-selector-calibration-fraction",
        type=float,
        default=defaults.get("candidate_selector_calibration_fraction", 0.0),
    )
    parser.add_argument(
        "--candidate-selector-calibration-strategy",
        choices=["random", "stratified"],
        default=defaults.get("candidate_selector_calibration_strategy", "random"),
    )
    parser.add_argument(
        "--candidate-selector-anchor-priority",
        type=str,
        default=defaults.get("candidate_selector_anchor_priority", ""),
        help="Comma-separated pre-registered anchor priority for anchored-no-regret selection.",
    )
    parser.add_argument(
        "--strong-candidate-selector-anchor-priority",
        type=str,
        default=defaults.get("strong_candidate_selector_anchor_priority", ""),
        help="Comma-separated pre-registered anchor priority for expanded anchored selection.",
    )
    parser.add_argument(
        "--candidate-selector-softmax-tau",
        type=float,
        default=defaults.get("candidate_selector_softmax_tau", 0.05),
    )
    parser.add_argument(
        "--candidate-selector-lcb-delta",
        type=float,
        default=defaults.get("candidate_selector_lcb_delta", 0.05),
    )
    parser.add_argument(
        "--run-path-admission",
        action="store_true",
        default=defaults.get("run_path_admission", False),
    )
    parser.add_argument(
        "--path-admission-candidates",
        type=str,
        default=defaults.get("path_admission_candidates", "0,0.25,0.50,0.75,1.0"),
    )
    parser.add_argument(
        "--path-admission-delta",
        type=float,
        default=defaults.get("path_admission_delta", 0.05),
    )
    parser.add_argument(
        "--path-admission-risk-tolerance",
        type=float,
        default=defaults.get("path_admission_risk_tolerance", 0.0),
    )
    parser.add_argument("--anchor-residual-epochs", type=int, default=defaults.get("anchor_residual_epochs", 0))
    parser.add_argument(
        "--anchor-residual-lr-scale",
        type=float,
        default=defaults.get("anchor_residual_lr_scale", 0.5),
    )
    parser.add_argument("--anchor-residual-rank", type=int, default=defaults.get("anchor_residual_rank", 0))
    parser.add_argument(
        "--anchor-residual-validation-fraction",
        type=float,
        default=defaults.get("anchor_residual_validation_fraction", 0.0),
    )
    parser.add_argument(
        "--anchor-residual-validation-strategy",
        choices=["random", "stratified"],
        default=defaults.get("anchor_residual_validation_strategy", "random"),
    )
    parser.add_argument(
        "--anchor-residual-shrinkage-candidates",
        type=str,
        default=defaults.get("anchor_residual_shrinkage_candidates", "1.0"),
    )
    parser.add_argument(
        "--anchor-residual-selector-shrinkage-candidates",
        type=str,
        default=defaults.get("anchor_residual_selector_shrinkage_candidates", ""),
    )
    parser.add_argument(
        "--run-anchor-residual-admission",
        action="store_true",
        default=defaults.get("run_anchor_residual_admission", False),
    )
    parser.add_argument(
        "--anchor-residual-admission-sources",
        type=str,
        default=defaults.get("anchor_residual_admission_sources", "geo,subspace,bank"),
    )
    parser.add_argument(
        "--run-signed-tangent-admission",
        action="store_true",
        default=defaults.get("run_signed_tangent_admission", False),
    )
    parser.add_argument(
        "--signed-tangent-sources",
        type=str,
        default=defaults.get("signed_tangent_sources", "subspace,bank"),
    )
    parser.add_argument(
        "--signed-tangent-alpha-max",
        type=float,
        default=defaults.get("signed_tangent_alpha_max", 1.0),
    )
    parser.add_argument(
        "--signed-tangent-derivative-margin",
        type=float,
        default=defaults.get("signed_tangent_derivative_margin", 0.0),
    )
    parser.add_argument(
        "--signed-tangent-loss-margin",
        type=float,
        default=defaults.get("signed_tangent_loss_margin", 0.0),
    )
    parser.add_argument(
        "--signed-tangent-exact-certificate",
        action="store_true",
        default=defaults.get("signed_tangent_exact_certificate", False),
        help="Use immutable-Local hierarchical exact paired admission.",
    )
    parser.add_argument(
        "--signed-tangent-familywise-alpha",
        type=float,
        default=defaults.get("signed_tangent_familywise_alpha", 0.05),
        help="Family-wise alpha for the three predeclared certificate edges.",
    )
    parser.add_argument(
        "--calibration-shift-mode",
        choices=["marginal", "confidence-stratified"],
        default=defaults.get("calibration_shift_mode", "marginal"),
    )
    parser.add_argument(
        "--calibration-shift-bins",
        type=int,
        default=defaults.get("calibration_shift_bins", 2),
    )
    parser.add_argument(
        "--calibration-shift-min-stratum-size",
        type=int,
        default=defaults.get("calibration_shift_min_stratum_size", 16),
    )
    parser.add_argument(
        "--route-candidate-search-mode",
        choices=("calibration-grid", "training-fixed"),
        default=defaults.get("route_candidate_search_mode", "calibration-grid"),
    )
    parser.add_argument("--geometry-outputs-dir", type=str, default=defaults.get("geometry_outputs_dir", ""))
    parser.add_argument("--round-id", type=int, default=defaults.get("round_id", defaults.get("geometry_round", 0)))
    parser.add_argument("--fedgeo-dir", type=str, default=defaults["fedgeo_dir"])
    parser.add_argument("--geometry-round", type=int, default=defaults["geometry_round"])
    parser.add_argument(
        "--geometry-ablation-mode",
        choices=["provider", "no-geometry", "shuffled-geometry", "self-only"],
        default=defaults.get("geometry_ablation_mode", "provider"),
    )
    parser.add_argument("--diagnostic-threshold", type=float, default=defaults["diagnostic_threshold"])
    parser.add_argument("--continue-on-failed-diagnostic", action="store_true", default=defaults["continue_on_failed_diagnostic"])
    parser.add_argument("--seed", type=int, default=defaults["seed"])
    parser.add_argument("--device", choices=["cpu", "cuda"], default=defaults["device"])
    parser.add_argument("--cpu-debug", action="store_true", default=defaults["cpu_debug"])
    parser.add_argument("--no-cpu-debug", action="store_false", dest="cpu_debug")
    return parser


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _sha256_source_tree(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*.py")):
        relative = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        digest.update(bytes.fromhex(_sha256_file(path)))
    return digest.hexdigest()


def _geometry_input_hash(root: str) -> tuple[str, list[str]]:
    if not root:
        return "", []
    directory = Path(root)
    if not directory.is_dir():
        return "missing", []
    files = sorted(path for path in directory.iterdir() if path.is_file())
    digest = hashlib.sha256()
    names: list[str] = []
    for path in files:
        name = path.name
        names.append(name)
        encoded = name.encode("utf-8")
        digest.update(len(encoded).to_bytes(4, "big"))
        digest.update(encoded)
        digest.update(bytes.fromhex(_sha256_file(path)))
    return digest.hexdigest(), names


def _write_run_provenance(
    path: Path,
    *,
    raw_argv: list[str],
    source_config: str,
    effective_config: dict,
    geometry_outputs_dir: str,
) -> None:
    package_root = Path(__file__).resolve().parent
    source_path = Path(source_config).resolve() if source_config else None
    geometry_hash, geometry_files = _geometry_input_hash(geometry_outputs_dir)
    effective_bytes = json.dumps(
        effective_config,
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    ).encode("utf-8")
    record = {
        "schema_version": 1,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "command": ["python", "-m", "fedadaptermanifold.run_experiment", *raw_argv],
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "numpy_version": np.__version__,
        "package_source_sha256": _sha256_source_tree(package_root),
        "source_config_path": str(source_path) if source_path else "",
        "source_config_sha256": (
            _sha256_file(source_path) if source_path is not None and source_path.is_file() else ""
        ),
        "effective_config_sha256": hashlib.sha256(effective_bytes).hexdigest(),
        "geometry_outputs_dir": str(Path(geometry_outputs_dir).resolve()) if geometry_outputs_dir else "",
        "geometry_inputs_sha256": geometry_hash,
        "geometry_input_files": geometry_files,
    }
    path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    pre_parser = argparse.ArgumentParser(add_help=False)
    pre_parser.add_argument("--config", type=str, default="")
    pre_args, _ = pre_parser.parse_known_args(raw_argv)
    defaults = merge_defaults(pre_args.config or None)
    args = build_arg_parser(defaults).parse_args(raw_argv)
    output_dir = ensure_dir(args.output_dir)
    figures_dir = ensure_dir(output_dir / "figures")
    geometry_outputs_dir = args.geometry_outputs_dir or args.fedgeo_dir
    geometry_round_id = int(args.round_id)
    round_id_was_cli = "--round-id" in raw_argv or any(arg.startswith("--round-id=") for arg in raw_argv)
    if (
        not round_id_was_cli
        and args.round_id == DEFAULT_CONFIG.get("round_id", 0)
        and args.geometry_round != DEFAULT_CONFIG.get("geometry_round", 0)
    ):
        geometry_round_id = int(args.geometry_round)
    effective_config = vars(args).copy()
    effective_config.pop("config", None)
    effective_config["geometry_outputs_dir"] = geometry_outputs_dir
    effective_config["round_id"] = geometry_round_id
    effective_config["geometry_round"] = geometry_round_id

    clients, base_weight, class_names = _load_clients(args)
    clients, selector_clients, calibration_rows = _split_clients_for_candidate_selection(
        clients,
        fraction=args.candidate_selector_calibration_fraction,
        strategy=args.candidate_selector_calibration_strategy,
        seed=args.seed,
    )
    num_classes = base_weight.shape[0]
    effective_config.update(_effective_data_config(clients, base_weight, class_names))
    save_yaml_copy(output_dir / "config.yaml", effective_config)
    _write_run_provenance(
        output_dir / "run_provenance.json",
        raw_argv=raw_argv,
        source_config=pre_args.config,
        effective_config=effective_config,
        geometry_outputs_dir=geometry_outputs_dir,
    )

    geometry_provider = FedGeoFileGeometryProvider(geometry_outputs_dir) if geometry_outputs_dir else LocalPrototypeGeometry()
    geometry = geometry_provider.build(clients, num_classes=num_classes, round_id=geometry_round_id)
    geometry = _apply_geometry_ablation(geometry, args.geometry_ablation_mode, args.seed)
    write_geometry_outputs(output_dir / "geometry_outputs", geometry, round_id=geometry_round_id)
    conflict_probe = None
    conflict_probe_r = None
    conflict_probe_passed = None
    effective_rank_policy = args.rank_policy
    rank_allocation_policy = args.rank_policy
    rank_fallback_reason = ""
    if args.rank_policy == "conflict-aware":
        probe_result = run_local_lora(
            clients,
            base_weight,
            ranks=args.min_rank,
            epochs=max(1, args.local_epochs),
            lr=args.lr,
            batch_size=args.batch_size,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=0,
            method="Conflict-Probe-LoRA",
        )
        probe_diagnostic = run_subspace_failure_diagnostic(
            clients,
            base_weight,
            probe_result.adapters,
            d_geo=geometry.d_geo,
            lambda_geo=args.lambda_geo,
            lambda_label=args.lambda_label,
            tau=args.tau,
            diagnostic_threshold=args.diagnostic_threshold,
        )
        conflict_probe = conflict_scores_from_distance(probe_diagnostic.d_adapter_incompatibility)
        conflict_probe_r = probe_diagnostic.incompatibility_pearson_r
        conflict_probe_passed = probe_diagnostic.passed
        if not probe_diagnostic.passed:
            rank_fallback_reason = "conflict_probe_failed"
            effective_rank_policy = "fixed-fallback"
            rank_allocation_policy = "fixed"
    ranks = allocate_ranks(
        rank_allocation_policy,
        len(clients),
        args.rank,
        min_rank=args.min_rank,
        max_rank=args.max_rank,
        novelty=geometry.novelty,
        conflict=conflict_probe,
        risk=geometry.risk_geo_scores,
        feature_energy_deficit=geometry.feature_energy_deficit,
        seed=args.seed,
    )

    total_local_epochs = args.rounds * args.local_epochs
    base_adapters = [
        LoRAAdapter.zeros(
            input_dim=base_weight.shape[1],
            output_dim=base_weight.shape[0],
            rank=int(rank),
            alpha=float(rank),
            name=f"base_head_{client.client_id}",
        )
        for client, rank in zip(clients, ranks)
    ]
    base_head_metrics = evaluate_client_adapters(
        "Base-Head",
        clients,
        base_weight,
        base_adapters,
        ranks=ranks,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    local_result = run_local_lora(
        clients,
        base_weight,
        ranks=ranks,
        epochs=total_local_epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    local_adapters = local_result.adapters
    local_train_rows = local_result.training_summary

    d_label = label_distance_matrix(clients, num_classes)
    diagnostic = run_subspace_failure_diagnostic(
        clients,
        base_weight,
        local_adapters,
        d_geo=geometry.d_geo,
        d_label=d_label,
        lambda_geo=args.lambda_geo,
        lambda_label=args.lambda_label,
        tau=args.tau,
        diagnostic_threshold=args.diagnostic_threshold,
    )
    if args.rank_policy == "conflict-aware" and effective_rank_policy == "conflict-aware" and not diagnostic.passed:
        rank_fallback_reason = "final_diagnostic_failed"
        effective_rank_policy = "fixed-fallback"
        ranks = allocate_ranks(
            "fixed",
            len(clients),
            args.rank,
            min_rank=args.min_rank,
            max_rank=args.max_rank,
            risk=geometry.risk_geo_scores,
            feature_energy_deficit=geometry.feature_energy_deficit,
            seed=args.seed,
        )
        local_result = run_local_lora(
            clients,
            base_weight,
            ranks=ranks,
            epochs=total_local_epochs,
            lr=args.lr,
            batch_size=args.batch_size,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
        )
        local_adapters = local_result.adapters
        local_train_rows = local_result.training_summary
        diagnostic = run_subspace_failure_diagnostic(
            clients,
            base_weight,
            local_adapters,
            d_geo=geometry.d_geo,
            d_label=d_label,
            lambda_geo=args.lambda_geo,
            lambda_label=args.lambda_label,
            tau=args.tau,
            diagnostic_threshold=args.diagnostic_threshold,
        )
    rank_rows = _rank_rows(
        clients,
        ranks,
        args.rank_policy,
        effective_rank_policy,
        geometry,
        conflict_probe,
        conflict_probe_r,
        conflict_probe_passed,
        rank_fallback_reason,
    )
    d_sub = diagnostic.d_sub
    compat = diagnostic.compatibility
    rank_heterogeneous = len(set(int(rank) for rank in ranks)) > 1
    adapter_distance = diagnostic.d_combined if rank_heterogeneous else d_sub
    manifold_distance = _manifold_distance_matrix(
        args.manifold_distance_components,
        adapter_distance,
        geometry.d_geo,
        d_label,
        lambda_geo=args.lambda_geo,
        lambda_label=args.lambda_label,
    )
    method_compat = _compatibility_from_distance(manifold_distance, args.tau)

    decoupled_transport_result = None
    decoupled_transport_weight_rows: list[dict] = []
    cumulative_action_decomposition_rows: list[dict] = []
    cumulative_semantic_weight_rows: list[dict] = []
    cumulative_blockwise_fit_rows: list[dict] = []
    if args.run_decoupled_transport:
        decoupled_modes = tuple(
            item.strip().lower()
            for item in str(args.decoupled_transport_modes).split(",")
            if item.strip()
        )
        # Geometry is only an optional proposal signal.  This fallback keeps
        # donor coverage independent of provider graph connectivity and lets
        # receiver action projection plus calibration decide admissibility.
        decoupled_distance = np.asarray(d_sub, dtype=np.float64).copy()
        decoupled_distance += max(0.0, float(args.lambda_label)) * np.asarray(d_label, dtype=np.float64)
        decoupled_logits = -decoupled_distance / max(float(args.tau), 1e-8)
        decoupled_logits -= np.max(decoupled_logits, axis=1, keepdims=True)
        decoupled_weights = np.exp(decoupled_logits)
        diagonal = np.arange(len(clients))
        decoupled_weights[diagonal, diagonal] *= max(float(args.adapter_graph_self_weight), 1e-12)
        decoupled_weights /= np.clip(decoupled_weights.sum(axis=1, keepdims=True), 1e-12, None)
        for receiver_index, receiver in enumerate(clients):
            for donor_index, donor in enumerate(clients):
                decoupled_transport_weight_rows.append(
                    {
                        "method": "FedAdapterManifold-DecoupledAdmit",
                        "seed": int(args.seed),
                        "dataset": args.dataset,
                        "heterogeneity_setting": args.heterogeneity_setting,
                        "round": int(args.rounds),
                        "receiver_client": receiver.client_id,
                        "receiver_domain": receiver.domain,
                        "donor_client": donor.client_id,
                        "donor_domain": donor.domain,
                        "d_sub": float(d_sub[receiver_index, donor_index]),
                        "d_label": float(d_label[receiver_index, donor_index]),
                        "d_geo_used": False,
                        "donor_weight": float(decoupled_weights[receiver_index, donor_index]),
                    }
                )
        decoupled_families = build_receiver_action_candidates(
            receivers=local_adapters,
            donors=local_adapters,
            donor_weights=decoupled_weights,
            target_ranks=ranks,
            modes=decoupled_modes,
        )
        decoupled_transport_result = select_joint_empirical_bernstein_paths(
            selector_clients=selector_clients,
            eval_clients=clients,
            base_weight=base_weight,
            anchor_adapters=local_adapters,
            manifold_families=decoupled_families,
            ranks=ranks,
            path=args.decoupled_transport_candidates,
            delta=args.decoupled_transport_delta,
            risk_tolerance=args.decoupled_transport_risk_tolerance,
            confidence_bound=args.decoupled_transport_confidence_bound,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
        )

    semantic_admission_result = None
    semantic_exact_certificate_rows: list[dict] = []
    semantic_generator_screen_rows: list[dict] = []
    if args.run_multiround_semantic_admission:
        semantic_admission_result = run_semantic_admission_lora(
            clients,
            selector_clients,
            base_weight,
            graph=geometry.graph,
            d_geo=geometry.d_geo,
            d_label=d_label,
            ranks=ranks,
            rounds=args.rounds,
            local_epochs=args.local_epochs,
            lr=args.lr,
            batch_size=args.batch_size,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            lambda_geo=args.lambda_geo,
            lambda_label=args.lambda_label,
            lambda_risk=args.semantic_admission_lambda_risk,
            tau=args.tau,
            self_weight=args.adapter_graph_self_weight,
            graph_mass_temperature=args.semantic_admission_graph_mass_temperature,
            minimum_tempered_neighbor_mass=args.semantic_admission_minimum_tempered_neighbor_mass,
            graph_scale_policy=args.semantic_admission_graph_scale_policy,
            topology_top_k=args.semantic_admission_topology_top_k,
            topology_neighbor_mass=args.semantic_admission_topology_neighbor_mass,
            final_gate_candidates=args.adapter_graph_mix_candidates,
            final_gate_tolerance=args.adapter_graph_mix_tolerance,
            final_gate_policy=args.adapter_graph_mix_policy,
            method="FedAdapterManifold-Admit",
        )

    fedavg_lora_result = run_fedavg_lora_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=args.rounds,
        local_epochs=args.local_epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
    )
    fedavg_lora_adapter = fedavg_lora_result.global_adapter
    fedavg_lift_result = run_fedavg_lift_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=args.rounds,
        local_epochs=args.local_epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
    )
    fedprox_result = run_fedprox_lora_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=args.rounds,
        local_epochs=args.local_epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        prox_mu=args.fedprox_mu,
    )
    fedrot_result = run_fedrot_lora_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=args.rounds,
        local_epochs=args.local_epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        rotation_strength=args.fedrot_rotation_strength,
    )
    fedex_result = None
    fedsa_result = None
    fedpissa_result = None
    fedlease_result = None
    fedalt_result = None
    fedtree_result = None
    hilora_result = None
    fedsmooth_result = None
    intrinsic_cumulative_result = None
    lorafair_result = None
    telora_result = None
    subspace_reg_result = None
    dysco_result = None
    cumulative_action_result = None
    cumulative_full_gate_result = None
    cumulative_screened_action_result = None
    cumulative_screened_full_control_result = None
    cumulative_blockwise_action_result = None
    cumulative_blockwise_source_control_result = None
    cumulative_blockwise_joint_result = None
    cumulative_blockwise_joint_full_control_result = None
    cumulative_competitive_action_result = None
    cumulative_competitive_full_control_result = None
    cumulative_disagreement_route_result = None
    cumulative_direct_anchor_route_result = None
    cumulative_action_rank_matched_result = None
    if args.run_recent_lora_baselines:
        if len(set(int(rank) for rank in ranks)) != 1:
            raise ValueError(
                "Recent LoRA fidelity baselines require a fixed common rank; "
                "use rank_policy: fixed for the fair-comparison run."
            )
        requested_recent = {
            item.strip().lower()
            for item in str(args.recent_lora_methods).split(",")
            if item.strip()
        }
        valid_recent = {
            "fedex",
            "fedsa",
            "fedpissa",
            "fedlease",
            "fedalt",
            "fedtree",
            "hilora",
            "fedsmooth",
            "lorafair",
            "telora",
            "subspace_reg",
            "dysco",
        }
        if not requested_recent or "all" in requested_recent:
            requested_recent = set(valid_recent)
        unknown_recent = requested_recent - valid_recent
        if unknown_recent:
            raise ValueError(f"Unknown recent LoRA methods: {sorted(unknown_recent)}")
        if (
            args.run_cumulative_action_admission
            and args.cumulative_action_source == "fedsmooth"
            and "fedsmooth" not in requested_recent
        ):
            raise ValueError("Cumulative action admission requires recent_lora_methods to include fedsmooth")
        if "fedex" in requested_recent:
            fedex_result = run_fedex_lora_baseline(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
            )
        if "fedsa" in requested_recent:
            fedsa_result = run_fedsa_lora_baseline(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
            )
        if "fedpissa" in requested_recent:
            fedpissa_result = run_fedpissa_visual_baseline(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                decorrelation_strength=args.fedpissa_lambda,
                tail_start=(None if int(args.fedpissa_tail_start) <= 0 else int(args.fedpissa_tail_start)),
            )
        if "fedlease" in requested_recent:
            fedlease_result = run_fedlease_visual_baseline(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                max_experts=args.recent_lora_max_experts,
            )
        if "fedalt" in requested_recent:
            fedalt_result = run_fedalt_visual_baseline(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
            )
        if "fedtree" in requested_recent:
            fedtree_result = run_fedtree_lora_visual_baseline(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                warmup_rounds=args.fedtree_warmup_rounds,
                max_clusters=args.recent_lora_max_experts,
                search_range_k=args.fedtree_search_range_k,
                single_cluster_score=args.fedtree_single_cluster_score,
                routing_candidates=tuple(
                    float(item.strip())
                    for item in str(args.fedtree_routing_candidates).split(",")
                    if item.strip()
                ),
            )
        if "hilora" in requested_recent and int(ranks[0]) >= 3:
            hilora_result = run_hilora_visual_baseline(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                max_clusters=args.recent_lora_max_experts,
            )
        if "fedsmooth" in requested_recent:
            fedsmooth_result = run_fedsmooth_lora_baseline(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                zeta=args.fedsmooth_zeta,
                min_zeta=args.fedsmooth_min_zeta,
                gamma=args.fedsmooth_gamma,
                gradient_sample_size=args.fedsmooth_gradient_sample_size,
            )
        if "lorafair" in requested_recent:
            lorafair_result = run_lorafair_baseline(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                refinement_iterations=args.lorafair_refinement_iterations,
                refinement_lr=args.lorafair_refinement_lr,
                lambda_reg=args.lorafair_lambda_reg,
            )
        if "telora" in requested_recent:
            telora_result = run_telora_baseline(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                eta=args.telora_eta,
                sinkhorn_iterations=args.telora_sinkhorn_iterations,
            )
        if "subspace_reg" in requested_recent:
            subspace_reg_result = run_subspace_reg_lora_baseline(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                mu=args.subspace_reg_mu,
                basis_alpha=args.subspace_reg_basis_alpha,
                lambda_reg=args.subspace_reg_lambda,
            )
        if "dysco" in requested_recent:
            dysco_result = run_dysco_visual_port(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
            )
        if bool(args.run_intrinsic_cumulative_source):
            intrinsic_cumulative_result = run_intrinsic_cumulative_lift(
                clients,
                base_weight,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                server_step_candidates=args.cumulative_server_step_candidates,
                warm_start_subspace=args.cumulative_subspace_warm_start,
            )
        if args.run_cumulative_action_admission:
            if args.cumulative_action_source == "intrinsic-lift":
                if intrinsic_cumulative_result is None:
                    intrinsic_cumulative_result = run_intrinsic_cumulative_lift(
                        clients,
                        base_weight,
                        ranks=ranks,
                        rounds=args.rounds,
                        local_epochs=args.local_epochs,
                        lr=args.lr,
                        batch_size=args.batch_size,
                        seed=args.seed,
                        dataset=args.dataset,
                        heterogeneity_setting=args.heterogeneity_setting,
                        server_step_candidates=args.cumulative_server_step_candidates,
                        warm_start_subspace=args.cumulative_subspace_warm_start,
                    )
                cumulative_stream_result = intrinsic_cumulative_result
                cumulative_transport_source = "FedAdapterManifold intrinsic cumulative lifted-update stream"
            else:
                if fedsmooth_result is None:
                    raise ValueError("The fedsmooth cumulative source requires a completed FedSmoothLoRA run")
                cumulative_stream_result = fedsmooth_result
                cumulative_transport_source = "FedSmoothLoRA official-equation cumulative center"
            cumulative_exact_rank = int(cumulative_stream_result.effective_adapter.rank)
            requested_cumulative_rank = int(args.cumulative_semantic_target_rank)
            cumulative_target_rank = (
                cumulative_exact_rank if requested_cumulative_rank <= 0 else min(requested_cumulative_rank, cumulative_exact_rank)
            )
            identity_weights = np.eye(len(clients), dtype=np.float64)
            cumulative_sources = [cumulative_stream_result.effective_adapter for _ in clients]
            for receiver_index, (client, receiver) in enumerate(zip(clients, local_adapters)):
                cumulative_action_decomposition_rows.append(
                    {
                        "method": "FedAdapterManifold-CumulativeAdmit",
                        "seed": int(args.seed),
                        "dataset": args.dataset,
                        "heterogeneity_setting": args.heterogeneity_setting,
                        "round": int(args.rounds),
                        "client_id": client.client_id,
                        "domain": client.domain,
                        "transport_source": cumulative_transport_source,
                        "transport_source_effective_rank": cumulative_exact_rank,
                        **receiver_action_energy_summary(
                            receiver,
                            cumulative_stream_result.effective_adapter.delta(),
                        ),
                    }
                )
            cumulative_families = build_receiver_action_candidates(
                receivers=local_adapters,
                donors=cumulative_sources,
                donor_weights=identity_weights,
                target_ranks=[cumulative_target_rank for _ in clients],
                modes=("core", "column", "row", "tangent", "full"),
                name_prefix="FedAdapterManifold-CumulativeAction",
            )
            sample_prior = np.asarray([max(len(client.x_train), 1) for client in clients], dtype=np.float64)
            cumulative_semantic_adapters, cumulative_semantic_weight_rows = build_curvature_semantic_candidates(
                training_clients=clients,
                base_weight=base_weight,
                receivers=local_adapters,
                donor_cumulative_deltas=cumulative_stream_result.client_cumulative_deltas,
                algebraic_residual=cumulative_stream_result.cumulative_projection_residual,
                prior_weights=sample_prior,
                graph=geometry.graph,
                d_geo=geometry.d_geo,
                label_distance=d_label,
                tau=args.tau,
                lambda_subspace=args.cumulative_semantic_lambda_subspace,
                lambda_geo=args.lambda_geo,
                lambda_label=args.lambda_label,
                lambda_risk=args.cumulative_semantic_lambda_risk,
                self_weight=args.adapter_graph_self_weight,
                top_k_neighbors=args.cumulative_semantic_top_k,
                correction_scale=args.cumulative_semantic_correction_scale,
                target_ranks=[cumulative_target_rank for _ in clients],
            )
            for row in cumulative_semantic_weight_rows:
                receiver_index = int(row["receiver_index"])
                donor_index = int(row["donor_index"])
                row.update(
                    {
                        "method": "FedAdapterManifold-CumulativeSemantic",
                        "seed": int(args.seed),
                        "dataset": args.dataset,
                        "heterogeneity_setting": args.heterogeneity_setting,
                        "round": int(args.rounds),
                        "transport_source": cumulative_transport_source,
                        "transport_source_effective_rank": cumulative_exact_rank,
                        "deployment_rank": cumulative_target_rank,
                        "receiver_client_id": clients[receiver_index].client_id,
                        "receiver_domain": clients[receiver_index].domain,
                        "donor_client_id": clients[donor_index].client_id,
                        "donor_domain": clients[donor_index].domain,
                    }
                )
            cumulative_families["semantic_stream"] = cumulative_semantic_adapters
            blockwise_endpoints, blockwise_source_controls, cumulative_blockwise_fit_rows = (
                fit_blockwise_action_endpoints(
                    training_clients=clients,
                    base_weight=base_weight,
                    receiver_adapters=local_adapters,
                    source_families={
                        "full_center": cumulative_families["full"],
                        "semantic_stream": cumulative_semantic_adapters,
                    },
                    ranks=[cumulative_target_rank for _ in clients],
                )
            )
            blockwise_source_by_client = {
                str(row["client_id"]): str(row["selected_source_name"])
                for row in cumulative_blockwise_fit_rows
                if row["selected_source"]
            }
            cumulative_blockwise_action_result = select_joint_empirical_bernstein_paths(
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                anchor_adapters=local_adapters,
                manifold_families={"blockwise": blockwise_endpoints},
                ranks=[cumulative_target_rank for _ in clients],
                path=args.decoupled_transport_candidates,
                delta=args.decoupled_transport_delta,
                risk_tolerance=args.decoupled_transport_risk_tolerance,
                confidence_bound=args.decoupled_transport_confidence_bound,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="FedAdapterManifold-CumulativeBlockwiseAdmit",
            )
            cumulative_blockwise_source_control_result = select_joint_empirical_bernstein_paths(
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                anchor_adapters=local_adapters,
                manifold_families={"selected_source": blockwise_source_controls},
                ranks=[cumulative_target_rank for _ in clients],
                path=args.decoupled_transport_candidates,
                delta=args.decoupled_transport_delta,
                risk_tolerance=args.decoupled_transport_risk_tolerance,
                confidence_bound=args.decoupled_transport_confidence_bound,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="CumulativeSelectedSource-Scalar-Control",
            )
            for result in (cumulative_blockwise_action_result, cumulative_blockwise_source_control_result):
                for row in result.admission_rows:
                    row["training_selected_source"] = blockwise_source_by_client[str(row["client_id"])]
                for row in result.per_client_metrics:
                    row["training_selected_source"] = blockwise_source_by_client[str(row["client_id"])]
            blockwise_joint_comparisons = joint_path_comparison_count(
                args.decoupled_transport_candidates,
                2,
            )
            cumulative_blockwise_joint_result = select_joint_empirical_bernstein_paths(
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                anchor_adapters=local_adapters,
                manifold_families={
                    "blockwise": blockwise_endpoints,
                    "full": cumulative_families["full"],
                },
                ranks=[cumulative_target_rank for _ in clients],
                path=args.decoupled_transport_candidates,
                delta=args.decoupled_transport_delta,
                risk_tolerance=args.decoupled_transport_risk_tolerance,
                confidence_bound=args.decoupled_transport_confidence_bound,
                num_comparisons_override=blockwise_joint_comparisons,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="FedAdapterManifold-CumulativeBlockwiseJointAdmit",
            )
            cumulative_blockwise_joint_full_control_result = select_joint_empirical_bernstein_paths(
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                anchor_adapters=local_adapters,
                manifold_families={"full": cumulative_families["full"]},
                ranks=[cumulative_target_rank for _ in clients],
                path=args.decoupled_transport_candidates,
                delta=args.decoupled_transport_delta,
                risk_tolerance=args.decoupled_transport_risk_tolerance,
                confidence_bound=args.decoupled_transport_confidence_bound,
                num_comparisons_override=blockwise_joint_comparisons,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="CumulativeFull-BlockwiseBudget-Control",
            )
            for result in (cumulative_blockwise_joint_result, cumulative_blockwise_joint_full_control_result):
                for row in result.admission_rows:
                    row["training_selected_source"] = blockwise_source_by_client[str(row["client_id"])]
                for row in result.per_client_metrics:
                    row["training_selected_source"] = blockwise_source_by_client[str(row["client_id"])]
            cumulative_competitive_action_result, cumulative_competitive_full_control_result = (
                select_competitive_safe_blockwise_paths(
                    selector_clients=selector_clients,
                    eval_clients=clients,
                    base_weight=base_weight,
                    anchor_adapters=local_adapters,
                    full_endpoints=cumulative_families["full"],
                    blockwise_endpoints=blockwise_endpoints,
                    ranks=[cumulative_target_rank for _ in clients],
                    path=args.decoupled_transport_candidates,
                    delta=args.decoupled_transport_delta,
                    risk_tolerance=args.decoupled_transport_risk_tolerance,
                    seed=args.seed,
                    dataset=args.dataset,
                    heterogeneity_setting=args.heterogeneity_setting,
                    round_id=args.rounds,
                )
            )
            for result in (cumulative_competitive_action_result, cumulative_competitive_full_control_result):
                for row in result.admission_rows:
                    row["training_selected_source"] = blockwise_source_by_client[str(row["client_id"])]
                for row in result.per_client_metrics:
                    row["training_selected_source"] = blockwise_source_by_client[str(row["client_id"])]
            cumulative_disagreement_route_result = select_disagreement_localized_routes(
                training_clients=clients,
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                anchor_adapters=local_adapters,
                full_endpoints=cumulative_families["full"],
                blockwise_endpoints=blockwise_endpoints,
                full_control=cumulative_competitive_full_control_result,
                ranks=[cumulative_target_rank for _ in clients],
                prototype_maps=geometry.prototypes,
                path=args.decoupled_transport_candidates,
                delta=args.decoupled_transport_delta,
                risk_tolerance=args.decoupled_transport_risk_tolerance,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                calibration_shift_mode=args.calibration_shift_mode,
                calibration_shift_bins=args.calibration_shift_bins,
                calibration_shift_min_stratum_size=args.calibration_shift_min_stratum_size,
                candidate_search_mode=args.route_candidate_search_mode,
            )
            for row in cumulative_disagreement_route_result.admission_rows:
                row["training_selected_source"] = blockwise_source_by_client[str(row["client_id"])]
            for row in cumulative_disagreement_route_result.per_client_metrics:
                row["training_selected_source"] = blockwise_source_by_client[str(row["client_id"])]
            cumulative_direct_anchor_route_result = select_disagreement_localized_routes(
                training_clients=clients,
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                anchor_adapters=local_adapters,
                full_endpoints=cumulative_families["full"],
                blockwise_endpoints=blockwise_endpoints,
                full_control=cumulative_competitive_full_control_result,
                ranks=[cumulative_target_rank for _ in clients],
                prototype_maps=geometry.prototypes,
                path=args.decoupled_transport_candidates,
                delta=args.decoupled_transport_delta,
                risk_tolerance=args.decoupled_transport_risk_tolerance,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="FedAdapterManifold-DirectAnchorRoute",
                safety_reference="anchor",
                calibration_shift_mode=args.calibration_shift_mode,
                calibration_shift_bins=args.calibration_shift_bins,
                calibration_shift_min_stratum_size=args.calibration_shift_min_stratum_size,
                candidate_search_mode=args.route_candidate_search_mode,
            )
            for row in cumulative_direct_anchor_route_result.admission_rows:
                row["training_selected_source"] = blockwise_source_by_client[str(row["client_id"])]
            for row in cumulative_direct_anchor_route_result.per_client_metrics:
                row["training_selected_source"] = blockwise_source_by_client[str(row["client_id"])]
            screened_endpoints, cumulative_screening_rows = screen_action_family_on_training_data(
                training_clients=clients,
                base_weight=base_weight,
                anchor_adapters=local_adapters,
                manifold_families=cumulative_families,
                ranks=[cumulative_target_rank for _ in clients],
                path=args.decoupled_transport_candidates,
            )
            screened_family_by_client = {
                str(row["client_id"]): str(row["selected_family_name"])
                for row in cumulative_screening_rows
                if row["selected_family"]
            }
            cumulative_screened_action_result = select_joint_empirical_bernstein_paths(
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                anchor_adapters=local_adapters,
                manifold_families={"screened": screened_endpoints},
                ranks=[cumulative_target_rank for _ in clients],
                path=args.decoupled_transport_candidates,
                delta=args.decoupled_transport_delta,
                risk_tolerance=args.decoupled_transport_risk_tolerance,
                confidence_bound=args.decoupled_transport_confidence_bound,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="FedAdapterManifold-CumulativeScreenedAdmit",
            )
            cumulative_screened_full_control_result = select_joint_empirical_bernstein_paths(
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                anchor_adapters=local_adapters,
                manifold_families={"full": cumulative_families["full"]},
                ranks=[cumulative_target_rank for _ in clients],
                path=args.decoupled_transport_candidates,
                delta=args.decoupled_transport_delta,
                risk_tolerance=args.decoupled_transport_risk_tolerance,
                confidence_bound=args.decoupled_transport_confidence_bound,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="CumulativeFull-ScreenedBudget-Control",
            )
            for result in (cumulative_screened_action_result, cumulative_screened_full_control_result):
                for row in result.admission_rows:
                    row["training_screened_family"] = screened_family_by_client[str(row["client_id"])]
                for row in result.per_client_metrics:
                    row["training_screened_family"] = screened_family_by_client[str(row["client_id"])]
            joint_comparison_count = joint_path_comparison_count(
                args.decoupled_transport_candidates,
                len(cumulative_families),
            )
            cumulative_action_result = select_joint_empirical_bernstein_paths(
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                anchor_adapters=local_adapters,
                manifold_families=cumulative_families,
                ranks=[cumulative_target_rank for _ in clients],
                path=args.decoupled_transport_candidates,
                delta=args.decoupled_transport_delta,
                risk_tolerance=args.decoupled_transport_risk_tolerance,
                confidence_bound=args.decoupled_transport_confidence_bound,
                num_comparisons_override=joint_comparison_count,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="FedAdapterManifold-CumulativeAdmit",
            )
            for row in cumulative_action_result.admission_rows:
                row["transport_source"] = cumulative_transport_source
                row["transport_source_effective_rank"] = cumulative_exact_rank
                row["transport_source_deployment_rank"] = cumulative_target_rank
            cumulative_full_gate_result = select_joint_empirical_bernstein_paths(
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                anchor_adapters=local_adapters,
                manifold_families={"full": cumulative_families["full"]},
                ranks=[cumulative_target_rank for _ in clients],
                path=args.decoupled_transport_candidates,
                delta=args.decoupled_transport_delta,
                risk_tolerance=args.decoupled_transport_risk_tolerance,
                confidence_bound=args.decoupled_transport_confidence_bound,
                num_comparisons_override=joint_comparison_count,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="CumulativeFull-Gate-Control",
            )
            for row in cumulative_full_gate_result.admission_rows:
                row["transport_source"] = cumulative_transport_source
                row["transport_source_effective_rank"] = cumulative_exact_rank
                row["transport_source_deployment_rank"] = cumulative_target_rank
            rank_matched_sources = [cumulative_stream_result.rank_matched_adapter for _ in clients]
            rank_matched_families = build_receiver_action_candidates(
                receivers=local_adapters,
                donors=rank_matched_sources,
                donor_weights=identity_weights,
                target_ranks=ranks,
                modes=("core", "column", "row", "tangent", "full"),
                name_prefix="FedAdapterManifold-CumulativeAction-RankMatched",
            )
            cumulative_action_rank_matched_result = select_joint_empirical_bernstein_paths(
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                anchor_adapters=local_adapters,
                manifold_families=rank_matched_families,
                ranks=ranks,
                path=args.decoupled_transport_candidates,
                delta=args.decoupled_transport_delta,
                risk_tolerance=args.decoupled_transport_risk_tolerance,
                confidence_bound=args.decoupled_transport_confidence_bound,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="FedAdapterManifold-CumulativeAdmit-RankMatched",
            )
            for row in cumulative_action_rank_matched_result.admission_rows:
                row["transport_source"] = "FedSmoothLoRA final deployment-rank control"
                row["transport_source_effective_rank"] = int(cumulative_stream_result.rank_matched_adapter.rank)
                row["transport_source_deployment_rank_matched"] = True
    scaffold_result = None
    if not args.skip_heavy_personalized_baselines:
        scaffold_result = run_scaffold_lora_baseline(
            clients,
            base_weight,
            ranks=ranks,
            rounds=args.rounds,
            local_epochs=args.local_epochs,
            lr=args.lr,
            batch_size=args.batch_size,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            control_lr=args.scaffold_control_lr,
        )
    ditto_result = run_ditto_lora_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=args.rounds,
        local_epochs=args.local_epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        prox_mu=args.ditto_mu,
    )
    pfedme_result = None
    if not args.skip_heavy_personalized_baselines:
        pfedme_result = run_pfedme_lora_baseline(
            clients,
            base_weight,
            ranks=ranks,
            rounds=args.rounds,
            local_epochs=args.local_epochs,
            lr=args.lr,
            batch_size=args.batch_size,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            prox_mu=args.pfedme_mu,
        )
    fedgeo_diag_result = run_fedgeo_diag_baseline(
        clients,
        base_weight,
        local_adapters,
        ranks=ranks,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    fedgeo_agg_result = run_fedgeo_agg_baseline(
        clients,
        base_weight,
        local_adapters,
        d_geo=geometry.d_geo,
        graph=geometry.graph,
        ranks=ranks,
        tau=args.tau,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    if semantic_admission_result is not None and bool(args.semantic_admission_exact_certificate):
        semantic_candidates = semantic_admission_result.candidate_adapters
        semantic_candidate_name = "FAM-SemanticEndpoint"
        exact_method = "FedAdapterManifold-Admit"
        generator_screen_count = sum(
            bool(flag)
            for flag in (
                args.semantic_admission_generator_screening,
                args.semantic_admission_internal_generator_screening,
                args.semantic_admission_anchored_action_screening,
                args.semantic_admission_crossfit_anchored_action_screening,
            )
        )
        if generator_screen_count > 1:
            raise ValueError(
                "external, raw-action, anchored-action, and crossfit generator screening are mutually exclusive"
            )
        if bool(args.semantic_admission_crossfit_anchored_action_screening):
            if not bool(args.run_decoupled_transport):
                raise ValueError(
                    "semantic_admission_crossfit_anchored_action_screening requires run_decoupled_transport"
                )
            crossfit_fraction = float(args.semantic_admission_crossfit_fraction)
            if not 0.0 < crossfit_fraction < 0.5:
                raise ValueError("semantic_admission_crossfit_fraction must be in (0, 0.5)")
            inner_train_clients, inner_validation_clients, inner_split_rows = (
                _split_clients_for_candidate_selection(
                    clients,
                    fraction=crossfit_fraction,
                    strategy="stratified",
                    seed=int(args.seed) + 70001,
                )
            )
            provisional_local_result = run_local_lora(
                inner_train_clients,
                base_weight,
                ranks=ranks,
                epochs=total_local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=int(args.seed) + 71003,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="Crossfit-Provisional-Local",
            )
            provisional_local = provisional_local_result.adapters
            provisional_d_label = label_distance_matrix(inner_train_clients, num_classes)
            provisional_diagnostic = run_subspace_failure_diagnostic(
                inner_train_clients,
                base_weight,
                provisional_local,
                d_geo=geometry.d_geo,
                d_label=provisional_d_label,
                lambda_geo=args.lambda_geo,
                lambda_label=args.lambda_label,
                tau=args.tau,
                diagnostic_threshold=args.diagnostic_threshold,
            )
            provisional_distance = np.asarray(provisional_diagnostic.d_sub, dtype=np.float64).copy()
            provisional_distance += max(0.0, float(args.lambda_label)) * np.asarray(
                provisional_d_label, dtype=np.float64
            )
            provisional_logits = -provisional_distance / max(float(args.tau), 1e-8)
            provisional_logits -= np.max(provisional_logits, axis=1, keepdims=True)
            provisional_weights = np.exp(provisional_logits)
            provisional_diagonal = np.arange(len(inner_train_clients))
            provisional_weights[provisional_diagonal, provisional_diagonal] *= max(
                float(args.adapter_graph_self_weight), 1e-12
            )
            provisional_weights /= np.clip(
                provisional_weights.sum(axis=1, keepdims=True), 1e-12, None
            )
            provisional_semantic_result = run_semantic_admission_lora(
                inner_train_clients,
                inner_train_clients,
                base_weight,
                graph=geometry.graph,
                d_geo=geometry.d_geo,
                d_label=provisional_d_label,
                ranks=ranks,
                rounds=args.rounds,
                local_epochs=args.local_epochs,
                lr=args.lr,
                batch_size=args.batch_size,
                seed=int(args.seed) + 72007,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                lambda_geo=args.lambda_geo,
                lambda_label=args.lambda_label,
                lambda_risk=args.semantic_admission_lambda_risk,
                tau=args.tau,
                self_weight=args.adapter_graph_self_weight,
                graph_mass_temperature=args.semantic_admission_graph_mass_temperature,
                minimum_tempered_neighbor_mass=args.semantic_admission_minimum_tempered_neighbor_mass,
                graph_scale_policy=args.semantic_admission_graph_scale_policy,
                topology_top_k=args.semantic_admission_topology_top_k,
                topology_neighbor_mass=args.semantic_admission_topology_neighbor_mass,
                final_gate_candidates="1.0",
                final_gate_tolerance=0.0,
                final_gate_policy="fixed",
                method="Crossfit-Provisional-Semantic",
                precomputed_local_fallback=provisional_local_result,
            )
            anchored_modes = tuple(
                item.strip()
                for item in str(args.decoupled_transport_modes).split(",")
                if item.strip()
            )
            anchored_steps = tuple(
                step
                for step in _parse_unit_interval_candidates(
                    args.decoupled_transport_candidates,
                    default=[0.25, 0.5, 0.75, 1.0],
                )
                if step > 0.0
            )
            provisional_anchored = build_anchored_receiver_action_path_candidates(
                receivers=provisional_local,
                donors=provisional_local,
                donor_weights=provisional_weights,
                target_ranks=ranks,
                modes=anchored_modes,
                steps=anchored_steps,
            )
            rebuilt_anchored = build_anchored_receiver_action_path_candidates(
                receivers=local_adapters,
                donors=local_adapters,
                donor_weights=decoupled_weights,
                target_ranks=ranks,
                modes=anchored_modes,
                steps=anchored_steps,
            )
            provisional_families = {
                "FAM-InternalSemanticGenerator": provisional_semantic_result.candidate_adapters,
            }
            rebuilt_families = {
                "FAM-InternalSemanticGenerator": semantic_admission_result.candidate_adapters,
            }
            for family_name, adapters in sorted(provisional_anchored.items()):
                key = f"FAM-{family_name}"
                provisional_families[key] = adapters
                rebuilt_families[key] = rebuilt_anchored[family_name]
            semantic_candidates, semantic_generator_screen_rows = (
                select_crossfitted_semantic_endpoint(
                    validation_clients=inner_validation_clients,
                    base_weight=base_weight,
                    provisional_candidate_families=provisional_families,
                    rebuilt_candidate_families=rebuilt_families,
                    seed=args.seed,
                    dataset=args.dataset,
                    heterogeneity_setting=args.heterogeneity_setting,
                    round_id=args.rounds,
                )
            )
            split_by_client = {str(row["client_id"]): row for row in inner_split_rows}
            for row in semantic_generator_screen_rows:
                split = split_by_client[str(row["client_id"])]
                row["inner_training_samples"] = int(split["train_samples_for_adapter_training"])
                row["inner_validation_samples"] = int(split["calibration_samples_for_selector"])
                row["inner_validation_fraction"] = crossfit_fraction
            semantic_candidate_name = "FAM-CrossfitAnchoredActionEndpoint"
            exact_method = "FedAdapterManifold-Admit-CrossfitAction"
        elif bool(args.semantic_admission_anchored_action_screening):
            if not bool(args.run_decoupled_transport):
                raise ValueError(
                    "semantic_admission_anchored_action_screening requires run_decoupled_transport"
                )
            anchored_modes = tuple(
                item.strip()
                for item in str(args.decoupled_transport_modes).split(",")
                if item.strip()
            )
            anchored_steps = tuple(
                step
                for step in _parse_unit_interval_candidates(
                    args.decoupled_transport_candidates,
                    default=[0.25, 0.5, 0.75, 1.0],
                )
                if step > 0.0
            )
            anchored_families = build_anchored_receiver_action_path_candidates(
                receivers=local_adapters,
                donors=local_adapters,
                donor_weights=decoupled_weights,
                target_ranks=ranks,
                modes=anchored_modes,
                steps=anchored_steps,
            )
            internal_families = {
                "FAM-InternalSemanticGenerator": semantic_admission_result.candidate_adapters,
            }
            for family_name, adapters in sorted(anchored_families.items()):
                internal_families[f"FAM-{family_name}"] = adapters
            semantic_candidates, semantic_generator_screen_rows = (
                select_training_fixed_semantic_endpoint(
                    training_clients=clients,
                    base_weight=base_weight,
                    candidate_families=internal_families,
                    seed=args.seed,
                    dataset=args.dataset,
                    heterogeneity_setting=args.heterogeneity_setting,
                    round_id=args.rounds,
                )
            )
            semantic_candidate_name = "FAM-AnchoredActionEndpoint"
            exact_method = "FedAdapterManifold-Admit-AnchoredAction"
        elif bool(args.semantic_admission_internal_generator_screening):
            if not bool(args.run_decoupled_transport):
                raise ValueError(
                    "semantic_admission_internal_generator_screening requires run_decoupled_transport"
                )
            internal_families = {
                "FAM-InternalSemanticGenerator": semantic_admission_result.candidate_adapters,
            }
            for family_name, adapters in sorted(decoupled_families.items()):
                internal_families[f"FAM-ReceiverAction-{family_name}"] = adapters
            semantic_candidates, semantic_generator_screen_rows = (
                select_training_fixed_semantic_endpoint(
                    training_clients=clients,
                    base_weight=base_weight,
                    candidate_families=internal_families,
                    seed=args.seed,
                    dataset=args.dataset,
                    heterogeneity_setting=args.heterogeneity_setting,
                    round_id=args.rounds,
                )
            )
            semantic_candidate_name = "FAM-InternalGeneratorEndpoint"
            exact_method = "FedAdapterManifold-Admit-InternalBank"
        elif bool(args.semantic_admission_generator_screening):
            if subspace_reg_result is None:
                raise ValueError(
                    "semantic_admission_generator_screening requires recent_lora_methods to include subspace_reg"
                )
            subspace_reg_candidates = [
                subspace_reg_result.global_adapter for _ in clients
            ]
            semantic_candidates, semantic_generator_screen_rows = (
                select_training_fixed_semantic_endpoint(
                    training_clients=clients,
                    base_weight=base_weight,
                    candidate_families={
                        "FAM-InternalSemanticGenerator": semantic_admission_result.candidate_adapters,
                        "Subspace-Reg-LoRA-Visual-Port": subspace_reg_candidates,
                    },
                    seed=args.seed,
                    dataset=args.dataset,
                    heterogeneity_setting=args.heterogeneity_setting,
                    round_id=args.rounds,
                )
            )
            semantic_candidate_name = "FAM-TrainingScreenedSemanticEndpoint"
            exact_method = "FedAdapterManifold-Admit-Power"
        if args.semantic_admission_exact_mode == "hierarchical-holm-deduplicated":
            exact_semantic_result = select_hierarchical_exact_certified_endpoint(
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                local_adapters=local_adapters,
                geo_adapters=fedgeo_agg_result.client_adapters,
                semantic_adapters=semantic_candidates,
                familywise_alpha=float(args.semantic_admission_familywise_alpha),
                loss_margin=0.0,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method=exact_method,
                candidate_name=semantic_candidate_name,
                candidate_training_fixed=True,
            )
        else:
            exact_semantic_result = select_exact_certified_signed_tangent(
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                local_adapters=local_adapters,
                geo_adapters=fedgeo_agg_result.client_adapters,
                signed_adapters=semantic_candidates,
                familywise_alpha=float(args.semantic_admission_familywise_alpha),
                loss_margin=0.0,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method=exact_method,
                candidate_name=semantic_candidate_name,
                candidate_training_fixed=True,
            )
        semantic_admission_result.client_adapters = exact_semantic_result.client_adapters
        semantic_admission_result.per_client_metrics = exact_semantic_result.per_client_metrics
        semantic_exact_certificate_rows = exact_semantic_result.admission_rows
    fedproto_result = run_fedproto_lora_baseline(
        clients,
        base_weight,
        local_adapters,
        d_geo=geometry.d_geo,
        ranks=ranks,
        tau=args.tau,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )

    sca_result = run_subspace_compatible_baseline(
        clients,
        base_weight,
        local_adapters,
        compat,
        ranks=ranks,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    pair_rows = diagnostic.conflict_rows
    failure_x = diagnostic.failure_x
    update_failure_x = diagnostic.update_failure_x
    failure_y = diagnostic.failure_y
    diagnostic_r = diagnostic.subspace_semantic_loss_pearson_r
    diagnostic_passed = diagnostic.passed

    combined_distance = manifold_distance
    baseline_cluster_k = int(max(1, min(args.adapter_bank_k if args.adapter_bank_k > 0 else 2, len(clients))))
    clustered_result = run_clustered_lora_baseline(
        clients,
        base_weight,
        local_adapters,
        distance=combined_distance,
        ranks=ranks,
        k=baseline_cluster_k,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    fedamp_result = run_fedamp_lora_baseline(
        clients,
        base_weight,
        local_adapters,
        distance=adapter_distance,
        ranks=ranks,
        tau=args.tau,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    fedper_result = run_fedper_lora_baseline(
        clients,
        base_weight,
        local_adapters,
        shared_adapter=fedavg_lift_result.global_adapter,
        ranks=ranks,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
        candidates=args.fedper_personal_weight_candidates,
        tolerance=args.fedper_personal_weight_tolerance,
    )
    adapter_graph = _select_adapter_graph(geometry.graph, args.adapter_graph_mode, seed=args.seed)
    graph_mixed_adapters = graph_compatible_aggregate(
        local_adapters,
        graph=adapter_graph,
        compatibility=method_compat if args.adapter_graph_compatibility == "method" else None,
        distance=combined_distance if args.adapter_graph_distance == "combined" else None,
        target_ranks=ranks,
        tau=args.tau,
        self_weight=args.adapter_graph_self_weight,
        name_prefix="fedadaptermanifold_graphmix",
    )
    if args.adapter_graph_mix_policy == "fixed":
        manifold_adapters = _blend_fixed_graph_mix(
            local_adapters,
            graph_mixed_adapters,
            weight=args.adapter_graph_mix_weight,
            ranks=ranks,
        )
        graph_mix_rows = _fixed_graph_mix_rows(
            clients,
            weight=args.adapter_graph_mix_weight,
            policy=args.adapter_graph_mix_policy,
        )
    else:
        manifold_adapters, graph_mix_rows = select_loss_constrained_graph_mix(
            clients,
            base_weight,
            local_adapters,
            graph_mixed_adapters,
            ranks=ranks,
            candidates=args.adapter_graph_mix_candidates,
            tolerance=args.adapter_graph_mix_tolerance,
            policy=args.adapter_graph_mix_policy,
        )
    bank_result = None
    client_route_bank_result = None
    fedper_fam_adapters = None
    fedper_fam_metrics = []
    fedper_fam_rows = []
    fedper_fam_selective_adapters = None
    fedper_fam_selective_metrics = []
    ditto_fam_adapters = None
    ditto_fam_metrics = []
    ditto_fam_rows = []
    ditto_fam_selective_adapters = None
    ditto_fam_selective_metrics = []
    fedper_residual_fam_adapters = None
    fedper_residual_fam_metrics = []
    fedper_residual_fam_rows = []
    ditto_residual_fam_adapters = None
    ditto_residual_fam_metrics = []
    ditto_residual_fam_rows = []
    anchor_residual_admission_results = {}
    anchor_residual_scalar_control_results = {}
    anchor_residual_fit_rows = []
    selective_adapters = None
    selective_metrics = []
    strong_selective_adapters = None
    strong_selective_metrics = []
    path_admission_result = None
    signed_tangent_result = None
    signed_tangent_screen_rows: list[dict] = []
    selective_rows = []
    bank_selection_rows = []
    if diagnostic_passed or args.continue_on_failed_diagnostic:
        effective_bank_k = args.adapter_bank_k
        if effective_bank_k <= 0:
            effective_bank_k, bank_selection_rows = select_adapter_bank_k(
                combined_distance,
                max_k=min(4, len(clients)),
            )
        else:
            effective_bank_k = int(max(1, min(args.adapter_bank_k, len(clients))))
            bank_selection_rows = _fixed_bank_selection_rows(combined_distance, effective_bank_k)
        provisional_medoids, provisional_assignments = _bank_assignments(combined_distance, effective_bank_k)
        cluster_prototypes = cluster_prototypes_from_geometry(
            geometry.prototypes,
            geometry.client_ids,
            provisional_assignments,
            num_classes,
            fallback_clients=clients,
        )
        bank_result = run_adapter_bank_baseline(
            clients,
            base_weight,
            manifold_adapters,
            d_geo=geometry.d_geo,
            combined_distance=combined_distance,
            ranks=ranks,
            k=effective_bank_k,
            route_tau=args.route_tau,
            shared_weight=args.shared_weight,
            shared_weight_policy=args.shared_weight_policy,
            shared_weight_tolerance=args.shared_weight_tolerance,
            shared_weight_candidates=args.shared_weight_candidates,
            personal_weight=args.personal_weight,
            personal_weight_policy=args.personal_weight_policy,
            personal_weight_tolerance=args.personal_weight_tolerance,
            personal_weight_candidates=args.personal_weight_candidates,
            cluster_prototypes=cluster_prototypes,
            routing_mode=args.adapter_bank_routing,
            routing_prior_weight=args.adapter_bank_prior_weight,
            personal_adapters=local_adapters,
            smoothing_adapters=fedgeo_agg_result.client_adapters,
            smoothing_weight=args.manifold_smoothing_weight,
            smoothing_policy=args.manifold_smoothing_policy,
            smoothing_tolerance=args.manifold_smoothing_tolerance,
            smoothing_candidates=args.manifold_smoothing_candidates,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
        )
        if args.adapter_bank_routing != "client":
            client_route_bank_result = run_adapter_bank_baseline(
                clients,
                base_weight,
                manifold_adapters,
                d_geo=geometry.d_geo,
                combined_distance=combined_distance,
                ranks=ranks,
                k=effective_bank_k,
                route_tau=args.route_tau,
                shared_weight=args.shared_weight,
                shared_weight_policy=args.shared_weight_policy,
                shared_weight_tolerance=args.shared_weight_tolerance,
                shared_weight_candidates=args.shared_weight_candidates,
                personal_weight=args.personal_weight,
                personal_weight_policy=args.personal_weight_policy,
                personal_weight_tolerance=args.personal_weight_tolerance,
                personal_weight_candidates=args.personal_weight_candidates,
                cluster_prototypes=cluster_prototypes,
                routing_mode="client",
                routing_prior_weight=args.adapter_bank_prior_weight,
                personal_adapters=local_adapters,
                smoothing_adapters=fedgeo_agg_result.client_adapters,
                smoothing_weight=args.manifold_smoothing_weight,
                smoothing_policy=args.manifold_smoothing_policy,
                smoothing_tolerance=args.manifold_smoothing_tolerance,
                smoothing_candidates=args.manifold_smoothing_candidates,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="FedAdapterManifold-ClientRoute",
            )
        if args.run_signed_tangent_admission:
            requested_sources = [
                item.strip().lower()
                for item in str(args.signed_tangent_sources).split(",")
                if item.strip()
            ]
            source_map = {
                "geo": fedgeo_agg_result.client_adapters,
                "subspace": sca_result.client_adapters,
                "bank": bank_result.client_adapters,
            }
            if semantic_admission_result is not None:
                source_map["semantic"] = semantic_admission_result.client_adapters
            if fedsmooth_result is not None:
                source_map["fedsmooth"] = [fedsmooth_result.effective_adapter for _ in clients]
            if intrinsic_cumulative_result is not None:
                source_map["intrinsic"] = [intrinsic_cumulative_result.effective_adapter for _ in clients]
            unknown_sources = sorted(set(requested_sources) - set(source_map))
            if unknown_sources:
                raise ValueError(f"Unknown signed tangent sources: {unknown_sources}")
            if not requested_sources:
                raise ValueError("signed_tangent_sources must contain at least one source")
            temporal_source_names = {"fedsmooth", "intrinsic"}
            signed_method = (
                "FedAdapterManifold-TemporalSemanticAdmit"
                if set(requested_sources).issubset(temporal_source_names)
                else "FedAdapterManifold-SignedTangentAdmit"
            )
            signed_candidates = []
            for client_index, (client, local_adapter, geo_adapter, rank) in enumerate(
                zip(clients, local_adapters, fedgeo_agg_result.client_adapters, ranks)
            ):
                anchor_map = {"local": local_adapter, "geo": geo_adapter}
                candidate_records = []
                for anchor_name, anchor_adapter in anchor_map.items():
                    for source_name in requested_sources:
                        candidate, diagnostics = build_fisher_signed_tangent_candidate(
                            x_screen=client.x_train,
                            y_screen=client.y_train,
                            base_weight=base_weight,
                            receiver=local_adapter,
                            anchor=anchor_adapter,
                            source=source_map[source_name][client_index],
                            target_rank=int(rank),
                            alpha_max=float(args.signed_tangent_alpha_max),
                            derivative_margin=float(args.signed_tangent_derivative_margin),
                            name=f"signed_tangent_{client_index}_{anchor_name}_{source_name}",
                        )
                        record = {
                            "method": signed_method,
                            "seed": int(args.seed),
                            "dataset": args.dataset,
                            "heterogeneity_setting": args.heterogeneity_setting,
                            "round": int(args.rounds),
                            "client_id": client.client_id,
                            "domain": client.domain,
                            "anchor_source": anchor_name,
                            "transport_source": source_name,
                            **vars(diagnostics),
                        }
                        candidate_records.append((record, candidate))
                selected_record, selected_candidate = min(
                    candidate_records,
                    key=lambda item: (
                        float(item[0]["candidate_screen_loss"]),
                        0 if item[0]["anchor_source"] == "local" else 1,
                        requested_sources.index(str(item[0]["transport_source"])),
                    ),
                )
                for record, _ in candidate_records:
                    record["training_screen_selected"] = record is selected_record
                    signed_tangent_screen_rows.append(record)
                signed_candidates.append(selected_candidate)
            selector = (
                select_exact_certified_signed_tangent
                if bool(args.signed_tangent_exact_certificate)
                else select_target_pareto_signed_tangent
            )
            selector_kwargs = {
                "selector_clients": selector_clients,
                "eval_clients": clients,
                "base_weight": base_weight,
                "local_adapters": local_adapters,
                "geo_adapters": fedgeo_agg_result.client_adapters,
                "signed_adapters": signed_candidates,
                "loss_margin": float(args.signed_tangent_loss_margin),
                "seed": args.seed,
                "dataset": args.dataset,
                "heterogeneity_setting": args.heterogeneity_setting,
                "round_id": args.rounds,
                "method": signed_method,
            }
            if bool(args.signed_tangent_exact_certificate):
                selector_kwargs["familywise_alpha"] = float(
                    args.signed_tangent_familywise_alpha
                )
            signed_tangent_result = selector(**selector_kwargs)
        selector_candidates = _selector_candidate_pool(
            scope=args.candidate_selector_scope,
            local_adapters=local_adapters,
            fedgeo_agg_adapters=fedgeo_agg_result.client_adapters,
            subspace_adapters=sca_result.client_adapters,
            bank_adapters=bank_result.client_adapters,
        )
        # ClientRoute remains a separately reported mechanism control.  The
        # deployable intrinsic selector is intentionally limited to the four
        # candidates returned by _selector_candidate_pool.
        fedper_fam_adapters, fedper_fam_metrics, fedper_fam_rows = _select_fedper_fam_hybrid(
            selector_clients=selector_clients,
            eval_clients=clients,
            base_weight=base_weight,
            personal_adapters=fedper_result.client_adapters,
            fam_adapters=bank_result.client_adapters,
            ranks=ranks,
            candidates=args.fedper_fam_personal_weight_candidates,
            tolerance=args.fedper_fam_loss_tolerance,
            policy=args.fedper_fam_policy,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
            method="FedPer-FAM",
            personal_source_method="FedPer-LoRA",
        )
        ditto_fam_adapters, ditto_fam_metrics, ditto_fam_rows = _select_fedper_fam_hybrid(
            selector_clients=selector_clients,
            eval_clients=clients,
            base_weight=base_weight,
            personal_adapters=ditto_result.personal_adapters,
            fam_adapters=bank_result.client_adapters,
            ranks=ranks,
            candidates=args.ditto_fam_personal_weight_candidates,
            tolerance=args.ditto_fam_loss_tolerance,
            policy=args.ditto_fam_policy,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
            method="Ditto-FAM",
            personal_source_method="Ditto-LoRA",
        )
        if int(args.anchor_residual_epochs) > 0:
            fedper_residual_fam_adapters, fedper_residual_fam_metrics, fedper_residual_fam_rows = (
                _train_anchor_residual_adapters(
                    train_clients=clients,
                    eval_clients=clients,
                    base_weight=base_weight,
                    anchor_adapters=fedper_result.client_adapters,
                    fam_adapters=bank_result.client_adapters,
                    ranks=ranks,
                    epochs=args.anchor_residual_epochs,
                    lr=args.lr,
                    lr_scale=args.anchor_residual_lr_scale,
                    batch_size=args.batch_size,
                    residual_rank=args.anchor_residual_rank,
                    validation_fraction=args.anchor_residual_validation_fraction,
                    validation_strategy=args.anchor_residual_validation_strategy,
                    shrinkage_candidates=args.anchor_residual_shrinkage_candidates,
                    seed=args.seed,
                    dataset=args.dataset,
                    heterogeneity_setting=args.heterogeneity_setting,
                    round_id=args.rounds,
                    method="FedPer-ResidualFAM",
                    anchor_source_method="FedPer-LoRA",
                )
            )
            ditto_residual_fam_adapters, ditto_residual_fam_metrics, ditto_residual_fam_rows = (
                _train_anchor_residual_adapters(
                    train_clients=clients,
                    eval_clients=clients,
                    base_weight=base_weight,
                    anchor_adapters=ditto_result.personal_adapters,
                    fam_adapters=bank_result.client_adapters,
                    ranks=ranks,
                    epochs=args.anchor_residual_epochs,
                    lr=args.lr,
                    lr_scale=args.anchor_residual_lr_scale,
                    batch_size=args.batch_size,
                    residual_rank=args.anchor_residual_rank,
                    validation_fraction=args.anchor_residual_validation_fraction,
                    validation_strategy=args.anchor_residual_validation_strategy,
                    shrinkage_candidates=args.anchor_residual_shrinkage_candidates,
                    seed=args.seed,
                    trainer_seed_offset=70000,
                    dataset=args.dataset,
                    heterogeneity_setting=args.heterogeneity_setting,
                    round_id=args.rounds,
                    method="Ditto-ResidualFAM",
                    anchor_source_method="Ditto-LoRA",
                )
            )
        if args.run_anchor_residual_admission:
            available_sources = {
                "geo": fedgeo_agg_result.client_adapters,
                "subspace": sca_result.client_adapters,
                "bank": bank_result.client_adapters,
            }
            requested_sources = [
                item.strip().lower()
                for item in str(args.anchor_residual_admission_sources).split(",")
                if item.strip()
            ]
            unknown_sources = sorted(set(requested_sources) - set(available_sources))
            if unknown_sources:
                raise ValueError(
                    "Unknown anchor residual admission sources: " + ", ".join(unknown_sources)
                )
            residual_sources = {
                name: available_sources[name]
                for name in requested_sources
            }
            if not residual_sources:
                raise ValueError("At least one anchor residual admission source is required")

            anchor_families = _build_anchor_residual_families(
                fedper_result=fedper_result,
                ditto_result=ditto_result,
                fedtree_result=fedtree_result,
                subspace_reg_result=subspace_reg_result,
                num_clients=len(clients),
            )
            for anchor_name, (anchor_method, anchor_adapters, anchor_metrics) in anchor_families.items():
                residual_endpoints, scalar_endpoints, fit_rows = fit_residual_blockwise_action_endpoints(
                    training_clients=clients,
                    base_weight=base_weight,
                    receiver_adapters=anchor_adapters,
                    center_endpoints=anchor_adapters,
                    residual_source_families=residual_sources,
                    ranks=ranks,
                    name_prefix=f"FedAdapterManifold-{anchor_name}AnchorResidual",
                )
                for row in fit_rows:
                    row.update(
                        {
                            "method": f"FedAdapterManifold-{anchor_name}AnchorResidual",
                            "anchor_family": anchor_method,
                            "seed": int(args.seed),
                            "dataset": args.dataset,
                            "heterogeneity_setting": args.heterogeneity_setting,
                            "round": int(args.rounds),
                            "candidate_pool_fixed_pretest": True,
                            "test_used_for_selection": False,
                        }
                    )
                anchor_residual_fit_rows.extend(fit_rows)
                anchor_control_metrics = []
                for metric in anchor_metrics:
                    anchor_control_metrics.append(
                        {
                            **metric,
                            "method": f"{anchor_name}-Anchor-Control",
                            "selected_transport_family": "anchor",
                            "selected_admission_strength": 0.0,
                            "certified_risk_upper_bound": 0.0,
                        }
                    )
                anchor_control = JointPathAdmissionResult(
                    client_adapters=anchor_adapters,
                    per_client_metrics=anchor_control_metrics,
                    admission_rows=[],
                )
                method_name = f"FedAdapterManifold-{anchor_name}AnchorResidualAdmit"
                anchor_residual_admission_results[anchor_name] = select_disagreement_localized_routes(
                    training_clients=clients,
                    selector_clients=selector_clients,
                    eval_clients=clients,
                    base_weight=base_weight,
                    anchor_adapters=anchor_adapters,
                    full_endpoints=anchor_adapters,
                    blockwise_endpoints=residual_endpoints,
                    full_control=anchor_control,
                    ranks=ranks,
                    prototype_maps=geometry.prototypes,
                    path=args.decoupled_transport_candidates,
                    delta=args.decoupled_transport_delta,
                    risk_tolerance=args.decoupled_transport_risk_tolerance,
                    seed=args.seed,
                    dataset=args.dataset,
                    heterogeneity_setting=args.heterogeneity_setting,
                    round_id=args.rounds,
                    method=method_name,
                    safety_reference="anchor",
                    calibration_shift_mode=args.calibration_shift_mode,
                    calibration_shift_bins=args.calibration_shift_bins,
                    calibration_shift_min_stratum_size=args.calibration_shift_min_stratum_size,
                    candidate_search_mode=args.route_candidate_search_mode,
                )
                anchor_residual_scalar_control_results[anchor_name] = select_disagreement_localized_routes(
                    training_clients=clients,
                    selector_clients=selector_clients,
                    eval_clients=clients,
                    base_weight=base_weight,
                    anchor_adapters=anchor_adapters,
                    full_endpoints=anchor_adapters,
                    blockwise_endpoints=scalar_endpoints,
                    full_control=anchor_control,
                    ranks=ranks,
                    prototype_maps=geometry.prototypes,
                    path=args.decoupled_transport_candidates,
                    delta=args.decoupled_transport_delta,
                    risk_tolerance=args.decoupled_transport_risk_tolerance,
                    seed=args.seed,
                    dataset=args.dataset,
                    heterogeneity_setting=args.heterogeneity_setting,
                    round_id=args.rounds,
                    method=f"{method_name}-ScalarControl",
                    safety_reference="anchor",
                    calibration_shift_mode=args.calibration_shift_mode,
                    calibration_shift_bins=args.calibration_shift_bins,
                    calibration_shift_min_stratum_size=args.calibration_shift_min_stratum_size,
                    candidate_search_mode=args.route_candidate_search_mode,
                )
        # Primary admission must not depend on outcome-conditioned setting
        # summaries. Candidate losses below are evaluated only on the declared
        # training/calibration split, so the manifold-priority shortcut is off.
        high_conflict_prior = False
        selector_metrics = _selector_metric_pool(
            scope=args.candidate_selector_scope,
            local_metrics=local_result.per_client_metrics,
            fedgeo_agg_metrics=fedgeo_agg_result.per_client_metrics,
            subspace_metrics=sca_result.per_client_metrics,
            bank_metrics=bank_result.per_client_metrics,
        )
        selective_adapters, selective_metrics, selective_rows = _select_client_candidate_adapters(
            selector_clients,
            base_weight,
            selector_candidates,
            candidate_metrics=selector_metrics,
            ranks=ranks,
            graph=geometry.graph,
            policy=args.candidate_selector_policy,
            manifold_prior=high_conflict_prior,
            loss_tolerance=args.candidate_selector_loss_tolerance,
            loss_tolerance_ratio=args.candidate_selector_loss_tolerance_ratio,
            neighbor_weight=args.candidate_selector_neighbor_weight,
            softmax_tau=args.candidate_selector_softmax_tau,
            lcb_delta=args.candidate_selector_lcb_delta,
            anchor_priority=args.candidate_selector_anchor_priority,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
            method="FedAdapterManifold-Selective",
        )
        if args.run_path_admission:
            path_anchor_adapters, _, path_anchor_rows = _select_client_candidate_adapters(
                selector_clients,
                base_weight,
                {
                    "Local-LoRA": local_adapters,
                    "FedGeo-Agg": fedgeo_agg_result.client_adapters,
                },
                candidate_metrics={
                    "Local-LoRA": local_result.per_client_metrics,
                    "FedGeo-Agg": fedgeo_agg_result.per_client_metrics,
                },
                ranks=ranks,
                graph=geometry.graph,
                policy="loss-min",
                manifold_prior=False,
                loss_tolerance=0.0,
                loss_tolerance_ratio=0.0,
                neighbor_weight=0.0,
                softmax_tau=args.candidate_selector_softmax_tau,
                lcb_delta=args.path_admission_delta,
                anchor_priority="",
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="FedAdapterManifold-PathAnchor",
            )
            path_manifold_candidates = {
                "Subspace-Compatible": sca_result.client_adapters,
                "FedAdapterManifold": bank_result.client_adapters,
            }
            path_manifold_metrics = {
                "Subspace-Compatible": sca_result.per_client_metrics,
                "FedAdapterManifold": bank_result.per_client_metrics,
            }
            if semantic_admission_result is not None:
                path_manifold_candidates["FedAdapterManifold-Admit"] = semantic_admission_result.client_adapters
                path_manifold_metrics["FedAdapterManifold-Admit"] = semantic_admission_result.per_client_metrics
            path_manifold_adapters, _, path_manifold_rows = _select_client_candidate_adapters(
                selector_clients,
                base_weight,
                path_manifold_candidates,
                candidate_metrics=path_manifold_metrics,
                ranks=ranks,
                graph=geometry.graph,
                policy="loss-min",
                manifold_prior=False,
                loss_tolerance=0.0,
                loss_tolerance_ratio=0.0,
                neighbor_weight=0.0,
                softmax_tau=args.candidate_selector_softmax_tau,
                lcb_delta=args.path_admission_delta,
                anchor_priority="",
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="FedAdapterManifold-PathManifold",
            )
            path_admission_result = select_empirical_bernstein_path(
                selector_clients=selector_clients,
                eval_clients=clients,
                base_weight=base_weight,
                anchor_adapters=path_anchor_adapters,
                manifold_adapters=path_manifold_adapters,
                ranks=ranks,
                path=args.path_admission_candidates,
                delta=args.path_admission_delta,
                risk_tolerance=args.path_admission_risk_tolerance,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
            )
            for row in path_admission_result.admission_rows:
                client_id = str(row["client_id"])
                anchor_selected = next(
                    (
                        source["selected_method"]
                        for source in path_anchor_rows
                        if str(source["client_id"]) == client_id and bool(source["selected"])
                    ),
                    "",
                )
                manifold_selected = next(
                    (
                        source["selected_method"]
                        for source in path_manifold_rows
                        if str(source["client_id"]) == client_id and bool(source["selected"])
                    ),
                    "",
                )
                row["anchor_method"] = anchor_selected
                row["manifold_method"] = manifold_selected
        fedper_fam_selective_rows = []
        fedper_fam_selective_adapters, fedper_fam_selective_metrics, fedper_fam_selective_rows = _select_client_candidate_adapters(
            selector_clients,
            base_weight,
            {
                "FedPer-LoRA": fedper_result.client_adapters,
                "FedAdapterManifold": bank_result.client_adapters,
                "FedPer-FAM": fedper_fam_adapters,
            },
            candidate_metrics={
                "FedPer-LoRA": fedper_result.per_client_metrics,
                "FedAdapterManifold": bank_result.per_client_metrics,
                "FedPer-FAM": fedper_fam_metrics,
            },
            ranks=ranks,
            graph=geometry.graph,
            policy="diagnostic-gated",
            manifold_prior=high_conflict_prior,
            loss_tolerance=args.candidate_selector_loss_tolerance,
            loss_tolerance_ratio=args.candidate_selector_loss_tolerance_ratio,
            neighbor_weight=args.candidate_selector_neighbor_weight,
            softmax_tau=args.candidate_selector_softmax_tau,
            lcb_delta=args.candidate_selector_lcb_delta,
            anchor_priority="FedPer-LoRA,FedAvg-LoRA,Local-LoRA",
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
            method="FedPer-FAM-Selective",
        )
        selective_rows.extend(fedper_fam_selective_rows)
        ditto_fam_selective_rows = []
        ditto_fam_selective_adapters, ditto_fam_selective_metrics, ditto_fam_selective_rows = _select_client_candidate_adapters(
            selector_clients,
            base_weight,
            {
                "Ditto-LoRA": ditto_result.personal_adapters,
                "FedAdapterManifold": bank_result.client_adapters,
                "Ditto-FAM": ditto_fam_adapters,
            },
            candidate_metrics={
                "Ditto-LoRA": ditto_result.per_client_metrics,
                "FedAdapterManifold": bank_result.per_client_metrics,
                "Ditto-FAM": ditto_fam_metrics,
            },
            ranks=ranks,
            graph=geometry.graph,
            policy="diagnostic-gated",
            manifold_prior=high_conflict_prior,
            loss_tolerance=args.candidate_selector_loss_tolerance,
            loss_tolerance_ratio=args.candidate_selector_loss_tolerance_ratio,
            neighbor_weight=args.candidate_selector_neighbor_weight,
            softmax_tau=args.candidate_selector_softmax_tau,
            lcb_delta=args.candidate_selector_lcb_delta,
            anchor_priority="Ditto-LoRA,FedAvg-LoRA,Local-LoRA",
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
            method="Ditto-FAM-Selective",
        )
        selective_rows.extend(ditto_fam_selective_rows)
        strong_selector_candidates = dict(selector_candidates)
        strong_selector_candidates.update(
            {
                "FedAvg-Lift": [fedavg_lift_result.global_adapter for _ in clients],
                "FedRot-LoRA": [fedrot_result.global_adapter for _ in clients],
                "FedProx-LoRA": [fedprox_result.global_adapter for _ in clients],
                "Ditto-LoRA": ditto_result.personal_adapters,
                "Ditto-FAM": ditto_fam_adapters,
                "Ditto-FAM-Selective": ditto_fam_selective_adapters,
                "FedProto-LoRA": fedproto_result.client_adapters,
                "FedPer-LoRA": fedper_result.client_adapters,
                "FedPer-FAM": fedper_fam_adapters,
                "FedPer-FAM-Selective": fedper_fam_selective_adapters,
                "Clustered-LoRA": clustered_result.client_adapters,
                "FedAMP-LoRA": fedamp_result.client_adapters,
            }
        )
        if semantic_admission_result is not None:
            strong_selector_candidates["FedAdapterManifold-Admit"] = semantic_admission_result.client_adapters
        if fedper_residual_fam_adapters is not None:
            strong_selector_candidates["FedPer-ResidualFAM"] = fedper_residual_fam_adapters
            strong_selector_candidates.update(
                _residual_shrinkage_candidate_pool(
                    anchor_adapters=fedper_result.client_adapters,
                    residual_adapters=fedper_residual_fam_adapters,
                    ranks=ranks,
                    candidates=args.anchor_residual_selector_shrinkage_candidates,
                    prefix="FedPer-ResidualFAM",
                )
            )
        if ditto_residual_fam_adapters is not None:
            strong_selector_candidates["Ditto-ResidualFAM"] = ditto_residual_fam_adapters
            strong_selector_candidates.update(
                _residual_shrinkage_candidate_pool(
                    anchor_adapters=ditto_result.personal_adapters,
                    residual_adapters=ditto_residual_fam_adapters,
                    ranks=ranks,
                    candidates=args.anchor_residual_selector_shrinkage_candidates,
                    prefix="Ditto-ResidualFAM",
                )
            )
        if scaffold_result is not None:
            strong_selector_candidates["SCAFFOLD-LoRA"] = [scaffold_result.global_adapter for _ in clients]
        if pfedme_result is not None:
            strong_selector_candidates["pFedMe-LoRA"] = pfedme_result.personal_adapters
        strong_selector_metrics = dict(selector_metrics)
        strong_selector_metrics.update(
            {
                "FedAvg-Lift": fedavg_lift_result.per_client_metrics,
                "FedRot-LoRA": fedrot_result.per_client_metrics,
                "FedProx-LoRA": fedprox_result.per_client_metrics,
                "Ditto-LoRA": ditto_result.per_client_metrics,
                "Ditto-FAM": ditto_fam_metrics,
                "Ditto-FAM-Selective": ditto_fam_selective_metrics,
                "FedProto-LoRA": fedproto_result.per_client_metrics,
                "FedPer-LoRA": fedper_result.per_client_metrics,
                "FedPer-FAM": fedper_fam_metrics,
                "FedPer-FAM-Selective": fedper_fam_selective_metrics,
                "Clustered-LoRA": clustered_result.per_client_metrics,
                "FedAMP-LoRA": fedamp_result.per_client_metrics,
            }
        )
        if semantic_admission_result is not None:
            strong_selector_metrics["FedAdapterManifold-Admit"] = semantic_admission_result.per_client_metrics
        if fedper_residual_fam_metrics:
            strong_selector_metrics["FedPer-ResidualFAM"] = fedper_residual_fam_metrics
        if ditto_residual_fam_metrics:
            strong_selector_metrics["Ditto-ResidualFAM"] = ditto_residual_fam_metrics
        if scaffold_result is not None:
            strong_selector_metrics["SCAFFOLD-LoRA"] = scaffold_result.per_client_metrics
        if pfedme_result is not None:
            strong_selector_metrics["pFedMe-LoRA"] = pfedme_result.per_client_metrics
        strong_rows = []
        strong_selective_adapters, strong_selective_metrics, strong_rows = _select_client_candidate_adapters(
            selector_clients,
            base_weight,
            strong_selector_candidates,
            candidate_metrics=strong_selector_metrics,
            ranks=ranks,
            graph=geometry.graph,
            policy=args.strong_candidate_selector_policy,
            manifold_prior=False,
            loss_tolerance=args.candidate_selector_loss_tolerance,
            loss_tolerance_ratio=args.candidate_selector_loss_tolerance_ratio,
            neighbor_weight=args.candidate_selector_neighbor_weight,
            softmax_tau=args.candidate_selector_softmax_tau,
            lcb_delta=args.candidate_selector_lcb_delta,
            anchor_priority=args.strong_candidate_selector_anchor_priority or args.candidate_selector_anchor_priority,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
            method="FedAdapterManifold-StrongSelective",
        )
        selective_rows.extend(strong_rows)

    per_client_rows = []
    per_client_rows.extend(base_head_metrics)
    per_client_rows.extend(local_result.per_client_metrics)
    if semantic_admission_result is not None:
        per_client_rows.extend(semantic_admission_result.per_client_metrics)
    if decoupled_transport_result is not None:
        per_client_rows.extend(decoupled_transport_result.per_client_metrics)
    per_client_rows.extend(fedavg_lora_result.per_client_metrics)
    per_client_rows.extend(fedavg_lift_result.per_client_metrics)
    per_client_rows.extend(fedrot_result.per_client_metrics)
    if fedex_result is not None:
        per_client_rows.extend(fedex_result.per_client_metrics)
    if fedsa_result is not None:
        per_client_rows.extend(fedsa_result.per_client_metrics)
    if fedpissa_result is not None:
        per_client_rows.extend(fedpissa_result.per_client_metrics)
    if fedlease_result is not None:
        per_client_rows.extend(fedlease_result.per_client_metrics)
    if fedalt_result is not None:
        per_client_rows.extend(fedalt_result.per_client_metrics)
    if fedtree_result is not None:
        per_client_rows.extend(fedtree_result.per_client_metrics)
    if hilora_result is not None:
        per_client_rows.extend(hilora_result.per_client_metrics)
    if fedsmooth_result is not None:
        per_client_rows.extend(fedsmooth_result.per_client_metrics)
        if args.report_fedsmooth_rank_matched:
            per_client_rows.extend(fedsmooth_result.rank_matched_per_client_metrics)
    if intrinsic_cumulative_result is not None:
        per_client_rows.extend(intrinsic_cumulative_result.per_client_metrics)
        if args.report_fedsmooth_rank_matched:
            per_client_rows.extend(intrinsic_cumulative_result.rank_matched_metrics)
    if lorafair_result is not None:
        per_client_rows.extend(lorafair_result.per_client_metrics)
    if telora_result is not None:
        per_client_rows.extend(telora_result.per_client_metrics)
    if subspace_reg_result is not None:
        per_client_rows.extend(subspace_reg_result.per_client_metrics)
    if dysco_result is not None:
        per_client_rows.extend(dysco_result.per_client_metrics)
    if cumulative_action_result is not None:
        per_client_rows.extend(cumulative_action_result.per_client_metrics)
    if cumulative_full_gate_result is not None:
        per_client_rows.extend(cumulative_full_gate_result.per_client_metrics)
    if cumulative_screened_action_result is not None:
        per_client_rows.extend(cumulative_screened_action_result.per_client_metrics)
    if cumulative_screened_full_control_result is not None:
        per_client_rows.extend(cumulative_screened_full_control_result.per_client_metrics)
    if cumulative_blockwise_action_result is not None:
        per_client_rows.extend(cumulative_blockwise_action_result.per_client_metrics)
    if cumulative_blockwise_source_control_result is not None:
        per_client_rows.extend(cumulative_blockwise_source_control_result.per_client_metrics)
    if cumulative_blockwise_joint_result is not None:
        per_client_rows.extend(cumulative_blockwise_joint_result.per_client_metrics)
    if cumulative_blockwise_joint_full_control_result is not None:
        per_client_rows.extend(cumulative_blockwise_joint_full_control_result.per_client_metrics)
    if cumulative_competitive_action_result is not None:
        per_client_rows.extend(cumulative_competitive_action_result.per_client_metrics)
    if cumulative_competitive_full_control_result is not None:
        per_client_rows.extend(cumulative_competitive_full_control_result.per_client_metrics)
    if cumulative_disagreement_route_result is not None:
        per_client_rows.extend(cumulative_disagreement_route_result.per_client_metrics)
    if cumulative_direct_anchor_route_result is not None:
        per_client_rows.extend(cumulative_direct_anchor_route_result.per_client_metrics)
    if cumulative_action_rank_matched_result is not None:
        per_client_rows.extend(cumulative_action_rank_matched_result.per_client_metrics)
    per_client_rows.extend(fedprox_result.per_client_metrics)
    if scaffold_result is not None:
        per_client_rows.extend(scaffold_result.per_client_metrics)
    per_client_rows.extend(ditto_result.per_client_metrics)
    if pfedme_result is not None:
        per_client_rows.extend(pfedme_result.per_client_metrics)
    per_client_rows.extend(fedgeo_diag_result.per_client_metrics)
    per_client_rows.extend(fedgeo_agg_result.per_client_metrics)
    per_client_rows.extend(fedproto_result.per_client_metrics)
    per_client_rows.extend(fedper_result.per_client_metrics)
    if fedper_fam_metrics:
        per_client_rows.extend(fedper_fam_metrics)
    if fedper_fam_selective_metrics:
        per_client_rows.extend(fedper_fam_selective_metrics)
    if ditto_fam_metrics:
        per_client_rows.extend(ditto_fam_metrics)
    if ditto_fam_selective_metrics:
        per_client_rows.extend(ditto_fam_selective_metrics)
    if fedper_residual_fam_metrics:
        per_client_rows.extend(fedper_residual_fam_metrics)
    if ditto_residual_fam_metrics:
        per_client_rows.extend(ditto_residual_fam_metrics)
    for result in anchor_residual_admission_results.values():
        per_client_rows.extend(result.per_client_metrics)
    for result in anchor_residual_scalar_control_results.values():
        per_client_rows.extend(result.per_client_metrics)
    per_client_rows.extend(clustered_result.per_client_metrics)
    per_client_rows.extend(fedamp_result.per_client_metrics)
    per_client_rows.extend(sca_result.per_client_metrics)
    if bank_result is not None:
        per_client_rows.extend(bank_result.per_client_metrics)
    if client_route_bank_result is not None:
        per_client_rows.extend(client_route_bank_result.per_client_metrics)
    if selective_metrics:
        per_client_rows.extend(selective_metrics)
    if strong_selective_metrics:
        per_client_rows.extend(strong_selective_metrics)
    if path_admission_result is not None:
        per_client_rows.extend(path_admission_result.per_client_metrics)
    if signed_tangent_result is not None:
        per_client_rows.extend(signed_tangent_result.per_client_metrics)
    _add_heterogeneity_alias(per_client_rows)
    _add_geometry_auxiliary_scores(per_client_rows, clients, geometry)
    metrics_rows = summarize_method(per_client_rows, diagnostic_r)
    for row in metrics_rows:
        row["raw_subspace_failure_pearson_r"] = diagnostic.pearson_r
        row["adapter_incompatibility_failure_pearson_r"] = diagnostic.incompatibility_pearson_r
        row["raw_adapter_incompatibility_failure_pearson_r"] = diagnostic.incompatibility_pearson_r
        row["receiver_residual_subspace_failure_pearson_r"] = diagnostic.receiver_residual_pearson_r
        row["receiver_residual_adapter_incompatibility_failure_pearson_r"] = (
            diagnostic.incompatibility_receiver_residual_pearson_r
        )
        row["receiver_residual_geo_failure_pearson_r"] = diagnostic.geo_receiver_residual_pearson_r
        row["pair_mean_adapter_incompatibility_failure_pearson_r"] = diagnostic.incompatibility_pair_mean_pearson_r
        row["pair_max_adapter_incompatibility_failure_pearson_r"] = diagnostic.incompatibility_pair_max_pearson_r
        row["update_failure_pearson_r"] = diagnostic.update_pearson_r
        row["action_semantic_loss_pearson_r"] = diagnostic.action_semantic_loss_pearson_r
        row["action_semantic_accuracy_pearson_r"] = diagnostic.action_semantic_accuracy_pearson_r
        row["local_risk_semantic_loss_pearson_r"] = diagnostic.local_risk_semantic_loss_pearson_r
        row["projection_semantic_loss_pearson_r"] = diagnostic.projection_semantic_loss_pearson_r
        row["subspace_semantic_loss_pearson_r"] = diagnostic.subspace_semantic_loss_pearson_r
        row["column_subspace_semantic_loss_pearson_r"] = diagnostic.column_subspace_semantic_loss_pearson_r
        row["row_subspace_semantic_loss_pearson_r"] = diagnostic.row_subspace_semantic_loss_pearson_r
        row["update_semantic_loss_pearson_r"] = diagnostic.update_semantic_loss_pearson_r
        row["geo_failure_pearson_r"] = diagnostic.geo_pearson_r
        row["label_failure_pearson_r"] = diagnostic.label_pearson_r
        row["combined_failure_pearson_r"] = diagnostic.combined_pearson_r
        row["diagnostic_passed"] = diagnostic_passed
    idea_support_rows = _idea_support_rows(metrics_rows, args.diagnostic_threshold)
    statistical_rows = _statistical_support_rows(per_client_rows, pair_rows, args.seed)

    subspace_rows = diagnostic.subspace_rows
    drop_rows = _drop_rows(clients, base_weight, local_adapters, fedavg_lora_adapter)
    generalization_rows = _local_generalization_rows(local_result.per_client_metrics)
    bank_rows = bank_result.routing_rows if bank_result is not None else []
    sample_bank_rows = bank_result.sample_routing_rows if bank_result is not None else []
    negative_transfer_rows, negative_transfer_summary_rows = _negative_transfer_rows(per_client_rows)
    method_adapters = {
        "Base-Head": base_adapters,
        "Local-LoRA": local_adapters,
        "FedAvg-LoRA": [fedavg_lora_result.global_adapter for _ in clients],
        "FedAvg-Lift": [fedavg_lift_result.global_adapter for _ in clients],
        "FedRot-LoRA": [fedrot_result.global_adapter for _ in clients],
        "FedProx-LoRA": [fedprox_result.global_adapter for _ in clients],
        "Ditto-LoRA": ditto_result.personal_adapters,
        "FedGeo-Diag": fedgeo_diag_result.client_adapters,
        "FedGeo-Agg": fedgeo_agg_result.client_adapters,
        "FedProto-LoRA": fedproto_result.client_adapters,
        "FedPer-LoRA": fedper_result.client_adapters,
        "Clustered-LoRA": clustered_result.client_adapters,
        "FedAMP-LoRA": fedamp_result.client_adapters,
        "Subspace-Compatible": sca_result.client_adapters,
    }
    if semantic_admission_result is not None:
        method_adapters["FedAdapterManifold-Admit"] = semantic_admission_result.client_adapters
    if decoupled_transport_result is not None:
        method_adapters["FedAdapterManifold-DecoupledAdmit"] = decoupled_transport_result.client_adapters
    if fedex_result is not None:
        method_adapters["FedEx-LoRA"] = [fedex_result.effective_adapter for _ in clients]
    if fedsa_result is not None:
        method_adapters["FedSA-LoRA"] = fedsa_result.personal_adapters
    if fedpissa_result is not None:
        method_adapters["FedPissa-EquationPort"] = fedpissa_result.personal_adapters
    if fedlease_result is not None:
        method_adapters["FedLEASE-OfficialPort"] = fedlease_result.client_adapters
    if fedalt_result is not None:
        method_adapters["FedALT-OfficialVisualPort"] = fedalt_result.effective_adapters
    if fedtree_result is not None:
        method_adapters["FedTreeLoRA-Visual-Port"] = fedtree_result.client_adapters
    if hilora_result is not None:
        method_adapters["HiLoRA-Visual"] = hilora_result.client_adapters
    if fedsmooth_result is not None:
        method_adapters["FedSmoothLoRA"] = [fedsmooth_result.effective_adapter for _ in clients]
        if args.report_fedsmooth_rank_matched:
            method_adapters["FedSmoothLoRA-RankMatched"] = [fedsmooth_result.rank_matched_adapter for _ in clients]
    if intrinsic_cumulative_result is not None:
        method_adapters["Intrinsic-Cumulative-Lift"] = [
            intrinsic_cumulative_result.effective_adapter for _ in clients
        ]
        if args.report_fedsmooth_rank_matched:
            method_adapters["Intrinsic-Cumulative-Lift-RankMatched"] = [
                intrinsic_cumulative_result.rank_matched_adapter for _ in clients
            ]
    if lorafair_result is not None:
        method_adapters["LoRA-FAIR"] = [lorafair_result.global_adapter for _ in clients]
    if telora_result is not None:
        method_adapters["Te-LoRA-Eq6-Audit"] = [telora_result.global_adapter for _ in clients]
    if subspace_reg_result is not None:
        method_adapters["Subspace-Reg-LoRA-Visual-Port"] = [
            subspace_reg_result.global_adapter for _ in clients
        ]
    if dysco_result is not None:
        method_adapters["Dysco-FrozenFeature-Visual-Port"] = dysco_result.client_adapters
    if cumulative_action_result is not None:
        method_adapters["FedAdapterManifold-CumulativeAdmit"] = cumulative_action_result.client_adapters
    if cumulative_full_gate_result is not None:
        method_adapters["CumulativeFull-Gate-Control"] = cumulative_full_gate_result.client_adapters
    if cumulative_screened_action_result is not None:
        method_adapters["FedAdapterManifold-CumulativeScreenedAdmit"] = (
            cumulative_screened_action_result.client_adapters
        )
    if cumulative_screened_full_control_result is not None:
        method_adapters["CumulativeFull-ScreenedBudget-Control"] = (
            cumulative_screened_full_control_result.client_adapters
        )
    if cumulative_blockwise_action_result is not None:
        method_adapters["FedAdapterManifold-CumulativeBlockwiseAdmit"] = (
            cumulative_blockwise_action_result.client_adapters
        )
    if cumulative_blockwise_source_control_result is not None:
        method_adapters["CumulativeSelectedSource-Scalar-Control"] = (
            cumulative_blockwise_source_control_result.client_adapters
        )
    if cumulative_blockwise_joint_result is not None:
        method_adapters["FedAdapterManifold-CumulativeBlockwiseJointAdmit"] = (
            cumulative_blockwise_joint_result.client_adapters
        )
    if cumulative_blockwise_joint_full_control_result is not None:
        method_adapters["CumulativeFull-BlockwiseBudget-Control"] = (
            cumulative_blockwise_joint_full_control_result.client_adapters
        )
    if cumulative_competitive_action_result is not None:
        method_adapters["FedAdapterManifold-CumulativeCompetitiveAdmit"] = (
            cumulative_competitive_action_result.client_adapters
        )
    if cumulative_competitive_full_control_result is not None:
        method_adapters["CumulativeFull-CompetitiveBudget-Control"] = (
            cumulative_competitive_full_control_result.client_adapters
        )
    if cumulative_action_rank_matched_result is not None:
        method_adapters["FedAdapterManifold-CumulativeAdmit-RankMatched"] = (
            cumulative_action_rank_matched_result.client_adapters
        )
    if scaffold_result is not None:
        method_adapters["SCAFFOLD-LoRA"] = [scaffold_result.global_adapter for _ in clients]
    if pfedme_result is not None:
        method_adapters["pFedMe-LoRA"] = pfedme_result.personal_adapters
    if bank_result is not None:
        method_adapters["FedAdapterManifold"] = bank_result.client_adapters
    if fedper_fam_adapters is not None:
        method_adapters["FedPer-FAM"] = fedper_fam_adapters
    if fedper_fam_selective_adapters is not None:
        method_adapters["FedPer-FAM-Selective"] = fedper_fam_selective_adapters
    if ditto_fam_adapters is not None:
        method_adapters["Ditto-FAM"] = ditto_fam_adapters
    if ditto_fam_selective_adapters is not None:
        method_adapters["Ditto-FAM-Selective"] = ditto_fam_selective_adapters
    if fedper_residual_fam_adapters is not None:
        method_adapters["FedPer-ResidualFAM"] = fedper_residual_fam_adapters
    if ditto_residual_fam_adapters is not None:
        method_adapters["Ditto-ResidualFAM"] = ditto_residual_fam_adapters
    if client_route_bank_result is not None:
        method_adapters["FedAdapterManifold-ClientRoute"] = client_route_bank_result.client_adapters
    if selective_adapters is not None:
        method_adapters["FedAdapterManifold-Selective"] = selective_adapters
    if strong_selective_adapters is not None:
        method_adapters["FedAdapterManifold-StrongSelective"] = strong_selective_adapters
    if path_admission_result is not None:
        method_adapters["FedAdapterManifold-PathAdmit"] = path_admission_result.client_adapters
    if signed_tangent_result is not None:
        signed_result_name = str(
            signed_tangent_result.per_client_metrics[0]["method"]
            if signed_tangent_result.per_client_metrics
            else "FedAdapterManifold-SignedTangentAdmit"
        )
        method_adapters[signed_result_name] = signed_tangent_result.client_adapters
    risk_rows = _risk_metric_rows(per_client_rows, method_adapters, local_adapters, geometry.graph)
    claim_rows = build_single_run_claim_report(metrics_rows, risk_rows, idea_support_rows, statistical_rows)

    write_csv(output_dir / "metrics.csv", metrics_rows)
    write_csv(output_dir / "baseline_fidelity.csv", [item.as_row() for item in BASELINE_FIDELITY])
    write_csv(output_dir / "idea_support.csv", idea_support_rows)
    write_csv(output_dir / "claim_report.csv", claim_rows)
    write_csv(output_dir / "statistical_support.csv", statistical_rows)
    write_csv(output_dir / "per_client_metrics.csv", per_client_rows)
    write_csv(output_dir / "negative_transfer.csv", negative_transfer_rows)
    write_csv(output_dir / "negative_transfer_summary.csv", negative_transfer_summary_rows)
    write_csv(output_dir / "risk_metrics.csv", risk_rows)
    write_csv(output_dir / "subspace_metrics.csv", subspace_rows)
    write_csv(output_dir / "distance_diagnostics.csv", diagnostic.distance_rows)
    write_csv(output_dir / "adapter_incompatibility_calibration.csv", diagnostic.calibration_rows)
    write_csv(output_dir / "adapter_conflict.csv", pair_rows)
    write_csv(output_dir / "local_lora_vs_fedavg_lora_drop.csv", drop_rows)
    write_csv(output_dir / "local_generalization_gap.csv", generalization_rows)
    write_csv(output_dir / "adapter_bank_weights.csv", bank_rows)
    write_csv(output_dir / "adapter_bank_sample_routing.csv", sample_bank_rows)
    write_csv(output_dir / "fedper_fam_hybrid_selection.csv", fedper_fam_rows)
    write_csv(output_dir / "ditto_fam_hybrid_selection.csv", ditto_fam_rows)
    write_csv(output_dir / "anchor_residual_training.csv", fedper_residual_fam_rows + ditto_residual_fam_rows)
    write_csv(output_dir / "anchor_residual_action_fit.csv", anchor_residual_fit_rows)
    for anchor_name, result in anchor_residual_admission_results.items():
        prefix = anchor_name.lower()
        write_csv(output_dir / f"{prefix}_anchor_residual_admission.csv", result.admission_rows)
        write_csv(output_dir / f"{prefix}_anchor_residual_routing.csv", result.routing_rows)
    for anchor_name, result in anchor_residual_scalar_control_results.items():
        prefix = anchor_name.lower()
        write_csv(
            output_dir / f"{prefix}_anchor_residual_scalar_control_admission.csv",
            result.admission_rows,
        )
    write_csv(output_dir / "adapter_candidate_selection.csv", selective_rows)
    if path_admission_result is not None:
        write_csv(output_dir / "path_admission.csv", path_admission_result.admission_rows)
    if signed_tangent_result is not None:
        write_csv(output_dir / "signed_tangent_screen.csv", signed_tangent_screen_rows)
        write_csv(output_dir / "signed_tangent_admission.csv", signed_tangent_result.admission_rows)
    if decoupled_transport_result is not None:
        write_csv(output_dir / "decoupled_transport_admission.csv", decoupled_transport_result.admission_rows)
        write_csv(output_dir / "decoupled_transport_weights.csv", decoupled_transport_weight_rows)
    if cumulative_action_result is not None:
        write_csv(output_dir / "cumulative_action_admission.csv", cumulative_action_result.admission_rows)
        write_csv(output_dir / "cumulative_action_decomposition.csv", cumulative_action_decomposition_rows)
        write_csv(output_dir / "cumulative_semantic_weights.csv", cumulative_semantic_weight_rows)
    if cumulative_full_gate_result is not None:
        write_csv(output_dir / "cumulative_full_gate_control.csv", cumulative_full_gate_result.admission_rows)
    if cumulative_screened_action_result is not None:
        write_csv(output_dir / "cumulative_training_family_screen.csv", cumulative_screening_rows)
        write_csv(
            output_dir / "cumulative_screened_action_admission.csv",
            cumulative_screened_action_result.admission_rows,
        )
    if cumulative_screened_full_control_result is not None:
        write_csv(
            output_dir / "cumulative_screened_full_control.csv",
            cumulative_screened_full_control_result.admission_rows,
        )
    if cumulative_blockwise_action_result is not None:
        write_csv(output_dir / "cumulative_blockwise_training_fit.csv", cumulative_blockwise_fit_rows)
        write_csv(
            output_dir / "cumulative_blockwise_action_admission.csv",
            cumulative_blockwise_action_result.admission_rows,
        )
    if cumulative_blockwise_source_control_result is not None:
        write_csv(
            output_dir / "cumulative_blockwise_source_control.csv",
            cumulative_blockwise_source_control_result.admission_rows,
        )
    if cumulative_blockwise_joint_result is not None:
        write_csv(
            output_dir / "cumulative_blockwise_joint_admission.csv",
            cumulative_blockwise_joint_result.admission_rows,
        )
    if cumulative_blockwise_joint_full_control_result is not None:
        write_csv(
            output_dir / "cumulative_blockwise_joint_full_control.csv",
            cumulative_blockwise_joint_full_control_result.admission_rows,
        )
    if cumulative_competitive_action_result is not None:
        write_csv(
            output_dir / "cumulative_competitive_action_admission.csv",
            cumulative_competitive_action_result.admission_rows,
        )
    if cumulative_competitive_full_control_result is not None:
        write_csv(
            output_dir / "cumulative_competitive_full_control.csv",
            cumulative_competitive_full_control_result.admission_rows,
        )
    if cumulative_disagreement_route_result is not None:
        write_csv(
            output_dir / "cumulative_disagreement_route_admission.csv",
            cumulative_disagreement_route_result.admission_rows,
        )
        write_csv(
            output_dir / "cumulative_disagreement_routing.csv",
            cumulative_disagreement_route_result.routing_rows,
        )
    if cumulative_direct_anchor_route_result is not None:
        write_csv(
            output_dir / "cumulative_direct_anchor_route_admission.csv",
            cumulative_direct_anchor_route_result.admission_rows,
        )
        write_csv(
            output_dir / "cumulative_direct_anchor_routing.csv",
            cumulative_direct_anchor_route_result.routing_rows,
        )
    if cumulative_action_rank_matched_result is not None:
        write_csv(
            output_dir / "cumulative_action_rank_matched_admission.csv",
            cumulative_action_rank_matched_result.admission_rows,
        )
    write_csv(output_dir / "candidate_selector_calibration.csv", calibration_rows)
    write_csv(output_dir / "adapter_bank_k_selection.csv", bank_selection_rows)
    write_csv(output_dir / "adapter_graph_mixing.csv", graph_mix_rows)
    if semantic_admission_result is not None:
        write_csv(output_dir / "semantic_admission_weights.csv", semantic_admission_result.admission_rows)
        write_csv(output_dir / "semantic_admission_gates.csv", semantic_admission_result.final_gate_rows)
        write_csv(output_dir / "semantic_admission_history.csv", semantic_admission_result.round_history)
        if semantic_exact_certificate_rows:
            write_csv(
                output_dir / "semantic_admission_exact_certificate.csv",
                semantic_exact_certificate_rows,
            )
        if semantic_generator_screen_rows:
            write_csv(
                output_dir / "semantic_generator_training_screen.csv",
                semantic_generator_screen_rows,
            )
    write_csv(output_dir / "geometry_signal_roles.csv", _geometry_signal_role_rows(geometry))
    write_csv(output_dir / "local_training.csv", local_train_rows)
    write_csv(output_dir / "rank_allocation.csv", rank_rows)
    write_csv(output_dir / "local_lora_training_trace.csv", local_result.training_trace)
    write_csv(output_dir / "fedavg_lora_history.csv", fedavg_lora_result.round_history)
    write_csv(output_dir / "fedavg_lift_history.csv", fedavg_lift_result.round_history)
    write_csv(output_dir / "fedrot_lora_history.csv", fedrot_result.round_history)
    if fedex_result is not None:
        write_csv(output_dir / "fedex_lora_history.csv", fedex_result.round_history)
    if fedsa_result is not None:
        write_csv(output_dir / "fedsa_lora_history.csv", fedsa_result.round_history)
    if fedpissa_result is not None:
        write_csv(output_dir / "fedpissa_equation_port_history.csv", fedpissa_result.round_history)
    if fedlease_result is not None:
        write_csv(output_dir / "fedlease_official_port_history.csv", fedlease_result.round_history)
    if fedalt_result is not None:
        write_csv(output_dir / "fedalt_official_visual_port_history.csv", fedalt_result.round_history)
    if fedtree_result is not None:
        write_csv(output_dir / "fedtree_lora_visual_history.csv", fedtree_result.round_history)
    if hilora_result is not None:
        write_csv(output_dir / "hilora_visual_history.csv", hilora_result.round_history)
    if fedsmooth_result is not None:
        write_csv(output_dir / "fedsmooth_lora_history.csv", fedsmooth_result.round_history)
        np.save(output_dir / "fedsmooth_cumulative_delta.npy", fedsmooth_result.cumulative_base_delta)
        np.save(output_dir / "fedsmooth_rank_matched_delta.npy", fedsmooth_result.rank_matched_adapter.delta())
        np.save(
            output_dir / "fedsmooth_client_cumulative_deltas.npy",
            np.stack(fedsmooth_result.client_cumulative_deltas, axis=0),
        )
        np.save(
            output_dir / "fedsmooth_cumulative_projection_residual.npy",
            fedsmooth_result.cumulative_projection_residual,
        )
    if intrinsic_cumulative_result is not None:
        write_csv(output_dir / "intrinsic_cumulative_history.csv", intrinsic_cumulative_result.round_history)
        np.save(
            output_dir / "intrinsic_cumulative_delta.npy",
            intrinsic_cumulative_result.cumulative_base_delta,
        )
        np.save(
            output_dir / "intrinsic_cumulative_client_deltas.npy",
            np.stack(intrinsic_cumulative_result.client_cumulative_deltas, axis=0),
        )
        np.save(
            output_dir / "intrinsic_cumulative_projection_residual.npy",
            intrinsic_cumulative_result.cumulative_projection_residual,
        )
    if lorafair_result is not None:
        write_csv(output_dir / "lorafair_history.csv", lorafair_result.round_history)
    if telora_result is not None:
        write_csv(output_dir / "telora_history.csv", telora_result.round_history)
    if subspace_reg_result is not None:
        write_csv(output_dir / "subspace_reg_lora_history.csv", subspace_reg_result.round_history)
    if dysco_result is not None:
        write_csv(output_dir / "dysco_visual_port_history.csv", dysco_result.round_history)
    write_csv(output_dir / "fedprox_lora_history.csv", fedprox_result.round_history)
    if scaffold_result is not None:
        write_csv(output_dir / "scaffold_lora_history.csv", scaffold_result.round_history)
    write_csv(output_dir / "ditto_lora_history.csv", ditto_result.round_history)
    if pfedme_result is not None:
        write_csv(output_dir / "pfedme_lora_history.csv", pfedme_result.round_history)

    labels = [c.domain for c in clients]
    save_heatmap(d_sub, labels, figures_dir / "subspace_angle_heatmap.png", "Adapter subspace distance")
    save_scatter(
        np.asarray(failure_x),
        np.asarray(failure_y),
        figures_dir / "subspace_distance_vs_aggregation_failure.png",
        "Subspace distance vs pairwise aggregation failure",
        "d_sub(i,j)",
        "Local-LoRA accuracy drop after pair averaging",
        caption=f"Pearson r={diagnostic.pearson_r:.3f}",
    )
    save_scatter(
        np.asarray(diagnostic.incompatibility_failure_x),
        np.asarray(failure_y),
        figures_dir / "adapter_incompatibility_vs_aggregation_failure.png",
        "Dynamically calibrated adapter incompatibility vs aggregation failure",
        "d_adapter_incompatibility(i,j)",
        "Local-LoRA accuracy drop after pair averaging",
        caption=f"Pearson r={diagnostic.incompatibility_pearson_r:.3f}; threshold={args.diagnostic_threshold:.3f}",
    )
    save_scatter(
        np.asarray(diagnostic.incompatibility_failure_x),
        np.asarray(diagnostic.receiver_residual_failure_y),
        figures_dir / "adapter_incompatibility_vs_receiver_residual_failure.png",
        "Adapter incompatibility vs receiver-normalized aggregation failure",
        "d_adapter_incompatibility(i,j)",
        "Excess pair-averaging accuracy drop",
        caption=f"Pearson r={diagnostic.incompatibility_receiver_residual_pearson_r:.3f}",
    )
    save_scatter(
        np.asarray(update_failure_x),
        np.asarray(failure_y),
        figures_dir / "update_distance_vs_aggregation_failure.png",
        "Normalized update distance vs pairwise aggregation failure",
        "d_update(i,j)",
        "Local-LoRA accuracy drop after pair averaging",
        caption=f"Pearson r={diagnostic.update_pearson_r:.3f}",
    )
    save_scatter(
        np.asarray([float(row["d_action"]) for row in pair_rows]),
        np.asarray([float(row["semantic_exact_loss_failure"]) for row in pair_rows]),
        figures_dir / "action_distance_vs_semantic_loss_failure.png",
        "Action-space distance vs exact-update semantic failure",
        "Receiver Fisher action distance",
        "Loss increase after exact full-update averaging",
        caption=f"Pearson r={diagnostic.action_semantic_loss_pearson_r:.3f}",
    )
    save_scatter(
        np.asarray([float(row["d_local_risk"]) for row in pair_rows]),
        np.asarray([float(row["semantic_exact_loss_failure"]) for row in pair_rows]),
        figures_dir / "local_risk_surrogate_vs_semantic_loss_failure.png",
        "Local risk surrogate vs exact-update semantic failure",
        "Positive local Taylor risk for exact midpoint",
        "Loss increase after exact full-update averaging",
        caption=f"Pearson r={diagnostic.local_risk_semantic_loss_pearson_r:.3f}",
    )
    save_scatter(
        np.asarray([float(row["d_geo"]) for row in pair_rows]),
        np.asarray(failure_y),
        figures_dir / "geometry_distance_vs_aggregation_failure.png",
        "Prototype/FedGeo distance vs pairwise aggregation failure",
        "d_geo(i,j)",
        "Local-LoRA accuracy drop after pair averaging",
        caption=f"Pearson r={diagnostic.geo_pearson_r:.3f}",
    )
    geo_x = []
    sub_y = []
    for i in range(len(clients)):
        for j in range(i + 1, len(clients)):
            geo_x.append(float(geometry.d_geo[i, j]))
            sub_y.append(float(d_sub[i, j]))
    save_scatter(
        np.asarray(geo_x),
        np.asarray(sub_y),
        figures_dir / "prototype_distance_vs_subspace_distance.png",
        "Prototype/FedGeo distance vs adapter subspace distance",
        "d_geo(i,j)",
        "d_sub(i,j)",
        caption=f"Geometry provider: {geometry.provider}",
    )
    if bank_result is not None:
        save_routing_heatmap(bank_result.bank.routing_weights, labels, figures_dir / "adapter_bank_routing.png")
    else:
        save_routing_heatmap(np.zeros((len(clients), 1)), labels, figures_dir / "adapter_bank_routing.png")

    _write_report(
        output_dir,
        args,
        diagnostic_r,
        diagnostic.pearson_r,
        diagnostic.update_pearson_r,
        diagnostic.geo_pearson_r,
        diagnostic.label_pearson_r,
        diagnostic.combined_pearson_r,
        diagnostic.distance_rows,
        diagnostic_passed,
        geometry.provider,
        bank_result is not None,
        class_names,
    )
    return 0 if diagnostic_passed or args.continue_on_failed_diagnostic else 2


def _load_clients(args):
    if args.dataset in {"synthetic", "pacs-debug", "cifar10-debug"}:
        num_classes = 10 if args.dataset == "cifar10-debug" else args.num_classes
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=args.num_clients,
            num_classes=num_classes,
            feature_dim=args.feature_dim,
            train_per_client=args.train_per_client,
            test_per_client=args.test_per_client,
            rank=args.rank,
            seed=args.seed,
        )
        class_names = [f"class_{i}" for i in range(num_classes)]
        return clients, base_weight, class_names
    if args.dataset == "cifar10":
        return load_cifar10_clients(
            args.data_root,
            num_clients=args.num_clients,
            dirichlet_alpha=args.dirichlet_alpha,
            min_train_size=args.min_train_size,
            train_per_client=args.train_per_client,
            test_per_client=args.test_per_client,
            align_test_with_train=args.align_test_with_train,
            seed=args.seed,
        )
    if args.dataset == "medmnist-npz":
        return load_medmnist_npz_clients(
            args.data_root,
            num_clients=args.num_clients,
            dirichlet_alpha=args.dirichlet_alpha,
            min_train_size=args.min_train_size,
            train_per_client=args.train_per_client,
            test_per_client=args.test_per_client,
            align_test_with_train=args.align_test_with_train,
            seed=args.seed,
            feature_cache_dir=args.feature_cache_dir,
            feature_backbone=args.feature_backbone,
        )
    clients, base_weight, class_names = load_image_folder_clients(
        args.data_root,
        domains=_parse_domains(args.domains),
        feature_backbone=args.feature_backbone,
        feature_cache_dir=args.feature_cache_dir,
        base_head_init=args.base_head_init,
        base_head_scale=args.base_head_scale,
        class_prompt_template=args.class_prompt_template,
        device="cpu" if args.cpu_debug else args.device,
        test_fraction=args.test_fraction,
        seed=args.seed,
        train_per_client=args.train_per_client,
        test_per_client=args.test_per_client,
    )
    return clients, base_weight, class_names


def _split_clients_for_candidate_selection(clients, fraction: float, strategy: str = "random", seed: int = 0):
    """Reserve a local calibration subset for candidate selection.

    Training and diagnostics use the returned training clients.  The final
    selector uses the calibration clients through the same x_train/y_train
    fields, so downstream selector code stays protocol-compatible while avoiding
    test-set model selection.
    """

    fraction = float(np.clip(fraction, 0.0, 0.95))
    strategy = str(strategy or "random").lower()
    rows = []
    if fraction <= 0.0:
        for client in clients:
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "candidate_selector_calibration_fraction": 0.0,
                    "train_samples_for_adapter_training": int(client.y_train.shape[0]),
                    "calibration_samples_for_selector": int(client.y_train.shape[0]),
                    "selector_split": "train",
                    "selector_split_strategy": str(strategy or "random").lower(),
                }
            )
        return clients, clients, rows
    rng = np.random.default_rng(int(seed) + 4242)
    train_clients = []
    selector_clients = []
    for client_idx, client in enumerate(clients):
        n = int(client.y_train.shape[0])
        if n < 2:
            train_clients.append(client)
            selector_clients.append(client)
            cal_size = n
            train_size = n
        else:
            cal_size = int(round(n * fraction))
            cal_size = int(min(n - 1, max(1, cal_size)))
            if strategy == "stratified":
                cal_idx = _stratified_calibration_indices(client.y_train, cal_size, rng)
                mask = np.ones(n, dtype=bool)
                mask[cal_idx] = False
                train_idx = np.flatnonzero(mask)
            else:
                order = rng.permutation(n)
                cal_idx = np.sort(order[:cal_size])
                train_idx = np.sort(order[cal_size:])
            train_size = int(train_idx.size)
            train_clients.append(
                client.__class__(
                    client_id=client.client_id,
                    domain=client.domain,
                    x_train=client.x_train[train_idx],
                    y_train=client.y_train[train_idx],
                    x_test=client.x_test,
                    y_test=client.y_test,
                )
            )
            selector_clients.append(
                client.__class__(
                    client_id=client.client_id,
                    domain=client.domain,
                    x_train=client.x_train[cal_idx],
                    y_train=client.y_train[cal_idx],
                    x_test=client.x_test,
                    y_test=client.y_test,
                )
            )
        rows.append(
            {
                "client_id": client.client_id,
                "domain": client.domain,
                "candidate_selector_calibration_fraction": fraction,
                "train_samples_for_adapter_training": train_size,
                "calibration_samples_for_selector": cal_size,
                "selector_split": "heldout_calibration",
                "selector_split_strategy": strategy,
                "calibration_seed": int(seed) + 4242 + client_idx,
            }
        )
    return train_clients, selector_clients, rows


def _stratified_calibration_indices(labels, cal_size: int, rng: np.random.Generator) -> np.ndarray:
    labels = np.asarray(labels)
    n = int(labels.shape[0])
    cal_size = int(min(max(cal_size, 1), max(n - 1, 1)))
    classes, counts = np.unique(labels, return_counts=True)
    if classes.size <= 1:
        return np.sort(rng.choice(n, size=cal_size, replace=False))

    raw = counts.astype(np.float64) * (cal_size / max(float(n), 1.0))
    quotas = np.floor(raw).astype(int)
    remainders = raw - quotas

    if cal_size >= classes.size:
        quotas = np.maximum(quotas, 1)
    while int(quotas.sum()) > cal_size:
        candidates = np.flatnonzero(quotas > 0)
        if candidates.size == 0:
            break
        drop = candidates[np.argmin(remainders[candidates])]
        quotas[drop] -= 1
    while int(quotas.sum()) < cal_size:
        candidates = np.flatnonzero(quotas < counts)
        if candidates.size == 0:
            break
        add = candidates[np.argmax(remainders[candidates])]
        quotas[add] += 1

    selected: list[int] = []
    for cls, quota in zip(classes, quotas):
        quota = int(min(max(quota, 0), counts[classes == cls][0]))
        if quota <= 0:
            continue
        idx = np.flatnonzero(labels == cls)
        selected.extend(rng.choice(idx, size=quota, replace=False).tolist())
    if len(selected) < cal_size:
        remaining = np.setdiff1d(np.arange(n), np.asarray(selected, dtype=int), assume_unique=False)
        fill = rng.choice(remaining, size=cal_size - len(selected), replace=False)
        selected.extend(fill.tolist())
    if len(selected) > cal_size:
        selected = rng.choice(np.asarray(selected, dtype=int), size=cal_size, replace=False).tolist()
    return np.sort(np.asarray(selected, dtype=int))


def _apply_geometry_ablation(geometry, mode: str, seed: int):
    """Apply a declared pre-training geometry intervention."""

    mode = str(mode or "provider").lower()
    if mode == "provider":
        return geometry
    n = len(geometry.client_ids)
    if mode == "no-geometry":
        graph = np.ones((n, n), dtype=np.float64)
        np.fill_diagonal(graph, 0.0)
        return replace(
            geometry,
            d_geo=np.zeros((n, n), dtype=np.float64),
            graph=graph,
            provider=f"{geometry.provider}:no-geometry",
        )
    if mode == "self-only":
        return replace(
            geometry,
            d_geo=np.zeros((n, n), dtype=np.float64),
            graph=np.zeros((n, n), dtype=np.float64),
            provider=f"{geometry.provider}:self-only",
        )
    if mode == "shuffled-geometry":
        rng = np.random.default_rng(int(seed) + 18041)
        permutation = rng.permutation(n)
        return replace(
            geometry,
            d_geo=np.asarray(geometry.d_geo, dtype=np.float64)[np.ix_(permutation, permutation)],
            graph=np.asarray(geometry.graph, dtype=np.float64)[np.ix_(permutation, permutation)],
            provider=f"{geometry.provider}:shuffled-geometry",
        )
    raise ValueError(f"Unknown geometry ablation mode: {mode}")


def _manifold_distance_matrix(
    components: str,
    d_sub,
    d_geo,
    d_label,
    lambda_geo: float,
    lambda_label: float,
):
    d_sub = np.asarray(d_sub, dtype=np.float64)
    d_geo = np.asarray(d_geo, dtype=np.float64)
    d_label = np.asarray(d_label, dtype=np.float64)
    if d_sub.shape != d_geo.shape or d_sub.shape != d_label.shape:
        raise ValueError(f"Distance shapes must match: d_sub={d_sub.shape}, d_geo={d_geo.shape}, d_label={d_label.shape}")
    zeros = np.zeros_like(d_sub, dtype=np.float64)
    geo = float(lambda_geo) * d_geo
    label = float(lambda_label) * d_label
    mapping = {
        "all": d_sub + geo + label,
        "d_sub": d_sub,
        "d_geo": geo,
        "d_label": label,
        "d_sub_d_geo": d_sub + geo,
        "d_sub_d_label": d_sub + label,
        "d_geo_d_label": geo + label,
    }
    if components not in mapping:
        raise ValueError(f"Unknown manifold_distance_components: {components}")
    out = np.asarray(mapping.get(components, zeros), dtype=np.float64).copy()
    np.fill_diagonal(out, 0.0)
    return out


def _compatibility_from_distance(distance, tau: float):
    distance = np.asarray(distance, dtype=np.float64)
    tau = max(float(tau), 1e-8)
    compat = np.exp(-distance / tau)
    np.fill_diagonal(compat, 1.0)
    return compat


def _effective_data_config(clients, base_weight, class_names):
    domains = [str(client.domain) for client in clients]
    train_sizes = [int(client.x_train.shape[0]) for client in clients]
    test_sizes = [int(client.x_test.shape[0]) for client in clients]
    return {
        "effective_num_clients": len(clients),
        "effective_num_classes": int(base_weight.shape[0]),
        "effective_feature_dim": int(base_weight.shape[1]),
        "effective_base_head_norm": float(np.linalg.norm(base_weight)),
        "effective_client_domains": ",".join(domains),
        "effective_class_names": ",".join(str(name) for name in class_names),
        "effective_train_samples_per_client": ",".join(str(size) for size in train_sizes),
        "effective_test_samples_per_client": ",".join(str(size) for size in test_sizes),
    }


def _parse_domains(value):
    if value in {"", None}:
        return None
    if isinstance(value, (list, tuple)):
        return [str(part).strip() for part in value if str(part).strip()]
    return [part.strip() for part in str(value).split(",") if part.strip()]


def _drop_rows(clients, base_weight, local_adapters, fedavg_adapter):
    rows = []
    for idx, client in enumerate(clients):
        local = evaluate_adapter(client.x_test, client.y_test, base_weight, local_adapters[idx])
        fedavg = evaluate_adapter(client.x_test, client.y_test, base_weight, fedavg_adapter)
        rows.append(
            {
                "client_id": client.client_id,
                "domain": client.domain,
                "local_lora_accuracy": local["accuracy"],
                "fedavg_lora_accuracy": fedavg["accuracy"],
                "drop": local["accuracy"] - fedavg["accuracy"],
            }
        )
    return rows


def _add_heterogeneity_alias(rows):
    for row in rows:
        if "heterogeneity" not in row and "heterogeneity_setting" in row:
            row["heterogeneity"] = row["heterogeneity_setting"]


def _bank_assignments(combined_distance, k):
    from .aggregation import k_medoids

    return k_medoids(combined_distance, k)


def _fixed_bank_selection_rows(combined_distance, selected_k):
    _, rows = select_adapter_bank_k(
        combined_distance,
        max_k=min(4, np.asarray(combined_distance).shape[0]),
    )
    for row in rows:
        row["selected"] = int(row["candidate_k"]) == int(selected_k)
        row["selection_mode"] = "fixed"
    return rows


def _select_adapter_graph(graph, mode: str, seed: int = 0):
    graph = np.asarray(graph, dtype=np.float64)
    if mode == "fedgeo":
        return graph
    if mode == "complete":
        return np.ones_like(graph, dtype=np.float64) - np.eye(graph.shape[0], dtype=np.float64)
    if mode == "self":
        return np.zeros_like(graph, dtype=np.float64)
    if mode == "random":
        return _random_graph_control(graph, seed=seed)
    raise ValueError(f"Unknown adapter_graph_mode: {mode}")


def _random_graph_control(graph: np.ndarray, seed: int = 0) -> np.ndarray:
    """Build a deterministic random graph preserving edge count and weights."""

    graph = np.asarray(graph, dtype=np.float64)
    n = int(graph.shape[0])
    if n <= 1:
        return np.zeros_like(graph, dtype=np.float64)
    upper = np.triu_indices(n, k=1)
    upper_weights = np.maximum(graph[upper], graph.T[upper])
    positive_weights = upper_weights[upper_weights > 0.0]
    if positive_weights.size == 0:
        return np.zeros_like(graph, dtype=np.float64)
    rng = np.random.default_rng(int(seed) + 7919)
    edge_count = int(min(positive_weights.size, len(upper[0])))
    chosen = rng.choice(len(upper[0]), size=edge_count, replace=False)
    shuffled_weights = np.asarray(positive_weights, dtype=np.float64).copy()
    rng.shuffle(shuffled_weights)
    out = np.zeros_like(graph, dtype=np.float64)
    for idx, weight in zip(chosen, shuffled_weights[:edge_count]):
        i = int(upper[0][idx])
        j = int(upper[1][idx])
        out[i, j] = float(weight)
        out[j, i] = float(weight)
    return out


def _blend_fixed_graph_mix(local_adapters, graph_adapters, weight: float, ranks) -> list[LoRAAdapter]:
    rank_list = [int(rank) for rank in ranks]
    weight = float(np.clip(weight, 0.0, 1.0))
    adapters = []
    for idx, (local_adapter, graph_adapter) in enumerate(zip(local_adapters, graph_adapters)):
        delta = (1.0 - weight) * local_adapter.delta() + weight * graph_adapter.delta()
        adapters.append(
            LoRAAdapter.from_delta(
                delta,
                rank=rank_list[idx],
                alpha=float(rank_list[idx]),
                name=f"fixed_graphmix_client_{idx}",
            )
        )
    return adapters


def _select_fedper_fam_hybrid(
    *,
    selector_clients,
    eval_clients,
    base_weight,
    personal_adapters,
    fam_adapters,
    ranks,
    candidates: str,
    tolerance: float,
    policy: str,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    method: str,
    personal_source_method: str = "FedPer-LoRA",
):
    """Blend a personalized adapter branch with the learned adapter manifold.

    A personal weight of 1.0 recovers the named personalized baseline and
    0.0 recovers Base FAM.
    Selection uses only the local train/calibration split carried by
    ``selector_clients``; final metrics are then evaluated on ``eval_clients``.
    """

    if isinstance(ranks, int):
        rank_list = [int(ranks) for _ in eval_clients]
    else:
        rank_list = [int(rank) for rank in ranks]
    candidate_values = _parse_unit_interval_candidates(candidates, default=[0.0, 0.25, 0.50, 0.75, 1.0])
    selected_adapters = []
    rows = []
    for idx, (selector_client, personal_adapter, fam_adapter) in enumerate(
        zip(selector_clients, personal_adapters, fam_adapters)
    ):
        losses = []
        adapters = []
        for candidate in candidate_values:
            personal_weight = float(candidate)
            delta = personal_weight * personal_adapter.delta() + (1.0 - personal_weight) * fam_adapter.delta()
            adapter = LoRAAdapter.from_delta(
                delta,
                rank=rank_list[idx],
                alpha=float(rank_list[idx]),
                name=f"fedper_fam_client_{idx}_p_{personal_weight:.2f}",
            )
            metrics = evaluate_adapter(selector_client.x_train, selector_client.y_train, base_weight, adapter)
            losses.append(float(metrics["loss"]))
            adapters.append(adapter)
        loss_array = np.asarray(losses, dtype=np.float64)
        best_idx = int(np.argmin(loss_array))
        if policy == "loss-constrained":
            allowed = float(loss_array[best_idx]) + max(0.0, float(tolerance))
            selected_idx = 0
            for candidate_idx, loss in enumerate(loss_array):
                if float(loss) <= allowed + 1e-12:
                    selected_idx = candidate_idx
        elif policy == "loss-min":
            selected_idx = best_idx
        elif policy == "personal-fallback":
            personal_idx = int(np.argmax(candidate_values))
            personal_loss = float(loss_array[personal_idx])
            if float(loss_array[best_idx]) <= personal_loss - max(0.0, float(tolerance)):
                selected_idx = best_idx
            else:
                selected_idx = personal_idx
        else:
            raise ValueError(f"Unknown FedPer-FAM policy: {policy}")
        selected_weight = float(candidate_values[selected_idx])
        selected_adapters.append(adapters[selected_idx])
        for candidate_idx, candidate in enumerate(candidate_values):
            rows.append(
                {
                    "client_id": selector_client.client_id,
                    "domain": selector_client.domain,
                    "method": method,
                    "selection_policy": policy,
                    "candidate_personal_weight": float(candidate),
                    "selected_personal_weight": selected_weight,
                    "candidate_selector_loss": float(loss_array[candidate_idx]),
                    "best_selector_loss": float(loss_array[best_idx]),
                    "fedper_fam_loss_tolerance": float(tolerance),
                    "selected": candidate_idx == selected_idx,
                    "interpretation": f"0=BaseFAM,1={personal_source_method}",
                }
            )
    per_client_metrics = evaluate_client_adapters(
        method,
        eval_clients,
        base_weight,
        selected_adapters,
        ranks=rank_list,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=round_id,
    )
    selected_by_client = {
        (row["client_id"], row["domain"]): row["selected_personal_weight"] for row in rows if row["selected"]
    }
    for row in per_client_metrics:
        row["source_method"] = f"{personal_source_method}+FedAdapterManifold"
        row["selected_personal_weight"] = selected_by_client.get((row["client_id"], row["domain"]), "")
        row["personalization_policy"] = policy
    return selected_adapters, per_client_metrics, rows


def _build_anchor_residual_families(
    *,
    fedper_result,
    ditto_result,
    fedtree_result,
    subspace_reg_result,
    num_clients: int,
):
    """Return predeclared anchors for receiver-residual composability audits.

    These anchors remain external to the canonical internal FAM bank.  Each
    audit freezes the named anchor before fitting a receiver-action residual,
    so a positive result measures incremental admissibility rather than
    test-time selection among unrelated methods.
    """

    families = {
        "FedPer": (
            "FedPer-LoRA",
            fedper_result.client_adapters,
            fedper_result.per_client_metrics,
        ),
        "Ditto": (
            "Ditto-LoRA",
            ditto_result.personal_adapters,
            ditto_result.per_client_metrics,
        ),
    }
    if fedtree_result is not None:
        families["FedTree"] = (
            "FedTreeLoRA-Visual-Port",
            fedtree_result.client_adapters,
            fedtree_result.per_client_metrics,
        )
    if subspace_reg_result is not None:
        # Subspace-Reg produces one global adapter.  Repeating that immutable
        # object per receiver preserves the published generator while the FAM
        # branch learns only a receiver-specific action residual.
        families["SubspaceReg"] = (
            "Subspace-Reg-LoRA-Visual-Port",
            [subspace_reg_result.global_adapter for _ in range(int(num_clients))],
            subspace_reg_result.per_client_metrics,
        )
    return families


def _train_anchor_residual_adapters(
    *,
    train_clients,
    eval_clients,
    base_weight,
    anchor_adapters,
    fam_adapters,
    ranks,
    epochs: int,
    lr: float,
    lr_scale: float,
    batch_size: int,
    residual_rank: int,
    validation_fraction: float,
    validation_strategy: str,
    shrinkage_candidates: str,
    seed: int,
    trainer_seed_offset: int = 0,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    method: str,
    anchor_source_method: str,
):
    """Train a residual FAM branch around a fixed personalized anchor.

    The residual update is optimized on the client training split only:

        W_i = W_0 + Delta_anchor_i + Delta_residual_i.

    It is then re-expressed as one LoRA update relative to W_0 so the normal
    candidate selector can compare it against the fixed anchor on held-out
    calibration data.  This branch is intentionally opt-in because it adds
    local compute; with epochs <= 0 it is never constructed.
    """

    epochs = int(max(0, epochs))
    if epochs <= 0:
        return None, [], []
    if isinstance(ranks, int):
        rank_list = [int(ranks) for _ in eval_clients]
    else:
        rank_list = [int(rank) for rank in ranks]
    residual_rank = int(residual_rank)
    lr_eff = float(max(1e-12, lr * lr_scale))
    selected_adapters = []
    rows = []
    for idx, (train_client, anchor_adapter, fam_adapter) in enumerate(
        zip(train_clients, anchor_adapters, fam_adapters)
    ):
        final_rank = rank_list[idx]
        train_rank = final_rank if residual_rank <= 0 else residual_rank
        anchor_delta = anchor_adapter.delta()
        fam_delta = fam_adapter.delta()
        shifted_base = np.asarray(base_weight, dtype=np.float64) + anchor_delta
        residual_init = LoRAAdapter.from_delta(
            fam_delta - anchor_delta,
            rank=train_rank,
            alpha=float(train_rank),
            name=f"{method.lower()}_{idx}_init_residual",
        )
        anchor_metrics = evaluate_adapter(train_client.x_train, train_client.y_train, base_weight, anchor_adapter)
        fam_metrics = evaluate_adapter(train_client.x_train, train_client.y_train, base_weight, fam_adapter)
        (
            residual_adapter,
            residual_trace,
            selected_epoch,
            residual_validation_loss,
            residual_validation_accuracy,
            selected_residual_shrinkage,
            anchor_internal_validation_loss,
            selected_shrinkage_validation_loss,
        ) = _fit_residual_with_optional_validation(
            train_client.x_train,
            train_client.y_train,
            shifted_base,
            residual_init,
            rank=train_rank,
            epochs=epochs,
            lr=lr_eff,
            batch_size=batch_size,
            validation_fraction=validation_fraction,
            validation_strategy=validation_strategy,
            shrinkage_candidates=shrinkage_candidates,
            seed=seed + int(trainer_seed_offset) + 9100 + idx,
            name=f"{method.lower()}_{idx}_residual",
        )
        final_delta = anchor_delta + residual_adapter.delta()
        final_adapter = LoRAAdapter.from_delta(
            final_delta,
            rank=final_rank,
            alpha=float(final_rank),
            name=f"{method.lower()}_{idx}",
        )
        final_train_metrics = evaluate_adapter(
            train_client.x_train,
            train_client.y_train,
            base_weight,
            final_adapter,
        )
        initial_residual_metrics = evaluate_adapter(
            train_client.x_train,
            train_client.y_train,
            shifted_base,
            residual_init,
        )
        final_residual_metrics = evaluate_adapter(
            train_client.x_train,
            train_client.y_train,
            shifted_base,
            residual_adapter,
        )
        selected_adapters.append(final_adapter)
        rows.append(
            {
                "client_id": train_client.client_id,
                "domain": train_client.domain,
                "method": method,
                "seed": int(seed),
                "method_seed": int(seed) + int(trainer_seed_offset),
                "anchor_source_method": anchor_source_method,
                "residual_epochs": epochs,
                "residual_lr": lr_eff,
                "residual_rank": train_rank,
                "residual_validation_fraction": float(validation_fraction),
                "residual_validation_strategy": str(validation_strategy),
                "selected_residual_epoch": int(selected_epoch),
                "selected_residual_shrinkage": float(selected_residual_shrinkage),
                "final_rank": final_rank,
                "anchor_train_loss": float(anchor_metrics["loss"]),
                "fam_train_loss": float(fam_metrics["loss"]),
                "initial_residual_train_loss": float(initial_residual_metrics["loss"]),
                "final_residual_train_loss": float(final_residual_metrics["loss"]),
                "best_residual_validation_loss": float(residual_validation_loss),
                "anchor_internal_validation_loss": float(anchor_internal_validation_loss),
                "selected_shrinkage_validation_loss": float(selected_shrinkage_validation_loss),
                "final_combined_train_loss": float(final_train_metrics["loss"]),
                "anchor_train_accuracy": float(anchor_metrics["accuracy"]),
                "fam_train_accuracy": float(fam_metrics["accuracy"]),
                "initial_residual_train_accuracy": float(initial_residual_metrics["accuracy"]),
                "final_residual_train_accuracy": float(final_residual_metrics["accuracy"]),
                "best_residual_validation_accuracy": float(residual_validation_accuracy),
                "final_combined_train_accuracy": float(final_train_metrics["accuracy"]),
                "anchor_delta_norm": float(np.linalg.norm(anchor_delta)),
                "fam_delta_norm": float(np.linalg.norm(fam_delta)),
                "initial_residual_delta_norm": float(np.linalg.norm(residual_init.delta())),
                "final_residual_delta_norm": float(np.linalg.norm(residual_adapter.delta())),
                "final_delta_norm": float(np.linalg.norm(final_adapter.delta())),
                "loss_history": residual_trace,
            }
        )
    per_client_metrics = evaluate_client_adapters(
        method,
        eval_clients,
        base_weight,
        selected_adapters,
        ranks=rank_list,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=round_id,
    )
    training_by_client = {(row["client_id"], row["domain"]): row for row in rows}
    for row in per_client_metrics:
        row["method_seed"] = int(seed) + int(trainer_seed_offset)
        row["source_method"] = f"{anchor_source_method}+ResidualFAM"
        row["anchor_source_method"] = anchor_source_method
        row["anchor_residual_epochs"] = epochs
        row["anchor_residual_lr"] = lr_eff
        row["anchor_residual_validation_fraction"] = float(validation_fraction)
        row["anchor_residual_validation_strategy"] = str(validation_strategy)
        train_row = training_by_client.get((row["client_id"], row["domain"]), {})
        row["anchor_train_loss"] = train_row.get("anchor_train_loss", "")
        row["final_combined_train_loss"] = train_row.get("final_combined_train_loss", "")
        row["selected_residual_shrinkage"] = train_row.get("selected_residual_shrinkage", "")
    return selected_adapters, per_client_metrics, rows


def _fit_residual_with_optional_validation(
    x,
    y,
    shifted_base,
    init_adapter: LoRAAdapter,
    *,
    rank: int,
    epochs: int,
    lr: float,
    batch_size: int,
    validation_fraction: float,
    validation_strategy: str,
    shrinkage_candidates: str,
    seed: int,
    name: str,
) -> tuple[LoRAAdapter, str, int, float, float, float, float, float]:
    """Train a residual adapter and optionally keep the best internal-val epoch."""

    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.int64)
    n = int(y.shape[0])
    validation_fraction = float(np.clip(validation_fraction, 0.0, 0.8))
    validation_strategy = str(validation_strategy or "random").lower()
    shrinkage_values = _parse_residual_shrinkage_candidates(shrinkage_candidates, default=[1.0])
    if validation_fraction <= 0.0 or n < 3 or epochs <= 1:
        adapter, stats = train_lora_adapter(
            x,
            y,
            shifted_base,
            rank=rank,
            init_adapter=init_adapter,
            epochs=epochs,
            lr=lr,
            batch_size=batch_size,
            seed=seed,
            name=name,
        )
        adapter, gamma, shrink_metrics = _select_residual_shrinkage(
            adapter,
            x,
            y,
            shifted_base,
            rank=rank,
            shrinkage_values=shrinkage_values,
            name=name,
        )
        trace = "|".join(f"{float(value):.8f}" for value in (stats.loss_history or []))
        return (
            adapter,
            trace,
            int(epochs),
            float(shrink_metrics["selected_loss"]),
            float(shrink_metrics["selected_accuracy"]),
            float(gamma),
            float(shrink_metrics["anchor_loss"]),
            float(shrink_metrics["selected_loss"]),
        )

    val_size = int(round(n * validation_fraction))
    val_size = int(min(n - 1, max(1, val_size)))
    rng = np.random.default_rng(seed + 137)
    if validation_strategy == "stratified":
        val_idx = _stratified_calibration_indices(y, val_size, rng)
        mask = np.ones(n, dtype=bool)
        mask[val_idx] = False
        fit_idx = np.flatnonzero(mask)
    else:
        order = rng.permutation(n)
        val_idx = np.sort(order[:val_size])
        fit_idx = np.sort(order[val_size:])
    if fit_idx.size == 0 or val_idx.size == 0:
        return _fit_residual_with_optional_validation(
            x,
            y,
            shifted_base,
            init_adapter,
            rank=rank,
            epochs=epochs,
            lr=lr,
            batch_size=batch_size,
            validation_fraction=0.0,
            validation_strategy=validation_strategy,
            shrinkage_candidates=shrinkage_candidates,
            seed=seed,
            name=name,
        )

    fit_x, fit_y = x[fit_idx], y[fit_idx]
    val_x, val_y = x[val_idx], y[val_idx]
    current = init_adapter.copy(name=f"{name}_epoch0")
    best = current.copy(name=f"{name}_best_epoch0")
    best_epoch = 0
    best_metrics = evaluate_adapter(val_x, val_y, shifted_base, best)
    trace_rows = [
        f"0:{float(evaluate_adapter(fit_x, fit_y, shifted_base, current)['loss']):.8f}:"
        f"{float(best_metrics['loss']):.8f}"
    ]
    for epoch in range(1, int(epochs) + 1):
        current, _ = train_lora_adapter(
            fit_x,
            fit_y,
            shifted_base,
            rank=rank,
            init_adapter=current,
            epochs=1,
            lr=lr,
            batch_size=batch_size,
            seed=seed + epoch,
            name=f"{name}_epoch{epoch}",
        )
        fit_metrics = evaluate_adapter(fit_x, fit_y, shifted_base, current)
        val_metrics = evaluate_adapter(val_x, val_y, shifted_base, current)
        trace_rows.append(f"{epoch}:{float(fit_metrics['loss']):.8f}:{float(val_metrics['loss']):.8f}")
        if float(val_metrics["loss"]) <= float(best_metrics["loss"]) + 1e-12:
            best = current.copy(name=f"{name}_best_epoch{epoch}")
            best_epoch = epoch
            best_metrics = val_metrics
    best, gamma, shrink_metrics = _select_residual_shrinkage(
        best,
        val_x,
        val_y,
        shifted_base,
        rank=rank,
        shrinkage_values=shrinkage_values,
        name=f"{name}_shrink",
    )
    selected_metrics = evaluate_adapter(val_x, val_y, shifted_base, best)
    return (
        best,
        "|".join(trace_rows),
        best_epoch,
        float(selected_metrics["loss"]),
        float(selected_metrics["accuracy"]),
        float(gamma),
        float(shrink_metrics["anchor_loss"]),
        float(shrink_metrics["selected_loss"]),
    )


def _select_residual_shrinkage(
    residual_adapter: LoRAAdapter,
    x,
    y,
    shifted_base,
    *,
    rank: int,
    shrinkage_values: list[float],
    name: str,
) -> tuple[LoRAAdapter, float, dict[str, float]]:
    """Select gamma in anchor + gamma * residual using an internal split."""

    if not shrinkage_values:
        shrinkage_values = [1.0]
    residual_delta = residual_adapter.delta()
    best_gamma = float(shrinkage_values[0])
    best_adapter = LoRAAdapter.from_delta(
        best_gamma * residual_delta,
        rank=rank,
        alpha=float(rank),
        name=f"{name}_gamma_{best_gamma:.2f}",
    )
    best_metrics = evaluate_adapter(x, y, shifted_base, best_adapter)
    anchor_adapter = LoRAAdapter.zeros(
        input_dim=residual_adapter.input_dim,
        output_dim=residual_adapter.output_dim,
        rank=rank,
        alpha=float(rank),
        name=f"{name}_gamma_0.00",
    )
    anchor_metrics = evaluate_adapter(x, y, shifted_base, anchor_adapter)
    for gamma in shrinkage_values[1:]:
        gamma = float(gamma)
        candidate = LoRAAdapter.from_delta(
            gamma * residual_delta,
            rank=rank,
            alpha=float(rank),
            name=f"{name}_gamma_{gamma:.2f}",
        )
        metrics = evaluate_adapter(x, y, shifted_base, candidate)
        if float(metrics["loss"]) <= float(best_metrics["loss"]) + 1e-12:
            best_gamma = gamma
            best_adapter = candidate
            best_metrics = metrics
    return best_adapter, best_gamma, {
        "anchor_loss": float(anchor_metrics["loss"]),
        "selected_loss": float(best_metrics["loss"]),
        "selected_accuracy": float(best_metrics["accuracy"]),
    }


def _parse_residual_shrinkage_candidates(value: str | None, default: list[float]) -> list[float]:
    if value is None or str(value).strip() == "":
        values = list(default)
    else:
        values = [float(part.strip()) for part in str(value).split(",") if part.strip()]
    values = sorted({float(np.clip(candidate, 0.0, 1.0)) for candidate in values})
    return values or list(default)


def _residual_shrinkage_candidate_pool(
    *,
    anchor_adapters,
    residual_adapters,
    ranks,
    candidates: str,
    prefix: str,
) -> dict[str, list[LoRAAdapter]]:
    """Export fixed gamma variants for held-out selector-side admission."""

    if not candidates or str(candidates).strip() == "":
        return {}
    gamma_values = _parse_residual_shrinkage_candidates(candidates, default=[])
    gamma_values = [gamma for gamma in gamma_values if 0.0 < float(gamma) < 1.0]
    if not gamma_values:
        return {}
    if isinstance(ranks, int):
        rank_list = [int(ranks) for _ in anchor_adapters]
    else:
        rank_list = [int(rank) for rank in ranks]
    out: dict[str, list[LoRAAdapter]] = {}
    for gamma in gamma_values:
        gamma = float(gamma)
        method_name = f"{prefix}-g{gamma:.2f}"
        adapters = []
        for idx, (anchor_adapter, residual_adapter) in enumerate(zip(anchor_adapters, residual_adapters)):
            anchor_delta = anchor_adapter.delta()
            residual_delta = residual_adapter.delta() - anchor_delta
            delta = anchor_delta + gamma * residual_delta
            rank = rank_list[idx]
            adapters.append(
                LoRAAdapter.from_delta(
                    delta,
                    rank=rank,
                    alpha=float(rank),
                    name=f"{method_name.lower()}_{idx}",
                )
            )
        out[method_name] = adapters
    return out


def _parse_unit_interval_candidates(value: str | None, default: list[float]) -> list[float]:
    if value is None or value == "":
        values = list(default)
    else:
        values = [float(part.strip()) for part in str(value).split(",") if part.strip()]
    values = sorted({float(np.clip(candidate, 0.0, 1.0)) for candidate in values})
    if not values or values[0] != 0.0:
        values.insert(0, 0.0)
    if values[-1] != 1.0:
        values.append(1.0)
    return values


def _selector_candidate_pool(
    *,
    scope: str,
    local_adapters,
    fedgeo_agg_adapters,
    subspace_adapters,
    bank_adapters,
):
    if scope == "adapter-only":
        return {"FedAdapterManifold": bank_adapters}
    return {
        "Local-LoRA": local_adapters,
        "FedGeo-Agg": fedgeo_agg_adapters,
        "Subspace-Compatible": subspace_adapters,
        "FedAdapterManifold": bank_adapters,
    }


def _selector_metric_pool(
    *,
    scope: str,
    local_metrics,
    fedgeo_agg_metrics,
    subspace_metrics,
    bank_metrics,
):
    if scope == "adapter-only":
        return {"FedAdapterManifold": bank_metrics}
    return {
        "Local-LoRA": local_metrics,
        "FedGeo-Agg": fedgeo_agg_metrics,
        "Subspace-Compatible": subspace_metrics,
        "FedAdapterManifold": bank_metrics,
    }


def _fixed_graph_mix_rows(clients, weight: float, policy: str) -> list[dict]:
    weight = float(np.clip(weight, 0.0, 1.0))
    return [
        {
            "client_id": client.client_id,
            "domain": client.domain,
            "adapter_graph_mix_policy": policy,
            "candidate_graph_mix_weight": weight,
            "selected_graph_mix_weight": weight,
            "candidate_graph_mix_loss": "",
            "best_graph_mix_loss": "",
            "adapter_graph_mix_tolerance": "",
            "selected": True,
        }
        for client in clients
    ]


def _select_client_candidate_adapters(
    clients,
    base_weight,
    candidates: dict[str, list],
    candidate_metrics: dict[str, list[dict]],
    ranks,
    graph,
    policy: str,
    manifold_prior: bool,
    loss_tolerance: float,
    loss_tolerance_ratio: float,
    neighbor_weight: float,
    softmax_tau: float,
    lcb_delta: float,
    anchor_priority: str | list[str] | None,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    method: str,
):
    """Select a safe positive-transfer adapter candidate without test leakage.

    The primary loss-min policy uses only declared training/calibration scores
    and an anchor-first candidate order. The legacy diagnostic-gated branch is
    retained for backward-compatible audit replay, but primary experiments pass
    ``manifold_prior=False`` so outcome summaries cannot affect selection.
    """

    if not candidates:
        return None, [], []
    if isinstance(ranks, int):
        rank_list = [int(ranks) for _ in clients]
    else:
        rank_list = [int(rank) for rank in ranks]
    selected_adapters = []
    selected_metrics = []
    rows = []
    ordered_candidates = list(candidates.items())
    metric_lookup = _candidate_metric_lookup(candidate_metrics)
    fixed_anchor_priority = _parse_selector_anchor_priority(anchor_priority)
    priority = [
        "Ditto-FAM-Selective",
        "Ditto-FAM",
        "FedPer-FAM-Selective",
        "FedPer-FAM",
        "FedAdapterManifold",
        "FedAdapterManifold-ClientRoute",
        "Subspace-Compatible",
        "FedPer-LoRA",
        "FedGeo-Agg",
        "Local-LoRA",
    ]
    priority_index = {name: idx for idx, name in enumerate(priority)}
    graph = np.asarray(graph, dtype=np.float64)
    neighbor_weight = float(np.clip(neighbor_weight, 0.0, 1.0))
    for idx, client in enumerate(clients):
        local_losses = []
        neighbor_losses = []
        scores = []
        neighbor_weights = _selector_neighbor_weights(graph, idx)
        for candidate_name, adapters in ordered_candidates:
            local_metrics = evaluate_adapter(client.x_train, client.y_train, base_weight, adapters[idx])
            local_loss = float(local_metrics["loss"])
            neighbor_loss = _selector_neighbor_loss(
                clients,
                base_weight,
                adapters[idx],
                neighbor_weights,
                fallback_loss=local_loss,
            )
            score = (1.0 - neighbor_weight) * local_loss + neighbor_weight * neighbor_loss
            local_losses.append(local_loss)
            neighbor_losses.append(neighbor_loss)
            scores.append(score)
        local_loss_array = np.asarray(local_losses, dtype=np.float64)
        neighbor_loss_array = np.asarray(neighbor_losses, dtype=np.float64)
        score_array = np.asarray(scores, dtype=np.float64)
        best_score = float(score_array.min())
        allowed_score = best_score + max(0.0, float(loss_tolerance)) + max(0.0, float(loss_tolerance_ratio)) * max(
            abs(best_score),
            1e-12,
        )
        if policy in {"anchored-no-regret", "anchored-diff-lcb"}:
            anchor_indices = [
                candidate_idx
                for candidate_idx, (candidate_name, _) in enumerate(ordered_candidates)
                if _selector_anchor_candidate(candidate_name)
            ]
            if not anchor_indices:
                anchor_indices = list(range(len(ordered_candidates)))
            manifold_indices = [
                candidate_idx
                for candidate_idx, (candidate_name, _) in enumerate(ordered_candidates)
                if not _selector_anchor_candidate(candidate_name)
            ]
            anchor_idx = _fixed_anchor_index(ordered_candidates, fixed_anchor_priority)
            if anchor_idx is None or anchor_idx not in anchor_indices:
                anchor_idx = min(anchor_indices, key=lambda candidate_idx: float(score_array[candidate_idx]))
            anchor_score = float(score_array[anchor_idx])
            penalty = _selector_lcb_penalty(len(client.y_train), len(ordered_candidates), lcb_delta)
            statistical_margin = penalty * max(abs(anchor_score), 1e-12)
            accept_margin = (
                max(0.0, float(loss_tolerance))
                + max(0.0, float(loss_tolerance_ratio)) * max(abs(anchor_score), 1e-12)
                + statistical_margin
            )
            if manifold_indices:
                best_manifold_idx = min(manifold_indices, key=lambda candidate_idx: float(score_array[candidate_idx]))
                best_manifold_score = float(score_array[best_manifold_idx])
                if policy == "anchored-diff-lcb":
                    diff_stats = _selector_loss_difference_stats(
                        client.x_train,
                        client.y_train,
                        base_weight,
                        ordered_candidates[anchor_idx][1][idx],
                        ordered_candidates[best_manifold_idx][1][idx],
                        delta=lcb_delta,
                    )
                    selected_idx = (
                        best_manifold_idx
                        if diff_stats["mean_diff"] + diff_stats["margin"] <= -max(0.0, float(loss_tolerance)) + 1e-12
                        else anchor_idx
                    )
                else:
                    diff_stats = {"mean_diff": float("nan"), "se": float("nan"), "margin": float("nan")}
                    selected_idx = (
                        best_manifold_idx
                        if best_manifold_score <= anchor_score - accept_margin + 1e-12
                        else anchor_idx
                    )
            else:
                best_manifold_idx = anchor_idx
                best_manifold_score = anchor_score
                diff_stats = {"mean_diff": 0.0, "se": 0.0, "margin": 0.0}
                selected_idx = anchor_idx
            selected_name, selected_source = ordered_candidates[selected_idx]
            selected_adapters.append(
                selected_source[idx].copy(name=f"{method.lower()}_{idx}_{selected_name.lower().replace('-', '_')}")
            )
            selected_metric = dict(metric_lookup.get((selected_name, str(client.client_id)), {}))
            if selected_metric:
                selected_metric["source_method"] = selected_name
                selected_metric["method"] = method
            else:
                metrics = evaluate_adapter(client.x_test, client.y_test, base_weight, selected_adapters[-1])
                selected_metric = {
                    "method": method,
                    "seed": seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_id,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "accuracy": metrics["accuracy"],
                    "loss": metrics["loss"],
                    "rank": rank_list[idx],
                    "source_method": selected_name,
                }
            selected_metrics.append(selected_metric)
            for candidate_idx, (candidate_name, _) in enumerate(ordered_candidates):
                rows.append(
                    {
                        "client_id": client.client_id,
                        "domain": client.domain,
                        "method": method,
                        "selector_policy": policy,
                        "manifold_prior_active": bool(manifold_prior),
                        "candidate_method": candidate_name,
                        "candidate_train_loss": float(local_loss_array[candidate_idx]),
                        "candidate_neighbor_loss": float(neighbor_loss_array[candidate_idx]),
                        "candidate_selector_score": float(score_array[candidate_idx]),
                        "best_selector_score": best_score,
                        "allowed_selector_score": float(anchor_score - accept_margin),
                        "anchor_method": ordered_candidates[anchor_idx][0],
                        "anchor_priority": ",".join(fixed_anchor_priority),
                        "anchor_selector_score": anchor_score,
                        "best_manifold_method": ordered_candidates[best_manifold_idx][0],
                        "best_manifold_selector_score": best_manifold_score,
                        "selector_statistical_margin": float(statistical_margin),
                        "selector_accept_margin": float(accept_margin),
                        "selector_diff_mean": float(diff_stats["mean_diff"]),
                        "selector_diff_se": float(diff_stats["se"]),
                        "selector_diff_margin": float(diff_stats["margin"]),
                        "best_train_loss": float(local_loss_array[selected_idx]),
                        "selector_loss_tolerance": float(loss_tolerance),
                        "selector_loss_tolerance_ratio": float(loss_tolerance_ratio),
                        "selector_neighbor_weight": float(neighbor_weight),
                        "selector_lcb_delta": float(lcb_delta),
                        "selector_lcb_penalty": float(penalty),
                        "selected_method": selected_name,
                        "selected": candidate_idx == selected_idx,
                    }
                )
            continue
        if policy in {"loss-softmax", "gibbs", "gibbs-lcb", "safe-gibbs", "safe-gibbs-lcb"}:
            penalty = _selector_lcb_penalty(len(client.y_train), len(ordered_candidates), lcb_delta)
            use_lcb = policy in {"gibbs-lcb", "safe-gibbs-lcb"}
            lcb_scores = score_array + (penalty if use_lcb else 0.0)
            if policy in {"safe-gibbs", "safe-gibbs-lcb"}:
                allowed_mask = score_array <= allowed_score + 1e-12
                if not bool(np.any(allowed_mask)):
                    allowed_mask[int(np.argmin(score_array))] = True
                masked_scores = np.where(allowed_mask, lcb_scores, np.inf)
                weights = _softmax_weights(-masked_scores, temperature=max(float(softmax_tau), 1e-12))
            else:
                allowed_mask = np.ones_like(score_array, dtype=bool)
                weights = _softmax_weights(-lcb_scores, temperature=max(float(softmax_tau), 1e-12))
            delta = np.zeros_like(ordered_candidates[0][1][idx].delta(), dtype=np.float64)
            for candidate_weight, (_, source) in zip(weights, ordered_candidates):
                delta += float(candidate_weight) * source[idx].delta()
            selected_adapter = LoRAAdapter.from_delta(
                delta,
                rank=rank_list[idx],
                alpha=float(rank_list[idx]),
                name=f"{method.lower()}_{idx}_gibbs_selector",
            )
            selected_idx = int(np.argmax(weights))
            selected_name = "GibbsMixture"
            selected_adapters.append(selected_adapter)
            metrics = evaluate_adapter(client.x_test, client.y_test, base_weight, selected_adapter)
            selected_metric = {
                "method": method,
                "seed": seed,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": round_id,
                "client_id": client.client_id,
                "domain": client.domain,
                "accuracy": metrics["accuracy"],
                "loss": metrics["loss"],
                "rank": rank_list[idx],
                "source_method": selected_name,
                "selector_softmax_tau": float(softmax_tau),
                "selector_lcb_penalty": float(penalty),
            }
            selected_metrics.append(selected_metric)
            for candidate_idx, (candidate_name, _) in enumerate(ordered_candidates):
                rows.append(
                    {
                        "client_id": client.client_id,
                        "domain": client.domain,
                        "method": method,
                        "selector_policy": policy,
                        "manifold_prior_active": bool(manifold_prior),
                        "candidate_method": candidate_name,
                        "candidate_train_loss": float(local_loss_array[candidate_idx]),
                        "candidate_neighbor_loss": float(neighbor_loss_array[candidate_idx]),
                        "candidate_selector_score": float(score_array[candidate_idx]),
                        "candidate_gibbs_weight": float(weights[candidate_idx]),
                        "candidate_in_safe_set": bool(allowed_mask[candidate_idx]),
                        "best_selector_score": best_score,
                        "allowed_selector_score": allowed_score,
                        "best_train_loss": float(local_loss_array[selected_idx]),
                        "selector_loss_tolerance": float(loss_tolerance),
                        "selector_loss_tolerance_ratio": float(loss_tolerance_ratio),
                        "selector_neighbor_weight": float(neighbor_weight),
                        "selector_softmax_tau": float(softmax_tau),
                        "selector_lcb_delta": float(lcb_delta),
                        "selector_lcb_penalty": float(penalty),
                        "selected_method": selected_name,
                        "selected": candidate_idx == selected_idx,
                    }
                )
            continue
        if policy == "diagnostic-gated" and manifold_prior:
            allowed = [
                candidate_idx
                for candidate_idx, score in enumerate(score_array)
                if float(score) <= allowed_score + 1e-12
            ]
            selected_idx = min(
                allowed,
                key=lambda candidate_idx: priority_index.get(ordered_candidates[candidate_idx][0], len(priority)),
            )
        elif policy == "loss-min":
            selected_idx = int(np.argmin(score_array))
        else:
            selected_idx = int(np.argmin(score_array))
        selected_name, selected_source = ordered_candidates[selected_idx]
        selected_adapters.append(
            selected_source[idx].copy(name=f"{method.lower()}_{idx}_{selected_name.lower().replace('-', '_')}")
        )
        selected_metric = dict(metric_lookup.get((selected_name, str(client.client_id)), {}))
        if selected_metric:
            selected_metric["source_method"] = selected_name
            selected_metric["method"] = method
        else:
            metrics = evaluate_adapter(client.x_test, client.y_test, base_weight, selected_adapters[-1])
            selected_metric = {
                "method": method,
                "seed": seed,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": round_id,
                "client_id": client.client_id,
                "domain": client.domain,
                "accuracy": metrics["accuracy"],
                "loss": metrics["loss"],
                "rank": rank_list[idx],
                "source_method": selected_name,
            }
        selected_metrics.append(selected_metric)
        for candidate_idx, (candidate_name, _) in enumerate(ordered_candidates):
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "method": method,
                    "selector_policy": policy,
                    "manifold_prior_active": bool(manifold_prior),
                    "candidate_method": candidate_name,
                    "candidate_train_loss": float(local_loss_array[candidate_idx]),
                    "candidate_neighbor_loss": float(neighbor_loss_array[candidate_idx]),
                    "candidate_selector_score": float(score_array[candidate_idx]),
                    "best_selector_score": best_score,
                    "allowed_selector_score": allowed_score,
                    "best_train_loss": float(local_loss_array[selected_idx]),
                    "selector_loss_tolerance": float(loss_tolerance),
                    "selector_loss_tolerance_ratio": float(loss_tolerance_ratio),
                    "selector_neighbor_weight": float(neighbor_weight),
                    "selected_method": selected_name,
                    "selected": candidate_idx == selected_idx,
                }
            )
    return selected_adapters, selected_metrics, rows


def _selector_lcb_penalty(num_samples: int, num_candidates: int, delta: float) -> float:
    num_samples = max(int(num_samples), 1)
    num_candidates = max(int(num_candidates), 1)
    delta = float(np.clip(delta, 1e-12, 1.0))
    return float(np.sqrt(np.log(2.0 * num_candidates / delta) / (2.0 * num_samples)))


def _selector_loss_difference_stats(
    x,
    y,
    base_weight,
    anchor_adapter,
    manifold_adapter,
    delta: float,
) -> dict[str, float]:
    anchor_losses = evaluate_adapter_loss_vector(x, y, base_weight, anchor_adapter)
    manifold_losses = evaluate_adapter_loss_vector(x, y, base_weight, manifold_adapter)
    diff = np.asarray(manifold_losses - anchor_losses, dtype=np.float64)
    diff = diff[np.isfinite(diff)]
    if diff.size == 0:
        return {"mean_diff": float("inf"), "se": float("inf"), "margin": float("inf")}
    mean_diff = float(np.mean(diff))
    if diff.size <= 1:
        se = float("inf")
    else:
        se = float(np.std(diff, ddof=1) / np.sqrt(float(diff.size)))
    delta = float(np.clip(delta, 1e-12, 1.0))
    margin = float(np.sqrt(2.0 * np.log(2.0 / delta)) * se) if np.isfinite(se) else float("inf")
    return {"mean_diff": mean_diff, "se": se, "margin": margin}


def _selector_anchor_candidate(candidate_name: str) -> bool:
    """Return whether a candidate is a conservative no-regret anchor.

    The anchor branch represents the strongest non-manifold option available
    before test evaluation.  A manifold candidate must beat this branch by a
    calibration margin before it is selected by the anchored no-regret policy.
    """

    name = str(candidate_name).lower()
    manifold_tokens = [
        "fedadaptermanifold",
        "fam",
        "subspace-compatible",
    ]
    return not any(token in name for token in manifold_tokens)


def _parse_selector_anchor_priority(priority: str | list[str] | None) -> list[str]:
    if priority is None:
        return []
    if isinstance(priority, str):
        return [part.strip() for part in priority.split(",") if part.strip()]
    return [str(part).strip() for part in priority if str(part).strip()]


def _fixed_anchor_index(ordered_candidates: list[tuple[str, list]], priority: list[str]) -> int | None:
    if not priority:
        return None
    name_to_idx = {str(name): idx for idx, (name, _) in enumerate(ordered_candidates)}
    lower_to_idx = {str(name).lower(): idx for idx, (name, _) in enumerate(ordered_candidates)}
    for name in priority:
        if name in name_to_idx:
            return int(name_to_idx[name])
        lower = name.lower()
        if lower in lower_to_idx:
            return int(lower_to_idx[lower])
    return None


def _softmax_weights(values: np.ndarray, temperature: float) -> np.ndarray:
    temperature = max(float(temperature), 1e-12)
    scaled = np.asarray(values, dtype=np.float64) / temperature
    scaled = scaled - float(np.max(scaled))
    weights = np.exp(scaled)
    total = float(weights.sum())
    if not np.isfinite(total) or total <= 0.0:
        return np.full_like(weights, 1.0 / max(weights.size, 1), dtype=np.float64)
    return weights / total


def _candidate_metric_lookup(candidate_metrics: dict[str, list[dict]]) -> dict[tuple[str, str], dict]:
    lookup = {}
    for method, rows in candidate_metrics.items():
        for row in rows:
            lookup[(method, str(row.get("client_id")))] = row
    return lookup


def _high_conflict_prior(local_rows, fedavg_rows, adapter_r: float, threshold: float) -> bool:
    local_acc = _mean_accuracy_from_rows(local_rows)
    fedavg_acc = _mean_accuracy_from_rows(fedavg_rows)
    return bool(np.isfinite(adapter_r) and adapter_r >= float(threshold) and local_acc > fedavg_acc)


def _mean_accuracy_from_rows(rows) -> float:
    values = [float(row["accuracy"]) for row in rows if "accuracy" in row]
    if not values:
        return float("nan")
    return float(np.mean(np.asarray(values, dtype=np.float64)))


def _selector_neighbor_weights(graph, idx: int):
    graph = np.asarray(graph, dtype=np.float64)
    if graph.ndim != 2 or idx >= graph.shape[0]:
        return np.zeros(0, dtype=np.float64)
    weights = graph[idx].astype(np.float64).copy()
    if idx < weights.size:
        weights[idx] = 0.0
    weights = np.maximum(weights, 0.0)
    total = float(weights.sum())
    if total <= 1e-12:
        return np.zeros_like(weights)
    return weights / total


def _selector_neighbor_loss(clients, base_weight, adapter, neighbor_weights, fallback_loss: float) -> float:
    if neighbor_weights.size == 0 or float(np.sum(neighbor_weights)) <= 1e-12:
        return float(fallback_loss)
    losses = []
    weights = []
    for neighbor_idx, weight in enumerate(neighbor_weights):
        if float(weight) <= 0.0 or neighbor_idx >= len(clients):
            continue
        client = clients[neighbor_idx]
        metrics = evaluate_adapter(client.x_train, client.y_train, base_weight, adapter)
        losses.append(float(metrics["loss"]))
        weights.append(float(weight))
    if not losses:
        return float(fallback_loss)
    return float(np.average(np.asarray(losses, dtype=np.float64), weights=np.asarray(weights, dtype=np.float64)))


def _idea_support_rows(metrics_rows, diagnostic_threshold):
    by_method = {row["method"]: row for row in metrics_rows}
    local = by_method.get("Local-LoRA")
    fedavg = by_method.get("FedAvg-LoRA")
    subspace = by_method.get("Subspace-Compatible")
    fedgeo_agg = by_method.get("FedGeo-Agg")
    bank = (
        by_method.get("FedAdapterManifold-Admit")
        or by_method.get("FedAdapterManifold-Selective")
        or by_method.get("FedAdapterManifold")
    )
    client_route = by_method.get("FedAdapterManifold-ClientRoute")
    if local is None or fedavg is None or subspace is None or bank is None:
        return []
    raw_adapter_r = float(
        fedavg.get(
            "raw_adapter_incompatibility_failure_pearson_r",
            fedavg.get("adapter_incompatibility_failure_pearson_r", float("nan")),
        )
    )
    controlled_adapter_r = float(
        fedavg.get(
            "receiver_residual_adapter_incompatibility_failure_pearson_r",
            raw_adapter_r,
        )
    )
    semantic_subspace_r = float(fedavg.get("subspace_semantic_loss_pearson_r", float("nan")))
    r_candidates = (
        [("exact_update_semantic_loss", semantic_subspace_r)]
        if np.isfinite(semantic_subspace_r)
        else [
            ("raw_directional", raw_adapter_r),
            ("receiver_residual", controlled_adapter_r),
        ]
    )
    finite_r_candidates = [(name, value) for name, value in r_candidates if np.isfinite(value)]
    if finite_r_candidates:
        primary_r_name, r_value = max(finite_r_candidates, key=lambda item: item[1])
    else:
        primary_r_name, r_value = "none", float("nan")
    raw_subspace_r = float(fedavg.get("raw_subspace_failure_pearson_r", fedavg.get("subspace_failure_pearson_r", float("nan"))))
    local_minus = float(local["mean_accuracy"]) - float(fedavg["mean_accuracy"])
    subspace_minus = float(subspace["mean_accuracy"]) - float(fedavg["mean_accuracy"])
    fedgeo_agg_minus = "" if fedgeo_agg is None else float(fedgeo_agg["mean_accuracy"]) - float(fedavg["mean_accuracy"])
    bank_minus = float(bank["mean_accuracy"]) - float(fedavg["mean_accuracy"])
    bank_minus_fedgeo_agg = "" if fedgeo_agg is None else float(bank["mean_accuracy"]) - float(fedgeo_agg["mean_accuracy"])
    client_route_minus = "" if client_route is None else float(client_route["mean_accuracy"]) - float(fedavg["mean_accuracy"])
    supports_vs_fedgeo_agg = (
        fedgeo_agg is not None
        and bank_minus_fedgeo_agg != ""
        and float(bank_minus_fedgeo_agg) > 0
    )
    fedgeo_gate = fedgeo_agg is None or bool(supports_vs_fedgeo_agg)
    supports = (
        np.isfinite(r_value)
        and r_value >= float(diagnostic_threshold)
        and local_minus > 0
        and bank_minus > 0
        and fedgeo_gate
    )
    return [
        {
            "supports_idea": bool(supports),
            "supports_vs_fedgeo_agg": bool(supports_vs_fedgeo_agg),
            "support_rule": "exact_update_subspace_semantic_loss_r>=threshold;local>fedavg;primary_admission>fedavg;primary_admission>geo_only_when_available",
            "subspace_compatible_is_gate": False,
            "primary_adapter_method": bank["method"],
            "primary_adapter_incompatibility_signal": primary_r_name,
            "adapter_incompatibility_failure_pearson_r": r_value,
            "raw_adapter_incompatibility_failure_pearson_r": raw_adapter_r,
            "receiver_residual_adapter_incompatibility_failure_pearson_r": controlled_adapter_r,
            "raw_subspace_failure_pearson_r": raw_subspace_r,
            "subspace_semantic_loss_pearson_r": semantic_subspace_r,
            "subspace_failure_pearson_r": r_value,
            "diagnostic_threshold": float(diagnostic_threshold),
            "local_minus_fedavg_lora": local_minus,
            "subspace_minus_fedavg_lora": subspace_minus,
            "fedgeo_agg_minus_fedavg_lora": fedgeo_agg_minus,
            "adapter_bank_minus_fedavg_lora": bank_minus,
            "adapter_bank_minus_fedgeo_agg": bank_minus_fedgeo_agg,
            "client_route_minus_fedavg_lora": client_route_minus,
        }
    ]


def _statistical_support_rows(per_client_rows, pair_rows, seed):
    rows = []
    rng = np.random.default_rng(int(seed) + 1701)
    pair_rows = _ensure_failure_control_fields(pair_rows)
    for distance_name in [
        "d_sub",
        "d_update",
        "d_action",
        "d_local_risk",
        "d_projection",
        "d_adapter_incompatibility",
        "d_geo",
        "d_combined",
        "d_label",
    ]:
        distance = np.asarray([float(row[distance_name]) for row in pair_rows], dtype=np.float64)
        for test_name, target_field in [
            ("distance_failure_correlation", "aggregation_failure"),
            ("distance_receiver_residual_failure_correlation", "receiver_residual_aggregation_failure"),
            ("distance_pair_mean_failure_correlation", "pair_mean_aggregation_failure"),
            ("distance_pair_max_failure_correlation", "pair_max_aggregation_failure"),
            ("distance_semantic_loss_correlation", "semantic_exact_loss_failure"),
            ("distance_semantic_accuracy_correlation", "semantic_exact_accuracy_failure"),
            ("distance_algebraic_loss_correlation", "algebraic_factor_loss_delta"),
        ]:
            failure = np.asarray([float(row[target_field]) for row in pair_rows], dtype=np.float64)
            estimate = _pearson_no_import(distance, failure)
            low, high = _bootstrap_stat(distance, failure, _pearson_no_import, rng)
            p_value = _permutation_corr_pvalue(distance, failure, estimate, rng)
            rows.append(
                {
                    "test": test_name,
                    "measure": distance_name,
                    "comparison": f"{distance_name}_vs_{target_field}",
                    "estimate": estimate,
                    "ci_low": low,
                    "ci_high": high,
                    "p_value": p_value,
                    "supports": bool(np.isfinite(estimate) and estimate > 0 and np.isfinite(low) and low > 0),
                }
            )

    by_method_client = {}
    for row in per_client_rows:
        by_method_client[(row["method"], row["client_id"])] = float(row["accuracy"])
    clients = sorted({row["client_id"] for row in per_client_rows})
    for method in [
        "Local-LoRA",
        "FedGeo-Diag",
        "FedGeo-Agg",
        "Subspace-Compatible",
        "FedAdapterManifold",
        "FedAdapterManifold-Admit",
        "FedAdapterManifold-ClientRoute",
        "FedAdapterManifold-Selective",
        "Ditto-FAM",
        "Ditto-FAM-Selective",
        "FedPer-FAM",
        "FedPer-FAM-Selective",
        "FedAdapterManifold-StrongSelective",
    ]:
        diffs = []
        for client_id in clients:
            key = (method, client_id)
            base = ("FedAvg-LoRA", client_id)
            if key in by_method_client and base in by_method_client:
                diffs.append(by_method_client[key] - by_method_client[base])
        if not diffs:
            continue
        diff_arr = np.asarray(diffs, dtype=np.float64)
        estimate = float(diff_arr.mean())
        low, high = _bootstrap_1d(diff_arr, rng)
        p_value = _sign_flip_pvalue(diff_arr)
        rows.append(
            {
                "test": "paired_accuracy_gain",
                "measure": "mean_accuracy_gain",
                "comparison": f"{method}_vs_FedAvg-LoRA",
                "estimate": estimate,
                "ci_low": low,
                "ci_high": high,
                "p_value": p_value,
                "supports": bool(estimate > 0 and low > 0),
            }
        )
    return rows


def _ensure_failure_control_fields(pair_rows):
    rows = [dict(row) for row in pair_rows]
    if not rows:
        return rows
    if all("receiver_residual_aggregation_failure" in row for row in rows):
        return rows
    by_receiver = {}
    by_pair = {}
    for row in rows:
        failure = float(row["aggregation_failure"])
        receiver_key = row["client_i"]
        pair_key = tuple(sorted((str(row["client_i"]), str(row["client_j"]))))
        by_receiver.setdefault(receiver_key, []).append(failure)
        by_pair.setdefault(pair_key, []).append(failure)
    receiver_mean = {key: float(np.mean(values)) for key, values in by_receiver.items()}
    pair_mean = {key: float(np.mean(values)) for key, values in by_pair.items()}
    pair_max = {key: float(np.max(values)) for key, values in by_pair.items()}
    for row in rows:
        failure = float(row["aggregation_failure"])
        receiver_key = row["client_i"]
        pair_key = tuple(sorted((str(row["client_i"]), str(row["client_j"]))))
        row["receiver_mean_aggregation_failure"] = receiver_mean.get(receiver_key, 0.0)
        row["receiver_residual_aggregation_failure"] = failure - receiver_mean.get(receiver_key, 0.0)
        row["pair_mean_aggregation_failure"] = pair_mean.get(pair_key, failure)
        row["pair_max_aggregation_failure"] = pair_max.get(pair_key, failure)
    return rows


def _pearson_no_import(x, y):
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    if x.size < 2:
        return float("nan")
    x = x - x.mean()
    y = y - y.mean()
    denom = np.sqrt(np.sum(x * x) * np.sum(y * y))
    if denom <= 1e-12:
        return float("nan")
    return float(np.sum(x * y) / denom)


def _bootstrap_stat(x, y, fn, rng, n_boot=1000):
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    if x.size < 2:
        return float("nan"), float("nan")
    values = []
    for _ in range(int(n_boot)):
        idx = rng.integers(0, x.size, size=x.size)
        value = fn(x[idx], y[idx])
        if np.isfinite(value):
            values.append(value)
    if not values:
        return float("nan"), float("nan")
    arr = np.asarray(values, dtype=np.float64)
    return float(np.quantile(arr, 0.025)), float(np.quantile(arr, 0.975))


def _bootstrap_1d(values, rng, n_boot=1000):
    values = np.asarray(values, dtype=np.float64)
    if values.size == 0:
        return float("nan"), float("nan")
    means = []
    for _ in range(int(n_boot)):
        idx = rng.integers(0, values.size, size=values.size)
        means.append(float(values[idx].mean()))
    arr = np.asarray(means, dtype=np.float64)
    return float(np.quantile(arr, 0.025)), float(np.quantile(arr, 0.975))


def _permutation_corr_pvalue(x, y, observed, rng, n_perm=2000):
    if not np.isfinite(observed):
        return float("nan")
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    count = 1
    total = 1
    for _ in range(int(n_perm)):
        value = _pearson_no_import(x, rng.permutation(y))
        if np.isfinite(value):
            total += 1
            if value >= observed:
                count += 1
    return float(count / total)


def _sign_flip_pvalue(diffs):
    diffs = np.asarray(diffs, dtype=np.float64)
    diffs = diffs[np.isfinite(diffs)]
    if diffs.size == 0:
        return float("nan")
    observed = float(diffs.mean())
    if diffs.size > 12:
        signs = np.random.default_rng(0).choice([-1.0, 1.0], size=(4096, diffs.size))
        means = signs @ diffs / diffs.size
        return float((np.sum(means >= observed) + 1) / (means.size + 1))
    count = 0
    total = 2 ** int(diffs.size)
    for mask in range(total):
        signs = np.array([1.0 if (mask >> i) & 1 else -1.0 for i in range(diffs.size)])
        if float((signs * diffs).mean()) >= observed:
            count += 1
    return float(count / total)


def _local_generalization_rows(per_client_metrics):
    rows = []
    for row in per_client_metrics:
        if row.get("method") != "Local-LoRA":
            continue
        train_acc = float(row["train_accuracy"])
        test_acc = float(row["test_accuracy"])
        train_loss = float(row["train_loss"])
        test_loss = float(row["test_loss"])
        rows.append(
            {
                "client_id": row["client_id"],
                "domain": row["domain"],
                "rank": row["rank"],
                "train_accuracy": train_acc,
                "test_accuracy": test_acc,
                "accuracy_gap": train_acc - test_acc,
                "train_loss": train_loss,
                "test_loss": test_loss,
                "loss_gap": test_loss - train_loss,
            }
        )
    return rows


def _negative_transfer_rows(per_client_rows):
    local_by_client = {
        row["client_id"]: float(row["accuracy"])
        for row in per_client_rows
        if row["method"] == "Local-LoRA"
    }
    fedavg_by_client = {
        row["client_id"]: float(row["accuracy"])
        for row in per_client_rows
        if row["method"] == "FedAvg-LoRA"
    }
    detail_rows = []
    by_method: dict[str, list[dict]] = {}
    for row in per_client_rows:
        client_id = row["client_id"]
        if client_id not in local_by_client:
            continue
        method = row["method"]
        accuracy = float(row["accuracy"])
        local_accuracy = local_by_client[client_id]
        fedavg_accuracy = fedavg_by_client.get(client_id, float("nan"))
        negative_transfer = max(0.0, local_accuracy - accuracy)
        fedavg_negative_transfer = max(0.0, local_accuracy - fedavg_accuracy) if np.isfinite(fedavg_accuracy) else float("nan")
        row_out = {
            "method": method,
            "seed": row["seed"],
            "dataset": row["dataset"],
            "heterogeneity_setting": row["heterogeneity_setting"],
            "heterogeneity": row.get("heterogeneity", row["heterogeneity_setting"]),
            "round": row["round"],
            "client_id": client_id,
            "domain": row["domain"],
            "rank": row.get("rank", ""),
            "local_lora_accuracy": local_accuracy,
            "method_accuracy": accuracy,
            "fedavg_lora_accuracy": fedavg_accuracy,
            "accuracy_gain_vs_fedavg": accuracy - fedavg_accuracy if np.isfinite(fedavg_accuracy) else "",
            "negative_transfer_vs_local": negative_transfer,
            "fedavg_negative_transfer_vs_local": fedavg_negative_transfer,
            "negative_transfer_reduction_vs_fedavg": fedavg_negative_transfer - negative_transfer
            if np.isfinite(fedavg_negative_transfer)
            else "",
            "is_harmed_vs_local": bool(negative_transfer > 1e-12),
            "is_helped_vs_fedavg": bool(np.isfinite(fedavg_accuracy) and accuracy > fedavg_accuracy),
        }
        detail_rows.append(row_out)
        by_method.setdefault(method, []).append(row_out)

    summary_rows = []
    for method, rows in by_method.items():
        nt = np.asarray([float(row["negative_transfer_vs_local"]) for row in rows], dtype=np.float64)
        gains = np.asarray(
            [
                float(row["negative_transfer_reduction_vs_fedavg"])
                for row in rows
                if row["negative_transfer_reduction_vs_fedavg"] != ""
            ],
            dtype=np.float64,
        )
        acc_gains = np.asarray(
            [
                float(row["accuracy_gain_vs_fedavg"])
                for row in rows
                if row["accuracy_gain_vs_fedavg"] != ""
            ],
            dtype=np.float64,
        )
        summary_rows.append(
            {
                "method": method,
                "seed": rows[0]["seed"],
                "dataset": rows[0]["dataset"],
                "heterogeneity_setting": rows[0]["heterogeneity_setting"],
                "heterogeneity": rows[0].get("heterogeneity", rows[0]["heterogeneity_setting"]),
                "round": rows[0]["round"],
                "mean_negative_transfer_vs_local": float(nt.mean()) if nt.size else float("nan"),
                "max_negative_transfer_vs_local": float(nt.max()) if nt.size else float("nan"),
                "harmed_client_count": int(np.sum(nt > 1e-12)),
                "num_clients": len(rows),
                "mean_negative_transfer_reduction_vs_fedavg": float(gains.mean()) if gains.size else "",
                "min_negative_transfer_reduction_vs_fedavg": float(gains.min()) if gains.size else "",
                "mean_accuracy_gain_vs_fedavg": float(acc_gains.mean()) if acc_gains.size else "",
                "helped_vs_fedavg_client_count": int(np.sum(acc_gains > 1e-12)) if acc_gains.size else "",
            }
        )
    return detail_rows, summary_rows


def _risk_metric_rows(per_client_rows, method_adapters, local_adapters, graph):
    rows = []
    local_accuracy = {
        row["client_id"]: float(row["accuracy"])
        for row in per_client_rows
        if row["method"] == "Local-LoRA"
    }
    by_method: dict[str, list[dict]] = {}
    for row in per_client_rows:
        by_method.setdefault(row["method"], []).append(row)

    for method, metrics in by_method.items():
        accuracy = np.asarray([float(row["accuracy"]) for row in metrics], dtype=np.float64)
        losses = []
        for row in metrics:
            baseline = local_accuracy.get(row["client_id"], float("nan"))
            if np.isfinite(baseline):
                losses.append(max(0.0, baseline - float(row["accuracy"])))
        drift = np.asarray(losses, dtype=np.float64)
        adapters = method_adapters.get(method)
        update_conflict = ""
        max_update_conflict = ""
        graph_conflict = ""
        if adapters is not None:
            distances = np.asarray(
                [
                    _adapter_update_distance(adapter, local_adapters[idx])
                    for idx, adapter in enumerate(adapters)
                ],
                dtype=np.float64,
            )
            update_conflict = float(distances.mean())
            max_update_conflict = float(distances.max())
            graph_conflict = _graph_update_conflict(adapters, graph)
        rows.append(
            {
                "method": method,
                "seed": metrics[0]["seed"],
                "dataset": metrics[0]["dataset"],
                "heterogeneity_setting": metrics[0]["heterogeneity_setting"],
                "heterogeneity": metrics[0].get("heterogeneity", metrics[0]["heterogeneity_setting"]),
                "round": metrics[0]["round"],
                "worst_client_accuracy": float(accuracy.min()) if accuracy.size else float("nan"),
                "worst_client_risk": float(1.0 - accuracy.min()) if accuracy.size else float("nan"),
                "mean_client_drift_vs_local": float(drift.mean()) if drift.size else float("nan"),
                "max_client_drift_vs_local": float(drift.max()) if drift.size else float("nan"),
                "mean_update_conflict_vs_local": update_conflict,
                "max_update_conflict_vs_local": max_update_conflict,
                "mean_graph_neighbor_update_conflict": graph_conflict,
                "num_clients": int(accuracy.size),
            }
        )
    return rows


def _add_geometry_auxiliary_scores(per_client_rows, clients, geometry) -> None:
    by_client = {client.client_id: idx for idx, client in enumerate(clients)}
    for row in per_client_rows:
        idx = by_client.get(row.get("client_id"))
        if idx is None:
            continue
        row["geometry_signal_for_manifold"] = "d_geo+geometry_graph"
        row["risk_signal_usage"] = "auxiliary_prior_only"
        row["risk_geo_score"] = _optional_float_at(geometry.risk_geo_scores, idx)
        row["feature_energy_deficit"] = _optional_float_at(geometry.feature_energy_deficit, idx)


def _optional_float_at(values, idx):
    if values is None:
        return ""
    arr = np.asarray(values, dtype=np.float64)
    if idx >= arr.size or not np.isfinite(arr[idx]):
        return ""
    return float(arr[idx])


def _geometry_signal_role_rows(geometry) -> list[dict]:
    return [
        {
            "signal": "d_geo",
            "source": "d_geo_round_t.npy",
            "role": "main_adapter_manifold_distance",
            "used_for": "compatibility, adapter graph distance, bank clustering, routing prior",
            "is_main_manifold": True,
        },
        {
            "signal": "geometry_graph",
            "source": "geometry_graph_round_t.npy",
            "role": "main_adapter_sharing_graph",
            "used_for": "client neighborhood, graph-compatible adapter sharing",
            "is_main_manifold": True,
        },
        {
            "signal": "prototypes",
            "source": "prototypes_round_t.pkl",
            "role": "class_conditional_routing_anchor",
            "used_for": "adapter-bank feature/prototype routing",
            "is_main_manifold": True,
        },
        {
            "signal": "risk_geo_score",
            "source": "risk_geo_scores_round_t.csv",
            "role": "auxiliary_rare_mode_fairness_prior",
            "used_for": "optional risk-aware rank capacity ablation only",
            "is_main_manifold": False,
            "available": geometry.risk_geo_scores is not None,
        },
        {
            "signal": "feature_energy_deficit",
            "source": "feature_energy_deficit_round_t.csv",
            "role": "auxiliary_reliability_energy_prior",
            "used_for": "optional risk-aware rank capacity ablation only",
            "is_main_manifold": False,
            "available": geometry.feature_energy_deficit is not None,
        },
    ]


def _adapter_update_distance(adapter_a, adapter_b):
    delta_a = adapter_a.delta()
    delta_b = adapter_b.delta()
    denom = np.linalg.norm(delta_a) + np.linalg.norm(delta_b)
    if denom <= 1e-12:
        return 0.0
    return float(2.0 * np.linalg.norm(delta_a - delta_b) / denom)


def _graph_update_conflict(adapters, graph):
    graph = np.asarray(graph, dtype=np.float64)
    values = []
    weights = []
    for i in range(len(adapters)):
        for j in range(i + 1, len(adapters)):
            weight = float(max(graph[i, j], graph[j, i]))
            if weight > 1e-12:
                values.append(_adapter_update_distance(adapters[i], adapters[j]))
                weights.append(weight)
    if not values:
        return ""
    return float(np.average(np.asarray(values, dtype=np.float64), weights=np.asarray(weights, dtype=np.float64)))


def _rank_rows(
    clients,
    ranks,
    requested_policy,
    effective_policy,
    geometry,
    conflict_probe,
    conflict_probe_r,
    conflict_probe_passed,
    fallback_reason,
):
    return [
        {
            "client_id": client.client_id,
            "domain": client.domain,
            "rank_policy": requested_policy,
            "effective_rank_policy": effective_policy,
            "rank": ranks[idx],
            "novelty": float(geometry.novelty[idx]),
            "coverage": float(geometry.coverage[idx]),
            "risk_geo_score": _optional_float_at(geometry.risk_geo_scores, idx),
            "feature_energy_deficit": _optional_float_at(geometry.feature_energy_deficit, idx),
            "risk_signal_usage": "auxiliary_capacity_prior" if requested_policy == "risk-aware" else "logged_only",
            "conflict_probe": "" if conflict_probe is None else float(conflict_probe[idx]),
            "conflict_probe_r": "" if conflict_probe_r is None else float(conflict_probe_r),
            "conflict_probe_passed": "" if conflict_probe_passed is None else bool(conflict_probe_passed),
            "fallback_reason": fallback_reason,
        }
        for idx, client in enumerate(clients)
    ]


def _write_report(
    output_dir,
    args,
    incompatibility_diagnostic_r,
    raw_subspace_diagnostic_r,
    update_diagnostic_r,
    geo_diagnostic_r,
    label_diagnostic_r,
    combined_diagnostic_r,
    distance_rows,
    diagnostic_passed,
    provider,
    bank_built,
    class_names,
):
    status = "PASS" if diagnostic_passed else "FAIL"
    text = [
        "FedAdapterManifold diagnostic report",
        f"dataset={args.dataset}",
        f"classes={','.join(class_names)}",
        f"geometry_provider={provider}",
        "main_manifold_signals=d_geo,geometry_graph,prototypes",
        "auxiliary_risk_signals=risk_geo_score,feature_energy_deficit",
        f"rank_policy={args.rank_policy}",
        f"adapter_incompatibility_failure_pearson_r={incompatibility_diagnostic_r:.6f}",
        f"raw_subspace_failure_pearson_r={raw_subspace_diagnostic_r:.6f}",
        f"update_failure_pearson_r={update_diagnostic_r:.6f}",
        f"geo_failure_pearson_r={geo_diagnostic_r:.6f}",
        f"label_failure_pearson_r={label_diagnostic_r:.6f}",
        f"combined_failure_pearson_r={combined_diagnostic_r:.6f}",
        f"diagnostic_threshold={args.diagnostic_threshold:.6f}",
        f"killer_diagnostic={status}",
        f"adapter_bank_built={bank_built}",
    ]
    complementarity = _distance_row(distance_rows, "joint_model", "subspace_plus_geo")
    if complementarity:
        text.append(f"subspace_plus_geo_r2={float(complementarity.get('r2', float('nan'))):.6f}")
        text.append(f"subspace_plus_geo_incremental_r2={float(complementarity.get('incremental_r2_vs_subspace', float('nan'))):.6f}")
        text.append(f"geo_subspace_complementarity={complementarity.get('supports_geo_subspace_complementarity')}")
    if not diagnostic_passed and not args.continue_on_failed_diagnostic:
        text.append("Stopped before expanding AdapterBank because the killer diagnostic failed.")
    path = Path(output_dir) / "diagnostic_report.txt"
    path.write_text("\n".join(text) + "\n", encoding="utf-8")


def _distance_row(rows, diagnostic_type, measure):
    for row in rows:
        if row.get("diagnostic_type") == diagnostic_type and row.get("measure") == measure:
            return row
    return None


if __name__ == "__main__":
    raise SystemExit(main())
