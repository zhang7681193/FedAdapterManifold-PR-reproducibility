from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .adapters import LoRAAdapter
from .training import evaluate_adapter, evaluate_adapter_error_vector


Array = np.ndarray


@dataclass
class PathAdmissionResult:
    client_adapters: list[LoRAAdapter]
    per_client_metrics: list[dict]
    admission_rows: list[dict]


def empirical_bernstein_upper_bound(
    differences: Array,
    delta: float,
    num_comparisons: int = 1,
) -> tuple[float, float, float]:
    """Return mean, margin, and upper bound for bounded paired differences.

    ``differences`` are paired 0-1 loss differences and therefore lie in
    [-1, 1].  The comparison count applies a Bonferroni correction over the
    fixed admission path inspected for one receiver.
    """

    values = np.asarray(differences, dtype=np.float64).reshape(-1)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return float("inf"), float("inf"), float("inf")
    mean = float(values.mean())
    if values.size <= 1:
        return mean, float("inf"), float("inf")
    variance = float(values.var(ddof=1))
    adjusted_delta = float(np.clip(delta / max(int(num_comparisons), 1), 1e-12, 1.0))
    log_term = float(np.log(3.0 / adjusted_delta))
    margin = float(
        np.sqrt(2.0 * variance * log_term / float(values.size))
        + 3.0 * 2.0 * log_term / float(values.size)
    )
    return mean, margin, mean + margin


def select_empirical_bernstein_path(
    selector_clients: list,
    eval_clients: list,
    base_weight: Array,
    anchor_adapters: list[LoRAAdapter],
    manifold_adapters: list[LoRAAdapter],
    ranks: list[int] | int,
    path: list[float] | str | None = None,
    delta: float = 0.05,
    risk_tolerance: float = 0.0,
    seed: int = 0,
    dataset: str = "",
    heterogeneity_setting: str = "",
    round_id: int = 0,
    method: str = "FedAdapterManifold-PathAdmit",
) -> PathAdmissionResult:
    """Select a certified partial manifold admission without test leakage.

    The anchor and manifold endpoints must be fixed before this function is
    called.  Selection uses only each client's declared training/calibration
    split.  Test examples are touched only after the path coefficient is fixed.
    """

    n_clients = len(selector_clients)
    if len(eval_clients) != n_clients:
        raise ValueError("selector_clients and eval_clients must have the same length")
    if len(anchor_adapters) != n_clients or len(manifold_adapters) != n_clients:
        raise ValueError("Path admission requires one anchor and manifold adapter per client")
    rank_list = [int(ranks)] * n_clients if isinstance(ranks, int) else [int(value) for value in ranks]
    if len(rank_list) != n_clients:
        raise ValueError(f"Expected {n_clients} ranks, got {len(rank_list)}")
    path_values = _parse_path(path)
    positive_steps = [value for value in path_values if value > 0.0]
    comparison_count = max(len(positive_steps), 1)

    selected_adapters: list[LoRAAdapter] = []
    metrics_rows: list[dict] = []
    admission_rows: list[dict] = []
    for idx, (selector_client, eval_client, anchor, manifold, rank) in enumerate(
        zip(selector_clients, eval_clients, anchor_adapters, manifold_adapters, rank_list)
    ):
        anchor_errors = evaluate_adapter_error_vector(
            selector_client.x_train,
            selector_client.y_train,
            base_weight,
            anchor,
        )
        candidate_records: list[dict] = []
        candidate_adapters: list[LoRAAdapter] = []
        for strength in path_values:
            adapter = _path_adapter(anchor, manifold, strength, rank, idx, method)
            candidate_adapters.append(adapter)
            candidate_errors = evaluate_adapter_error_vector(
                selector_client.x_train,
                selector_client.y_train,
                base_weight,
                adapter,
            )
            mean, margin, upper = empirical_bernstein_upper_bound(
                candidate_errors - anchor_errors,
                delta=delta,
                num_comparisons=comparison_count,
            )
            candidate_records.append(
                {
                    "admission_strength": float(strength),
                    "paired_error_difference": float(mean),
                    "empirical_bernstein_margin": float(margin),
                    "risk_upper_bound": float(upper),
                    "certified_safe": bool(strength == 0.0 or upper <= float(risk_tolerance) + 1e-12),
                }
            )

        safe_indices = [index for index, row in enumerate(candidate_records) if row["certified_safe"]]
        if not safe_indices:
            selected_idx = 0
        else:
            # Among certified steps, minimize empirical risk first and prefer
            # more sharing only when the paired estimates are tied.
            selected_idx = min(
                safe_indices,
                key=lambda index: (
                    float(candidate_records[index]["paired_error_difference"]),
                    -float(candidate_records[index]["admission_strength"]),
                ),
            )
        selected = candidate_adapters[selected_idx]
        selected_adapters.append(selected)
        test_metrics = evaluate_adapter(eval_client.x_test, eval_client.y_test, base_weight, selected)
        selected_record = candidate_records[selected_idx]
        metrics_rows.append(
            {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": eval_client.client_id,
                "domain": eval_client.domain,
                "accuracy": float(test_metrics["accuracy"]),
                "loss": float(test_metrics["loss"]),
                "rank": int(rank),
                "selected_admission_strength": float(selected_record["admission_strength"]),
                "certified_risk_upper_bound": float(selected_record["risk_upper_bound"]),
            }
        )
        for candidate_idx, record in enumerate(candidate_records):
            admission_rows.append(
                {
                    "method": method,
                    "seed": int(seed),
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": int(round_id),
                    "client_id": eval_client.client_id,
                    "domain": eval_client.domain,
                    "selection_split": "heldout_calibration",
                    "selector_loss": "paired_0_1_error",
                    "selector_delta": float(delta),
                    "selector_num_comparisons": int(comparison_count),
                    "risk_tolerance": float(risk_tolerance),
                    **record,
                    "selected": bool(candidate_idx == selected_idx),
                }
            )
    return PathAdmissionResult(selected_adapters, metrics_rows, admission_rows)


def _path_adapter(
    anchor: LoRAAdapter,
    manifold: LoRAAdapter,
    strength: float,
    rank: int,
    client_index: int,
    method: str,
) -> LoRAAdapter:
    strength = float(np.clip(strength, 0.0, 1.0))
    delta = (1.0 - strength) * anchor.delta() + strength * manifold.delta()
    return LoRAAdapter.from_delta(
        delta,
        rank=int(rank),
        alpha=float(rank),
        name=f"{method.lower()}_client_{client_index}_strength_{strength:.3f}",
    )


def _parse_path(path: list[float] | str | None) -> list[float]:
    if path is None or path == "":
        values = [0.0, 0.25, 0.5, 0.75, 1.0]
    elif isinstance(path, str):
        values = [float(part.strip()) for part in path.split(",") if part.strip()]
    else:
        values = [float(value) for value in path]
    values = sorted({float(np.clip(value, 0.0, 1.0)) for value in values} | {0.0, 1.0})
    return values
