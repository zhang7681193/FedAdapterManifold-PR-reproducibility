from __future__ import annotations

import math
import hashlib
from dataclasses import dataclass

import numpy as np

from .adapters import LoRAAdapter
from .training import cross_entropy_and_grad, evaluate_adapter, predict_with_weight, softmax


Array = np.ndarray


@dataclass(frozen=True)
class SignedTangentDiagnostics:
    directional_derivative: float
    curvature_bound: float
    closed_form_step: float
    selected_step: float
    predicted_loss_decrease: float
    anchor_screen_loss: float
    candidate_screen_loss: float
    residual_norm: float
    tangent_norm: float
    normal_norm: float
    tangent_energy_ratio: float
    projection_error_norm: float
    descent_direction: bool


@dataclass
class SignedTangentAdmissionResult:
    client_adapters: list[LoRAAdapter]
    per_client_metrics: list[dict]
    admission_rows: list[dict]


def exact_one_sided_discordance_p(beneficial: int, harmful: int) -> float:
    """Exact one-sided paired sign/McNemar p-value for candidate improvement."""

    beneficial = int(beneficial)
    harmful = int(harmful)
    if beneficial < 0 or harmful < 0:
        raise ValueError("discordance counts must be nonnegative")
    total = beneficial + harmful
    if total == 0 or beneficial <= harmful:
        return 1.0
    numerator = sum(math.comb(total, k) for k in range(0, harmful + 1))
    return float(numerator / (2**total))


def paired_candidate_certificate(
    anchor: dict,
    candidate: dict,
    *,
    edge_alpha: float,
    loss_margin: float = 0.0,
) -> dict[str, float | int | bool]:
    """Certify one directed candidate-vs-anchor calibration edge."""

    if not 0.0 < float(edge_alpha) < 1.0:
        raise ValueError("edge_alpha must be in (0, 1)")
    anchor_correctness = np.asarray(anchor["correctness"], dtype=np.int64)
    candidate_correctness = np.asarray(candidate["correctness"], dtype=np.int64)
    if anchor_correctness.shape != candidate_correctness.shape:
        raise ValueError("paired correctness vectors must have equal shape")
    beneficial = int(np.sum((anchor_correctness == 0) & (candidate_correctness == 1)))
    harmful = int(np.sum((anchor_correctness == 1) & (candidate_correctness == 0)))
    p_value = exact_one_sided_discordance_p(beneficial, harmful)
    target_improved = bool(float(candidate["accuracy"]) > float(anchor["accuracy"]) + 1e-12)
    loss_improved = bool(
        float(candidate["loss"]) < float(anchor["loss"]) - float(loss_margin) - 1e-12
    )
    brier_nonincrease = bool(float(candidate["brier"]) <= float(anchor["brier"]) + 1e-12)
    pareto_pass = bool(target_improved and loss_improved and brier_nonincrease)
    certified = bool(pareto_pass and p_value <= float(edge_alpha))
    return {
        "beneficial": beneficial,
        "harmful": harmful,
        "discordant": beneficial + harmful,
        "p_value": p_value,
        "edge_alpha": float(edge_alpha),
        "target_improved": target_improved,
        "loss_improved": loss_improved,
        "brier_nonincrease": brier_nonincrease,
        "pareto_pass": pareto_pass,
        "certified": certified,
    }


def select_training_fixed_semantic_endpoint(
    *,
    training_clients: list,
    base_weight: Array,
    candidate_families: dict[str, list[LoRAAdapter]],
    seed: int = 0,
    dataset: str = "",
    heterogeneity_setting: str = "",
    round_id: int = 0,
) -> tuple[list[LoRAAdapter], list[dict]]:
    """Select one endpoint family using adapter-training data only.

    The returned endpoint is fixed before an independent calibration split is
    inspected.  Candidate-family size therefore does not enter the later exact
    calibration multiplicity.
    """

    if not candidate_families:
        raise ValueError("candidate_families must not be empty")
    n = len(training_clients)
    names = list(candidate_families)
    if any(len(adapters) != n for adapters in candidate_families.values()):
        raise ValueError("Every candidate family must align with training_clients")
    selected: list[LoRAAdapter] = []
    rows: list[dict] = []
    for index, client in enumerate(training_clients):
        records: list[tuple[str, LoRAAdapter, dict]] = []
        for priority, name in enumerate(names):
            adapter = candidate_families[name][index]
            metrics = evaluate_adapter(client.x_train, client.y_train, base_weight, adapter)
            records.append((name, adapter, {**metrics, "priority": priority}))
        selected_name, selected_adapter, _ = min(
            records,
            key=lambda item: (
                -float(item[2]["accuracy"]),
                float(item[2]["loss"]),
                int(item[2]["priority"]),
            ),
        )
        selected.append(selected_adapter.copy(name=f"training_fixed_semantic_client_{index}"))
        for name, adapter, metrics in records:
            rows.append(
                {
                    "method": "FedAdapterManifold-TrainingScreenedEndpoint",
                    "seed": int(seed),
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": int(round_id),
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "candidate_generator": name,
                    "training_accuracy": float(metrics["accuracy"]),
                    "training_loss": float(metrics["loss"]),
                    "candidate_sha256": _adapter_sha256(adapter),
                    "selected_generator": selected_name,
                    "selected": name == selected_name,
                    "selection_split": "adapter_training",
                    "calibration_used": False,
                    "test_used": False,
                }
            )
    return selected, rows


def select_crossfitted_semantic_endpoint(
    *,
    validation_clients: list,
    base_weight: Array,
    provisional_candidate_families: dict[str, list[LoRAAdapter]],
    rebuilt_candidate_families: dict[str, list[LoRAAdapter]],
    seed: int = 0,
    dataset: str = "",
    heterogeneity_setting: str = "",
    round_id: int = 0,
) -> tuple[list[LoRAAdapter], list[dict]]:
    """Choose a generator on an inner split and return its full-training rebuild.

    Provisional candidates must be fitted without the inner validation samples.
    The selected family name is then mapped to a candidate rebuilt from the
    complete adapter-training split. Outer calibration and test data are never
    inspected by this function.
    """

    if not provisional_candidate_families:
        raise ValueError("provisional_candidate_families must not be empty")
    if set(provisional_candidate_families) != set(rebuilt_candidate_families):
        raise ValueError("provisional and rebuilt candidate families must have identical names")
    n = len(validation_clients)
    names = list(provisional_candidate_families)
    for family_map in (provisional_candidate_families, rebuilt_candidate_families):
        if any(len(adapters) != n for adapters in family_map.values()):
            raise ValueError("Every candidate family must align with validation_clients")

    selected: list[LoRAAdapter] = []
    rows: list[dict] = []
    for index, client in enumerate(validation_clients):
        records: list[tuple[str, dict]] = []
        for priority, name in enumerate(names):
            provisional = provisional_candidate_families[name][index]
            metrics = evaluate_adapter(client.x_train, client.y_train, base_weight, provisional)
            records.append((name, {**metrics, "priority": priority}))
        selected_name, _ = min(
            records,
            key=lambda item: (
                -float(item[1]["accuracy"]),
                float(item[1]["loss"]),
                int(item[1]["priority"]),
            ),
        )
        rebuilt = rebuilt_candidate_families[selected_name][index]
        selected.append(rebuilt.copy(name=f"crossfit_fixed_semantic_client_{index}"))
        for name, metrics in records:
            rows.append(
                {
                    "method": "FedAdapterManifold-CrossfitGeneratorScreen",
                    "seed": int(seed),
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": int(round_id),
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "candidate_generator": name,
                    "inner_validation_accuracy": float(metrics["accuracy"]),
                    "inner_validation_loss": float(metrics["loss"]),
                    "provisional_candidate_sha256": _adapter_sha256(
                        provisional_candidate_families[name][index]
                    ),
                    "rebuilt_candidate_sha256": _adapter_sha256(
                        rebuilt_candidate_families[name][index]
                    ),
                    "selected_generator": selected_name,
                    "selected": name == selected_name,
                    "selection_split": "nested_training_validation",
                    "calibration_used": False,
                    "test_used": False,
                }
            )
    return selected, rows


def select_hierarchical_exact_certified_endpoint(
    *,
    selector_clients: list,
    eval_clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    geo_adapters: list[LoRAAdapter],
    semantic_adapters: list[LoRAAdapter],
    familywise_alpha: float = 0.05,
    loss_margin: float = 0.0,
    seed: int = 0,
    dataset: str = "",
    heterogeneity_setting: str = "",
    round_id: int = 0,
    method: str = "FedAdapterManifold-Admit-Power",
    candidate_name: str = "FAM-TrainingScreenedSemanticEndpoint",
    candidate_training_fixed: bool = True,
) -> SignedTangentAdmissionResult:
    """Deduplicate endpoints and apply a serial Holm exact certificate.

    Local safety is the primary family.  The FAM-vs-Geo dominance edge is
    opened only after both distinct primary endpoints beat immutable Local.
    """

    n = len(selector_clients)
    collections = [eval_clients, local_adapters, geo_adapters, semantic_adapters]
    if any(len(items) != n for items in collections):
        raise ValueError("selector, evaluation, and candidate collections must align")
    if not 0.0 < float(familywise_alpha) < 1.0:
        raise ValueError("familywise_alpha must be in (0, 1)")
    if not bool(candidate_training_fixed):
        raise ValueError("exact certification requires a training-fixed candidate endpoint")
    candidate_name = str(candidate_name).strip()
    if not candidate_name or candidate_name in {"Local-LoRA", "Geo-only-Agg"}:
        raise ValueError("candidate_name must identify a distinct semantic endpoint")

    names = ["Local-LoRA", "Geo-only-Agg", candidate_name]
    selected: list[LoRAAdapter] = []
    metrics_rows: list[dict] = []
    admission_rows: list[dict] = []
    for index, (selector, evaluator) in enumerate(zip(selector_clients, eval_clients)):
        candidates = {
            names[0]: local_adapters[index],
            names[1]: geo_adapters[index],
            names[2]: semantic_adapters[index],
        }
        calibration = {
            name: _classification_metrics_with_correctness(
                selector.x_train, selector.y_train, base_weight, adapter
            )
            for name, adapter in candidates.items()
        }
        geo_duplicate_local = _adapters_bytewise_equal(candidates[names[1]], candidates[names[0]])
        fam_duplicate_local = _adapters_bytewise_equal(candidates[names[2]], candidates[names[0]])
        fam_duplicate_geo = _adapters_bytewise_equal(candidates[names[2]], candidates[names[1]])

        primary: dict[str, dict] = {}
        if not geo_duplicate_local:
            primary["geo_only_agg"] = paired_candidate_certificate(
                calibration[names[0]], calibration[names[1]],
                edge_alpha=float(familywise_alpha), loss_margin=loss_margin,
            )
        if not fam_duplicate_local and not fam_duplicate_geo:
            primary["fam_vs_local"] = paired_candidate_certificate(
                calibration[names[0]], calibration[names[2]],
                edge_alpha=float(familywise_alpha), loss_margin=loss_margin,
            )
        primary_rejected, primary_thresholds = _holm_pareto_rejections(
            primary, alpha=float(familywise_alpha)
        )
        geo_deployable = bool(primary_rejected.get("geo_only_agg", False))
        fam_local_deployable = bool(primary_rejected.get("fam_vs_local", False))

        secondary_opened = bool(geo_deployable and fam_local_deployable)
        fam_geo = paired_candidate_certificate(
            calibration[names[1]], calibration[names[2]],
            edge_alpha=float(familywise_alpha), loss_margin=loss_margin,
        )
        secondary_certified = bool(
            secondary_opened and not fam_duplicate_geo and _pareto_pass(fam_geo)
            and float(fam_geo["p_value"]) <= float(familywise_alpha)
        )
        fam_deployable = bool(
            fam_local_deployable and (not geo_deployable or secondary_certified)
        )

        eligible = [names[0]]
        if geo_deployable:
            eligible.append(names[1])
        if fam_deployable:
            eligible.append(names[2])
        priority = {name: position for position, name in enumerate(names)}
        deployed_name = min(
            eligible,
            key=lambda name: (
                -float(calibration[name]["accuracy"]),
                float(calibration[name]["loss"]),
                priority[name],
            ),
        )
        deployed = candidates[deployed_name].copy(name=f"{method}-client-{index}")
        if deployed_name == names[0] and not _adapters_bytewise_equal(
            deployed, local_adapters[index]
        ):
            raise RuntimeError("Local fallback must be bytewise exact")
        selected.append(deployed)
        test_metrics = evaluate_adapter(evaluator.x_test, evaluator.y_test, base_weight, deployed)
        metrics_rows.append(
            {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": evaluator.client_id,
                "domain": evaluator.domain,
                "accuracy": float(test_metrics["accuracy"]),
                "loss": float(test_metrics["loss"]),
                "rank": int(deployed.rank),
                "selected_transport_family": deployed_name,
                "selected_nonlocal": deployed_name != names[0],
                "admitted_semantic_endpoint": deployed_name == names[2],
                "fell_back_to_local": deployed_name == names[0],
            }
        )
        test_by_name = {
            name: evaluate_adapter(evaluator.x_test, evaluator.y_test, base_weight, adapter)
            for name, adapter in candidates.items()
        }
        empty = {
            "beneficial": 0, "harmful": 0, "discordant": 0,
            "p_value": 1.0, "edge_alpha": float("nan"), "certified": False,
            "target_improved": False, "loss_improved": False,
            "brier_nonincrease": True, "pareto_pass": False,
        }
        geo_local = primary.get("geo_only_agg", empty)
        fam_local = primary.get("fam_vs_local", empty)
        certificates = {
            "geo_only_agg": geo_local,
            "fam_vs_local": fam_local,
            "fam_vs_geo": fam_geo,
        }
        for endpoint_name in names:
            row = {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": evaluator.client_id,
                "domain": evaluator.domain,
                "candidate_method": endpoint_name,
                "immutable_anchor": names[0],
                "calibration_size": int(selector.y_train.size),
                "calibration_accuracy": float(calibration[endpoint_name]["accuracy"]),
                "calibration_loss": float(calibration[endpoint_name]["loss"]),
                "calibration_brier": float(calibration[endpoint_name]["brier"]),
                "familywise_alpha": float(familywise_alpha),
                "certificate_hierarchy": "deduplicate;holm_local_safety;serial_fam_vs_geo",
                "candidate_training_fixed": True,
                "primary_family_size": int(len(primary)),
                "geo_duplicate_local": geo_duplicate_local,
                "fam_duplicate_local": fam_duplicate_local,
                "fam_duplicate_geo": fam_duplicate_geo,
                "geo_primary_holm_threshold": primary_thresholds.get("geo_only_agg", float("nan")),
                "fam_primary_holm_threshold": primary_thresholds.get("fam_vs_local", float("nan")),
                "secondary_opened": secondary_opened,
                "secondary_alpha": float(familywise_alpha),
                "geo_deployable": geo_deployable,
                "fam_deployable": fam_deployable,
                "selected_method": deployed_name,
                "selected": endpoint_name == deployed_name,
                "fell_back_to_local": deployed_name == names[0],
                "test_accuracy_post_selection_audit": float(test_by_name[endpoint_name]["accuracy"]),
                "test_loss_post_selection_audit": float(test_by_name[endpoint_name]["loss"]),
                "test_used_for_selection": False,
            }
            for edge_name, certificate in certificates.items():
                for field, value in certificate.items():
                    row[f"{edge_name}_{field}"] = value
            admission_rows.append(row)
    return SignedTangentAdmissionResult(selected, metrics_rows, admission_rows)


def _holm_pareto_rejections(
    certificates: dict[str, dict], *, alpha: float
) -> tuple[dict[str, bool], dict[str, float]]:
    ordered = sorted(
        certificates,
        key=lambda name: (
            float(certificates[name]["p_value"]) if _pareto_pass(certificates[name]) else 1.0,
            name,
        ),
    )
    rejected = {name: False for name in certificates}
    thresholds = {name: float("nan") for name in certificates}
    total = len(ordered)
    for position, name in enumerate(ordered):
        threshold = float(alpha) / float(total - position)
        thresholds[name] = threshold
        effective_p = float(certificates[name]["p_value"]) if _pareto_pass(certificates[name]) else 1.0
        if effective_p <= threshold:
            rejected[name] = True
        else:
            break
    return rejected, thresholds


def _pareto_pass(certificate: dict) -> bool:
    return bool(certificate.get("pareto_pass", False))


def _adapter_sha256(adapter: LoRAAdapter) -> str:
    digest = hashlib.sha256()
    digest.update(np.ascontiguousarray(adapter.A).tobytes())
    digest.update(np.ascontiguousarray(adapter.B).tobytes())
    return digest.hexdigest()


def _adapters_bytewise_equal(left: LoRAAdapter, right: LoRAAdapter) -> bool:
    return bool(np.array_equal(left.A, right.A) and np.array_equal(left.B, right.B))


def select_exact_certified_signed_tangent(
    *,
    selector_clients: list,
    eval_clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    geo_adapters: list[LoRAAdapter],
    signed_adapters: list[LoRAAdapter],
    familywise_alpha: float = 0.05,
    loss_margin: float = 0.0,
    seed: int = 0,
    dataset: str = "",
    heterogeneity_setting: str = "",
    round_id: int = 0,
    method: str = "FedAdapterManifold-ExactAdmit",
    candidate_name: str = "FAM-ReceiverTangent",
    candidate_training_fixed: bool = True,
) -> SignedTangentAdmissionResult:
    """Deploy only endpoints with a certified path from immutable Local.

    Candidate construction is assumed fixed before this function receives the
    held-out training-side calibration clients.  Three directed edges are
    predeclared, so every edge uses ``familywise_alpha / 3``.
    """

    n = len(selector_clients)
    collections = [eval_clients, local_adapters, geo_adapters, signed_adapters]
    if any(len(items) != n for items in collections):
        raise ValueError("selector, evaluation, and candidate collections must align")
    if not 0.0 < float(familywise_alpha) < 1.0:
        raise ValueError("familywise_alpha must be in (0, 1)")
    edge_alpha = float(familywise_alpha) / 3.0
    selected: list[LoRAAdapter] = []
    metrics_rows: list[dict] = []
    admission_rows: list[dict] = []
    candidate_name = str(candidate_name).strip()
    if not candidate_name or candidate_name in {"Local-LoRA", "Geo-only-Agg"}:
        raise ValueError("candidate_name must identify a distinct non-local endpoint")
    if not bool(candidate_training_fixed):
        raise ValueError("exact certification requires a training-fixed candidate endpoint")
    names = ["Local-LoRA", "Geo-only-Agg", candidate_name]

    for index, (selector, evaluator) in enumerate(zip(selector_clients, eval_clients)):
        candidates = {
            names[0]: local_adapters[index],
            names[1]: geo_adapters[index],
            names[2]: signed_adapters[index],
        }
        calibration = {
            name: _classification_metrics_with_correctness(
                selector.x_train, selector.y_train, base_weight, adapter
            )
            for name, adapter in candidates.items()
        }
        geo_local = paired_candidate_certificate(
            calibration[names[0]],
            calibration[names[1]],
            edge_alpha=edge_alpha,
            loss_margin=loss_margin,
        )
        fam_local = paired_candidate_certificate(
            calibration[names[0]],
            calibration[names[2]],
            edge_alpha=edge_alpha,
            loss_margin=loss_margin,
        )
        fam_geo = paired_candidate_certificate(
            calibration[names[1]],
            calibration[names[2]],
            edge_alpha=edge_alpha,
            loss_margin=loss_margin,
        )
        geo_deployable = bool(geo_local["certified"])
        fam_deployable = bool(
            fam_local["certified"] and (not geo_deployable or fam_geo["certified"])
        )
        eligible = [names[0]]
        if geo_deployable:
            eligible.append(names[1])
        if fam_deployable:
            eligible.append(names[2])
        priority = {name: position for position, name in enumerate(names)}
        deployed_name = min(
            eligible,
            key=lambda name: (
                -float(calibration[name]["accuracy"]),
                float(calibration[name]["loss"]),
                priority[name],
            ),
        )
        deployed = candidates[deployed_name].copy(name=f"{method}-client-{index}")
        if deployed_name == names[0]:
            if not np.array_equal(deployed.A, local_adapters[index].A) or not np.array_equal(
                deployed.B, local_adapters[index].B
            ):
                raise RuntimeError("Local fallback must be bytewise exact")
        selected.append(deployed)
        test_metrics = evaluate_adapter(
            evaluator.x_test, evaluator.y_test, base_weight, deployed
        )
        metrics_rows.append(
            {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": evaluator.client_id,
                "domain": evaluator.domain,
                "accuracy": float(test_metrics["accuracy"]),
                "loss": float(test_metrics["loss"]),
                "rank": int(deployed.rank),
                "selected_transport_family": deployed_name,
                "selected_nonlocal": deployed_name != names[0],
                "admitted_signed_tangent": deployed_name == names[2],
                "fell_back_to_local": deployed_name == names[0],
            }
        )
        certificates = {
            "Geo-only-Agg": geo_local,
            "FAM-vs-Local": fam_local,
            "FAM-vs-Geo": fam_geo,
        }
        test_by_name = {
            name: evaluate_adapter(evaluator.x_test, evaluator.y_test, base_weight, adapter)
            for name, adapter in candidates.items()
        }
        for candidate_name in names:
            row = {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": evaluator.client_id,
                "domain": evaluator.domain,
                "candidate_method": candidate_name,
                "immutable_anchor": names[0],
                "calibration_size": int(selector.y_train.size),
                "calibration_accuracy": float(calibration[candidate_name]["accuracy"]),
                "calibration_loss": float(calibration[candidate_name]["loss"]),
                "calibration_brier": float(calibration[candidate_name]["brier"]),
                "familywise_alpha": float(familywise_alpha),
                "per_edge_alpha": edge_alpha,
                "certificate_hierarchy": "local_safe;geo_vs_local;fam_vs_local_and_admitted_geo",
                "candidate_training_fixed": True,
                "geo_deployable": geo_deployable,
                "fam_deployable": fam_deployable,
                "selected_method": deployed_name,
                "selected": candidate_name == deployed_name,
                "fell_back_to_local": deployed_name == names[0],
                "test_accuracy_post_selection_audit": float(test_by_name[candidate_name]["accuracy"]),
                "test_loss_post_selection_audit": float(test_by_name[candidate_name]["loss"]),
                "test_used_for_selection": False,
            }
            for edge_name, certificate in certificates.items():
                prefix = edge_name.lower().replace("-", "_")
                for field, value in certificate.items():
                    row[f"{prefix}_{field}"] = value
            admission_rows.append(row)
    return SignedTangentAdmissionResult(selected, metrics_rows, admission_rows)


def receiver_tangent_projection(residual: Array, receiver: LoRAAdapter) -> Array:
    """Project an ambient update onto the receiver's fixed-rank tangent space.

    For receiver column/row bases ``U`` and ``V``, the orthogonal tangent
    projector is ``P_U R + R P_V - P_U R P_V``. This keeps one-sided action
    directions while removing the normal block that changes both action
    subspaces at once.
    """

    residual = np.nan_to_num(np.asarray(residual, dtype=np.float64))
    if residual.shape != (receiver.output_dim, receiver.input_dim):
        raise ValueError(
            f"Residual shape {residual.shape} does not match receiver update "
            f"{(receiver.output_dim, receiver.input_dim)}"
        )
    u = _orth(receiver.B)
    v = _orth(receiver.A.T)
    if u.size == 0 and v.size == 0:
        return np.zeros_like(residual)
    left = u @ (u.T @ residual) if u.size else np.zeros_like(residual)
    right = (residual @ v) @ v.T if v.size else np.zeros_like(residual)
    overlap = u @ ((u.T @ residual @ v) @ v.T) if u.size and v.size else np.zeros_like(residual)
    return np.nan_to_num(left + right - overlap)


def receiver_risk_gradient(x: Array, y: Array, weight: Array) -> Array:
    """Return the empirical cross-entropy gradient with respect to ``weight``."""

    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.int64)
    logits = predict_with_weight(x, weight)
    _, grad_logits = cross_entropy_and_grad(logits, y)
    return np.nan_to_num(grad_logits.T @ x)


def softmax_directional_curvature_bound(x: Array, direction: Array) -> float:
    """A global empirical CE curvature bound along one weight direction.

    The multiclass softmax Hessian in logit space has spectral norm at most
    one half. Therefore the directional Hessian is bounded by
    ``0.5 * mean(||direction @ x||_2^2)`` at every point on the path.
    """

    x = np.asarray(x, dtype=np.float64)
    direction = np.asarray(direction, dtype=np.float64)
    action = x @ direction.T
    return float(0.5 * np.mean(np.sum(action * action, axis=1))) if x.shape[0] else 0.0


def build_fisher_signed_tangent_candidate(
    *,
    x_screen: Array,
    y_screen: Array,
    base_weight: Array,
    receiver: LoRAAdapter,
    anchor: LoRAAdapter,
    source: LoRAAdapter,
    target_rank: int,
    alpha_max: float = 1.0,
    derivative_margin: float = 0.0,
    curvature_floor: float = 1e-12,
    backtracking_factors: tuple[float, ...] = (1.0, 0.5, 0.25, 0.125),
    name: str = "fisher_signed_tangent",
) -> tuple[LoRAAdapter, SignedTangentDiagnostics]:
    """Construct one training-fixed signed tangent residual candidate.

    Grassmann geometry determines which part of ``source - anchor`` is in the
    receiver tangent space. The receiver risk derivative determines whether
    that tangent direction is beneficial. A softmax smoothness bound supplies
    a closed-form step; deterministic training-side backtracking absorbs the
    error introduced by projection to the requested deployment rank.
    """

    if not 0.0 < float(alpha_max) <= 1.0:
        raise ValueError("alpha_max must be in (0, 1]")
    x_screen = np.asarray(x_screen, dtype=np.float64)
    y_screen = np.asarray(y_screen, dtype=np.int64)
    base_weight = np.asarray(base_weight, dtype=np.float64)
    if x_screen.ndim != 2 or y_screen.ndim != 1 or x_screen.shape[0] != y_screen.shape[0]:
        raise ValueError("Screen features and labels must have aligned 2D/1D shapes")
    residual = source.delta() - anchor.delta()
    tangent = receiver_tangent_projection(residual, receiver)
    normal = residual - tangent
    gradient = receiver_risk_gradient(x_screen, y_screen, anchor.weight(base_weight))
    derivative = float(np.sum(gradient * tangent))
    curvature = max(float(curvature_floor), softmax_directional_curvature_bound(x_screen, tangent))
    residual_norm = float(np.linalg.norm(residual))
    tangent_norm = float(np.linalg.norm(tangent))
    normal_norm = float(np.linalg.norm(normal))
    anchor_metrics = evaluate_adapter(x_screen, y_screen, base_weight, anchor)
    is_descent = bool(tangent_norm > 0.0 and derivative < -float(derivative_margin))
    closed_form = float(np.clip(-derivative / curvature, 0.0, float(alpha_max))) if is_descent else 0.0

    best = anchor.copy(name=name)
    best_loss = float(anchor_metrics["loss"])
    best_step = 0.0
    projection_error = 0.0
    factors = sorted({float(value) for value in backtracking_factors if 0.0 < float(value) <= 1.0}, reverse=True)
    if is_descent and closed_form > 0.0:
        for factor in factors:
            step = closed_form * factor
            lifted_delta = anchor.delta() + step * tangent
            candidate = LoRAAdapter.from_delta(
                lifted_delta,
                rank=int(target_rank),
                alpha=float(target_rank),
                name=name,
            )
            metrics = evaluate_adapter(x_screen, y_screen, base_weight, candidate)
            if float(metrics["loss"]) < best_loss - 1e-12:
                best = candidate
                best_loss = float(metrics["loss"])
                best_step = float(step)
                projection_error = float(np.linalg.norm(candidate.delta() - lifted_delta))

    predicted_decrease = max(
        0.0,
        -(best_step * derivative + 0.5 * curvature * best_step * best_step),
    )
    diagnostics = SignedTangentDiagnostics(
        directional_derivative=derivative,
        curvature_bound=curvature,
        closed_form_step=closed_form,
        selected_step=best_step,
        predicted_loss_decrease=float(predicted_decrease),
        anchor_screen_loss=float(anchor_metrics["loss"]),
        candidate_screen_loss=best_loss,
        residual_norm=residual_norm,
        tangent_norm=tangent_norm,
        normal_norm=normal_norm,
        tangent_energy_ratio=float(tangent_norm**2 / max(residual_norm**2, 1e-24)),
        projection_error_norm=projection_error,
        descent_direction=is_descent,
    )
    return best, diagnostics


def select_target_pareto_signed_tangent(
    *,
    selector_clients: list,
    eval_clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    geo_adapters: list[LoRAAdapter],
    signed_adapters: list[LoRAAdapter],
    loss_margin: float = 0.0,
    seed: int = 0,
    dataset: str = "",
    heterogeneity_setting: str = "",
    round_id: int = 0,
    method: str = "FedAdapterManifold-SignedTangentAdmit",
) -> SignedTangentAdmissionResult:
    """Select one training-fixed signed candidate against two fixed anchors.

    The three-member pool is fixed before calibration. The best Local/Geo
    anchor is selected on calibration with Local-first exact ties. The signed
    endpoint is admitted only when it strictly lowers calibration error and
    loss while not increasing Brier risk. Test labels are evaluated only after
    this decision has been frozen.
    """

    n = len(selector_clients)
    collections = [eval_clients, local_adapters, geo_adapters, signed_adapters]
    if any(len(items) != n for items in collections):
        raise ValueError("Selector, evaluation, and candidate collections must align")
    selected: list[LoRAAdapter] = []
    metrics_rows: list[dict] = []
    admission_rows: list[dict] = []
    for index, (selector, evaluator) in enumerate(zip(selector_clients, eval_clients)):
        candidates = {
            "Local-LoRA": local_adapters[index],
            "Geo-only-Agg": geo_adapters[index],
            "FAM-SignedTangent": signed_adapters[index],
        }
        calibration = {
            name: _classification_metrics(
                selector.x_train,
                selector.y_train,
                base_weight,
                adapter,
            )
            for name, adapter in candidates.items()
        }
        anchor_names = ["Local-LoRA", "Geo-only-Agg"]
        anchor_name = min(
            anchor_names,
            key=lambda name: (
                -float(calibration[name]["accuracy"]),
                float(calibration[name]["loss"]),
                anchor_names.index(name),
            ),
        )
        anchor_metrics = calibration[anchor_name]
        signed_metrics = calibration["FAM-SignedTangent"]
        admitted = bool(
            float(signed_metrics["accuracy"]) > float(anchor_metrics["accuracy"]) + 1e-12
            and float(signed_metrics["loss"]) < float(anchor_metrics["loss"]) - float(loss_margin) - 1e-12
            and float(signed_metrics["brier"]) <= float(anchor_metrics["brier"]) + 1e-12
        )
        selected_name = "FAM-SignedTangent" if admitted else anchor_name
        selected_adapter = candidates[selected_name].copy(name=f"{method}-client-{index}")
        selected.append(selected_adapter)
        test_metrics = evaluate_adapter(
            evaluator.x_test,
            evaluator.y_test,
            base_weight,
            selected_adapter,
        )
        metrics_rows.append(
            {
                "method": method,
                "seed": int(seed),
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": int(round_id),
                "client_id": evaluator.client_id,
                "domain": evaluator.domain,
                "accuracy": float(test_metrics["accuracy"]),
                "loss": float(test_metrics["loss"]),
                "rank": int(selected_adapter.rank),
                "selected_transport_family": selected_name,
                "admitted_signed_tangent": admitted,
            }
        )
        for name, adapter in candidates.items():
            candidate_test = evaluate_adapter(
                evaluator.x_test,
                evaluator.y_test,
                base_weight,
                adapter,
            )
            admission_rows.append(
                {
                    "method": method,
                    "seed": int(seed),
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": int(round_id),
                    "client_id": evaluator.client_id,
                    "domain": evaluator.domain,
                    "candidate_method": name,
                    "is_anchor": name in anchor_names,
                    "best_anchor_method": anchor_name,
                    "calibration_size": int(selector.y_train.size),
                    "calibration_accuracy": float(calibration[name]["accuracy"]),
                    "calibration_loss": float(calibration[name]["loss"]),
                    "calibration_brier": float(calibration[name]["brier"]),
                    "loss_margin": float(loss_margin),
                    "signed_candidate_admissible": admitted if name == "FAM-SignedTangent" else "",
                    "selected_method": selected_name,
                    "selected": name == selected_name,
                    "test_accuracy_post_selection_audit": float(candidate_test["accuracy"]),
                    "test_loss_post_selection_audit": float(candidate_test["loss"]),
                    "test_used_for_selection": False,
                }
            )
    return SignedTangentAdmissionResult(selected, metrics_rows, admission_rows)


def _classification_metrics(
    x: Array,
    y: Array,
    base_weight: Array,
    adapter: LoRAAdapter,
) -> dict[str, float]:
    logits = predict_with_weight(x, adapter.weight(base_weight))
    probabilities = softmax(logits)
    labels = np.asarray(y, dtype=np.int64)
    targets = np.zeros_like(probabilities)
    targets[np.arange(labels.size), labels] = 1.0
    return {
        **evaluate_adapter(x, labels, base_weight, adapter),
        "brier": float(np.mean(np.sum((probabilities - targets) ** 2, axis=1))),
    }


def _classification_metrics_with_correctness(
    x: Array,
    y: Array,
    base_weight: Array,
    adapter: LoRAAdapter,
) -> dict[str, float | list[int]]:
    labels = np.asarray(y, dtype=np.int64)
    metrics = _classification_metrics(x, labels, base_weight, adapter)
    logits = predict_with_weight(np.asarray(x, dtype=np.float64), adapter.weight(base_weight))
    return {
        **metrics,
        "correctness": (logits.argmax(axis=1) == labels).astype(np.int64).tolist(),
    }


def _orth(matrix: Array, tol: float = 1e-10) -> Array:
    matrix = np.nan_to_num(np.asarray(matrix, dtype=np.float64))
    if matrix.ndim != 2 or matrix.size == 0:
        rows = matrix.shape[0] if matrix.ndim == 2 else 0
        return np.zeros((rows, 0), dtype=np.float64)
    u, singular_values, _ = np.linalg.svd(matrix, full_matrices=False)
    if singular_values.size == 0:
        return np.zeros((matrix.shape[0], 0), dtype=np.float64)
    threshold = float(tol) * max(matrix.shape) * max(float(singular_values[0]), 1.0)
    rank = int(np.sum(singular_values > threshold))
    return u[:, :rank]
