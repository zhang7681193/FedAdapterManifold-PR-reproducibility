from __future__ import annotations

from dataclasses import dataclass

import numpy as np


Array = np.ndarray


@dataclass(frozen=True)
class SourceCoverageResult:
    """First-order coverage of a receiver descent direction by donor sources."""

    gradient_norm: float
    atom_coverage: float
    cone_coverage: float
    span_coverage: float
    best_source: int
    best_descent_cosine: float
    positive_sources: int
    active_cone_sources: int
    cone_coefficients: Array
    span_coefficients: Array
    cone_projection: Array
    span_projection: Array
    directional_derivatives: Array


@dataclass(frozen=True)
class CommonDescentResult:
    """Max-min descent direction shared by independent training folds."""

    feasible: bool
    margin: float
    direction: Array
    convex_weights: Array
    projected_gradients: Array
    directional_derivatives: Array
    span_rank: int


def _as_vector(value: Array, name: str) -> Array:
    vector = np.asarray(value, dtype=np.float64).reshape(-1)
    if not np.isfinite(vector).all():
        raise ValueError(f"{name} must contain only finite values")
    return vector


def _normalized_dictionary(directions: Array, dimension: int) -> tuple[Array, Array]:
    matrix = np.asarray(directions, dtype=np.float64)
    if matrix.ndim == 1:
        matrix = matrix[None, :]
    if matrix.ndim != 2 or matrix.shape[1] != dimension:
        raise ValueError("directions must have shape (num_sources, gradient_dimension)")
    if not np.isfinite(matrix).all():
        raise ValueError("directions must contain only finite values")
    norms = np.linalg.norm(matrix, axis=1)
    valid = norms > 1e-12
    normalized = np.zeros_like(matrix)
    normalized[valid] = matrix[valid] / norms[valid, None]
    return normalized, valid


def source_coverage(
    tangent_gradient: Array,
    directions: Array,
    *,
    nnls_maxiter: int | None = None,
) -> SourceCoverageResult:
    """Measure atom, non-negative-cone, and signed-span source coverage.

    ``tangent_gradient`` is the receiver risk gradient projected onto its LoRA
    tangent space. Rows of ``directions`` are receiver-tangent donor residuals.
    Rows are normalized before analysis, so the scores do not depend on donor
    update magnitude. The non-negative cone matches ordinary adapter sharing;
    the signed span is an upper bound that permits extrapolating coefficients.
    """

    gradient = _as_vector(tangent_gradient, "tangent_gradient")
    dictionary, valid = _normalized_dictionary(directions, gradient.size)
    target = -gradient
    target_norm = float(np.linalg.norm(target))
    num_sources = int(dictionary.shape[0])
    zeros = np.zeros(num_sources, dtype=np.float64)
    if target_norm <= 1e-12 or not np.any(valid):
        return SourceCoverageResult(
            gradient_norm=target_norm,
            atom_coverage=0.0,
            cone_coverage=0.0,
            span_coverage=0.0,
            best_source=-1,
            best_descent_cosine=0.0,
            positive_sources=0,
            active_cone_sources=0,
            cone_coefficients=zeros,
            span_coefficients=zeros,
            cone_projection=np.zeros_like(target),
            span_projection=np.zeros_like(target),
            directional_derivatives=dictionary @ gradient,
        )

    valid_indices = np.flatnonzero(valid)
    atoms = dictionary[valid]
    cosines = atoms @ (target / target_norm)
    positive = np.maximum(cosines, 0.0)
    local_best = int(np.argmax(positive))
    best_source = int(valid_indices[local_best]) if positive[local_best] > 0.0 else -1
    atom_coverage = float(positive[local_best])

    # Signed span is the least-squares projection and is an optimistic upper
    # bound on what a source dictionary could express with arbitrary signs.
    span_coefficients_valid, *_ = np.linalg.lstsq(atoms.T, target, rcond=None)
    span_projection = atoms.T @ span_coefficients_valid
    span_coefficients = np.zeros(num_sources, dtype=np.float64)
    span_coefficients[valid] = span_coefficients_valid
    span_coverage = float(np.linalg.norm(span_projection) / target_norm)

    # The non-negative least-squares projection is the Euclidean projection of
    # -gradient onto the donor cone. Import locally to keep the core package
    # usable in minimal NumPy-only debug environments.
    try:
        from scipy.optimize import nnls
    except ImportError as exc:  # pragma: no cover - full experiment environment
        raise RuntimeError("source-cone coverage requires scipy.optimize.nnls") from exc
    coefficients_valid, _ = nnls(atoms.T, target, maxiter=nnls_maxiter)
    cone_projection = atoms.T @ coefficients_valid
    cone_coverage = float(np.linalg.norm(cone_projection) / target_norm)
    cone_coefficients = np.zeros(num_sources, dtype=np.float64)
    cone_coefficients[valid] = coefficients_valid

    # Numerical noise can place a projection infinitesimally outside [0, 1].
    atom_coverage = float(np.clip(atom_coverage, 0.0, 1.0))
    cone_coverage = float(np.clip(cone_coverage, 0.0, 1.0))
    span_coverage = float(np.clip(span_coverage, 0.0, 1.0))
    return SourceCoverageResult(
        gradient_norm=target_norm,
        atom_coverage=atom_coverage,
        cone_coverage=cone_coverage,
        span_coverage=span_coverage,
        best_source=best_source,
        best_descent_cosine=atom_coverage,
        positive_sources=int(np.sum(cosines > 1e-12)),
        active_cone_sources=int(np.sum(coefficients_valid > 1e-10)),
        cone_coefficients=cone_coefficients,
        span_coefficients=span_coefficients,
        cone_projection=cone_projection,
        span_projection=span_projection,
        directional_derivatives=dictionary @ gradient,
    )


def quadratic_cone_decrease_bound(
    coverage: SourceCoverageResult,
    smoothness: float,
) -> float:
    """Return the best smooth quadratic-model decrease attainable in the cone."""

    if not np.isfinite(smoothness) or smoothness <= 0.0:
        raise ValueError("smoothness must be finite and positive")
    projected_norm = coverage.cone_coverage * coverage.gradient_norm
    return float((projected_norm * projected_norm) / (2.0 * smoothness))


def common_descent_in_span(
    fold_gradients: Array,
    directions: Array,
    *,
    tolerance: float = 1e-10,
) -> CommonDescentResult:
    """Find the unit donor-span direction with best worst-fold descent.

    The minimum-norm point ``h_star`` in the convex hull of the fold gradients
    projected into the donor span defines ``d_star=-h_star/||h_star||``.
    Projection optimality gives ``<h_k,d_star> <= -||h_star||`` for every
    fold. If the convex hull contains zero, no strict common descent direction
    exists and the function returns an exact zero fallback.
    """

    gradients = np.asarray(fold_gradients, dtype=np.float64)
    if gradients.ndim != 2 or gradients.shape[0] < 2:
        raise ValueError("fold_gradients must have shape (num_folds >= 2, dimension)")
    if not np.isfinite(gradients).all():
        raise ValueError("fold_gradients must contain only finite values")
    if not np.isfinite(tolerance) or tolerance <= 0.0:
        raise ValueError("tolerance must be finite and positive")
    dictionary, valid = _normalized_dictionary(directions, gradients.shape[1])
    num_folds = int(gradients.shape[0])
    zero_weights = np.full(num_folds, 1.0 / num_folds, dtype=np.float64)
    if not np.any(valid):
        return CommonDescentResult(
            feasible=False,
            margin=0.0,
            direction=np.zeros(gradients.shape[1], dtype=np.float64),
            convex_weights=zero_weights,
            projected_gradients=np.zeros_like(gradients),
            directional_derivatives=np.zeros(num_folds, dtype=np.float64),
            span_rank=0,
        )

    atoms = dictionary[valid]
    _, singular_values, right_vectors = np.linalg.svd(atoms, full_matrices=False)
    rank = int(np.sum(singular_values > tolerance * max(1.0, singular_values[0])))
    if rank <= 0:
        return CommonDescentResult(
            feasible=False,
            margin=0.0,
            direction=np.zeros(gradients.shape[1], dtype=np.float64),
            convex_weights=zero_weights,
            projected_gradients=np.zeros_like(gradients),
            directional_derivatives=np.zeros(num_folds, dtype=np.float64),
            span_rank=0,
        )
    basis = right_vectors[:rank]
    projected = (gradients @ basis.T) @ basis

    try:
        from scipy.optimize import minimize
    except ImportError as exc:  # pragma: no cover - full experiment environment
        raise RuntimeError("common-descent coverage requires scipy.optimize.minimize") from exc

    gram = projected @ projected.T

    def objective(weights: Array) -> float:
        return float(0.5 * weights @ gram @ weights)

    def jacobian(weights: Array) -> Array:
        return gram @ weights

    optimization = minimize(
        objective,
        zero_weights,
        jac=jacobian,
        bounds=[(0.0, 1.0)] * num_folds,
        constraints={"type": "eq", "fun": lambda weights: float(np.sum(weights) - 1.0),
                     "jac": lambda weights: np.ones_like(weights)},
        method="SLSQP",
        options={"ftol": tolerance * tolerance, "maxiter": 1000, "disp": False},
    )
    if not optimization.success:
        raise RuntimeError(f"minimum-norm convex-hull solve failed: {optimization.message}")
    weights = np.asarray(optimization.x, dtype=np.float64)
    weights = np.maximum(weights, 0.0)
    weights /= float(np.sum(weights))
    minimum_norm_point = weights @ projected
    norm = float(np.linalg.norm(minimum_norm_point))
    if norm <= tolerance:
        return CommonDescentResult(
            feasible=False,
            margin=0.0,
            direction=np.zeros(gradients.shape[1], dtype=np.float64),
            convex_weights=weights,
            projected_gradients=projected,
            directional_derivatives=np.zeros(num_folds, dtype=np.float64),
            span_rank=rank,
        )

    direction = -minimum_norm_point / norm
    derivatives = projected @ direction
    margin = float(max(0.0, -np.max(derivatives)))
    feasible = bool(margin > tolerance and np.all(derivatives < -tolerance))
    if not feasible:
        direction = np.zeros_like(direction)
        derivatives = np.zeros(num_folds, dtype=np.float64)
        margin = 0.0
    return CommonDescentResult(
        feasible=feasible,
        margin=margin,
        direction=direction,
        convex_weights=weights,
        projected_gradients=projected,
        directional_derivatives=derivatives,
        span_rank=rank,
    )
