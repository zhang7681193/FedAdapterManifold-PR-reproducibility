from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .adapters import LoRAAdapter


Array = np.ndarray


@dataclass
class TrainStats:
    loss: float
    accuracy: float
    epochs: int
    initial_loss: float = float("nan")
    initial_accuracy: float = float("nan")
    loss_history: list[float] | None = None
    accuracy_history: list[float] | None = None


def softmax(logits: Array) -> Array:
    logits = np.nan_to_num(np.asarray(logits, dtype=np.float64), nan=0.0, posinf=50.0, neginf=-50.0)
    shifted = logits - logits.max(axis=1, keepdims=True)
    exp = np.exp(shifted)
    return exp / np.clip(exp.sum(axis=1, keepdims=True), 1e-12, None)


def cross_entropy_and_grad(logits: Array, y: Array) -> tuple[float, Array]:
    probs = softmax(logits)
    n = y.shape[0]
    loss = -np.log(np.clip(probs[np.arange(n), y], 1e-12, None)).mean()
    grad = probs
    grad[np.arange(n), y] -= 1.0
    grad /= float(n)
    return float(loss), grad


def cross_entropy_per_sample(logits: Array, y: Array) -> Array:
    probs = softmax(logits)
    y = y.astype(np.int64)
    n = y.shape[0]
    return -np.log(np.clip(probs[np.arange(n), y], 1e-12, None))


def predict_with_weight(x: Array, weight: Array) -> Array:
    x = np.nan_to_num(np.asarray(x, dtype=np.float64), nan=0.0, posinf=0.0, neginf=0.0)
    weight = np.nan_to_num(np.asarray(weight, dtype=np.float64), nan=0.0, posinf=1e6, neginf=-1e6)
    return x @ weight.T


def evaluate_weight(x: Array, y: Array, weight: Array) -> dict[str, float]:
    logits = predict_with_weight(x, weight)
    loss, _ = cross_entropy_and_grad(logits.copy(), y.astype(np.int64))
    pred = logits.argmax(axis=1)
    return {"loss": loss, "accuracy": float((pred == y).mean())}


def evaluate_adapter(x: Array, y: Array, base_weight: Array, adapter: LoRAAdapter) -> dict[str, float]:
    return evaluate_weight(x, y, adapter.weight(base_weight))


def evaluate_adapter_loss_vector(x: Array, y: Array, base_weight: Array, adapter: LoRAAdapter) -> Array:
    logits = predict_with_weight(x, adapter.weight(base_weight))
    return cross_entropy_per_sample(logits, y.astype(np.int64))


def evaluate_adapter_error_vector(x: Array, y: Array, base_weight: Array, adapter: LoRAAdapter) -> Array:
    logits = predict_with_weight(x, adapter.weight(base_weight))
    labels = y.astype(np.int64)
    return (logits.argmax(axis=1) != labels).astype(np.float64)


def train_lora_adapter(
    x: Array,
    y: Array,
    base_weight: Array,
    rank: int,
    init_adapter: LoRAAdapter | None = None,
    prox_adapter: LoRAAdapter | None = None,
    prox_mu: float = 0.0,
    epochs: int = 20,
    lr: float = 0.2,
    batch_size: int = 32,
    weight_decay: float = 1e-4,
    grad_clip_norm: float = 5.0,
    factor_clip_norm: float = 25.0,
    factor_clip_value: float = 5.0,
    train_a: bool = True,
    train_b: bool = True,
    seed: int = 0,
    name: str = "",
) -> tuple[LoRAAdapter, TrainStats]:
    """Train only LoRA factors on frozen features and frozen base_weight."""

    if not bool(train_a) and not bool(train_b):
        raise ValueError("At least one LoRA factor must be trainable")

    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.int64)
    base_weight = np.asarray(base_weight, dtype=np.float64)
    if x.ndim != 2:
        raise ValueError(f"x must be a 2D feature matrix, got shape {x.shape}")
    if y.ndim != 1 or y.shape[0] != x.shape[0]:
        raise ValueError(f"y shape {y.shape} is incompatible with x shape {x.shape}")
    output_dim, input_dim = base_weight.shape
    if input_dim != x.shape[1]:
        raise ValueError(f"base_weight input_dim {input_dim} does not match x feature_dim {x.shape[1]}")
    if y.size and (int(y.min()) < 0 or int(y.max()) >= output_dim):
        raise ValueError(f"labels must be in [0, {output_dim - 1}]")
    rank = int(rank)
    if rank <= 0:
        raise ValueError("rank must be positive")
    rng = np.random.default_rng(seed)
    if init_adapter is None:
        adapter = LoRAAdapter.random(
            input_dim=input_dim,
            output_dim=output_dim,
            rank=rank,
            rng=rng,
            alpha=float(rank),
            name=name,
            zero_b=True,
        )
    else:
        adapter = init_adapter.projected(rank, name=name) if init_adapter.rank != rank else init_adapter.copy(name=name)
    _stabilize_adapter(adapter, max_norm=factor_clip_norm, max_abs=factor_clip_value)
    prox_reference = None
    prox_mu = float(max(0.0, prox_mu))
    if prox_adapter is not None and prox_mu > 0.0:
        prox_reference = _prox_reference_adapter(prox_adapter, rank, input_dim, output_dim)

    n = x.shape[0]
    batch_size = int(max(1, min(batch_size, n)))
    initial_metrics = evaluate_adapter(x, y, base_weight, adapter)
    loss_history = [initial_metrics["loss"]]
    accuracy_history = [initial_metrics["accuracy"]]
    for _ in range(int(epochs)):
        order = rng.permutation(n)
        for start in range(0, n, batch_size):
            idx = order[start : start + batch_size]
            xb = x[idx]
            yb = y[idx]
            weight = adapter.weight(base_weight)
            logits = xb @ weight.T
            _, grad_logits = cross_entropy_and_grad(logits, yb)
            grad_w = grad_logits.T @ xb
            grad_b = adapter.scale * (grad_w @ adapter.A.T) + weight_decay * adapter.B
            grad_a = adapter.scale * (adapter.B.T @ grad_w) + weight_decay * adapter.A
            if prox_reference is not None:
                grad_b += prox_mu * (adapter.B - prox_reference.B)
                grad_a += prox_mu * (adapter.A - prox_reference.A)
            grad_a = np.nan_to_num(grad_a, nan=0.0, posinf=0.0, neginf=0.0)
            grad_b = np.nan_to_num(grad_b, nan=0.0, posinf=0.0, neginf=0.0)
            grad_a, grad_b = _clip_pair_by_norm(grad_a, grad_b, grad_clip_norm)
            if bool(train_b):
                adapter.B -= lr * grad_b
            if bool(train_a):
                adapter.A -= lr * grad_a
            _stabilize_adapter(adapter, max_norm=factor_clip_norm, max_abs=factor_clip_value)
        epoch_metrics = evaluate_adapter(x, y, base_weight, adapter)
        loss_history.append(epoch_metrics["loss"])
        accuracy_history.append(epoch_metrics["accuracy"])

    metrics = evaluate_adapter(x, y, base_weight, adapter)
    return adapter, TrainStats(
        loss=metrics["loss"],
        accuracy=metrics["accuracy"],
        epochs=epochs,
        initial_loss=initial_metrics["loss"],
        initial_accuracy=initial_metrics["accuracy"],
        loss_history=loss_history,
        accuracy_history=accuracy_history,
    )


def _clip_pair_by_norm(a: Array, b: Array, max_norm: float) -> tuple[Array, Array]:
    max_norm = float(max_norm)
    if max_norm <= 0.0:
        return a, b
    norm = float(np.sqrt(np.sum(a * a) + np.sum(b * b)))
    if not np.isfinite(norm) or norm <= max_norm:
        return a, b
    scale = max_norm / np.clip(norm, 1e-12, None)
    return a * scale, b * scale


def _stabilize_adapter(adapter: LoRAAdapter, max_norm: float, max_abs: float) -> None:
    adapter.A = np.nan_to_num(adapter.A, nan=0.0, posinf=max_abs, neginf=-max_abs)
    adapter.B = np.nan_to_num(adapter.B, nan=0.0, posinf=max_abs, neginf=-max_abs)
    adapter.A = np.clip(adapter.A, -max_abs, max_abs)
    adapter.B = np.clip(adapter.B, -max_abs, max_abs)
    _clip_matrix_in_place(adapter.A, max_norm)
    _clip_matrix_in_place(adapter.B, max_norm)


def _prox_reference_adapter(prox_adapter: LoRAAdapter, rank: int, input_dim: int, output_dim: int) -> LoRAAdapter:
    if prox_adapter.input_dim != input_dim or prox_adapter.output_dim != output_dim:
        raise ValueError(
            "prox_adapter dimensions do not match base_weight: "
            f"{(prox_adapter.output_dim, prox_adapter.input_dim)} != {(output_dim, input_dim)}"
        )
    if prox_adapter.rank == rank:
        return prox_adapter.copy(name="prox_reference")
    if float(np.linalg.norm(prox_adapter.delta())) <= 1e-12:
        return LoRAAdapter.zeros(
            input_dim=input_dim,
            output_dim=output_dim,
            rank=rank,
            alpha=float(rank),
            name="prox_reference_zero",
        )
    return prox_adapter.projected(rank, name="prox_reference")


def _clip_matrix_in_place(matrix: Array, max_norm: float) -> None:
    max_norm = float(max_norm)
    if max_norm <= 0.0:
        return
    norm = float(np.linalg.norm(matrix))
    if np.isfinite(norm) and norm > max_norm:
        matrix *= max_norm / np.clip(norm, 1e-12, None)


def train_federated_global(
    clients: list,
    base_weight: Array,
    ranks: list[int],
    aggregate_fn,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    name: str,
    prox_mu: float = 0.0,
    weight_decay: float = 1e-4,
) -> tuple[LoRAAdapter, list[dict]]:
    """Run a simple synchronous FL loop over LoRA adapters."""

    target_rank = int(max(ranks))
    # Every client must receive the same server initialization.  Initializing
    # A independently on each client creates an artificial gauge mismatch in
    # the first round and is not the standard synchronous FL protocol.
    initial_adapters = {
        int(rank): LoRAAdapter.random(
            input_dim=base_weight.shape[1],
            output_dim=base_weight.shape[0],
            rank=int(rank),
            rng=np.random.default_rng(seed + 7919 * int(rank)),
            alpha=float(rank),
            name=f"{name}_shared_init_r{int(rank)}",
            zero_b=True,
        )
        for rank in sorted(set(int(value) for value in ranks))
    }
    global_adapter = LoRAAdapter.random(
        input_dim=base_weight.shape[1],
        output_dim=base_weight.shape[0],
        rank=target_rank,
        rng=np.random.default_rng(seed + 7919 * target_rank),
        alpha=float(target_rank),
        name=f"{name}_global_init",
        zero_b=True,
    )
    history: list[dict] = []
    sample_weights = np.array([len(c.y_train) for c in clients], dtype=np.float64)
    sample_weights /= np.clip(sample_weights.sum(), 1e-12, None)
    for round_id in range(int(rounds)):
        local_adapters: list[LoRAAdapter] = []
        for client_idx, client in enumerate(clients):
            init_adapter = initial_adapters[int(ranks[client_idx])] if round_id == 0 else global_adapter
            prox_adapter = global_adapter if prox_mu > 0.0 else None
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                base_weight,
                rank=ranks[client_idx],
                init_adapter=init_adapter,
                prox_adapter=prox_adapter,
                prox_mu=prox_mu,
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                weight_decay=weight_decay,
                seed=seed + 1000 * round_id + client_idx,
                name=f"{name}_{client.client_id}_r{round_id}",
            )
            local_adapters.append(adapter)
            history.append(
                {
                    "round": round_id + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": adapter.rank,
                }
            )
        global_adapter = aggregate_fn(
            local_adapters,
            weights=sample_weights,
            target_rank=target_rank,
            name=f"{name}_global_r{round_id + 1}",
        )
    return global_adapter, history
