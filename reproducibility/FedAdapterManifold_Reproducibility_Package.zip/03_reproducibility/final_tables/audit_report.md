# Final Exact Manuscript Table Audit

- All table sources are registered as frozen.
- Client-level values were recomputed rather than copied from manuscript prose.
- Manuscript literal check: PASS.

## Receiver-admission rows

- Local/Geo: anchor=0.648750, candidate=0.774375, deploy=0.699375, gain=+0.050625, CI=[0.013125,0.095312], admit=6/20, harm=0, uncertified=0.
- Subspace-Reg: anchor=0.712500, candidate=0.772188, deploy=0.726562, gain=+0.014063, CI=[0.002187,0.025938], admit=3/20, harm=0, uncertified=0.

## Missing manuscript literals

- None.
