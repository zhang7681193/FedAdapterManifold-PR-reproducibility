# Geometry-provider stability and re-certification

## Problem decomposition

Let a geometry provider version `g` expose, for receiver `i`, a client order,
graph support `S_i^g`, visual distances `d_geo^g(i,j)`, and prototype anchors.
Changing the provider can affect four distinct objects:

1. **Identity drift:** client order or label support changes.
2. **Topology drift:** the positive donor support changes.
3. **Metric drift:** distances change on a fixed support.
4. **Anchor drift:** class prototypes change while the client graph remains fixed.

Only metric drift on a fixed identity/topology contract admits a direct smooth
perturbation bound. Identity or topology drift changes the candidate family and
therefore requires endpoint regeneration. Prototype drift requires routing replay
unless the input-level assignment margins are also certified.

## Fixed-support Gibbs stability

For fixed receiver support `S_i`, write

`c_ij^g = q_ij + lambda_geo d_geo^g(i,j)`,

where `q_ij` contains the adapter-subspace, label-support, and other terms that
are held fixed in this comparison. The routing weights are

`beta_ij^g = exp(-c_ij^g/tau) / sum_{l in S_i} exp(-c_il^g/tau)`.

If

`max_{j in S_i} |c_ij^g - c_ij^{g'}| <= epsilon_i`,

then the likelihood ratio between the two Gibbs distributions is bounded and

`||beta_i^g - beta_i^{g'}||_1 <= 2 tanh(epsilon_i/tau)
                                  <= 2 epsilon_i/tau`.

For transported donor updates with `||T_ij(Delta_j)||_F <= R_i`, the candidate
adapter perturbation satisfies

`||Delta_i^g - Delta_i^{g'}||_F
   <= 2 R_i tanh(epsilon_i/tau)`.

This is a candidate-stability result. It is not, by itself, permission to reuse
an old deployment certificate.

## When the receiver decision is unchanged

Suppose calibration logits are `L_f`-Lipschitz in the adapter and every
calibration example has top-1 logit margin greater than

`4 L_f R_i tanh(epsilon_i/tau)`.

Then the predicted labels of both candidate and anchor are unchanged, so the
paired exact outcomes and the serial-Holm admission decision are unchanged. A
continuous loss gate has the analogous sufficient condition that its declared
candidate-versus-anchor margin exceed twice the corresponding Lipschitz loss
perturbation.

These margins are sufficient, not necessary. When they are not recorded, the
safe operation is inexpensive certificate replay, not silent provider
replacement and not necessarily full adapter retraining.

## Frozen Geometry Contract

The resulting operational rule has three levels:

1. **Exact hash match:** reuse the frozen result.
2. **Same client order and graph support, different metric/prototype hash:**
   regenerate or replay the affected endpoint and rerun the receiver certificate.
3. **Changed client order or graph support:** regenerate the endpoint and rerun
   the receiver certificate. Previously reported results are not inherited.

No later FedGeo revision is automatically substituted into a manuscript table.
FedGeo remains one provider of candidate geometry; adapter-subspace admissibility
and the receiver certificate remain the contribution evaluated in this project.

## Empirical check

The released audit uses every main-table frozen snapshot. At 1%, 5%, and 10%
fixed-support distance perturbation it evaluates 390 receiver units. All 390
obey the Gibbs stability bound. The maximum route-weight L1 changes are 0.0055,
0.0275, and 0.0548, respectively, with no top-donor change.

An actual four-provider comparison on PACS and OfficeCaltech uses FedAvg,
top-k, utility-only, and full geometry outputs for three seeds. All 72 receiver
comparisons retain graph support and the top donor; maximum route L1 drift is
0.0209. Because the provider hashes differ and calibration logit margins were
not part of the old provider artifact, the contract correctly requires
certificate replay rather than claiming automatic interchangeability.

The experiment therefore supports both parts of the solution: small metric
perturbations produce bounded candidate drift, while versioned scientific inputs
must still be frozen or re-certified before they replace reported evidence.
