from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path
from typing import Iterable


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Aggregate completed federated CLIP ViT LoRA seed directories.")
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--seed-dir", action="append", default=[], help="Repeated mapping seed=path/to/seed_dir.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    seed_dirs = [_parse_seed_dir(value) for value in args.seed_dir]
    if not seed_dirs:
        raise ValueError("At least one --seed-dir seed=path is required.")

    runs: list[dict] = []
    metrics: list[dict] = []
    per_client: list[dict] = []
    subspace: list[dict] = []
    conflicts: list[dict] = []
    bank_weights: list[dict] = []
    selection: list[dict] = []
    for seed, seed_dir in seed_dirs:
        missing = [name for name in ["metrics.csv", "per_client_metrics.csv", "subspace_metrics.csv"] if not (seed_dir / name).exists()]
        if missing:
            raise FileNotFoundError(f"Seed {seed} is incomplete at {seed_dir}: missing {', '.join(missing)}")
        runs.append({"seed": seed, "output_dir": str(seed_dir), "exit_code": 0})
        for rows, name in [
            (metrics, "metrics.csv"),
            (per_client, "per_client_metrics.csv"),
            (subspace, "subspace_metrics.csv"),
            (conflicts, "adapter_conflict.csv"),
            (bank_weights, "adapter_bank_weights.csv"),
            (selection, "candidate_selection.csv"),
        ]:
            for row in read_csv(seed_dir / name):
                row["source_seed"] = seed
                rows.append(row)

    write_csv(output_root / "runs.csv", runs)
    write_csv(output_root / "multiseed_metrics.csv", aggregate_metrics(metrics))
    write_csv(output_root / "multiseed_per_client_metrics.csv", per_client)
    write_csv(output_root / "multiseed_subspace_metrics.csv", subspace)
    write_csv(output_root / "multiseed_adapter_conflict.csv", conflicts)
    write_csv(output_root / "multiseed_adapter_bank_weights.csv", bank_weights)
    write_csv(output_root / "multiseed_candidate_selection.csv", selection)
    safety_rows = certificate_safety_audit(per_client, selection)
    safety_summary = certificate_safety_summary(safety_rows)
    write_csv(output_root / "certificate_safety_audit.csv", safety_rows)
    write_csv(output_root / "certificate_safety_summary.csv", safety_summary)
    write_csv(output_root / "paired_significance.csv", paired_significance(per_client))
    write_csv(output_root / "seed_clustered_paired_significance.csv", seed_clustered_paired_significance(per_client))
    write_csv(output_root / "subspace_correlation_summary.csv", subspace_summary(subspace))
    write_report(output_root / "multiseed_report.md", output_root)
    if safety_summary and not (
        bool(safety_summary[0]["zero_harm_gate_passed"])
        and bool(safety_summary[0]["certificate_integrity_passed"])
    ):
        print("Exact-certificate safety gate failed.")
        return 2
    return 0


def aggregate_metrics(rows: list[dict]) -> list[dict]:
    out: list[dict] = []
    methods = sorted({row.get("method", "") for row in rows if row.get("method")})
    for method in methods:
        group = [row for row in rows if row.get("method") == method]
        acc = [fnum(row.get("mean_accuracy")) for row in group]
        loss = [fnum(row.get("mean_loss")) for row in group]
        risk = [fnum(row.get("worst_client_risk")) for row in group]
        conflict = [fnum(row.get("mean_update_conflict_vs_local")) for row in group]
        first = group[0] if group else {}
        ci_low, ci_high = bootstrap_ci(acc)
        out.append(
            {
                "method": method,
                "mean_accuracy": mean(acc),
                "std_accuracy": std(acc),
                "ci_low_accuracy": ci_low,
                "ci_high_accuracy": ci_high,
                "mean_loss": mean(loss),
                "mean_worst_client_risk": mean(risk),
                "mean_update_conflict_vs_local": mean(conflict),
                "num_seeds": len({row.get("source_seed") for row in group}),
                "num_observations": len(group),
                "dataset": first.get("dataset", ""),
                "heterogeneity": first.get("heterogeneity", ""),
                "round": first.get("round", ""),
            }
        )
    return out


def paired_significance(rows: list[dict]) -> list[dict]:
    methods = sorted({row.get("method", "") for row in rows if row.get("method")})
    baselines = ["FedAvg-CLIP-LoRA", "FedGeo-Agg-CLIP-LoRA", "Local-CLIP-LoRA", "CLIP-ZeroShot"]
    by_key: dict[tuple[str, str], dict[str, float]] = {}
    for row in rows:
        key = (row.get("source_seed", row.get("seed", "")), row.get("client_id", ""))
        by_key.setdefault(key, {})
        by_key[key][row.get("method", "")] = fnum(row.get("accuracy"))
    out: list[dict] = []
    for method in methods:
        for baseline in baselines:
            if method == baseline:
                continue
            diffs = [
                vals[method] - vals[baseline]
                for vals in by_key.values()
                if method in vals and baseline in vals and math.isfinite(vals[method]) and math.isfinite(vals[baseline])
            ]
            if not diffs:
                continue
            ci_low, ci_high = bootstrap_ci(diffs)
            out.append(
                {
                    "method": method,
                    "baseline": baseline,
                    "paired_units": len(diffs),
                    "mean_accuracy_diff": mean(diffs),
                    "ci_low": ci_low,
                    "ci_high": ci_high,
                    "sign_flip_p_value": sign_flip_p_value(diffs),
                    "supports_positive_gain": bool(mean(diffs) > 0.0 and ci_low > 0.0),
                }
            )
    return out


def seed_clustered_paired_significance(rows: list[dict]) -> list[dict]:
    """Treat independent training seeds, not client-seed rows, as inference units."""

    methods = sorted({row.get("method", "") for row in rows if row.get("method")})
    baselines = ["FedAvg-CLIP-LoRA", "FedGeo-Agg-CLIP-LoRA", "Local-CLIP-LoRA", "FedAvg-Lift-CLIP-LoRA"]
    by_key: dict[tuple[str, str], dict[str, float]] = {}
    for row in rows:
        key = (str(row.get("source_seed", row.get("seed", ""))), str(row.get("client_id", "")))
        by_key.setdefault(key, {})[row.get("method", "")] = fnum(row.get("accuracy"))
    out: list[dict] = []
    for method in methods:
        for baseline in baselines:
            if method == baseline:
                continue
            by_seed: dict[str, list[float]] = {}
            for (seed, _), values in by_key.items():
                if method in values and baseline in values and math.isfinite(values[method]) and math.isfinite(values[baseline]):
                    by_seed.setdefault(seed, []).append(values[method] - values[baseline])
            seed_means = [mean(values) for _, values in sorted(by_seed.items())]
            if not seed_means:
                continue
            ci_low, ci_high = bootstrap_ci(seed_means)
            out.append(
                {
                    "method": method,
                    "baseline": baseline,
                    "independent_seed_clusters": len(seed_means),
                    "client_seed_rows": sum(len(values) for values in by_seed.values()),
                    "mean_accuracy_diff": mean(seed_means),
                    "seed_cluster_ci_low": ci_low,
                    "seed_cluster_ci_high": ci_high,
                    "one_sided_seed_sign_flip_p": one_sided_sign_flip_p_value(seed_means),
                    "positive_seed_count": sum(value > 0.0 for value in seed_means),
                    "negative_seed_count": sum(value < 0.0 for value in seed_means),
                    "supports_positive_seed_cluster_gain": bool(mean(seed_means) > 0.0 and ci_low > 0.0),
                }
            )
    return out


def subspace_summary(rows: list[dict]) -> list[dict]:
    by_seed: dict[str, dict[str, float]] = {}
    for row in rows:
        seed = row.get("source_seed", row.get("seed", ""))
        by_seed.setdefault(seed, {})
        for key in ["subspace_failure_pearson_r", "geometry_failure_pearson_r"]:
            value = fnum(row.get(key))
            if math.isfinite(value):
                by_seed[seed][key] = value
    out: list[dict] = []
    for key in ["subspace_failure_pearson_r", "geometry_failure_pearson_r"]:
        values = [item[key] for item in by_seed.values() if key in item]
        ci_low, ci_high = bootstrap_ci(values)
        out.append(
            {
                "measure": key,
                "mean": mean(values),
                "std": std(values),
                "ci_low": ci_low,
                "ci_high": ci_high,
                "num_seeds": len(values),
                "positive_seed_count": sum(1 for value in values if value > 0),
            }
        )
    return out


def certificate_safety_audit(per_client: list[dict], selection: list[dict]) -> list[dict]:
    """Reconcile every exact-certificate decision with post-selection test data."""

    by_metric: dict[tuple[str, str, str], float] = {}
    for row in per_client:
        key = (
            str(row.get("source_seed", row.get("seed", ""))),
            str(row.get("client_id", "")),
            str(row.get("method", "")),
        )
        by_metric[key] = fnum(row.get("accuracy"))
    audited = []
    for row in selection:
        if str(row.get("selection_protocol", "")) != "receiver_tangent_exact_certificate_v1":
            continue
        if not as_bool(row.get("screen_selected", False)):
            continue
        seed = str(row.get("source_seed", row.get("seed", "")))
        client = str(row.get("client_id", ""))
        deployed = str(row.get("deployed_method", ""))
        local_key = (seed, client, "Local-CLIP-LoRA")
        certified_key = (seed, client, "FedAdapterManifold-Tangent-Certified-CLIP-LoRA")
        if local_key not in by_metric or certified_key not in by_metric:
            raise ValueError(f"Missing Local/certified metric for seed={seed}, client={client}")
        local_accuracy = by_metric[local_key]
        deployed_accuracy = by_metric[certified_key]
        gain = deployed_accuracy - local_accuracy
        nonlocal_deployed = deployed != "Local-CLIP-LoRA"
        geo_certified = as_bool(row.get("geo_certified_vs_local", False))
        fam_local = as_bool(row.get("fam_certified_vs_local", False))
        fam_geo = as_bool(row.get("fam_certified_vs_geo", False))
        if deployed == "Local-CLIP-LoRA":
            required_edges_certified = True
        elif deployed == "FedGeo-Agg-CLIP-LoRA":
            required_edges_certified = geo_certified
        else:
            required_edges_certified = fam_local and (not geo_certified or fam_geo)
        audited.append(
            {
                "source_seed": seed,
                "client_id": client,
                "domain": row.get("domain", ""),
                "deployed_method": deployed,
                "nonlocal_deployed": nonlocal_deployed,
                "required_edges_certified": required_edges_certified,
                "geo_certified_vs_local": geo_certified,
                "fam_certified_vs_local": fam_local,
                "fam_certified_vs_geo": fam_geo,
                "local_test_accuracy": local_accuracy,
                "deployed_test_accuracy": deployed_accuracy,
                "test_accuracy_gain_vs_local": gain,
                "harmful_nonlocal_test_unit": bool(nonlocal_deployed and gain < -1e-12),
                "test_used_for_selection": False,
            }
        )
    return audited


def certificate_safety_summary(rows: list[dict]) -> list[dict]:
    if not rows:
        return []
    gains = [fnum(row.get("test_accuracy_gain_vs_local")) for row in rows]
    nonlocal_rows = [row for row in rows if as_bool(row.get("nonlocal_deployed"))]
    harmful = [row for row in rows if as_bool(row.get("harmful_nonlocal_test_unit"))]
    uncertified = [row for row in rows if not as_bool(row.get("required_edges_certified"))]
    return [
        {
            "client_seed_units": len(rows),
            "nonlocal_deployments": len(nonlocal_rows),
            "harmful_nonlocal_test_units": len(harmful),
            "uncertified_nonlocal_deployments": len(uncertified),
            "mean_accuracy_gain_vs_local": mean(gains),
            "zero_harm_gate_passed": len(harmful) == 0,
            "certificate_integrity_passed": len(uncertified) == 0,
        }
    ]


def read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    if not fieldnames:
        fieldnames = ["empty"]
        rows = [{"empty": ""}]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_report(path: Path, output_root: Path) -> None:
    metrics = read_csv(output_root / "multiseed_metrics.csv")
    paired = read_csv(output_root / "seed_clustered_paired_significance.csv")
    lines = [
        "# Federated CLIP ViT LoRA Multiseed Report",
        "",
        "| Method | Mean accuracy | CI low | CI high |",
        "|---|---:|---:|---:|",
    ]
    for row in sorted(metrics, key=lambda item: fnum(item.get("mean_accuracy")), reverse=True):
        lines.append(
            f"| {row.get('method','')} | {fnum(row.get('mean_accuracy')):.4f} | {fnum(row.get('ci_low_accuracy')):.4f} | {fnum(row.get('ci_high_accuracy')):.4f} |"
        )
    lines.extend(["", "## Key paired gains", "", "| Method | Baseline | Diff | CI low | Supports |", "|---|---|---:|---:|---|"])
    for row in paired:
        if row.get("method") in {
            "FedAdapterManifold-CLIP-LoRA",
            "FedAdapterManifold-Selective-CLIP-LoRA",
            "FedAdapterManifold-Tangent-Admit-CLIP-LoRA",
            "FedAdapterManifold-Tangent-Certified-CLIP-LoRA",
        }:
            lines.append(
                f"| {row.get('method','')} | {row.get('baseline','')} | {fnum(row.get('mean_accuracy_diff')):.4f} | {fnum(row.get('seed_cluster_ci_low')):.4f} | {row.get('supports_positive_seed_cluster_gain','')} |"
            )
    safety = read_csv(output_root / "certificate_safety_summary.csv")
    if safety:
        row = safety[0]
        lines.extend(
            [
                "",
                "## Exact-certificate safety audit",
                "",
                f"- Client-seed units: {row.get('client_seed_units', '')}",
                f"- Non-local deployments: {row.get('nonlocal_deployments', '')}",
                f"- Harmful non-local test units: {row.get('harmful_nonlocal_test_units', '')}",
                f"- Uncertified non-local deployments: {row.get('uncertified_nonlocal_deployments', '')}",
                f"- Zero-harm gate passed: {row.get('zero_harm_gate_passed', '')}",
            ]
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def bootstrap_ci(values: Iterable[float], reps: int = 4000) -> tuple[float, float]:
    vals = [float(value) for value in values if math.isfinite(float(value))]
    if not vals:
        return float("nan"), float("nan")
    if len(vals) == 1:
        return vals[0], vals[0]
    rng = deterministic_rng(29 + len(vals))
    means: list[float] = []
    n = len(vals)
    for _ in range(reps):
        total = 0.0
        for _ in range(n):
            total += vals[int(next(rng) * n) % n]
        means.append(total / n)
    means.sort()
    return means[int(0.025 * reps)], means[int(0.975 * reps)]


def sign_flip_p_value(values: list[float], reps: int = 8192) -> float:
    if not values:
        return float("nan")
    observed = abs(mean(values))
    if len(values) <= 20:
        total = 1 << len(values)
        extreme = 0
        for mask in range(total):
            flipped = 0.0
            for idx, value in enumerate(values):
                flipped += value if (mask >> idx) & 1 else -value
            if abs(flipped / len(values)) >= observed - 1e-12:
                extreme += 1
        return extreme / total
    rng = deterministic_rng(913 + len(values))
    extreme = 0
    for _ in range(reps):
        flipped = sum(value if next(rng) >= 0.5 else -value for value in values)
        if abs(flipped / len(values)) >= observed - 1e-12:
            extreme += 1
    return extreme / reps


def one_sided_sign_flip_p_value(values: list[float], reps: int = 8192) -> float:
    if not values:
        return float("nan")
    observed = mean(values)
    if len(values) <= 20:
        total = 1 << len(values)
        extreme = 0
        for mask in range(total):
            flipped = sum(value if (mask >> idx) & 1 else -value for idx, value in enumerate(values))
            if flipped / len(values) >= observed - 1e-12:
                extreme += 1
        return extreme / total
    rng = deterministic_rng(1907 + len(values))
    extreme = 0
    for _ in range(reps):
        flipped = sum(value if next(rng) >= 0.5 else -value for value in values)
        if flipped / len(values) >= observed - 1e-12:
            extreme += 1
    return extreme / reps


def deterministic_rng(seed: int):
    state = int(seed) & 0x7FFFFFFF
    while True:
        state = (1103515245 * state + 12345) & 0x7FFFFFFF
        yield state / 0x80000000


def mean(values: Iterable[float]) -> float:
    vals = [float(value) for value in values if math.isfinite(float(value))]
    return sum(vals) / len(vals) if vals else float("nan")


def std(values: Iterable[float]) -> float:
    vals = [float(value) for value in values if math.isfinite(float(value))]
    if len(vals) <= 1:
        return 0.0 if vals else float("nan")
    mu = mean(vals)
    return math.sqrt(sum((value - mu) ** 2 for value in vals) / (len(vals) - 1))


def fnum(value, default: float = float("nan")) -> float:
    try:
        if value in {"", None}:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def as_bool(value) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def _parse_seed_dir(value: str) -> tuple[int, Path]:
    if "=" not in value:
        raise ValueError(f"Invalid --seed-dir {value!r}; expected seed=path")
    seed, path = value.split("=", 1)
    return int(seed.strip()), Path(path.strip())


if __name__ == "__main__":
    raise SystemExit(main())
