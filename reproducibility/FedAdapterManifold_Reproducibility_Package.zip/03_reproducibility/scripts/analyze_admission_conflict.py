from __future__ import annotations

import argparse
import csv
import itertools
from pathlib import Path

import numpy as np


METRICS = (
    "subspace_conflict_reduction_vs_fedavg",
    "local_risk_reduction_vs_fedavg",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Clustered inference for semantic-admission conflict reduction.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--method", default="FedAdapterManifold-Admit")
    parser.add_argument("--bootstrap-replicates", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=20260804)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    rows = read_csv(Path(args.input))
    units = collapse_rounds(rows, method=str(args.method))
    if not units:
        raise ValueError(f"No rows found for method {args.method!r}")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(output_dir / "seed_receiver_semantic_conflict.csv", units)
    summary = summarize(
        units,
        replicates=int(args.bootstrap_replicates),
        seed=int(args.seed),
    )
    write_csv(output_dir / "clustered_semantic_admission_statistics.csv", summary)
    write_report(output_dir / "semantic_admission_conflict_report.md", summary)
    return 0


def collapse_rounds(rows: list[dict], method: str) -> list[dict]:
    grouped: dict[tuple[int, str], list[dict]] = {}
    for row in rows:
        if str(row.get("method")) != method:
            continue
        grouped.setdefault((int(row["seed"]), str(row["receiver_client"])), []).append(row)
    output = []
    for (seed, receiver), group in sorted(grouped.items()):
        result = {
            "seed": seed,
            "receiver_client": receiver,
            "round_count": len(group),
        }
        for metric in METRICS:
            result[metric] = float(np.mean([float(row[metric]) for row in group]))
        result["fedavg_subspace_conflict"] = float(
            np.mean([float(row["fedavg_subspace_conflict"]) for row in group])
        )
        result["admitted_subspace_conflict"] = float(
            np.mean([float(row["admitted_subspace_conflict"]) for row in group])
        )
        result["fedavg_local_risk"] = float(np.mean([float(row["fedavg_local_risk"]) for row in group]))
        result["admitted_local_risk"] = float(np.mean([float(row["admitted_local_risk"]) for row in group]))
        output.append(result)
    return output


def summarize(units: list[dict], replicates: int, seed: int) -> list[dict]:
    rng = np.random.default_rng(seed)
    by_seed: dict[int, list[dict]] = {}
    for row in units:
        by_seed.setdefault(int(row["seed"]), []).append(row)
    seed_ids = sorted(by_seed)
    output = []
    for metric in METRICS:
        values = np.asarray([float(row[metric]) for row in units], dtype=np.float64)
        seed_means = np.asarray(
            [np.mean([float(row[metric]) for row in by_seed[seed_id]]) for seed_id in seed_ids],
            dtype=np.float64,
        )
        bootstrap = np.empty(max(1, replicates), dtype=np.float64)
        for replicate in range(bootstrap.size):
            sampled_seeds = rng.choice(seed_ids, size=len(seed_ids), replace=True)
            sampled_values = []
            for sampled_seed in sampled_seeds:
                receiver_rows = by_seed[int(sampled_seed)]
                receiver_indices = rng.integers(0, len(receiver_rows), size=len(receiver_rows))
                sampled_values.extend(float(receiver_rows[index][metric]) for index in receiver_indices)
            bootstrap[replicate] = float(np.mean(sampled_values))
        estimate = float(values.mean())
        denominator_name = "fedavg_subspace_conflict" if metric.startswith("subspace") else "fedavg_local_risk"
        denominator = float(np.mean([float(row[denominator_name]) for row in units]))
        output.append(
            {
                "metric": metric,
                "seed_count": len(seed_ids),
                "receiver_seed_count": len(units),
                "estimate": estimate,
                "ci95_low": float(np.quantile(bootstrap, 0.025)),
                "ci95_high": float(np.quantile(bootstrap, 0.975)),
                "relative_reduction": estimate / denominator if denominator > 1e-12 else float("nan"),
                "positive_seed_count": int(np.sum(seed_means > 0.0)),
                "seed_sign_flip_p_one_sided": exact_sign_flip_p(seed_means),
            }
        )
    return output


def exact_sign_flip_p(seed_effects: np.ndarray) -> float:
    nonzero = np.asarray(seed_effects[np.abs(seed_effects) > 1e-15], dtype=np.float64)
    if nonzero.size == 0:
        return 1.0
    observed = float(nonzero.mean())
    if nonzero.size > 20:
        rng = np.random.default_rng(1729)
        signs = rng.choice((-1.0, 1.0), size=(200000, nonzero.size))
        permuted = np.mean(signs * nonzero[None, :], axis=1)
        return float((np.sum(permuted >= observed) + 1.0) / (permuted.size + 1.0))
    exceed = 0
    total = 0
    for signs in itertools.product((-1.0, 1.0), repeat=nonzero.size):
        total += 1
        if float(np.mean(np.asarray(signs) * nonzero)) >= observed - 1e-15:
            exceed += 1
    return float(exceed / total)


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_report(path: Path, rows: list[dict]) -> None:
    lines = [
        "# Clustered Semantic-Admission Conflict Audit",
        "",
        "Rounds are first collapsed within each seed-receiver unit. Confidence intervals then resample seeds and receivers hierarchically.",
        "",
        "| Metric | Estimate | 95% CI | Relative reduction | Positive seeds | Exact one-sided p |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            f"| {row['metric']} | {float(row['estimate']):.6f} | "
            f"[{float(row['ci95_low']):.6f}, {float(row['ci95_high']):.6f}] | "
            f"{100.0 * float(row['relative_reduction']):.2f}% | "
            f"{row['positive_seed_count']}/{row['seed_count']} | "
            f"{float(row['seed_sign_flip_p_one_sided']):.6f} |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
