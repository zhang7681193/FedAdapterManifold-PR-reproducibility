from __future__ import annotations

import csv
import itertools
import math
from pathlib import Path
from typing import Dict, Iterable, List, Sequence

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
OUT = RESULTS / "fam_admit_clustered_stats_v1"
EVIDENCE = RESULTS / "fam_pr_evidence_pack_v15"
STABILITY = RESULTS / "fam_pr_stability_audit_v1"


def pearson(x: Sequence[float], y: Sequence[float]) -> float:
    x_arr = np.asarray(x, dtype=float)
    y_arr = np.asarray(y, dtype=float)
    mask = np.isfinite(x_arr) & np.isfinite(y_arr)
    x_arr = x_arr[mask]
    y_arr = y_arr[mask]
    if len(x_arr) < 3:
        return float("nan")
    if np.std(x_arr) == 0 or np.std(y_arr) == 0:
        return float("nan")
    return float(np.corrcoef(x_arr, y_arr)[0, 1])


def percentile_ci(values: Sequence[float], lo: float = 2.5, hi: float = 97.5) -> tuple[float, float]:
    arr = np.asarray([v for v in values if np.isfinite(v)], dtype=float)
    if len(arr) == 0:
        return float("nan"), float("nan")
    return float(np.percentile(arr, lo)), float(np.percentile(arr, hi))


def bootstrap_seed_means(gains: Sequence[float], rng: np.random.Generator, n_boot: int = 2000) -> np.ndarray:
    arr = np.asarray(gains, dtype=float)
    if len(arr) == 0:
        return np.asarray([])
    idx = rng.integers(0, len(arr), size=(n_boot, len(arr)))
    return arr[idx].mean(axis=1)


def one_sided_sign_flip_p(gains: Sequence[float]) -> float:
    arr = np.asarray(gains, dtype=float)
    arr = arr[np.isfinite(arr)]
    if len(arr) == 0:
        return float("nan")
    obs = float(arr.mean())
    # Exact enumeration is cheap for five seeds; fall back to random if needed.
    if len(arr) <= 18:
        vals = []
        for signs in itertools.product([-1.0, 1.0], repeat=len(arr)):
            vals.append(float((np.asarray(signs) * np.abs(arr)).mean()))
        vals = np.asarray(vals)
        return float((np.sum(vals >= obs) + 1) / (len(vals) + 1))
    rng = np.random.default_rng(17)
    signs = rng.choice([-1.0, 1.0], size=(200000, len(arr)))
    vals = (signs * np.abs(arr)).mean(axis=1)
    return float((np.sum(vals >= obs) + 1) / (len(vals) + 1))


def parse_gain_string(text: str) -> List[float]:
    if text is None:
        return []
    out: List[float] = []
    for part in str(text).replace(",", ";").split(";"):
        part = part.strip()
        if not part:
            continue
        try:
            out.append(float(part))
        except ValueError:
            pass
    return out


def seed_cluster_accuracy_gains() -> pd.DataFrame:
    path = STABILITY / "key_paired_seed_gains.csv"
    rows = []
    rng = np.random.default_rng(20260620)
    df = pd.read_csv(path)
    for _, row in df.iterrows():
        gains = parse_gain_string(row.get("gains", ""))
        if not gains:
            continue
        boot = bootstrap_seed_means(gains, rng)
        ci_low, ci_high = percentile_ci(boot)
        rows.append(
            {
                "dataset": row.get("dataset"),
                "method": row.get("method"),
                "baseline": row.get("baseline"),
                "n_independent_seeds": len(gains),
                "seed_mean_gain": float(np.mean(gains)),
                "seed_boot_ci_low": ci_low,
                "seed_boot_ci_high": ci_high,
                "seed_min_gain": float(np.min(gains)),
                "seed_max_gain": float(np.max(gains)),
                "positive_seeds": int(np.sum(np.asarray(gains) > 0)),
                "nonnegative_seeds": int(np.sum(np.asarray(gains) >= 0)),
                "seed_sign_flip_p_one_sided": one_sided_sign_flip_p(gains),
                "gains": ";".join(f"{g:.6g}" for g in gains),
            }
        )
    return pd.DataFrame(rows)


def sources_from_mechanism_diagnostics() -> Dict[str, str]:
    path = EVIDENCE / "mechanism_diagnostics.csv"
    df = pd.read_csv(path)
    out: Dict[str, str] = {}
    for _, row in df.iterrows():
        if row.get("claim_id") == "adapter_incompatibility_failure_correlation":
            dataset = str(row.get("dataset"))
            source = str(row.get("source"))
            if source and source != "nan":
                out[dataset] = source
    # Add full VFM audits that are central to the upgraded admissibility claim.
    extra = {
        "DINOv2-OfficeHome": "results/fam_dinov2_officehome_full_calib20_noregret_5seed_v1",
        "DINOv2-PACS": "results/fam_dinov2_pacs_calib20_noregret_5seed_v1",
        "CLIP-OfficeHome": "results/fam_clip_officehome_full_calib20_noregret_5seed_v2",
        "CLIP-PACS": "results/fam_clip_vit_lora_federated_pacs_7class_5seed_v1",
        "CLIP-OfficeCaltech": "results/fam_clip_vit_lora_federated_officecaltech_10class_5seed_v1",
        "CLIP-DomainNetMini": "results/fam_clip_vit_lora_federated_domainnetmini_60class_5seed_v2",
        "CLIP-DomainNetMini-Large": "results/fam_clip_vit_lora_federated_domainnetmini_60class_8shot_5seed_v1",
    }
    for k, v in extra.items():
        if (ROOT / v).exists():
            out[k] = v
    return out


def read_directional_subspace_rows(dataset: str, source_rel: str) -> pd.DataFrame:
    source = ROOT / source_rel
    rows = []
    for seed_dir in sorted(source.glob("seed_*")):
        if not seed_dir.is_dir():
            continue
        try:
            seed = int(seed_dir.name.split("_")[-1])
        except ValueError:
            continue
        f = seed_dir / "subspace_metrics.csv"
        if not f.exists():
            continue
        df = pd.read_csv(f)
        if "receiver_client_id" in df.columns:
            for _, row in df.iterrows():
                receiver = f"client_{int(row.get('receiver_client_id'))}"
                source_client = f"client_{int(row.get('donor_client_id'))}"
                rows.append(
                    {
                        "dataset": dataset,
                        "source": source_rel,
                        "seed": seed,
                        "client_i": receiver,
                        "client_j": source_client,
                        "domain_i": row.get("receiver_domain"),
                        "domain_j": row.get("donor_domain"),
                        "d_sub": row.get("d_sub"),
                        "d_update": np.nan,
                        "d_combined": np.nan,
                        "d_adapter_incompatibility": np.nan,
                        "d_geo": row.get("d_geo"),
                        "d_label": np.nan,
                        "receiver": receiver,
                        "source_client": source_client,
                        "receiver_cluster": f"{seed}:{receiver}",
                        "failure_raw_directional": row.get("aggregation_failure"),
                    }
                )
            continue
        for _, row in df.iterrows():
            base = {
                "dataset": dataset,
                "source": source_rel,
                "seed": seed,
                "client_i": row.get("client_i"),
                "client_j": row.get("client_j"),
                "domain_i": row.get("domain_i"),
                "domain_j": row.get("domain_j"),
            }
            measures = {
                "d_sub": row.get("d_sub"),
                "d_update": row.get("d_update"),
                "d_combined": row.get("d_combined"),
                "d_adapter_incompatibility": row.get("d_adapter_incompatibility"),
                "d_geo": row.get("d_geo"),
                "d_label": row.get("d_label"),
            }
            for receiver_key, source_key, failure_key in [
                ("client_i", "client_j", "aggregation_failure_i"),
                ("client_j", "client_i", "aggregation_failure_j"),
            ]:
                rec = dict(base)
                rec.update(measures)
                rec["receiver"] = row.get(receiver_key)
                rec["source_client"] = row.get(source_key)
                rec["receiver_cluster"] = f"{seed}:{row.get(receiver_key)}"
                rec["failure_raw_directional"] = row.get(failure_key)
                rows.append(rec)
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame(rows)
    numeric = [
        "d_sub",
        "d_update",
        "d_combined",
        "d_adapter_incompatibility",
        "d_geo",
        "d_label",
        "failure_raw_directional",
    ]
    for col in numeric:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def cluster_bootstrap_corr(
    df: pd.DataFrame,
    measure: str,
    cluster_col: str,
    rng: np.random.Generator,
    n_boot: int = 500,
) -> np.ndarray:
    clusters = [c for c in df[cluster_col].dropna().unique()]
    if len(clusters) < 2:
        return np.asarray([])
    grouped = {c: df[df[cluster_col] == c] for c in clusters}
    vals = []
    for _ in range(n_boot):
        sampled = rng.choice(clusters, size=len(clusters), replace=True)
        sample = pd.concat([grouped[c] for c in sampled], ignore_index=True)
        vals.append(pearson(sample[measure], sample["failure_raw_directional"]))
    return np.asarray(vals, dtype=float)


def hierarchical_bootstrap_corr(
    df: pd.DataFrame,
    measure: str,
    rng: np.random.Generator,
    n_boot: int = 500,
) -> np.ndarray:
    seeds = [s for s in sorted(df["seed"].dropna().unique())]
    if len(seeds) < 2:
        return np.asarray([])
    vals = []
    for _ in range(n_boot):
        parts = []
        sampled_seeds = rng.choice(seeds, size=len(seeds), replace=True)
        for seed in sampled_seeds:
            seed_df = df[df["seed"] == seed]
            receivers = [r for r in seed_df["receiver"].dropna().unique()]
            if not receivers:
                continue
            sampled_receivers = rng.choice(receivers, size=len(receivers), replace=True)
            for receiver in sampled_receivers:
                parts.append(seed_df[seed_df["receiver"] == receiver])
        if not parts:
            vals.append(float("nan"))
            continue
        sample = pd.concat(parts, ignore_index=True)
        vals.append(pearson(sample[measure], sample["failure_raw_directional"]))
    return np.asarray(vals, dtype=float)


def clustered_subspace_failure_correlations() -> tuple[pd.DataFrame, pd.DataFrame]:
    rng = np.random.default_rng(20260621)
    summary_rows = []
    all_rows = []
    measures = [
        "d_sub",
        "d_adapter_incompatibility",
        "d_combined",
        "d_geo",
        "d_label",
        "d_update",
    ]
    for dataset, source in sources_from_mechanism_diagnostics().items():
        df = read_directional_subspace_rows(dataset, source)
        if df.empty:
            continue
        all_rows.append(df)
        for measure in measures:
            if measure not in df.columns:
                continue
            pooled = pearson(df[measure], df["failure_raw_directional"])
            seed_boot = cluster_bootstrap_corr(df, measure, "seed", rng)
            receiver_boot = cluster_bootstrap_corr(df, measure, "receiver_cluster", rng)
            hier_boot = hierarchical_bootstrap_corr(df, measure, rng)
            seed_low, seed_high = percentile_ci(seed_boot)
            rec_low, rec_high = percentile_ci(receiver_boot)
            hier_low, hier_high = percentile_ci(hier_boot)
            summary_rows.append(
                {
                    "dataset": dataset,
                    "source": source,
                    "measure": measure,
                    "n_directional_pairs": len(df),
                    "n_seeds": int(df["seed"].nunique()),
                    "n_receiver_clusters": int(df["receiver_cluster"].nunique()),
                    "pooled_pearson_r": pooled,
                    "seed_cluster_ci_low": seed_low,
                    "seed_cluster_ci_high": seed_high,
                    "receiver_cluster_ci_low": rec_low,
                    "receiver_cluster_ci_high": rec_high,
                    "hierarchical_ci_low": hier_low,
                    "hierarchical_ci_high": hier_high,
                    "seed_cluster_positive_rate": float(np.nanmean(seed_boot > 0)) if len(seed_boot) else float("nan"),
                    "receiver_cluster_positive_rate": float(np.nanmean(receiver_boot > 0)) if len(receiver_boot) else float("nan"),
                    "hierarchical_positive_rate": float(np.nanmean(hier_boot > 0)) if len(hier_boot) else float("nan"),
                }
            )
    raw = pd.concat(all_rows, ignore_index=True) if all_rows else pd.DataFrame()
    return pd.DataFrame(summary_rows), raw


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    acc = seed_cluster_accuracy_gains()
    acc.to_csv(OUT / "seed_cluster_accuracy_gains.csv", index=False)

    corr, raw = clustered_subspace_failure_correlations()
    corr.to_csv(OUT / "clustered_subspace_failure_correlation.csv", index=False)
    raw.to_csv(OUT / "directional_subspace_failure_samples.csv", index=False)

    with (OUT / "README.md").open("w", encoding="utf-8") as f:
        f.write("# FedAdapterManifold-Admit clustered statistics\n\n")
        f.write("This directory contains stricter inference summaries for the upgraded admissibility manuscript.\n\n")
        f.write("- `seed_cluster_accuracy_gains.csv`: seed-level bootstrap over independent training seeds from existing gain strings.\n")
        f.write("- `clustered_subspace_failure_correlation.csv`: pooled, seed-clustered, receiver-clustered, and hierarchical bootstrap correlations between adapter distances and directional aggregation failure.\n")
        f.write("- `directional_subspace_failure_samples.csv`: constructed directional receiver/source samples from per-seed `subspace_metrics.csv` files.\n\n")
        f.write("These statistics do not rerun training. They re-analyze existing audited result roots.\n")

    print(f"Wrote {OUT}")
    print(f"accuracy rows: {len(acc)}")
    print(f"correlation rows: {len(corr)}")


if __name__ == "__main__":
    main()
