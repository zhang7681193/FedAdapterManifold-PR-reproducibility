from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd


ANCHORS = {
    "FedPer": "FedPer-LoRA",
    "Ditto": "Ditto-LoRA",
    "FedTree": "FedTreeLoRA-Visual-Port",
    "SubspaceReg": "Subspace-Reg-LoRA-Visual-Port",
}
METHOD = "FedAdapterManifold-{anchor}AnchorResidualAdmit"
SCALAR = METHOD + "-ScalarControl"
SEED = 20260812


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Analyze receiver-residual ceiling experiments.")
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path("results/anchor_residual_ceiling_audit_20260812"),
    )
    parser.add_argument("--bootstrap-replicates", type=int, default=20000)
    return parser.parse_args()


def _bootstrap_seed_means(values: np.ndarray, n_boot: int, rng: np.random.Generator) -> tuple[float, float]:
    draws = rng.choice(values, size=(n_boot, len(values)), replace=True).mean(axis=1)
    return tuple(float(value) for value in np.quantile(draws, [0.025, 0.975]))


def _exact_sign_flip_p(values: np.ndarray) -> float:
    observed = float(values.mean())
    null = [
        float(np.mean(values * np.asarray(signs, dtype=np.float64)))
        for signs in itertools.product((-1.0, 1.0), repeat=len(values))
    ]
    return float(np.mean(np.asarray(null) >= observed - 1e-15))


def _bool(series: pd.Series) -> pd.Series:
    return series.astype(str).str.lower().isin({"true", "1", "yes"})


def _bool_value(value: object) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes"}


def main() -> int:
    args = parse_args()
    rng = np.random.default_rng(SEED)
    units = []
    opportunities = []
    incomplete_runs: list[str] = []
    for dataset_dir in sorted(path for path in args.result_root.iterdir() if path.is_dir()):
        if dataset_dir.name in {"configs", "logs", "analysis"}:
            continue
        for seed_dir in sorted(dataset_dir.glob("seed_*")):
            seed = int(seed_dir.name.split("_")[-1])
            required = [
                seed_dir / "per_client_metrics.csv",
                seed_dir / "anchor_residual_action_fit.csv",
                seed_dir / "fedper_anchor_residual_admission.csv",
                seed_dir / "ditto_anchor_residual_admission.csv",
            ]
            if not all(path.exists() for path in required):
                incomplete_runs.append(str(seed_dir.relative_to(args.result_root)))
                continue
            metrics = pd.read_csv(required[0])
            fits = pd.read_csv(required[1])
            for anchor, anchor_method in ANCHORS.items():
                admission_path = seed_dir / f"{anchor.lower()}_anchor_residual_admission.csv"
                if not admission_path.exists():
                    continue
                names = [anchor_method, METHOD.format(anchor=anchor), SCALAR.format(anchor=anchor)]
                subset = metrics[metrics["method"].isin(names)].copy()
                pivot = subset.pivot_table(
                    index=["client_id", "domain"],
                    columns="method",
                    values=["accuracy", "loss"],
                    aggfunc="first",
                )
                if len(pivot) == 0:
                    continue
                admission = pd.read_csv(admission_path)
                selected = admission[_bool(admission["selected"])].set_index("client_id")
                anchor_fits = fits[fits["anchor_family"] == anchor_method].copy()
                selected_fit = anchor_fits[_bool(anchor_fits["selected_block_source"])]
                fit_by_client = selected_fit.set_index("client_id")
                for client_id, domain in pivot.index:
                    residual_method = METHOD.format(anchor=anchor)
                    scalar_method = SCALAR.format(anchor=anchor)
                    anchor_acc = float(pivot.loc[(client_id, domain), ("accuracy", anchor_method)])
                    residual_acc = float(pivot.loc[(client_id, domain), ("accuracy", residual_method)])
                    scalar_acc = float(pivot.loc[(client_id, domain), ("accuracy", scalar_method)])
                    decision = selected.loc[client_id]
                    fit = fit_by_client.loc[client_id]
                    units.append(
                        {
                            "dataset": dataset_dir.name,
                            "seed": seed,
                            "client_id": client_id,
                            "domain": domain,
                            "anchor": anchor_method,
                            "selected_family": decision["transport_family"],
                            "nonlocal_admission": decision["transport_family"] == "disagreement_blockwise",
                            "certified_anchor_safe": _bool_value(
                                decision["certified_anchor_safe"]
                            ),
                            "calibration_shift_mode": decision.get(
                                "calibration_shift_mode", "marginal"
                            ),
                            "calibration_shift_strata": int(
                                decision.get("calibration_shift_strata", 1)
                            ),
                            "calibration_minimum_stratum_size": int(
                                decision.get("calibration_minimum_stratum_size", len(selected))
                            ),
                            "calibration_undersampled_strata": int(
                                decision.get("calibration_undersampled_strata", 0)
                            ),
                            "calibration_error_difference": float(
                                decision["paired_error_difference_vs_anchor"]
                            ),
                            "calibration_logloss_difference": float(
                                decision["paired_log_loss_difference_vs_anchor"]
                            ),
                            "anchor_accuracy": anchor_acc,
                            "residual_accuracy": residual_acc,
                            "scalar_accuracy": scalar_acc,
                            "gain_vs_anchor": residual_acc - anchor_acc,
                            "gain_vs_scalar": residual_acc - scalar_acc,
                            "training_gain_vs_anchor": float(fit["training_gain_vs_center"]),
                            "blockwise_gain_vs_scalar_training": float(
                                fit["blockwise_gain_vs_scalar"]
                            ),
                            "normal_coefficient": float(fit["normal_coefficient"]),
                        }
                    )
                for _, row in anchor_fits.iterrows():
                    opportunities.append(
                        {
                            "dataset": dataset_dir.name,
                            "seed": seed,
                            "anchor": anchor_method,
                            **row.to_dict(),
                        }
                    )

    if not units:
        raise FileNotFoundError(f"No completed audit runs under {args.result_root}")
    unit_frame = pd.DataFrame(units)
    opportunity_frame = pd.DataFrame(opportunities)
    seed_frame = (
        unit_frame.groupby(["dataset", "anchor", "seed"], as_index=False)
        .agg(
            gain_vs_anchor=("gain_vs_anchor", "mean"),
            gain_vs_scalar=("gain_vs_scalar", "mean"),
            nonlocal_admissions=("nonlocal_admission", "sum"),
            worst_gain_vs_anchor=("gain_vs_anchor", "min"),
        )
    )
    summary_rows = []
    for (dataset, anchor), group in unit_frame.groupby(["dataset", "anchor"], sort=True):
        seeds = seed_frame[(seed_frame["dataset"] == dataset) & (seed_frame["anchor"] == anchor)]
        effects = seeds["gain_vs_anchor"].to_numpy(dtype=np.float64)
        scalar_effects = seeds["gain_vs_scalar"].to_numpy(dtype=np.float64)
        ci_low, ci_high = _bootstrap_seed_means(effects, args.bootstrap_replicates, rng)
        scalar_low, scalar_high = _bootstrap_seed_means(
            scalar_effects, args.bootstrap_replicates, rng
        )
        opportunity = bool((group["training_gain_vs_anchor"] > 1e-5).any())
        nonlocal_count = int(group["nonlocal_admission"].sum())
        certified_positive = bool(
            nonlocal_count > 0
            and ci_low > 0.0
            and float(group["gain_vs_anchor"].min()) >= -1e-12
        )
        cone_ceiling = bool(not opportunity and nonlocal_count == 0)
        if certified_positive:
            status = "certified_positive"
        elif cone_ceiling:
            status = "empirical_transport_cone_ceiling"
        elif nonlocal_count == 0:
            status = "calibration_power_blocked"
        else:
            status = "unresolved_directional_transfer"
        summary_rows.append(
            {
                "dataset": dataset,
                "anchor": anchor,
                "seed_count": int(seeds["seed"].nunique()),
                "client_seed_units": int(len(group)),
                "nonlocal_admissions": nonlocal_count,
                "directional_opportunity_units": int(
                    (group["training_gain_vs_anchor"] > 1e-5).sum()
                ),
                "mean_gain_vs_anchor": float(group["gain_vs_anchor"].mean()),
                "worst_gain_vs_anchor": float(group["gain_vs_anchor"].min()),
                "seed_cluster_ci_low": ci_low,
                "seed_cluster_ci_high": ci_high,
                "seed_sign_flip_p_one_sided": _exact_sign_flip_p(effects),
                "mean_gain_vs_scalar": float(group["gain_vs_scalar"].mean()),
                "gain_vs_scalar_ci_low": scalar_low,
                "gain_vs_scalar_ci_high": scalar_high,
                "all_selected_anchor_safe": bool(group["certified_anchor_safe"].all()),
                "calibration_shift_mode": "|".join(
                    sorted(group["calibration_shift_mode"].astype(str).unique())
                ),
                "minimum_calibration_stratum_size": int(
                    group["calibration_minimum_stratum_size"].min()
                ),
                "undersampled_strata_total": int(
                    group["calibration_undersampled_strata"].sum()
                ),
                "status": status,
            }
        )

    output = args.result_root / "analysis"
    output.mkdir(parents=True, exist_ok=True)
    unit_frame.to_csv(output / "receiver_residual_client_seed_units.csv", index=False)
    opportunity_frame.to_csv(output / "receiver_residual_training_opportunities.csv", index=False)
    seed_frame.to_csv(output / "receiver_residual_seed_effects.csv", index=False)
    summary = pd.DataFrame(summary_rows)
    summary.to_csv(output / "receiver_residual_summary.csv", index=False)
    unresolved = summary[summary["status"].str.startswith("unresolved")]
    report = [
        "# Receiver-residual personalization-ceiling audit",
        "",
        "Each available external or personalized anchor is audited separately with the same predeclared receiver-action residual cone. Test accuracy never selects the anchor, source family, path strength, or route threshold.",
        f"Completed runs analyzed: {seed_frame[['dataset', 'seed']].drop_duplicates().shape[0]}; incomplete runs skipped: {len(incomplete_runs)}.",
        "",
        "| Dataset | Anchor | Nonlocal | Gain | 95% seed CI | Worst | Scalar delta | Status |",
        "|---|---|---:|---:|---:|---:|---:|---|",
    ]
    for row in summary_rows:
        report.append(
            f"| {row['dataset']} | {row['anchor']} | {row['nonlocal_admissions']}/{row['client_seed_units']} | "
            f"{row['mean_gain_vs_anchor']:+.4f} | [{row['seed_cluster_ci_low']:+.4f}, {row['seed_cluster_ci_high']:+.4f}] | "
            f"{row['worst_gain_vs_anchor']:+.4f} | {row['mean_gain_vs_scalar']:+.4f} | {row['status']} |"
        )
    report.extend(
        [
            "",
            f"Unresolved directional-transfer rows: {len(unresolved)}.",
            "A cone-ceiling row is not relabeled as a gain: it means the adapter-training split found no improving direction in the declared receiver residual cone and the certified policy returned the strong anchor. A certified-positive row additionally requires non-local use, a positive seed-clustered lower bound, and no negative client-seed test unit.",
            "Incomplete run directories: " + (", ".join(incomplete_runs) if incomplete_runs else "none"),
        ]
    )
    (output / "receiver_residual_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
