from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import Counter
from pathlib import Path

import numpy as np
import yaml


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = (
    ROOT
    / "results"
    / "fam_canonical_admission_gate_20260810"
    / "canonical_admission_units.csv"
)
DEFAULT_OUTPUT = ROOT / "results" / "fam_calibration_robustness_20260810"
BLOOD_ROOT = ROOT / "results" / "fam_blood_manifest_fedavg_fedper_fam_5seed_v1"

LOCAL = "Local-LoRA"
GEO = "FedGeo-Agg"
SUBSPACE = "Subspace-Compatible"
FAM = "FedAdapterManifold"
CANDIDATES = [LOCAL, GEO, SUBSPACE, FAM]
MANIFOLD = {SUBSPACE, FAM}
TOL = 1e-12


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Audit admission robustness to calibration-score error and label skew."
    )
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--replicates", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260810)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write an empty table: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def select(scores: dict[str, float]) -> str:
    # Anchor-first order is the declared deterministic tie break.
    return min(CANDIDATES, key=lambda name: (scores[name], CANDIDATES.index(name)))


def proposal_outcome(row: dict[str, str]) -> str:
    delta = float(row["manifold_delta_vs_better_test_anchor"])
    if delta > TOL:
        return "beneficial"
    if delta < -TOL:
        return "harmful"
    return "neutral"


def summarize_draw(
    rows: list[dict[str, str]], selected: list[str], proposals: list[str]
) -> dict[str, float]:
    accuracies = []
    geo = []
    accepted = []
    beneficial_total = 0
    beneficial_accepted = 0
    harmful_total = 0
    harmful_accepted = 0
    canonical_agreement = 0
    for row, method, proposal in zip(rows, selected, proposals):
        accuracies.append(float(row[f"{method_key(method)}_accuracy"]))
        geo.append(float(row["geo_accuracy"]))
        is_accepted = method in MANIFOLD
        accepted.append(is_accepted)
        canonical_agreement += method == row["canonical_selected_method"]
        anchor_accuracy = max(float(row["local_accuracy"]), float(row["geo_accuracy"]))
        proposal_delta = float(row[f"{method_key(proposal)}_accuracy"]) - anchor_accuracy
        outcome = "beneficial" if proposal_delta > TOL else ("harmful" if proposal_delta < -TOL else "neutral")
        if outcome == "beneficial":
            beneficial_total += 1
            beneficial_accepted += int(is_accepted)
        elif outcome == "harmful":
            harmful_total += 1
            harmful_accepted += int(is_accepted)
    return {
        "accuracy": float(np.mean(accuracies)),
        "delta_vs_geo": float(np.mean(np.asarray(accuracies) - np.asarray(geo))),
        "worst_client_accuracy": float(np.min(accuracies)),
        "coverage": float(np.mean(accepted)),
        "beneficial_admission_rate": beneficial_accepted / beneficial_total,
        "harmful_admission_rate": harmful_accepted / harmful_total,
        "decision_agreement": canonical_agreement / len(rows),
    }


def method_key(method: str) -> str:
    return {
        LOCAL: "local",
        GEO: "geo",
        SUBSPACE: "subspace",
        FAM: "fam",
    }[method]


def quantile_summary(values: list[float]) -> tuple[float, float, float]:
    arr = np.asarray(values, dtype=np.float64)
    return float(np.mean(arr)), float(np.quantile(arr, 0.025)), float(np.quantile(arr, 0.975))


def perturbation_audit(
    rows: list[dict[str, str]], replicates: int, seed: int, *, confidence_margin: bool
) -> list[dict[str, object]]:
    rng = np.random.default_rng(seed)
    output = []
    for coefficient_of_variation in [0.0, 0.01, 0.02, 0.05, 0.10]:
        draws: dict[str, list[float]] = {
            name: []
            for name in [
                "accuracy",
                "delta_vs_geo",
                "worst_client_accuracy",
                "coverage",
                "beneficial_admission_rate",
                "harmful_admission_rate",
                "decision_agreement",
            ]
        }
        draw_count = 1 if coefficient_of_variation == 0 else replicates
        for _ in range(draw_count):
            selected = []
            proposals = []
            for row in rows:
                scores = {
                    name: float(row[f"selector_score_{name}"])
                    for name in CANDIDATES
                }
                if coefficient_of_variation:
                    scores = {
                        name: max(
                            0.0,
                            value
                            * (1.0 + rng.normal(0.0, coefficient_of_variation)),
                        )
                        for name, value in scores.items()
                    }
                anchor = min((LOCAL, GEO), key=lambda name: (scores[name], CANDIDATES.index(name)))
                proposal = min((SUBSPACE, FAM), key=lambda name: (scores[name], CANDIDATES.index(name)))
                proposals.append(proposal)
                if confidence_margin and coefficient_of_variation:
                    uncertainty = 1.96 * coefficient_of_variation * math.sqrt(
                        scores[anchor] ** 2 + scores[proposal] ** 2
                    )
                    selected.append(
                        proposal
                        if scores[anchor] - scores[proposal] > uncertainty
                        else anchor
                    )
                else:
                    selected.append(select(scores))
            metrics = summarize_draw(rows, selected, proposals)
            for name, value in metrics.items():
                draws[name].append(value)
        summary: dict[str, object] = {
            "policy": "confidence-margin" if confidence_margin else "zero-margin",
            "score_noise_cv": coefficient_of_variation,
            "replicates": draw_count,
        }
        for name, values in draws.items():
            mean, low, high = quantile_summary(values)
            summary[f"{name}_mean"] = mean
            summary[f"{name}_q025"] = low
            summary[f"{name}_q975"] = high
        output.append(summary)
    return output


def deterministic_margin_audit(rows: list[dict[str, str]]) -> list[dict[str, object]]:
    margins = []
    for row in rows:
        ordered = sorted(
            (
                (float(row[f"selector_score_{name}"]), CANDIDATES.index(name), name)
                for name in CANDIDATES
            )
        )
        best_score, _, best_name = ordered[0]
        second_score, _, second_name = ordered[1]
        # If each positive score has relative error <= rho, the winner is fixed when
        # second - best > rho * (second + best).
        certified_relative_radius = (second_score - best_score) / max(
            second_score + best_score, TOL
        )
        margins.append(
            {
                "setting": row["setting"],
                "seed": int(row["seed"]),
                "client_id": row["client_id"],
                "selected": best_name,
                "runner_up": second_name,
                "certified_relative_radius": certified_relative_radius,
            }
        )
    return margins


def margin_summary(margins: list[dict[str, object]]) -> list[dict[str, object]]:
    rows = []
    for radius in [0.01, 0.02, 0.05, 0.10]:
        for setting in ["All"] + sorted({str(row["setting"]) for row in margins}):
            group = margins if setting == "All" else [row for row in margins if row["setting"] == setting]
            stable = sum(float(row["certified_relative_radius"]) > radius for row in group)
            rows.append(
                {
                    "setting": setting,
                    "relative_error_bound": radius,
                    "certified_stable_units": stable,
                    "total_units": len(group),
                    "certified_stability_rate": stable / len(group),
                }
            )
    return rows


def normalize_windows_path(value: str) -> str:
    # Historical YAML copies escaped each backslash twice. Path accepts the
    # normalized form while preserving ordinary paths unchanged.
    while "\\\\" in value:
        value = value.replace("\\\\", "\\")
    return value


def load_blood_histograms() -> list[dict[str, object]]:
    sys.path.insert(0, str(ROOT))
    from fedadaptermanifold.data import load_medmnist_npz_clients

    rows = []
    for seed_dir in sorted(BLOOD_ROOT.glob("seed_*")):
        with (seed_dir / "config.yaml").open(encoding="utf-8") as handle:
            config = yaml.safe_load(handle)
        clients, _, class_names = load_medmnist_npz_clients(
            data_root=normalize_windows_path(str(config["data_root"])),
            num_clients=int(config["num_clients"]),
            dirichlet_alpha=float(config["dirichlet_alpha"]),
            min_train_size=int(config["min_train_size"]),
            train_per_client=int(config["train_per_client"]),
            test_per_client=int(config["test_per_client"]),
            align_test_with_train=bool(config["align_test_with_train"]),
            seed=int(config["seed"]),
            feature_cache_dir=config.get("feature_cache_dir", ""),
            feature_backbone=config.get("feature_backbone", "numpy"),
        )
        num_classes = len(class_names)
        for client in clients:
            counts = np.bincount(client.y_train, minlength=num_classes).astype(np.float64)
            probs = counts / counts.sum()
            positive = probs[probs > 0]
            entropy = -float(np.sum(positive * np.log(positive)))
            normalized_entropy = entropy / math.log(num_classes)
            rows.append(
                {
                    "setting": "BloodMNIST",
                    "seed": int(config["seed"]),
                    "client_id": client.client_id,
                    "train_examples": int(counts.sum()),
                    "class_counts": json.dumps(counts.astype(int).tolist()),
                    "observed_classes": int(np.sum(counts > 0)),
                    "dominant_class_share": float(np.max(probs)),
                    "normalized_label_entropy": normalized_entropy,
                    "effective_classes": float(math.exp(entropy)),
                }
            )
    return rows


def imbalance_audit(
    canonical_rows: list[dict[str, str]], histograms: list[dict[str, object]]
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    canonical = {
        (int(row["seed"]), row["client_id"]): row
        for row in canonical_rows
        if row["setting"] == "BloodMNIST"
    }
    joined = []
    for row in histograms:
        key = (int(row["seed"]), str(row["client_id"]))
        if key not in canonical:
            raise KeyError(f"Missing canonical BloodMNIST unit: {key}")
        item = {**row, **canonical[key]}
        joined.append(item)
    joined.sort(key=lambda row: float(row["normalized_label_entropy"]))
    for index, row in enumerate(joined):
        row["imbalance_quartile"] = min(4, index * 4 // len(joined) + 1)

    summaries = []
    for quartile in range(1, 5):
        group = [row for row in joined if row["imbalance_quartile"] == quartile]
        selected_delta = [
            float(row["canonical_accuracy"]) - float(row["geo_accuracy"])
            for row in group
        ]
        summaries.append(
            {
                "imbalance_quartile": quartile,
                "interpretation": "most imbalanced" if quartile == 1 else ("least imbalanced" if quartile == 4 else "intermediate"),
                "units": len(group),
                "normalized_entropy_mean": float(np.mean([float(row["normalized_label_entropy"]) for row in group])),
                "dominant_class_share_mean": float(np.mean([float(row["dominant_class_share"]) for row in group])),
                "fedavg_accuracy": float(np.mean([float(row["fedavg_accuracy"]) for row in group])),
                "geo_accuracy": float(np.mean([float(row["geo_accuracy"]) for row in group])),
                "canonical_accuracy": float(np.mean([float(row["canonical_accuracy"]) for row in group])),
                "delta_vs_geo": float(np.mean(selected_delta)),
                "worst_client_accuracy": float(np.min([float(row["canonical_accuracy"]) for row in group])),
                "manifold_coverage": float(np.mean([int(row["manifold_accepted"]) for row in group])),
                "geo_degrade_units": int(sum(delta < -TOL for delta in selected_delta)),
            }
        )
    return joined, summaries


def symmetric_noise_bounds() -> list[dict[str, object]]:
    rows = []
    classes = 8
    candidates = len(CANDIDATES)
    delta = 0.05
    for noise_rate in [0.0, 0.05, 0.10, 0.20, 0.40, 0.60]:
        contraction = 1.0 - classes * noise_rate / (classes - 1)
        for calibration_n in [16, 32, 64, 128, 256, 512]:
            epsilon = math.sqrt(math.log(2 * candidates / delta) / (2 * calibration_n))
            clean_gap = 2 * epsilon / contraction if contraction > 0 else float("inf")
            rows.append(
                {
                    "classes": classes,
                    "symmetric_noise_rate": noise_rate,
                    "risk_gap_contraction": contraction,
                    "calibration_n": calibration_n,
                    "candidate_count": candidates,
                    "delta": delta,
                    "uniform_hoeffding_epsilon": epsilon,
                    "sufficient_clean_risk_gap": clean_gap,
                    "ranking_preserved_in_expectation": int(contraction > 0),
                }
            )
    return rows


def build_report(
    perturbation: list[dict[str, object]],
    confidence_margin: list[dict[str, object]],
    margin: list[dict[str, object]],
    imbalance: list[dict[str, object]],
) -> str:
    lines = [
        "# Calibration and imbalance robustness audit",
        "",
        "This is a fixed-candidate replay. Test metrics are attached only after each perturbed selector decision. Calibration-score perturbation models finite-sample/measurement error in the stored selector objective; it is not presented as a label-noise retraining experiment.",
        "",
        "## Calibration-score perturbation",
        "",
        "| CV | Decision agreement | Accuracy | Delta vs Geo | Coverage | Beneficial admitted | Harmful admitted |",
        "|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in perturbation:
        lines.append(
            "| {score_noise_cv:.0%} | {decision_agreement_mean:.1%} | {accuracy_mean:.4f} | {delta_vs_geo_mean:+.4f} | {coverage_mean:.1%} | {beneficial_admission_rate_mean:.1%} | {harmful_admission_rate_mean:.1%} |".format(**row)
        )
    lines.extend(
        [
            "",
            "A confidence-adaptive gate admits a manifold proposal only when its perturbed score improvement exceeds $1.96\\sigma\\sqrt{s_a^2+s_m^2}$, where $\\sigma$ is the declared score-noise CV. This rule uses no test outcome.",
            "",
            "| CV | Decision agreement | Accuracy | Delta vs Geo | Coverage | Beneficial admitted | Harmful admitted |",
            "|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for row in confidence_margin:
        lines.append(
            "| {score_noise_cv:.0%} | {decision_agreement_mean:.1%} | {accuracy_mean:.4f} | {delta_vs_geo_mean:+.4f} | {coverage_mean:.1%} | {beneficial_admission_rate_mean:.1%} | {harmful_admission_rate_mean:.1%} |".format(**row)
        )
    lines.extend(
        [
            "",
            "## Deterministic decision-margin certificate",
            "",
            "A unit is certified unchanged when every positive candidate score is perturbed by at most the stated relative error in the adversarial direction.",
            "",
            "| Relative error | Certified stable units | Rate |",
            "|---:|---:|---:|",
        ]
    )
    for row in margin:
        if row["setting"] == "All":
            lines.append(
                f"| {float(row['relative_error_bound']):.0%} | {row['certified_stable_units']}/{row['total_units']} | {float(row['certified_stability_rate']):.1%} |"
            )
    lines.extend(
        [
            "",
            "## BloodMNIST label-imbalance stratification",
            "",
            "Quartiles use the actual reconstructed client training-label histograms. Q1 is the most imbalanced group.",
            "",
            "| Quartile | Entropy | Dominant share | FedAvg | Geo | Admit | Delta vs Geo | Coverage |",
            "|---:|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for row in imbalance:
        lines.append(
            "| Q{imbalance_quartile} | {normalized_entropy_mean:.3f} | {dominant_class_share_mean:.1%} | {fedavg_accuracy:.4f} | {geo_accuracy:.4f} | {canonical_accuracy:.4f} | {delta_vs_geo:+.4f} | {manifold_coverage:.1%} |".format(**row)
        )
    lines.extend(
        [
            "",
            "## Symmetric label-noise guarantee",
            "",
            "For C-class uniform symmetric label noise with rate eta and 0-1 calibration risk, the noisy risk is eta + (1 - C eta/(C-1)) R. Thus candidate ordering is preserved in expectation for eta < (C-1)/C. Finite calibration samples require the clean risk gap to exceed 2 epsilon_n divided by this contraction. The CSV reports this sufficient bound for C=8 and four candidates. This theorem does not cover arbitrary class-conditional or instance-dependent noise.",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    args = parse_args()
    rows = read_csv(args.input)
    if len(rows) != 150:
        raise ValueError(f"Expected 150 canonical units, found {len(rows)}")
    perturbation = perturbation_audit(
        rows, args.replicates, args.seed, confidence_margin=False
    )
    confidence_margin = perturbation_audit(
        rows, args.replicates, args.seed + 1, confidence_margin=True
    )
    margins = deterministic_margin_audit(rows)
    margin_table = margin_summary(margins)
    histograms = load_blood_histograms()
    imbalance_units, imbalance_summary = imbalance_audit(rows, histograms)
    noise_bounds = symmetric_noise_bounds()

    args.output.mkdir(parents=True, exist_ok=True)
    write_csv(args.output / "calibration_score_perturbation.csv", perturbation)
    write_csv(
        args.output / "confidence_margin_score_perturbation.csv", confidence_margin
    )
    write_csv(args.output / "decision_margin_units.csv", margins)
    write_csv(args.output / "decision_margin_summary.csv", margin_table)
    write_csv(args.output / "bloodmnist_label_histogram_units.csv", imbalance_units)
    write_csv(args.output / "bloodmnist_imbalance_summary.csv", imbalance_summary)
    write_csv(args.output / "symmetric_label_noise_bound.csv", noise_bounds)
    (args.output / "calibration_robustness_report.md").write_text(
        build_report(perturbation, confidence_margin, margin_table, imbalance_summary),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
