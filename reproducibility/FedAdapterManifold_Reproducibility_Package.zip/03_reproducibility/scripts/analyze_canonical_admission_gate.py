from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "results" / "fam_canonical_admission_gate_20260810"
SETTINGS = {
    "PACS": ROOT / "results" / "fam_pacs_manifest_fedavg_fedper_fam_5seed_v1",
    "Office-Caltech": ROOT
    / "results"
    / "fam_officecaltech_neighbor_selector_fedrot_w050_v1",
    "DomainNetMini": ROOT
    / "results"
    / "fam_domainnetmini_manifest_fedavg_fedper_fam_5seed_v1",
    "BloodMNIST": ROOT / "results" / "fam_blood_manifest_fedavg_fedper_fam_5seed_v1",
    "OfficeHome-DINOv2": ROOT
    / "results"
    / "fam_dinov2_officehome_full_calib20_noregret_5seed_v1",
    "OfficeHome-CLIP": ROOT
    / "results"
    / "fam_clip_officehome_full_calib20_noregret_5seed_v2",
}

LOCAL = "Local-LoRA"
GEO = "FedGeo-Agg"
SUBSPACE = "Subspace-Compatible"
FAM = "FedAdapterManifold"
CLIENT_ROUTE = "FedAdapterManifold-ClientRoute"
FINAL = "FedAdapterManifold-Selective"
CANONICAL_CANDIDATES = [LOCAL, GEO, SUBSPACE, FAM]
ANCHORS = [LOCAL, GEO]
MANIFOLD_CANDIDATES = [SUBSPACE, FAM]
TOL = 1e-12


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def outcome(delta: float) -> str:
    if delta > TOL:
        return "beneficial"
    if delta < -TOL:
        return "harmful"
    return "neutral"


def argmin(methods: list[str], values: dict[str, float]) -> str:
    # The list order is the pre-declared tie break; anchors precede sharing.
    return min(methods, key=lambda method: (float(values[method]), methods.index(method)))


def collect_units() -> tuple[list[dict[str, object]], dict[str, object]]:
    units: list[dict[str, object]] = []
    legacy_selected = Counter()
    legacy_client_route_rows = 0
    for setting, root in SETTINGS.items():
        for seed_dir in sorted(root.glob("seed_*")):
            metrics_path = seed_dir / "per_client_metrics.csv"
            selection_path = seed_dir / "adapter_candidate_selection.csv"
            if not metrics_path.exists() or not selection_path.exists():
                raise FileNotFoundError(f"Missing audit artifact under {seed_dir}")

            metric_lookup: dict[tuple[str, str], dict[str, float]] = {}
            for row in read_rows(metrics_path):
                method = row["method"]
                if method not in CANONICAL_CANDIDATES + ["FedAvg-LoRA"]:
                    continue
                metric_lookup[(row["client_id"], method)] = {
                    "accuracy": float(row["accuracy"]),
                    "loss": float(row["loss"]),
                }

            selection_by_client: dict[str, list[dict[str, str]]] = defaultdict(list)
            for row in read_rows(selection_path):
                if row.get("method") != FINAL:
                    continue
                selection_by_client[row["client_id"]].append(row)
                if row.get("candidate_method") == CLIENT_ROUTE:
                    legacy_client_route_rows += 1
                if str(row.get("selected", "")).lower() in {"true", "1"}:
                    legacy_selected[row.get("selected_method", "")] += 1

            seed = int(seed_dir.name.split("_")[-1])
            for client_id, selector_rows in sorted(selection_by_client.items()):
                candidate_rows = {
                    row["candidate_method"]: row
                    for row in selector_rows
                    if row.get("candidate_method") in CANONICAL_CANDIDATES
                }
                missing = [method for method in CANONICAL_CANDIDATES if method not in candidate_rows]
                if missing:
                    raise ValueError(
                        f"{setting} seed={seed} {client_id} misses selector candidates: {missing}"
                    )
                missing_metrics = [
                    method
                    for method in CANONICAL_CANDIDATES + ["FedAvg-LoRA"]
                    if (client_id, method) not in metric_lookup
                ]
                if missing_metrics:
                    raise ValueError(
                        f"{setting} seed={seed} {client_id} misses metrics: {missing_metrics}"
                    )

                scores = {
                    method: float(candidate_rows[method]["candidate_selector_score"])
                    for method in CANONICAL_CANDIDATES
                }
                train_losses = {
                    method: float(candidate_rows[method]["candidate_train_loss"])
                    for method in CANONICAL_CANDIDATES
                }
                accuracies = {
                    method: metric_lookup[(client_id, method)]["accuracy"]
                    for method in CANONICAL_CANDIDATES
                }
                test_losses = {
                    method: metric_lookup[(client_id, method)]["loss"]
                    for method in CANONICAL_CANDIDATES
                }
                anchor = argmin(ANCHORS, scores)
                manifold = argmin(MANIFOLD_CANDIDATES, scores)
                selected = argmin(CANONICAL_CANDIDATES, scores)
                oracle_anchor_accuracy = max(accuracies[LOCAL], accuracies[GEO])
                relative_gap = (scores[manifold] - scores[anchor]) / max(
                    abs(scores[anchor]), TOL
                )
                units.append(
                    {
                        "setting": setting,
                        "seed": seed,
                        "client_id": client_id,
                        "canonical_selected_method": selected,
                        "canonical_manifold_proposal": manifold,
                        "canonical_calibration_anchor": anchor,
                        "manifold_accepted": int(selected in MANIFOLD_CANDIDATES),
                        "manifold_relative_score_gap": relative_gap,
                        "manifold_delta_vs_better_test_anchor": accuracies[manifold]
                        - oracle_anchor_accuracy,
                        "manifold_test_outcome": outcome(
                            accuracies[manifold] - oracle_anchor_accuracy
                        ),
                        "selected_delta_vs_better_test_anchor": accuracies[selected]
                        - oracle_anchor_accuracy,
                        "selected_test_outcome": outcome(
                            accuracies[selected] - oracle_anchor_accuracy
                        ),
                        "canonical_accuracy": accuracies[selected],
                        "canonical_loss": test_losses[selected],
                        "fedavg_accuracy": metric_lookup[(client_id, "FedAvg-LoRA")][
                            "accuracy"
                        ],
                        "geo_accuracy": accuracies[GEO],
                        "local_accuracy": accuracies[LOCAL],
                        "subspace_accuracy": accuracies[SUBSPACE],
                        "fam_accuracy": accuracies[FAM],
                        **{
                            f"selector_score_{method}": scores[method]
                            for method in CANONICAL_CANDIDATES
                        },
                        **{
                            f"train_loss_{method}": train_losses[method]
                            for method in CANONICAL_CANDIDATES
                        },
                    }
                )

    if len(units) != 150:
        raise ValueError(f"Expected 150 client-seed units, found {len(units)}")
    protocol = {
        "client_seed_units": len(units),
        "legacy_client_route_rows": legacy_client_route_rows,
        "legacy_client_route_selected": legacy_selected.get(CLIENT_ROUTE, 0),
        "legacy_selected_methods": dict(sorted(legacy_selected.items())),
    }
    return units, protocol


def confusion_rows(
    units: list[dict[str, object]],
    *,
    truth_field: str,
    accepted_field: str,
    audit: str,
) -> list[dict[str, object]]:
    rows = []
    for truth in ["harmful", "neutral", "beneficial"]:
        group = [row for row in units if row[truth_field] == truth]
        accepted = sum(int(row[accepted_field]) for row in group)
        rows.append(
            {
                "audit": audit,
                "actual_test_outcome": truth,
                "accepted": accepted,
                "rejected": len(group) - accepted,
                "total": len(group),
                "admission_rate": accepted / len(group) if group else float("nan"),
            }
        )
    return rows


def raw_subspace_units(units: list[dict[str, object]]) -> list[dict[str, object]]:
    rows = []
    for row in units:
        anchor_accuracy = max(float(row["local_accuracy"]), float(row["geo_accuracy"]))
        delta = float(row["subspace_accuracy"]) - anchor_accuracy
        rows.append(
            {
                **row,
                "raw_subspace_test_outcome": outcome(delta),
                "raw_subspace_accepted": int(
                    row["canonical_selected_method"] == SUBSPACE
                ),
            }
        )
    return rows


def decision_metrics(rows: list[dict[str, object]]) -> dict[str, float]:
    beneficial = [row for row in rows if row["proposal_outcome"] == "beneficial"]
    harmful = [row for row in rows if row["proposal_outcome"] == "harmful"]
    neutral = [row for row in rows if row["proposal_outcome"] == "neutral"]
    accepted = [row for row in rows if int(row["accepted"])]
    accepted_beneficial = sum(row["proposal_outcome"] == "beneficial" for row in accepted)
    accepted_harmful = sum(row["proposal_outcome"] == "harmful" for row in accepted)
    decisive_accepted = accepted_beneficial + accepted_harmful
    return {
        "coverage": len(accepted) / len(rows),
        "fallback_rate": 1.0 - len(accepted) / len(rows),
        "beneficial_admission_rate": (
            sum(int(row["accepted"]) for row in beneficial) / len(beneficial)
            if beneficial
            else float("nan")
        ),
        "harmful_admission_rate": (
            sum(int(row["accepted"]) for row in harmful) / len(harmful)
            if harmful
            else float("nan")
        ),
        "neutral_admission_rate": (
            sum(int(row["accepted"]) for row in neutral) / len(neutral)
            if neutral
            else float("nan")
        ),
        "beneficial_precision_excluding_neutral": (
            accepted_beneficial / decisive_accepted
            if decisive_accepted
            else float("nan")
        ),
    }


def policy_rows(units: list[dict[str, object]]) -> list[dict[str, object]]:
    policies = [
        ("Always Geo", [GEO], "selector_score"),
        ("Anchor calibration", ANCHORS, "selector_score"),
        ("Calibration-only", CANONICAL_CANDIDATES, "train_loss"),
        ("Subspace + calibration", ANCHORS + [SUBSPACE], "selector_score"),
        ("Full canonical gate", CANONICAL_CANDIDATES, "selector_score"),
    ]
    output: list[dict[str, object]] = []
    for policy, candidates, score_prefix in policies:
        decisions = []
        selected_by_setting: dict[str, list[dict[str, object]]] = defaultdict(list)
        for row in units:
            values = {
                method: float(row[f"{score_prefix}_{method}"]) for method in candidates
            }
            selected = argmin(candidates, values)
            manifold_candidates = [
                method for method in candidates if method in MANIFOLD_CANDIDATES
            ]
            if manifold_candidates:
                proposal = argmin(manifold_candidates, values)
                anchor_accuracy = max(
                    float(row["local_accuracy"]), float(row["geo_accuracy"])
                )
                # The stored field names for the two manifold candidates are explicit.
                if proposal == SUBSPACE:
                    proposal_delta = float(row["subspace_accuracy"]) - anchor_accuracy
                else:
                    proposal_delta = float(row["fam_accuracy"]) - anchor_accuracy
                proposal_outcome = outcome(proposal_delta)
            else:
                proposal = ""
                proposal_outcome = "not_applicable"
            selected_accuracy = {
                LOCAL: float(row["local_accuracy"]),
                GEO: float(row["geo_accuracy"]),
                SUBSPACE: float(row["subspace_accuracy"]),
                FAM: float(row["fam_accuracy"]),
            }[selected]
            decision = {
                "proposal_outcome": proposal_outcome,
                "accepted": int(selected in MANIFOLD_CANDIDATES),
                "selected_accuracy": selected_accuracy,
                "geo_accuracy": float(row["geo_accuracy"]),
                "fedavg_accuracy": float(row["fedavg_accuracy"]),
                "setting": row["setting"],
                "seed": row["seed"],
                "client_id": row["client_id"],
                "selected_method": selected,
                "proposal_method": proposal,
            }
            decisions.append(decision)
            selected_by_setting[str(row["setting"])].append(decision)

        setting_deltas = []
        seed_worst = []
        for setting, setting_rows in selected_by_setting.items():
            setting_deltas.append(
                np.mean([row["selected_accuracy"] for row in setting_rows])
                - np.mean([row["geo_accuracy"] for row in setting_rows])
            )
            by_seed: dict[int, list[dict[str, object]]] = defaultdict(list)
            for row in setting_rows:
                by_seed[int(row["seed"])].append(row)
            seed_worst.extend(
                min(float(row["selected_accuracy"]) for row in seed_rows)
                for seed_rows in by_seed.values()
            )
        metrics = (
            decision_metrics(decisions)
            if any(row["proposal_outcome"] != "not_applicable" for row in decisions)
            else {
                "coverage": 0.0,
                "fallback_rate": 1.0,
                "beneficial_admission_rate": float("nan"),
                "harmful_admission_rate": float("nan"),
                "neutral_admission_rate": float("nan"),
                "beneficial_precision_excluding_neutral": float("nan"),
            }
        )
        output.append(
            {
                "policy": policy,
                "candidate_pool": ";".join(candidates),
                "mean_accuracy_client_weighted": np.mean(
                    [row["selected_accuracy"] for row in decisions]
                ),
                "macro_setting_delta_vs_geo": np.mean(setting_deltas),
                "mean_seed_worst_client_accuracy": np.mean(seed_worst),
                **metrics,
                "selected_method_counts": ";".join(
                    f"{method}:{count}"
                    for method, count in sorted(
                        Counter(row["selected_method"] for row in decisions).items()
                    )
                ),
            }
        )
    return output


def risk_coverage_rows(units: list[dict[str, object]]) -> list[dict[str, object]]:
    thresholds = [-0.10, -0.05, -0.02, -0.01, 0.0, 0.01, 0.02, 0.05, 0.10, 0.20]
    output = []
    for threshold in thresholds:
        decisions = []
        for row in units:
            # Strict inequality preserves the declared anchor-first tie break at zero.
            accepted = float(row["manifold_relative_score_gap"]) < threshold
            decisions.append(
                {
                    "proposal_outcome": row["manifold_test_outcome"],
                    "accepted": int(accepted),
                }
            )
        output.append({"relative_score_threshold": threshold, **decision_metrics(decisions)})
    return output


def setting_summary(units: list[dict[str, object]]) -> list[dict[str, object]]:
    groups: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in units:
        groups[str(row["setting"])].append(row)
    output = []
    for setting, rows in groups.items():
        raw_rows = raw_subspace_units(rows)
        raw_harmful = [
            row for row in raw_rows if row["raw_subspace_test_outcome"] == "harmful"
        ]
        raw_beneficial = [
            row for row in raw_rows if row["raw_subspace_test_outcome"] == "beneficial"
        ]
        seed_means: dict[int, list[float]] = defaultdict(list)
        for row in rows:
            seed_means[int(row["seed"])].append(float(row["canonical_accuracy"]))
        seed_values = np.asarray(
            [np.mean(values) for _, values in sorted(seed_means.items())], dtype=np.float64
        )
        output.append(
            {
                "setting": setting,
                "client_seed_units": len(rows),
                "fedavg_accuracy": np.mean([float(row["fedavg_accuracy"]) for row in rows]),
                "geo_accuracy": np.mean([float(row["geo_accuracy"]) for row in rows]),
                "canonical_accuracy": np.mean(
                    [float(row["canonical_accuracy"]) for row in rows]
                ),
                "canonical_seed_sd": float(np.std(seed_values, ddof=1)),
                "delta_vs_fedavg": np.mean(
                    [
                        float(row["canonical_accuracy"]) - float(row["fedavg_accuracy"])
                        for row in rows
                    ]
                ),
                "delta_vs_geo": np.mean(
                    [
                        float(row["canonical_accuracy"]) - float(row["geo_accuracy"])
                        for row in rows
                    ]
                ),
                "manifold_coverage": np.mean(
                    [int(row["manifold_accepted"]) for row in rows]
                ),
                "raw_subspace_harmful_rejected": sum(
                    not int(row["raw_subspace_accepted"]) for row in raw_harmful
                ),
                "raw_subspace_harmful_total": len(raw_harmful),
                "raw_subspace_beneficial_accepted": sum(
                    int(row["raw_subspace_accepted"]) for row in raw_beneficial
                ),
                "raw_subspace_beneficial_total": len(raw_beneficial),
                "final_vs_fedavg_improve": sum(
                    float(row["canonical_accuracy"]) - float(row["fedavg_accuracy"]) > TOL
                    for row in rows
                ),
                "final_vs_fedavg_tie": sum(
                    abs(float(row["canonical_accuracy"]) - float(row["fedavg_accuracy"]))
                    <= TOL
                    for row in rows
                ),
                "final_vs_fedavg_degrade": sum(
                    float(row["canonical_accuracy"]) - float(row["fedavg_accuracy"]) < -TOL
                    for row in rows
                ),
                "final_vs_geo_improve": sum(
                    float(row["canonical_accuracy"]) - float(row["geo_accuracy"]) > TOL
                    for row in rows
                ),
                "final_vs_geo_tie": sum(
                    abs(float(row["canonical_accuracy"]) - float(row["geo_accuracy"]))
                    <= TOL
                    for row in rows
                ),
                "final_vs_geo_degrade": sum(
                    float(row["canonical_accuracy"]) - float(row["geo_accuracy"]) < -TOL
                    for row in rows
                ),
                "selected_method_counts": ";".join(
                    f"{method}:{count}"
                    for method, count in sorted(
                        Counter(row["canonical_selected_method"] for row in rows).items()
                    )
                ),
            }
        )
    return output


def write_report(
    units: list[dict[str, object]],
    protocol: dict[str, object],
    raw_confusion: list[dict[str, object]],
    manifold_confusion: list[dict[str, object]],
    ablations: list[dict[str, object]],
) -> None:
    raw = {row["actual_test_outcome"]: row for row in raw_confusion}
    manifold = {row["actual_test_outcome"]: row for row in manifold_confusion}
    full = next(row for row in ablations if row["policy"] == "Full canonical gate")
    raw_decisive_accepted = int(raw["beneficial"]["accepted"]) + int(
        raw["harmful"]["accepted"]
    )
    raw_precision = (
        int(raw["beneficial"]["accepted"]) / raw_decisive_accepted
        if raw_decisive_accepted
        else float("nan")
    )
    lines = [
        "# Canonical four-candidate admission audit",
        "",
        "The replay fixes the candidate universe to Local-LoRA, Geo-only Agg,",
        "Subspace-Compatible, and the FAM bank. It uses only selector scores stored",
        "before test evaluation. Held-out test labels are joined only after every",
        "decision is frozen.",
        "",
        f"The legacy logs contain {protocol['legacy_client_route_rows']} rows for an",
        "additional ClientRoute diagnostic candidate, but it is selected in",
        f"{protocol['legacy_client_route_selected']} of {protocol['client_seed_units']} units.",
        "It is excluded from the canonical replay, so the deployable pool has four",
        "functionally active candidates.",
        "",
        "## Raw Subspace-Compatible decision",
        "",
        f"The canonical gate accepts {raw['beneficial']['accepted']}/",
        f"{raw['beneficial']['total']} beneficial raw subspace candidates",
        f"({100.0 * float(raw['beneficial']['admission_rate']):.1f}%) and",
        f"{raw['harmful']['accepted']}/{raw['harmful']['total']} harmful candidates",
        f"({100.0 * float(raw['harmful']['admission_rate']):.1f}%).",
        "Its raw-subspace coverage is 10.0%, and precision among accepted",
        f"non-neutral candidates is {100.0 * raw_precision:.1f}%.",
        "",
        "## Full manifold proposal",
        "",
        f"For the best calibration-scored manifold proposal, the gate accepts",
        f"{manifold['beneficial']['accepted']}/{manifold['beneficial']['total']} beneficial",
        f"and {manifold['harmful']['accepted']}/{manifold['harmful']['total']} harmful",
        f"proposals. Overall manifold coverage is {100.0 * float(full['coverage']):.1f}%,",
        f"fallback is {100.0 * float(full['fallback_rate']):.1f}%, and harmful-admission",
        f"rate is {100.0 * float(full['harmful_admission_rate']):.1f}%.",
        "",
        "## Interpretation",
        "",
        "This audit rejects the reject-all explanation: the canonical gate admits",
        "13/18 beneficial manifold opportunities while rejecting 18/20 harmful ones.",
        "It is nevertheless conservative, and neutral proposals account for much of",
        "the accepted coverage. The risk-coverage CSV reports the complete fixed",
        "relative-score threshold sweep rather than selecting a threshold on test data.",
    ]
    (OUTPUT / "canonical_admission_report.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    units, protocol = collect_units()
    raw_units = raw_subspace_units(units)
    raw_confusion = confusion_rows(
        raw_units,
        truth_field="raw_subspace_test_outcome",
        accepted_field="raw_subspace_accepted",
        audit="raw_subspace_candidate",
    )
    manifold_confusion = confusion_rows(
        units,
        truth_field="manifold_test_outcome",
        accepted_field="manifold_accepted",
        audit="best_calibration_scored_manifold_proposal",
    )
    ablations = policy_rows(units)
    risk_coverage = risk_coverage_rows(units)
    summary = setting_summary(units)
    write_csv(OUTPUT / "canonical_admission_units.csv", units)
    write_csv(OUTPUT / "canonical_admission_setting_summary.csv", summary)
    write_csv(OUTPUT / "raw_subspace_confusion.csv", raw_confusion)
    write_csv(OUTPUT / "manifold_proposal_confusion.csv", manifold_confusion)
    write_csv(OUTPUT / "gate_ablation_summary.csv", ablations)
    write_csv(OUTPUT / "risk_coverage_curve.csv", risk_coverage)
    write_csv(OUTPUT / "protocol_audit.csv", [protocol])
    write_report(units, protocol, raw_confusion, manifold_confusion, ablations)
    print(OUTPUT / "canonical_admission_report.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
