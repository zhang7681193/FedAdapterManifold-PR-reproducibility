from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd


SEEDS = [0, 1, 2, 3, 4]
RNG_SEED = 20260813


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Analyze the frozen five-seed DomainNetMini-60 CLIP-LoRA confirmation."
    )
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path(__file__).resolve().parents[1]
        / "results"
        / "fam_clip_e2e_domainnet60_multiround_exactlocal_5seed_20260813",
    )
    parser.add_argument("--bootstrap-replicates", type=int, default=30000)
    return parser.parse_args()


def _pearson(x: np.ndarray, y: np.ndarray) -> float:
    if len(x) < 2 or np.std(x) < 1e-12 or np.std(y) < 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def _seed_bootstrap(
    values: np.ndarray, n_boot: int, rng: np.random.Generator
) -> tuple[float, float]:
    draws = rng.choice(values, size=(n_boot, len(values)), replace=True).mean(axis=1)
    return tuple(float(value) for value in np.quantile(draws, [0.025, 0.975]))


def _exact_sign_flip_p(values: np.ndarray) -> float:
    observed = float(values.mean())
    null = [
        float(np.mean(values * np.asarray(signs, dtype=np.float64)))
        for signs in itertools.product((-1.0, 1.0), repeat=len(values))
    ]
    return float(np.mean(np.asarray(null) >= observed - 1e-15))


def _hierarchical_correlation_bootstrap(
    rows: pd.DataFrame, n_boot: int, rng: np.random.Generator
) -> tuple[float, float]:
    seeds = np.asarray(sorted(rows["seed"].unique()), dtype=np.int64)
    blocks: dict[int, list[tuple[np.ndarray, np.ndarray]]] = {}
    for seed in seeds:
        seed_rows = rows[rows["seed"] == int(seed)]
        blocks[int(seed)] = [
            (
                frame["d_sub"].to_numpy(dtype=np.float64, copy=True),
                frame["aggregation_failure"].to_numpy(dtype=np.float64, copy=True),
            )
            for _, frame in seed_rows.groupby("receiver_client_id", sort=True)
        ]
    draws: list[float] = []
    for _ in range(n_boot):
        sampled_x: list[np.ndarray] = []
        sampled_y: list[np.ndarray] = []
        for seed in rng.choice(seeds, size=len(seeds), replace=True):
            seed_blocks = blocks[int(seed)]
            for receiver_index in rng.integers(0, len(seed_blocks), size=len(seed_blocks)):
                x_block, y_block = seed_blocks[int(receiver_index)]
                sampled_x.append(x_block)
                sampled_y.append(y_block)
        value = _pearson(np.concatenate(sampled_x), np.concatenate(sampled_y))
        if np.isfinite(value):
            draws.append(value)
    return tuple(float(value) for value in np.quantile(draws, [0.025, 0.975]))


def _controlled_subspace_effect(rows: pd.DataFrame) -> tuple[float, float]:
    def standardize(values: np.ndarray) -> np.ndarray:
        scale = float(np.std(values))
        return (values - float(np.mean(values))) / scale if scale > 1e-12 else np.zeros_like(values)

    y = standardize(rows["aggregation_failure"].to_numpy(float))
    geo = standardize(rows["d_geo"].to_numpy(float))
    sub = standardize(rows["d_sub"].to_numpy(float))
    reduced = np.column_stack([np.ones(len(rows)), geo])
    full = np.column_stack([np.ones(len(rows)), geo, sub])
    reduced_fit = reduced @ np.linalg.lstsq(reduced, y, rcond=None)[0]
    full_beta = np.linalg.lstsq(full, y, rcond=None)[0]
    full_fit = full @ full_beta
    denominator = max(float(np.sum((y - y.mean()) ** 2)), 1e-12)
    reduced_r2 = 1.0 - float(np.sum((y - reduced_fit) ** 2)) / denominator
    full_r2 = 1.0 - float(np.sum((y - full_fit) ** 2)) / denominator
    return float(full_beta[-1]), float(full_r2 - reduced_r2)


def _deployed_method_by_client(path: Path) -> dict[int, str]:
    rows = pd.read_csv(path)
    exact = rows[rows["selection_protocol"] == "receiver_tangent_exact_certificate_v1"]
    output: dict[int, str] = {}
    for client_id, frame in exact.groupby("client_id"):
        deployed = sorted(set(frame["deployed_method"].dropna().astype(str)))
        if len(deployed) != 1:
            raise RuntimeError(
                f"Expected one exact deployment for client {client_id} in {path}, found {deployed}"
            )
        output[int(client_id)] = deployed[0]
    if len(output) != 6:
        raise RuntimeError(f"Expected six receiver deployments in {path}, found {len(output)}")
    return output


def main() -> int:
    args = parse_args()
    root = args.result_root.resolve()
    rng = np.random.default_rng(RNG_SEED)
    metric_parts = []
    client_parts = []
    subspace_parts = []
    deployments: list[dict[str, object]] = []
    for seed in SEEDS:
        seed_root = root / "shot_4" / f"seed_{seed}"
        required = [
            seed_root / "metrics.csv",
            seed_root / "per_client_metrics.csv",
            seed_root / "subspace_metrics.csv",
            seed_root / "candidate_selection.csv",
        ]
        missing = [str(path) for path in required if not path.is_file()]
        if missing:
            raise RuntimeError(f"Frozen confirmation incomplete for seed {seed}: {missing}")
        for path, parts in [(required[0], metric_parts), (required[1], client_parts), (required[2], subspace_parts)]:
            frame = pd.read_csv(path)
            frame["seed"] = seed
            parts.append(frame)
        for client_id, deployed in _deployed_method_by_client(required[3]).items():
            deployments.append({"seed": seed, "client_id": client_id, "deployed_method": deployed})

    metrics = pd.concat(metric_parts, ignore_index=True)
    clients = pd.concat(client_parts, ignore_index=True)
    subspace = pd.concat(subspace_parts, ignore_index=True)

    performance_rows = []
    for method, frame in metrics.groupby("method"):
        frame = frame.sort_values("seed")
        if len(frame) != len(SEEDS):
            raise RuntimeError(f"Expected five rows for {method}, found {len(frame)}")
        values = frame["mean_accuracy"].to_numpy(float)
        low, high = _seed_bootstrap(values, args.bootstrap_replicates, rng)
        performance_rows.append(
            {
                "method": method,
                "mean_accuracy": float(values.mean()),
                "seed_sd": float(values.std(ddof=1)),
                "seed_ci_low": low,
                "seed_ci_high": high,
            }
        )
    performance = pd.DataFrame(performance_rows).sort_values("method")

    deployed_method = "FedAdapterManifold-Tangent-Certified-CLIP-LoRA"
    deployed_values = (
        metrics[metrics["method"] == deployed_method]
        .sort_values("seed")["mean_accuracy"]
        .to_numpy(float)
    )
    gain_rows = []
    for baseline in ["FedAvg-CLIP-LoRA", "FedGeo-Agg-CLIP-LoRA", "Local-CLIP-LoRA"]:
        baseline_values = (
            metrics[metrics["method"] == baseline]
            .sort_values("seed")["mean_accuracy"]
            .to_numpy(float)
        )
        effects = deployed_values - baseline_values
        low, high = _seed_bootstrap(effects, args.bootstrap_replicates, rng)
        gain_rows.append(
            {
                "comparison": f"{deployed_method} minus {baseline}",
                "mean_gain": float(effects.mean()),
                "seed_ci_low": low,
                "seed_ci_high": high,
                "sign_flip_p_one_sided": _exact_sign_flip_p(effects),
                "positive_seeds": int((effects > 1e-12).sum()),
                "ties": int(np.isclose(effects, 0.0).sum()),
                "negative_seeds": int((effects < -1e-12).sum()),
            }
        )
    gains = pd.DataFrame(gain_rows)

    raw_r = _pearson(
        subspace["d_sub"].to_numpy(float),
        subspace["aggregation_failure"].to_numpy(float),
    )
    correlation_low, correlation_high = _hierarchical_correlation_bootstrap(
        subspace, args.bootstrap_replicates, rng
    )
    seed_coefficients = []
    seed_r2 = []
    for _, frame in subspace.groupby("seed"):
        coefficient, incremental_r2 = _controlled_subspace_effect(frame)
        seed_coefficients.append(coefficient)
        seed_r2.append(incremental_r2)
    coefficient_low, coefficient_high = _seed_bootstrap(
        np.asarray(seed_coefficients), args.bootstrap_replicates, rng
    )
    diagnostics = pd.DataFrame(
        [
            {
                "distance_estimator": "final_round_d_sub",
                "pooled_pair_correlation": raw_r,
                "hierarchical_ci_low": correlation_low,
                "hierarchical_ci_high": correlation_high,
                "controlled_subspace_coefficient": float(np.mean(seed_coefficients)),
                "controlled_coefficient_ci_low": coefficient_low,
                "controlled_coefficient_ci_high": coefficient_high,
                "incremental_r2": float(np.mean(seed_r2)),
            }
        ]
    )

    local = clients[clients["method"] == "Local-CLIP-LoRA"][
        ["seed", "client_id", "domain", "accuracy"]
    ].rename(columns={"accuracy": "local_accuracy"})
    deployed = clients[clients["method"] == deployed_method][
        ["seed", "client_id", "accuracy"]
    ].rename(columns={"accuracy": "deployed_accuracy"})
    safety = local.merge(deployed, on=["seed", "client_id"], validate="one_to_one")
    safety = safety.merge(pd.DataFrame(deployments), on=["seed", "client_id"], validate="one_to_one")
    safety["gain_vs_local"] = safety["deployed_accuracy"] - safety["local_accuracy"]
    safety["selected_nonlocal"] = safety["deployed_method"] != "Local-CLIP-LoRA"
    safety["harmful_nonlocal"] = safety["selected_nonlocal"] & (safety["gain_vs_local"] < -1e-12)

    fedavg_gain = gains[gains["comparison"].str.endswith("FedAvg-CLIP-LoRA")].iloc[0]
    geo_gain = gains[gains["comparison"].str.endswith("FedGeo-Agg-CLIP-LoRA")].iloc[0]
    harmful = int(safety["harmful_nonlocal"].sum())
    nonlocal_count = int(safety["selected_nonlocal"].sum())
    report = [
        "# DomainNetMini-60 end-to-end CLIP-LoRA confirmation",
        "",
        "The five seeds, four-shot training budget, five communication rounds, candidate set, and exact Local-anchored certificate were fixed before test evaluation.",
        "",
        f"- Deployed gain versus FedAvg-LoRA: {fedavg_gain['mean_gain']:+.4f}, seed CI [{fedavg_gain['seed_ci_low']:+.4f}, {fedavg_gain['seed_ci_high']:+.4f}].",
        f"- Deployed gain versus Geo-only: {geo_gain['mean_gain']:+.4f}, seed CI [{geo_gain['seed_ci_low']:+.4f}, {geo_gain['seed_ci_high']:+.4f}].",
        f"- Certified non-local deployments: {nonlocal_count}/{len(safety)}; harmful: {harmful}/{len(safety)}.",
        f"- Final-round subspace/failure r: {raw_r:+.4f}, hierarchical CI [{correlation_low:+.4f}, {correlation_high:+.4f}].",
        f"- Controlled final-round subspace coefficient: {np.mean(seed_coefficients):+.4f}, seed CI [{coefficient_low:+.4f}, {coefficient_high:+.4f}].",
        "",
        "Interpretation is claim-bounded: a zero-harm fallback supports deployment safety, but it is not counted as positive non-local routing utility. A non-positive final-round diagnostic motivates the separately frozen pooled-projector confirmation rather than being hidden.",
    ]
    output = root / "analysis"
    output.mkdir(parents=True, exist_ok=True)
    performance.to_csv(output / "performance_summary.csv", index=False)
    gains.to_csv(output / "paired_seed_gains.csv", index=False)
    diagnostics.to_csv(output / "subspace_diagnostics.csv", index=False)
    safety.to_csv(output / "certified_safety_units.csv", index=False)
    (output / "clip_confirmation_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
