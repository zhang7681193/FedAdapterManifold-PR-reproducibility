from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd


SEEDS = tuple(range(5))
RNG_SEED = 20260814
LOCAL = "Local-CLIP-LoRA"
GEO = "FedGeo-Agg-CLIP-LoRA"
FAM = "FedAdapterManifold-CLIP-LoRA"
RAW = "FedAdapterManifold-ModeTangent-Raw-CLIP-LoRA"
DEPLOYED = "FedAdapterManifold-ModeTangent-Certified-CLIP-LoRA"
CONTROL_METHODS = (
    LOCAL,
    "FedAvg-CLIP-LoRA",
    "FedAvg-Lift-CLIP-LoRA",
    GEO,
    FAM,
)


def _as_bool(values: pd.Series) -> pd.Series:
    return values.map(lambda value: str(value).strip().lower() == "true")


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Analyze the frozen OfficeHome mode-tangent confirmation."
    )
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path(__file__).resolve().parents[1]
        / "results"
        / "fam_clip_e2e_officehome65_mode_tangent_20260814",
    )
    parser.add_argument(
        "--reference-root",
        type=Path,
        default=Path(__file__).resolve().parents[1]
        / "results"
        / "fam_clip_e2e_officehome65_temporal_projector_20260814"
        / "final-residual",
    )
    parser.add_argument("--bootstrap-replicates", type=int, default=50000)
    return parser.parse_args()


def exact_sign_flip_p(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=np.float64)
    values = values[np.abs(values) > 1e-15]
    if values.size == 0:
        return 1.0
    observed = float(values.mean())
    null = np.asarray(
        [
            np.mean(values * np.asarray(signs, dtype=np.float64))
            for signs in itertools.product((-1.0, 1.0), repeat=len(values))
        ],
        dtype=np.float64,
    )
    return float(np.mean(null >= observed - 1e-15))


def paired_summary(
    rows: pd.DataFrame,
    left: str,
    right: str,
    replicates: int,
    rng: np.random.Generator,
) -> dict[str, object]:
    effects = []
    for seed, frame in rows.groupby("seed", sort=True):
        effects.append(
            (int(seed), float((frame[left].to_numpy(float) - frame[right].to_numpy(float)).mean()))
        )
    if [seed for seed, _ in effects] != list(SEEDS):
        raise RuntimeError(f"Expected seeds {SEEDS}, found {[seed for seed, _ in effects]}")
    values = np.asarray([value for _, value in effects], dtype=np.float64)
    draws = rng.choice(values, size=(replicates, len(values)), replace=True).mean(axis=1)
    low, high = np.quantile(draws, [0.025, 0.975])
    return {
        "comparison": f"{left} minus {right}",
        "mean_gain": float(values.mean()),
        "seed_ci_low": float(low),
        "seed_ci_high": float(high),
        "positive_seeds": int(np.sum(values > 1e-12)),
        "ties": int(np.sum(np.isclose(values, 0.0))),
        "negative_seeds": int(np.sum(values < -1e-12)),
        "exact_sign_flip_p_one_sided": exact_sign_flip_p(values),
        "seed_effects": ";".join(f"{value:+.8f}" for value in values),
    }


def _load_seed(root: Path, seed: int) -> tuple[pd.DataFrame, pd.DataFrame]:
    seed_root = root / f"seed_{seed}"
    client_path = seed_root / "per_client_metrics.csv"
    route_path = seed_root / "mode_tangent_routing.csv"
    if not client_path.is_file() or not route_path.is_file():
        raise RuntimeError(f"Incomplete frozen run for seed {seed}")
    clients = pd.read_csv(client_path)
    selected = clients[clients["method"].isin([LOCAL, GEO, FAM, RAW, DEPLOYED])]
    wide = selected.pivot(
        index=["client_id", "domain"], columns="method", values="accuracy"
    ).reset_index()
    if len(wide) != 4 or wide[[LOCAL, GEO, FAM, RAW, DEPLOYED]].isna().any().any():
        raise RuntimeError(f"Incomplete client endpoints for seed {seed}")

    routes = pd.read_csv(route_path)
    candidate_rows = routes[
        (routes["selection_protocol"] == "mode_tangent_loss_first_exact_v1")
        & _as_bool(routes["selected"])
    ].copy()
    if len(candidate_rows) != 4:
        raise RuntimeError(f"Expected four fixed selected steps for seed {seed}")
    certified = _as_bool(candidate_rows.set_index("client_id")["certified"])
    wide["certified_nonlocal"] = wide["client_id"].map(certified).fillna(False)
    wide["harmful_certified"] = wide["certified_nonlocal"] & (
        wide[RAW] < wide[LOCAL] - 1e-12
    )
    wide["seed"] = seed

    test_routes = routes[
        (routes["selection_protocol"] == "mode_tangent_loss_first_exact_v1")
        & (routes["split"] == "test")
    ].copy()
    if test_routes.empty:
        raise RuntimeError(f"Missing test route manifest for seed {seed}")
    return wide, test_routes


def _matched_control_delta(root: Path, reference: Path) -> tuple[float, pd.DataFrame]:
    rows = []
    maximum = 0.0
    for seed in SEEDS:
        current = pd.read_csv(root / f"seed_{seed}" / "per_client_metrics.csv")
        prior = pd.read_csv(reference / f"seed_{seed}" / "per_client_metrics.csv")
        current = current[current["method"].isin(CONTROL_METHODS)][
            ["method", "client_id", "accuracy", "loss"]
        ]
        prior = prior[prior["method"].isin(CONTROL_METHODS)][
            ["method", "client_id", "accuracy", "loss"]
        ]
        paired = current.merge(
            prior,
            on=["method", "client_id"],
            suffixes=("_current", "_reference"),
            validate="one_to_one",
        )
        if len(paired) != 4 * len(CONTROL_METHODS):
            raise RuntimeError(f"Incomplete matched controls for seed {seed}")
        paired["seed"] = seed
        paired["accuracy_abs_delta"] = np.abs(
            paired["accuracy_current"] - paired["accuracy_reference"]
        )
        paired["loss_abs_delta"] = np.abs(
            paired["loss_current"] - paired["loss_reference"]
        )
        maximum = max(
            maximum,
            float(paired[["accuracy_abs_delta", "loss_abs_delta"]].to_numpy().max()),
        )
        rows.append(paired)
    return maximum, pd.concat(rows, ignore_index=True)


def main() -> int:
    args = parse_args()
    root = args.result_root.resolve()
    reference = args.reference_root.resolve()
    protocol_path = root / "frozen_protocol.json"
    if not protocol_path.is_file():
        raise RuntimeError(f"Missing frozen protocol: {protocol_path}")
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    if protocol.get("test_used_for_routing_or_selection") is not False:
        raise RuntimeError("Frozen protocol does not certify test-free routing")
    expected_reference_hashes = protocol.get("matched_control_per_client_sha256", {})
    for seed in SEEDS:
        path = reference / f"seed_{seed}" / "per_client_metrics.csv"
        if _sha256(path) != expected_reference_hashes.get(str(seed)):
            raise RuntimeError(f"Matched-control reference hash changed for seed {seed}")

    client_parts = []
    route_parts = []
    for seed in SEEDS:
        clients, routes = _load_seed(root, seed)
        client_parts.append(clients)
        routes["seed"] = seed
        route_parts.append(routes)
    paired = pd.concat(client_parts, ignore_index=True)
    route_rows = pd.concat(route_parts, ignore_index=True)

    rng = np.random.default_rng(RNG_SEED)
    comparisons = pd.DataFrame(
        [
            paired_summary(paired, DEPLOYED, GEO, args.bootstrap_replicates, rng),
            paired_summary(paired, DEPLOYED, LOCAL, args.bootstrap_replicates, rng),
            paired_summary(paired, DEPLOYED, FAM, args.bootstrap_replicates, rng),
            paired_summary(paired, RAW, LOCAL, args.bootstrap_replicates, rng),
        ]
    )
    matched_delta, matched_rows = _matched_control_delta(root, reference)
    gain_geo = comparisons.iloc[0]
    gain_local = comparisons.iloc[1]
    certified_count = int(paired["certified_nonlocal"].sum())
    harmful_count = int(paired["harmful_certified"].sum())
    external_mask = _as_bool(route_rows["external_route"])
    external_routes = int(external_mask.sum())
    self_routes = int((~external_mask).sum())
    success = bool(
        float(gain_geo["seed_ci_low"]) > 0.0
        and float(gain_local["seed_ci_low"]) > 0.0
        and certified_count > 0
        and harmful_count == 0
        and int(gain_local["negative_seeds"]) == 0
        and matched_delta <= 1e-12
        and external_routes > 0
        and self_routes > 0
    )
    decision = {
        "pre_registered_success": success,
        "certified_gain_vs_geo_ci_low_positive": bool(
            float(gain_geo["seed_ci_low"]) > 0.0
        ),
        "certified_gain_vs_local_ci_low_positive": bool(
            float(gain_local["seed_ci_low"]) > 0.0
        ),
        "certified_nonlocal_count": certified_count,
        "harmful_certified_count": harmful_count,
        "negative_seed_count_vs_local": int(gain_local["negative_seeds"]),
        "matched_control_max_abs_delta": matched_delta,
        "external_test_routes": external_routes,
        "self_test_routes": self_routes,
        "interpretation": "positive confirmation" if success else "criterion not met",
    }

    output = root / "analysis"
    output.mkdir(parents=True, exist_ok=True)
    paired.to_csv(output / "paired_client_units.csv", index=False)
    comparisons.to_csv(output / "paired_seed_comparisons.csv", index=False)
    route_rows.to_csv(output / "test_route_manifest.csv", index=False)
    matched_rows.to_csv(output / "matched_control_audit.csv", index=False)
    (output / "confirmation_decision.json").write_text(
        json.dumps(decision, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    report = [
        "# OfficeHome-65 mode-tangent confirmation",
        "",
        "The route, step grid, screen rule, certificate, seeds, and success criteria were frozen before the first result file. Test labels are evaluation-only.",
        "",
        f"- Pre-registered criterion: **{'PASS' if success else 'NOT MET'}**.",
        f"- Certified mode-tangent vs Geo-only: {float(gain_geo['mean_gain']):+.4f}, seed CI [{float(gain_geo['seed_ci_low']):+.4f}, {float(gain_geo['seed_ci_high']):+.4f}].",
        f"- Certified mode-tangent vs Local: {float(gain_local['mean_gain']):+.4f}, seed CI [{float(gain_local['seed_ci_low']):+.4f}, {float(gain_local['seed_ci_high']):+.4f}].",
        f"- Certified non-local receivers: {certified_count}/20; harmful certified test outcomes: {harmful_count}/20.",
        f"- Test routes: {external_routes} external and {self_routes} self.",
        f"- Matched-control maximum absolute metric delta: {matched_delta:.3e}.",
        "",
        "A failed criterion remains a negative confirmation and cannot be repaired by post-hoc threshold changes.",
    ]
    (output / "confirmation_report.md").write_text(
        "\n".join(report) + "\n", encoding="utf-8"
    )
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
