from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd


SEEDS = tuple(range(5))
ESTIMATORS = ("final-residual", "temporal-projector")
DEPLOYED_METHOD = "FedAdapterManifold-Tangent-Certified-CLIP-LoRA"
LOCAL_METHOD = "Local-CLIP-LoRA"
GEO_METHOD = "FedGeo-Agg-CLIP-LoRA"
FAM_METHOD = "FedAdapterManifold-CLIP-LoRA"
RNG_SEED = 20260814


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Analyze the frozen OfficeHome-65 temporal-projector confirmation."
    )
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path(__file__).resolve().parents[1]
        / "results"
        / "fam_clip_e2e_officehome65_temporal_projector_20260814",
    )
    parser.add_argument("--bootstrap-replicates", type=int, default=50000)
    return parser.parse_args()


def exact_sign_flip_p(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=np.float64)
    values = values[np.abs(values) > 1e-15]
    if values.size == 0:
        return 1.0
    observed = float(values.mean())
    null = np.asarray(
        [
            np.mean(values * np.asarray(signs, dtype=np.float64))
            for signs in itertools.product((-1.0, 1.0), repeat=len(values))
        ],
        dtype=np.float64,
    )
    return float(np.mean(null >= observed - 1e-15))


def seed_bootstrap_interval(
    values: np.ndarray, replicates: int, rng: np.random.Generator
) -> tuple[float, float]:
    values = np.asarray(values, dtype=np.float64)
    draws = rng.choice(values, size=(replicates, len(values)), replace=True).mean(axis=1)
    low, high = np.quantile(draws, [0.025, 0.975])
    return float(low), float(high)


def paired_summary(
    rows: pd.DataFrame,
    left: str,
    right: str,
    replicates: int,
    rng: np.random.Generator,
) -> dict[str, object]:
    effects = []
    for seed, frame in rows.groupby("seed", sort=True):
        difference = frame[left].to_numpy(float) - frame[right].to_numpy(float)
        effects.append((int(seed), float(difference.mean())))
    if [seed for seed, _ in effects] != list(SEEDS):
        raise RuntimeError(f"Expected seeds {SEEDS}, found {[seed for seed, _ in effects]}")
    seed_effects = np.asarray([value for _, value in effects], dtype=np.float64)
    low, high = seed_bootstrap_interval(seed_effects, replicates, rng)
    return {
        "comparison": f"{left} minus {right}",
        "mean_gain": float(seed_effects.mean()),
        "seed_ci_low": low,
        "seed_ci_high": high,
        "positive_seeds": int(np.sum(seed_effects > 1e-12)),
        "ties": int(np.sum(np.isclose(seed_effects, 0.0))),
        "negative_seeds": int(np.sum(seed_effects < -1e-12)),
        "exact_sign_flip_p_one_sided": exact_sign_flip_p(seed_effects),
        "seed_effects": ";".join(f"{value:+.8f}" for value in seed_effects),
    }


def _deployed_method_by_client(path: Path) -> dict[int, str]:
    rows = pd.read_csv(path)
    exact = rows[rows["selection_protocol"] == "receiver_tangent_exact_certificate_v1"]
    output: dict[int, str] = {}
    for client_id, frame in exact.groupby("client_id", sort=True):
        deployed = sorted(set(frame["deployed_method"].dropna().astype(str)))
        if len(deployed) != 1:
            raise RuntimeError(
                f"Expected one exact deployment for client {client_id} in {path}, found {deployed}"
            )
        output[int(client_id)] = deployed[0]
    if len(output) != 4:
        raise RuntimeError(f"Expected four receiver deployments in {path}, found {len(output)}")
    return output


def _load_estimator(root: Path, estimator: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    client_parts: list[pd.DataFrame] = []
    diagnostic_parts: list[pd.DataFrame] = []
    for seed in SEEDS:
        seed_root = root / estimator / f"seed_{seed}"
        required = {
            "clients": seed_root / "per_client_metrics.csv",
            "subspace": seed_root / "subspace_metrics.csv",
            "selection": seed_root / "candidate_selection.csv",
            "routing": seed_root / "routing_subspace_distance.npy",
        }
        missing = [str(path) for path in required.values() if not path.is_file()]
        if missing:
            raise RuntimeError(f"Frozen confirmation incomplete: {missing}")

        clients = pd.read_csv(required["clients"])
        selected = clients[clients["method"].isin([LOCAL_METHOD, GEO_METHOD, FAM_METHOD, DEPLOYED_METHOD])]
        wide = selected.pivot(
            index=["client_id", "domain"], columns="method", values="accuracy"
        ).reset_index()
        if len(wide) != 4 or wide[[LOCAL_METHOD, GEO_METHOD, FAM_METHOD, DEPLOYED_METHOD]].isna().any().any():
            raise RuntimeError(f"Incomplete client metrics in {required['clients']}")
        deployments = _deployed_method_by_client(required["selection"])
        wide["deployed_method"] = wide["client_id"].map(deployments)
        wide["selected_nonlocal"] = wide["deployed_method"] != LOCAL_METHOD
        wide["harmful_nonlocal"] = wide["selected_nonlocal"] & (
            wide[DEPLOYED_METHOD] < wide[LOCAL_METHOD] - 1e-12
        )
        wide["seed"] = seed
        wide["estimator"] = estimator
        client_parts.append(wide)

        subspace = pd.read_csv(required["subspace"])
        routing = np.load(required["routing"])
        if routing.shape != (4, 4):
            raise RuntimeError(f"Expected 4x4 routing matrix in {required['routing']}")
        subspace["routing_d_sub"] = [
            float(routing[int(receiver), int(donor)])
            for receiver, donor in zip(
                subspace["receiver_client_id"], subspace["donor_client_id"]
            )
        ]
        subspace["seed"] = seed
        subspace["estimator"] = estimator
        diagnostic_parts.append(subspace)
    return pd.concat(client_parts, ignore_index=True), pd.concat(diagnostic_parts, ignore_index=True)


def _pearson(x: np.ndarray, y: np.ndarray) -> float:
    if len(x) < 2 or np.std(x) < 1e-12 or np.std(y) < 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def _controlled_subspace_effect(rows: pd.DataFrame) -> tuple[float, float]:
    def standardize(values: np.ndarray) -> np.ndarray:
        scale = float(np.std(values))
        if scale <= 1e-12:
            return np.zeros_like(values)
        return (values - float(np.mean(values))) / scale

    y = standardize(rows["aggregation_failure"].to_numpy(float))
    geo = standardize(rows["d_geo"].to_numpy(float))
    sub = standardize(rows["routing_d_sub"].to_numpy(float))
    reduced = np.column_stack([np.ones(len(rows)), geo])
    full = np.column_stack([np.ones(len(rows)), geo, sub])
    reduced_fit = reduced @ np.linalg.lstsq(reduced, y, rcond=None)[0]
    full_beta = np.linalg.lstsq(full, y, rcond=None)[0]
    full_fit = full @ full_beta
    denominator = max(float(np.sum((y - y.mean()) ** 2)), 1e-12)
    reduced_r2 = 1.0 - float(np.sum((y - reduced_fit) ** 2)) / denominator
    full_r2 = 1.0 - float(np.sum((y - full_fit) ** 2)) / denominator
    return float(full_beta[-1]), float(full_r2 - reduced_r2)


def main() -> int:
    args = parse_args()
    root = args.result_root.resolve()
    protocol_path = root / "frozen_protocol.json"
    if not protocol_path.is_file():
        raise RuntimeError(f"Missing frozen protocol: {protocol_path}")
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    if protocol.get("test_used_for_selection") is not False:
        raise RuntimeError("The frozen protocol does not certify test-free selection")

    clients_by_estimator: dict[str, pd.DataFrame] = {}
    diagnostics_by_estimator: dict[str, pd.DataFrame] = {}
    for estimator in ESTIMATORS:
        clients_by_estimator[estimator], diagnostics_by_estimator[estimator] = _load_estimator(
            root, estimator
        )

    temporal = clients_by_estimator["temporal-projector"].copy()
    final = clients_by_estimator["final-residual"][
        ["seed", "client_id", DEPLOYED_METHOD]
    ].rename(columns={DEPLOYED_METHOD: "final_residual_deployed_accuracy"})
    paired = temporal.merge(final, on=["seed", "client_id"], validate="one_to_one")
    paired = paired.rename(
        columns={
            DEPLOYED_METHOD: "temporal_deployed_accuracy",
            LOCAL_METHOD: "local_accuracy",
            GEO_METHOD: "geo_accuracy",
            FAM_METHOD: "temporal_fam_candidate_accuracy",
        }
    )

    rng = np.random.default_rng(RNG_SEED)
    comparisons = pd.DataFrame(
        [
            paired_summary(
                paired,
                "temporal_deployed_accuracy",
                "geo_accuracy",
                args.bootstrap_replicates,
                rng,
            ),
            paired_summary(
                paired,
                "temporal_deployed_accuracy",
                "final_residual_deployed_accuracy",
                args.bootstrap_replicates,
                rng,
            ),
            paired_summary(
                paired,
                "temporal_deployed_accuracy",
                "local_accuracy",
                args.bootstrap_replicates,
                rng,
            ),
            paired_summary(
                paired,
                "temporal_fam_candidate_accuracy",
                "geo_accuracy",
                args.bootstrap_replicates,
                rng,
            ),
        ]
    )

    diagnostic_rows = []
    for estimator, rows in diagnostics_by_estimator.items():
        coefficients = []
        incremental_r2 = []
        correlations = []
        for _, frame in rows.groupby("seed", sort=True):
            correlations.append(
                _pearson(
                    frame["routing_d_sub"].to_numpy(float),
                    frame["aggregation_failure"].to_numpy(float),
                )
            )
            coefficient, extra_r2 = _controlled_subspace_effect(frame)
            coefficients.append(coefficient)
            incremental_r2.append(extra_r2)
        diagnostic_rows.append(
            {
                "estimator": estimator,
                "mean_seed_correlation": float(np.nanmean(correlations)),
                "mean_controlled_coefficient": float(np.mean(coefficients)),
                "mean_incremental_r2": float(np.mean(incremental_r2)),
                "seed_correlations": ";".join(f"{value:+.8f}" for value in correlations),
            }
        )
    diagnostics = pd.DataFrame(diagnostic_rows)

    gain_geo = comparisons.iloc[0]
    gain_final = comparisons.iloc[1]
    gain_local = comparisons.iloc[2]
    nonlocal_count = int(paired["selected_nonlocal"].sum())
    harmful_count = int(paired["harmful_nonlocal"].sum())
    no_negative_seed_vs_local = int(gain_local["negative_seeds"]) == 0
    success = bool(
        float(gain_geo["seed_ci_low"]) > 0.0
        and float(gain_final["seed_ci_low"]) > 0.0
        and nonlocal_count > 0
        and harmful_count == 0
        and no_negative_seed_vs_local
    )
    decision = {
        "pre_registered_success": success,
        "temporal_gain_vs_geo_ci_low_positive": bool(float(gain_geo["seed_ci_low"]) > 0.0),
        "temporal_gain_vs_final_ci_low_positive": bool(float(gain_final["seed_ci_low"]) > 0.0),
        "certified_nonlocal_count": nonlocal_count,
        "harmful_nonlocal_count": harmful_count,
        "negative_seed_count_vs_local": int(gain_local["negative_seeds"]),
        "interpretation": (
            "positive confirmation" if success else "pre-registered confirmation criterion not met"
        ),
    }

    output = root / "analysis"
    output.mkdir(parents=True, exist_ok=True)
    paired.to_csv(output / "paired_client_units.csv", index=False)
    comparisons.to_csv(output / "paired_seed_comparisons.csv", index=False)
    diagnostics.to_csv(output / "subspace_estimator_diagnostics.csv", index=False)
    (output / "confirmation_decision.json").write_text(
        json.dumps(decision, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    report = [
        "# OfficeHome-65 temporal-projector confirmation",
        "",
        "This report applies the frozen five-seed, full-65-class, five-round CLIP ViT-B/32 protocol. No test label enters routing or selection.",
        "",
        f"- Pre-registered criterion: **{'PASS' if success else 'NOT MET'}**.",
        f"- Temporal deployed vs Geo-only: {float(gain_geo['mean_gain']):+.4f}, seed CI [{float(gain_geo['seed_ci_low']):+.4f}, {float(gain_geo['seed_ci_high']):+.4f}].",
        f"- Temporal deployed vs final-residual deployed: {float(gain_final['mean_gain']):+.4f}, seed CI [{float(gain_final['seed_ci_low']):+.4f}, {float(gain_final['seed_ci_high']):+.4f}].",
        f"- Temporal deployed vs Local: {float(gain_local['mean_gain']):+.4f}, seed CI [{float(gain_local['seed_ci_low']):+.4f}, {float(gain_local['seed_ci_high']):+.4f}].",
        f"- Certified non-local deployments: {nonlocal_count}/{len(paired)}; harmful test outcomes: {harmful_count}/{len(paired)}.",
        "",
        "A failed criterion is retained as a negative confirmation and cannot be converted into a positive claim by post-hoc tuning.",
    ]
    (output / "confirmation_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
