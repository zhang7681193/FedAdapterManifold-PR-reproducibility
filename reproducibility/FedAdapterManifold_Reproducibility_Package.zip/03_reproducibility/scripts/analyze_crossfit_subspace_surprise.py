from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import numpy as np

from analyze_currentcode_subspace_failure import _parse_source, _read_directional_rows


CONTROLS = ("d_geo", "d_label")
RIDGE = 1e-6


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Leave-one-seed-out test of whether adapter-subspace surprise adds "
            "failure information beyond visual geometry and label support."
        )
    )
    parser.add_argument("--source", action="append", default=[])
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--bootstrap-replicates", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260813)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    sources = [_parse_source(value) for value in args.source]
    if not sources:
        raise ValueError("At least one --source DATASET=ROOT is required")

    source_rows: list[dict] = []
    for dataset, root in sources:
        source_rows.extend(_read_directional_rows(dataset, root))
    rows = [row for row in source_rows if _complete(row)]
    if not rows:
        raise FileNotFoundError("No complete directional rows were found")

    predictions: list[dict] = []
    for dataset in sorted({str(row["dataset"]) for row in rows}):
        family = [row for row in rows if str(row["dataset"]) == dataset]
        seeds = sorted({int(row["seed"]) for row in family})
        if len(seeds) < 3:
            raise ValueError(f"{dataset} requires at least three independent seeds")
        for heldout_seed in seeds:
            train = [row for row in family if int(row["seed"]) != heldout_seed]
            test = [row for row in family if int(row["seed"]) == heldout_seed]
            predictions.extend(_fit_predict_fold(train, test))

    family_rows = [_family_summary(dataset, predictions) for dataset in sorted({row["dataset"] for row in predictions})]
    overall = _overall_summary(predictions, int(args.bootstrap_replicates), int(args.seed))

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    _write_csv(output_dir / "crossfit_directional_predictions.csv", predictions)
    _write_csv(output_dir / "crossfit_family_summary.csv", family_rows)
    _write_csv(output_dir / "crossfit_hierarchical_summary.csv", [overall])
    _write_report(output_dir / "crossfit_subspace_surprise_report.md", family_rows, overall)
    return 0


def _complete(row: dict) -> bool:
    return all(math.isfinite(float(row[key])) for key in ["d_sub", "failure", *CONTROLS])


def _fit_predict_fold(train: list[dict], test: list[dict]) -> list[dict]:
    control_train = _matrix(train, CONTROLS)
    control_test = _matrix(test, CONTROLS)
    sub_train = np.asarray([float(row["d_sub"]) for row in train], dtype=np.float64)
    sub_test = np.asarray([float(row["d_sub"]) for row in test], dtype=np.float64)
    failure_train = np.asarray([float(row["failure"]) for row in train], dtype=np.float64)
    failure_test = np.asarray([float(row["failure"]) for row in test], dtype=np.float64)

    control_train, control_test = _standardize(control_train, control_test)
    sub_mean = float(sub_train.mean())
    sub_scale = max(float(sub_train.std()), 1e-12)
    sub_train_z = (sub_train - sub_mean) / sub_scale
    sub_test_z = (sub_test - sub_mean) / sub_scale
    failure_mean = float(failure_train.mean())
    failure_scale = max(float(failure_train.std()), 1e-12)
    failure_train_z = (failure_train - failure_mean) / failure_scale
    failure_test_z = (failure_test - failure_mean) / failure_scale

    control_design_train = np.column_stack([np.ones(len(train)), control_train])
    control_design_test = np.column_stack([np.ones(len(test)), control_test])
    beta_control = _ridge(control_design_train, failure_train_z, penalize_intercept=False)
    pred_control = control_design_test @ beta_control

    residualizer = _ridge(control_design_train, sub_train_z, penalize_intercept=False)
    surprise_train = sub_train_z - control_design_train @ residualizer
    surprise_test = sub_test_z - control_design_test @ residualizer
    full_design_train = np.column_stack([control_design_train, surprise_train])
    full_design_test = np.column_stack([control_design_test, surprise_test])
    beta_full = _ridge(full_design_train, failure_train_z, penalize_intercept=False)
    pred_full = full_design_test @ beta_full

    output = []
    for index, row in enumerate(test):
        output.append(
            {
                **row,
                "heldout_seed": int(row["seed"]),
                "subspace_surprise": float(surprise_test[index]),
                "failure_z_heldout": float(failure_test_z[index]),
                "failure_z_prediction_controls": float(pred_control[index]),
                "failure_z_prediction_controls_plus_subspace": float(pred_full[index]),
                "squared_error_controls": float((failure_test_z[index] - pred_control[index]) ** 2),
                "squared_error_controls_plus_subspace": float((failure_test_z[index] - pred_full[index]) ** 2),
                "subspace_surprise_coefficient_train": float(beta_full[-1]),
            }
        )
    return output


def _matrix(rows: list[dict], keys: tuple[str, ...]) -> np.ndarray:
    return np.asarray([[float(row[key]) for key in keys] for row in rows], dtype=np.float64)


def _standardize(train: np.ndarray, test: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    mean = train.mean(axis=0)
    scale = np.maximum(train.std(axis=0), 1e-12)
    return (train - mean) / scale, (test - mean) / scale


def _ridge(design: np.ndarray, target: np.ndarray, *, penalize_intercept: bool) -> np.ndarray:
    penalty = np.eye(design.shape[1], dtype=np.float64) * RIDGE
    if not penalize_intercept:
        penalty[0, 0] = 0.0
    return np.linalg.solve(design.T @ design + penalty, design.T @ target)


def _family_summary(dataset: str, rows: list[dict]) -> dict:
    selected = [row for row in rows if row["dataset"] == dataset]
    surprise = np.asarray([row["subspace_surprise"] for row in selected], dtype=np.float64)
    failure = np.asarray([row["failure"] for row in selected], dtype=np.float64)
    se_control = np.asarray([row["squared_error_controls"] for row in selected], dtype=np.float64)
    se_full = np.asarray([row["squared_error_controls_plus_subspace"] for row in selected], dtype=np.float64)
    seed_correlations = []
    seed_mse_gains = []
    for seed in sorted({int(row["seed"]) for row in selected}):
        current = [row for row in selected if int(row["seed"]) == seed]
        seed_correlations.append(_corr(current, "subspace_surprise", "failure"))
        seed_mse_gains.append(
            float(np.mean([row["squared_error_controls"] - row["squared_error_controls_plus_subspace"] for row in current]))
        )
    return {
        "dataset": dataset,
        "directional_rows": len(selected),
        "independent_seeds": len({row["seed"] for row in selected}),
        "crossfit_surprise_failure_r": _safe_corr(surprise, failure),
        "crossfit_mse_controls": float(se_control.mean()),
        "crossfit_mse_controls_plus_subspace": float(se_full.mean()),
        "crossfit_mse_gain": float((se_control - se_full).mean()),
        "positive_seed_surprise_correlations": sum(value > 0 for value in seed_correlations if math.isfinite(value)),
        "finite_seed_surprise_correlations": sum(math.isfinite(value) for value in seed_correlations),
        "positive_seed_mse_gains": sum(value > 0 for value in seed_mse_gains),
        "seed_mse_gains": ";".join(f"{value:.8g}" for value in seed_mse_gains),
    }


def _overall_summary(rows: list[dict], replicates: int, seed: int) -> dict:
    family_summaries = [_family_summary(dataset, rows) for dataset in sorted({row["dataset"] for row in rows})]
    point_r = float(np.mean([row["crossfit_surprise_failure_r"] for row in family_summaries]))
    point_gain = float(np.mean([row["crossfit_mse_gain"] for row in family_summaries]))
    rng = np.random.default_rng(seed)
    datasets = sorted({row["dataset"] for row in rows})
    boot_r: list[float] = []
    boot_gain: list[float] = []
    for _ in range(replicates):
        rs = []
        gains = []
        for dataset in rng.choice(datasets, size=len(datasets), replace=True):
            family = [row for row in rows if row["dataset"] == dataset]
            seeds = sorted({int(row["seed"]) for row in family})
            sampled = []
            for seed_copy, sampled_seed in enumerate(rng.choice(seeds, size=len(seeds), replace=True)):
                seed_rows = [row for row in family if int(row["seed"]) == int(sampled_seed)]
                receivers = sorted({row["receiver"] for row in seed_rows})
                for receiver_copy, receiver in enumerate(rng.choice(receivers, size=len(receivers), replace=True)):
                    for row in seed_rows:
                        if row["receiver"] == receiver:
                            copied = dict(row)
                            copied["receiver"] = f"{receiver}#{receiver_copy}"
                            copied["seed"] = seed_copy
                            sampled.append(copied)
            summary = _family_summary(str(dataset), [{**row, "dataset": str(dataset)} for row in sampled])
            if math.isfinite(summary["crossfit_surprise_failure_r"]):
                rs.append(float(summary["crossfit_surprise_failure_r"]))
            gains.append(float(summary["crossfit_mse_gain"]))
        if rs:
            boot_r.append(float(np.mean(rs)))
        if gains:
            boot_gain.append(float(np.mean(gains)))
    return {
        "measure": "crossfit_subspace_surprise_increment",
        "equal_family_surprise_failure_r": point_r,
        "r_ci_low": _quantile(boot_r, 0.025),
        "r_ci_high": _quantile(boot_r, 0.975),
        "equal_family_mse_gain": point_gain,
        "mse_gain_ci_low": _quantile(boot_gain, 0.025),
        "mse_gain_ci_high": _quantile(boot_gain, 0.975),
        "datasets": len(datasets),
        "independent_seeds": len({(row["dataset"], row["seed"]) for row in rows}),
        "directional_rows": len(rows),
        "supports_incremental_subspace_value": bool(_quantile(boot_r, 0.025) > 0.0 and _quantile(boot_gain, 0.025) > 0.0),
    }


def _corr(rows: list[dict], x_key: str, y_key: str) -> float:
    x = np.asarray([float(row[x_key]) for row in rows], dtype=np.float64)
    y = np.asarray([float(row[y_key]) for row in rows], dtype=np.float64)
    return _safe_corr(x, y)


def _safe_corr(x: np.ndarray, y: np.ndarray) -> float:
    if x.size < 3 or np.std(x) <= 1e-12 or np.std(y) <= 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def _quantile(values: list[float], quantile: float) -> float:
    finite = [value for value in values if math.isfinite(value)]
    return float(np.quantile(finite, quantile)) if finite else float("nan")


def _write_csv(path: Path, rows: list[dict]) -> None:
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _write_report(path: Path, families: list[dict], overall: dict) -> None:
    lines = [
        "# Cross-Fitted Subspace-Surprise Audit",
        "",
        "Each seed is predicted by models fit only on the remaining seeds of the same dataset. "
        "The subspace term is first residualized against visual geometry and label distance on "
        "the training seeds. Positive MSE gain means that this held-out subspace surprise improves "
        "failure prediction beyond the pre-adaptation controls.",
        "",
        "| Dataset | Seeds | Surprise/failure r | Control MSE | +subspace MSE | MSE gain | Positive seed r | Positive seed MSE gain |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in families:
        lines.append(
            f"| {row['dataset']} | {row['independent_seeds']} | "
            f"{row['crossfit_surprise_failure_r']:.4f} | {row['crossfit_mse_controls']:.6f} | "
            f"{row['crossfit_mse_controls_plus_subspace']:.6f} | {row['crossfit_mse_gain']:.6f} | "
            f"{row['positive_seed_surprise_correlations']}/{row['finite_seed_surprise_correlations']} | "
            f"{row['positive_seed_mse_gains']}/{row['independent_seeds']} |"
        )
    lines.extend(
        [
            "",
            "## Hierarchical result",
            "",
            f"- Equal-family surprise/failure r: {overall['equal_family_surprise_failure_r']:.4f}, "
            f"95% CI [{overall['r_ci_low']:.4f}, {overall['r_ci_high']:.4f}].",
            f"- Equal-family held-out MSE gain: {overall['equal_family_mse_gain']:.6f}, "
            f"95% CI [{overall['mse_gain_ci_low']:.6f}, {overall['mse_gain_ci_high']:.6f}].",
            f"- Strict incremental-value criterion supported: {overall['supports_incremental_subspace_value']}.",
            "",
            "The strict claim is supported only when both hierarchical lower bounds are positive. "
            "Otherwise subspace distance remains a stable marginal diagnostic but cannot yet be "
            "claimed as an independently predictive safety signal.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
