from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import numpy as np


NUMERIC = ["d_sub", "d_geo", "d_label", "d_update", "failure"]
PRIMARY_CONTROLS = ("d_geo", "d_label")
SENSITIVITY_CONTROLS = ("d_geo", "d_label", "d_update")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Hierarchical current-code adapter-subspace/failure inference."
    )
    parser.add_argument(
        "--source",
        action="append",
        default=[],
        help="Repeated DATASET=path/to/five-seed/root mapping.",
    )
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--bootstrap-replicates", type=int, default=5000)
    parser.add_argument("--seed", type=int, default=20260813)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    sources = [_parse_source(value) for value in args.source]
    if not sources:
        raise ValueError("At least one --source DATASET=ROOT is required")
    rows = []
    for dataset, root in sources:
        rows.extend(_read_directional_rows(dataset, root))
    if not rows:
        raise FileNotFoundError("No directional subspace rows were found")

    dataset_rows = []
    for dataset in sorted({row["dataset"] for row in rows}):
        current = [row for row in rows if row["dataset"] == dataset]
        seed_correlations = []
        for seed in sorted({int(row["seed"]) for row in current}):
            selected = [row for row in current if int(row["seed"]) == seed]
            seed_correlations.append(_corr(selected, "d_sub", "failure"))
        dataset_rows.append(
            {
                "dataset": dataset,
                "directional_rows": len(current),
                "independent_seeds": len({row["seed"] for row in current}),
                "receivers": len({row["receiver"] for row in current}),
                "pooled_d_sub_failure_r": _corr(current, "d_sub", "failure"),
                "pooled_d_geo_failure_r": _corr(current, "d_geo", "failure"),
                "pre_adapter_controlled_d_sub_beta": _controlled_beta(
                    current, controls=PRIMARY_CONTROLS
                ),
                "update_adjusted_d_sub_beta": _controlled_beta(
                    current, controls=SENSITIVITY_CONTROLS
                ),
                "positive_seed_correlations": sum(value > 0 for value in seed_correlations if math.isfinite(value)),
                "finite_seed_correlations": sum(math.isfinite(value) for value in seed_correlations),
                "seed_correlations": ";".join(
                    f"{value:.8g}" for value in seed_correlations if math.isfinite(value)
                ),
            }
        )

    rng = np.random.default_rng(int(args.seed))
    datasets = sorted({row["dataset"] for row in rows})
    boot_r = []
    boot_primary_beta = []
    boot_sensitivity_beta = []
    for replicate in range(int(args.bootstrap_replicates)):
        sampled = []
        sampled_datasets = rng.choice(datasets, size=len(datasets), replace=True)
        family_rs = []
        for copy_index, dataset in enumerate(sampled_datasets):
            current = [row for row in rows if row["dataset"] == dataset]
            resampled = _resample_seed_receiver(current, rng, f"{dataset}#{copy_index}")
            sampled.extend(resampled)
            family_rs.append(_corr(resampled, "d_sub", "failure"))
        finite_rs = [value for value in family_rs if math.isfinite(value)]
        if finite_rs:
            boot_r.append(float(np.mean(finite_rs)))
        primary_beta = _controlled_beta(sampled, controls=PRIMARY_CONTROLS)
        if math.isfinite(primary_beta):
            boot_primary_beta.append(primary_beta)
        sensitivity_beta = _controlled_beta(sampled, controls=SENSITIVITY_CONTROLS)
        if math.isfinite(sensitivity_beta):
            boot_sensitivity_beta.append(sensitivity_beta)

    point_family_r = float(
        np.mean(
            [
                row["pooled_d_sub_failure_r"]
                for row in dataset_rows
                if math.isfinite(float(row["pooled_d_sub_failure_r"]))
            ]
        )
    )
    point_primary_beta = _controlled_beta(rows, controls=PRIMARY_CONTROLS)
    point_sensitivity_beta = _controlled_beta(rows, controls=SENSITIVITY_CONTROLS)
    summary = [
        {
            "measure": "equal_family_d_sub_failure_r",
            "estimate": point_family_r,
            "hierarchical_ci_low": _quantile(boot_r, 0.025),
            "hierarchical_ci_high": _quantile(boot_r, 0.975),
            "datasets": len(datasets),
            "independent_seeds": len({(row["dataset"], row["seed"]) for row in rows}),
            "directional_rows": len(rows),
        },
        {
            "measure": "pre_adapter_controlled_standardized_d_sub_beta",
            "estimate": point_primary_beta,
            "hierarchical_ci_low": _quantile(boot_primary_beta, 0.025),
            "hierarchical_ci_high": _quantile(boot_primary_beta, 0.975),
            "controls": ";".join(PRIMARY_CONTROLS),
            "datasets": len(datasets),
            "independent_seeds": len({(row["dataset"], row["seed"]) for row in rows}),
            "directional_rows": len(rows),
        },
        {
            "measure": "update_adjusted_standardized_d_sub_beta_sensitivity",
            "estimate": point_sensitivity_beta,
            "hierarchical_ci_low": _quantile(boot_sensitivity_beta, 0.025),
            "hierarchical_ci_high": _quantile(boot_sensitivity_beta, 0.975),
            "controls": ";".join(SENSITIVITY_CONTROLS),
            "datasets": len(datasets),
            "independent_seeds": len({(row["dataset"], row["seed"]) for row in rows}),
            "directional_rows": len(rows),
        },
    ]

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    _write_csv(output_dir / "dataset_subspace_failure_summary.csv", dataset_rows)
    _write_csv(output_dir / "hierarchical_subspace_failure_summary.csv", summary)
    _write_csv(output_dir / "directional_rows.csv", rows)
    _write_report(output_dir / "currentcode_subspace_failure_report.md", dataset_rows, summary)
    return 0


def _parse_source(value: str) -> tuple[str, Path]:
    if "=" not in value:
        raise ValueError(f"Invalid --source {value!r}; expected DATASET=ROOT")
    dataset, raw_path = value.split("=", 1)
    root = Path(raw_path)
    if not root.exists():
        raise FileNotFoundError(root)
    return dataset.strip(), root


def _read_directional_rows(dataset: str, root: Path) -> list[dict]:
    rows = []
    for seed_dir in sorted(root.glob("seed_*")):
        if not seed_dir.is_dir() or not (seed_dir / "subspace_metrics.csv").exists():
            continue
        seed = int(seed_dir.name.rsplit("_", 1)[-1])
        with (seed_dir / "subspace_metrics.csv").open(
            "r", newline="", encoding="utf-8-sig"
        ) as handle:
            source_rows = list(csv.DictReader(handle))
        for source in source_rows:
            if "receiver_client_id" in source:
                rows.append(
                    _directional_row(
                        dataset,
                        seed,
                        str(source["receiver_client_id"]),
                        str(source["donor_client_id"]),
                        source,
                        "aggregation_failure",
                    )
                )
                continue
            for receiver_key, donor_key, failure_key in [
                ("client_i", "client_j", "aggregation_failure_i"),
                ("client_j", "client_i", "aggregation_failure_j"),
            ]:
                rows.append(
                    _directional_row(
                        dataset,
                        seed,
                        str(source[receiver_key]),
                        str(source[donor_key]),
                        source,
                        failure_key,
                    )
                )
    return rows


def _directional_row(dataset, seed, receiver, donor, source, failure_key) -> dict:
    def number(key: str) -> float:
        try:
            return float(source.get(key, "nan"))
        except (TypeError, ValueError):
            return float("nan")

    return {
        "dataset": dataset,
        "seed": int(seed),
        "receiver": receiver,
        "donor": donor,
        "d_sub": number("d_sub"),
        "d_geo": number("d_geo"),
        "d_label": number("d_label"),
        "d_update": number("d_update"),
        "failure": number(failure_key),
    }


def _resample_seed_receiver(rows: list[dict], rng: np.random.Generator, dataset_copy: str) -> list[dict]:
    seeds = sorted({int(row["seed"]) for row in rows})
    output = []
    for seed_copy, sampled_seed in enumerate(rng.choice(seeds, size=len(seeds), replace=True)):
        seed_rows = [row for row in rows if int(row["seed"]) == int(sampled_seed)]
        receivers = sorted({row["receiver"] for row in seed_rows})
        for receiver_copy, sampled_receiver in enumerate(
            rng.choice(receivers, size=len(receivers), replace=True)
        ):
            for row in seed_rows:
                if row["receiver"] != sampled_receiver:
                    continue
                copied = dict(row)
                copied["dataset"] = dataset_copy
                copied["seed"] = seed_copy
                copied["receiver"] = f"{sampled_receiver}#{receiver_copy}"
                output.append(copied)
    return output


def _corr(rows: list[dict], x_key: str, y_key: str) -> float:
    pairs = [
        (float(row[x_key]), float(row[y_key]))
        for row in rows
        if math.isfinite(float(row[x_key])) and math.isfinite(float(row[y_key]))
    ]
    if len(pairs) < 3:
        return float("nan")
    x, y = np.asarray(pairs, dtype=np.float64).T
    if np.std(x) <= 1e-12 or np.std(y) <= 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def _controlled_beta(
    rows: list[dict],
    controls: tuple[str, ...] = SENSITIVITY_CONTROLS,
) -> float:
    complete = [
        row
        for row in rows
        if all(math.isfinite(float(row[key])) for key in ["d_sub", "failure", *controls])
    ]
    if len(complete) < 10:
        return float("nan")
    dataset_ids = sorted({row["dataset"] for row in complete})
    standardized = []
    for dataset in dataset_ids:
        subset = [row for row in complete if row["dataset"] == dataset]
        arrays = {
            key: np.asarray([float(row[key]) for row in subset], dtype=np.float64)
            for key in ["d_sub", "failure", *controls]
        }
        for index, row in enumerate(subset):
            item = dict(row)
            for key, values in arrays.items():
                item[key] = float((values[index] - values.mean()) / max(values.std(), 1e-12))
            standardized.append(item)

    seed_levels = sorted({(row["dataset"], row["seed"]) for row in standardized})
    receiver_levels = sorted({(row["dataset"], row["receiver"]) for row in standardized})
    design = []
    target = []
    for row in standardized:
        values = [1.0, row["d_sub"], *(row[key] for key in controls)]
        values.extend(float((row["dataset"], row["seed"]) == level) for level in seed_levels[1:])
        values.extend(
            float((row["dataset"], row["receiver"]) == level)
            for level in receiver_levels[1:]
        )
        design.append(values)
        target.append(float(row["failure"]))
    coefficient = np.linalg.lstsq(
        np.asarray(design, dtype=np.float64),
        np.asarray(target, dtype=np.float64),
        rcond=None,
    )[0]
    return float(coefficient[1])


def _quantile(values: list[float], quantile: float) -> float:
    finite = [value for value in values if math.isfinite(value)]
    return float(np.quantile(finite, quantile)) if finite else float("nan")


def _write_csv(path: Path, rows: list[dict]) -> None:
    fieldnames = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _write_report(path: Path, dataset_rows: list[dict], summary: list[dict]) -> None:
    lines = [
        "# Current-Code Subspace/Failure Analysis",
        "",
        "Only runs using the corrected shared server LoRA initialization are included.",
        "Inference resamples dataset families, seeds within family, and receivers within seed.",
        "The primary incremental test controls only pre-adaptation visual geometry and label support. "
        "Full-update distance is post-adaptation and algebraically coupled to subspace mismatch, so "
        "including it is reported separately as an over-adjusted sensitivity analysis.",
        "",
        "| Dataset | Rows | d_sub r | Pre-adapter controlled beta | Update-adjusted beta | Positive seed r |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in dataset_rows:
        lines.append(
            f"| {row['dataset']} | {row['directional_rows']} | "
            f"{float(row['pooled_d_sub_failure_r']):.4f} | "
            f"{float(row['pre_adapter_controlled_d_sub_beta']):.4f} | "
            f"{float(row['update_adjusted_d_sub_beta']):.4f} | "
            f"{row['positive_seed_correlations']}/{row['finite_seed_correlations']} |"
        )
    lines.extend(["", "## Hierarchical inference", ""])
    for row in summary:
        lines.append(
            f"- {row['measure']}: {float(row['estimate']):.4f}, 95% CI "
            f"[{float(row['hierarchical_ci_low']):.4f}, "
            f"{float(row['hierarchical_ci_high']):.4f}]."
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
