from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np


CATEGORIES = {
    "fedavg": ("FedAvg-LoRA",),
    "algebraic": (
        "FedAvg-Lift",
        "FedRot-LoRA",
        "FedEx-LoRA",
        "FedSA-LoRA",
        "FedSmoothLoRA",
        "FedSmoothLoRA-RankMatched",
    ),
    "capacity_selection_control": (
        "CumulativeFull-Gate-Control",
        "CumulativeFull-ScreenedBudget-Control",
        "CumulativeFull-CompetitiveBudget-Control",
    ),
    "hierarchical": ("FedLEASE-OfficialPort", "HiLoRA-Visual", "Clustered-LoRA"),
    "geometry": ("FedGeo-Agg",),
    "personalization": ("Local-LoRA", "FedPer-LoRA", "Ditto-LoRA"),
    "semantic": (
        "FedAdapterManifold-DisagreementRoute",
        "FedAdapterManifold-CumulativeCompetitiveAdmit",
        "FedAdapterManifold-CumulativeBlockwiseJointAdmit",
        "FedAdapterManifold-CumulativeBlockwiseAdmit",
        "FedAdapterManifold-CumulativeScreenedAdmit",
        "FedAdapterManifold-CumulativeAdmit",
        "FedAdapterManifold-CumulativeAdmit-RankMatched",
        "FedAdapterManifold-DecoupledAdmit",
        "FedAdapterManifold-Admit",
        "FedAdapterManifold-PathAdmit",
    ),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Decompose empirical failures into theory-defined terms.")
    parser.add_argument("--result-root", action="append", required=True)
    parser.add_argument("--output-dir", default="results/decoupled_failure_diagnosis_20260810")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    rows = _load_rows([Path(value) for value in args.result_root])
    seed_rows = diagnose(rows)
    dataset_rows = aggregate(seed_rows)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    _write_csv(output / "seed_failure_decomposition.csv", seed_rows)
    _write_csv(output / "dataset_failure_decomposition.csv", dataset_rows)
    _write_report(output / "decoupled_failure_report.md", dataset_rows)
    return 0


def diagnose(rows: list[dict]) -> list[dict]:
    grouped: dict[tuple[str, int], list[dict]] = {}
    for row in rows:
        grouped.setdefault((str(row["audit_dataset"]), int(row["seed"])), []).append(row)
    output: list[dict] = []
    for (dataset, seed), group in sorted(grouped.items()):
        means = _method_means(group)
        fedavg_method, fedavg = _best(means, CATEGORIES["fedavg"])
        algebraic_method, algebraic = _best(means, CATEGORIES["algebraic"])
        hierarchy_method, hierarchy = _best(means, CATEGORIES["hierarchical"])
        geometry_method, geometry = _best(means, CATEGORIES["geometry"])
        personal_method, personal = _best(means, CATEGORIES["personalization"])
        semantic_method, semantic = _best(means, CATEGORIES["semantic"])
        old_admit = means.get("FedAdapterManifold-Admit", float("nan"))
        decoupled = means.get("FedAdapterManifold-DecoupledAdmit", float("nan"))
        cumulative_admit = means.get("FedAdapterManifold-CumulativeAdmit", float("nan"))
        cumulative_full_gate = means.get("CumulativeFull-Gate-Control", float("nan"))
        cumulative_screened = means.get("FedAdapterManifold-CumulativeScreenedAdmit", float("nan"))
        cumulative_screened_control = means.get("CumulativeFull-ScreenedBudget-Control", float("nan"))
        cumulative_blockwise = means.get("FedAdapterManifold-CumulativeBlockwiseAdmit", float("nan"))
        cumulative_blockwise_control = means.get("CumulativeSelectedSource-Scalar-Control", float("nan"))
        cumulative_blockwise_joint = means.get(
            "FedAdapterManifold-CumulativeBlockwiseJointAdmit", float("nan")
        )
        cumulative_blockwise_joint_control = means.get(
            "CumulativeFull-BlockwiseBudget-Control", float("nan")
        )
        fedsmooth_full = means.get("FedSmoothLoRA", float("nan"))
        fedsmooth_rank_matched = means.get("FedSmoothLoRA-RankMatched", float("nan"))
        competitors = {
            "algebraic": (algebraic_method, algebraic),
            "latent_hierarchy": (hierarchy_method, hierarchy),
            "geometry_ceiling": (geometry_method, geometry),
            "personalization_ceiling": (personal_method, personal),
        }
        valid_competitors = {key: value for key, value in competitors.items() if np.isfinite(value[1])}
        limiting_term = "not_identifiable"
        best_competitor_method = ""
        best_competitor = float("nan")
        if valid_competitors:
            limiting_term, (best_competitor_method, best_competitor) = max(
                valid_competitors.items(), key=lambda item: item[1][1]
            )
        residual_gap = best_competitor - semantic if np.isfinite(best_competitor) and np.isfinite(semantic) else float("nan")
        if np.isfinite(residual_gap) and residual_gap <= 1e-12:
            status = "resolved_on_this_seed"
            remedy = "retain receiver-specific semantic admission; confirm on frozen seeds"
        else:
            status = "unresolved_development_seed"
            remedy = {
                "algebraic": "separate cumulative/full-update capacity from semantic projection; compare rank-matched recurrence",
                "latent_hierarchy": "replace one-center donor proposal by fixed K-center action candidates before joint admission",
                "geometry_ceiling": "remove provider graph as a coverage veto; use provider-independent core/tangent proposals",
                "personalization_ceiling": "use an anchor-to-manifold path and certify only a positive receiver-specific step",
                "not_identifiable": "collect the missing matched control before changing the method",
            }[limiting_term]
        output.append(
            {
                "dataset": dataset,
                "seed": seed,
                "fedavg_accuracy": fedavg,
                "best_algebraic_method": algebraic_method,
                "best_algebraic_accuracy": algebraic,
                "best_hierarchy_method": hierarchy_method,
                "best_hierarchy_accuracy": hierarchy,
                "geometry_accuracy": geometry,
                "best_personal_method": personal_method,
                "best_personal_accuracy": personal,
                "best_semantic_method": semantic_method,
                "best_semantic_accuracy": semantic,
                "old_admit_accuracy": old_admit,
                "decoupled_admit_accuracy": decoupled,
                "fedavg_repair": semantic - fedavg if np.isfinite(semantic) and np.isfinite(fedavg) else float("nan"),
                "decoupling_recovery": decoupled - old_admit
                if np.isfinite(decoupled) and np.isfinite(old_admit)
                else float("nan"),
                "cumulative_capacity_gain": fedsmooth_full - fedsmooth_rank_matched
                if np.isfinite(fedsmooth_full) and np.isfinite(fedsmooth_rank_matched)
                else float("nan"),
                "receiver_action_decoupling_gain": cumulative_admit - cumulative_full_gate
                if np.isfinite(cumulative_admit) and np.isfinite(cumulative_full_gate)
                else float("nan"),
                "screened_receiver_action_gain": cumulative_screened - cumulative_screened_control
                if np.isfinite(cumulative_screened) and np.isfinite(cumulative_screened_control)
                else float("nan"),
                "blockwise_receiver_action_gain": cumulative_blockwise - cumulative_blockwise_control
                if np.isfinite(cumulative_blockwise) and np.isfinite(cumulative_blockwise_control)
                else float("nan"),
                "blockwise_joint_gain": cumulative_blockwise_joint - cumulative_blockwise_joint_control
                if np.isfinite(cumulative_blockwise_joint)
                and np.isfinite(cumulative_blockwise_joint_control)
                else float("nan"),
                "best_competitor_method": best_competitor_method,
                "best_competitor_accuracy": best_competitor,
                "residual_gap": residual_gap,
                "limiting_term": limiting_term,
                "development_status": status,
                "theory_prescribed_remedy": remedy,
            }
        )
    return output


def aggregate(rows: list[dict]) -> list[dict]:
    grouped: dict[str, list[dict]] = {}
    for row in rows:
        grouped.setdefault(str(row["dataset"]), []).append(row)
    output: list[dict] = []
    for dataset, group in sorted(grouped.items()):
        residuals = np.asarray([float(row["residual_gap"]) for row in group], dtype=np.float64)
        repairs = np.asarray([float(row["fedavg_repair"]) for row in group], dtype=np.float64)
        recoveries = np.asarray([float(row["decoupling_recovery"]) for row in group], dtype=np.float64)
        capacity_gains = np.asarray([float(row["cumulative_capacity_gain"]) for row in group], dtype=np.float64)
        action_gains = np.asarray([float(row["receiver_action_decoupling_gain"]) for row in group], dtype=np.float64)
        screened_action_gains = np.asarray(
            [float(row["screened_receiver_action_gain"]) for row in group], dtype=np.float64
        )
        blockwise_action_gains = np.asarray(
            [float(row["blockwise_receiver_action_gain"]) for row in group], dtype=np.float64
        )
        blockwise_joint_gains = np.asarray(
            [float(row["blockwise_joint_gain"]) for row in group], dtype=np.float64
        )
        finite_residuals = residuals[np.isfinite(residuals)]
        finite_repairs = repairs[np.isfinite(repairs)]
        finite_recoveries = recoveries[np.isfinite(recoveries)]
        finite_capacity_gains = capacity_gains[np.isfinite(capacity_gains)]
        finite_action_gains = action_gains[np.isfinite(action_gains)]
        finite_screened_action_gains = screened_action_gains[np.isfinite(screened_action_gains)]
        finite_blockwise_action_gains = blockwise_action_gains[np.isfinite(blockwise_action_gains)]
        finite_blockwise_joint_gains = blockwise_joint_gains[np.isfinite(blockwise_joint_gains)]
        terms = [str(row["limiting_term"]) for row in group]
        output.append(
            {
                "dataset": dataset,
                "seed_count": len(group),
                "mean_fedavg_repair": float(finite_repairs.mean()) if finite_repairs.size else float("nan"),
                "mean_decoupling_recovery": float(finite_recoveries.mean()) if finite_recoveries.size else float("nan"),
                "mean_cumulative_capacity_gain": float(finite_capacity_gains.mean())
                if finite_capacity_gains.size
                else float("nan"),
                "mean_receiver_action_decoupling_gain": float(finite_action_gains.mean())
                if finite_action_gains.size
                else float("nan"),
                "receiver_action_nonnegative_seed_count": int(np.sum(finite_action_gains >= -1e-12)),
                "mean_screened_receiver_action_gain": float(finite_screened_action_gains.mean())
                if finite_screened_action_gains.size
                else float("nan"),
                "screened_receiver_action_nonnegative_seed_count": int(
                    np.sum(finite_screened_action_gains >= -1e-12)
                ),
                "mean_blockwise_receiver_action_gain": float(finite_blockwise_action_gains.mean())
                if finite_blockwise_action_gains.size
                else float("nan"),
                "blockwise_receiver_action_nonnegative_seed_count": int(
                    np.sum(finite_blockwise_action_gains >= -1e-12)
                ),
                "mean_blockwise_joint_gain": float(finite_blockwise_joint_gains.mean())
                if finite_blockwise_joint_gains.size
                else float("nan"),
                "blockwise_joint_nonnegative_seed_count": int(
                    np.sum(finite_blockwise_joint_gains >= -1e-12)
                ),
                "mean_residual_gap": float(finite_residuals.mean()) if finite_residuals.size else float("nan"),
                "resolved_seed_count": int(np.sum(finite_residuals <= 1e-12)),
                "dominant_limiting_term": max(set(terms), key=terms.count) if terms else "not_identifiable",
                "confirmatory_ready": bool(len(group) >= 2 and finite_residuals.size == len(group)),
            }
        )
    return output


def _load_rows(roots: list[Path]) -> list[dict]:
    unique: dict[tuple[str, int, str, str], dict] = {}
    for root in roots:
        for path in sorted(root.glob("*/seed_*/per_client_metrics.csv")):
            dataset = path.parents[1].name
            with path.open("r", encoding="utf-8-sig", newline="") as handle:
                rows = list(csv.DictReader(handle))
            for row in rows:
                row["audit_dataset"] = dataset
                row["seed"] = int(row["seed"])
                row["accuracy"] = float(row["accuracy"])
                key = (dataset, int(row["seed"]), str(row["method"]), str(row["client_id"]))
                previous = unique.get(key)
                if previous is not None and not np.isclose(previous["accuracy"], row["accuracy"], atol=1e-12):
                    raise ValueError(f"Conflicting result for {key}")
                unique[key] = row
    return list(unique.values())


def _method_means(rows: list[dict]) -> dict[str, float]:
    grouped: dict[str, list[float]] = {}
    for row in rows:
        grouped.setdefault(str(row["method"]), []).append(float(row["accuracy"]))
    return {method: float(np.mean(values)) for method, values in grouped.items()}


def _best(means: dict[str, float], methods: tuple[str, ...]) -> tuple[str, float]:
    available = [(method, means[method]) for method in methods if method in means]
    return max(available, key=lambda item: item[1]) if available else ("", float("nan"))


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    fields = list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _write_report(path: Path, rows: list[dict]) -> None:
    lines = [
        "# Theory-to-Experiment Failure Decomposition",
        "",
        "The diagnosis is computed before any claim update. A negative result is assigned to the theory-defined residual term that wins under the matched protocol; test accuracy is not used to tune the confirmatory seeds.",
        "",
        "| Dataset | Seeds | FedAvg repair | One-shot recovery | Capacity gain | Joint action gain | Screened action gain | Blockwise action gain | Blockwise+full gain | Residual gap | Dominant term |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for row in rows:
        lines.append(
            f"| {row['dataset']} | {row['seed_count']} | {float(row['mean_fedavg_repair']):.4f} | "
            f"{float(row['mean_decoupling_recovery']):.4f} | "
            f"{float(row['mean_cumulative_capacity_gain']):.4f} | "
            f"{float(row['mean_receiver_action_decoupling_gain']):.4f} | "
            f"{float(row['mean_screened_receiver_action_gain']):.4f} | "
            f"{float(row['mean_blockwise_receiver_action_gain']):.4f} | "
            f"{float(row['mean_blockwise_joint_gain']):.4f} | "
            f"{float(row['mean_residual_gap']):.4f} | "
            f"{row['dominant_limiting_term']} |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
