from __future__ import annotations

import argparse
import csv
import itertools
from pathlib import Path

import numpy as np


METRICS = (
    ("accuracy_gain", "accuracy", 1.0),
    ("worst_client_accuracy_gain", "accuracy", 1.0),
    ("loss_reduction", "loss", -1.0),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Paired seed audit for receiver-decoupled dual transport.")
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--extra-input-dir", action="append", default=[])
    parser.add_argument("--output-dir")
    parser.add_argument("--method", default="FedAdapterManifold-DualTransport")
    parser.add_argument("--anchor", default="FedAdapterManifold-SharedAxisCenter")
    parser.add_argument("--bootstrap-replicates", type=int, default=200000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260804)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    input_dir = Path(args.input_dir)
    input_dirs = [input_dir, *(Path(value) for value in args.extra_input_dir)]
    output_dir = Path(args.output_dir) if args.output_dir else input_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    observed_seed_sets = []
    for source in input_dirs:
        source_rows = read_csv(source / "per_client_metrics.csv")
        source_seeds = {int(row["seed"]) for row in source_rows}
        if any(source_seeds & existing for existing in observed_seed_sets):
            raise ValueError(f"Input directories contain overlapping seeds: {source}")
        observed_seed_sets.append(source_seeds)
        rows.extend(source_rows)
    seed_rows, paired_rows, receiver_rows = analyze(
        rows,
        method=str(args.method),
        anchor=str(args.anchor),
        replicates=int(args.bootstrap_replicates),
        bootstrap_seed=int(args.bootstrap_seed),
    )
    write_csv(output_dir / "dual_transport_seed_metrics.csv", seed_rows)
    write_csv(output_dir / "dual_transport_paired_statistics.csv", paired_rows)
    write_csv(output_dir / "dual_transport_receiver_deltas.csv", receiver_rows)
    gate_rows = []
    for source in input_dirs:
        gate_path = source / "admission_gates.csv"
        if gate_path.exists():
            gate_rows.extend(read_csv(gate_path))
    if gate_rows:
        certificate_rows = reconstruct_certificates(gate_rows, method=str(args.method))
        write_csv(output_dir / "dual_transport_certificates.csv", certificate_rows)
    write_report(output_dir / "dual_transport_report.md", str(args.method), str(args.anchor), paired_rows, receiver_rows)
    return 0


def analyze(
    rows: list[dict],
    method: str,
    anchor: str,
    replicates: int,
    bootstrap_seed: int,
) -> tuple[list[dict], list[dict], list[dict]]:
    method_by_seed = seed_metrics(rows, method)
    anchor_by_seed = seed_metrics(rows, anchor)
    seed_ids = sorted(set(method_by_seed) & set(anchor_by_seed))
    if not seed_ids:
        raise ValueError(f"No matched seeds for {method!r} and {anchor!r}")
    if set(method_by_seed) != set(anchor_by_seed):
        raise ValueError("Method and anchor seed sets do not match")

    seed_rows = []
    for seed in seed_ids:
        method_row = method_by_seed[seed]
        anchor_row = anchor_by_seed[seed]
        seed_rows.append(
            {
                "seed": seed,
                "method": method,
                "anchor": anchor,
                "method_accuracy": method_row["accuracy"],
                "anchor_accuracy": anchor_row["accuracy"],
                "accuracy_gain": method_row["accuracy"] - anchor_row["accuracy"],
                "method_worst_client_accuracy": method_row["worst_client_accuracy"],
                "anchor_worst_client_accuracy": anchor_row["worst_client_accuracy"],
                "worst_client_accuracy_gain": method_row["worst_client_accuracy"]
                - anchor_row["worst_client_accuracy"],
                "method_loss": method_row["loss"],
                "anchor_loss": anchor_row["loss"],
                "loss_reduction": anchor_row["loss"] - method_row["loss"],
            }
        )

    rng = np.random.default_rng(bootstrap_seed)
    paired_rows = []
    for metric_name, _, _ in METRICS:
        effects = np.asarray([float(row[metric_name]) for row in seed_rows], dtype=np.float64)
        bootstrap = effects[
            rng.integers(0, effects.size, size=(max(1, replicates), effects.size))
        ].mean(axis=1)
        paired_rows.append(
            {
                "method": method,
                "anchor": anchor,
                "metric": metric_name,
                "seed_count": len(seed_ids),
                "estimate": float(effects.mean()),
                "ci95_low": float(np.quantile(bootstrap, 0.025)),
                "ci95_high": float(np.quantile(bootstrap, 0.975)),
                "positive_seed_count": int(np.sum(effects > 1e-15)),
                "tie_seed_count": int(np.sum(np.abs(effects) <= 1e-15)),
                "negative_seed_count": int(np.sum(effects < -1e-15)),
                "exact_sign_flip_p_one_sided": exact_sign_flip_p(effects),
                "bootstrap_replicates": max(1, replicates),
                "bootstrap_seed": bootstrap_seed,
            }
        )

    method_rows = keyed_client_rows(rows, method)
    anchor_rows = keyed_client_rows(rows, anchor)
    if set(method_rows) != set(anchor_rows):
        raise ValueError("Method and anchor client-seed units do not match")
    receiver_rows = []
    for key in sorted(method_rows):
        method_row = method_rows[key]
        anchor_row = anchor_rows[key]
        receiver_rows.append(
            {
                "seed": key[0],
                "client_id": key[1],
                "domain": str(method_row.get("domain", "")),
                "method": method,
                "anchor": anchor,
                "method_accuracy": float(method_row["accuracy"]),
                "anchor_accuracy": float(anchor_row["accuracy"]),
                "accuracy_gain": float(method_row["accuracy"]) - float(anchor_row["accuracy"]),
                "method_loss": float(method_row["loss"]),
                "anchor_loss": float(anchor_row["loss"]),
                "loss_reduction": float(anchor_row["loss"]) - float(method_row["loss"]),
            }
        )
    return seed_rows, paired_rows, receiver_rows


def seed_metrics(rows: list[dict], method: str) -> dict[int, dict[str, float]]:
    grouped: dict[int, list[dict]] = {}
    for row in rows:
        if str(row.get("method")) == method:
            grouped.setdefault(int(row["seed"]), []).append(row)
    output = {}
    for seed, group in grouped.items():
        accuracies = np.asarray([float(row["accuracy"]) for row in group], dtype=np.float64)
        losses = np.asarray([float(row["loss"]) for row in group], dtype=np.float64)
        output[seed] = {
            "accuracy": float(accuracies.mean()),
            "worst_client_accuracy": float(accuracies.min()),
            "loss": float(losses.mean()),
        }
    return output


def keyed_client_rows(rows: list[dict], method: str) -> dict[tuple[int, str], dict]:
    return {
        (int(row["seed"]), str(row["client_id"])): row
        for row in rows
        if str(row.get("method")) == method
    }


def exact_sign_flip_p(values: np.ndarray) -> float:
    nonzero = np.asarray(values[np.abs(values) > 1e-15], dtype=np.float64)
    if nonzero.size == 0:
        return 1.0
    observed = float(nonzero.mean())
    exceed = 0
    total = 0
    for signs in itertools.product((-1.0, 1.0), repeat=nonzero.size):
        total += 1
        permuted = float(np.mean(np.asarray(signs, dtype=np.float64) * nonzero))
        if permuted >= observed - 1e-15:
            exceed += 1
    return float(exceed / total)


def reconstruct_certificates(rows: list[dict], method: str) -> list[dict]:
    grouped: dict[tuple[int, str], list[dict]] = {}
    for row in rows:
        if str(row.get("method")) == method:
            grouped.setdefault((int(row["seed"]), str(row["client_id"])), []).append(row)
    output = []
    for (seed, client_id), group in sorted(grouped.items()):
        by_candidate = {str(row.get("candidate_adapter")): row for row in group}
        for row in group:
            anchor_name = str(row.get("worst_certificate_anchor", ""))
            if not anchor_name or anchor_name not in by_candidate:
                continue
            candidate_name = str(row.get("candidate_adapter", ""))
            if candidate_name == anchor_name:
                continue
            candidate_loss = float(row["candidate_graph_mix_loss"])
            anchor_loss = float(by_candidate[anchor_name]["candidate_graph_mix_loss"])
            paired_mean = candidate_loss - anchor_loss
            ucb = float(row["paired_loss_upper_confidence_bound"])
            z_value = float(row["residual_bank_z_value"])
            standard_error = (ucb - paired_mean) / z_value if z_value > 0.0 else float("nan")
            output.append(
                {
                    "seed": seed,
                    "client_id": client_id,
                    "domain": str(row.get("domain", "")),
                    "candidate_adapter": candidate_name,
                    "certificate_anchor_names": str(row.get("certificate_anchor_names", "")),
                    "worst_certificate_anchor": anchor_name,
                    "candidate_calibration_loss": candidate_loss,
                    "worst_anchor_calibration_loss": anchor_loss,
                    "paired_loss_difference_vs_worst_anchor": paired_mean,
                    "paired_loss_standard_error_vs_worst_anchor": standard_error,
                    "paired_loss_upper_confidence_bound": ucb,
                    "all_anchor_ucb_certified": str(row.get("all_anchor_ucb_certified", "")).lower() == "true",
                    "selected_adapter": str(row.get("selected_adapter", "")),
                }
            )
    return output


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_report(path: Path, method: str, anchor: str, paired: list[dict], receivers: list[dict]) -> None:
    lines = [
        "# Dual-Transport Paired Audit",
        "",
        f"Method: `{method}`  ",
        f"Anchor: `{anchor}`",
        "",
        "Confidence intervals resample independent seeds. Exact sign-flip tests remove zero effects before enumeration.",
        "",
        "| Metric | Effect | 95% seed-bootstrap CI | Positive / tie / negative seeds | Exact one-sided p |",
        "|---|---:|---:|---:|---:|",
    ]
    for row in paired:
        lines.append(
            f"| {row['metric']} | {float(row['estimate']):.6f} | "
            f"[{float(row['ci95_low']):.6f}, {float(row['ci95_high']):.6f}] | "
            f"{row['positive_seed_count']} / {row['tie_seed_count']} / {row['negative_seed_count']} | "
            f"{float(row['exact_sign_flip_p_one_sided']):.6f} |"
        )
    accuracy = np.asarray([float(row["accuracy_gain"]) for row in receivers], dtype=np.float64)
    loss = np.asarray([float(row["loss_reduction"]) for row in receivers], dtype=np.float64)
    lines.extend(
        [
            "",
            "## Receiver-level audit",
            "",
            f"Accuracy units: {(accuracy > 1e-15).sum()} positive, {(np.abs(accuracy) <= 1e-15).sum()} ties, {(accuracy < -1e-15).sum()} negative.",
            f"Loss units: {(loss > 1e-15).sum()} positive, {(np.abs(loss) <= 1e-15).sum()} ties, {(loss < -1e-15).sum()} negative.",
            "",
            "A positive effect means the dual-transport method improves over the anchor.",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
