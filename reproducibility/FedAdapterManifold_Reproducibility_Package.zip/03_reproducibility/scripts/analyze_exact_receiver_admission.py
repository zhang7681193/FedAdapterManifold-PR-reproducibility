from __future__ import annotations

import argparse
import csv
import itertools
import json
from pathlib import Path

import numpy as np


_TRAINING_ONLY_SELECTION_SPLITS = {
    "adapter_training",
    "nested_training_validation",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit immutable-Local exact receiver admission.")
    parser.add_argument("--result-root", required=True)
    parser.add_argument(
        "--certificate-file",
        choices=["signed_tangent_admission.csv", "semantic_admission_exact_certificate.csv"],
        default="signed_tangent_admission.csv",
    )
    parser.add_argument("--bootstrap-replicates", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260813)
    parser.add_argument(
        "--semantic-candidate-name",
        default="auto",
        help="Exact semantic endpoint name, or 'auto' to infer the unique non-Local/non-Geo endpoint per client.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.result_root)
    paths = sorted(root.glob(f"**/seed_*/{args.certificate_file}"))
    direct_path = root / args.certificate_file
    if not paths and direct_path.is_file():
        paths = [direct_path]
    if not paths:
        raise FileNotFoundError(f"No {args.certificate_file} under {root}")
    rng = np.random.default_rng(int(args.seed))
    units: list[dict] = []
    protocols: list[dict] = []
    for path in paths:
        config = _read_yaml_scalars(path.parent / "config.yaml")
        if path.parent.name.startswith("seed_"):
            run_label = path.parent.parent.relative_to(root).as_posix()
            seed = int(path.parent.name.split("_")[-1])
        else:
            run_label = root.name
            seed = int(float(config.get("seed", 0)))
        rows = _read_csv(path)
        screen_rows, screen = _selected_screen(path.parent)
        provenance_path = path.parent / "run_provenance.json"
        provenance = json.loads(provenance_path.read_text(encoding="utf-8")) if provenance_path.is_file() else {}
        protocols.append(
            {
                "run_label": run_label,
                "seed": seed,
                "calibration_fraction": float(config.get("candidate_selector_calibration_fraction", 0.0)),
                "calibration_strategy": str(config.get("candidate_selector_calibration_strategy", "")),
                "package_source_sha256": str(provenance.get("package_source_sha256", "")),
                "geometry_inputs_sha256": str(provenance.get("geometry_inputs_sha256", "")),
                "provenance_present": provenance_path.is_file(),
                "test_free_selection": all(not _as_bool(row.get("test_used_for_selection", False)) for row in rows),
                "training_screen_present": bool(screen_rows),
                "training_screen_isolation": _training_screen_isolated(screen_rows),
                "serial_holm_expected": args.certificate_file == "semantic_admission_exact_certificate.csv",
                "serial_holm_runtime_match": all(
                    str(row.get("certificate_hierarchy", ""))
                    == "deduplicate;holm_local_safety;serial_fam_vs_geo"
                    for row in rows
                )
                if args.certificate_file == "semantic_admission_exact_certificate.csv"
                else True,
            }
        )
        for client_id, client_rows in sorted(_group(rows, "client_id").items()):
            local = _one(client_rows, "candidate_method", "Local-LoRA")
            fam_name = _semantic_candidate_name(
                client_rows,
                requested=str(args.semantic_candidate_name),
            )
            fam = _one(client_rows, "candidate_method", fam_name)
            selected = _selected(client_rows)
            selected_name = str(selected["candidate_method"])
            local_accuracy = float(local["test_accuracy_post_selection_audit"])
            selected_accuracy = float(selected["test_accuracy_post_selection_audit"])
            local_loss = float(local["test_loss_post_selection_audit"])
            selected_loss = float(selected["test_loss_post_selection_audit"])
            fam_accuracy = float(fam["test_accuracy_post_selection_audit"])
            fam_loss = float(fam["test_loss_post_selection_audit"])
            geo_deployable = _as_bool(selected.get("geo_deployable", False))
            fam_deployable = _as_bool(selected.get("fam_deployable", False))
            certificate_integrity = bool(
                selected_name == "Local-LoRA"
                or (selected_name == "Geo-only-Agg" and geo_deployable)
                or (selected_name == fam_name and fam_deployable)
            )
            screen_row = screen.get(str(client_id), {})
            units.append(
                {
                    "run_label": run_label,
                    "seed": seed,
                    "client_id": client_id,
                    "domain": selected.get("domain", ""),
                    "method": selected.get("method", ""),
                    "selected_method": selected_name,
                    "selected_nonlocal": selected_name != "Local-LoRA",
                    "selected_fam": selected_name == fam_name,
                    "selected_accuracy_gain_over_local": selected_accuracy - local_accuracy,
                    "selected_loss_reduction_over_local": local_loss - selected_loss,
                    "fam_candidate_accuracy_gain_over_local": fam_accuracy - local_accuracy,
                    "fam_candidate_loss_reduction_over_local": local_loss - fam_loss,
                    "harmful_admission": selected_name != "Local-LoRA" and selected_accuracy < local_accuracy - 1e-12,
                    "uncertified_deployment": not certificate_integrity,
                    "geo_deployable": geo_deployable,
                    "fam_deployable": fam_deployable,
                    "calibration_size": int(float(selected.get("calibration_size", 0))),
                    "familywise_alpha": float(selected.get("familywise_alpha", "nan")),
                    "certificate_hierarchy": selected.get("certificate_hierarchy", ""),
                    "primary_family_size": int(float(selected.get("primary_family_size", 0))),
                    "geo_primary_holm_threshold": _float_or_nan(
                        selected.get("geo_primary_holm_threshold", "nan")
                    ),
                    "fam_primary_holm_threshold": _float_or_nan(
                        selected.get("fam_primary_holm_threshold", "nan")
                    ),
                    "secondary_opened": _as_bool(selected.get("secondary_opened", False)),
                    "secondary_alpha": _float_or_nan(selected.get("secondary_alpha", "nan")),
                    "predicted_loss_decrease": _float_or_nan(screen_row.get("predicted_loss_decrease", "nan")),
                    "selected_step": _float_or_nan(screen_row.get("selected_step", "nan")),
                    "transport_source": screen_row.get("transport_source", ""),
                    "anchor_source": screen_row.get("anchor_source", ""),
                    "selected_generator": screen_row.get("selected_generator", ""),
                    "candidate_sha256": screen_row.get("candidate_sha256", ""),
                    "training_screen_accuracy": _float_or_nan(screen_row.get("training_accuracy", "nan")),
                    "training_screen_loss": _float_or_nan(screen_row.get("training_loss", "nan")),
                }
            )

    summaries: list[dict] = []
    seed_rows: list[dict] = []
    for run_label, current in sorted(_group(units, "run_label").items()):
        current_protocols = [row for row in protocols if row["run_label"] == run_label]
        for seed, seed_units in sorted(_group(current, "seed").items()):
            seed_rows.append(
                {
                    "run_label": run_label,
                    "seed": int(seed),
                    "unit_count": len(seed_units),
                    "mean_accuracy_gain_over_local": _mean(seed_units, "selected_accuracy_gain_over_local"),
                    "mean_loss_reduction_over_local": _mean(seed_units, "selected_loss_reduction_over_local"),
                    "nonlocal_admission_count": sum(_as_bool(row["selected_nonlocal"]) for row in seed_units),
                    "fam_admission_count": sum(_as_bool(row["selected_fam"]) for row in seed_units),
                    "harmful_admission_count": sum(_as_bool(row["harmful_admission"]) for row in seed_units),
                    "uncertified_deployment_count": sum(_as_bool(row["uncertified_deployment"]) for row in seed_units),
                }
            )
        current_seed_rows = [row for row in seed_rows if row["run_label"] == run_label]
        accuracy_boot = _hierarchical_bootstrap(
            current, "selected_accuracy_gain_over_local", int(args.bootstrap_replicates), rng
        )
        loss_boot = _hierarchical_bootstrap(
            current, "selected_loss_reduction_over_local", int(args.bootstrap_replicates), rng
        )
        correlation_rows = [
            row
            for row in current
            if np.isfinite(float(row["predicted_loss_decrease"]))
            and np.isfinite(float(row["fam_candidate_loss_reduction_over_local"]))
        ]
        prediction_r = _correlation(
            correlation_rows, "predicted_loss_decrease", "fam_candidate_loss_reduction_over_local"
        )
        hashes = {
            row["package_source_sha256"]
            for row in current_protocols
            if row["package_source_sha256"]
        }
        heldout = bool(current_protocols and all(row["calibration_fraction"] > 0 for row in current_protocols))
        provenance_complete = bool(current_protocols and all(row["provenance_present"] for row in current_protocols))
        test_free = bool(current_protocols and all(row["test_free_selection"] for row in current_protocols))
        screen_isolated = bool(
            current_protocols and all(row["training_screen_isolation"] for row in current_protocols)
        )
        serial_holm_match = bool(
            current_protocols and all(row["serial_holm_runtime_match"] for row in current_protocols)
        )
        hash_consistent = bool(provenance_complete and len(hashes) == 1)
        harmful = sum(_as_bool(row["harmful_admission"]) for row in current)
        uncertified = sum(_as_bool(row["uncertified_deployment"]) for row in current)
        admissions = sum(_as_bool(row["selected_nonlocal"]) for row in current)
        lower = float(np.quantile(accuracy_boot, 0.025))
        summaries.append(
            {
                "run_label": run_label,
                "seed_count": len(current_seed_rows),
                "unit_count": len(current),
                "mean_accuracy_gain_over_local": _mean(current, "selected_accuracy_gain_over_local"),
                "accuracy_gain_ci95_low": lower,
                "accuracy_gain_ci95_high": float(np.quantile(accuracy_boot, 0.975)),
                "mean_loss_reduction_over_local": _mean(current, "selected_loss_reduction_over_local"),
                "loss_reduction_ci95_low": float(np.quantile(loss_boot, 0.025)),
                "loss_reduction_ci95_high": float(np.quantile(loss_boot, 0.975)),
                "positive_seed_count": sum(row["mean_accuracy_gain_over_local"] > 1e-12 for row in current_seed_rows),
                "negative_seed_count": sum(row["mean_accuracy_gain_over_local"] < -1e-12 for row in current_seed_rows),
                "seed_sign_flip_p_one_sided": _exact_sign_flip_p(
                    [float(row["mean_accuracy_gain_over_local"]) for row in current_seed_rows]
                ),
                "nonlocal_admission_count": admissions,
                "fam_admission_count": sum(_as_bool(row["selected_fam"]) for row in current),
                "harmful_admission_count": harmful,
                "uncertified_deployment_count": uncertified,
                "prediction_realized_loss_pearson_r": prediction_r,
                "heldout_calibration": heldout,
                "provenance_complete": provenance_complete,
                "code_hash_consistent": hash_consistent,
                "test_free_selection": test_free,
                "training_screen_isolation": screen_isolated,
                "serial_holm_runtime_match": serial_holm_match,
                "passes_safety_gate": bool(
                    harmful == 0
                    and uncertified == 0
                    and heldout
                    and test_free
                    and screen_isolated
                    and serial_holm_match
                ),
                "passes_positive_confirmation": bool(
                    len(current_seed_rows) == 5
                    and lower > 0.0
                    and admissions > 0
                    and harmful == 0
                    and uncertified == 0
                    and heldout
                    and provenance_complete
                    and hash_consistent
                    and test_free
                    and screen_isolated
                    and serial_holm_match
                ),
            }
        )

    output = root / "exact_receiver_admission_statistics"
    output.mkdir(parents=True, exist_ok=True)
    _write_csv(output / "exact_receiver_units.csv", units)
    _write_csv(output / "exact_receiver_seed_effects.csv", seed_rows)
    _write_csv(output / "exact_receiver_protocols.csv", protocols)
    _write_csv(output / "exact_receiver_summary.csv", summaries)
    _write_report(output / "exact_receiver_report.md", summaries)
    return 0


def _selected_screen(run_dir: Path) -> tuple[list[dict], dict[str, dict]]:
    for filename in ("semantic_generator_training_screen.csv", "signed_tangent_screen.csv"):
        path = run_dir / filename
        if not path.is_file():
            continue
        rows = _read_csv(path)
        selected = {
            str(row["client_id"]): row
            for row in rows
            if _as_bool(row.get("selected", row.get("training_screen_selected", False)))
        }
        return rows, selected
    return [], {}


def _training_screen_isolated(rows: list[dict]) -> bool:
    """Accept only explicitly training-side generator screens.

    ``nested_training_validation`` is the leakage-safe cross-fit protocol: its
    inner validation fold is carved from adapter-training data and is disjoint
    from both the outer calibration split and the test set.
    """
    return all(
        not _as_bool(row.get("calibration_used", False))
        and not _as_bool(row.get("test_used", False))
        and str(row.get("selection_split", "adapter_training"))
        in _TRAINING_ONLY_SELECTION_SPLITS
        for row in rows
    )


def _semantic_candidate_name(rows: list[dict], requested: str) -> str:
    if requested.strip().lower() != "auto":
        _one(rows, "candidate_method", requested)
        return requested
    names = sorted(
        {
            str(row.get("candidate_method", ""))
            for row in rows
            if str(row.get("candidate_method", "")) not in {"", "Local-LoRA", "Geo-only-Agg"}
        }
    )
    if len(names) != 1:
        raise ValueError(f"Expected one semantic endpoint, found {names}")
    return names[0]


def _selected(rows: list[dict]) -> dict:
    selected = [row for row in rows if _as_bool(row.get("selected", False))]
    if len(selected) != 1:
        raise ValueError(f"Expected exactly one selected candidate, found {len(selected)}")
    return selected[0]


def _hierarchical_bootstrap(rows, field, replicates, rng):
    grouped = _group(rows, "seed")
    seeds = sorted(grouped)
    draws = np.empty(max(1, replicates), dtype=np.float64)
    for index in range(draws.size):
        values = []
        for sampled_seed in rng.choice(seeds, size=len(seeds), replace=True):
            seed_rows = grouped[int(sampled_seed)]
            sampled_indices = rng.integers(0, len(seed_rows), size=len(seed_rows))
            values.extend(float(seed_rows[item][field]) for item in sampled_indices)
        draws[index] = float(np.mean(values))
    return draws


def _correlation(rows, x_field, y_field):
    if len(rows) < 2:
        return float("nan")
    x = np.asarray([float(row[x_field]) for row in rows], dtype=np.float64)
    y = np.asarray([float(row[y_field]) for row in rows], dtype=np.float64)
    if np.std(x) <= 1e-12 or np.std(y) <= 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def _exact_sign_flip_p(values):
    values = np.asarray(values, dtype=np.float64)
    observed = float(np.mean(values))
    magnitudes = np.abs(values)
    null = [
        float(np.mean(np.asarray(signs, dtype=np.float64) * magnitudes))
        for signs in itertools.product([-1.0, 1.0], repeat=len(values))
    ]
    return float(np.mean(np.asarray(null) >= observed - 1e-15))


def _read_yaml_scalars(path: Path) -> dict:
    if not path.is_file():
        return {}
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if ":" not in line or line.lstrip().startswith("#"):
            continue
        key, value = line.split(":", 1)
        value = value.strip().strip('"\'')
        if value.lower() in {"true", "false"}:
            out[key.strip()] = value.lower() == "true"
        else:
            try:
                out[key.strip()] = float(value)
            except ValueError:
                out[key.strip()] = value
    return out


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _one(rows, field, value):
    matches = [row for row in rows if str(row.get(field, "")) == value]
    if len(matches) != 1:
        raise ValueError(f"Expected one {field}={value}, found {len(matches)}")
    return matches[0]


def _group(rows, field):
    grouped = {}
    for row in rows:
        grouped.setdefault(row[field], []).append(row)
    return grouped


def _mean(rows, field):
    return float(np.mean([float(row[field]) for row in rows]))


def _as_bool(value):
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes"}


def _float_or_nan(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _write_report(path: Path, rows: list[dict]) -> None:
    lines = [
        "# Immutable-Local Exact Receiver Admission Audit",
        "",
        "| Run | Seeds | Units | Accuracy gain vs Local | 95% CI | Non-local | Harmful | Uncertified | Serial-Holm | Pred./realized loss r | Safety | Positive confirmation |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            f"| {row['run_label']} | {row['seed_count']} | {row['unit_count']} | "
            f"{float(row['mean_accuracy_gain_over_local']):.4f} | "
            f"[{float(row['accuracy_gain_ci95_low']):.4f}, {float(row['accuracy_gain_ci95_high']):.4f}] | "
            f"{row['nonlocal_admission_count']} | {row['harmful_admission_count']} | "
            f"{row['uncertified_deployment_count']} | {row['serial_holm_runtime_match']} | "
            f"{float(row['prediction_realized_loss_pearson_r']):.4f} | "
            f"{row['passes_safety_gate']} | {row['passes_positive_confirmation']} |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
