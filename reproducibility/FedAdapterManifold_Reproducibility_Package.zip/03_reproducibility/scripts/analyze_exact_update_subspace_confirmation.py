from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "results/opportunity_conditioned_subspace_confirmation_20260812"
OUTPUT = ROOT / "results/exact_update_subspace_confirmation_20260812"
SETTINGS = {
    "DINOv2-PACS": "pacs_dinov2",
    "CLIP-DomainNetMini": "domainnetmini_clip",
}
CONTROLS = ("d_geo", "d_update", "d_action")
ANALYSIS_SEED = 20260812
N_BOOT = 20000


def _standardized_subspace_beta(array: np.ndarray) -> float:
    predictors = array[:, :4]
    target = array[:, 4]
    predictors = (predictors - predictors.mean(axis=0)) / (predictors.std(axis=0) + 1e-12)
    target = (target - target.mean()) / (target.std() + 1e-12)
    design = np.column_stack([np.ones(len(predictors)), predictors])
    return float(np.linalg.lstsq(design, target, rcond=None)[0][1])


def _load_seed_arrays(folder: str) -> tuple[list[np.ndarray], pd.DataFrame]:
    arrays = []
    frames = []
    columns = ["d_sub", *CONTROLS, "semantic_exact_loss_failure"]
    for seed in range(5, 10):
        path = SOURCE / folder / f"seed_{seed}" / "adapter_conflict.csv"
        frame = pd.read_csv(path)
        missing = set(columns).difference(frame.columns)
        if missing:
            raise ValueError(f"{path} is missing {sorted(missing)}")
        frame["seed"] = seed
        frames.append(frame)
        arrays.append(frame[columns].to_numpy(dtype=np.float64))
    return arrays, pd.concat(frames, ignore_index=True)


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(ANALYSIS_SEED)
    rows = []
    bootstrap_by_setting: dict[str, np.ndarray] = {}
    all_frames = []
    for setting, folder in SETTINGS.items():
        seed_arrays, frame = _load_seed_arrays(folder)
        frame["setting"] = setting
        all_frames.append(frame)
        pooled = np.concatenate(seed_arrays, axis=0)
        raw_r = float(frame[["d_sub", "semantic_exact_loss_failure"]].corr().iloc[0, 1])
        beta = _standardized_subspace_beta(pooled)
        bootstrap = np.empty(N_BOOT, dtype=np.float64)
        for index in range(N_BOOT):
            sampled = rng.integers(0, len(seed_arrays), size=len(seed_arrays))
            bootstrap[index] = _standardized_subspace_beta(
                np.concatenate([seed_arrays[i] for i in sampled], axis=0)
            )
        bootstrap_by_setting[setting] = bootstrap
        ci_low, ci_high = np.quantile(bootstrap, [0.025, 0.975])
        rows.append(
            {
                "setting": setting,
                "confirmation_seeds": "5,6,7,8,9",
                "n_directional_pairs": len(frame),
                "raw_subspace_exact_loss_pearson_r": raw_r,
                "controlled_standardized_subspace_beta": beta,
                "seed_cluster_ci_low": float(ci_low),
                "seed_cluster_ci_high": float(ci_high),
                "bootstrap_positive_probability": float(np.mean(bootstrap > 0)),
                "controls": "+".join(CONTROLS),
                "setting_confirmed": bool(ci_low > 0),
            }
        )
    setting_table = pd.DataFrame(rows)
    setting_table.to_csv(OUTPUT / "setting_level_confirmation.csv", index=False)
    all_pairs = pd.concat(all_frames, ignore_index=True)
    all_pairs.to_csv(OUTPUT / "independent_directional_pairs.csv", index=False)

    pooled_bootstrap = np.mean(np.vstack(list(bootstrap_by_setting.values())), axis=0)
    pooled_beta = float(setting_table["controlled_standardized_subspace_beta"].mean())
    pooled_low, pooled_high = np.quantile(pooled_bootstrap, [0.025, 0.975])
    summary = {
        "n_settings": len(setting_table),
        "n_seeds_per_setting": 5,
        "n_directional_pairs": len(all_pairs),
        "mean_controlled_standardized_subspace_beta": pooled_beta,
        "seed_cluster_ci_low": float(pooled_low),
        "seed_cluster_ci_high": float(pooled_high),
        "bootstrap_positive_probability": float(np.mean(pooled_bootstrap > 0)),
        "all_settings_ci_lower_positive": bool(setting_table["seed_cluster_ci_low"].gt(0).all()),
        "confirmation_supported": bool(pooled_low > 0 and setting_table["seed_cluster_ci_low"].gt(0).all()),
    }
    pd.DataFrame([summary]).to_csv(OUTPUT / "confirmation_summary.csv", index=False)
    report = [
        "# Independent-seed exact-update subspace confirmation",
        "",
        "## Estimand",
        "",
        "The endpoint is the increase in receiver cross-entropy after averaging the exact full LoRA updates. This endpoint and its implementation existed before the seed-5--9 diagnostics were generated. Unlike factor-wise averaging, it is invariant to a change of LoRA factor gauge.",
        "",
        "The controlled coefficient is the standardized d_sub coefficient after controlling for d_geo, normalized full-update distance, and receiver Fisher action distance. Seeds are resampled as clusters.",
        "",
    ]
    for row in rows:
        report.append(
            f"- {row['setting']}: raw r={row['raw_subspace_exact_loss_pearson_r']:.4f}; "
            f"controlled beta={row['controlled_standardized_subspace_beta']:.4f}, "
            f"95% seed-cluster CI [{row['seed_cluster_ci_low']:.4f}, {row['seed_cluster_ci_high']:.4f}]."
        )
    report.extend(
        [
            f"- Equal-setting mean controlled beta={pooled_beta:.4f}, 95% CI [{pooled_low:.4f}, {pooled_high:.4f}].",
            f"- Confirmation supported: {summary['confirmation_supported']}.",
            "",
            "## Protocol note",
            "",
            "A separate opportunity-threshold analysis was frozen before these outputs but failed because development and confirmation artifacts used non-commensurate multi-layer and equivalent-update distance scales. That failed analysis remains archived and is not used as positive evidence. The present audit uses the pre-existing gauge-invariant exact-update endpoint without transferring numeric thresholds across implementations.",
        ]
    )
    (OUTPUT / "confirmation_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(summary)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

