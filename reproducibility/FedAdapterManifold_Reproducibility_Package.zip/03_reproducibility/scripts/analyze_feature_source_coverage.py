from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import yaml


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.baselines import run_local_lora
from fedadaptermanifold.run_experiment import _load_clients, _split_clients_for_candidate_selection
from fedadaptermanifold.source_coverage import source_coverage
from fedadaptermanifold.training import cross_entropy_and_grad


def _orth(value: np.ndarray) -> np.ndarray:
    value = np.asarray(value, dtype=np.float64)
    if value.size == 0:
        return np.zeros((value.shape[0], 0), dtype=np.float64)
    u, singular, _ = np.linalg.svd(value, full_matrices=False)
    if singular.size == 0:
        return np.zeros((value.shape[0], 0), dtype=np.float64)
    keep = singular > max(value.shape) * np.finfo(np.float64).eps * singular[0]
    return u[:, keep]


def _tangent_projection(matrix: np.ndarray, adapter) -> np.ndarray:
    matrix = np.asarray(matrix, dtype=np.float64)
    u = _orth(adapter.B)
    v = _orth(adapter.A.T)
    left = u @ (u.T @ matrix) if u.size else np.zeros_like(matrix)
    right = (matrix @ v) @ v.T if v.size else np.zeros_like(matrix)
    overlap = u @ ((u.T @ matrix @ v) @ v.T) if u.size and v.size else np.zeros_like(matrix)
    return left + right - overlap


def _training_gradient(client, base_weight: np.ndarray, adapter) -> tuple[np.ndarray, float]:
    weight = base_weight + adapter.delta()
    logits = client.x_train @ weight.T
    loss, grad_logits = cross_entropy_and_grad(logits, client.y_train.astype(np.int64))
    return grad_logits.T @ client.x_train, float(loss)


def _geometry_support(config: dict, num_clients: int) -> np.ndarray:
    directory = str(config.get("geometry_outputs_dir", "")).replace("\\\\", "\\")
    round_id = int(config.get("geometry_round", config.get("round_id", 0)))
    path = Path(directory) / f"geometry_graph_round_{round_id}.npy"
    if not path.exists():
        support = np.ones((num_clients, num_clients), dtype=bool)
        np.fill_diagonal(support, False)
        return support
    graph = np.asarray(np.load(path), dtype=np.float64)
    if graph.shape != (num_clients, num_clients):
        raise ValueError(f"geometry graph shape {graph.shape} does not match {num_clients} clients")
    support = graph > 0.0
    np.fill_diagonal(support, False)
    return support


def _read_admitted_clients(seed_dir: Path) -> set[str]:
    path = seed_dir / "semantic_admission_exact_certificate.csv"
    if not path.exists():
        return set()
    admitted: set[str] = set()
    with path.open("r", newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            method = str(row.get("selected_method", row.get("deployed_method", "")))
            selected = str(row.get("selected", "")).lower() in {"true", "1"}
            if selected and method and "local" not in method.lower():
                admitted.add(str(row.get("client_id", "")))
    return admitted


def _write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("empty\n", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Frozen feature-level source dictionary coverage replay")
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args(argv)
    source_root = Path(args.source_root)
    output_dir = Path(args.output_dir)
    summary_rows: list[dict] = []
    donor_rows: list[dict] = []
    hashes: dict[str, str] = {}

    seed_dirs = sorted(path for path in source_root.glob("seed_*") if (path / "config.yaml").exists())
    if not seed_dirs:
        raise FileNotFoundError(f"no seed directories found under {source_root}")
    for seed_dir in seed_dirs:
        config_path = seed_dir / "config.yaml"
        config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        hashes[str(config_path)] = _sha256(config_path)
        run_args = SimpleNamespace(**config)
        loaded_clients, base_weight, _ = _load_clients(run_args)
        clients, selector_clients, _ = _split_clients_for_candidate_selection(
            loaded_clients,
            fraction=float(config.get("candidate_selector_calibration_fraction", 0.0)),
            strategy=str(config.get("candidate_selector_calibration_strategy", "random")),
            seed=int(config["seed"]),
        )
        seed = int(config["seed"])
        rank = int(config["rank"])
        result = run_local_lora(
            clients=clients,
            base_weight=base_weight,
            ranks=[rank] * len(clients),
            epochs=int(config.get("rounds", 1)) * int(config["local_epochs"]),
            lr=float(config["lr"]),
            batch_size=int(config["batch_size"]),
            seed=seed,
            dataset=str(config["dataset"]),
            heterogeneity_setting=str(config["heterogeneity_setting"]),
            round_id=int(config.get("rounds", config.get("round", 0))),
        )
        support = _geometry_support(config, len(clients))
        admitted = _read_admitted_clients(seed_dir)
        for receiver_idx, (client, receiver) in enumerate(zip(clients, result.adapters)):
            for risk_split, risk_client in [
                ("adapter_training", client),
                ("outer_calibration", selector_clients[receiver_idx]),
            ]:
                gradient, risk_loss = _training_gradient(risk_client, base_weight, receiver)
                tangent_gradient = _tangent_projection(gradient, receiver).reshape(-1)
                dictionaries = {
                    "all_external": [idx for idx in range(len(clients)) if idx != receiver_idx],
                    "graph_supported": [idx for idx in range(len(clients)) if support[receiver_idx, idx]],
                }
                for dictionary_name, donors in dictionaries.items():
                    directions = [
                        _tangent_projection(result.adapters[idx].delta() - receiver.delta(), receiver).reshape(-1)
                        for idx in donors
                    ]
                    matrix = (
                        np.stack(directions, axis=0)
                        if directions
                        else np.zeros((0, tangent_gradient.size), dtype=np.float64)
                    )
                    coverage = source_coverage(tangent_gradient, matrix)
                    best_donor = donors[coverage.best_source] if coverage.best_source >= 0 else -1
                    summary_rows.append(
                        {
                            "seed": seed,
                            "client_id": client.client_id,
                            "domain": client.domain,
                            "risk_split": risk_split,
                            "dictionary": dictionary_name,
                            "risk_loss": risk_loss,
                            "num_sources": len(donors),
                            "gamma_atom": coverage.atom_coverage,
                            "gamma_cone": coverage.cone_coverage,
                            "gamma_span": coverage.span_coverage,
                            "multi_donor_gap": coverage.cone_coverage - coverage.atom_coverage,
                            "signed_span_gap": coverage.span_coverage - coverage.cone_coverage,
                            "uncovered_fraction": 1.0 - coverage.span_coverage,
                            "positive_single_sources": coverage.positive_sources,
                            "active_cone_sources": coverage.active_cone_sources,
                            "best_donor_client_id": (
                                clients[best_donor].client_id if best_donor >= 0 else ""
                            ),
                            "known_nonlocal_admission": str(client.client_id) in admitted,
                            "selection_uses_test": False,
                        }
                    )
                    for position, donor_idx in enumerate(donors):
                        derivative = float(coverage.directional_derivatives[position])
                        donor_rows.append(
                            {
                                "seed": seed,
                                "receiver_client_id": client.client_id,
                                "receiver_domain": client.domain,
                                "risk_split": risk_split,
                                "donor_client_id": clients[donor_idx].client_id,
                                "donor_domain": clients[donor_idx].domain,
                                "dictionary": dictionary_name,
                                "normalized_directional_derivative": derivative,
                                "descent_cosine": max(0.0, -derivative)
                                / max(coverage.gradient_norm, 1e-12),
                                "cone_coefficient": float(coverage.cone_coefficients[position]),
                            }
                        )

    _write_csv(output_dir / "source_coverage.csv", summary_rows)
    _write_csv(output_dir / "source_coverage_donors.csv", donor_rows)
    all_external = [
        row
        for row in summary_rows
        if row["dictionary"] == "all_external" and row["risk_split"] == "outer_calibration"
    ]
    admitted_rows = [row for row in all_external if row["known_nonlocal_admission"]]
    fallback_rows = [row for row in all_external if not row["known_nonlocal_admission"]]
    report = {
        "num_receiver_seed_units": len(all_external),
        "num_known_nonlocal_admissions_matched": len(admitted_rows),
        "median_gamma_atom": float(np.median([row["gamma_atom"] for row in all_external])),
        "median_gamma_cone": float(np.median([row["gamma_cone"] for row in all_external])),
        "median_gamma_span": float(np.median([row["gamma_span"] for row in all_external])),
        "admitted_median_gamma_cone": (
            float(np.median([row["gamma_cone"] for row in admitted_rows])) if admitted_rows else None
        ),
        "fallback_median_gamma_cone": (
            float(np.median([row["gamma_cone"] for row in fallback_rows])) if fallback_rows else None
        ),
        "fraction_multi_donor_gap_ge_0_05": float(
            np.mean([row["multi_donor_gap"] >= 0.05 for row in all_external])
        ),
        "fraction_signed_span_gap_ge_0_05": float(
            np.mean([row["signed_span_gap"] >= 0.05 for row in all_external])
        ),
        "uses_test_for_coverage": False,
    }
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "coverage_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (output_dir / "evidence_hashes.json").write_text(json.dumps(hashes, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
