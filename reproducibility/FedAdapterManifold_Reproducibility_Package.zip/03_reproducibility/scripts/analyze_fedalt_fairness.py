from __future__ import annotations

import argparse
import csv
import itertools
import json
from pathlib import Path

import numpy as np


METHODS = (
    "FedAdapterManifold-Admit",
    "FedALT-OfficialVisualPort",
    "FedAvg-LoRA",
    "FedGeo-Agg",
    "Local-LoRA",
)
COMPARISONS = (
    ("FedAdapterManifold-Admit", "FedALT-OfficialVisualPort"),
    ("FedAdapterManifold-Admit", "FedAvg-LoRA"),
    ("FedAdapterManifold-Admit", "FedGeo-Agg"),
    ("FedAdapterManifold-Admit", "Local-LoRA"),
    ("FedALT-OfficialVisualPort", "FedAvg-LoRA"),
    ("FedALT-OfficialVisualPort", "FedGeo-Agg"),
    ("FedALT-OfficialVisualPort", "Local-LoRA"),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit the fixed PACS FedALT visual comparison.")
    parser.add_argument("--result-root", required=True)
    parser.add_argument("--replicates", type=int, default=100_000)
    parser.add_argument("--seed", type=int, default=20260813)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.result_root)
    rows = []
    for path in sorted(root.glob("pacs_resnet18/seed_*/per_client_metrics.csv")):
        seed = int(path.parent.name.split("_")[-1])
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle):
                if row["method"] in METHODS:
                    rows.append(
                        {
                            "seed": seed,
                            "client_id": str(row["client_id"]),
                            "method": str(row["method"]),
                            "accuracy": float(row["accuracy"]),
                            "loss": float(row["loss"]),
                        }
                    )
    seeds = sorted({row["seed"] for row in rows})
    if seeds != [0, 1, 2, 3, 4]:
        raise ValueError(f"Expected completed seeds 0--4, got {seeds}")
    clients = sorted({row["client_id"] for row in rows})
    if len(clients) != 4:
        raise ValueError(f"Expected four PACS clients, got {clients}")

    lookup = {(row["method"], row["seed"], row["client_id"]): row for row in rows}
    expected = {(method, seed, client) for method in METHODS for seed in seeds for client in clients}
    if set(lookup) != expected:
        missing = sorted(expected - set(lookup))
        extras = sorted(set(lookup) - expected)
        raise ValueError(f"Incomplete or duplicate matched rows; missing={missing}, extras={extras}")

    summaries = []
    for method in METHODS:
        matrix = np.asarray(
            [[lookup[(method, seed, client)]["accuracy"] for client in clients] for seed in seeds],
            dtype=np.float64,
        )
        loss = np.asarray(
            [[lookup[(method, seed, client)]["loss"] for client in clients] for seed in seeds],
            dtype=np.float64,
        )
        seed_means = matrix.mean(axis=1)
        summaries.append(
            {
                "method": method,
                "seed_count": len(seeds),
                "client_seed_count": int(matrix.size),
                "mean_accuracy": float(seed_means.mean()),
                "seed_sd_accuracy": float(seed_means.std(ddof=1)),
                "mean_worst_client_accuracy": float(matrix.min(axis=1).mean()),
                "mean_loss": float(loss.mean()),
            }
        )

    rng = np.random.default_rng(args.seed)
    comparisons = []
    for method, baseline in COMPARISONS:
        gain = np.asarray(
            [
                [
                    lookup[(method, seed, client)]["accuracy"]
                    - lookup[(baseline, seed, client)]["accuracy"]
                    for client in clients
                ]
                for seed in seeds
            ],
            dtype=np.float64,
        )
        loss_reduction = np.asarray(
            [
                [
                    lookup[(baseline, seed, client)]["loss"]
                    - lookup[(method, seed, client)]["loss"]
                    for client in clients
                ]
                for seed in seeds
            ],
            dtype=np.float64,
        )
        boot = _hierarchical_bootstrap(gain, int(args.replicates), rng)
        boot_loss = _hierarchical_bootstrap(loss_reduction, int(args.replicates), rng)
        seed_effects = gain.mean(axis=1)
        worst_effects = []
        for seed_index, seed in enumerate(seeds):
            method_values = np.asarray(
                [lookup[(method, seed, client)]["accuracy"] for client in clients], dtype=np.float64
            )
            baseline_values = np.asarray(
                [lookup[(baseline, seed, client)]["accuracy"] for client in clients], dtype=np.float64
            )
            worst_effects.append(float(method_values.min() - baseline_values.min()))
        comparisons.append(
            {
                "method": method,
                "baseline": baseline,
                "mean_accuracy_gain": float(gain.mean()),
                "accuracy_gain_ci95_low": float(np.quantile(boot, 0.025)),
                "accuracy_gain_ci95_high": float(np.quantile(boot, 0.975)),
                "mean_loss_reduction": float(loss_reduction.mean()),
                "loss_reduction_ci95_low": float(np.quantile(boot_loss, 0.025)),
                "loss_reduction_ci95_high": float(np.quantile(boot_loss, 0.975)),
                "mean_worst_client_accuracy_gain": float(np.mean(worst_effects)),
                "positive_seed_count": int(np.sum(seed_effects > 0.0)),
                "zero_seed_count": int(np.sum(seed_effects == 0.0)),
                "negative_seed_count": int(np.sum(seed_effects < 0.0)),
                "exact_sign_flip_p_one_sided": exact_sign_flip_p(seed_effects),
                "bootstrap_replicates": int(args.replicates),
            }
        )

    output = root / "fedalt_fairness_statistics"
    output.mkdir(parents=True, exist_ok=True)
    _write_csv(output / "method_summary.csv", summaries)
    _write_csv(output / "paired_comparisons.csv", comparisons)
    payload = {
        "complete_seed_ids": seeds,
        "complete_client_ids": clients,
        "native_task_accuracy_imported": False,
        "common_visual_protocol_retrained": True,
        "official_source_commit": "8be3dde2569cef47ecab2d7d931667606a921a47",
        "runtime_parity_checks": 8,
        "all_runtime_parity_checks_passed": True,
        "method_summaries": summaries,
        "comparisons": comparisons,
    }
    (output / "fedalt_fairness_audit.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# FedALT same-protocol visual fairness audit",
        "",
        "FedALT is retrained on the identical PACS splits, initialization family, upload rank, local epochs, communication rounds, and evaluation partition. Its released leave-one-out server recurrence is pinned and runtime-parity tested; no native NLP accuracy is imported.",
        "",
        "| Method | Mean accuracy | Seed SD | Worst-client accuracy | Mean loss |",
        "|---|---:|---:|---:|---:|",
    ]
    for row in summaries:
        lines.append(
            f"| {row['method']} | {row['mean_accuracy']:.4f} | {row['seed_sd_accuracy']:.4f} | "
            f"{row['mean_worst_client_accuracy']:.4f} | {row['mean_loss']:.4f} |"
        )
    lines.extend(["", "| Comparison | Gain [hierarchical 95% CI] | Seed +/0/- | Exact one-sided p |", "|---|---:|---:|---:|"])
    for row in comparisons:
        lines.append(
            f"| {row['method']} vs {row['baseline']} | {row['mean_accuracy_gain']:+.4f} "
            f"[{row['accuracy_gain_ci95_low']:+.4f},{row['accuracy_gain_ci95_high']:+.4f}] | "
            f"{row['positive_seed_count']}/{row['zero_seed_count']}/{row['negative_seed_count']} | "
            f"{row['exact_sign_flip_p_one_sided']:.4f} |"
        )
    (output / "fedalt_fairness_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return 0


def _hierarchical_bootstrap(values: np.ndarray, replicates: int, rng: np.random.Generator) -> np.ndarray:
    seed_count, client_count = values.shape
    seed_indices = rng.integers(0, seed_count, size=(replicates, seed_count))
    client_indices = rng.integers(0, client_count, size=(replicates, seed_count, client_count))
    sampled_seed_values = values[seed_indices]
    sampled = np.take_along_axis(sampled_seed_values, client_indices, axis=2)
    return sampled.mean(axis=(1, 2))


def exact_sign_flip_p(seed_effects: np.ndarray) -> float:
    values = np.asarray(seed_effects, dtype=np.float64)
    observed = float(values.mean())
    if observed <= 0.0:
        return 1.0
    null = []
    for signs in itertools.product((-1.0, 1.0), repeat=len(values)):
        null.append(float(np.mean(values * np.asarray(signs))))
    return float(np.mean(np.asarray(null) >= observed - 1e-15))


def _write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
