from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np


METHODS = (
    "FedAvg-LoRA",
    "FedGeo-Agg",
    "FedPissa-EquationPort",
    "FedAdapterManifold-Selective",
    "FedAdapterManifold-Admit",
)
COMPARISONS = (
    ("FedPissa-EquationPort", "FedAvg-LoRA"),
    ("FedAdapterManifold-Selective", "FedPissa-EquationPort"),
    ("FedAdapterManifold-Admit", "FedPissa-EquationPort"),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--result-root",
        default="results/fedpissa_equation_port_crossdataset_5seed_20260813",
    )
    parser.add_argument("--bootstrap-repetitions", type=int, default=20000)
    return parser.parse_args()


def _read(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _write(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _seed_cluster_interval(seed_effects: dict[int, np.ndarray], repetitions: int, rng: np.random.Generator) -> tuple[float, float]:
    seeds = np.asarray(sorted(seed_effects), dtype=np.int64)
    draws = np.empty(repetitions, dtype=np.float64)
    for index in range(repetitions):
        sampled = rng.choice(seeds, size=len(seeds), replace=True)
        values = []
        for seed in sampled:
            client_values = seed_effects[int(seed)]
            values.extend(rng.choice(client_values, size=len(client_values), replace=True).tolist())
        draws[index] = float(np.mean(values))
    return tuple(float(value) for value in np.quantile(draws, [0.025, 0.975]))


def main() -> int:
    args = parse_args()
    root = Path(args.result_root)
    rows = _read(root / "all_seed_per_client_metrics.csv")
    units: dict[tuple[str, int, str, str], float] = {}
    for row in rows:
        method = row.get("method", "")
        if method not in METHODS:
            continue
        key = (
            row["fairness_dataset_key"],
            int(row["seed"]),
            row["client_id"],
            method,
        )
        units[key] = float(row["accuracy"])

    summaries: list[dict] = []
    comparisons: list[dict] = []
    rng = np.random.default_rng(20260813)
    datasets = sorted({key[0] for key in units})
    for dataset in datasets:
        for method in METHODS:
            values = [value for key, value in units.items() if key[0] == dataset and key[3] == method]
            if values:
                summaries.append(
                    {
                        "dataset": dataset,
                        "method": method,
                        "client_seed_units": len(values),
                        "mean_accuracy": float(np.mean(values)),
                        "worst_client_seed_accuracy": float(np.min(values)),
                    }
                )
        for method, baseline in COMPARISONS:
            seed_effects: dict[int, list[float]] = {}
            for (setting, seed, client_id, candidate), value in units.items():
                if setting != dataset or candidate != method:
                    continue
                baseline_key = (setting, seed, client_id, baseline)
                if baseline_key in units:
                    seed_effects.setdefault(seed, []).append(value - units[baseline_key])
            if not seed_effects:
                continue
            arrays = {seed: np.asarray(values, dtype=np.float64) for seed, values in seed_effects.items()}
            all_effects = np.concatenate(list(arrays.values()))
            low, high = _seed_cluster_interval(arrays, args.bootstrap_repetitions, rng)
            seed_means = np.asarray([values.mean() for _, values in sorted(arrays.items())])
            exact_sign_p = min(1.0, 2.0 * min(
                np.mean([np.mean(seed_means * signs) <= 0.0 for signs in _all_signs(len(seed_means))]),
                np.mean([np.mean(seed_means * signs) >= 0.0 for signs in _all_signs(len(seed_means))]),
            ))
            comparisons.append(
                {
                    "dataset": dataset,
                    "method": method,
                    "baseline": baseline,
                    "seeds": len(arrays),
                    "client_seed_units": len(all_effects),
                    "mean_accuracy_gain": float(all_effects.mean()),
                    "seed_cluster_ci_low": low,
                    "seed_cluster_ci_high": high,
                    "exact_seed_sign_flip_p": float(exact_sign_p),
                    "all_seed_means_nonnegative": int(bool(np.all(seed_means >= -1e-12))),
                }
            )
    out = root / "analysis"
    _write(out / "method_summary.csv", summaries)
    _write(out / "paired_comparisons.csv", comparisons)
    report = [
        "# FedPissa equation-port confirmation",
        "",
        "This audit uses the paper equations because no public reference implementation was identifiable at protocol freeze. It does not import the paper's native DomainNet accuracies.",
        "",
        "| Dataset | Method | Baseline | Mean gain | 95% seed-cluster CI | Exact seed sign-flip p |",
        "|---|---|---|---:|---:|---:|",
    ]
    for row in comparisons:
        report.append(
            f"| {row['dataset']} | {row['method']} | {row['baseline']} | {row['mean_accuracy_gain']:.4f} | [{row['seed_cluster_ci_low']:.4f}, {row['seed_cluster_ci_high']:.4f}] | {row['exact_seed_sign_flip_p']:.4f} |"
        )
    (out / "report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    return 0


def _all_signs(size: int) -> list[np.ndarray]:
    return [
        np.asarray([1.0 if (mask >> bit) & 1 else -1.0 for bit in range(size)], dtype=np.float64)
        for mask in range(1 << size)
    ]


if __name__ == "__main__":
    raise SystemExit(main())
