from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np


METHODS = (
    "FedAvg-LoRA",
    "FedGeo-Agg",
    "FedPissa-EquationPort",
    "FedAdapterManifold-Selective",
    "FedAdapterManifold-Admit",
)
COMPARISONS = (
    ("FedPissa-EquationPort", "FedAvg-LoRA"),
    ("FedAdapterManifold-Selective", "FedPissa-EquationPort"),
    ("FedAdapterManifold-Admit", "FedPissa-EquationPort"),
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Corrected FedPissa seed-level randomization analysis.")
    parser.add_argument(
        "--result-root",
        default="results/fedpissa_equation_port_crossdataset_5seed_20260813",
    )
    parser.add_argument("--bootstrap-repetitions", type=int, default=20000)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def cluster_interval(
    seed_effects: dict[int, np.ndarray], repetitions: int, rng: np.random.Generator
) -> tuple[float, float]:
    seeds = np.asarray(sorted(seed_effects), dtype=np.int64)
    draws = np.empty(repetitions, dtype=np.float64)
    for index in range(repetitions):
        sampled_seeds = rng.choice(seeds, size=len(seeds), replace=True)
        cluster_means = []
        for sampled_seed in sampled_seeds:
            values = seed_effects[int(sampled_seed)]
            cluster_means.append(float(np.mean(rng.choice(values, size=len(values), replace=True))))
        draws[index] = float(np.mean(cluster_means))
    return tuple(float(value) for value in np.quantile(draws, [0.025, 0.975]))


def exact_sign_flip(seed_means: np.ndarray) -> tuple[float, float]:
    observed = float(np.mean(seed_means))
    null = np.asarray(
        [
            float(np.mean(seed_means * np.asarray(signs, dtype=np.float64)))
            for signs in itertools.product((-1.0, 1.0), repeat=seed_means.size)
        ],
        dtype=np.float64,
    )
    if observed > 0.0:
        one_sided = float(np.mean(null >= observed - 1e-15))
    elif observed < 0.0:
        one_sided = float(np.mean(null <= observed + 1e-15))
    else:
        one_sided = 1.0
    two_sided = float(np.mean(np.abs(null) >= abs(observed) - 1e-15))
    return one_sided, two_sided


def main() -> int:
    args = parse_args()
    root = Path(args.result_root)
    source = root / "all_seed_per_client_metrics.csv"
    rows = read_csv(source)
    units: dict[tuple[str, int, str, str], float] = {}
    for row in rows:
        method = row.get("method", "")
        if method not in METHODS:
            continue
        units[(row["fairness_dataset_key"], int(row["seed"]), row["client_id"], method)] = float(
            row["accuracy"]
        )

    summaries: list[dict] = []
    comparisons: list[dict] = []
    rng = np.random.default_rng(20260813)
    for dataset in sorted({key[0] for key in units}):
        for method in METHODS:
            values = [value for key, value in units.items() if key[0] == dataset and key[3] == method]
            if values:
                summaries.append(
                    {
                        "dataset": dataset,
                        "method": method,
                        "client_seed_units": len(values),
                        "mean_accuracy": float(np.mean(values)),
                        "worst_client_seed_accuracy": float(np.min(values)),
                    }
                )
        for method, baseline in COMPARISONS:
            effects: dict[int, list[float]] = {}
            for (setting, seed, client_id, candidate), value in units.items():
                baseline_key = (setting, seed, client_id, baseline)
                if setting == dataset and candidate == method and baseline_key in units:
                    effects.setdefault(seed, []).append(value - units[baseline_key])
            if not effects:
                continue
            arrays = {seed: np.asarray(values, dtype=np.float64) for seed, values in effects.items()}
            all_effects = np.concatenate(list(arrays.values()))
            seed_means = np.asarray([values.mean() for _, values in sorted(arrays.items())])
            low, high = cluster_interval(arrays, args.bootstrap_repetitions, rng)
            one_sided, two_sided = exact_sign_flip(seed_means)
            comparisons.append(
                {
                    "dataset": dataset,
                    "method": method,
                    "baseline": baseline,
                    "seeds": len(arrays),
                    "client_seed_units": len(all_effects),
                    "mean_accuracy_gain": float(np.mean(all_effects)),
                    "seed_cluster_ci_low": low,
                    "seed_cluster_ci_high": high,
                    "exact_seed_sign_flip_p_one_sided": one_sided,
                    "exact_seed_sign_flip_p_two_sided": two_sided,
                    "positive_seed_count": int(np.sum(seed_means > 1e-12)),
                    "tie_seed_count": int(np.sum(np.abs(seed_means) <= 1e-12)),
                    "negative_seed_count": int(np.sum(seed_means < -1e-12)),
                }
            )

    output = root / "analysis_corrected"
    write_csv(output / "method_summary.csv", summaries)
    write_csv(output / "paired_comparisons.csv", comparisons)
    script = Path(__file__).resolve()
    correction = {
        "schema_version": 1,
        "source_data": str(source),
        "source_data_sha256": sha256(source),
        "analysis_script": str(script),
        "analysis_script_sha256": sha256(script),
        "correction": (
            "The frozen analyzer compared sign-flipped statistics with zero, which is symmetric by construction. "
            "This corrected audit compares every sign-flipped statistic with the observed mean and reports both "
            "one- and two-sided exact randomization values. Training outputs are unchanged."
        ),
        "bootstrap_repetitions": int(args.bootstrap_repetitions),
        "bootstrap_seed": 20260813,
    }
    (output / "statistical_correction_manifest.json").write_text(
        json.dumps(correction, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    report = [
        "# Corrected FedPissa equation-port confirmation",
        "",
        correction["correction"],
        "",
        "| Dataset | Method | Baseline | Mean gain | Hierarchical 95% CI | +/=/- seeds | Exact p (one/two sided) |",
        "|---|---|---|---:|---:|---:|---:|",
    ]
    for row in comparisons:
        report.append(
            "| {dataset} | {method} | {baseline} | {mean_accuracy_gain:+.4f} | [{seed_cluster_ci_low:+.4f}, {seed_cluster_ci_high:+.4f}] | {positive_seed_count}/{tie_seed_count}/{negative_seed_count} | {exact_seed_sign_flip_p_one_sided:.4f}/{exact_seed_sign_flip_p_two_sided:.4f} |".format(
                **row
            )
        )
    (output / "report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
