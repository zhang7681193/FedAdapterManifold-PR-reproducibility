from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd


SEED = 20260812
FEDTREE = "FedTreeLoRA-Visual-Port"
REFERENCES = (
    "FedAvg-LoRA",
    "FedGeo-Agg",
    "FedAdapterManifold",
    "FedAdapterManifold-StrongSelective",
    "Ditto-LoRA",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Analyze the matched visual FedTreeLoRA audit.")
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path("results/fedtree_visual_audit_20260812"),
    )
    parser.add_argument("--expected-seeds", type=int, default=5)
    parser.add_argument("--bootstrap-replicates", type=int, default=20000)
    return parser.parse_args()


def bootstrap_interval(values: np.ndarray, replicates: int, rng: np.random.Generator) -> tuple[float, float]:
    draws = rng.choice(values, size=(replicates, len(values)), replace=True).mean(axis=1)
    return tuple(float(value) for value in np.quantile(draws, [0.025, 0.975]))


def exact_sign_flip(values: np.ndarray) -> float:
    observed = float(values.mean())
    null = [
        float(np.mean(values * np.asarray(signs, dtype=np.float64)))
        for signs in itertools.product((-1.0, 1.0), repeat=len(values))
    ]
    return float(np.mean(np.asarray(null) >= observed - 1e-15))


def main() -> int:
    args = parse_args()
    rng = np.random.default_rng(SEED)
    frames = []
    incomplete = []
    for dataset_dir in sorted(path for path in args.result_root.iterdir() if path.is_dir()):
        if dataset_dir.name in {"configs", "logs", "analysis"}:
            continue
        for seed_dir in sorted(dataset_dir.glob("seed_*")):
            path = seed_dir / "per_client_metrics.csv"
            if not path.exists():
                incomplete.append(str(seed_dir.relative_to(args.result_root)))
                continue
            frame = pd.read_csv(path)
            frame["audit_dataset"] = dataset_dir.name
            frames.append(frame)
    if not frames:
        raise FileNotFoundError(f"No completed per-client metrics under {args.result_root}")

    units = pd.concat(frames, ignore_index=True)
    methods = [FEDTREE, *REFERENCES]
    units = units[units["method"].isin(methods)].copy()
    seed = (
        units.groupby(["audit_dataset", "method", "seed"], as_index=False)
        .agg(
            accuracy=("accuracy", "mean"),
            loss=("loss", "mean"),
            worst_client_accuracy=("accuracy", "min"),
            client_count=("client_id", "nunique"),
        )
    )
    method_summary = (
        seed.groupby(["audit_dataset", "method"], as_index=False)
        .agg(
            seed_count=("seed", "nunique"),
            accuracy=("accuracy", "mean"),
            loss=("loss", "mean"),
            worst_client_accuracy=("worst_client_accuracy", "mean"),
        )
    )
    method_summary["complete_five_seed"] = method_summary["seed_count"] == args.expected_seeds

    pairwise = []
    for dataset, group in seed.groupby("audit_dataset", sort=True):
        pivot = group.pivot(index="seed", columns="method", values=["accuracy", "loss", "worst_client_accuracy"])
        if ("accuracy", FEDTREE) not in pivot.columns:
            continue
        for reference in REFERENCES:
            if ("accuracy", reference) not in pivot.columns:
                continue
            complete = pivot[[
                ("accuracy", FEDTREE),
                ("accuracy", reference),
                ("loss", FEDTREE),
                ("loss", reference),
                ("worst_client_accuracy", FEDTREE),
                ("worst_client_accuracy", reference),
            ]].dropna()
            accuracy_gain = (
                complete[("accuracy", FEDTREE)] - complete[("accuracy", reference)]
            ).to_numpy(dtype=np.float64)
            loss_gain = (
                complete[("loss", reference)] - complete[("loss", FEDTREE)]
            ).to_numpy(dtype=np.float64)
            worst_gain = (
                complete[("worst_client_accuracy", FEDTREE)]
                - complete[("worst_client_accuracy", reference)]
            ).to_numpy(dtype=np.float64)
            acc_low, acc_high = bootstrap_interval(accuracy_gain, args.bootstrap_replicates, rng)
            loss_low, loss_high = bootstrap_interval(loss_gain, args.bootstrap_replicates, rng)
            worst_low, worst_high = bootstrap_interval(worst_gain, args.bootstrap_replicates, rng)
            pairwise.append(
                {
                    "dataset": dataset,
                    "reference": reference,
                    "seed_count": int(len(complete)),
                    "complete_five_seed": bool(len(complete) == args.expected_seeds),
                    "accuracy_gain": float(accuracy_gain.mean()),
                    "accuracy_ci_low": acc_low,
                    "accuracy_ci_high": acc_high,
                    "accuracy_sign_flip_p_one_sided": exact_sign_flip(accuracy_gain),
                    "loss_reduction": float(loss_gain.mean()),
                    "loss_ci_low": loss_low,
                    "loss_ci_high": loss_high,
                    "worst_client_gain": float(worst_gain.mean()),
                    "worst_client_ci_low": worst_low,
                    "worst_client_ci_high": worst_high,
                }
            )

    output = args.result_root / "analysis"
    output.mkdir(parents=True, exist_ok=True)
    seed.to_csv(output / "fedtree_seed_metrics.csv", index=False)
    method_summary.to_csv(output / "fedtree_method_summary.csv", index=False)
    pairwise_frame = pd.DataFrame(pairwise)
    pairwise_frame.to_csv(output / "fedtree_pairwise_summary.csv", index=False)

    report = [
        "# Matched visual FedTreeLoRA audit",
        "",
        "The visual port uses the pinned official hierarchical own-cluster/rest-expert recurrence. Splits, upload rank, local budget, rounds, and evaluation partitions are matched within each dataset; published native-language-task accuracies are not imported.",
        f"Completed seed directories: {seed[['audit_dataset', 'seed']].drop_duplicates().shape[0]}; incomplete directories skipped: {len(incomplete)}.",
        "",
        "| Dataset | Method | Seeds | Accuracy | Loss | Worst-client |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for row in method_summary.to_dict("records"):
        report.append(
            f"| {row['audit_dataset']} | {row['method']} | {row['seed_count']} | "
            f"{row['accuracy']:.4f} | {row['loss']:.4f} | {row['worst_client_accuracy']:.4f} |"
        )
    report.extend(["", "Incomplete directories: " + (", ".join(incomplete) if incomplete else "none")])
    (output / "fedtree_visual_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(method_summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
