from __future__ import annotations

import argparse
import csv
import itertools
from collections import defaultdict
from pathlib import Path

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Paired hierarchical audit for one frozen method.")
    parser.add_argument("--result-root", required=True)
    parser.add_argument("--method", required=True)
    parser.add_argument("--baselines", required=True)
    parser.add_argument("--output-dir", default="")
    parser.add_argument("--bootstrap-replicates", type=int, default=20000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260813)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.result_root)
    output = Path(args.output_dir) if args.output_dir else root / "frozen_method_comparisons"
    output.mkdir(parents=True, exist_ok=True)
    method = str(args.method)
    baselines = [value.strip() for value in str(args.baselines).split(",") if value.strip()]
    rows = _load_rows(root)
    summaries: list[dict] = []
    seed_rows: list[dict] = []
    for dataset_key in sorted({row["dataset_key"] for row in rows}):
        current = [row for row in rows if row["dataset_key"] == dataset_key]
        for baseline in baselines:
            pairs = _pair(current, method, baseline)
            if not pairs:
                continue
            grouped: dict[int, list[dict]] = defaultdict(list)
            for pair in pairs:
                grouped[int(pair["seed"])].append(pair)
            rng = np.random.default_rng(int(args.bootstrap_seed) + len(summaries) * 1009)
            accuracy_draws = _hierarchical_bootstrap(
                grouped, "accuracy_gain", int(args.bootstrap_replicates), rng
            )
            loss_draws = _hierarchical_bootstrap(
                grouped, "loss_reduction", int(args.bootstrap_replicates), rng
            )
            seed_effects = []
            for seed, values in sorted(grouped.items()):
                accuracy_gain = float(np.mean([row["accuracy_gain"] for row in values]))
                loss_reduction = float(np.mean([row["loss_reduction"] for row in values]))
                seed_effects.append(accuracy_gain)
                seed_rows.append(
                    {
                        "dataset_key": dataset_key,
                        "method": method,
                        "baseline": baseline,
                        "seed": seed,
                        "unit_count": len(values),
                        "mean_accuracy_gain": accuracy_gain,
                        "mean_loss_reduction": loss_reduction,
                    }
                )
            summaries.append(
                {
                    "dataset_key": dataset_key,
                    "method": method,
                    "baseline": baseline,
                    "seed_count": len(grouped),
                    "unit_count": len(pairs),
                    "complete_matched_coverage": len(pairs)
                    == sum(len(values) for values in grouped.values()),
                    "mean_accuracy_gain": float(np.mean([row["accuracy_gain"] for row in pairs])),
                    "accuracy_ci95_low": float(np.quantile(accuracy_draws, 0.025)),
                    "accuracy_ci95_high": float(np.quantile(accuracy_draws, 0.975)),
                    "mean_loss_reduction": float(np.mean([row["loss_reduction"] for row in pairs])),
                    "loss_reduction_ci95_low": float(np.quantile(loss_draws, 0.025)),
                    "loss_reduction_ci95_high": float(np.quantile(loss_draws, 0.975)),
                    "positive_seed_count": sum(value > 1e-12 for value in seed_effects),
                    "tie_seed_count": sum(abs(value) <= 1e-12 for value in seed_effects),
                    "negative_seed_count": sum(value < -1e-12 for value in seed_effects),
                    "accuracy_sign_flip_p_one_sided": _exact_sign_flip(seed_effects),
                    "bootstrap_replicates": int(args.bootstrap_replicates),
                    "bootstrap_seed": int(args.bootstrap_seed) + len(summaries) * 1009,
                }
            )
    if not summaries:
        raise ValueError("No complete requested method/baseline pairs were found")
    _write_csv(output / "paired_method_comparisons.csv", summaries)
    _write_csv(output / "paired_seed_effects.csv", seed_rows)
    _write_report(output / "paired_method_comparisons.md", summaries)
    return 0


def _load_rows(root: Path) -> list[dict]:
    rows: list[dict] = []
    for path in sorted(root.glob("*/seed_*/per_client_metrics.csv")):
        dataset_key = path.parents[1].name
        seed = int(path.parent.name.rsplit("_", 1)[-1])
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle):
                rows.append(
                    {
                        "dataset_key": dataset_key,
                        "seed": seed,
                        "method": str(row["method"]),
                        "client_id": str(row["client_id"]),
                        "domain": str(row.get("domain", "")),
                        "accuracy": float(row["accuracy"]),
                        "loss": float(row["loss"]),
                    }
                )
    return rows


def _pair(rows: list[dict], method: str, baseline: str) -> list[dict]:
    index: dict[tuple[int, str, str, str], dict] = {}
    for row in rows:
        key = (int(row["seed"]), row["client_id"], row["domain"], row["method"])
        if key in index:
            raise ValueError(f"Duplicate per-client row: {key}")
        index[key] = row
    pairs = []
    units = sorted({(int(row["seed"]), row["client_id"], row["domain"]) for row in rows})
    for seed, client_id, domain in units:
        left = index.get((seed, client_id, domain, method))
        right = index.get((seed, client_id, domain, baseline))
        if left is None or right is None:
            continue
        pairs.append(
            {
                "seed": seed,
                "client_id": client_id,
                "domain": domain,
                "accuracy_gain": left["accuracy"] - right["accuracy"],
                "loss_reduction": right["loss"] - left["loss"],
            }
        )
    return pairs


def _hierarchical_bootstrap(
    grouped: dict[int, list[dict]], field: str, replicates: int, rng: np.random.Generator
) -> np.ndarray:
    seeds = np.asarray(sorted(grouped), dtype=np.int64)
    draws = np.empty(replicates, dtype=np.float64)
    for draw_index in range(replicates):
        sampled_seeds = rng.choice(seeds, size=seeds.size, replace=True)
        sampled_values = []
        for seed in sampled_seeds:
            values = np.asarray([row[field] for row in grouped[int(seed)]], dtype=np.float64)
            sampled_values.extend(rng.choice(values, size=values.size, replace=True).tolist())
        draws[draw_index] = float(np.mean(sampled_values))
    return draws


def _exact_sign_flip(values: list[float]) -> float:
    nonzero = np.asarray([value for value in values if abs(value) > 1e-12], dtype=np.float64)
    if nonzero.size == 0:
        return 1.0
    observed = float(np.mean(nonzero))
    total = 0
    extreme = 0
    for signs in itertools.product((-1.0, 1.0), repeat=int(nonzero.size)):
        total += 1
        if float(np.mean(nonzero * np.asarray(signs))) >= observed - 1e-12:
            extreme += 1
    return float(extreme / total)


def _write_csv(path: Path, rows: list[dict]) -> None:
    fields = list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _write_report(path: Path, rows: list[dict]) -> None:
    lines = [
        "# Frozen Method Paired Comparison Audit",
        "",
        "| Dataset | Baseline | Seeds | Units | Accuracy gain | 95% hierarchical CI | +/0/- seeds | One-sided sign-flip p |",
        "|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            f"| {row['dataset_key']} | {row['baseline']} | {row['seed_count']} | {row['unit_count']} | "
            f"{row['mean_accuracy_gain']:.4f} | [{row['accuracy_ci95_low']:.4f}, {row['accuracy_ci95_high']:.4f}] | "
            f"{row['positive_seed_count']}/{row['tie_seed_count']}/{row['negative_seed_count']} | "
            f"{row['accuracy_sign_flip_p_one_sided']:.6f} |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
