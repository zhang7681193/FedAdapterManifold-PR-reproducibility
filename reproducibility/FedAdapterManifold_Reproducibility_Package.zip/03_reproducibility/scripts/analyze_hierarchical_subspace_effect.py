from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path

import numpy as np


DEFAULT_FAMILIES = {
    "PACS": "PACS",
    "DINOv2-PACS": "PACS",
    "CLIP-PACS": "PACS",
    "OfficeCaltech": "OfficeCaltech",
    "CLIP-OfficeCaltech": "OfficeCaltech",
    "DomainNetMini": "DomainNetMini",
    "CLIP-DomainNetMini": "DomainNetMini",
    "CLIP-DomainNetMini-Large": "DomainNetMini",
    "BloodMNIST": "BloodMNIST",
    "DINOv2-OfficeHome": "OfficeHome",
    "CLIP-OfficeHome": "OfficeHome",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Hierarchical family/setting/seed inference for the core d_sub diagnostic."
    )
    parser.add_argument(
        "--input",
        default="results/fam_admit_clustered_stats_v1/directional_subspace_failure_samples.csv",
    )
    parser.add_argument(
        "--output-dir",
        default="results/fam_hierarchical_subspace_effect_20260805",
    )
    parser.add_argument("--bootstrap-replicates", type=int, default=200000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260805)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    rows = _read_csv(Path(args.input))
    grouped = _group(rows)
    missing = sorted(set(grouped) - set(DEFAULT_FAMILIES))
    if missing:
        raise ValueError(f"Missing dataset-family declarations: {missing}")
    setting_rows = _setting_effect_rows(grouped)
    family_effects = _family_effects(setting_rows)
    observed = _equal_family_effect(family_effects)
    rng = np.random.default_rng(args.bootstrap_seed)
    draws = _hierarchical_bootstrap(grouped, args.bootstrap_replicates, rng)
    low, high = np.quantile(draws, [0.025, 0.975])
    family_sign_p = 0.5 ** len(family_effects) if all(value > 0.0 for value in family_effects.values()) else math.nan
    nonpositive_fraction = float(np.mean(draws <= 0.0))

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    _write_csv(output_dir / "setting_effects.csv", setting_rows)
    _write_csv(
        output_dir / "family_effects.csv",
        [
            {"dataset_family": family, "fisher_equal_setting_r": value}
            for family, value in sorted(family_effects.items())
        ],
    )
    summary = [{
        "measure": "d_sub_vs_failure_raw_directional",
        "n_dataset_families": len(family_effects),
        "n_backbone_settings": len(setting_rows),
        "n_federated_seeds": len({(row["dataset"], row["seed"]) for row in rows}),
        "equal_family_fisher_r": observed,
        "hierarchical_ci_low": float(low),
        "hierarchical_ci_high": float(high),
        "hierarchical_bootstrap_nonpositive_fraction": nonpositive_fraction,
        "positive_dataset_families": sum(value > 0.0 for value in family_effects.values()),
        "family_sign_test_one_sided_p": family_sign_p,
        "bootstrap_replicates": len(draws),
        "bootstrap_seed": args.bootstrap_seed,
    }]
    _write_csv(output_dir / "hierarchical_effect_summary.csv", summary)
    _write_report(output_dir / "hierarchical_effect_report.md", summary[0], family_effects, setting_rows)
    print(output_dir / "hierarchical_effect_report.md")
    return 0


def _group(rows: list[dict]) -> dict[str, dict[int, list[dict]]]:
    grouped: dict[str, dict[int, list[dict]]] = defaultdict(lambda: defaultdict(list))
    for row in rows:
        grouped[str(row["dataset"])][int(row["seed"])].append(row)
    return grouped


def _setting_effect_rows(grouped: dict[str, dict[int, list[dict]]]) -> list[dict]:
    output = []
    for setting, by_seed in sorted(grouped.items()):
        all_rows = [row for seed_rows in by_seed.values() for row in seed_rows]
        output.append({
            "dataset_family": DEFAULT_FAMILIES[setting],
            "setting": setting,
            "n_seeds": len(by_seed),
            "n_directional_pairs": len(all_rows),
            "pearson_r": _correlation(all_rows),
        })
    return output


def _family_effects(setting_rows: list[dict]) -> dict[str, float]:
    by_family: dict[str, list[float]] = defaultdict(list)
    for row in setting_rows:
        by_family[str(row["dataset_family"])].append(float(row["pearson_r"]))
    return {
        family: _fisher_mean(values)
        for family, values in by_family.items()
    }


def _equal_family_effect(family_effects: dict[str, float]) -> float:
    return _fisher_mean(list(family_effects.values()))


def _hierarchical_bootstrap(
    grouped: dict[str, dict[int, list[dict]]],
    replicates: int,
    rng: np.random.Generator,
) -> np.ndarray:
    by_family: dict[str, list[str]] = defaultdict(list)
    for setting in grouped:
        by_family[DEFAULT_FAMILIES[setting]].append(setting)
    families = sorted(by_family)
    draws = np.empty(int(replicates), dtype=np.float64)
    for replicate in range(int(replicates)):
        sampled_family_effects = []
        for family in rng.choice(families, size=len(families), replace=True):
            setting_effects = []
            for setting in by_family[str(family)]:
                seeds = sorted(grouped[setting])
                sampled_rows = []
                for seed in rng.choice(seeds, size=len(seeds), replace=True):
                    sampled_rows.extend(grouped[setting][int(seed)])
                setting_effects.append(_correlation(sampled_rows))
            sampled_family_effects.append(_fisher_mean(setting_effects))
        draws[replicate] = _fisher_mean(sampled_family_effects)
    return draws


def _correlation(rows: list[dict]) -> float:
    x = np.asarray([float(row["d_sub"]) for row in rows], dtype=np.float64)
    y = np.asarray([float(row["failure_raw_directional"]) for row in rows], dtype=np.float64)
    if len(x) < 2 or np.std(x) <= 1e-12 or np.std(y) <= 1e-12:
        return 0.0
    return float(np.corrcoef(x, y)[0, 1])


def _fisher_mean(values: list[float]) -> float:
    clipped = np.clip(np.asarray(values, dtype=np.float64), -0.999999, 0.999999)
    return float(np.tanh(np.mean(np.arctanh(clipped))))


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path: Path, rows: list[dict]) -> None:
    fields = list(rows[0])
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _write_report(path: Path, summary: dict, family_effects: dict[str, float], setting_rows: list[dict]) -> None:
    lines = [
        "# Hierarchical Adapter-Subspace Diagnostic",
        "",
        "The confirmatory measure is the pre-defined Grassmannian adapter distance `d_sub` against directional FedAvg-LoRA failure. Each dataset family receives equal weight. The bootstrap resamples dataset families and, within each backbone setting, federated seeds; client pairs are never treated as independent seeds.",
        "",
        f"- Equal-family Fisher effect: r = {float(summary['equal_family_fisher_r']):.4f}",
        f"- Hierarchical 95% CI: [{float(summary['hierarchical_ci_low']):.4f}, {float(summary['hierarchical_ci_high']):.4f}]",
        f"- Fraction of hierarchical bootstrap draws at or below zero: {float(summary['hierarchical_bootstrap_nonpositive_fraction']):.6g}",
        f"- Positive dataset families: {summary['positive_dataset_families']}/{summary['n_dataset_families']}",
        f"- Family-level one-sided sign p = {float(summary['family_sign_test_one_sided_p']):.6g}",
        "",
        "## Dataset-family effects",
        "",
        "| Family | Equal-setting Fisher r |",
        "|---|---:|",
    ]
    lines.extend(f"| {family} | {value:.4f} |" for family, value in sorted(family_effects.items()))
    lines.extend(["", "## Backbone-setting effects", "", "| Setting | Family | Seeds | Directional pairs | r |", "|---|---|---:|---:|---:|"])
    lines.extend(
        f"| {row['setting']} | {row['dataset_family']} | {row['n_seeds']} | {row['n_directional_pairs']} | {float(row['pearson_r']):.4f} |"
        for row in setting_rows
    )
    lines.extend([
        "",
        "This aggregate test supports a cross-setting association; it does not imply that every individual high-ceiling setting has a separately significant correlation.",
    ])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
