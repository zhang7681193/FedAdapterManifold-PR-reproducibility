from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score


ROOT = Path(__file__).resolve().parents[1]
FAMILIES = {
    "PACS": "PACS",
    "DINOv2-PACS": "PACS",
    "CLIP-PACS": "PACS",
    "OfficeCaltech": "OfficeCaltech",
    "CLIP-OfficeCaltech": "OfficeCaltech",
    "DomainNetMini": "DomainNetMini",
    "CLIP-DomainNetMini": "DomainNetMini",
    "CLIP-DomainNetMini-Large": "DomainNetMini",
    "BloodMNIST": "BloodMNIST",
    "DINOv2-OfficeHome": "OfficeHome",
    "CLIP-OfficeHome": "OfficeHome",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Incremental and predictive audit of the LoRA subspace diagnostic."
    )
    parser.add_argument(
        "--input",
        default="results/fam_admit_clustered_stats_v1/directional_subspace_failure_samples.csv",
    )
    parser.add_argument(
        "--output-dir",
        default="results/fam_incremental_subspace_diagnostic_20260805",
    )
    parser.add_argument("--bootstrap-replicates", type=int, default=20000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260805)
    return parser.parse_args()


def zscore_by_setting(frame: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    output = frame.copy()
    for column in columns:
        mean = output.groupby("dataset")[column].transform("mean")
        std = output.groupby("dataset")[column].transform("std").replace(0.0, np.nan)
        output[f"z_{column}"] = ((output[column] - mean) / std).fillna(0.0)
    return output


def receiver_difficulty(rows: pd.DataFrame) -> pd.DataFrame:
    records: list[dict] = []
    for (source, seed), group in rows.groupby(["source", "seed"], sort=False):
        metrics_path = ROOT / str(source) / f"seed_{int(seed)}" / "per_client_metrics.csv"
        if not metrics_path.is_file():
            continue
        metrics = pd.read_csv(metrics_path)
        local = metrics[metrics["method"].astype(str).str.startswith("Local-")].copy()
        if local.empty:
            continue
        for _, row in local.iterrows():
            client_id = str(row["client_id"])
            if client_id.replace(".0", "", 1).isdigit():
                client_id = f"client_{int(float(client_id))}"
            records.append(
                {
                    "source": source,
                    "seed": int(seed),
                    "receiver": client_id,
                    "receiver_local_loss": float(row["loss"]),
                    "receiver_local_accuracy": float(row["accuracy"]),
                }
            )
    return pd.DataFrame(records).drop_duplicates(["source", "seed", "receiver"])


def design(frame: pd.DataFrame, columns: list[str]) -> np.ndarray:
    return np.column_stack([np.ones(len(frame))] + [frame[column].to_numpy(float) for column in columns])


def ols_metrics(frame: pd.DataFrame, controls: list[str]) -> dict[str, float]:
    y = frame["z_failure_raw_directional"].to_numpy(float)
    x0 = design(frame, controls)
    x1 = design(frame, controls + ["z_d_sub"])
    b0 = np.linalg.lstsq(x0, y, rcond=None)[0]
    b1 = np.linalg.lstsq(x1, y, rcond=None)[0]
    pred0 = x0 @ b0
    pred1 = x1 @ b1
    sst = np.sum((y - y.mean()) ** 2)
    r2_0 = 1.0 - np.sum((y - pred0) ** 2) / sst
    r2_1 = 1.0 - np.sum((y - pred1) ** 2) / sst
    resid_y = y - pred0
    x_sub = frame["z_d_sub"].to_numpy(float)
    sub_fit = x0 @ np.linalg.lstsq(x0, x_sub, rcond=None)[0]
    resid_sub = x_sub - sub_fit
    partial = float(np.corrcoef(resid_sub, resid_y)[0, 1])
    return {
        "n_rows": len(frame),
        "n_settings": frame["dataset"].nunique(),
        "n_families": frame["family"].nunique(),
        "d_sub_standardized_beta": float(b1[-1]),
        "partial_r": partial,
        "context_r2": float(r2_0),
        "context_plus_subspace_r2": float(r2_1),
        "incremental_r2": float(r2_1 - r2_0),
    }


def hierarchical_bootstrap_beta(
    frame: pd.DataFrame,
    controls: list[str],
    replicates: int,
    rng: np.random.Generator,
) -> np.ndarray:
    families = sorted(frame["family"].unique())
    y = frame["z_failure_raw_directional"].to_numpy(float)
    x = design(frame, controls + ["z_d_sub"])
    blocks: dict[str, dict[str, dict[int, np.ndarray]]] = {}
    for family in families:
        blocks[family] = {}
        family_mask = frame["family"].to_numpy() == family
        for setting in frame.loc[family_mask, "dataset"].unique():
            blocks[family][setting] = {}
            setting_mask = family_mask & (frame["dataset"].to_numpy() == setting)
            for seed in frame.loc[setting_mask, "seed"].unique():
                blocks[family][setting][int(seed)] = np.flatnonzero(
                    setting_mask & (frame["seed"].to_numpy() == seed)
                )
    values = np.empty(replicates, dtype=float)
    for index in range(replicates):
        sampled_indices: list[np.ndarray] = []
        for family in rng.choice(families, size=len(families), replace=True):
            for setting_blocks in blocks[str(family)].values():
                seeds = np.asarray(sorted(setting_blocks), dtype=int)
                for seed in rng.choice(seeds, size=len(seeds), replace=True):
                    sampled_indices.append(setting_blocks[int(seed)])
        row_indices = np.concatenate(sampled_indices)
        values[index] = np.linalg.lstsq(x[row_indices], y[row_indices], rcond=None)[0][-1]
    return values


def leave_one_family_out(frame: pd.DataFrame, controls: list[str]) -> pd.DataFrame:
    rows: list[dict] = []
    y_column = "z_failure_raw_directional"
    for family in sorted(frame["family"].unique()):
        train = frame[frame["family"] != family]
        test = frame[frame["family"] == family]
        y_train = train[y_column].to_numpy(float)
        y_test = test[y_column].to_numpy(float)
        x0_train = design(train, controls)
        x1_train = design(train, controls + ["z_d_sub"])
        x0_test = design(test, controls)
        x1_test = design(test, controls + ["z_d_sub"])
        b0 = np.linalg.lstsq(x0_train, y_train, rcond=None)[0]
        b1 = np.linalg.lstsq(x1_train, y_train, rcond=None)[0]
        rmse0 = float(np.sqrt(np.mean((y_test - x0_test @ b0) ** 2)))
        rmse1 = float(np.sqrt(np.mean((y_test - x1_test @ b1) ** 2)))
        rows.append(
            {
                "held_out_family": family,
                "n_test_rows": len(test),
                "context_rmse": rmse0,
                "context_plus_subspace_rmse": rmse1,
                "rmse_reduction": rmse0 - rmse1,
            }
        )
    return pd.DataFrame(rows)


def seed_cross_validated_classification(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    feature_sets = {
        "subspace_only": ["z_d_sub"],
        "context_only": ["z_d_geo", "z_receiver_local_loss", "z_d_label", "label_available"],
        "context_plus_subspace": [
            "z_d_geo",
            "z_receiver_local_loss",
            "z_d_label",
            "label_available",
            "z_d_sub",
        ],
    }
    predictions: list[dict] = []
    for setting, setting_frame in frame.groupby("dataset"):
        for seed in sorted(setting_frame["seed"].unique()):
            train = setting_frame[setting_frame["seed"] != seed]
            test = setting_frame[setting_frame["seed"] == seed]
            if train["harmful_transfer"].nunique() < 2:
                continue
            for model_name, columns in feature_sets.items():
                model = LogisticRegression(C=1.0, max_iter=1000, class_weight="balanced")
                model.fit(train[columns], train["harmful_transfer"])
                probability = model.predict_proba(test[columns])[:, 1]
                for row_index, score in zip(test.index, probability):
                    predictions.append(
                        {
                            "dataset": setting,
                            "family": test.loc[row_index, "family"],
                            "seed": int(seed),
                            "row_index": int(row_index),
                            "model": model_name,
                            "harmful_transfer": int(test.loc[row_index, "harmful_transfer"]),
                            "probability": float(score),
                        }
                    )
    prediction_frame = pd.DataFrame(predictions)
    metric_rows: list[dict] = []
    for (setting, model_name), group in prediction_frame.groupby(["dataset", "model"]):
        if group["harmful_transfer"].nunique() < 2:
            continue
        metric_rows.append(
            {
                "dataset": setting,
                "family": group["family"].iloc[0],
                "model": model_name,
                "n_rows": len(group),
                "roc_auc": roc_auc_score(group["harmful_transfer"], group["probability"]),
                "pr_auc": average_precision_score(group["harmful_transfer"], group["probability"]),
                "brier": brier_score_loss(group["harmful_transfer"], group["probability"]),
            }
        )
    return prediction_frame, pd.DataFrame(metric_rows)


def quantile_audit(frame: pd.DataFrame) -> pd.DataFrame:
    work = frame.copy()
    work["d_sub_percentile"] = work.groupby("dataset")["d_sub"].rank(pct=True, method="average")
    work["d_sub_quartile"] = pd.cut(
        work["d_sub_percentile"], [0.0, 0.25, 0.5, 0.75, 1.0],
        labels=["Q1", "Q2", "Q3", "Q4"], include_lowest=True,
    )
    setting_rows = (
        work.groupby(["dataset", "family", "d_sub_quartile"], observed=True)
        .agg(
            n_rows=("d_sub", "size"),
            harmful_transfer_rate=("harmful_transfer", "mean"),
            mean_failure=("failure_raw_directional", "mean"),
        )
        .reset_index()
    )
    equal_setting = (
        setting_rows.groupby("d_sub_quartile", observed=True)
        .agg(
            settings=("dataset", "nunique"),
            equal_setting_harmful_rate=("harmful_transfer_rate", "mean"),
            equal_setting_mean_failure=("mean_failure", "mean"),
        )
        .reset_index()
    )
    return equal_setting


def write_report(
    path: Path,
    complete_metrics: dict[str, float],
    bootstrap: np.ndarray,
    lofo: pd.DataFrame,
    classification: pd.DataFrame,
    quantiles: pd.DataFrame,
    difficult_metrics: dict[str, float],
) -> None:
    low, high = np.quantile(bootstrap, [0.025, 0.975])
    macro = classification.groupby("model")[["roc_auc", "pr_auc", "brier"]].mean()
    lines = [
        "# Incremental Adapter-Subspace Diagnostic",
        "",
        "This audit uses directional transfer records and treats the federated seed, not each client pair, as the independent resampling unit. Predictors and failure are standardized within each backbone setting. The strict complete-case model controls visual geometry distance, label discrepancy, and receiver Local-LoRA loss before adding Grassmannian adapter distance.",
        "",
        "## Controlled continuous effect",
        "",
        f"- Complete rows/settings/families: {int(complete_metrics['n_rows'])}/{int(complete_metrics['n_settings'])}/{int(complete_metrics['n_families'])}",
        f"- Standardized d_sub coefficient: {complete_metrics['d_sub_standardized_beta']:.4f}",
        f"- Hierarchical 95% interval: [{low:.4f}, {high:.4f}]",
        f"- Partial correlation after controls: {complete_metrics['partial_r']:.4f}",
        f"- Incremental R2: {complete_metrics['incremental_r2']:.4f}",
        f"- Difficult-receiver partial correlation: {difficult_metrics['partial_r']:.4f}",
        "",
        "## Leave-one-dataset-family-out generalization",
        "",
        "| Held-out family | Rows | Context RMSE | Context+d_sub RMSE | RMSE reduction |",
        "|---|---:|---:|---:|---:|",
    ]
    lines.extend(
        f"| {row.held_out_family} | {int(row.n_test_rows)} | {row.context_rmse:.4f} | {row.context_plus_subspace_rmse:.4f} | {row.rmse_reduction:+.4f} |"
        for row in lofo.itertuples()
    )
    lines.extend([
        "",
        "## Leave-one-seed-out harmful-transfer prediction",
        "",
        "| Model | Macro ROC-AUC | Macro PR-AUC | Macro Brier |",
        "|---|---:|---:|---:|",
    ])
    lines.extend(
        f"| {model} | {row.roc_auc:.4f} | {row.pr_auc:.4f} | {row.brier:.4f} |"
        for model, row in macro.iterrows()
    )
    lines.extend([
        "",
        "## Equal-setting d_sub quartiles",
        "",
        "| Quartile | Settings | Harmful-transfer rate | Mean directional failure |",
        "|---|---:|---:|---:|",
    ])
    lines.extend(
        f"| {row.d_sub_quartile} | {int(row.settings)} | {row.equal_setting_harmful_rate:.4f} | {row.equal_setting_mean_failure:.4f} |"
        for row in quantiles.itertuples()
    )
    lines.extend([
        "",
        "The analysis is diagnostic rather than causal. A positive controlled coefficient and improved out-of-family prediction support incremental information beyond geometry, labels, and receiver difficulty; mixed held-out families define the claim boundary.",
    ])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    args = parse_args()
    input_path = ROOT / args.input
    output_dir = ROOT / args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    frame = pd.read_csv(input_path)
    frame["family"] = frame["dataset"].map(FAMILIES)
    if frame["family"].isna().any():
        missing = sorted(frame.loc[frame["family"].isna(), "dataset"].unique())
        raise ValueError(f"Missing family declarations: {missing}")
    difficulty = receiver_difficulty(frame)
    frame = frame.merge(difficulty, on=["source", "seed", "receiver"], how="left", validate="many_to_one")
    if frame["receiver_local_loss"].isna().any():
        raise ValueError("Receiver Local-LoRA difficulty is missing for one or more directional rows")
    frame["label_available"] = frame["d_label"].notna().astype(float)
    frame["d_label"] = frame["d_label"].fillna(0.0)
    frame["harmful_transfer"] = (frame["failure_raw_directional"] > 0.0).astype(int)
    frame = zscore_by_setting(
        frame,
        ["d_sub", "d_geo", "d_label", "receiver_local_loss", "failure_raw_directional"],
    )

    controls = ["z_d_geo", "z_d_label", "z_receiver_local_loss"]
    strict = frame[frame["label_available"] == 1.0].copy()
    complete_metrics = ols_metrics(strict, controls)
    rng = np.random.default_rng(args.bootstrap_seed)
    bootstrap = hierarchical_bootstrap_beta(
        strict, controls, args.bootstrap_replicates, rng
    )
    difficult = strict[
        strict["receiver_local_loss"]
        >= strict.groupby(["dataset", "seed"])["receiver_local_loss"].transform("median")
    ]
    difficult_metrics = ols_metrics(difficult, controls)
    lofo = leave_one_family_out(strict, controls)
    predictions, classification = seed_cross_validated_classification(frame)
    quantiles = quantile_audit(frame)

    summary = pd.DataFrame([
        {
            **complete_metrics,
            "hierarchical_ci_low": float(np.quantile(bootstrap, 0.025)),
            "hierarchical_ci_high": float(np.quantile(bootstrap, 0.975)),
            "bootstrap_replicates": len(bootstrap),
            "bootstrap_seed": args.bootstrap_seed,
            "difficult_receiver_partial_r": difficult_metrics["partial_r"],
        }
    ])
    summary.to_csv(output_dir / "incremental_effect_summary.csv", index=False)
    lofo.to_csv(output_dir / "leave_one_family_out.csv", index=False)
    predictions.to_csv(output_dir / "harmful_transfer_predictions.csv", index=False)
    classification.to_csv(output_dir / "harmful_transfer_metrics.csv", index=False)
    quantiles.to_csv(output_dir / "d_sub_quantile_audit.csv", index=False)
    write_report(
        output_dir / "incremental_subspace_report.md",
        complete_metrics,
        bootstrap,
        lofo,
        classification,
        quantiles,
        difficult_metrics,
    )
    print(output_dir / "incremental_subspace_report.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
