from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "results" / "fam_intrinsic_admission_safety_20260805"
SETTINGS = {
    "PACS": ROOT / "results" / "fam_pacs_manifest_fedavg_fedper_fam_5seed_v1",
    "Office-Caltech": ROOT
    / "results"
    / "fam_officecaltech_neighbor_selector_fedrot_w050_v1",
    "DomainNetMini": ROOT
    / "results"
    / "fam_domainnetmini_manifest_fedavg_fedper_fam_5seed_v1",
    "BloodMNIST": ROOT / "results" / "fam_blood_manifest_fedavg_fedper_fam_5seed_v1",
    "OfficeHome-DINOv2": ROOT
    / "results"
    / "fam_dinov2_officehome_full_calib20_noregret_5seed_v1",
    "OfficeHome-CLIP": ROOT
    / "results"
    / "fam_clip_officehome_full_calib20_noregret_5seed_v2",
}

METHODS = {
    "local": "Local-LoRA",
    "fedavg": "FedAvg-LoRA",
    "geo": "FedGeo-Agg",
    "subspace": "Subspace-Compatible",
    "final": "FedAdapterManifold-Selective",
}
TOL = 1e-12


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def relation(delta: float) -> str:
    if delta > TOL:
        return "improve"
    if delta < -TOL:
        return "degrade"
    return "tie"


def collect_units() -> list[dict[str, object]]:
    units: list[dict[str, object]] = []
    for setting, root in SETTINGS.items():
        for seed_dir in sorted(root.glob("seed_*")):
            metrics_path = seed_dir / "per_client_metrics.csv"
            selection_path = seed_dir / "adapter_candidate_selection.csv"
            if not metrics_path.exists() or not selection_path.exists():
                raise FileNotFoundError(f"Missing audit artifact under {seed_dir}")

            metric_rows = read_rows(metrics_path)
            by_client: dict[str, dict[str, float]] = defaultdict(dict)
            for row in metric_rows:
                method = row["method"]
                if method in METHODS.values():
                    by_client[row["client_id"]][method] = float(row["accuracy"])

            selected_by_client: dict[str, str] = {}
            for row in read_rows(selection_path):
                if row.get("method") != METHODS["final"]:
                    continue
                selected_by_client.setdefault(row["client_id"], row["selected_method"])

            seed = int(seed_dir.name.split("_")[-1])
            for client_id, scores in sorted(by_client.items()):
                missing = [method for method in METHODS.values() if method not in scores]
                if missing:
                    raise ValueError(
                        f"{setting} seed={seed} {client_id} misses methods: {missing}"
                    )
                anchor_oracle = max(scores[METHODS["local"]], scores[METHODS["geo"]])
                subspace_delta = scores[METHODS["subspace"]] - anchor_oracle
                final_avg_delta = scores[METHODS["final"]] - scores[METHODS["fedavg"]]
                final_geo_delta = scores[METHODS["final"]] - scores[METHODS["geo"]]
                selected = selected_by_client.get(client_id, "")
                harmful_subspace = subspace_delta < -TOL
                units.append(
                    {
                        "setting": setting,
                        "seed": seed,
                        "client_id": client_id,
                        "selected_method": selected,
                        "local_accuracy": scores[METHODS["local"]],
                        "fedavg_accuracy": scores[METHODS["fedavg"]],
                        "geo_accuracy": scores[METHODS["geo"]],
                        "subspace_accuracy": scores[METHODS["subspace"]],
                        "final_accuracy": scores[METHODS["final"]],
                        "subspace_delta_vs_best_local_geo": subspace_delta,
                        "harmful_subspace_candidate": int(harmful_subspace),
                        "harmful_subspace_rejected": int(
                            harmful_subspace and selected != METHODS["subspace"]
                        ),
                        "final_delta_vs_fedavg": final_avg_delta,
                        "final_vs_fedavg": relation(final_avg_delta),
                        "final_delta_vs_geo": final_geo_delta,
                        "final_vs_geo": relation(final_geo_delta),
                    }
                )
    return units


def summarize(units: list[dict[str, object]]) -> list[dict[str, object]]:
    groups: dict[str, list[dict[str, object]]] = defaultdict(list)
    groups["All six settings"] = units
    for row in units:
        groups[str(row["setting"])].append(row)

    summary: list[dict[str, object]] = []
    for setting, rows in groups.items():
        harmful = sum(int(row["harmful_subspace_candidate"]) for row in rows)
        rejected = sum(int(row["harmful_subspace_rejected"]) for row in rows)
        summary.append(
            {
                "setting": setting,
                "client_seed_units": len(rows),
                "harmful_subspace_candidates": harmful,
                "harmful_subspace_rejected": rejected,
                "rejection_rate": rejected / harmful if harmful else 1.0,
                "final_vs_fedavg_improve": sum(
                    row["final_vs_fedavg"] == "improve" for row in rows
                ),
                "final_vs_fedavg_tie": sum(row["final_vs_fedavg"] == "tie" for row in rows),
                "final_vs_fedavg_degrade": sum(
                    row["final_vs_fedavg"] == "degrade" for row in rows
                ),
                "final_vs_geo_improve": sum(row["final_vs_geo"] == "improve" for row in rows),
                "final_vs_geo_tie": sum(row["final_vs_geo"] == "tie" for row in rows),
                "final_vs_geo_degrade": sum(row["final_vs_geo"] == "degrade" for row in rows),
            }
        )
    return summary


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_report(summary: list[dict[str, object]]) -> None:
    overall = summary[0]
    lines = [
        "# Intrinsic admission safety audit",
        "",
        "This is a retrospective test-only audit. Held-out test labels are used only to",
        "measure the selected adapter after the fixed training/calibration decision; they",
        "never tune the gate or choose a candidate.",
        "",
        f"Across {overall['client_seed_units']} client-seed units, the raw Subspace-Compatible",
        f"candidate was worse than the better of Local-LoRA and Geo-only Agg in",
        f"{overall['harmful_subspace_candidates']} units. The pre-test selector rejected",
        f"{overall['harmful_subspace_rejected']} of those candidates",
        f"({100.0 * float(overall['rejection_rate']):.1f}%).",
        "",
        "The final intrinsic rule versus FedAvg-LoRA has improve/tie/degrade counts of",
        f"{overall['final_vs_fedavg_improve']}/{overall['final_vs_fedavg_tie']}/",
        f"{overall['final_vs_fedavg_degrade']}; versus Geo-only Agg the counts are",
        f"{overall['final_vs_geo_improve']}/{overall['final_vs_geo_tie']}/",
        f"{overall['final_vs_geo_degrade']}.",
        "",
        "| Setting | Units | Unsafe subspace rejected | Final vs FedAvg (+/=/-) | Final vs Geo (+/=/-) |",
        "|---|---:|---:|---:|---:|",
    ]
    for row in summary[1:]:
        lines.append(
            f"| {row['setting']} | {row['client_seed_units']} | "
            f"{row['harmful_subspace_rejected']}/{row['harmful_subspace_candidates']} | "
            f"{row['final_vs_fedavg_improve']}/{row['final_vs_fedavg_tie']}/"
            f"{row['final_vs_fedavg_degrade']} | "
            f"{row['final_vs_geo_improve']}/{row['final_vs_geo_tie']}/"
            f"{row['final_vs_geo_degrade']} |"
        )
    lines.extend(
        [
            "",
            "The audit certifies rejection of the raw Subspace-Compatible candidate only.",
            "It does not claim that every bank mixture is harmless, nor does it replace",
            "seed-clustered accuracy inference.",
        ]
    )
    (OUTPUT / "intrinsic_admission_safety_report.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    units = collect_units()
    summary = summarize(units)
    write_csv(OUTPUT / "intrinsic_admission_safety_units.csv", units)
    write_csv(OUTPUT / "intrinsic_admission_safety_summary.csv", summary)
    write_report(summary)
    print(OUTPUT / "intrinsic_admission_safety_report.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
