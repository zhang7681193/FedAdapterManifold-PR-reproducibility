from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEVELOPMENT_TABLE = ROOT / "results/fam_admit_clustered_stats_v1/directional_subspace_failure_samples.csv"
DEFAULT_OUTPUT = ROOT / "results/opportunity_conditioned_subspace_confirmation_20260812"
SETTINGS = {
    "DINOv2-PACS": "pacs_dinov2",
    "CLIP-DomainNetMini": "domainnetmini_clip",
}
ANALYSIS_SEED = 20260812


def _sign_flip_p(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=np.float64)
    if len(values) == 0:
        return float("nan")
    observed = float(values.mean())
    if len(values) <= 20:
        flipped = []
        for signs in itertools.product((-1.0, 1.0), repeat=len(values)):
            flipped.append(float(np.mean(values * np.asarray(signs))))
        return float(np.count_nonzero(np.asarray(flipped) >= observed) / len(flipped))
    rng = np.random.default_rng(ANALYSIS_SEED)
    flipped = np.mean(
        values[None, :] * rng.choice((-1.0, 1.0), size=(100000, len(values))),
        axis=1,
    )
    return float((np.count_nonzero(flipped >= observed) + 1) / (len(flipped) + 1))


def _bootstrap_mean(values: np.ndarray, n_boot: int = 20000) -> tuple[float, float]:
    values = np.asarray(values, dtype=np.float64)
    rng = np.random.default_rng(ANALYSIS_SEED)
    samples = rng.choice(values, size=(n_boot, len(values)), replace=True).mean(axis=1)
    return tuple(float(v) for v in np.quantile(samples, [0.025, 0.975]))


def _development_thresholds() -> pd.DataFrame:
    frame = pd.read_csv(DEVELOPMENT_TABLE)
    frame = frame[frame["dataset"].isin(SETTINGS)].copy()
    frame = frame[frame["seed"].isin(range(5))]
    rows = []
    for setting in SETTINGS:
        subset = frame[frame["dataset"] == setting].dropna(
            subset=["d_sub", "d_geo", "failure_raw_directional"]
        )
        rows.append(
            {
                "setting": setting,
                "development_seeds": "0,1,2,3,4",
                "n_directional_pairs": len(subset),
                "geometry_close_threshold": float(subset["d_geo"].median()),
                "subspace_far_threshold": float(subset["d_sub"].median()),
            }
        )
    return pd.DataFrame(rows)


def _read_confirmation(output_root: Path) -> pd.DataFrame:
    rows = []
    for setting, folder in SETTINGS.items():
        setting_root = output_root / folder
        for seed in range(5, 10):
            path = setting_root / f"seed_{seed}" / "adapter_conflict.csv"
            if not path.exists():
                raise FileNotFoundError(path)
            frame = pd.read_csv(path)
            required = {"d_sub", "d_geo", "aggregation_failure", "raw_accuracy_delta"}
            missing = required.difference(frame.columns)
            if missing:
                raise ValueError(f"{path} is missing {sorted(missing)}")
            frame["setting"] = setting
            frame["seed"] = seed
            rows.append(frame)
    return pd.concat(rows, ignore_index=True)


def analyze(output_root: Path) -> dict[str, object]:
    thresholds = _development_thresholds()
    thresholds.to_csv(output_root / "frozen_development_thresholds.csv", index=False)
    threshold_map = thresholds.set_index("setting").to_dict(orient="index")
    frame = _read_confirmation(output_root)
    eligible_parts = []
    for setting, subset in frame.groupby("setting", sort=False):
        rule = threshold_map[setting]
        eligible = subset[
            subset["d_geo"].astype(float) <= float(rule["geometry_close_threshold"])
        ].copy()
        eligible["subspace_group"] = np.where(
            eligible["d_sub"].astype(float) >= float(rule["subspace_far_threshold"]),
            "far",
            "near",
        )
        eligible_parts.append(eligible)
    eligible = pd.concat(eligible_parts, ignore_index=True)
    eligible.to_csv(output_root / "eligible_confirmation_pairs.csv", index=False)

    units = []
    for (setting, seed), subset in eligible.groupby(["setting", "seed"], sort=True):
        far = subset[subset["subspace_group"] == "far"]
        near = subset[subset["subspace_group"] == "near"]
        units.append(
            {
                "setting": setting,
                "seed": int(seed),
                "n_far": len(far),
                "n_near": len(near),
                "far_failure": float(far["aggregation_failure"].mean()) if len(far) else np.nan,
                "near_failure": float(near["aggregation_failure"].mean()) if len(near) else np.nan,
                "failure_delta_far_minus_near": (
                    float(far["aggregation_failure"].mean() - near["aggregation_failure"].mean())
                    if len(far) and len(near)
                    else np.nan
                ),
                "raw_delta_far_minus_near": (
                    float(far["raw_accuracy_delta"].mean() - near["raw_accuracy_delta"].mean())
                    if len(far) and len(near)
                    else np.nan
                ),
            }
        )
    unit_frame = pd.DataFrame(units)
    unit_frame.to_csv(output_root / "dataset_seed_effects.csv", index=False)
    complete = unit_frame.dropna(subset=["failure_delta_far_minus_near"])
    effects = complete["failure_delta_far_minus_near"].to_numpy(dtype=np.float64)
    ci_low, ci_high = _bootstrap_mean(effects)
    correlation = float(eligible[["d_sub", "aggregation_failure"]].corr().iloc[0, 1])
    summary = {
        "n_confirmation_directional_pairs": int(len(frame)),
        "n_geometry_close_pairs": int(len(eligible)),
        "n_complete_dataset_seed_units": int(len(complete)),
        "primary_mean_failure_delta": float(effects.mean()),
        "primary_ci_low": ci_low,
        "primary_ci_high": ci_high,
        "primary_positive_unit_fraction": float(np.mean(effects > 0)),
        "primary_sign_flip_p_one_sided": _sign_flip_p(effects),
        "secondary_mean_raw_delta": float(complete["raw_delta_far_minus_near"].mean()),
        "geometry_close_subspace_failure_pearson_r": correlation,
        "confirmation_passed": bool(float(effects.mean()) > 0 and ci_low > 0),
    }
    pd.DataFrame([summary]).to_csv(output_root / "confirmation_summary.csv", index=False)
    report = [
        "# Opportunity-conditioned subspace confirmation",
        "",
        "The rule, development seeds, confirmation seeds, and endpoint were frozen before reading the confirmation diagnostics.",
        "",
        f"- Confirmation pairs: {summary['n_confirmation_directional_pairs']}",
        f"- Geometry-close pairs: {summary['n_geometry_close_pairs']}",
        f"- Complete dataset-seed units: {summary['n_complete_dataset_seed_units']}",
        f"- Far-minus-near aggregation-failure delta: {summary['primary_mean_failure_delta']:.6f}",
        f"- Dataset-seed bootstrap 95% CI: [{ci_low:.6f}, {ci_high:.6f}]",
        f"- Positive unit fraction: {summary['primary_positive_unit_fraction']:.3f}",
        f"- One-sided exact sign-flip p: {summary['primary_sign_flip_p_one_sided']:.6f}",
        f"- Geometry-close Pearson r: {correlation:.6f}",
        f"- Pre-registered confirmation passed: {summary['confirmation_passed']}",
        "",
        "Interpretation: this test asks whether subspace distance separates safe from harmful sharing when visual geometry already makes sharing plausible. It is not a post-hoc all-pairs correlation.",
    ]
    (output_root / "confirmation_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT))
    args = parser.parse_args()
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    summary = analyze(output_root)
    print(summary)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
