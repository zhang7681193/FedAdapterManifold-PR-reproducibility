from __future__ import annotations

import argparse
import hashlib
import json
from argparse import Namespace
from pathlib import Path

import numpy as np
import pandas as pd

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.config import merge_defaults
from fedadaptermanifold.risk_geometry import directed_receiver_risk_subspace_distance_matrix
from fedadaptermanifold.run_experiment import _load_clients


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = ROOT / "results" / "opportunity_conditioned_subspace_confirmation_20260812"
DEFAULT_OUTPUT = ROOT / "results" / "receiver_risk_subspace_replay_20260814"
SETTINGS = {
    "DINOv2-PACS": "pacs_dinov2",
    "CLIP-DomainNetMini": "domainnetmini_clip",
}
SEEDS = tuple(range(5, 10))
BASE_CONTROLS = (
    "d_sub",
    "d_action",
    "d_geo",
    "d_label",
    "d_update",
    "d_local_risk",
    "d_projection",
)
NEW_PREDICTORS = ("d_risk_sub", "risk_normal_energy_ratio")
TARGET = "semantic_exact_loss_failure"
ANALYSIS_SEED = 20260814


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Frozen Stage-A receiver-risk subspace replay")
    parser.add_argument("--source-root", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--permutations", type=int, default=2000)
    return parser.parse_args()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _normalize_windows_path(value: object) -> object:
    if not isinstance(value, str):
        return value
    text = value
    while "\\\\" in text:
        text = text.replace("\\\\", "\\")
    return text


def _load_frozen_bundle(seed_dir: Path, cached_base_weight: np.ndarray | None):
    config_path = seed_dir / "config.yaml"
    config = merge_defaults(str(config_path))
    for key in ("data_root", "feature_cache_dir", "geometry_outputs_dir"):
        config[key] = _normalize_windows_path(config.get(key, ""))
    config["device"] = "cpu"
    config["cpu_debug"] = True
    if cached_base_weight is not None:
        config["base_head_init"] = "zero"
    clients, reconstructed_base, _ = _load_clients(Namespace(**config))
    base_weight = reconstructed_base if cached_base_weight is None else cached_base_weight

    deltas = np.load(seed_dir / "local_anchor_deltas.npy", allow_pickle=False)
    metrics = pd.read_csv(seed_dir / "per_client_metrics.csv")
    local_rows = metrics.loc[metrics["method"].eq("Local-LoRA")].copy()
    local_rows = local_rows.drop_duplicates("client_id").set_index("client_id")
    if deltas.shape[0] != len(clients):
        raise ValueError(f"{seed_dir}: {deltas.shape[0]} deltas for {len(clients)} clients")
    adapters = []
    for index, client in enumerate(clients):
        rank = int(local_rows.loc[client.client_id, "rank"])
        adapter = LoRAAdapter.from_delta(deltas[index], rank=rank, name=f"risk-replay-{client.client_id}")
        relative_error = float(
            np.linalg.norm(adapter.delta() - deltas[index])
            / max(np.linalg.norm(deltas[index]), np.finfo(np.float64).tiny)
        )
        if relative_error > 1e-8:
            raise ValueError(f"{seed_dir}: update reconstruction error {relative_error:.3e}")
        adapters.append(adapter)
    return clients, np.asarray(base_weight, dtype=np.float64), adapters, config_path


def _metric_rows(setting: str, seed: int, clients: list, distances: np.ndarray, normal: np.ndarray) -> pd.DataFrame:
    rows = []
    for receiver_index, receiver in enumerate(clients):
        for donor_index, donor in enumerate(clients):
            if receiver_index == donor_index:
                continue
            rows.append(
                {
                    "setting": setting,
                    "seed": seed,
                    "client_i": receiver.client_id,
                    "domain_i": receiver.domain,
                    "client_j": donor.client_id,
                    "domain_j": donor.domain,
                    "d_risk_sub": float(distances[receiver_index, donor_index]),
                    "risk_normal_energy_ratio": float(normal[receiver_index, donor_index]),
                }
            )
    return pd.DataFrame(rows)


def _standardize_from_train(train: pd.DataFrame, test: pd.DataFrame, columns: list[str]):
    mean = train[columns].mean(axis=0)
    scale = train[columns].std(axis=0, ddof=0).replace(0.0, 1.0)
    return (train[columns] - mean) / scale, (test[columns] - mean) / scale


def _leave_one_seed_predictions(frame: pd.DataFrame, predictors: tuple[str, ...]) -> np.ndarray:
    prediction = np.full(len(frame), np.nan, dtype=np.float64)
    for setting in sorted(frame["setting"].unique()):
        setting_frame = frame.loc[frame["setting"].eq(setting)]
        for seed in sorted(setting_frame["seed"].unique()):
            test_mask = frame["setting"].eq(setting) & frame["seed"].eq(seed)
            train_mask = frame["setting"].eq(setting) & ~frame["seed"].eq(seed)
            train = frame.loc[train_mask]
            test = frame.loc[test_mask]
            train_x, test_x = _standardize_from_train(train, test, list(predictors))
            target_mean = float(train[TARGET].mean())
            target_scale = float(train[TARGET].std(ddof=0)) or 1.0
            train_y = (train[TARGET].to_numpy(float) - target_mean) / target_scale
            design_train = np.column_stack([np.ones(len(train_x)), train_x.to_numpy(float)])
            coefficient = np.linalg.lstsq(design_train, train_y, rcond=None)[0]
            design_test = np.column_stack([np.ones(len(test_x)), test_x.to_numpy(float)])
            prediction[test_mask.to_numpy()] = target_mean + target_scale * (design_test @ coefficient)
    if not np.all(np.isfinite(prediction)):
        raise RuntimeError("Leave-one-seed predictions are incomplete")
    return prediction


def _equal_setting_mse(frame: pd.DataFrame, prediction: np.ndarray) -> float:
    work = frame[["setting", TARGET]].copy()
    work["squared_error"] = (work[TARGET].to_numpy(float) - prediction) ** 2
    return float(work.groupby("setting")["squared_error"].mean().mean())


def _controlled_normal_coefficient(frame: pd.DataFrame) -> float:
    coefficients = []
    predictors = [*BASE_CONTROLS, *NEW_PREDICTORS]
    for _, setting_frame in frame.groupby("setting"):
        standardized = setting_frame[[*predictors, TARGET]].copy()
        standardized = (standardized - standardized.mean()) / standardized.std(ddof=0).replace(0.0, 1.0)
        design = np.column_stack([np.ones(len(standardized)), standardized[predictors].to_numpy(float)])
        beta = np.linalg.lstsq(design, standardized[TARGET].to_numpy(float), rcond=None)[0]
        coefficients.append(float(beta[predictors.index("risk_normal_energy_ratio") + 1]))
    return float(np.mean(coefficients))


def _cluster_bootstrap(frame: pd.DataFrame, repeats: int, rng: np.random.Generator) -> np.ndarray:
    grouped = {
        setting: [group.copy() for _, group in setting_frame.groupby("seed")]
        for setting, setting_frame in frame.groupby("setting")
    }
    draws = np.empty(repeats, dtype=np.float64)
    for repeat in range(repeats):
        sampled_settings = []
        for setting, seeds in grouped.items():
            indices = rng.integers(0, len(seeds), size=len(seeds))
            sampled = []
            for new_seed, index in enumerate(indices):
                block = seeds[int(index)].copy()
                block["seed"] = new_seed
                sampled.append(block)
            sampled_settings.append(pd.concat(sampled, ignore_index=True))
        draws[repeat] = _controlled_normal_coefficient(pd.concat(sampled_settings, ignore_index=True))
    return draws


def _permutation_gains(frame: pd.DataFrame, repeats: int, rng: np.random.Generator, base_mse: float) -> np.ndarray:
    gains = np.empty(repeats, dtype=np.float64)
    for repeat in range(repeats):
        permuted = frame.copy()
        for _, indices in permuted.groupby(["setting", "seed", "client_i"]).groups.items():
            index = np.asarray(list(indices), dtype=np.int64)
            order = rng.permutation(index)
            permuted.loc[index, list(NEW_PREDICTORS)] = frame.loc[order, list(NEW_PREDICTORS)].to_numpy()
        prediction = _leave_one_seed_predictions(permuted, (*BASE_CONTROLS, *NEW_PREDICTORS))
        gains[repeat] = base_mse - _equal_setting_mse(permuted, prediction)
    return gains


def main() -> int:
    args = parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)
    metric_frames = []
    evidence_hashes = []
    for setting, folder in SETTINGS.items():
        cached_base_weight = None
        for seed in SEEDS:
            seed_dir = args.source_root / folder / f"seed_{seed}"
            clients, base_weight, adapters, config_path = _load_frozen_bundle(seed_dir, cached_base_weight)
            if cached_base_weight is None:
                cached_base_weight = base_weight.copy()
            distance, normal = directed_receiver_risk_subspace_distance_matrix(clients, base_weight, adapters)
            metric_frames.append(_metric_rows(setting, seed, clients, distance, normal))
            for path in (config_path, seed_dir / "local_anchor_deltas.npy", seed_dir / "adapter_conflict.csv"):
                evidence_hashes.append({"path": str(path.resolve()), "sha256": _sha256(path)})

    metrics = pd.concat(metric_frames, ignore_index=True)
    metrics.to_csv(args.output_root / "training_only_risk_subspace_metrics.csv", index=False)
    conflict_frames = []
    for setting, folder in SETTINGS.items():
        for seed in SEEDS:
            frame = pd.read_csv(args.source_root / folder / f"seed_{seed}" / "adapter_conflict.csv")
            frame["setting"] = setting
            frame["seed"] = seed
            conflict_frames.append(frame)
    conflict = pd.concat(conflict_frames, ignore_index=True)
    merged = conflict.merge(
        metrics,
        on=["setting", "seed", "client_i", "domain_i", "client_j", "domain_j"],
        how="inner",
        validate="one_to_one",
    )
    required = [*BASE_CONTROLS, *NEW_PREDICTORS, TARGET]
    if len(merged) != len(conflict) or not np.all(np.isfinite(merged[required].to_numpy(float))):
        raise RuntimeError("Frozen conflict rows and training-only risk metrics did not align")
    merged.to_csv(args.output_root / "risk_subspace_directional_pairs.csv", index=False)

    base_prediction = _leave_one_seed_predictions(merged, BASE_CONTROLS)
    extended_prediction = _leave_one_seed_predictions(merged, (*BASE_CONTROLS, *NEW_PREDICTORS))
    base_mse = _equal_setting_mse(merged, base_prediction)
    extended_mse = _equal_setting_mse(merged, extended_prediction)
    mse_gain = base_mse - extended_mse
    setting_rows = []
    for setting, setting_frame in merged.groupby("setting"):
        index = setting_frame.index.to_numpy()
        setting_base = float(np.mean((setting_frame[TARGET].to_numpy(float) - base_prediction[index]) ** 2))
        setting_extended = float(np.mean((setting_frame[TARGET].to_numpy(float) - extended_prediction[index]) ** 2))
        setting_rows.append(
            {
                "setting": setting,
                "rows": len(setting_frame),
                "base_loso_mse": setting_base,
                "extended_loso_mse": setting_extended,
                "mse_reduction": setting_base - setting_extended,
                "extended_improves": bool(setting_extended < setting_base),
            }
        )
    setting_table = pd.DataFrame(setting_rows)
    setting_table.to_csv(args.output_root / "setting_level_replay.csv", index=False)

    rng = np.random.default_rng(ANALYSIS_SEED)
    coefficient = _controlled_normal_coefficient(merged)
    bootstrap = _cluster_bootstrap(merged, args.bootstrap, rng)
    coefficient_low, coefficient_high = np.quantile(bootstrap, [0.025, 0.975])
    permutation = _permutation_gains(merged, args.permutations, rng, base_mse)
    permutation_p = float((1 + np.sum(permutation >= mse_gain)) / (len(permutation) + 1))
    majority_settings = bool(setting_table["extended_improves"].mean() > 0.5)
    stage_a_passed = bool(
        coefficient_low > 0.0
        and mse_gain > 0.0
        and majority_settings
        and permutation_p <= 0.05
    )
    summary = {
        "stage": "A_frozen_diagnostic_replay",
        "settings": len(setting_table),
        "seeds_per_setting": len(SEEDS),
        "directional_pairs": len(merged),
        "base_controls": list(BASE_CONTROLS),
        "new_predictors": list(NEW_PREDICTORS),
        "controlled_risk_normal_beta": coefficient,
        "seed_cluster_ci_low": float(coefficient_low),
        "seed_cluster_ci_high": float(coefficient_high),
        "base_loso_mse": base_mse,
        "extended_loso_mse": extended_mse,
        "mse_reduction": mse_gain,
        "settings_improved": int(setting_table["extended_improves"].sum()),
        "majority_settings_improved": majority_settings,
        "donor_permutation_p": permutation_p,
        "stage_a_passed": stage_a_passed,
        "next_action": "authorize_stage_B_development" if stage_a_passed else "stop_extension_keep_current_manuscript",
    }
    (args.output_root / "stage_a_decision.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    (args.output_root / "evidence_hashes.json").write_text(json.dumps(evidence_hashes, indent=2), encoding="utf-8")
    report = [
        "# Receiver-risk subspace Stage-A replay",
        "",
        "All new predictors were computed from frozen local updates and receiver training features before being joined to the existing exact-update failure endpoint.",
        "",
        f"- Controlled risk-normal coefficient: {coefficient:+.4f}, seed-clustered 95% CI [{coefficient_low:+.4f}, {coefficient_high:+.4f}].",
        f"- Leave-one-seed-out MSE: controls {base_mse:.6f}, controls+risk geometry {extended_mse:.6f}, reduction {mse_gain:+.6f}.",
        f"- Settings improved: {int(setting_table['extended_improves'].sum())}/{len(setting_table)}.",
        f"- Donor-identity permutation p-value for the MSE reduction: {permutation_p:.6f}.",
        f"- Pre-registered Stage-A gate: **{'PASSED' if stage_a_passed else 'NOT MET'}**.",
        f"- Decision: `{summary['next_action']}`.",
        "",
        "A failed gate is a negative extension result and does not alter the frozen Pattern Recognition manuscript.",
    ]
    (args.output_root / "stage_a_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

