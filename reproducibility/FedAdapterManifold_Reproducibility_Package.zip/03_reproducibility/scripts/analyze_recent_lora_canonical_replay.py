from __future__ import annotations

import argparse
import csv
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = ROOT / "results" / "recent_lora_fairness_20260804"
DEFAULT_OUTPUT = ROOT / "results" / "recent_lora_canonical_replay_20260812"
SETTINGS = {
    "PACS-R18": "pacs_resnet18",
    "OfficeHome-CLIP": "officehome_clip_full",
    "DomainNetMini-CLIP": "domainnetmini_clip_60class",
}
LOCAL = "Local-LoRA"
GEO = "FedGeo-Agg"
SUBSPACE = "Subspace-Compatible"
FAM = "FedAdapterManifold"
FEDAVG = "FedAvg-LoRA"
SELECTOR = "FedAdapterManifold-Selective"
ANCHORS = [LOCAL, GEO]
MANIFOLD = [SUBSPACE, FAM]
CANDIDATES = ANCHORS + MANIFOLD
TOL = 1e-12


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write an empty table: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def choose(methods: list[str], scores: dict[str, float]) -> str:
    return min(methods, key=lambda method: (scores[method], methods.index(method)))


def outcome(delta: float) -> str:
    if delta > TOL:
        return "beneficial"
    if delta < -TOL:
        return "harmful"
    return "neutral"


def collect(input_root: Path) -> list[dict[str, object]]:
    units: list[dict[str, object]] = []
    for setting, directory in SETTINGS.items():
        setting_root = input_root / directory
        seed_dirs = sorted(setting_root.glob("seed_*"))
        if [path.name for path in seed_dirs] != [f"seed_{i}" for i in range(5)]:
            raise ValueError(f"{setting}: expected seeds 0--4, found {[p.name for p in seed_dirs]}")

        for seed_dir in seed_dirs:
            seed = int(seed_dir.name.rsplit("_", 1)[1])
            metrics = read_csv(seed_dir / "per_client_metrics.csv")
            selections = read_csv(seed_dir / "adapter_candidate_selection.csv")

            metric_lookup: dict[tuple[str, str], dict[str, float]] = {}
            for row in metrics:
                method = row["method"]
                if method in CANDIDATES + [FEDAVG]:
                    metric_lookup[(row["client_id"], method)] = {
                        "accuracy": float(row["accuracy"]),
                        "loss": float(row["loss"]),
                    }

            selection_lookup: dict[str, dict[str, dict[str, str]]] = defaultdict(dict)
            for row in selections:
                if row.get("method") == SELECTOR and row.get("candidate_method") in CANDIDATES:
                    selection_lookup[row["client_id"]][row["candidate_method"]] = row

            if not selection_lookup:
                raise ValueError(f"{setting} seed {seed}: no {SELECTOR} rows")

            for client_id, candidate_rows in sorted(selection_lookup.items()):
                missing_candidates = [method for method in CANDIDATES if method not in candidate_rows]
                missing_metrics = [
                    method
                    for method in CANDIDATES + [FEDAVG]
                    if (client_id, method) not in metric_lookup
                ]
                if missing_candidates or missing_metrics:
                    raise ValueError(
                        f"{setting} seed {seed} {client_id}: missing candidates={missing_candidates}, "
                        f"metrics={missing_metrics}"
                    )

                scores = {
                    method: float(candidate_rows[method]["candidate_selector_score"])
                    for method in CANDIDATES
                }
                accuracies = {
                    method: metric_lookup[(client_id, method)]["accuracy"]
                    for method in CANDIDATES
                }
                losses = {
                    method: metric_lookup[(client_id, method)]["loss"]
                    for method in CANDIDATES
                }
                anchor = choose(ANCHORS, scores)
                manifold = choose(MANIFOLD, scores)
                selected = choose(CANDIDATES, scores)
                better_test_anchor = max(accuracies[LOCAL], accuracies[GEO])
                proposal_delta = accuracies[manifold] - better_test_anchor
                selected_delta = accuracies[selected] - better_test_anchor

                units.append(
                    {
                        "setting": setting,
                        "seed": seed,
                        "client_id": client_id,
                        "anchor": anchor,
                        "manifold_proposal": manifold,
                        "selected_method": selected,
                        "manifold_accepted": int(selected in MANIFOLD),
                        "proposal_outcome": outcome(proposal_delta),
                        "selected_outcome": outcome(selected_delta),
                        "proposal_delta_vs_better_test_anchor": proposal_delta,
                        "selected_delta_vs_better_test_anchor": selected_delta,
                        "canonical_accuracy": accuracies[selected],
                        "canonical_loss": losses[selected],
                        "fedavg_accuracy": metric_lookup[(client_id, FEDAVG)]["accuracy"],
                        "local_accuracy": accuracies[LOCAL],
                        "geo_accuracy": accuracies[GEO],
                        "subspace_accuracy": accuracies[SUBSPACE],
                        "fam_bank_accuracy": accuracies[FAM],
                        **{f"score_{method}": scores[method] for method in CANDIDATES},
                    }
                )
    return units


def summarize_seed(units: list[dict[str, object]]) -> list[dict[str, object]]:
    grouped: dict[tuple[str, int], list[dict[str, object]]] = defaultdict(list)
    for row in units:
        grouped[(str(row["setting"]), int(row["seed"]))].append(row)

    rows: list[dict[str, object]] = []
    for (setting, seed), group in sorted(grouped.items()):
        rows.append(
            {
                "setting": setting,
                "seed": seed,
                "client_units": len(group),
                "canonical_accuracy": np.mean([float(row["canonical_accuracy"]) for row in group]),
                "canonical_worst_client_accuracy": min(
                    float(row["canonical_accuracy"]) for row in group
                ),
                "fedavg_accuracy": np.mean([float(row["fedavg_accuracy"]) for row in group]),
                "geo_accuracy": np.mean([float(row["geo_accuracy"]) for row in group]),
                "geo_worst_client_accuracy": min(float(row["geo_accuracy"]) for row in group),
                "manifold_coverage": np.mean([int(row["manifold_accepted"]) for row in group]),
                "beneficial_admitted": sum(
                    int(row["manifold_accepted"]) and row["proposal_outcome"] == "beneficial"
                    for row in group
                ),
                "harmful_admitted": sum(
                    int(row["manifold_accepted"]) and row["proposal_outcome"] == "harmful"
                    for row in group
                ),
            }
        )
    return rows


def summarize_setting(
    units: list[dict[str, object]], seed_rows: list[dict[str, object]]
) -> list[dict[str, object]]:
    unit_groups: dict[str, list[dict[str, object]]] = defaultdict(list)
    seed_groups: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in units:
        unit_groups[str(row["setting"])].append(row)
    for row in seed_rows:
        seed_groups[str(row["setting"])].append(row)

    rows: list[dict[str, object]] = []
    for setting in SETTINGS:
        group = unit_groups[setting]
        seeds = seed_groups[setting]
        counts = Counter(str(row["selected_method"]) for row in group)
        canonical = np.array([float(row["canonical_accuracy"]) for row in seeds])
        fedavg = np.array([float(row["fedavg_accuracy"]) for row in seeds])
        geo = np.array([float(row["geo_accuracy"]) for row in seeds])
        worst_delta = np.array(
            [
                float(row["canonical_worst_client_accuracy"])
                - float(row["geo_worst_client_accuracy"])
                for row in seeds
            ]
        )
        proposals = [row for row in group if row["proposal_outcome"] != "neutral"]
        admitted = [row for row in group if int(row["manifold_accepted"])]
        rows.append(
            {
                "setting": setting,
                "seeds": len(seeds),
                "client_seed_units": len(group),
                "canonical_accuracy_mean": canonical.mean(),
                "canonical_accuracy_sd": canonical.std(ddof=1),
                "delta_vs_fedavg": (canonical - fedavg).mean(),
                "delta_vs_geo": (canonical - geo).mean(),
                "worst_client_delta_vs_geo": worst_delta.mean(),
                "manifold_coverage": len(admitted) / len(group),
                "beneficial_admitted": sum(
                    row["proposal_outcome"] == "beneficial" for row in admitted
                ),
                "beneficial_total": sum(
                    row["proposal_outcome"] == "beneficial" for row in proposals
                ),
                "harmful_admitted": sum(row["proposal_outcome"] == "harmful" for row in admitted),
                "harmful_total": sum(row["proposal_outcome"] == "harmful" for row in proposals),
                "selected_method_counts": ";".join(
                    f"{method}:{count}" for method, count in sorted(counts.items())
                ),
            }
        )
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-root", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()

    units = collect(args.input_root)
    if len(units) != 70:
        raise ValueError(f"Expected 70 client-seed units, found {len(units)}")
    seed_rows = summarize_seed(units)
    setting_rows = summarize_setting(units, seed_rows)

    args.output_root.mkdir(parents=True, exist_ok=True)
    write_csv(args.output_root / "canonical_replay_units.csv", units)
    write_csv(args.output_root / "canonical_replay_seed_summary.csv", seed_rows)
    write_csv(args.output_root / "canonical_replay_setting_summary.csv", setting_rows)
    print(f"Wrote {len(units)} units, {len(seed_rows)} seed rows, and {len(setting_rows)} settings")


if __name__ == "__main__":
    main()
