from __future__ import annotations

import argparse
import csv
import itertools
from pathlib import Path

import numpy as np


PRIMARY_METHODS = (
    "FedAdapterManifold-Admit-AnchoredAction",
    "FedAdapterManifold-Admit-InternalBank",
    "FedAdapterManifold-Admit-Power",
    "FedAdapterManifold-SignedTangentAdmit",
    "FedAdapterManifold-DirectAnchorRoute",
    "FedAdapterManifold-DisagreementRoute",
    "FedAdapterManifold-CumulativeCompetitiveAdmit",
    "FedAdapterManifold-CumulativeAdmit",
    "FedAdapterManifold-CumulativeBlockwiseAdmit",
    "FedAdapterManifold-CumulativeBlockwiseJointAdmit",
    "FedAdapterManifold-CumulativeScreenedAdmit",
    "FedAdapterManifold-CumulativeAdmit-RankMatched",
    "FedAdapterManifold-DecoupledAdmit",
    "FedAdapterManifold-DualTransport",
    "FedAdapterManifold-Admit",
    "FedAdapterManifold-PathAdmit",
    "FedAdapterManifold",
    "FedAdapterManifold-Selective",
    "FedAdapterManifold-StrongSelective",
)
BASELINES = (
    "FedAdapterManifold-DisagreementRoute",
    "CumulativeFull-CompetitiveBudget-Control",
    "CumulativeFull-Gate-Control",
    "CumulativeFull-ScreenedBudget-Control",
    "CumulativeSelectedSource-Scalar-Control",
    "CumulativeFull-BlockwiseBudget-Control",
    "FedAvg-LoRA",
    "FedAvg-Lift",
    "FedEx-LoRA",
    "FedSA-LoRA",
    "FedRot-LoRA",
    "FedSmoothLoRA",
    "FedSmoothLoRA-RankMatched",
    "LoRA-FAIR",
    "Te-LoRA-Eq6-Audit",
    "FedLEASE-OfficialPort",
    "FedALT-OfficialVisualPort",
    "FedTreeLoRA-Visual-Port",
    "Subspace-Reg-LoRA-Visual-Port",
    "Dysco-FrozenFeature-Visual-Port",
    "HiLoRA-Visual",
    "Local-LoRA",
    "FedProx-LoRA",
    "FedProto-LoRA",
    "FedPer-LoRA",
    "Ditto-LoRA",
    "Clustered-LoRA",
    "FedAMP-LoRA",
    "Subspace-Compatible",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Analyze fixed-rank recent federated-LoRA comparisons.")
    parser.add_argument("--result-root", default="results/recent_lora_fairness_20260804")
    parser.add_argument("--bootstrap-replicates", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260804)
    parser.add_argument(
        "--extra-per-client",
        action="append",
        default=[],
        help="Additional result in DATASET_KEY=path/to/per_client_metrics.csv form.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.result_root)
    rows = load_all_per_client_rows(root)
    rows.extend(load_extra_per_client_rows(args.extra_per_client))
    rows = deduplicate_rows(rows)
    if not rows:
        raise FileNotFoundError(f"No completed per-client runs under {root}")
    output_dir = root / "fairness_statistics"
    output_dir.mkdir(parents=True, exist_ok=True)
    method_rows = method_summaries(rows)
    comparison_rows, seed_rows = paired_comparisons(
        rows,
        replicates=int(args.bootstrap_replicates),
        seed=int(args.seed),
    )
    write_csv(output_dir / "method_summary.csv", method_rows)
    write_csv(output_dir / "paired_method_comparisons.csv", comparison_rows)
    write_csv(output_dir / "paired_seed_effects.csv", seed_rows)
    write_report(output_dir / "recent_lora_fairness_report.md", method_rows, comparison_rows)
    return 0


def load_all_per_client_rows(root: Path) -> list[dict]:
    rows: list[dict] = []
    for path in sorted(root.glob("*/seed_*/per_client_metrics.csv")):
        dataset_key = path.parents[1].name
        seed = int(path.parent.name.split("_")[-1])
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            current = list(csv.DictReader(handle))
        for row in current:
            row["fairness_dataset_key"] = dataset_key
            row["seed"] = seed
            row["accuracy"] = float(row["accuracy"])
            row["loss"] = float(row["loss"])
        rows.extend(current)
    return rows


def deduplicate_rows(rows: list[dict]) -> list[dict]:
    """Remove exact repeated client-seed records and reject conflicting ones."""

    unique: dict[tuple[str, int, str, str], dict] = {}
    for row in rows:
        key = (
            str(row["fairness_dataset_key"]),
            int(row["seed"]),
            str(row["method"]),
            str(row["client_id"]),
        )
        previous = unique.get(key)
        if previous is None:
            unique[key] = row
            continue
        same_result = np.isclose(float(previous["accuracy"]), float(row["accuracy"]), atol=1e-12, rtol=0.0)
        same_result &= np.isclose(float(previous["loss"]), float(row["loss"]), atol=1e-12, rtol=0.0)
        if not same_result:
            raise ValueError(
                "Conflicting per-client records for "
                f"dataset={key[0]}, seed={key[1]}, method={key[2]}, client={key[3]}"
            )
    return list(unique.values())


def load_extra_per_client_rows(specifications: list[str]) -> list[dict]:
    rows: list[dict] = []
    for specification in specifications:
        if "=" not in specification:
            raise ValueError(f"Expected DATASET_KEY=CSV_PATH, got {specification!r}")
        dataset_key, path_text = specification.split("=", 1)
        path = Path(path_text)
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            current = list(csv.DictReader(handle))
        for row in current:
            row["fairness_dataset_key"] = dataset_key
            row["seed"] = int(row["seed"])
            row["accuracy"] = float(row["accuracy"])
            row["loss"] = float(row["loss"])
        rows.extend(current)
    return rows


def method_summaries(rows: list[dict]) -> list[dict]:
    grouped: dict[tuple[str, str], list[dict]] = {}
    for row in rows:
        grouped.setdefault((str(row["fairness_dataset_key"]), str(row["method"])), []).append(row)
    output: list[dict] = []
    for (dataset, method), group in sorted(grouped.items()):
        seed_groups = _group(group, "seed")
        seed_means = [float(np.mean([float(row["accuracy"]) for row in seed_rows])) for seed_rows in seed_groups.values()]
        seed_worst = [float(np.min([float(row["accuracy"]) for row in seed_rows])) for seed_rows in seed_groups.values()]
        output.append(
            {
                "dataset": dataset,
                "method": method,
                "seed_count": len(seed_groups),
                "client_seed_count": len(group),
                "mean_accuracy": float(np.mean(seed_means)),
                "seed_sd_accuracy": float(np.std(seed_means, ddof=1)) if len(seed_means) > 1 else 0.0,
                "mean_worst_client_accuracy": float(np.mean(seed_worst)),
                "mean_client_loss": float(np.mean([float(row["loss"]) for row in group])),
            }
        )
    return output


def paired_comparisons(rows: list[dict], replicates: int, seed: int) -> tuple[list[dict], list[dict]]:
    rng = np.random.default_rng(seed)
    datasets = sorted({str(row["fairness_dataset_key"]) for row in rows})
    comparison_rows: list[dict] = []
    seed_rows: list[dict] = []
    for dataset in datasets:
        dataset_rows = [row for row in rows if str(row["fairness_dataset_key"]) == dataset]
        available = {str(row["method"]) for row in dataset_rows}
        for method in PRIMARY_METHODS:
            if method not in available:
                continue
            for baseline in BASELINES:
                if method == baseline:
                    continue
                if baseline not in available:
                    continue
                pairs = _paired_rows(dataset_rows, method, baseline)
                if not pairs:
                    continue
                seed_effects = _seed_effects(pairs)
                for entry in seed_effects:
                    entry["dataset"] = dataset
                accuracy_gains = np.asarray([pair["accuracy_gain"] for pair in pairs], dtype=np.float64)
                loss_reductions = np.asarray([pair["loss_reduction"] for pair in pairs], dtype=np.float64)
                acc_boot = _hierarchical_bootstrap(pairs, "accuracy_gain", replicates, rng)
                loss_boot = _hierarchical_bootstrap(pairs, "loss_reduction", replicates, rng)
                worst_gains = np.asarray([entry["worst_client_accuracy_gain"] for entry in seed_effects], dtype=np.float64)
                comparison_rows.append(
                    {
                        "dataset": dataset,
                        "method": method,
                        "baseline": baseline,
                        "seed_count": len(seed_effects),
                        "client_seed_count": len(pairs),
                        "mean_accuracy_gain": float(np.mean(accuracy_gains)),
                        "accuracy_gain_ci95_low": _quantile(acc_boot, 0.025),
                        "accuracy_gain_ci95_high": _quantile(acc_boot, 0.975),
                        "mean_loss_reduction": float(np.mean(loss_reductions)),
                        "loss_reduction_ci95_low": _quantile(loss_boot, 0.025),
                        "loss_reduction_ci95_high": _quantile(loss_boot, 0.975),
                        "mean_worst_client_accuracy_gain": float(np.mean(worst_gains)),
                        "seed_sign_flip_p_one_sided": exact_sign_flip_p(
                            [entry["mean_accuracy_gain"] for entry in seed_effects]
                        ),
                        "positive_seed_count": int(
                            np.sum(np.asarray([entry["mean_accuracy_gain"] for entry in seed_effects]) > 0.0)
                        ),
                        "supports_accuracy_gain": bool(_quantile(acc_boot, 0.025) > 0.0),
                    }
                )
                seed_rows.extend(seed_effects)
    return comparison_rows, seed_rows


def _paired_rows(rows: list[dict], method: str, baseline: str) -> list[dict]:
    method_map = {
        (int(row["seed"]), str(row["client_id"])): row for row in rows if str(row["method"]) == method
    }
    baseline_map = {
        (int(row["seed"]), str(row["client_id"])): row for row in rows if str(row["method"]) == baseline
    }
    if set(method_map) != set(baseline_map):
        missing_method = sorted(set(baseline_map) - set(method_map))
        missing_baseline = sorted(set(method_map) - set(baseline_map))
        raise ValueError(
            f"Unfair comparison {method} vs {baseline}: missing method keys={missing_method}, "
            f"missing baseline keys={missing_baseline}"
        )
    output = []
    for key in sorted(method_map):
        method_row = method_map[key]
        baseline_row = baseline_map[key]
        output.append(
            {
                "seed": key[0],
                "client_id": key[1],
                "method": method,
                "baseline": baseline,
                "method_accuracy": float(method_row["accuracy"]),
                "baseline_accuracy": float(baseline_row["accuracy"]),
                "accuracy_gain": float(method_row["accuracy"]) - float(baseline_row["accuracy"]),
                "loss_reduction": float(baseline_row["loss"]) - float(method_row["loss"]),
            }
        )
    return output


def _seed_effects(pairs: list[dict]) -> list[dict]:
    output: list[dict] = []
    for seed, seed_pairs in sorted(_group(pairs, "seed").items()):
        gains = np.asarray([float(row["accuracy_gain"]) for row in seed_pairs], dtype=np.float64)
        output.append(
            {
                "dataset": "",
                "method": seed_pairs[0]["method"],
                "baseline": seed_pairs[0]["baseline"],
                "seed": int(seed),
                "mean_accuracy_gain": float(np.mean(gains)),
                "worst_client_accuracy_gain": float(
                    np.min([float(row["method_accuracy"]) for row in seed_pairs])
                    - np.min([float(row["baseline_accuracy"]) for row in seed_pairs])
                ),
                "mean_loss_reduction": float(np.mean([float(row["loss_reduction"]) for row in seed_pairs])),
                "client_count": len(seed_pairs),
            }
        )
    return output


def _hierarchical_bootstrap(
    pairs: list[dict],
    field: str,
    replicates: int,
    rng: np.random.Generator,
) -> np.ndarray:
    grouped = _group(pairs, "seed")
    seeds = sorted(grouped)
    draws = np.empty(max(1, replicates), dtype=np.float64)
    for replicate in range(draws.size):
        sampled_values: list[float] = []
        for sampled_seed in rng.choice(seeds, size=len(seeds), replace=True):
            seed_rows = grouped[int(sampled_seed)]
            indices = rng.integers(0, len(seed_rows), size=len(seed_rows))
            sampled_values.extend(float(seed_rows[index][field]) for index in indices)
        draws[replicate] = float(np.mean(sampled_values))
    return draws


def exact_sign_flip_p(values: list[float]) -> float:
    observed = float(np.mean(values))
    magnitudes = np.abs(np.asarray(values, dtype=np.float64))
    null = [float(np.mean(np.asarray(signs) * magnitudes)) for signs in itertools.product([-1.0, 1.0], repeat=len(values))]
    return float(np.mean(np.asarray(null) >= observed - 1e-15))


def _group(rows: list[dict], field: str) -> dict:
    grouped: dict = {}
    for row in rows:
        grouped.setdefault(row[field], []).append(row)
    return grouped


def _quantile(values: np.ndarray, q: float) -> float:
    return float(np.quantile(values, q)) if values.size else float("nan")


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def write_report(path: Path, methods: list[dict], comparisons: list[dict]) -> None:
    lines = [
        "# Recent Federated-LoRA Fairness Report",
        "",
        "All comparisons use matched seed-client units, identical data splits, fixed ranks, and the same local budget.",
        "",
        "## Primary comparisons",
        "",
        "| Dataset | Method | Baseline | Accuracy gain | 95% hierarchical CI | Worst-client gain |",
        "|---|---|---|---:|---:|---:|",
    ]
    for row in comparisons:
        if row["method"] not in {
            "FedAdapterManifold-SignedTangentAdmit",
            "FedAdapterManifold-DirectAnchorRoute",
            "FedAdapterManifold-CumulativeAdmit",
            "FedAdapterManifold-CumulativeBlockwiseAdmit",
            "FedAdapterManifold-CumulativeBlockwiseJointAdmit",
            "FedAdapterManifold-CumulativeScreenedAdmit",
            "FedAdapterManifold-CumulativeAdmit-RankMatched",
            "FedAdapterManifold-DecoupledAdmit",
            "FedAdapterManifold-DualTransport",
            "FedAdapterManifold-Admit",
            "FedAdapterManifold-PathAdmit",
            "FedAdapterManifold-StrongSelective",
        }:
            continue
        lines.append(
            f"| {row['dataset']} | {row['method']} | {row['baseline']} | "
            f"{float(row['mean_accuracy_gain']):.4f} | "
            f"[{float(row['accuracy_gain_ci95_low']):.4f}, {float(row['accuracy_gain_ci95_high']):.4f}] | "
            f"{float(row['mean_worst_client_accuracy_gain']):.4f} |"
        )
    lines.extend(["", "## Method means", "", "| Dataset | Method | Accuracy | Worst-client accuracy |", "|---|---|---:|---:|"])
    for row in methods:
        if row["method"] not in set(PRIMARY_METHODS) | set(BASELINES):
            continue
        lines.append(
            f"| {row['dataset']} | {row['method']} | {float(row['mean_accuracy']):.4f} | "
            f"{float(row['mean_worst_client_accuracy']):.4f} |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
