from __future__ import annotations

import argparse
import csv
import glob
import sys
from pathlib import Path

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fedadaptermanifold.baselines import run_local_lora
from fedadaptermanifold.config import merge_defaults
from fedadaptermanifold.diagnostics import run_subspace_failure_diagnostic
from fedadaptermanifold.geometry import FedGeoFileGeometryProvider, LocalPrototypeGeometry, label_distance_matrix
from fedadaptermanifold.reporting import pearsonr, write_csv
from fedadaptermanifold.run_experiment import (
    _load_clients,
    _split_clients_for_candidate_selection,
    build_arg_parser,
)


METRICS = (
    "d_sub",
    "d_update",
    "d_action",
    "d_local_risk",
    "d_projection",
    "d_geo",
)
TARGET = "semantic_exact_loss_failure"
MODELS = {
    "subspace_only": ("d_sub",),
    "geo_only": ("d_geo",),
    "local_risk_only": ("d_local_risk",),
    "subspace_plus_geo": ("d_sub", "d_geo"),
    "subspace_geo_local_risk": ("d_sub", "d_geo", "d_local_risk"),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Recompute the algebraically decoupled adapter-conflict diagnostic across seeds."
    )
    parser.add_argument("--config-glob", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--bootstrap-replicates", type=int, default=5000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260804)
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config_paths = sorted(Path(path) for path in glob.glob(args.config_glob))
    if not config_paths:
        raise FileNotFoundError(f"No configs matched {args.config_glob!r}")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    all_rows: list[dict] = []
    per_seed_rows: list[dict] = []
    for config_path in config_paths:
        defaults = merge_defaults(str(config_path))
        run_args = build_arg_parser(defaults).parse_args(["--config", str(config_path)])
        seed_output = output_dir / f"seed_{run_args.seed}_adapter_conflict.csv"
        if seed_output.exists() and not args.force:
            rows = _read_csv(seed_output)
        else:
            rows = _run_one_seed(run_args)
            write_csv(seed_output, rows)
        for row in rows:
            row["seed"] = int(run_args.seed)
            row["config_path"] = str(config_path)
        all_rows.extend(rows)
        per_seed_rows.extend(_per_seed_summary(rows, int(run_args.seed)))

    write_csv(output_dir / "semantic_conflict_pairs.csv", all_rows)
    write_csv(output_dir / "semantic_conflict_per_seed.csv", per_seed_rows)
    clustered_rows = clustered_statistics(
        all_rows,
        replicates=args.bootstrap_replicates,
        seed=args.bootstrap_seed,
    )
    write_csv(output_dir / "clustered_semantic_conflict_statistics.csv", clustered_rows)
    model_rows = clustered_model_statistics(
        all_rows,
        replicates=args.bootstrap_replicates,
        seed=args.bootstrap_seed + 1,
    )
    write_csv(output_dir / "clustered_semantic_complementarity.csv", model_rows)
    _write_markdown_report(output_dir / "semantic_conflict_report.md", clustered_rows, per_seed_rows, model_rows)
    return 0


def _run_one_seed(args: argparse.Namespace) -> list[dict]:
    clients, base_weight, _ = _load_clients(args)
    clients, _, _ = _split_clients_for_candidate_selection(
        clients,
        fraction=args.candidate_selector_calibration_fraction,
        strategy=args.candidate_selector_calibration_strategy,
        seed=args.seed,
    )
    geometry_dir = args.geometry_outputs_dir or args.fedgeo_dir
    provider = FedGeoFileGeometryProvider(geometry_dir) if geometry_dir else LocalPrototypeGeometry()
    geometry = provider.build(clients, num_classes=int(base_weight.shape[0]), round_id=int(args.round_id))
    if args.rank_policy != "fixed":
        raise ValueError("This confirmatory diagnostic requires a pre-registered fixed rank")
    ranks = [int(args.rank) for _ in clients]
    local = run_local_lora(
        clients,
        base_weight,
        ranks=ranks,
        epochs=int(args.rounds) * int(args.local_epochs),
        lr=float(args.lr),
        batch_size=int(args.batch_size),
        seed=int(args.seed),
        dataset=str(args.dataset),
        heterogeneity_setting=str(args.heterogeneity_setting),
        round_id=int(args.rounds),
    )
    diagnostic = run_subspace_failure_diagnostic(
        clients,
        base_weight,
        local.adapters,
        d_geo=geometry.d_geo,
        d_label=label_distance_matrix(clients, int(base_weight.shape[0])),
        lambda_geo=float(args.lambda_geo),
        lambda_label=float(args.lambda_label),
        tau=float(args.tau),
        diagnostic_threshold=float(args.diagnostic_threshold),
    )
    return diagnostic.conflict_rows


def _per_seed_summary(rows: list[dict], seed: int) -> list[dict]:
    target = _column(rows, TARGET)
    return [
        {
            "seed": seed,
            "measure": metric,
            "target": TARGET,
            "pearson_r": pearsonr(_column(rows, metric), target),
            "directed_pair_count": len(rows),
            "receiver_count": len({str(row["client_i"]) for row in rows}),
        }
        for metric in METRICS
    ]


def clustered_statistics(rows: list[dict], replicates: int, seed: int) -> list[dict]:
    rng = np.random.default_rng(seed)
    observed = {metric: _within_seed_correlation(rows, metric, TARGET) for metric in METRICS}
    draws = {metric: [] for metric in METRICS}
    seeds = sorted({int(row["seed"]) for row in rows})
    by_seed: dict[int, list[dict]] = {seed_id: [] for seed_id in seeds}
    for row in rows:
        by_seed[int(row["seed"])].append(row)
    for _ in range(max(1, int(replicates))):
        sampled_rows: list[dict] = []
        sampled_seed_ids = rng.choice(seeds, size=len(seeds), replace=True)
        for replicate_seed_index, seed_id_raw in enumerate(sampled_seed_ids):
            seed_id = int(seed_id_raw)
            seed_rows = by_seed[seed_id]
            receivers = sorted({str(row["client_i"]) for row in seed_rows})
            sampled_receivers = rng.choice(receivers, size=len(receivers), replace=True)
            for receiver_copy, receiver in enumerate(sampled_receivers):
                for row in seed_rows:
                    if str(row["client_i"]) != str(receiver):
                        continue
                    copied = dict(row)
                    copied["bootstrap_seed_cluster"] = replicate_seed_index
                    copied["bootstrap_receiver_cluster"] = f"{replicate_seed_index}:{receiver_copy}"
                    sampled_rows.append(copied)
        for metric in METRICS:
            value = _within_cluster_correlation(
                sampled_rows,
                metric,
                TARGET,
                cluster_field="bootstrap_seed_cluster",
            )
            if np.isfinite(value):
                draws[metric].append(float(value))

    output: list[dict] = []
    for metric in METRICS:
        values = np.asarray(draws[metric], dtype=np.float64)
        low = float(np.quantile(values, 0.025)) if values.size else float("nan")
        high = float(np.quantile(values, 0.975)) if values.size else float("nan")
        output.append(
            {
                "measure": metric,
                "target": TARGET,
                "estimand": "within-seed Pearson correlation",
                "cluster_levels": "seed;receiver_client",
                "estimate": observed[metric],
                "ci95_low": low,
                "ci95_high": high,
                "bootstrap_replicates": int(values.size),
                "seed_count": len(seeds),
                "receiver_seed_count": len({(int(row["seed"]), str(row["client_i"])) for row in rows}),
                "directed_pair_count": len(rows),
                "supports_positive_association": bool(np.isfinite(low) and low > 0.0),
            }
        )
    return output


def clustered_model_statistics(rows: list[dict], replicates: int, seed: int) -> list[dict]:
    rng = np.random.default_rng(seed)
    observed = {
        model: _within_cluster_r2(rows, predictors, TARGET, cluster_field="seed")
        for model, predictors in MODELS.items()
    }
    draws = {model: [] for model in MODELS}
    delta_draws = {"add_geo_to_subspace": [], "add_local_risk_to_subspace_geo": []}
    for _ in range(max(1, int(replicates))):
        sampled = _hierarchical_sample_rows(rows, rng)
        scores = {
            model: _within_cluster_r2(
                sampled,
                predictors,
                TARGET,
                cluster_field="bootstrap_seed_cluster",
            )
            for model, predictors in MODELS.items()
        }
        for model, score in scores.items():
            if np.isfinite(score):
                draws[model].append(float(score))
        if np.isfinite(scores["subspace_plus_geo"]) and np.isfinite(scores["subspace_only"]):
            delta_draws["add_geo_to_subspace"].append(
                float(scores["subspace_plus_geo"] - scores["subspace_only"])
            )
        if np.isfinite(scores["subspace_geo_local_risk"]) and np.isfinite(scores["subspace_plus_geo"]):
            delta_draws["add_local_risk_to_subspace_geo"].append(
                float(scores["subspace_geo_local_risk"] - scores["subspace_plus_geo"])
            )
    output: list[dict] = []
    for model, predictors in MODELS.items():
        values = np.asarray(draws[model], dtype=np.float64)
        output.append(
            {
                "row_type": "model",
                "model": model,
                "predictors": "+".join(predictors),
                "within_seed_r2": observed[model],
                "ci95_low": _safe_quantile(values, 0.025),
                "ci95_high": _safe_quantile(values, 0.975),
                "delta_r2": "",
                "delta_ci95_low": "",
                "delta_ci95_high": "",
                "supports_complementarity": "",
            }
        )
    delta_specs = {
        "add_geo_to_subspace": ("subspace_plus_geo", "subspace_only"),
        "add_local_risk_to_subspace_geo": ("subspace_geo_local_risk", "subspace_plus_geo"),
    }
    for name, (rich, base) in delta_specs.items():
        values = np.asarray(delta_draws[name], dtype=np.float64)
        low = _safe_quantile(values, 0.025)
        high = _safe_quantile(values, 0.975)
        delta = observed[rich] - observed[base]
        output.append(
            {
                "row_type": "nested_delta",
                "model": name,
                "predictors": f"{rich} minus {base}",
                "within_seed_r2": "",
                "ci95_low": "",
                "ci95_high": "",
                "delta_r2": delta,
                "delta_ci95_low": low,
                "delta_ci95_high": high,
                "supports_complementarity": bool(np.isfinite(low) and low > 0.0),
            }
        )
    return output


def _hierarchical_sample_rows(rows: list[dict], rng: np.random.Generator) -> list[dict]:
    seeds = sorted({int(row["seed"]) for row in rows})
    by_seed = {seed_id: [row for row in rows if int(row["seed"]) == seed_id] for seed_id in seeds}
    sampled_rows: list[dict] = []
    for replicate_seed_index, seed_id_raw in enumerate(rng.choice(seeds, size=len(seeds), replace=True)):
        seed_rows = by_seed[int(seed_id_raw)]
        receivers = sorted({str(row["client_i"]) for row in seed_rows})
        for receiver_copy, receiver in enumerate(rng.choice(receivers, size=len(receivers), replace=True)):
            for row in seed_rows:
                if str(row["client_i"]) != str(receiver):
                    continue
                copied = dict(row)
                copied["bootstrap_seed_cluster"] = replicate_seed_index
                copied["bootstrap_receiver_cluster"] = f"{replicate_seed_index}:{receiver_copy}"
                sampled_rows.append(copied)
    return sampled_rows


def _within_seed_correlation(rows: list[dict], x_field: str, y_field: str) -> float:
    return _within_cluster_correlation(rows, x_field, y_field, cluster_field="seed")


def _within_cluster_correlation(rows: list[dict], x_field: str, y_field: str, cluster_field: str) -> float:
    by_cluster: dict[str, list[dict]] = {}
    for row in rows:
        by_cluster.setdefault(str(row[cluster_field]), []).append(row)
    x_residual: list[float] = []
    y_residual: list[float] = []
    for cluster_rows in by_cluster.values():
        x = _column(cluster_rows, x_field)
        y = _column(cluster_rows, y_field)
        x_residual.extend((x - np.mean(x)).tolist())
        y_residual.extend((y - np.mean(y)).tolist())
    return pearsonr(np.asarray(x_residual), np.asarray(y_residual))


def _within_cluster_r2(
    rows: list[dict],
    predictors: tuple[str, ...],
    target: str,
    cluster_field: str,
) -> float:
    by_cluster: dict[str, list[dict]] = {}
    for row in rows:
        by_cluster.setdefault(str(row[cluster_field]), []).append(row)
    x_parts: list[np.ndarray] = []
    y_parts: list[np.ndarray] = []
    for cluster_rows in by_cluster.values():
        x = np.column_stack([_column(cluster_rows, predictor) for predictor in predictors])
        y = _column(cluster_rows, target)
        x_parts.append(x - np.mean(x, axis=0, keepdims=True))
        y_parts.append(y - np.mean(y))
    x_all = np.vstack(x_parts)
    y_all = np.concatenate(y_parts)
    scale = np.std(x_all, axis=0, keepdims=True)
    x_all = x_all / np.clip(scale, 1e-12, None)
    try:
        coefficients, *_ = np.linalg.lstsq(x_all, y_all, rcond=None)
    except np.linalg.LinAlgError:
        return float("nan")
    residual = y_all - x_all @ coefficients
    total = float(np.sum(y_all * y_all))
    if total <= 1e-12:
        return float("nan")
    return float(1.0 - np.sum(residual * residual) / total)


def _safe_quantile(values: np.ndarray, q: float) -> float:
    values = np.asarray(values, dtype=np.float64)
    values = values[np.isfinite(values)]
    return float(np.quantile(values, q)) if values.size else float("nan")


def _column(rows: list[dict], field: str) -> np.ndarray:
    return np.asarray([float(row[field]) for row in rows], dtype=np.float64)


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _write_markdown_report(
    path: Path,
    clustered: list[dict],
    per_seed: list[dict],
    model_rows: list[dict],
) -> None:
    lines = [
        "# Algebraically Decoupled Semantic-Conflict Diagnostic",
        "",
        "The target is the receiver test-loss increase after averaging the two exact full LoRA updates. "
        "It excludes factor-wise rotational and structural aggregation error.",
        "",
        "## Clustered estimates",
        "",
        "| Measure | Within-seed r | 95% hierarchical CI | Positive lower bound |",
        "|---|---:|---:|:---:|",
    ]
    for row in clustered:
        lines.append(
            f"| {row['measure']} | {float(row['estimate']):.4f} | "
            f"[{float(row['ci95_low']):.4f}, {float(row['ci95_high']):.4f}] | "
            f"{str(row['supports_positive_association'])} |"
        )
    lines.extend(["", "## Signal complementarity", "", "| Model/comparison | R2 or delta R2 | 95% hierarchical CI | Supports |", "|---|---:|---:|:---:|"])
    for row in model_rows:
        if row["row_type"] == "model":
            lines.append(
                f"| {row['model']} | {float(row['within_seed_r2']):.4f} | "
                f"[{float(row['ci95_low']):.4f}, {float(row['ci95_high']):.4f}] |  |"
            )
        else:
            lines.append(
                f"| {row['model']} | {float(row['delta_r2']):.4f} | "
                f"[{float(row['delta_ci95_low']):.4f}, {float(row['delta_ci95_high']):.4f}] | "
                f"{row['supports_complementarity']} |"
            )
    lines.extend(["", "## Per-seed estimates", "", "| Seed | Measure | Pearson r |", "|---:|---|---:|"])
    for row in per_seed:
        lines.append(f"| {row['seed']} | {row['measure']} | {float(row['pearson_r']):.4f} |")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
