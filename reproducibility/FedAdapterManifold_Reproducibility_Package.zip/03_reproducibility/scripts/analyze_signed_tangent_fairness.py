from __future__ import annotations

import argparse
import csv
import itertools
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.config import load_yaml


METHOD = "FedAdapterManifold-SignedTangentAdmit"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit receiver-signed tangent admission.")
    parser.add_argument(
        "--result-root",
        default="results/fam_signed_tangent_fairness_dev_20260813",
    )
    parser.add_argument("--bootstrap-replicates", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=20260813)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.result_root)
    rng = np.random.default_rng(int(args.seed))
    unit_rows: list[dict] = []
    run_protocols: list[dict] = []
    for admission_path in sorted(root.glob("*/seed_*/signed_tangent_admission.csv")):
        dataset = admission_path.parents[1].name
        seed = int(admission_path.parent.name.split("_")[-1])
        admissions = _read_csv(admission_path)
        config = load_yaml(admission_path.parent / "config.yaml")
        provenance_path = admission_path.parent / "run_provenance.json"
        provenance = (
            json.loads(provenance_path.read_text(encoding="utf-8"))
            if provenance_path.is_file()
            else {}
        )
        test_free = all(
            not _as_bool(row.get("test_used_for_selection", False))
            for row in admissions
        )
        run_protocols.append(
            {
                "dataset": dataset,
                "seed": seed,
                "calibration_fraction": float(
                    config.get("candidate_selector_calibration_fraction", 0.0)
                ),
                "calibration_strategy": str(
                    config.get("candidate_selector_calibration_strategy", "")
                ),
                "provenance_present": provenance_path.is_file(),
                "package_source_sha256": str(provenance.get("package_source_sha256", "")),
                "geometry_inputs_sha256": str(provenance.get("geometry_inputs_sha256", "")),
                "test_free_selection": test_free,
            }
        )
        screen_rows = _read_csv(admission_path.parent / "signed_tangent_screen.csv")
        selected_screen = {
            str(row["client_id"]): row
            for row in screen_rows
            if _as_bool(row.get("training_screen_selected", False))
        }
        by_client: dict[str, list[dict]] = {}
        for row in admissions:
            by_client.setdefault(str(row["client_id"]), []).append(row)
        for client_id, rows in sorted(by_client.items()):
            signed = _one(rows, "candidate_method", "FAM-SignedTangent")
            selected = next(row for row in rows if _as_bool(row["selected"]))
            anchor_name = str(signed["best_anchor_method"])
            anchor = _one(rows, "candidate_method", anchor_name)
            screen = selected_screen[client_id]
            candidate_accuracy_gain = float(signed["test_accuracy_post_selection_audit"]) - float(
                anchor["test_accuracy_post_selection_audit"]
            )
            candidate_loss_reduction = float(anchor["test_loss_post_selection_audit"]) - float(
                signed["test_loss_post_selection_audit"]
            )
            admitted = _as_bool(signed["signed_candidate_admissible"])
            selected_accuracy_gain = (
                float(selected["test_accuracy_post_selection_audit"])
                - float(anchor["test_accuracy_post_selection_audit"])
            )
            selected_loss_reduction = (
                float(anchor["test_loss_post_selection_audit"])
                - float(selected["test_loss_post_selection_audit"])
            )
            unit_rows.append(
                {
                    "dataset": dataset,
                    "seed": seed,
                    "client_id": client_id,
                    "domain": signed.get("domain", ""),
                    "anchor_method": anchor_name,
                    "selected_method": selected["candidate_method"],
                    "admitted": admitted,
                    "candidate_accuracy_gain": candidate_accuracy_gain,
                    "candidate_loss_reduction": candidate_loss_reduction,
                    "selected_accuracy_gain": selected_accuracy_gain,
                    "selected_loss_reduction": selected_loss_reduction,
                    "candidate_beneficial": candidate_accuracy_gain > 1e-12,
                    "candidate_harmful": candidate_accuracy_gain < -1e-12,
                    "harmful_admission": admitted and candidate_accuracy_gain < -1e-12,
                    "predicted_loss_decrease": float(screen["predicted_loss_decrease"]),
                    "directional_derivative": float(screen["directional_derivative"]),
                    "selected_step": float(screen["selected_step"]),
                    "tangent_energy_ratio": float(screen["tangent_energy_ratio"]),
                    "transport_source": screen["transport_source"],
                    "anchor_source": screen["anchor_source"],
                }
            )
    if not unit_rows:
        raise FileNotFoundError(f"No completed signed-tangent runs under {root}")

    summary_rows: list[dict] = []
    seed_rows: list[dict] = []
    for dataset, rows in sorted(_group(unit_rows, "dataset").items()):
        dataset_protocols = [row for row in run_protocols if row["dataset"] == dataset]
        code_hashes = {
            str(row["package_source_sha256"])
            for row in dataset_protocols
            if str(row["package_source_sha256"])
        }
        heldout_calibration = bool(
            dataset_protocols
            and all(float(row["calibration_fraction"]) > 0.0 for row in dataset_protocols)
        )
        provenance_complete = bool(
            dataset_protocols and all(bool(row["provenance_present"]) for row in dataset_protocols)
        )
        code_hash_consistent = bool(provenance_complete and len(code_hashes) == 1)
        test_free_selection = bool(
            dataset_protocols and all(bool(row["test_free_selection"]) for row in dataset_protocols)
        )
        for seed, current in sorted(_group(rows, "seed").items()):
            seed_rows.append(
                {
                    "dataset": dataset,
                    "seed": int(seed),
                    "client_count": len(current),
                    "candidate_mean_accuracy_gain": _mean(current, "candidate_accuracy_gain"),
                    "selected_mean_accuracy_gain": _mean(current, "selected_accuracy_gain"),
                    "selected_mean_loss_reduction": _mean(current, "selected_loss_reduction"),
                    "admitted_count": sum(bool(row["admitted"]) for row in current),
                    "harmful_admission_count": sum(bool(row["harmful_admission"]) for row in current),
                }
            )
        current_seed_rows = [row for row in seed_rows if row["dataset"] == dataset]
        accuracy_boot = _hierarchical_bootstrap(
            rows, "selected_accuracy_gain", int(args.bootstrap_replicates), rng
        )
        loss_boot = _hierarchical_bootstrap(
            rows, "selected_loss_reduction", int(args.bootstrap_replicates), rng
        )
        correlation_boot = _clustered_correlation_bootstrap(
            rows,
            "predicted_loss_decrease",
            "candidate_loss_reduction",
            int(args.bootstrap_replicates),
            rng,
        )
        observed_correlation = _correlation(
            rows, "predicted_loss_decrease", "candidate_loss_reduction"
        )
        summary_rows.append(
            {
                "dataset": dataset,
                "seed_count": len(current_seed_rows),
                "client_seed_count": len(rows),
                "candidate_mean_accuracy_gain": _mean(rows, "candidate_accuracy_gain"),
                "selected_mean_accuracy_gain": _mean(rows, "selected_accuracy_gain"),
                "selected_accuracy_gain_ci95_low": float(np.quantile(accuracy_boot, 0.025)),
                "selected_accuracy_gain_ci95_high": float(np.quantile(accuracy_boot, 0.975)),
                "selected_mean_loss_reduction": _mean(rows, "selected_loss_reduction"),
                "selected_loss_reduction_ci95_low": float(np.quantile(loss_boot, 0.025)),
                "selected_loss_reduction_ci95_high": float(np.quantile(loss_boot, 0.975)),
                "positive_seed_count": sum(
                    float(row["selected_mean_accuracy_gain"]) > 1e-12 for row in current_seed_rows
                ),
                "negative_seed_count": sum(
                    float(row["selected_mean_accuracy_gain"]) < -1e-12 for row in current_seed_rows
                ),
                "seed_sign_flip_p_one_sided": _exact_sign_flip_p(
                    [float(row["selected_mean_accuracy_gain"]) for row in current_seed_rows]
                ),
                "admitted_count": sum(bool(row["admitted"]) for row in rows),
                "beneficial_candidate_count": sum(bool(row["candidate_beneficial"]) for row in rows),
                "harmful_candidate_count": sum(bool(row["candidate_harmful"]) for row in rows),
                "harmful_admission_count": sum(bool(row["harmful_admission"]) for row in rows),
                "prediction_realized_loss_pearson_r": observed_correlation,
                "prediction_realized_loss_ci95_low": float(np.quantile(correlation_boot, 0.025)),
                "prediction_realized_loss_ci95_high": float(np.quantile(correlation_boot, 0.975)),
                "heldout_calibration": heldout_calibration,
                "provenance_complete": provenance_complete,
                "code_hash_consistent": code_hash_consistent,
                "test_free_selection": test_free_selection,
                "passes_confirmation_gate": bool(
                    float(np.quantile(accuracy_boot, 0.025)) > 0.0
                    and sum(bool(row["harmful_admission"]) for row in rows) == 0
                    and sum(bool(row["admitted"]) for row in rows) > 0
                    and heldout_calibration
                    and provenance_complete
                    and code_hash_consistent
                    and test_free_selection
                ),
            }
        )

    output_dir = root / "signed_tangent_statistics"
    output_dir.mkdir(parents=True, exist_ok=True)
    _write_csv(output_dir / "signed_tangent_units.csv", unit_rows)
    _write_csv(output_dir / "signed_tangent_seed_effects.csv", seed_rows)
    _write_csv(output_dir / "signed_tangent_protocol_audit.csv", run_protocols)
    _write_csv(output_dir / "signed_tangent_summary.csv", summary_rows)
    _write_report(output_dir / "signed_tangent_report.md", summary_rows)
    return 0


def _hierarchical_bootstrap(rows, field, replicates, rng):
    grouped = _group(rows, "seed")
    seeds = sorted(grouped)
    draws = np.empty(max(1, replicates), dtype=np.float64)
    for index in range(draws.size):
        values: list[float] = []
        for sampled_seed in rng.choice(seeds, size=len(seeds), replace=True):
            seed_rows = grouped[int(sampled_seed)]
            sampled_indices = rng.integers(0, len(seed_rows), size=len(seed_rows))
            values.extend(float(seed_rows[item][field]) for item in sampled_indices)
        draws[index] = float(np.mean(values))
    return draws


def _clustered_correlation_bootstrap(rows, x_field, y_field, replicates, rng):
    grouped = _group(rows, "seed")
    seeds = sorted(grouped)
    draws = np.empty(max(1, replicates), dtype=np.float64)
    for index in range(draws.size):
        sampled: list[dict] = []
        for sampled_seed in rng.choice(seeds, size=len(seeds), replace=True):
            sampled.extend(grouped[int(sampled_seed)])
        draws[index] = _correlation(sampled, x_field, y_field)
    return draws


def _correlation(rows, x_field, y_field):
    x = np.asarray([float(row[x_field]) for row in rows], dtype=np.float64)
    y = np.asarray([float(row[y_field]) for row in rows], dtype=np.float64)
    if x.size < 2 or np.std(x) <= 1e-12 or np.std(y) <= 1e-12:
        return 0.0
    return float(np.corrcoef(x, y)[0, 1])


def _exact_sign_flip_p(values):
    values = np.asarray(values, dtype=np.float64)
    observed = float(np.mean(values))
    magnitudes = np.abs(values)
    null = [
        float(np.mean(np.asarray(signs, dtype=np.float64) * magnitudes))
        for signs in itertools.product([-1.0, 1.0], repeat=len(values))
    ]
    return float(np.mean(np.asarray(null) >= observed - 1e-15))


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _one(rows, field, value):
    matches = [row for row in rows if str(row[field]) == value]
    if len(matches) != 1:
        raise ValueError(f"Expected one {field}={value}, found {len(matches)}")
    return matches[0]


def _group(rows, field):
    grouped: dict = {}
    for row in rows:
        grouped.setdefault(row[field], []).append(row)
    return grouped


def _mean(rows, field):
    return float(np.mean([float(row[field]) for row in rows]))


def _as_bool(value):
    return str(value).strip().lower() in {"1", "true", "yes"}


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _write_report(path: Path, rows: list[dict]) -> None:
    lines = [
        "# Receiver-Signed Tangent Admission Audit",
        "",
        "The pre-specified confirmation gate requires a positive hierarchical lower bound, at least one admission, zero harmful admissions, held-out calibration, test-free selection, complete provenance, and one consistent source hash.",
        "",
        "| Dataset | Seeds | Units | Selected gain | 95% CI | Admitted | Harmful admitted | Held-out | Hash | Prediction/test loss r | Pass |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            f"| {row['dataset']} | {row['seed_count']} | {row['client_seed_count']} | "
            f"{float(row['selected_mean_accuracy_gain']):.4f} | "
            f"[{float(row['selected_accuracy_gain_ci95_low']):.4f}, "
            f"{float(row['selected_accuracy_gain_ci95_high']):.4f}] | "
            f"{row['admitted_count']} | {row['harmful_admission_count']} | "
            f"{row['heldout_calibration']} | {row['code_hash_consistent']} | "
            f"{float(row['prediction_realized_loss_pearson_r']):.4f} | "
            f"{row['passes_confirmation_gate']} |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
