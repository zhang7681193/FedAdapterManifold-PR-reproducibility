from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd


SEEDS = tuple(range(5))
LOCAL = "Local-CLIP-LoRA"
RAW_TANGENT = "FedAdapterManifold-Tangent-Admit-CLIP-LoRA"
CERTIFIED_TANGENT = "FedAdapterManifold-Tangent-Certified-CLIP-LoRA"
PROTOCOL = "receiver_tangent_exact_certificate_v1"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Post-hoc decomposition of the frozen temporal-projector confirmation."
    )
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path(__file__).resolve().parents[1]
        / "results"
        / "fam_clip_e2e_officehome65_temporal_projector_20260814",
    )
    return parser.parse_args()


def _method_value(frame: pd.DataFrame, method: str, column: str) -> float:
    row = frame[frame["method"] == method]
    if len(row) != 1:
        raise RuntimeError(f"Expected one {method!r} row, found {len(row)}")
    return float(row.iloc[0][column])


def _minimum_all_beneficial(alpha: float) -> int:
    # With h=0, the exact one-sided discordance p-value is 2^{-b}.
    return int(math.ceil(math.log2(1.0 / float(alpha))))


def main() -> int:
    args = parse_args()
    root = args.result_root.resolve()
    decision_path = root / "analysis" / "confirmation_decision.json"
    diagnostics_path = root / "analysis" / "subspace_estimator_diagnostics.csv"
    if not decision_path.is_file() or not diagnostics_path.is_file():
        raise RuntimeError("Run the frozen confirmation analyzer before this post-hoc audit")

    decision = json.loads(decision_path.read_text(encoding="utf-8"))
    diagnostics = pd.read_csv(diagnostics_path).set_index("estimator")
    unit_rows: list[dict[str, object]] = []
    seed_rows: list[dict[str, object]] = []

    for seed in SEEDS:
        seed_root = root / "temporal-projector" / f"seed_{seed}"
        metrics = pd.read_csv(seed_root / "metrics.csv")
        selection = pd.read_csv(seed_root / "candidate_selection.csv")
        calibration_sizes = (
            selection.dropna(subset=["num_calibration"])
            .groupby("client_id")["num_calibration"]
            .first()
            .astype(int)
            .to_dict()
        )
        screened = selection[
            (selection["selection_protocol"] == PROTOCOL)
            & (selection["screen_selected"] == True)  # noqa: E712
        ].copy()
        if len(screened) != 4:
            raise RuntimeError(f"Expected four screened receivers for seed {seed}")
        screened["alpha"] = (
            screened["candidate_method"]
            .str.extract(r"-a([0-9.]+)$", expand=False)
            .astype(float)
        )
        screened["discordances"] = (
            screened["beneficial_discordances"].astype(int)
            + screened["harmful_discordances"].astype(int)
        )
        for _, row in screened.iterrows():
            unit_rows.append(
                {
                    "seed": seed,
                    "client_id": int(row["client_id"]),
                    "domain": str(row["domain"]),
                    "screened_method": str(row["candidate_method"]),
                    "alpha": float(row["alpha"]),
                    "num_calibration": int(calibration_sizes[int(row["client_id"])]),
                    "beneficial_discordances": int(row["beneficial_discordances"]),
                    "harmful_discordances": int(row["harmful_discordances"]),
                    "discordances": int(row["discordances"]),
                    "exact_p": float(row["one_sided_exact_p"]),
                    "certified": bool(row["certified"]),
                }
            )

        local = _method_value(metrics, LOCAL, "mean_accuracy")
        raw = _method_value(metrics, RAW_TANGENT, "mean_accuracy")
        certified = _method_value(metrics, CERTIFIED_TANGENT, "mean_accuracy")
        seed_rows.append(
            {
                "seed": seed,
                "raw_tangent_minus_local": raw - local,
                "certified_tangent_minus_local": certified - local,
            }
        )

    units = pd.DataFrame(unit_rows)
    seeds = pd.DataFrame(seed_rows)
    # The frozen runner records the multiplicity-adjusted value in every row.
    first_selection = pd.read_csv(
        root / "temporal-projector" / "seed_0" / "candidate_selection.csv"
    )
    certificate_alpha = float(
        first_selection.loc[
            first_selection["selection_protocol"] == PROTOCOL, "certificate_alpha"
        ].dropna().iloc[0]
    )
    required_beneficial = _minimum_all_beneficial(certificate_alpha)

    final_diag = diagnostics.loc["final-residual"]
    temporal_diag = diagnostics.loc["temporal-projector"]
    raw_effects = seeds["raw_tangent_minus_local"].to_numpy(float)
    summary = {
        "analysis_status": "post_hoc_failure_decomposition",
        "pre_registered_success": bool(decision["pre_registered_success"]),
        "estimator": {
            "correlation_delta": float(
                temporal_diag["mean_seed_correlation"]
                - final_diag["mean_seed_correlation"]
            ),
            "controlled_coefficient_delta": float(
                temporal_diag["mean_controlled_coefficient"]
                - final_diag["mean_controlled_coefficient"]
            ),
            "incremental_r2_delta": float(
                temporal_diag["mean_incremental_r2"]
                - final_diag["mean_incremental_r2"]
            ),
            "uniform_improvement": bool(
                temporal_diag["mean_seed_correlation"]
                > final_diag["mean_seed_correlation"]
                and temporal_diag["mean_controlled_coefficient"]
                > final_diag["mean_controlled_coefficient"]
                and temporal_diag["mean_incremental_r2"]
                > final_diag["mean_incremental_r2"]
            ),
        },
        "candidate_effect": {
            "raw_mean_gain_vs_local": float(raw_effects.mean()),
            "positive_seeds": int(np.sum(raw_effects > 1e-12)),
            "ties": int(np.sum(np.isclose(raw_effects, 0.0))),
            "negative_seeds": int(np.sum(raw_effects < -1e-12)),
            "alpha_counts": {
                str(key): int(value)
                for key, value in units["alpha"].value_counts().sort_index().items()
            },
            "total_discordances": int(units["discordances"].sum()),
            "median_discordances_per_receiver": float(units["discordances"].median()),
            "max_beneficial_discordances": int(
                units["beneficial_discordances"].max()
            ),
        },
        "certificate_power": {
            "per_comparison_alpha": certificate_alpha,
            "minimum_all_beneficial_discordances": required_beneficial,
            "receivers_reaching_minimum": int(
                np.sum(
                    (units["beneficial_discordances"] >= required_beneficial)
                    & (units["harmful_discordances"] == 0)
                )
            ),
            "certified_receivers": int(units["certified"].sum()),
        },
        "diagnosis": [
            "temporal projector did not uniformly improve the subspace diagnostic",
            "accuracy-first screening selected low-amplitude candidates in most receivers",
            "screened candidates changed too few calibration decisions for the strict exact certificate",
            "uncertified tangent utility was mixed across seeds",
        ],
    }

    output = root / "analysis" / "post_hoc_failure_decomposition"
    output.mkdir(parents=True, exist_ok=True)
    units.to_csv(output / "screened_receiver_units.csv", index=False)
    seeds.to_csv(output / "seed_utility.csv", index=False)
    (output / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    report = [
        "# Post-hoc failure decomposition",
        "",
        "This audit was written after the frozen confirmation completed. It does not alter the pre-registered NOT MET decision.",
        "",
        "## Findings",
        "",
        f"- The temporal projector changed the controlled coefficient by {summary['estimator']['controlled_coefficient_delta']:+.4f}, but changed mean correlation by {summary['estimator']['correlation_delta']:+.4f} and incremental R2 by {summary['estimator']['incremental_r2_delta']:+.4f}; diagnostic improvement was not uniform.",
        f"- Accuracy-first screening selected alpha=0.125 for {summary['candidate_effect']['alpha_counts'].get('0.125', 0)}/20 receivers and alpha=0.25 for {summary['candidate_effect']['alpha_counts'].get('0.25', 0)}/20.",
        f"- The 20 screened receiver candidates produced only {summary['candidate_effect']['total_discordances']} calibration discordances in total; the median was {summary['candidate_effect']['median_discordances_per_receiver']:.1f}.",
        f"- At alpha={certificate_alpha:.6f}, even a zero-harm candidate needs at least {required_beneficial} beneficial discordances because p=2^(-b). The observed maximum was {summary['candidate_effect']['max_beneficial_discordances']}; no receiver reached the power floor.",
        f"- Uncertified tangent deployment had seed effects {', '.join(f'{value:+.6f}' for value in raw_effects)} relative to Local, so candidate utility itself was not stable.",
        "",
        "## Consequence",
        "",
        "Estimator variance was not the sole bottleneck. The next method must jointly address candidate step-size selection and finite-sample certification; rerunning another projector estimator under the same accuracy-first screen is not justified.",
    ]
    (output / "report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
