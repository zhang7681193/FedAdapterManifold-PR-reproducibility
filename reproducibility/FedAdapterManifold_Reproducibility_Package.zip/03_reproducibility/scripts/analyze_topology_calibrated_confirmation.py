from __future__ import annotations

import argparse
import csv
import itertools
from pathlib import Path

import numpy as np


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit scale-invariant graph support and exact deployment safety.")
    parser.add_argument("--result-root", required=True, type=Path)
    parser.add_argument("--bootstrap-replicates", type=int, default=20000)
    parser.add_argument("--seed", type=int, default=20260813)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = args.result_root.resolve()
    run_dirs = sorted(path.parent for path in root.glob("*/seed_*/semantic_admission_weights.csv"))
    if len(run_dirs) != 10:
        raise RuntimeError(f"Expected 10 completed runs, found {len(run_dirs)}")

    units: list[dict] = []
    for run_dir in run_dirs:
        dataset = run_dir.parent.name
        seed = int(run_dir.name.split("_")[-1])
        weights = _read_csv(run_dir / "semantic_admission_weights.csv")
        certificates = _read_csv(run_dir / "semantic_admission_exact_certificate.csv")
        final_round = max(int(float(row["round"])) for row in weights)
        final_weights = [row for row in weights if int(float(row["round"])) == final_round]
        graph_paths = sorted((run_dir / "geometry_outputs").glob("geometry_graph_round_*.npy"))
        if len(graph_paths) != 1:
            raise RuntimeError(
                f"Expected one geometry graph for {dataset}/seed_{seed}, found {len(graph_paths)}"
            )
        graph_path = graph_paths[0]
        original_graph = np.asarray(np.load(graph_path), dtype=np.float64)
        receiver_ids = sorted({str(row["receiver_client"]) for row in final_weights}, key=_client_order)
        donor_ids = sorted({str(row["donor_client"]) for row in final_weights}, key=_client_order)
        receiver_index = {client_id: index for index, client_id in enumerate(receiver_ids)}
        donor_index = {client_id: index for index, client_id in enumerate(donor_ids)}

        by_receiver = _group(final_weights, "receiver_client")
        cert_by_client = _group(certificates, "client_id")
        for client_id, rows in sorted(by_receiver.items(), key=lambda item: _client_order(item[0])):
            i = receiver_index[str(client_id)]
            absent_weight_count = 0
            nonlocal_weight = 0.0
            for row in rows:
                donor = str(row["donor_client"])
                j = donor_index[donor]
                weight = float(row["admission_weight"])
                if i != j:
                    nonlocal_weight += weight
                    if weight > 1e-12 and float(original_graph[i, j]) <= 0.0:
                        absent_weight_count += 1

            cert_rows = cert_by_client[str(client_id)]
            local = _one(cert_rows, "candidate_method", "Local-LoRA")
            geo = _one(cert_rows, "candidate_method", "Geo-only-Agg")
            semantic_names = sorted(
                {
                    str(row["candidate_method"])
                    for row in cert_rows
                    if str(row["candidate_method"]) not in {"Local-LoRA", "Geo-only-Agg"}
                }
            )
            if len(semantic_names) != 1:
                raise RuntimeError(f"Expected one semantic endpoint for {dataset}/{seed}/{client_id}: {semantic_names}")
            semantic = _one(cert_rows, "candidate_method", semantic_names[0])
            selected = [row for row in cert_rows if _as_bool(row.get("selected", False))]
            if len(selected) != 1:
                raise RuntimeError(f"Expected one selected endpoint for {dataset}/{seed}/{client_id}")
            selected = selected[0]
            selected_name = str(selected["candidate_method"])
            selected_accuracy = float(selected["test_accuracy_post_selection_audit"])
            local_accuracy = float(local["test_accuracy_post_selection_audit"])
            geo_accuracy = float(geo["test_accuracy_post_selection_audit"])
            semantic_accuracy = float(semantic["test_accuracy_post_selection_audit"])
            geo_deployable = _as_bool(selected.get("geo_deployable", False))
            fam_deployable = _as_bool(selected.get("fam_deployable", False))
            certified = bool(
                selected_name == "Local-LoRA"
                or (selected_name == "Geo-only-Agg" and geo_deployable)
                or (selected_name == semantic_names[0] and fam_deployable)
            )
            first = rows[0]
            units.append(
                {
                    "dataset": dataset,
                    "seed": seed,
                    "client_id": client_id,
                    "graph_scale_policy": first.get("graph_scale_policy", ""),
                    "raw_graph_neighbor_mass": float(first["raw_graph_neighbor_mass"]),
                    "effective_graph_neighbor_mass": float(first["effective_graph_neighbor_mass"]),
                    "graph_confidence_rejected": _as_bool(first.get("graph_confidence_rejected", False)),
                    "final_nonlocal_admission_weight": nonlocal_weight,
                    "positive_weight_on_absent_edge_count": absent_weight_count,
                    "semantic_candidate_accuracy_gain_over_local": semantic_accuracy - local_accuracy,
                    "selected_method": selected_name,
                    "selected_nonlocal": selected_name != "Local-LoRA",
                    "selected_accuracy_gain_over_local": selected_accuracy - local_accuracy,
                    "selected_accuracy_gain_over_geo": selected_accuracy - geo_accuracy,
                    "harmful_admission": selected_name != "Local-LoRA" and selected_accuracy < local_accuracy - 1e-12,
                    "uncertified_deployment": not certified,
                    "test_used_for_selection": _as_bool(selected.get("test_used_for_selection", False)),
                }
            )

    rng = np.random.default_rng(int(args.seed))
    summaries: list[dict] = []
    for dataset, rows in sorted(_group(units, "dataset").items()):
        local_draws = _hierarchical_bootstrap(rows, "selected_accuracy_gain_over_local", args.bootstrap_replicates, rng)
        geo_draws = _hierarchical_bootstrap(rows, "selected_accuracy_gain_over_geo", args.bootstrap_replicates, rng)
        seed_effects = [
            float(np.mean([float(row["selected_accuracy_gain_over_local"]) for row in seed_rows]))
            for _, seed_rows in sorted(_group(rows, "seed").items())
        ]
        nonlocal_count = sum(_as_bool(row["selected_nonlocal"]) for row in rows)
        harmful_count = sum(_as_bool(row["harmful_admission"]) for row in rows)
        uncertified_count = sum(_as_bool(row["uncertified_deployment"]) for row in rows)
        absent_count = sum(int(row["positive_weight_on_absent_edge_count"]) for row in rows)
        generator_count = sum(float(row["final_nonlocal_admission_weight"]) > 1e-12 for row in rows)
        scale_policy_correct = all(row["graph_scale_policy"] == "topology-calibrated" for row in rows)
        effective_mass_correct = all(
            abs(float(row["effective_graph_neighbor_mass"]) - 1.0) <= 1e-12 for row in rows
        )
        test_free_selection = all(not _as_bool(row["test_used_for_selection"]) for row in rows)
        summaries.append(
            {
                "dataset": dataset,
                "seed_count": len(_group(rows, "seed")),
                "unit_count": len(rows),
                "candidate_generation_receiver_count": generator_count,
                "selected_nonlocal_count": nonlocal_count,
                "mean_gain_over_local": float(np.mean([float(row["selected_accuracy_gain_over_local"]) for row in rows])),
                "gain_over_local_ci_low": float(np.quantile(local_draws, 0.025)),
                "gain_over_local_ci_high": float(np.quantile(local_draws, 0.975)),
                "mean_gain_over_geo": float(np.mean([float(row["selected_accuracy_gain_over_geo"]) for row in rows])),
                "gain_over_geo_ci_low": float(np.quantile(geo_draws, 0.025)),
                "gain_over_geo_ci_high": float(np.quantile(geo_draws, 0.975)),
                "exact_seed_sign_flip_p_one_sided": _exact_sign_flip_p(np.asarray(seed_effects)),
                "harmful_admission_count": harmful_count,
                "uncertified_deployment_count": uncertified_count,
                "positive_weight_on_absent_edge_count": absent_count,
                "all_scale_policy_correct": scale_policy_correct,
                "all_effective_neighbor_mass_one": effective_mass_correct,
                "test_free_selection": test_free_selection,
                "passes_generator_decoupling": bool(
                    generator_count == len(rows)
                    and absent_count == 0
                    and scale_policy_correct
                    and effective_mass_correct
                    and test_free_selection
                    and all(not _as_bool(row["graph_confidence_rejected"]) for row in rows)
                ),
                "passes_exact_safety": bool(harmful_count == 0 and uncertified_count == 0),
                "passes_positive_confirmation": bool(
                    nonlocal_count > 0
                    and harmful_count == 0
                    and uncertified_count == 0
                    and absent_count == 0
                    and float(np.mean([float(row["selected_accuracy_gain_over_local"]) for row in rows])) >= 0.0
                ),
            }
        )

    analysis = root / "analysis"
    analysis.mkdir(parents=True, exist_ok=True)
    _write_csv(analysis / "topology_support_units.csv", units)
    _write_csv(analysis / "topology_support_summary.csv", summaries)
    lines = [
        "# Topology-calibrated graph-support confirmation",
        "",
        "The graph support map and all numerical parameters were fixed before these runs. Test labels were attached only after exact receiver deployment was frozen.",
        "",
    ]
    for row in summaries:
        lines.extend(
            [
                f"## {row['dataset']}",
                f"- Candidate generation: {row['candidate_generation_receiver_count']}/{row['unit_count']} receiver-seed units.",
                f"- Certified non-local deployment: {row['selected_nonlocal_count']}/{row['unit_count']}.",
                f"- Gain over Local: {row['mean_gain_over_local']:+.4f}, hierarchical CI [{row['gain_over_local_ci_low']:+.4f}, {row['gain_over_local_ci_high']:+.4f}].",
                f"- Gain over Geo-only: {row['mean_gain_over_geo']:+.4f}, hierarchical CI [{row['gain_over_geo_ci_low']:+.4f}, {row['gain_over_geo_ci_high']:+.4f}].",
                f"- Harmful / uncertified / invented-edge counts: {row['harmful_admission_count']} / {row['uncertified_deployment_count']} / {row['positive_weight_on_absent_edge_count']}.",
                f"- Generator decoupling passes: {row['passes_generator_decoupling']}; positive confirmation passes: {row['passes_positive_confirmation']}.",
                "",
            ]
        )
    (analysis / "topology_support_report.md").write_text("\n".join(lines), encoding="utf-8")
    return 0


def _hierarchical_bootstrap(rows, field, replicates, rng):
    grouped = _group(rows, "seed")
    seeds = sorted(grouped)
    draws = np.empty(max(1, int(replicates)), dtype=np.float64)
    for draw_index in range(draws.size):
        values = []
        for sampled_seed in rng.choice(seeds, size=len(seeds), replace=True):
            seed_rows = grouped[int(sampled_seed)]
            indices = rng.integers(0, len(seed_rows), size=len(seed_rows))
            values.extend(float(seed_rows[int(index)][field]) for index in indices)
        draws[draw_index] = float(np.mean(values))
    return draws


def _exact_sign_flip_p(values):
    values = np.asarray(values, dtype=np.float64)
    observed = float(values.mean())
    null = [
        float(np.mean(values * np.asarray(signs, dtype=np.float64)))
        for signs in itertools.product((-1.0, 1.0), repeat=len(values))
    ]
    return float(np.mean(np.asarray(null) >= observed - 1e-15))


def _client_order(value):
    text = str(value)
    try:
        return (0, int(text.rsplit("_", 1)[-1]))
    except ValueError:
        return (1, text)


def _read_csv(path):
    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path, rows):
    if not rows:
        raise RuntimeError(f"Refusing to write an empty audit: {path}")
    fields = sorted({field for row in rows for field in row})
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _group(rows, field):
    grouped = {}
    for row in rows:
        grouped.setdefault(row[field], []).append(row)
    return grouped


def _one(rows, field, value):
    found = [row for row in rows if str(row.get(field, "")) == value]
    if len(found) != 1:
        raise RuntimeError(f"Expected one {field}={value}, found {len(found)}")
    return found[0]


def _as_bool(value):
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes"}


if __name__ == "__main__":
    raise SystemExit(main())
