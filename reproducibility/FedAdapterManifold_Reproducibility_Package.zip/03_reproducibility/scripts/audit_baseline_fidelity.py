from __future__ import annotations

import argparse
import csv
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.baseline_fidelity import BASELINE_FIDELITY


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Write the baseline-fidelity manifest used by the manuscript.")
    parser.add_argument("--output-dir", default="paper_resubmit")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    rows = [item.as_row() for item in BASELINE_FIDELITY]
    csv_path = output_dir / "baseline_fidelity_audit.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    lines = [
        "# Baseline Fidelity Audit",
        "",
        "This manifest separates direct same-protocol baselines, visual ports of pinned source recurrences, paper-equation ports, and internal mechanism controls.",
        "Rows marked `external_method_claim_allowed=1` may be used as named comparisons only at the declared fidelity level; a recurrence port does not imply full reproduction of its native task pipeline.",
        "Published numbers from incompatible protocols are not imported into the quantitative tables.",
        "",
        "| Run key | Paper label | Category | External claim? | Implementation scope |",
        "|---|---|---|---:|---|",
    ]
    for row in rows:
        lines.append(
            "| {run_key} | {paper_label} | {category} | {external_method_claim_allowed} | {implementation_scope} |".format(
                **row
            )
        )
    (output_dir / "baseline_fidelity_audit.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
