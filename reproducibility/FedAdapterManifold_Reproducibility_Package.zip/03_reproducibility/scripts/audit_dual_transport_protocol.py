from __future__ import annotations

import argparse
import csv
from pathlib import Path


METHOD = "FedAdapterManifold-DualTransport"
ANCHORS = "Local-LoRA;Ditto-LoRA"
FALLBACK = "Ditto-LoRA"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit fixed-pool dual-anchor admission outputs.")
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--expected-seeds", default="0,1,2,3,4")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.input_dir)
    expected_seeds = [int(value) for value in args.expected_seeds.split(",")]
    checks = []
    reference_pool = None
    for seed in expected_seeds:
        gates = _read(root / f"seed_{seed}_admission_gates.csv")
        metrics = _read(root / f"seed_{seed}_per_client_metrics.csv")
        dual_gates = [row for row in gates if row.get("method") == METHOD]
        dual_metrics = [row for row in metrics if row.get("method") == METHOD]
        pool = tuple(sorted({row["candidate_adapter"] for row in dual_gates}))
        if reference_pool is None:
            reference_pool = pool
        checks.append(_check(seed, "fixed_candidate_pool", pool == reference_pool, pool, reference_pool))
        checks.append(_check(seed, "declared_dual_anchors", all(row.get("certificate_anchor_names") == ANCHORS for row in dual_gates), "", ANCHORS))
        checks.append(_check(seed, "declared_fallback", all(row.get("fallback_anchor_name") == FALLBACK for row in dual_gates), "", FALLBACK))
        checks.append(_check(seed, "calibration_only", all(row.get("selection_split") == "heldout_calibration" for row in dual_gates), "", "heldout_calibration"))
        selected = [row for row in dual_gates if _truthy(row.get("selected"))]
        clients = sorted({row["client_id"] for row in dual_gates})
        checks.append(_check(seed, "one_selection_per_client", len(selected) == len(clients) and len({row["client_id"] for row in selected}) == len(clients), len(selected), len(clients)))
        invalid_admissions = [
            (row["client_id"], row["candidate_adapter"])
            for row in selected
            if row["candidate_adapter"] not in {"Local-LoRA", "Ditto-LoRA"}
            and not _truthy(row.get("all_anchor_ucb_certified"))
        ]
        checks.append(_check(seed, "nonanchor_requires_certificate", not invalid_admissions, invalid_admissions, []))
        selected_map = {row["client_id"]: row["selected_adapter"] for row in selected}
        metric_map = {row["client_id"]: row.get("selected_candidate") for row in dual_metrics}
        checks.append(_check(seed, "metric_gate_reconciliation", selected_map == metric_map, metric_map, selected_map))
        checks.append(_check(seed, "run_seed", all(int(float(row["seed"])) == seed for row in dual_metrics), "", seed))
    output_csv = root / "dual_transport_protocol_audit.csv"
    _write(output_csv, checks)
    failures = [row for row in checks if row["status"] == "fail"]
    report = root / "dual_transport_protocol_audit.md"
    report.write_text(
        "# Dual-Transport Protocol Audit\n\n"
        f"- Checks: {len(checks)}\n"
        f"- Passed: {len(checks) - len(failures)}\n"
        f"- Failed: {len(failures)}\n"
        f"- Fixed candidate pool: `{';'.join(reference_pool or ())}`\n\n"
        "## Failures\n\n"
        + ("- None\n" if not failures else "\n".join(f"- seed {row['seed']} / {row['check']}: {row['observed']}" for row in failures) + "\n"),
        encoding="utf-8",
    )
    print(report)
    return 1 if failures else 0


def _check(seed: int, name: str, passed: bool, observed, expected) -> dict:
    return {"seed": seed, "check": name, "status": "pass" if passed else "fail", "observed": observed, "expected": expected}


def _truthy(value) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def _read(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _write(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
