from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np


EXPECTED_SEEDS = list(range(10, 15))
EXPECTED_CLIENTS = {
    "0": "Art",
    "1": "Clipart",
    "2": "Product",
    "3": "Real_World",
}
KEY_COLUMNS = {
    "seed",
    "client_id",
    "domain",
    "candidate_fixed_before_calibration",
    "test_used_for_construction",
    "all_deployments_frozen_before_test",
    "test_used_for_construction_or_selection",
    "certified",
    "harmful_admission",
    "local_test_accuracy",
    "deployed_test_accuracy",
    "local_test_loss",
    "deployed_test_loss",
    "student_raw_test_accuracy",
    "direct_raw_test_accuracy",
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def _bool(value: object) -> bool:
    return str(value).strip().lower() == "true"


def _seed_bootstrap(values: dict[int, float], draws: int = 20000) -> list[float]:
    array = np.asarray([values[key] for key in sorted(values)], dtype=np.float64)
    rng = np.random.default_rng(20260815)
    samples = array[rng.integers(0, array.size, size=(draws, array.size))].mean(axis=1)
    return [float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))]


def _close(left: float, right: float, tolerance: float = 1e-12) -> bool:
    return abs(left - right) <= tolerance


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Audit the frozen OfficeHome-65 FunctionTransport confirmation"
    )
    parser.add_argument("--baseline-root", required=True)
    parser.add_argument("--transport-root", required=True)
    parser.add_argument("--geometry-registry", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args(argv)

    baseline_root = Path(args.baseline_root).resolve()
    transport_root = Path(args.transport_root).resolve()
    registry_path = Path(args.geometry_registry).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    protocol = _json(transport_root / "frozen_protocol.json")
    report = _json(transport_root / "confirmation_report.json")
    registry = _json(registry_path)
    baseline_protocol = _json(baseline_root / "frozen_baseline_protocol.json")
    rows = _csv(transport_root / "function_transport_admission_all_seeds.csv")
    snapshots = {int(item["seed"]): item for item in registry["snapshots"]}

    checks: list[dict[str, object]] = []

    def check(name: str, passed: bool, evidence: object, severity: str = "critical") -> None:
        checks.append(
            {
                "check": name,
                "passed": bool(passed),
                "severity_if_failed": severity,
                "evidence": evidence,
            }
        )

    check("confirmation protocol is frozen", protocol.get("frozen_before_results") is True, protocol.get("protocol"))
    check("confirmation seed set", protocol.get("seeds") == EXPECTED_SEEDS, protocol.get("seeds"))
    check("baseline seed set", baseline_protocol.get("seeds") == EXPECTED_SEEDS, baseline_protocol.get("seeds"))
    check("provider registry seed set", registry.get("seeds") == EXPECTED_SEEDS, registry.get("seeds"))
    check("provider registry hash", protocol.get("geometry_registry_sha256") == _sha256(registry_path), _sha256(registry_path))
    check("provider snapshots are training-only", all(item.get("no_calibration_or_test_used") is True for item in snapshots.values()), {seed: snapshots[seed].get("excluded_inputs") for seed in EXPECTED_SEEDS})
    check("provider snapshots are frozen", all(item.get("snapshot_status") == "frozen" for item in snapshots.values()), {seed: snapshots[seed].get("snapshot_status") for seed in EXPECTED_SEEDS})

    expected_keys = {(seed, client) for seed in EXPECTED_SEEDS for client in EXPECTED_CLIENTS}
    actual_keys = {(int(row["seed"]), row["client_id"]) for row in rows}
    check("receiver-seed grain is complete", len(rows) == 20 and actual_keys == expected_keys, {"rows": len(rows), "unique_keys": len(actual_keys)})
    check("receiver-seed grain is unique", len(actual_keys) == len(rows), {"rows": len(rows), "unique_keys": len(actual_keys)})
    missing_columns = sorted(KEY_COLUMNS.difference(rows[0] if rows else {}))
    check("required columns are present", not missing_columns, missing_columns)
    if rows and not missing_columns:
        check("client-domain order is stable", all(EXPECTED_CLIENTS[row["client_id"]] == row["domain"] for row in rows), sorted({(row["client_id"], row["domain"]) for row in rows}))
        check("candidate pool fixed before calibration", all(_bool(row["candidate_fixed_before_calibration"]) for row in rows), sum(_bool(row["candidate_fixed_before_calibration"]) for row in rows))
        check("no test construction", not any(_bool(row["test_used_for_construction"]) for row in rows), sum(_bool(row["test_used_for_construction"]) for row in rows))
        check("all deployments frozen before test", all(_bool(row["all_deployments_frozen_before_test"]) for row in rows), sum(_bool(row["all_deployments_frozen_before_test"]) for row in rows))
        check("no test construction or selection", not any(_bool(row["test_used_for_construction_or_selection"]) for row in rows), sum(_bool(row["test_used_for_construction_or_selection"]) for row in rows))

    split_hashes: dict[int, dict[str, object]] = {}
    geometry_hash_matches: dict[int, bool] = {}
    for seed in EXPECTED_SEEDS:
        baseline_provenance = _json(baseline_root / f"seed_{seed}" / "run_provenance.json")
        transport_provenance = _json(transport_root / f"seed_{seed}" / "run_provenance.json")
        baseline_manifest = baseline_root / f"seed_{seed}" / "split_manifest.json"
        transport_manifest = transport_root / f"seed_{seed}" / "split_manifest.json"
        split_hashes[seed] = {
            "baseline": _sha256(baseline_manifest),
            "transport": _sha256(transport_manifest),
            "rows": transport_provenance.get("split_manifest_rows"),
        }
        expected_geometry = snapshots[seed]["output_sha256"]
        observed_geometry = {
            item["name"]: item["sha256"] for item in transport_provenance["geometry_files"]
        }
        geometry_hash_matches[seed] = observed_geometry == expected_geometry
        check(
            f"seed {seed} provenance forbids test selection",
            baseline_provenance.get("test_used_for_selection") is False
            and transport_provenance.get("test_used_for_selection") is False,
            {
                "baseline": baseline_provenance.get("test_used_for_selection"),
                "transport": transport_provenance.get("test_used_for_selection"),
            },
        )
    check("baseline and transport split manifests match", all(item["baseline"] == item["transport"] for item in split_hashes.values()), split_hashes)
    check("provider output hashes match transport provenance", all(geometry_hash_matches.values()), geometry_hash_matches)

    local_replay_accuracy = float(report["max_local_replay_accuracy_difference"])
    local_replay_loss = float(report["max_local_replay_loss_difference"])
    local_replay_count = int(report["max_local_replay_sample_count_difference"])
    check("local replay accuracy is exact", local_replay_accuracy == 0.0, local_replay_accuracy)
    check("local replay sample counts are exact", local_replay_count == 0, local_replay_count)
    check("local replay loss is within frozen tolerance", local_replay_loss <= float(report["local_replay_loss_tolerance"]), {"difference": local_replay_loss, "tolerance": report["local_replay_loss_tolerance"]})

    harmful = sum(_bool(row["harmful_admission"]) for row in rows)
    certified = sum(_bool(row["certified"]) for row in rows)
    pointwise_accuracy_error = max(abs(float(row["deployed_test_accuracy"]) - float(row["local_test_accuracy"])) for row in rows)
    proper_loss_violations = sum(float(row["deployed_test_loss"]) > float(row["local_test_loss"]) + 1e-12 for row in rows)
    check("zero harmful certified admissions", harmful == 0 and int(report["harmful_certified"]) == 0, harmful)
    check("at least one non-local deployment", certified > 0 and certified == int(report["certified_nonlocal"]), certified)
    check("deployed top-1 is pointwise preserved", pointwise_accuracy_error == 0.0, pointwise_accuracy_error)
    check("deployed proper loss never increases", proper_loss_violations == 0, proper_loss_violations)

    seed_student: dict[int, float] = {}
    seed_loss: dict[int, float] = {}
    seed_direct: dict[int, float] = {}
    domain_student: dict[str, list[float]] = {domain: [] for domain in EXPECTED_CLIENTS.values()}
    for seed in EXPECTED_SEEDS:
        subset = [row for row in rows if int(row["seed"]) == seed]
        seed_student[seed] = float(np.mean([float(row["student_raw_test_accuracy"]) - float(row["local_test_accuracy"]) for row in subset]))
        seed_direct[seed] = float(np.mean([float(row["direct_raw_test_accuracy"]) - float(row["local_test_accuracy"]) for row in subset]))
        seed_loss[seed] = float(np.mean([float(row["local_test_loss"]) - float(row["deployed_test_loss"]) for row in subset]))
        for row in subset:
            domain_student[row["domain"]].append(float(row["student_raw_test_accuracy"]) - float(row["local_test_accuracy"]))

    student_mean = float(np.mean(list(seed_student.values())))
    student_ci = _seed_bootstrap(seed_student)
    loss_mean = float(np.mean(list(seed_loss.values())))
    loss_ci = _seed_bootstrap(seed_loss)
    positive_seed_count = sum(value > 0.0 for value in seed_student.values())
    domain_means = {domain: float(np.mean(values)) for domain, values in domain_student.items()}
    check("raw student mean is positive", student_mean > 0.0 and _close(student_mean, float(report["mean_raw_student_accuracy_gain_vs_local"])), seed_student)
    check("raw student seed-bootstrap lower bound is positive", student_ci[0] > 0.0 and np.allclose(student_ci, report["seed_bootstrap_ci_raw_student_accuracy_gain_vs_local"], atol=1e-15), student_ci)
    check("raw student is positive in at least four seeds", positive_seed_count >= 4 and positive_seed_count == int(report["raw_student_positive_seed_count"]), {"count": positive_seed_count, "seed_values": seed_student})
    check("deployed proper-loss improvement is stable", loss_mean > 0.0 and loss_ci[0] >= 0.0 and np.allclose(loss_ci, report["seed_bootstrap_ci_proper_loss_gain_vs_local"], atol=1e-15), {"mean": loss_mean, "ci": loss_ci, "seed_values": seed_loss})
    check("raw student domain means are all positive", all(value > 0.0 for value in domain_means.values()), domain_means, severity="high")
    check("confirmation gate passed", report.get("confirmation_passed") is True and report.get("stage_passed") is True, {"stage_passed": report.get("stage_passed"), "confirmation_passed": report.get("confirmation_passed")})

    failed = [item for item in checks if not item["passed"]]
    summary = {
        "audit": "officehome65_function_transport_untouched_confirmation_v1",
        "passed": not failed,
        "check_count": len(checks),
        "failed_check_count": len(failed),
        "receiver_seed_units": len(rows),
        "seeds": EXPECTED_SEEDS,
        "raw_student_seed_values": seed_student,
        "raw_student_mean_gain": student_mean,
        "raw_student_seed_bootstrap_ci": student_ci,
        "raw_student_positive_seed_count": positive_seed_count,
        "raw_direct_seed_values": seed_direct,
        "raw_direct_mean_gain": float(np.mean(list(seed_direct.values()))),
        "deployed_proper_loss_mean_gain": loss_mean,
        "deployed_proper_loss_seed_bootstrap_ci": loss_ci,
        "raw_student_domain_mean_gains": domain_means,
        "certified_nonlocal": certified,
        "harmful_certified": harmful,
        "checks": checks,
    }
    (output_dir / "confirmation_quality_audit.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    lines = [
        "# OfficeHome-65 FunctionTransport Confirmation Quality Audit",
        "",
        f"- Overall: `{'PASS' if not failed else 'FAIL'}`",
        f"- Checks: `{len(checks) - len(failed)}/{len(checks)}` passed",
        f"- Receiver-seed units: `{len(rows)}`",
        f"- Raw student top-1 gain: `{student_mean:.9f}`; seed-bootstrap CI `[{student_ci[0]:.9f}, {student_ci[1]:.9f}]`",
        f"- Positive seeds: `{positive_seed_count}/5`",
        f"- Deployed proper-loss gain: `{loss_mean:.9f}`; seed-bootstrap CI `[{loss_ci[0]:.9f}, {loss_ci[1]:.9f}]`",
        f"- Certified non-local deployments: `{certified}/20`; harmful: `{harmful}`",
        "",
        "## Checks",
        "",
    ]
    lines.extend(
        f"- [{'x' if item['passed'] else ' '}] {item['check']}: `{item['evidence']}`"
        for item in checks
    )
    (output_dir / "confirmation_quality_audit.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    print(json.dumps({key: value for key, value in summary.items() if key != "checks"}, indent=2))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
