from __future__ import annotations

import hashlib
import subprocess
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = ROOT / "results/baseline_official_code_audit_20260812/repos"
OUTPUT = ROOT / "results/baseline_official_code_audit_20260812"

SOURCES = {
    "FedEx-LoRA": {
        "repo": "fedex-lora",
        "revision": "2fa2e4a243f93c829e2b601e459e45aa748e4149",
        "files": ["fed_agg.py"],
        "markers": ["residue = M - lora_B_avg @ lora_A_avg", "base_layer.weight"],
        "native_task": "language-model fine-tuning",
        "ported_recurrence": "exact residual-base aggregation",
    },
    "FedSA-LoRA": {
        "repo": "FedSA-LoRA",
        "revision": "5e616a06e806a8804e09820ddebfcbd2363f0a2f",
        "files": ["federatedscope/glue/yamls/fedsa-lora.yaml"],
        "markers": ["local_param: ['lora_B', 'classifier']", "share_local_model: True"],
        "native_task": "GLUE language-model fine-tuning",
        "ported_recurrence": "shared-A/local-B selective aggregation",
    },
    "LoRA-FAIR": {
        "repo": "LoRA-FAIR",
        "revision": "6afb36c4d8ff9f7b5dce5fd4be7728d4f9467d5a",
        "files": ["server.py"],
        "markers": ["torch.nn.init.xavier_uniform_", "F.cosine_similarity", "optim.SGD"],
        "native_task": "ViT/Mixer visual domain adaptation",
        "ported_recurrence": "A/B/BA averaging and residual-B refinement",
    },
    "FedRot-LoRA": {
        "repo": "FedRot-LoRA",
        "revision": "36a67ef205818c292cf9ff361a80f969de16cedd",
        "files": [
            "federatedscope/rotation_alignment_tools.py",
            "federatedscope/core/workers/client.py",
        ],
        "markers": ["rotation_align_optimization_soft", "R_soft", "align_matrix = 'A'"],
        "native_task": "FederatedScope language-model fine-tuning",
        "ported_recurrence": "alternating proper-Procrustes gauge alignment",
    },
    "FedSmoothLoRA": {
        "repo": "FedSmoothLoRA",
        "revision": "41404dfa372b82e101660eb68979d383f63efc0d",
        "files": ["IC_exp/fedsmoothlora.py", "IC_exp/utils.py"],
        "markers": ["Round-Matching", "Gradient-Aligned", "matrix_truncated_svd_every_layer"],
        "native_task": "image classification and language generation",
        "ported_recurrence": "gradient-aligned initialization, round matching, full-update SVD merge",
    },
    "FedTreeLoRA": {
        "repo_path": "external/FedTreeLoRA",
        "revision": "0586fea07f071e4358599e4ab664a250a7a0f2d9",
        "files": ["server.py", "utils_functions.py", "client.py"],
        "markers": [
            "aggregation_proposed_two_expert",
            "progressive_layerwise_cluster_search",
            "rest of clusters",
        ],
        "native_task": "multi-layer RoBERTa GLUE fine-tuning",
        "ported_recurrence": "single-layer B-Frobenius hierarchy and own/rest two-expert aggregation",
    },
    "FedLEASE": {
        "repo_path": "third_party/FedLEASE",
        "revision": "3376b0f70dd1799b208e76e123f6e92bd9b945ca",
        "files": ["server.py", "utils.py", "peft/tuners/lora.py"],
        "markers": [
            "compute_lora_client_map",
            "calculate_B_similarity_matrix",
            "2 * self.lora_num - 1",
            "module_mapping[self.lora_num:] = self.idx",
            "route_aggregation",
        ],
        "native_task": "multi-task language-model fine-tuning",
        "ported_recurrence": "local warm-up, B-cosine/silhouette experts, adaptive top-K routing, and group-wise expert/router aggregation",
    },
    "FedALT": {
        "repo_path": "external/FedALT",
        "revision": "8be3dde2569cef47ecab2d7d931667606a921a47",
        "files": ["server.py", "client.py", "peft/tuners/lora.py"],
        "markers": [
            "Rest-of-World",
            "lora_A1",
            "lora_B1",
            "lora_route",
            "route_weight = nn.functional.softmax",
        ],
        "native_task": "heterogeneous multi-task language-model fine-tuning",
        "ported_recurrence": "persistent local/RoW dual LoRA, input-level softmax routing, and receiver-specific leave-one-out factor aggregation",
    },
}


def _git(repo: Path, *args: str) -> str:
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    rows = []
    file_rows = []
    for method, spec in SOURCES.items():
        repo = ROOT / str(spec["repo_path"]) if "repo_path" in spec else REPO_ROOT / str(spec["repo"])
        head = _git(repo, "rev-parse", "HEAD")
        source_text = "\n".join((repo / rel).read_text(encoding="utf-8", errors="replace") for rel in spec["files"])
        missing_markers = [marker for marker in spec["markers"] if marker not in source_text]
        for rel in spec["files"]:
            file_rows.append(
                {
                    "method": method,
                    "relative_source_file": rel,
                    "sha256": _sha256(repo / rel),
                }
            )
        rows.append(
            {
                "method": method,
                "expected_revision": spec["revision"],
                "checked_revision": head,
                "pin_matches_current_official_head": head == spec["revision"],
                "source_markers_complete": not missing_markers,
                "missing_markers": " | ".join(missing_markers),
                "official_native_task": spec["native_task"],
                "same_protocol_ported_recurrence": spec["ported_recurrence"],
                "official_native_numbers_imported": False,
                "common_visual_protocol_retrained": True,
                "classification": "same-protocol visual port of pinned source recurrence",
            }
        )
    audit = pd.DataFrame(rows)
    audit.to_csv(OUTPUT / "official_source_audit.csv", index=False)
    pd.DataFrame(file_rows).to_csv(OUTPUT / "official_source_file_hashes.csv", index=False)
    passed = bool(
        audit["pin_matches_current_official_head"].all()
        and audit["source_markers_complete"].all()
        and (~audit["official_native_numbers_imported"]).all()
        and audit["common_visual_protocol_retrained"].all()
    )
    report = [
        "# Pinned-source recurrence audit",
        "",
        "The reported recent federated-LoRA rows are not copied from incompatible native-task tables. Each method is retrained on the common visual client splits and budget using a visual port of its defining pinned-source recurrence. This audit establishes source and recurrence fidelity; it does not claim full execution of the native task pipeline.",
        "",
        "| Method | Official revision | Native task | Ported recurrence | Status |",
        "|---|---|---|---|---|",
    ]
    for row in rows:
        status = "PASS" if row["pin_matches_current_official_head"] and row["source_markers_complete"] else "FAIL"
        report.append(
            f"| {row['method']} | `{row['checked_revision'][:12]}` | {row['official_native_task']} | "
            f"{row['same_protocol_ported_recurrence']} | {status} |"
        )
    report.extend(
        [
            "",
            "Numerical identities and recurrence behavior are covered by `tests/test_recent_lora_baselines.py` and `scripts/audit_official_runtime_parity.py`: exact FedEx reconstruction, FedSA shared-A/local-B persistence, FedRot semantic-update preservation, LoRA-FAIR finite-difference gradient and objective descent, FedSmooth cumulative full-update merging, and FedTreeLoRA own/rest two-expert aggregation.",
            "",
            f"Overall audit: {'PASS' if passed else 'FAIL'}.",
        ]
    )
    (OUTPUT / "official_source_audit.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    if not passed:
        raise SystemExit("Official-source audit failed")
    print(audit.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
