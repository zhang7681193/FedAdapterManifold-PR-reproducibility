from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import re
import sys
from types import SimpleNamespace
from typing import Dict, List, Union

import numpy as np
import pandas as pd
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.aggregation import fedrot_align_to_reference
from fedadaptermanifold.recent_lora_baselines import (
    _fedlease_server_aggregate,
    _lorafair_objective_and_gradient,
    fedalt_rest_of_world_aggregate,
    fedex_exact_aggregate,
)


REPOS = ROOT / "results/baseline_official_code_audit_20260812/repos"
OUTPUT = ROOT / "results/baseline_official_runtime_parity_20260812"
TOL = 2e-5


def _load_definitions(path: Path, names: set[str], namespace: dict) -> dict:
    tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"), filename=str(path))
    selected = [
        node
        for node in tree.body
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in names
    ]
    missing = names - {node.name for node in selected}
    if missing:
        raise ValueError(f"Missing official definitions in {path}: {sorted(missing)}")
    module = ast.Module(body=selected, type_ignores=[])
    ast.fix_missing_locations(module)
    scope = dict(namespace)
    exec(compile(module, str(path), "exec"), scope)
    return scope


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class _Marker:
    lora_A = object()
    lora_B = object()


class _DummyFedExModel:
    def __init__(self, state: dict[str, torch.Tensor]):
        self.state = {key: value.clone() for key, value in state.items()}

    def state_dict(self) -> dict[str, torch.Tensor]:
        return {key: value.clone() for key, value in self.state.items()}

    def load_state_dict(self, state: dict[str, torch.Tensor]):
        self.state = {key: value.clone() for key, value in state.items()}

    def named_modules(self):
        return [("layer", _Marker())]

    def to(self, _device: str):
        return self


def _adapter(a: np.ndarray, b: np.ndarray, name: str) -> LoRAAdapter:
    rank = int(a.shape[0])
    return LoRAAdapter(
        input_dim=int(a.shape[1]),
        output_dim=int(b.shape[0]),
        rank=rank,
        A=np.asarray(a, dtype=np.float64),
        B=np.asarray(b, dtype=np.float64),
        alpha=float(rank),
        name=name,
    )


def _fedex_parity(rng: np.random.Generator) -> list[dict]:
    source = REPOS / "fedex-lora/fed_agg.py"
    scope = _load_definitions(source, {"aggregate_models_ours"}, {"torch": torch, "np": np})
    official = scope["aggregate_models_ours"]
    rank = 2
    client_adapters = []
    client_states = []
    for index in range(3):
        a = rng.normal(size=(rank, 3))
        b = rng.normal(size=(3, rank))
        client_adapters.append(_adapter(a, b, f"client-{index}"))
        client_states.append(
            {
                "layer.lora_A.default.weight": torch.tensor(a, dtype=torch.float64),
                "layer.lora_B.default.weight": torch.tensor(b, dtype=torch.float64),
                "layer.base_layer.weight": torch.zeros((3, 3), dtype=torch.float64),
            }
        )
    global_state = {
        "layer.lora_A.default.weight": torch.zeros((rank, 3), dtype=torch.float64),
        "layer.lora_B.default.weight": torch.zeros((3, rank), dtype=torch.float64),
        "layer.base_layer.weight": torch.zeros((3, 3), dtype=torch.float64),
    }
    model = _DummyFedExModel(global_state)
    args = SimpleNamespace(lora_alpha=rank, lora_r=rank, rslora=False)
    official_model = official(model, client_states, args)
    state = official_model.state
    official_factor = (
        state["layer.lora_B.default.weight"] @ state["layer.lora_A.default.weight"]
    ).numpy()
    # The released language-model code transposes the residual before adding
    # it to the PyTorch base-layer orientation. Convert it back to the BA
    # orientation used by the common visual protocol.
    official_effective = state["layer.base_layer.weight"].numpy().T + official_factor
    ours_factor, ours_residual, exact_error = fedex_exact_aggregate(
        client_adapters,
        previous_residual=np.zeros((3, 3), dtype=np.float64),
    )
    target = np.mean(np.stack([adapter.delta() for adapter in client_adapters]), axis=0)
    return [
        _row("FedEx-LoRA", "official aggregate_models_ours effective update", official_effective, target, source),
        _row("FedEx-LoRA", "ported factor average", ours_factor.delta(), official_factor, source),
        _row(
            "FedEx-LoRA",
            "ported residual-base reconstruction",
            ours_residual + ours_factor.delta(),
            official_effective,
            source,
            extra={"internal_exact_error": exact_error},
        ),
    ]


def _fedrot_parity(rng: np.random.Generator) -> list[dict]:
    source = REPOS / "FedRot-LoRA/federatedscope/rotation_alignment_tools.py"
    scope = _load_definitions(
        source,
        {"rotation_align_optimization_soft"},
        {"torch": torch},
    )
    official = scope["rotation_align_optimization_soft"]
    rank = 3
    a = rng.normal(size=(rank, 5))
    b = rng.normal(size=(4, rank))
    ref_a = rng.normal(size=(rank, 5))
    ref_b = rng.normal(size=(4, rank))
    adapter = _adapter(a, b, "updated")
    reference = _adapter(ref_a, ref_b, "reference")
    rows = []
    for factor, ref in (("A", ref_a), ("B", ref_b)):
        official_a, official_b = official(
            torch.tensor(ref, dtype=torch.float64),
            factor,
            torch.tensor(a, dtype=torch.float64),
            torch.tensor(b, dtype=torch.float64),
            0.4,
        )
        ours = fedrot_align_to_reference(
            adapter,
            reference,
            align_factor=factor,
            strength=0.4,
        )
        rows.append(_row("FedRot-LoRA", f"official soft {factor}-alignment A", ours.A, official_a.numpy(), source))
        rows.append(_row("FedRot-LoRA", f"official soft {factor}-alignment B", ours.B, official_b.numpy(), source))
        rows.append(_row("FedRot-LoRA", f"semantic BA preservation after {factor}-alignment", ours.delta(), adapter.delta(), source))
    return rows


def _lorafair_parity(rng: np.random.Generator) -> list[dict]:
    source = REPOS / "LoRA-FAIR/server.py"
    scope = _load_definitions(
        source,
        {"Server"},
        {
            "torch": torch,
            "nn": torch.nn,
            "optim": torch.optim,
            "F": torch.nn.functional,
            "LoraConfig": object,
            "FoundationModel": object,
        },
    )
    server = scope["Server"].__new__(scope["Server"])
    clients = []
    adapters = []
    for index in range(3):
        a = rng.normal(size=(2, 5))
        b = rng.normal(size=(4, 2))
        adapters.append(_adapter(a, b, f"client-{index}"))
        clients.append(
            {
                "layer.lora_A.default.weight": torch.tensor(a, dtype=torch.float64),
                "layer.lora_B.default.weight": torch.tensor(b, dtype=torch.float64),
            }
        )
    avg_a, avg_b, avg_products = server._aggregate_lora_parameters(clients)
    key_a = "layer.lora_A.default.weight"
    key_b = "layer.lora_B.default.weight"
    target = np.mean(np.stack([adapter.delta() for adapter in adapters]), axis=0)
    rows = [
        _row("LoRA-FAIR", "official A aggregation", avg_a[key_a].numpy(), np.mean([adapter.A for adapter in adapters], axis=0), source),
        _row("LoRA-FAIR", "official B aggregation", avg_b[key_b].numpy(), np.mean([adapter.B for adapter in adapters], axis=0), source),
        _row("LoRA-FAIR", "official BA aggregation", avg_products[key_a].numpy(), target, source),
    ]
    residual = rng.normal(scale=0.05, size=(4, 2))
    ours_loss, _, ours_gradient = _lorafair_objective_and_gradient(
        target,
        avg_a[key_a].numpy(),
        avg_b[key_b].numpy(),
        residual,
        0.1,
    )
    residual_t = torch.tensor(residual, dtype=torch.float64, requires_grad=True)
    reconstructed = (avg_b[key_b] + residual_t) @ avg_a[key_a]
    official_objective = 1.0 - torch.nn.functional.cosine_similarity(
        avg_products[key_a], reconstructed, dim=0
    ).mean() + 0.1 * torch.norm(residual_t) ** 2
    official_objective.backward()
    rows.append(_scalar_row("LoRA-FAIR", "official refinement objective", ours_loss, float(official_objective.detach()), source))
    rows.append(_row("LoRA-FAIR", "official refinement gradient", ours_gradient, residual_t.grad.numpy(), source))
    return rows


def _fedsmooth_parity(rng: np.random.Generator) -> list[dict]:
    source = REPOS / "FedSmoothLoRA/IC_exp/utils.py"
    scope = _load_definitions(
        source,
        {"linear_zeta_schedule", "cosine_zeta_schedule", "merge_ba_weights", "svd_ba"},
        {
            "torch": torch,
            "math": __import__("math"),
            "List": List,
            "Dict": Dict,
            "Union": Union,
        },
    )
    a = rng.normal(size=(2, 5))
    b = rng.normal(size=(4, 2))
    state = {
        "layer.lora_A.weight": torch.tensor(a, dtype=torch.float64),
        "layer.lora_B.weight": torch.tensor(b, dtype=torch.float64),
    }
    merged = scope["merge_ba_weights"]([state])[0]["layer.lora_BA.weight"]
    factored = scope["svd_ba"]({"layer.lora_BA.weight": merged}, 2)
    reconstructed = factored["layer.lora_B.weight"] @ factored["layer.lora_A.weight"]
    rows = [
        _row("FedSmoothLoRA", "official BA merge", merged.numpy(), b @ a, source),
        _row("FedSmoothLoRA", "official SVD refactorization", reconstructed.numpy(), b @ a, source),
    ]
    for round_id in (0, 3, 10):
        official_cosine = float(scope["cosine_zeta_schedule"](round_id, 10, 1.0, 0.1))
        ours_cosine = float(0.1 + 0.5 * 0.9 * (1.0 + np.cos(np.pi * round_id / 10.0)))
        rows.append(_scalar_row("FedSmoothLoRA", f"official cosine zeta round {round_id}", ours_cosine, official_cosine, source))
    return rows


def _fedlease_parity(rng: np.random.Generator) -> list[dict]:
    source = ROOT / "third_party/FedLEASE/server.py"
    scope = _load_definitions(
        source,
        {"Server"},
        {"torch": torch, "List": List, "Dict": Dict},
    )
    assignments = np.asarray([0, 0, 1, 1], dtype=np.int64)
    trained_adapters = []
    trained_routes = []
    official_params = []
    rank = 2
    num_experts = 2
    route_dim = 2 * num_experts - 1
    for client_id in range(4):
        adapter = _adapter(
            rng.normal(size=(rank, 3)),
            rng.normal(size=(3, rank)),
            f"fedlease-client-{client_id}",
        )
        route = rng.normal(size=(route_dim, 3))
        trained_adapters.append(adapter)
        trained_routes.append(route)
        params = {"layer.lora_route": torch.tensor(route, dtype=torch.float64)}
        for expert_id in range(num_experts):
            # The official server receives every expert slot. Only the assigned
            # slot is locally updated in the released client recurrence.
            if expert_id == assignments[client_id]:
                a, b = adapter.A, adapter.B
            else:
                a = np.zeros_like(adapter.A)
                b = np.zeros_like(adapter.B)
            params[f"layer.lora_A{expert_id}.weight"] = torch.tensor(a, dtype=torch.float64)
            params[f"layer.lora_B{expert_id}.weight"] = torch.tensor(b, dtype=torch.float64)
        official_params.append(params)

    lora_client_map = {0: [0, 1], 1: [2, 3]}
    official_server = scope["Server"](clients_num=4, device="cpu")
    official_results = official_server.aggregation(
        route_aggregation=True,
        params=official_params,
        lora_client_map=lora_client_map,
    )
    ours_experts, ours_routes = _fedlease_server_aggregate(
        trained_adapters,
        trained_routes,
        assignments,
        rank=rank,
        round_id=1,
    )
    rows = []
    for client_id in range(4):
        rows.append(
            _row(
                "FedLEASE",
                f"official group-wise router aggregation client {client_id}",
                ours_routes[client_id],
                official_results[client_id]["layer.lora_route"].numpy(),
                source,
            )
        )
        for expert_id in range(num_experts):
            rows.append(
                _row(
                    "FedLEASE",
                    f"official expert A aggregation client {client_id} expert {expert_id}",
                    ours_experts[expert_id].A,
                    official_results[client_id][f"layer.lora_A{expert_id}.weight"].numpy(),
                    source,
                )
            )
            rows.append(
                _row(
                    "FedLEASE",
                    f"official expert B aggregation client {client_id} expert {expert_id}",
                    ours_experts[expert_id].B,
                    official_results[client_id][f"layer.lora_B{expert_id}.weight"].numpy(),
                    source,
                )
            )
    return rows


def _fedtree_parity(rng: np.random.Generator) -> list[dict]:
    source = ROOT / "external/FedTreeLoRA/server.py"
    scope = _load_definitions(
        source,
        {"Server"},
        {"torch": torch, "re": re, "List": List, "Dict": Dict},
    )
    server = scope["Server"](clients_num=4, device="cpu", max_clusters=4)
    server.all_clustering_results = {"2": {0: [0, 1], 1: [2, 3]}}
    a0 = "encoder.layer.0.attention.lora_modules.A_0.weight"
    b0 = "encoder.layer.0.attention.lora_modules.B_0.weight"
    a1 = "encoder.layer.0.attention.lora_modules.A_1.weight"
    b1 = "encoder.layer.0.attention.lora_modules.B_1.weight"
    params = []
    for _ in range(4):
        params.append(
            {
                a0: torch.tensor(rng.normal(size=(2, 3)), dtype=torch.float64),
                b0: torch.tensor(rng.normal(size=(3, 2)), dtype=torch.float64),
                a1: torch.zeros((2, 3), dtype=torch.float64),
                b1: torch.zeros((3, 2), dtype=torch.float64),
            }
        )
    mappings = [
        {0: {0: 0, 1: -1}},
        {0: {0: 0, 1: -1}},
        {0: {0: 1, 1: -1}},
        {0: {0: 1, 1: -1}},
    ]
    official = server.aggregation_proposed_two_expert(params, {0: 2}, mappings)
    rows = []
    for client_id in range(4):
        own = 0 if client_id < 2 else 1
        rest = 1 - own
        own_members = server.all_clustering_results["2"][own]
        rest_members = server.all_clustering_results["2"][rest]
        expected = {
            a0: torch.stack([params[index][a0] for index in own_members]).mean(dim=0),
            b0: torch.stack([params[index][b0] for index in own_members]).mean(dim=0),
            a1: torch.stack([params[index][a0] for index in rest_members]).mean(dim=0),
            b1: torch.stack([params[index][b0] for index in rest_members]).mean(dim=0),
        }
        for name in (a0, b0, a1, b1):
            rows.append(
                _row(
                    "FedTreeLoRA",
                    f"official two-expert aggregation client {client_id} {name.split('.')[-2]}",
                    expected[name].numpy(),
                    official[client_id][name].numpy(),
                    source,
                )
            )
    return rows


def _fedalt_parity(rng: np.random.Generator) -> list[dict]:
    source = ROOT / "external/FedALT/server.py"
    scope = _load_definitions(
        source,
        {"Server"},
        {"torch": torch, "List": List, "Dict": Dict},
    )
    adapters = []
    params = []
    for client_id in range(4):
        adapter = _adapter(
            rng.normal(size=(2, 3)),
            rng.normal(size=(3, 2)),
            f"fedalt-client-{client_id}",
        )
        adapters.append(adapter)
        params.append(
            {
                "layer.lora_A1.weight": torch.tensor(adapter.A, dtype=torch.float64),
                "layer.lora_B1.weight": torch.tensor(adapter.B, dtype=torch.float64),
                "layer.lora_route.weight": torch.zeros((2, 3), dtype=torch.float64),
            }
        )
    official = scope["Server"](clients_num=4, device="cpu").aggregation(False, params)
    ours = fedalt_rest_of_world_aggregate(adapters, round_id=1)
    rows = []
    for client_id in range(4):
        rows.append(
            _row(
                "FedALT",
                f"official Rest-of-World A aggregation client {client_id}",
                ours[client_id].A,
                official[client_id]["layer.lora_A0.weight"].numpy(),
                source,
            )
        )
        rows.append(
            _row(
                "FedALT",
                f"official Rest-of-World B aggregation client {client_id}",
                ours[client_id].B,
                official[client_id]["layer.lora_B0.weight"].numpy(),
                source,
            )
        )
    return rows


def _source_only_rows() -> list[dict]:
    fedsa = REPOS / "FedSA-LoRA/federatedscope/glue/yamls/fedsa-lora.yaml"
    text = fedsa.read_text(encoding="utf-8", errors="replace")
    passed = "local_param: ['lora_B', 'classifier']" in text and "share_local_model: True" in text
    return [
        {
            "method": "FedSA-LoRA",
            "check": "official selective-sharing configuration",
            "official_source_file": str(fedsa.relative_to(ROOT)),
            "official_source_sha256": _sha256(fedsa),
            "max_abs_error": 0.0 if passed else float("inf"),
            "tolerance": 0.0,
            "passed": passed,
            "verification_level": "official configuration plus same-protocol recurrence test",
            "native_pipeline_executed": False,
            "reason_native_pipeline_not_used": "Official pipeline is coupled to FederatedScope GLUE language-model training.",
        }
    ]


def _row(method: str, check: str, ours, official, source: Path, extra: dict | None = None) -> dict:
    error = float(np.max(np.abs(np.asarray(ours, dtype=np.float64) - np.asarray(official, dtype=np.float64))))
    return {
        "method": method,
        "check": check,
        "official_source_file": str(source.relative_to(ROOT)),
        "official_source_sha256": _sha256(source),
        "max_abs_error": error,
        "tolerance": TOL,
        "passed": bool(error <= TOL),
        "verification_level": "official source executed against same-protocol implementation",
        "native_pipeline_executed": False,
        "reason_native_pipeline_not_used": "Native task/data pipeline is not the common visual federated protocol.",
        **(extra or {}),
    }


def _scalar_row(method: str, check: str, ours: float, official: float, source: Path) -> dict:
    return _row(method, check, np.asarray([ours]), np.asarray([official]), source)


def main() -> int:
    rng = np.random.default_rng(20260812)
    rows = []
    rows.extend(_fedex_parity(rng))
    rows.extend(_fedrot_parity(rng))
    rows.extend(_lorafair_parity(rng))
    rows.extend(_fedsmooth_parity(rng))
    rows.extend(_fedlease_parity(rng))
    rows.extend(_fedtree_parity(rng))
    rows.extend(_fedalt_parity(rng))
    rows.extend(_source_only_rows())
    frame = pd.DataFrame(rows)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    frame.to_csv(OUTPUT / "official_runtime_parity.csv", index=False)
    method_summary = (
        frame.groupby("method", as_index=False)
        .agg(
            checks=("check", "count"),
            all_passed=("passed", "all"),
            maximum_absolute_error=("max_abs_error", "max"),
        )
    )
    method_summary.to_csv(OUTPUT / "official_runtime_parity_summary.csv", index=False)
    manifest = {
        "official_native_task_numbers_imported": False,
        "common_visual_protocol_retrained": True,
        "runtime_parity_methods": sorted(
            frame.loc[frame["verification_level"].str.startswith("official source executed"), "method"].unique()
        ),
        "configuration_plus_recurrence_methods": ["FedSA-LoRA"],
        "all_checks_passed": bool(frame["passed"].all()),
    }
    (OUTPUT / "runtime_parity_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    report = [
        "# Official-code runtime parity audit",
        "",
        "Official server-side functions are executed directly from pinned source files whenever their recurrence is separable from the native task pipeline. The visual benchmark still retrains every method on the same client splits and budget; incompatible native-task accuracies are never imported.",
        "",
        "| Method | Checks | Max abs. error | Status |",
        "|---|---:|---:|---|",
    ]
    for row in method_summary.to_dict("records"):
        report.append(
            f"| {row['method']} | {row['checks']} | {row['maximum_absolute_error']:.3e} | "
            f"{'PASS' if row['all_passed'] else 'FAIL'} |"
        )
    report.extend(
        [
            "",
            "FedSA-LoRA is the explicit exception: its official implementation is embedded in a FederatedScope GLUE pipeline. We execute our shared-A/local-B recurrence under the visual protocol and audit its defining official configuration, rather than claiming an execution of the incompatible native pipeline.",
            "",
            f"Overall: {'PASS' if manifest['all_checks_passed'] else 'FAIL'}.",
        ]
    )
    (OUTPUT / "official_runtime_parity_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(method_summary.to_string(index=False))
    if not manifest["all_checks_passed"]:
        raise SystemExit("Official runtime parity audit failed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
