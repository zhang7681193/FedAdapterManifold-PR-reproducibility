from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

from fedadaptermanifold.config import load_yaml


DEFAULT_ROOTS = (
    "PACS=results/recent_lora_fairness_20260804/pacs_resnet18:7",
    "OfficeHome=results/recent_lora_fairness_20260804/officehome_clip_full:65",
    "DomainNetMini=results/recent_lora_fairness_20260804/domainnetmini_clip_60class:60",
)
DIRECT_RECENT_LORA = {"FedEx-LoRA", "FedSA-LoRA", "FedRot-LoRA"}
ALLOWED_SELECTION_SPLITS = {
    "geometry_graph_pretest",
    "round_training_trust_region",
    "heldout_calibration",
}
PROTOCOL_FIELDS = (
    "dataset",
    "feature_backbone",
    "rank",
    "rounds",
    "local_epochs",
    "lr",
    "batch_size",
    "domains",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit the matched recent-LoRA evidence at seed/client grain.")
    parser.add_argument("--root", action="append", default=[])
    parser.add_argument("--expected-seeds", default="0,1,2,3,4")
    parser.add_argument("--output-dir", default="results/recent_lora_data_quality_20260805")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    expected_seeds = {int(token) for token in str(args.expected_seeds).split(",") if token.strip()}
    specs = args.root or list(DEFAULT_ROOTS)
    checks: list[dict] = []
    for spec in specs:
        dataset, root, expected_classes = _parse_spec(spec)
        checks.extend(_audit_root(dataset, root, expected_classes, expected_seeds))
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    _write_csv(output_dir / "data_quality_checks.csv", checks)
    _write_report(output_dir / "data_quality_report.md", checks)
    return 2 if any(row["status"] == "fail" for row in checks) else 0


def _parse_spec(spec: str) -> tuple[str, Path, int]:
    if "=" not in spec or ":" not in spec.rsplit("=", 1)[1]:
        raise ValueError("Expected NAME=PATH:NUM_CLASSES")
    dataset, payload = spec.split("=", 1)
    path_text, classes = payload.rsplit(":", 1)
    return dataset, Path(path_text), int(classes)


def _audit_root(dataset: str, root: Path, expected_classes: int, expected_seeds: set[int]) -> list[dict]:
    rows: list[dict] = []
    seed_dirs = {int(path.name.split("_")[-1]): path for path in root.glob("seed_*") if path.is_dir()}
    rows.append(_check(dataset, "seed_set", set(seed_dirs) == expected_seeds, sorted(seed_dirs), sorted(expected_seeds)))
    reference_protocol = None
    for seed in sorted(expected_seeds & set(seed_dirs)):
        seed_dir = seed_dirs[seed]
        config = load_yaml(seed_dir / "config.yaml")
        effective_classes = int(config.get("effective_num_classes", config.get("num_classes", -1)))
        rows.append(
            _check(dataset, f"seed_{seed}:effective_num_classes", effective_classes == expected_classes,
                   effective_classes, expected_classes)
        )
        protocol = {field: config.get(field) for field in PROTOCOL_FIELDS}
        if reference_protocol is None:
            reference_protocol = protocol
        rows.append(_check(dataset, f"seed_{seed}:matched_protocol", protocol == reference_protocol,
                           protocol, reference_protocol))
        per_client = _read_csv(seed_dir / "per_client_metrics.csv")
        metrics = _read_csv(seed_dir / "metrics.csv")
        rows.extend(_audit_seed_rows(dataset, seed, per_client, metrics))
        gate_path = seed_dir / "semantic_admission_gates.csv"
        if gate_path.exists():
            gates = _read_csv(gate_path)
            invalid_splits = [
                row
                for row in gates
                if not selection_split_is_allowed(row.get("selection_split", ""))
            ]
            rows.append(
                _check(
                    dataset,
                    f"seed_{seed}:selection_split_allowlist",
                    not invalid_splits,
                    sorted({row.get("selection_split", "") for row in invalid_splits}),
                    [],
                )
            )
    return rows


def selection_split_is_allowed(value: object) -> bool:
    return str(value).strip().lower() in ALLOWED_SELECTION_SPLITS


def _audit_seed_rows(dataset: str, seed: int, per_client: list[dict], metrics: list[dict]) -> list[dict]:
    rows: list[dict] = []
    required = {"method", "seed", "client_id", "accuracy", "loss", "round", "dataset", "heterogeneity_setting"}
    missing = sorted(required - set(per_client[0])) if per_client else sorted(required)
    rows.append(_check(dataset, f"seed_{seed}:required_columns", not missing, missing, []))
    keys = [(row.get("method"), row.get("client_id")) for row in per_client]
    rows.append(_check(dataset, f"seed_{seed}:unique_method_client", len(keys) == len(set(keys)),
                       len(keys) - len(set(keys)), 0))
    invalid = []
    for row in per_client:
        try:
            accuracy = float(row["accuracy"])
            loss = float(row["loss"])
        except (KeyError, TypeError, ValueError):
            invalid.append((row.get("method"), row.get("client_id"), "parse"))
            continue
        if not (math.isfinite(accuracy) and 0.0 <= accuracy <= 1.0 and math.isfinite(loss) and loss >= 0.0):
            invalid.append((row.get("method"), row.get("client_id"), accuracy, loss))
        if int(float(row.get("seed", -1))) != seed:
            invalid.append((row.get("method"), row.get("client_id"), "seed_mismatch"))
        if row.get("method") == "Ditto-ResidualFAM":
            if int(float(row.get("method_seed", -1))) != seed + 70000:
                invalid.append((row.get("method"), row.get("client_id"), "method_seed_mismatch"))
    rows.append(_check(dataset, f"seed_{seed}:numeric_validity", not invalid, invalid[:5], []))

    by_method: dict[str, list[dict]] = {}
    for row in per_client:
        by_method.setdefault(str(row["method"]), []).append(row)
    anchor_clients = {row["client_id"] for row in by_method.get("FedAvg-LoRA", [])}
    mismatched = {
        method: sorted({row["client_id"] for row in method_rows} ^ anchor_clients)
        for method, method_rows in by_method.items()
        if anchor_clients and {row["client_id"] for row in method_rows} != anchor_clients
    }
    rows.append(_check(dataset, f"seed_{seed}:matched_client_sets", not mismatched, mismatched, {}))
    missing_direct = sorted(DIRECT_RECENT_LORA - set(by_method))
    rows.append(_check(dataset, f"seed_{seed}:recent_lora_coverage", not missing_direct, missing_direct, []))

    metric_map = {str(row["method"]): row for row in metrics}
    reconciliation = []
    for method, method_rows in by_method.items():
        if method not in metric_map:
            reconciliation.append((method, "missing_metric_row"))
            continue
        mean_accuracy = sum(float(row["accuracy"]) for row in method_rows) / len(method_rows)
        mean_loss = sum(float(row["loss"]) for row in method_rows) / len(method_rows)
        reported = metric_map[method]
        if not math.isclose(mean_accuracy, float(reported["mean_accuracy"]), abs_tol=1e-12, rel_tol=0.0):
            reconciliation.append((method, "accuracy", mean_accuracy, reported["mean_accuracy"]))
        if not math.isclose(mean_loss, float(reported["mean_loss"]), abs_tol=1e-12, rel_tol=0.0):
            reconciliation.append((method, "loss", mean_loss, reported["mean_loss"]))
    rows.append(_check(dataset, f"seed_{seed}:metric_reconciliation", not reconciliation,
                       reconciliation[:8], []))
    return rows


def _check(dataset: str, check: str, passed: bool, observed, expected) -> dict:
    return {
        "dataset": dataset,
        "check": check,
        "status": "pass" if passed else "fail",
        "observed": repr(observed),
        "expected": repr(expected),
    }


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _write_report(path: Path, rows: list[dict]) -> None:
    failures = [row for row in rows if row["status"] == "fail"]
    lines = [
        "# Recent-LoRA Data Quality Audit",
        "",
        f"- Checks: {len(rows)}",
        f"- Passed: {len(rows) - len(failures)}",
        f"- Failed: {len(failures)}",
        "",
        "## Failures",
    ]
    lines.extend(
        [f"- {row['dataset']} / {row['check']}: observed {row['observed']}; expected {row['expected']}" for row in failures]
        or ["- None"]
    )
    lines.extend([
        "",
        "The audit treats the federated seed as the independent replication unit. Client rows are used to verify matched coverage and metric reconstruction, not as independent seeds.",
    ])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
