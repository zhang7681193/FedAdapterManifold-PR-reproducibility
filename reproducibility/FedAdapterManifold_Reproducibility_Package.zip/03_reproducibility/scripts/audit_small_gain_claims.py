#!/usr/bin/env python3
"""Audit small/non-significant gain language against known boundary comparisons."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


UNSAFE = re.compile(r"\b(significant(?:ly)?|dominates?|outperforms\s+all|SOTA|consistently\s+outperforms)\b", re.I)
BOUNDARY_TERMS = [
    "FedPer-LoRA",
    "Ditto-LoRA",
    "BloodMNIST",
    "OfficeHome",
    "PACS-DINOv2",
    "CLIP-OfficeHome",
    "Geo-only",
]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="*", default=[
        "paper_resubmit/fedadaptermanifold_pr_resubmit.tex",
        "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.tex",
    ])
    ap.add_argument("--out", default="paper_resubmit/small_gain_claim_audit.md")
    args = ap.parse_args()

    errors: list[str] = []
    notes: list[str] = []
    for file in args.files:
        lines = Path(file).read_text(encoding="utf-8", errors="replace").splitlines()
        for i, line in enumerate(lines, 1):
            if UNSAFE.search(line) and any(term in line for term in BOUNDARY_TERMS):
                if not any(safe in line.lower() for safe in ("not significant", "do not claim", "interval crosses zero", "small", "no-regret")):
                    errors.append(f"{file}:{i}: unsafe language near boundary comparison: {line.strip()}")
            if any(term in line for term in BOUNDARY_TERMS) and any(x in line for x in ("0.0000", "-0.000", "crosses zero")):
                notes.append(f"{file}:{i}: boundary comparison explicitly labeled: {line.strip()}")

    report = ["# Small-Gain Claim Audit", "", "## Errors"]
    report += [f"- {e}" for e in errors] if errors else ["- None"]
    report += ["", "## Boundary Notes"]
    report += [f"- {n}" for n in notes[:80]] if notes else ["- None"]
    Path(args.out).write_text("\n".join(report) + "\n", encoding="utf-8")
    print(args.out)
    if errors:
        for e in errors:
            print("ERROR:", e, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
