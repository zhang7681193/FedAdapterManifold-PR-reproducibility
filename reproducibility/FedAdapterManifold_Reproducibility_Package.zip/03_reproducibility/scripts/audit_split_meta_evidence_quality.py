from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np


PRIMARY = "FedAdapterManifold-SplitMetaTargetParetoAdmit"


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit split-meta evidence integrity and fairness.")
    parser.add_argument("--root", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--primary-method", default=PRIMARY)
    parser.add_argument("--geometry-round", type=int, required=True)
    args = parser.parse_args()

    root = Path(args.root)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    checks: list[dict] = []
    for seed_dir in sorted(root.glob("seed_*"), key=lambda path: int(path.name.split("_")[-1])):
        seed = int(seed_dir.name.split("_")[-1])
        _check(checks, seed, "config_exists", (seed_dir / "config.yaml").is_file())
        config_text = (seed_dir / "config.yaml").read_text(encoding="utf-8")
        _check(checks, seed, "config_seed_matches_directory", f"seed: {seed}" in config_text)

        metrics = _read_csv(seed_dir / "metrics.csv")
        per_client = _read_csv(seed_dir / "per_client_metrics.csv")
        metric_methods = [row["method"] for row in metrics]
        _check(checks, seed, "metrics_method_unique", len(metric_methods) == len(set(metric_methods)))
        for method in ("Local-LoRA", args.primary_method, "IntrinsicPool-WithUnscreenedFull-Control"):
            method_metric = [row for row in metrics if row["method"] == method]
            method_clients = [row for row in per_client if row["method"] == method]
            _check(checks, seed, f"{method}_present", len(method_metric) == 1 and bool(method_clients))
            if len(method_metric) == 1 and method_clients:
                recomputed = float(np.mean([float(row["accuracy"]) for row in method_clients]))
                reported = float(method_metric[0]["mean_accuracy"])
                _check(
                    checks,
                    seed,
                    f"{method}_mean_accuracy_reconciles",
                    abs(recomputed - reported) <= 1e-12,
                    evidence={"reported": reported, "recomputed": recomputed},
                )

        key_pairs = [(row["method"], row["client_id"]) for row in per_client]
        _check(checks, seed, "per_client_method_key_unique", len(key_pairs) == len(set(key_pairs)))
        numeric_values = [
            float(row[field])
            for row in per_client
            for field in ("accuracy", "loss")
            if row.get(field, "") != ""
        ]
        _check(checks, seed, "per_client_metrics_finite", bool(numeric_values) and np.isfinite(numeric_values).all())
        _check(
            checks,
            seed,
            "accuracy_range_valid",
            all(0.0 <= value <= 1.0 for value in [
                float(row["accuracy"]) for row in per_client if row.get("accuracy", "") != ""
            ]),
        )

        admission = _read_csv(seed_dir / "split_meta_admit.csv")
        clients = sorted({row["client_id"] for row in admission})
        for client_id in clients:
            rows = [row for row in admission if row["client_id"] == client_id]
            selected = [row for row in rows if _as_bool(row["selected"])]
            _check(checks, seed, f"{client_id}_one_selected_candidate", len(selected) == 1)
            _check(
                checks,
                seed,
                f"{client_id}_fixed_pretest_pool",
                all(_as_bool(row["candidate_pool_fixed_pretest"]) for row in rows),
            )
            _check(
                checks,
                seed,
                f"{client_id}_test_not_used_for_selection",
                all(not _as_bool(row["test_used_for_selection"]) for row in rows),
            )
            _check(
                checks,
                seed,
                f"{client_id}_target_pareto_policy",
                all(row.get("selection_policy") == "target_pareto" for row in rows),
            )

        deltas = np.load(seed_dir / "local_anchor_deltas.npy")
        _check(checks, seed, "local_anchor_delta_shape", deltas.ndim == 3 and deltas.shape[0] == len(clients))
        _check(checks, seed, "local_anchor_deltas_finite", np.isfinite(deltas).all())

        geometry_dir = seed_dir / "geometry_outputs"
        d_geo = np.load(geometry_dir / f"d_geo_round_{args.geometry_round}.npy")
        graph = np.load(geometry_dir / f"geometry_graph_round_{args.geometry_round}.npy")
        expected = (len(clients), len(clients))
        _check(checks, seed, "d_geo_shape", d_geo.shape == expected)
        _check(checks, seed, "graph_shape", graph.shape == expected)
        _check(checks, seed, "d_geo_finite", np.isfinite(d_geo).all())
        _check(checks, seed, "graph_finite", np.isfinite(graph).all())
        _check(checks, seed, "d_geo_symmetric", np.allclose(d_geo, d_geo.T, atol=1e-10))
        _check(checks, seed, "d_geo_zero_diagonal", np.allclose(np.diag(d_geo), 0.0, atol=1e-10))

    failures = [row for row in checks if not row["passed"]]
    summary = {
        "root": str(root),
        "seed_count": len(list(root.glob("seed_*"))),
        "check_count": len(checks),
        "passed_checks": len(checks) - len(failures),
        "failed_checks": len(failures),
        "status": "PASS" if not failures else "FAIL",
    }
    _write_csv(output / "quality_checks.csv", checks)
    (output / "quality_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    lines = [
        "# Split-Meta Evidence Quality Audit",
        "",
        f"Status: **{summary['status']}**.",
        f"Seeds: {summary['seed_count']}.",
        f"Checks passed: {summary['passed_checks']}/{summary['check_count']}.",
        "",
    ]
    if failures:
        lines.extend(["## Failures", ""])
        lines.extend(f"- Seed {row['seed']}: {row['check']}." for row in failures)
    else:
        lines.append("No integrity or protocol violations were detected.")
    (output / "quality_report.md").write_text("\n".join(lines), encoding="utf-8")
    return 1 if failures else 0


def _check(
    rows: list[dict],
    seed: int,
    name: str,
    condition: bool,
    evidence: dict | None = None,
) -> None:
    rows.append(
        {
            "seed": seed,
            "check": name,
            "passed": bool(condition),
            "evidence": json.dumps(evidence or {}, sort_keys=True),
        }
    )


def _as_bool(value: str | bool) -> bool:
    return value is True or str(value).strip().lower() in {"true", "1", "yes"}


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
