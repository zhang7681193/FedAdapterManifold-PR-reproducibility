from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "results/direct_anchor_route_officehome_fedgeo_5seed_20260811"
RUN_ROOT = SOURCE / "officehome_clip_full"
OUTPUT = SOURCE / "target_constrained_utility_audit"
METHOD = "FedAdapterManifold-DirectAnchorRoute"
ANCHOR = "Local-LoRA"
SEED = 20260812


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit target-constrained direct routing.")
    parser.add_argument("--source", type=Path, default=SOURCE)
    parser.add_argument("--expected-seeds", type=int, default=5)
    return parser.parse_args()


def _as_bool(series: pd.Series) -> pd.Series:
    return series.astype(str).str.lower().isin({"true", "1", "yes"})


def _bootstrap_seed_means(values: np.ndarray, n_boot: int = 20000) -> tuple[float, float]:
    rng = np.random.default_rng(SEED)
    samples = rng.choice(values, size=(n_boot, len(values)), replace=True).mean(axis=1)
    return tuple(float(v) for v in np.quantile(samples, [0.025, 0.975]))


def _exact_sign_flip_p(values: np.ndarray) -> float:
    observed = float(np.mean(values))
    null = [
        float(np.mean(values * np.asarray(signs, dtype=np.float64)))
        for signs in itertools.product((-1.0, 1.0), repeat=len(values))
    ]
    # This is the complete 2^n randomization distribution, so no Monte Carlo
    # plus-one correction is needed.
    return float(np.count_nonzero(np.asarray(null) >= observed) / len(null))


def main() -> int:
    args = parse_args()
    source = args.source
    run_root = source / "officehome_clip_full"
    output = source / "target_constrained_utility_audit"
    output.mkdir(parents=True, exist_ok=True)
    selected_rows = []
    metric_rows = []
    incomplete = []
    for seed_dir in sorted(run_root.glob("seed_*")):
        seed = int(seed_dir.name.split("_")[-1])
        path = seed_dir / "cumulative_direct_anchor_route_admission.csv"
        metrics_path = seed_dir / "per_client_metrics.csv"
        if not path.exists() or not metrics_path.exists():
            incomplete.append(seed_dir.name)
            continue
        frame = pd.read_csv(path)
        selected = frame[_as_bool(frame["selected"])].copy()
        selected["seed"] = seed
        selected_rows.append(selected)
        metric_rows.append(pd.read_csv(metrics_path))
    if not selected_rows:
        raise FileNotFoundError(f"No completed direct-route runs under {run_root}")
    selected = pd.concat(selected_rows, ignore_index=True)
    seed_count = int(selected["seed"].nunique())
    expected_units = int(selected[["seed", "client_id"]].drop_duplicates().shape[0])
    if len(selected) != expected_units or selected.groupby(["seed", "client_id"]).size().ne(1).any():
        raise ValueError("Expected exactly one selected route for every completed seed-client unit")
    selected["nonlocal_selected"] = selected["transport_family"].astype(str) != "local_anchor"
    selected["strict_target_improvement"] = (
        selected["paired_error_difference_vs_anchor"].astype(float) < 0
    ) & (selected["paired_log_loss_difference_vs_anchor"].astype(float) < 0)
    selected["target_risk_certified"] = _as_bool(selected["certified_anchor_safe"]) & (
        selected["anchor_risk_upper_bound"].astype(float) <= 0
    )
    selected.to_csv(output / "selected_calibration_decisions.csv", index=False)

    metrics = pd.concat(metric_rows, ignore_index=True)
    paired = metrics[metrics["method"].isin([METHOD, ANCHOR])].pivot_table(
        index=["seed", "client_id", "domain"],
        columns="method",
        values="accuracy",
        aggfunc="first",
    ).reset_index()
    paired["accuracy_gain_vs_local"] = paired[METHOD] - paired[ANCHOR]
    paired.to_csv(output / "paired_test_accuracy.csv", index=False)
    seed_effects = paired.groupby("seed", as_index=False)["accuracy_gain_vs_local"].mean()
    seed_effects.to_csv(output / "seed_cluster_effects.csv", index=False)
    effects = seed_effects["accuracy_gain_vs_local"].to_numpy(dtype=np.float64)
    ci_low, ci_high = _bootstrap_seed_means(effects)

    nonlocal_rows = selected[selected["nonlocal_selected"]]
    summary = {
        "n_seed_client_units": int(len(selected)),
        "seed_count": seed_count,
        "complete_expected_seeds": bool(seed_count == args.expected_seeds),
        "n_nonlocal_admissions": int(selected["nonlocal_selected"].sum()),
        "n_local_fallbacks": int((~selected["nonlocal_selected"]).sum()),
        "nonlocal_strict_error_and_logloss_improvements": int(
            nonlocal_rows["strict_target_improvement"].sum()
        ),
        "nonlocal_target_risk_certified": int(nonlocal_rows["target_risk_certified"].sum()),
        "test_positive_units": int((paired["accuracy_gain_vs_local"] > 0).sum()),
        "test_tied_units": int(np.isclose(paired["accuracy_gain_vs_local"], 0).sum()),
        "test_negative_units": int((paired["accuracy_gain_vs_local"] < 0).sum()),
        "mean_test_accuracy_gain_vs_local": float(paired["accuracy_gain_vs_local"].mean()),
        "worst_test_accuracy_gain_vs_local": float(paired["accuracy_gain_vs_local"].min()),
        "seed_cluster_ci_low": ci_low,
        "seed_cluster_ci_high": ci_high,
        "seed_sign_flip_p_one_sided": _exact_sign_flip_p(effects),
        "utility_and_safety_confirmed": bool(
            len(nonlocal_rows) > 0
            and nonlocal_rows["strict_target_improvement"].all()
            and nonlocal_rows["target_risk_certified"].all()
            and float(paired["accuracy_gain_vs_local"].min()) >= 0
            and ci_low > 0
        ),
    }
    pd.DataFrame([summary]).to_csv(output / "target_constrained_utility_summary.csv", index=False)
    report = [
        "# Target-constrained admission: safety and non-zero utility",
        "",
        "This audit separates two necessary behaviors of a safe admission rule: rejecting inadmissible candidates and admitting useful candidates when the declared target-risk constraints are satisfied.",
        "",
        f"- Completed seeds: {seed_count}/{args.expected_seeds}; incomplete directories: {', '.join(incomplete) if incomplete else 'none'}.",
        f"- Non-local admissions: {summary['n_nonlocal_admissions']}/{len(selected)}; Local fallbacks: {summary['n_local_fallbacks']}/{len(selected)}.",
        f"- Non-local admissions with strict calibration error and log-loss improvements: {summary['nonlocal_strict_error_and_logloss_improvements']}/{summary['n_nonlocal_admissions']}.",
        f"- Non-local admissions satisfying the anchor-risk certificate: {summary['nonlocal_target_risk_certified']}/{summary['n_nonlocal_admissions']}.",
        f"- Test units positive/tied/negative versus Local: {summary['test_positive_units']}/{summary['test_tied_units']}/{summary['test_negative_units']}.",
        f"- Mean test gain versus Local: {summary['mean_test_accuracy_gain_vs_local']:.6f}; worst unit gain: {summary['worst_test_accuracy_gain_vs_local']:.6f}.",
        f"- Seed-cluster bootstrap 95% CI: [{ci_low:.6f}, {ci_high:.6f}]; exact one-sided sign-flip p={summary['seed_sign_flip_p_one_sided']:.6f}.",
        f"- Safety and non-zero utility confirmed: {summary['utility_and_safety_confirmed']}.",
        "",
        "The independent split-meta Target-Pareto experiment supplies the complementary reject-all negative control. Together, the two audits show that the gate is not a trivial always-local rule: it rejects candidates that fail the target constraints and admits candidates with independently observed utility when they pass.",
    ]
    (output / "target_constrained_utility_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(summary)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
