from __future__ import annotations

import argparse
import csv
from itertools import product
from pathlib import Path

import numpy as np


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Apply a calibration-only target-Pareto rule to frozen candidate logs."
    )
    parser.add_argument("--root", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--loss-tolerance", type=float, default=1e-3)
    parser.add_argument("--phase", default="retrospective_development")
    parser.add_argument("--bootstrap-samples", type=int, default=50000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260812)
    args = parser.parse_args()

    root = Path(args.root)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    seed_dirs = sorted(root.glob("seed_*"), key=lambda path: int(path.name.split("_")[-1]))
    if not seed_dirs:
        raise FileNotFoundError(f"No seed directories under {root}")

    paired_rows: list[dict] = []
    seed_rows: list[dict] = []
    for seed_dir in seed_dirs:
        seed = int(seed_dir.name.split("_")[-1])
        admission = _read_csv(seed_dir / "split_meta_admit.csv")
        by_client: dict[str, dict[str, dict]] = {}
        for row in admission:
            by_client.setdefault(row["client_id"], {})[row["candidate_family"]] = row
        current_seed_rows: list[dict] = []
        for client_id, candidates in sorted(by_client.items()):
            anchor = candidates["local_anchor"]
            fam = candidates["fam_split_meta"]
            ce_gain = float(anchor["calibration_log_loss"]) - float(
                fam["calibration_log_loss"]
            )
            error_difference = float(fam["calibration_error"]) - float(
                anchor["calibration_error"]
            )
            brier_difference = float(fam["calibration_brier"]) - float(
                anchor["calibration_brier"]
            )
            admitted = bool(
                ce_gain > float(args.loss_tolerance) + 1e-12
                and error_difference < -1e-12
                and brier_difference <= 1e-12
            )
            selected = fam if admitted else anchor
            local_accuracy = float(anchor["candidate_test_accuracy_audit"])
            selected_accuracy = float(selected["candidate_test_accuracy_audit"])
            row = {
                "phase": args.phase,
                "seed": seed,
                "client_id": client_id,
                "domain": anchor["domain"],
                "selection_rule": "target_pareto",
                "test_used_for_selection": False,
                "selected_family": selected["candidate_family"],
                "admitted": admitted,
                "calibration_size": int(anchor["calibration_size"]),
                "calibration_log_loss_gain_vs_anchor": ce_gain,
                "calibration_error_difference_vs_anchor": error_difference,
                "calibration_brier_difference_vs_anchor": brier_difference,
                "local_test_accuracy_audit": local_accuracy,
                "selected_test_accuracy_audit": selected_accuracy,
                "accuracy_gain_vs_local_audit": selected_accuracy - local_accuracy,
                "local_test_loss_audit": float(anchor["candidate_test_loss_audit"]),
                "selected_test_loss_audit": float(selected["candidate_test_loss_audit"]),
            }
            paired_rows.append(row)
            current_seed_rows.append(row)
        gains = np.asarray(
            [row["accuracy_gain_vs_local_audit"] for row in current_seed_rows],
            dtype=np.float64,
        )
        seed_rows.append(
            {
                "phase": args.phase,
                "seed": seed,
                "num_clients": len(current_seed_rows),
                "admitted_clients": sum(row["admitted"] for row in current_seed_rows),
                "mean_accuracy_gain_vs_local": float(gains.mean()),
                "worst_client_gain_vs_local": float(gains.min()),
                "positive_clients": int(np.sum(gains > 1e-12)),
                "tied_clients": int(np.sum(np.abs(gains) <= 1e-12)),
                "negative_clients": int(np.sum(gains < -1e-12)),
            }
        )

    seed_gains = np.asarray(
        [row["mean_accuracy_gain_vs_local"] for row in seed_rows], dtype=np.float64
    )
    pair_gains = np.asarray(
        [row["accuracy_gain_vs_local_audit"] for row in paired_rows], dtype=np.float64
    )
    ci_low, ci_high = _bootstrap_ci(
        seed_gains, int(args.bootstrap_samples), int(args.bootstrap_seed)
    )
    summary = {
        "phase": args.phase,
        "num_seeds": len(seed_rows),
        "num_client_seed_pairs": len(paired_rows),
        "admissions": sum(row["admitted"] for row in paired_rows),
        "mean_accuracy_gain_vs_local": float(seed_gains.mean()),
        "seed_clustered_ci_low": ci_low,
        "seed_clustered_ci_high": ci_high,
        "exact_one_sided_sign_flip_p": _sign_flip_p(seed_gains),
        "positive_seeds": int(np.sum(seed_gains > 1e-12)),
        "tied_seeds": int(np.sum(np.abs(seed_gains) <= 1e-12)),
        "negative_seeds": int(np.sum(seed_gains < -1e-12)),
        "positive_pairs": int(np.sum(pair_gains > 1e-12)),
        "tied_pairs": int(np.sum(np.abs(pair_gains) <= 1e-12)),
        "negative_pairs": int(np.sum(pair_gains < -1e-12)),
        "worst_pair_gain": float(pair_gains.min()),
    }
    _write_csv(output / "paired_client_seed_metrics.csv", paired_rows)
    _write_csv(output / "seed_metrics.csv", seed_rows)
    _write_csv(output / "summary.csv", [summary])
    (output / "summary.md").write_text(
        "\n".join(
            [
                "# Target-Pareto Candidate-Log Audit",
                "",
                f"Phase: {args.phase}.",
                f"Admissions: {summary['admissions']}/{summary['num_client_seed_pairs']}.",
                f"Mean accuracy gain vs Local: {summary['mean_accuracy_gain_vs_local']:.6f}.",
                "Seed-clustered 95% bootstrap CI: "
                f"[{summary['seed_clustered_ci_low']:.6f}, {summary['seed_clustered_ci_high']:.6f}].",
                f"Exact one-sided sign-flip p: {summary['exact_one_sided_sign_flip_p']:.6f}.",
                "Seed positive/tie/negative: "
                f"{summary['positive_seeds']}/{summary['tied_seeds']}/{summary['negative_seeds']}.",
                "Client-seed positive/tie/negative: "
                f"{summary['positive_pairs']}/{summary['tied_pairs']}/{summary['negative_pairs']}.",
                f"Worst paired gain: {summary['worst_pair_gain']:.6f}.",
            ]
        ),
        encoding="utf-8",
    )
    return 0


def _bootstrap_ci(values: np.ndarray, samples: int, seed: int) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, values.size, size=(max(samples, 1), values.size))
    means = values[indices].mean(axis=1)
    return float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def _sign_flip_p(values: np.ndarray) -> float:
    observed = float(values.mean())
    statistics = [
        float(np.mean(values * np.asarray(signs, dtype=np.float64)))
        for signs in product((-1.0, 1.0), repeat=values.size)
    ]
    return float(np.mean(np.asarray(statistics) >= observed - 1e-15))


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
