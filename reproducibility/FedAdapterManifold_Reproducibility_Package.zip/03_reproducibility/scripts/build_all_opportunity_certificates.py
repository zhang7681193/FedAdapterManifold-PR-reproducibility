#!/usr/bin/env python3
"""Build opportunity certificates for all audited FedAdapterManifold result roots."""

from __future__ import annotations

import argparse
import csv
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


DEFAULT_ROOTS: list[tuple[str, str]] = [
    ("PACS", "results/fam_pacs_manifest_fedavg_fedper_fam_5seed_v1"),
    ("DomainNetMini", "results/fam_domainnetmini_manifest_fedavg_fedper_fam_5seed_v1"),
    ("BloodMNIST", "results/fam_blood_manifest_fedavg_fedper_fam_5seed_v1"),
    ("Office-Caltech", "results/fam_officecaltech_neighbor_selector_fedrot_w050_v1"),
    ("PACS-DINOv2", "results/fam_dinov2_pacs_calib20_noregret_5seed_v1"),
    ("OfficeHome-DINOv2", "results/fam_dinov2_officehome_full_calib20_noregret_5seed_v1"),
    ("OfficeHome-CLIP", "results/fam_clip_officehome_full_calib20_noregret_5seed_v2"),
    (
        "OfficeHome-DINOv2-SelectorShrink",
        "results/fam_resolve_stage2_selectorshrink_20260629/officehome_dinov2",
    ),
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out-dir", default="results/fam_opportunity_certificates_20260629")
    parser.add_argument(
        "--roots",
        default="",
        help="Optional semicolon-separated label=path list. Defaults to audited evidence roots.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    roots = _parse_roots(args.roots) if args.roots else DEFAULT_ROOTS
    builder = ROOT / "scripts" / "build_opportunity_certificate.py"

    manifest_rows: list[dict] = []
    combined_rows: list[dict] = []
    for label, root_value in roots:
        result_root = ROOT / root_value
        safe_label = _safe_name(label)
        label_out = out_dir / safe_label
        seed_dirs = sorted(path for path in result_root.glob("seed_*") if path.is_dir()) if result_root.exists() else []
        has_standard_log = any((path / "adapter_candidate_selection.csv").exists() for path in seed_dirs)
        manifest_row = {
            "dataset": label,
            "result_root": str(result_root),
            "certificate_dir": str(label_out),
            "num_seed_dirs": len(seed_dirs),
            "has_standard_selector_log": has_standard_log,
            "status": "pending",
            "reason": "",
        }
        if not result_root.exists():
            manifest_row["status"] = "skipped"
            manifest_row["reason"] = "result_root_missing"
            manifest_rows.append(manifest_row)
            continue
        if not has_standard_log:
            manifest_row["status"] = "skipped"
            manifest_row["reason"] = "adapter_candidate_selection_missing"
            manifest_rows.append(manifest_row)
            continue
        cmd = [
            sys.executable,
            str(builder),
            "--root",
            str(result_root),
            "--out-dir",
            str(label_out),
        ]
        completed = subprocess.run(cmd, cwd=str(ROOT), check=False)
        if completed.returncode != 0:
            manifest_row["status"] = "failed"
            manifest_row["reason"] = f"builder_exit_{completed.returncode}"
            manifest_rows.append(manifest_row)
            continue
        summary_path = label_out / "opportunity_certificate_summary.csv"
        summary_rows = _read_csv(summary_path) if summary_path.exists() else []
        if summary_rows:
            row = dict(summary_rows[0])
            row["dataset"] = label
            row["result_root"] = str(result_root)
            row["certificate_dir"] = str(label_out)
            combined_rows.append(row)
        manifest_row["status"] = "complete"
        manifest_rows.append(manifest_row)

    _write_csv(out_dir / "opportunity_certificate_manifest.csv", manifest_rows)
    _write_csv(out_dir / "opportunity_certificate_combined_summary.csv", combined_rows)
    _write_markdown(out_dir / "opportunity_certificate_combined_report.md", manifest_rows, combined_rows)
    _write_latex(out_dir / "opportunity_certificate_table.tex", combined_rows)
    print(f"Wrote batch opportunity certificates to {out_dir}")
    return 0


def _parse_roots(value: str) -> list[tuple[str, str]]:
    out = []
    for item in value.split(";"):
        item = item.strip()
        if not item:
            continue
        if "=" not in item:
            raise ValueError(f"Root entry must be label=path, got {item!r}")
        label, path = item.split("=", 1)
        out.append((label.strip(), path.strip()))
    return out


def _safe_name(value: str) -> str:
    return "".join(ch.lower() if ch.isalnum() else "_" for ch in value).strip("_")


def _read_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _write_markdown(path: Path, manifest_rows: list[dict], combined_rows: list[dict]) -> None:
    lines = [
        "# FedAdapterManifold Opportunity Certificates",
        "",
        "This report aggregates opportunity/no-regret certificates for audited result roots that contain standard `adapter_candidate_selection.csv` logs.",
        "",
        "## Combined Summary",
        "",
        "| Dataset | Units | Ceiling | Positive transfer | Audit required | Gain vs FedAvg | Gain vs Geo |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in combined_rows:
        lines.append(
            "| {dataset} | {units} | {ceiling} | {positive} | {audit} | {fedavg} | {geo} |".format(
                dataset=row.get("dataset", ""),
                units=row.get("num_client_seed_units", ""),
                ceiling=row.get("certified_personalization_ceiling", ""),
                positive=row.get("positive_transfer_admitted", ""),
                audit=row.get("audit_required", ""),
                fedavg=_fmt(row.get("mean_seed_gain_vs_fedavg")),
                geo=_fmt(row.get("mean_seed_gain_vs_geo")),
            )
        )
    lines.extend(["", "## Manifest", "", "| Dataset | Status | Reason | Seeds | Result root |", "|---|---|---|---:|---|"])
    for row in manifest_rows:
        lines.append(
            "| {dataset} | {status} | {reason} | {seeds} | `{root}` |".format(
                dataset=row.get("dataset", ""),
                status=row.get("status", ""),
                reason=row.get("reason", ""),
                seeds=row.get("num_seed_dirs", ""),
                root=row.get("result_root", ""),
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_latex(path: Path, combined_rows: list[dict]) -> None:
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Opportunity-certified routing audit. Positive-transfer units indicate client-seed cases where the fixed calibration protocol admits a manifold-side adapter. Ceiling units indicate cases where the anchored no-regret rule certifies fallback to the fixed personalization anchor.}",
        r"\label{tab:opportunity_certificate}",
        r"\begin{tabular}{lrrrrr}",
        r"\toprule",
        r"Setting & Units & Ceiling & Positive & $\Delta$ FedAvg & $\Delta$ Geo \\",
        r"\midrule",
    ]
    for row in combined_rows:
        lines.append(
            "{} & {} & {} & {} & {} & {} \\\\".format(
                _latex_escape(row.get("dataset", "")),
                row.get("num_client_seed_units", ""),
                row.get("certified_personalization_ceiling", ""),
                row.get("positive_transfer_admitted", ""),
                _fmt(row.get("mean_seed_gain_vs_fedavg")),
                _fmt(row.get("mean_seed_gain_vs_geo")),
            )
        )
    lines.extend([r"\bottomrule", r"\end{tabular}", r"\end{table}", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def _latex_escape(value: str) -> str:
    return (
        str(value)
        .replace("\\", r"\textbackslash{}")
        .replace("_", r"\_")
        .replace("&", r"\&")
        .replace("%", r"\%")
        .replace("#", r"\#")
    )


def _fmt(value) -> str:
    try:
        return f"{float(value):+.6f}"
    except (TypeError, ValueError):
        return ""


if __name__ == "__main__":
    raise SystemExit(main())
