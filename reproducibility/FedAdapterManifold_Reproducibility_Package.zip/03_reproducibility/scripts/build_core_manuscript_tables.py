from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "results" / "core_manuscript_tables_20260812"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build historical development tables; not submission evidence."
    )
    parser.add_argument("--allow-development-evidence", action="store_true")
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def canonical_safety() -> list[dict[str, object]]:
    source = (
        ROOT
        / "results"
        / "fam_canonical_admission_gate_20260810"
        / "canonical_admission_units.csv"
    )
    rows = read_csv(source)
    settings = [
        "PACS",
        "Office-Caltech",
        "DomainNetMini",
        "BloodMNIST",
        "OfficeHome-DINOv2",
        "OfficeHome-CLIP",
    ]
    output: list[dict[str, object]] = []
    for setting in settings:
        group = [row for row in rows if row["setting"] == setting]
        by_seed: dict[int, list[dict[str, str]]] = defaultdict(list)
        for row in group:
            by_seed[int(row["seed"])].append(row)
        seed_fam = np.array(
            [np.mean([float(row["canonical_accuracy"]) for row in seed_rows]) for seed_rows in by_seed.values()]
        )
        seed_fedavg = np.array(
            [np.mean([float(row["fedavg_accuracy"]) for row in seed_rows]) for seed_rows in by_seed.values()]
        )
        seed_geo = np.array(
            [np.mean([float(row["geo_accuracy"]) for row in seed_rows]) for seed_rows in by_seed.values()]
        )
        seed_worst_delta = np.array(
            [
                min(float(row["canonical_accuracy"]) for row in seed_rows)
                - min(float(row["geo_accuracy"]) for row in seed_rows)
                for seed_rows in by_seed.values()
            ]
        )
        admitted = [row for row in group if int(row["manifold_accepted"]) == 1]
        positive = sum(row["selected_test_outcome"] == "beneficial" for row in admitted)
        negative = sum(row["selected_test_outcome"] == "harmful" for row in admitted)
        neutral = sum(row["selected_test_outcome"] == "neutral" for row in admitted)
        output.append(
            {
                "setting": setting,
                "seed_count": len(by_seed),
                "client_seed_units": len(group),
                "fedavg_accuracy": seed_fedavg.mean(),
                "geo_accuracy": seed_geo.mean(),
                "fam_accuracy": seed_fam.mean(),
                "fam_seed_sd": seed_fam.std(ddof=1),
                "delta_vs_fedavg": (seed_fam - seed_fedavg).mean(),
                "delta_vs_geo": (seed_fam - seed_geo).mean(),
                "worst_client_delta_vs_geo": seed_worst_delta.mean(),
                "share_coverage": len(admitted) / len(group),
                "admitted_positive": positive,
                "admitted_neutral": neutral,
                "admitted_negative": negative,
            }
        )
    return output


def e2e_summary() -> list[dict[str, object]]:
    settings = [
        (
            "PACS-7",
            ROOT / "results" / "fam_clip_vit_lora_federated_pacs_7class_5seed_v1",
        ),
        (
            "OfficeCaltech-10",
            ROOT / "results" / "fam_clip_vit_lora_federated_officecaltech_10class_5seed_v1",
        ),
        (
            "DomainNetMini-60",
            ROOT / "results" / "fam_clip_vit_lora_federated_domainnetmini_60class_5seed_v2",
        ),
    ]
    output: list[dict[str, object]] = []
    for setting, root in settings:
        means = {row["method"]: row for row in read_csv(root / "multiseed_metrics.csv")}
        selected_units = 0
        positive_units = 0
        neutral_units = 0
        negative_units = 0
        for seed in range(5):
            selections = [
                row
                for row in read_csv(root / f"seed_{seed}" / "candidate_selection.csv")
                if row["selected"].strip().lower() == "true"
            ]
            metrics = read_csv(root / f"seed_{seed}" / "per_client_metrics.csv")
            metric_index = {(row["client_id"], row["method"]): float(row["accuracy"]) for row in metrics}
            for row in selections:
                if row["candidate_method"] == "Local-CLIP-LoRA":
                    continue
                selected_units += 1
                client_id = row["client_id"]
                selected_acc = metric_index[(client_id, row["candidate_method"])]
                local_acc = metric_index[(client_id, "Local-CLIP-LoRA")]
                delta = selected_acc - local_acc
                if delta > 1e-12:
                    positive_units += 1
                elif delta < -1e-12:
                    negative_units += 1
                else:
                    neutral_units += 1
        output.append(
            {
                "setting": setting,
                "seed_count": 5,
                "local_accuracy": float(means["Local-CLIP-LoRA"]["mean_accuracy"]),
                "fedavg_accuracy": float(means["FedAvg-CLIP-LoRA"]["mean_accuracy"]),
                "lift_accuracy": float(means["FedAvg-Lift-CLIP-LoRA"]["mean_accuracy"]),
                "geo_accuracy": float(means["FedGeo-Agg-CLIP-LoRA"]["mean_accuracy"]),
                "fam_accuracy": float(means["FedAdapterManifold-Selective-CLIP-LoRA"]["mean_accuracy"]),
                "nonlocal_selected": selected_units,
                "positive_units_vs_local": positive_units,
                "neutral_units_vs_local": neutral_units,
                "negative_units_vs_local": negative_units,
            }
        )
    return output


def main() -> None:
    args = parse_args()
    if not args.allow_development_evidence:
        raise RuntimeError(
            "This builder reads the historical pre-certificate score gate and is "
            "blocked for submission use. Pass --allow-development-evidence only "
            "when intentionally regenerating the labelled supplement audit."
        )
    canonical = canonical_safety()
    e2e = e2e_summary()
    write_csv(OUTPUT / "canonical_safety_utility.csv", canonical)
    write_csv(OUTPUT / "end_to_end_clip_admission.csv", e2e)
    print(f"Wrote {len(canonical)} canonical rows and {len(e2e)} end-to-end rows")


if __name__ == "__main__":
    main()
