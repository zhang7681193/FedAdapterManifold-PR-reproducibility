from __future__ import annotations

import hashlib
import itertools
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
RUNS = {
    "cal48_marginal": ROOT / "results/fedtree_fam_admission_pacs_marginal_20260812",
    "cal48_prior_shift": ROOT / "results/fedtree_fam_admission_pacs_shift_20260812",
    "cal120_marginal": ROOT / "results/fedtree_fam_admission_pacs_cal120_marginal_20260812",
    "cal120_prior_shift": ROOT / "results/fedtree_fam_admission_pacs_cal120_shift_20260812",
}
METHOD = "FedAdapterManifold-FedTreeAnchorResidualAdmit"
ANCHOR = "FedTreeLoRA-Visual-Port"
SEED = 20260812


def _bootstrap(values: np.ndarray, replicates: int = 20000) -> tuple[float, float]:
    rng = np.random.default_rng(SEED)
    draws = rng.choice(values, size=(replicates, len(values)), replace=True).mean(axis=1)
    return tuple(float(value) for value in np.quantile(draws, [0.025, 0.975]))


def _sign_flip(values: np.ndarray) -> float:
    observed = float(values.mean())
    null = [
        float(np.mean(values * np.asarray(signs, dtype=np.float64)))
        for signs in itertools.product((-1.0, 1.0), repeat=len(values))
    ]
    return float(np.mean(np.asarray(null) >= observed - 1e-15))


def main() -> int:
    output = ROOT / "results/fedtree_fam_admission_evidence_20260812"
    output.mkdir(parents=True, exist_ok=True)
    unit_rows: list[pd.DataFrame] = []
    summary_rows: list[dict] = []
    hashed_files: list[Path] = []
    for protocol, run_root in RUNS.items():
        rows = []
        for path in sorted((run_root / "pacs_resnet18").glob("seed_*/per_client_metrics.csv")):
            frame = pd.read_csv(path)
            seed = int(path.parent.name.split("_")[-1])
            pivot = frame[frame["method"].isin([METHOD, ANCHOR])].pivot_table(
                index=["client_id", "domain"],
                columns="method",
                values="accuracy",
                aggfunc="first",
            ).reset_index()
            pivot["seed"] = seed
            pivot["gain_vs_fedtree"] = pivot[METHOD] - pivot[ANCHOR]
            rows.append(pivot)
            hashed_files.append(path)
            hashed_files.append(path.parent / "fedtree_anchor_residual_admission.csv")
        if len(rows) != 5:
            raise ValueError(f"{protocol}: expected five completed seeds, got {len(rows)}")
        units = pd.concat(rows, ignore_index=True)
        admissions = []
        for path in sorted((run_root / "pacs_resnet18").glob("seed_*/fedtree_anchor_residual_admission.csv")):
            frame = pd.read_csv(path)
            selected = frame[frame["selected"].astype(str).str.lower().isin({"true", "1", "yes"})]
            admissions.append(int((selected["transport_family"].astype(str) == "disagreement_blockwise").sum()))
        units.insert(0, "protocol", protocol)
        unit_rows.append(units)
        seed_effects = units.groupby("seed")["gain_vs_fedtree"].mean().to_numpy(dtype=np.float64)
        low, high = _bootstrap(seed_effects)
        summary_rows.append(
            {
                "protocol": protocol,
                "seed_count": int(units["seed"].nunique()),
                "client_seed_units": int(len(units)),
                "adapter_accuracy": float(units[METHOD].mean()),
                "fedtree_accuracy": float(units[ANCHOR].mean()),
                "mean_gain_vs_fedtree": float(units["gain_vs_fedtree"].mean()),
                "worst_gain_vs_fedtree": float(units["gain_vs_fedtree"].min()),
                "seed_ci_low": low,
                "seed_ci_high": high,
                "seed_sign_flip_p_one_sided": _sign_flip(seed_effects),
                "nonlocal_admissions": int(sum(admissions)),
                "positive_units": int((units["gain_vs_fedtree"] > 0).sum()),
                "tied_units": int(np.isclose(units["gain_vs_fedtree"], 0).sum()),
                "negative_units": int((units["gain_vs_fedtree"] < 0).sum()),
            }
        )
    pd.concat(unit_rows, ignore_index=True).to_csv(output / "client_seed_units.csv", index=False)
    pd.DataFrame(summary_rows).to_csv(output / "summary.csv", index=False)
    manifest = []
    for path in sorted(set(hashed_files)):
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        manifest.append({"path": str(path.relative_to(ROOT)), "sha256": digest})
    pd.DataFrame(manifest).to_csv(output / "input_sha256.csv", index=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
