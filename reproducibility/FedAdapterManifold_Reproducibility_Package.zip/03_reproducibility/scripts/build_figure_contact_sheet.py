from pathlib import Path
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
FIG_DIR = ROOT / "paper" / "figures"
OUT = FIG_DIR / "figure_contact_sheet.png"


def font(size, bold=False):
    candidates = [
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/calibrib.ttf" if bold else "C:/Windows/Fonts/calibri.ttf",
    ]
    for c in candidates:
        if Path(c).exists():
            return ImageFont.truetype(c, size)
    return ImageFont.load_default()


imgs = [
    p for p in sorted(FIG_DIR.glob("*.png"))
    if p.name != "figure_contact_sheet.png"
]

thumb_w, thumb_h = 560, 310
pad = 34
label_h = 42
cols = 2
rows = (len(imgs) + cols - 1) // cols
W = cols * thumb_w + (cols + 1) * pad
H = rows * (thumb_h + label_h) + (rows + 1) * pad

sheet = Image.new("RGB", (W, H), "white")
d = ImageDraw.Draw(sheet)
f_label = font(22, True)

for idx, p in enumerate(imgs):
    im = Image.open(p).convert("RGB")
    im.thumbnail((thumb_w, thumb_h), Image.LANCZOS)
    col = idx % cols
    row = idx // cols
    x = pad + col * (thumb_w + pad)
    y = pad + row * (thumb_h + label_h + pad)
    d.text((x, y), p.name, font=f_label, fill=(30, 41, 59))
    bx = x
    by = y + label_h
    d.rectangle((bx - 1, by - 1, bx + thumb_w + 1, by + thumb_h + 1), outline=(203, 213, 225), width=2)
    ix = bx + (thumb_w - im.width) // 2
    iy = by + (thumb_h - im.height) // 2
    sheet.paste(im, (ix, iy))

sheet.save(OUT, dpi=(180, 180))
print(OUT)
