from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from statistics import fmean


ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "paper_resubmit" / "final_evidence_registry.json"
MANUSCRIPT = ROOT / "paper_resubmit" / "fedadaptermanifold_pr_resubmit.tex"
OUTPUT = ROOT / "results" / "final_exact_manuscript_tables_20260813"

REQUIRED_FROZEN = {
    "exact_update_subspace_confirmation",
    "incremental_subspace_controlled",
    "pacs_canonical_exact_v7",
    "pacs_subspace_reg_endpoint_confirmation",
    "official_runtime_parity",
    "end_to_end_clip_shot4",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Rebuild submission-facing exact tables from frozen registered evidence."
    )
    parser.add_argument("--registry", type=Path, default=REGISTRY)
    parser.add_argument("--manuscript", type=Path, default=MANUSCRIPT)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        raise ValueError(f"Refusing to write an empty table: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def resolve_root(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else ROOT / path


def validate_entry(entry: dict) -> list[Path]:
    if entry.get("status") != "frozen":
        raise RuntimeError(
            f"Submission table source {entry['id']} is {entry.get('status')}, not frozen."
        )
    root = resolve_root(entry["root"])
    sources: list[Path] = []
    for relative in entry.get("required_files", []):
        path = root / relative
        if not path.is_file():
            raise FileNotFoundError(f"Missing registered source: {path}")
        sources.append(path)
    for check in entry.get("recursive_checks", []):
        matches = sorted(root.glob(check["glob"]))
        expected = int(check["exact_count"])
        if len(matches) != expected:
            raise RuntimeError(
                f"{entry['id']} glob {check['glob']} has {len(matches)} files, expected {expected}."
            )
        sources.extend(matches)
    for check in entry.get("csv_checks", []):
        path = root / check["file"]
        if not path.is_file():
            raise FileNotFoundError(f"Missing registered CSV: {path}")
        count = len(read_csv(path))
        if "exact_rows" in check and count != int(check["exact_rows"]):
            raise RuntimeError(
                f"{path} has {count} rows, expected {int(check['exact_rows'])}."
            )
        if "minimum_rows" in check and count < int(check["minimum_rows"]):
            raise RuntimeError(
                f"{path} has {count} rows, expected at least {int(check['minimum_rows'])}."
            )
        sources.append(path)
    return sorted(set(sources))


def mean_method(rows: list[dict[str, str]], method: str) -> float:
    values = [float(row["accuracy"]) for row in rows if row["method"] == method]
    if not values:
        raise RuntimeError(f"No rows found for method {method}.")
    return fmean(values)


def canonical_row(root: Path) -> dict[str, object]:
    metrics = read_csv(root / "all_seed_per_client_metrics.csv")
    units = read_csv(root / "exact_receiver_admission_statistics" / "exact_receiver_units.csv")
    summary_rows = read_csv(root / "exact_receiver_admission_statistics" / "exact_receiver_summary.csv")
    if len(units) != 20 or len(summary_rows) != 1:
        raise RuntimeError("Canonical PACS evidence must contain 20 units and one summary row.")
    local = mean_method(metrics, "Local-LoRA")
    geo = mean_method(metrics, "FedGeo-Agg")
    if not math.isclose(local, geo, abs_tol=1e-12):
        raise RuntimeError("The declared Local/Geo canonical anchor is not byte-equivalent.")
    candidate = fmean(
        float(row["fam_candidate_accuracy_gain_over_local"])
        + next(
            float(metric["accuracy"])
            for metric in metrics
            if metric["method"] == "Local-LoRA"
            and int(metric["seed"]) == int(row["seed"])
            and metric["client_id"] == row["client_id"]
        )
        for row in units
    )
    deploy = fmean(
        float(row["selected_accuracy_gain_over_local"])
        + next(
            float(metric["accuracy"])
            for metric in metrics
            if metric["method"] == "Local-LoRA"
            and int(metric["seed"]) == int(row["seed"])
            and metric["client_id"] == row["client_id"]
        )
        for row in units
    )
    summary = summary_rows[0]
    return {
        "protocol": "Local/Geo",
        "anchor_accuracy": local,
        "candidate_accuracy": candidate,
        "deploy_accuracy": deploy,
        "gain": float(summary["mean_accuracy_gain_over_local"]),
        "ci95_low": float(summary["accuracy_gain_ci95_low"]),
        "ci95_high": float(summary["accuracy_gain_ci95_high"]),
        "admissions": int(summary["nonlocal_admission_count"]),
        "units": int(summary["unit_count"]),
        "harmful": int(summary["harmful_admission_count"]),
        "uncertified": int(summary["uncertified_deployment_count"]),
    }


def subspace_reg_row(root: Path) -> dict[str, object]:
    metrics: list[dict[str, str]] = []
    for path in sorted((root / "pacs_resnet18").glob("seed_*/per_client_metrics.csv")):
        metrics.extend(read_csv(path))
    units = read_csv(root / "analysis" / "subspace_reg_endpoint_client_seed_units.csv")
    summary_rows = read_csv(root / "analysis" / "subspace_reg_endpoint_summary.csv")
    if len(units) != 20 or len(summary_rows) != 1:
        raise RuntimeError("Subspace-Reg endpoint evidence must contain 20 units and one summary row.")
    summary = summary_rows[0]
    if any(row["test_used_for_selection"].strip().lower() != "false" for row in units):
        raise RuntimeError("A Subspace-Reg endpoint unit used test data for selection.")
    return {
        "protocol": "Subspace-Reg",
        "anchor_accuracy": mean_method(metrics, "Subspace-Reg-LoRA-Visual-Port"),
        "candidate_accuracy": mean_method(metrics, "FedAdapterManifold-Admit"),
        "deploy_accuracy": fmean(float(row["selected_accuracy"]) for row in units),
        "gain": float(summary["mean_gain_vs_anchor"]),
        "ci95_low": float(summary["seed_cluster_ci_low"]),
        "ci95_high": float(summary["seed_cluster_ci_high"]),
        "admissions": int(summary["nonanchor_admissions"]),
        "units": int(summary["client_seed_units"]),
        "harmful": int(summary["harmful_units_vs_anchor"]),
        "uncertified": 0,
    }


def mechanism_rows(exact_root: Path, incremental_root: Path) -> list[dict[str, object]]:
    exact = read_csv(exact_root / "confirmation_summary.csv")
    incremental = read_csv(incremental_root / "incremental_effect_summary.csv")
    if len(exact) != 1 or len(incremental) != 1:
        raise RuntimeError("Mechanism summaries must each contain exactly one row.")
    exact_row = exact[0]
    inc_row = incremental[0]
    return [
        {
            "diagnostic": "gauge_invariant_exact_update",
            "standardized_d_sub_beta": float(exact_row["mean_controlled_standardized_subspace_beta"]),
            "ci95_low": float(exact_row["seed_cluster_ci_low"]),
            "ci95_high": float(exact_row["seed_cluster_ci_high"]),
            "partial_r": "",
            "incremental_r2": "",
            "directional_pairs": int(exact_row["n_directional_pairs"]),
        },
        {
            "diagnostic": "controlled_incremental",
            "standardized_d_sub_beta": float(inc_row["d_sub_standardized_beta"]),
            "ci95_low": float(inc_row["hierarchical_ci_low"]),
            "ci95_high": float(inc_row["hierarchical_ci_high"]),
            "partial_r": float(inc_row["partial_r"]),
            "incremental_r2": float(inc_row["incremental_r2"]),
            "directional_pairs": int(inc_row["n_rows"]),
        },
    ]


def manuscript_literals(rows: list[dict[str, object]]) -> list[str]:
    def rounded(value: object) -> str:
        stable = Decimal(format(float(value), ".12f"))
        return format(stable.quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP), "f")

    def decimal(value: object) -> str:
        return rounded(value).replace("-0.", "-.").replace("0.", ".")

    def signed(value: object) -> str:
        value_text = rounded(value)
        if not value_text.startswith("-"):
            value_text = "+" + value_text
        return value_text.replace("+0.", "+.").replace("-0.", "-.")

    output = []
    for row in rows:
        output.append(
            f"{row['protocol']} & {decimal(row['anchor_accuracy'])} & "
            f"{decimal(row['candidate_accuracy'])} & {decimal(row['deploy_accuracy'])} & "
            f"{signed(row['gain'])} [{decimal(row['ci95_low'])},{decimal(row['ci95_high'])}] & "
            f"{int(row['admissions'])}/{int(row['units'])} & {int(row['harmful'])} & "
            f"{int(row['uncertified'])}"
        )
    return output


def main() -> int:
    args = parse_args()
    registry = json.loads(args.registry.read_text(encoding="utf-8"))
    entries = {entry["id"]: entry for entry in registry["entries"]}
    missing = REQUIRED_FROZEN - set(entries)
    if missing:
        raise RuntimeError(f"Registry is missing required frozen entries: {sorted(missing)}")

    source_files: list[Path] = [args.registry]
    for entry_id in sorted(REQUIRED_FROZEN):
        source_files.extend(validate_entry(entries[entry_id]))

    canonical_root = resolve_root(entries["pacs_canonical_exact_v7"]["root"])
    endpoint_root = resolve_root(entries["pacs_subspace_reg_endpoint_confirmation"]["root"])
    exact_root = resolve_root(entries["exact_update_subspace_confirmation"]["root"])
    incremental_root = resolve_root(entries["incremental_subspace_controlled"]["root"])

    receiver_rows = [canonical_row(canonical_root), subspace_reg_row(endpoint_root)]
    mechanisms = mechanism_rows(exact_root, incremental_root)
    write_csv(args.output / "core_exact_receiver_admission.csv", receiver_rows)
    write_csv(args.output / "mechanism_diagnostics.csv", mechanisms)

    manuscript = args.manuscript.read_text(encoding="utf-8")
    expected_literals = manuscript_literals(receiver_rows)
    missing_literals = [literal for literal in expected_literals if literal not in manuscript]

    manifest_rows = []
    for path in sorted(set(source_files)):
        manifest_rows.append(
            {
                "path": str(path.resolve()),
                "size": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
    write_csv(args.output / "source_hash_manifest.csv", manifest_rows)

    report = [
        "# Final Exact Manuscript Table Audit",
        "",
        "- All table sources are registered as frozen.",
        "- Client-level values were recomputed rather than copied from manuscript prose.",
        f"- Manuscript literal check: {'PASS' if not missing_literals else 'FAIL'}.",
        "",
        "## Receiver-admission rows",
        "",
    ]
    for row in receiver_rows:
        report.append(
            f"- {row['protocol']}: anchor={row['anchor_accuracy']:.6f}, "
            f"candidate={row['candidate_accuracy']:.6f}, deploy={row['deploy_accuracy']:.6f}, "
            f"gain={row['gain']:+.6f}, CI=[{row['ci95_low']:.6f},{row['ci95_high']:.6f}], "
            f"admit={row['admissions']}/{row['units']}, harm={row['harmful']}, "
            f"uncertified={row['uncertified']}."
        )
    report.extend(["", "## Missing manuscript literals", ""])
    report.extend(f"- `{literal}`" for literal in missing_literals)
    if not missing_literals:
        report.append("- None.")
    (args.output / "audit_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")

    print(json.dumps({"output": str(args.output), "missing_literals": missing_literals}, indent=2))
    return 1 if missing_literals else 0


if __name__ == "__main__":
    raise SystemExit(main())
