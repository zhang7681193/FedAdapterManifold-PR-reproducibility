from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import pickle
import shutil
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "paper_resubmit" / "final_evidence_registry.json"
DEFAULT_OUTPUT = ROOT / "results" / "geometry_contract_20260813"

PROTOCOL_FILES = {
    "client_signatures": ".pkl",
    "d_geo": ".npy",
    "geometry_graph": ".npy",
    "novelty_scores": ".csv",
    "coverage_deficit": ".csv",
    "prototypes": ".pkl",
}
OPTIONAL_FILES = {
    "risk_geo_scores": ".csv",
    "feature_energy_deficit": ".csv",
    "label_breadth_scores": ".csv",
}


@dataclass(frozen=True)
class Source:
    evidence_id: str
    dataset: str
    seed: int
    round_id: int
    geometry_dir: Path
    role: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Freeze geometry inputs used by FedAdapterManifold and audit provider drift "
            "without retraining adapters."
        )
    )
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument(
        "--provider-results-root",
        type=Path,
        default=None,
        help=(
            "FedGeo results root. If omitted, the script checks the FEDGEO_RESULTS_ROOT "
            "environment variable and the sibling FedGeo workspace."
        ),
    )
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def combined_sha(rows: Iterable[tuple[str, str]]) -> str:
    payload = "\n".join(f"{name}:{digest}" for name, digest in sorted(rows))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def infer_provider_root(explicit: Path | None) -> Path:
    import os

    candidates: list[Path] = []
    if explicit is not None:
        candidates.append(explicit)
    if os.environ.get("FEDGEO_RESULTS_ROOT"):
        candidates.append(Path(os.environ["FEDGEO_RESULTS_ROOT"]))
    candidates.append(ROOT.parent / "you-are-implementing-the-first-and" / "results")
    for candidate in candidates:
        resolved = candidate.expanduser().resolve()
        if resolved.is_dir():
            return resolved
    raise FileNotFoundError(
        "Could not locate the FedGeo results root. Pass --provider-results-root or "
        "set FEDGEO_RESULTS_ROOT."
    )


def safe_clean(path: Path) -> None:
    resolved = path.resolve()
    allowed = (ROOT / "results").resolve()
    if allowed not in resolved.parents:
        raise RuntimeError(f"Refusing to clean a non-results path: {resolved}")
    if resolved.exists():
        shutil.rmtree(resolved)
    resolved.mkdir(parents=True)


def parse_scalar_config(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    if not path.is_file():
        return values
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        values[key.strip()] = value.strip().strip("'\"")
    return values


def infer_dataset(path: Path, config: dict[str, str]) -> str:
    text = path.as_posix().lower()
    if "officecaltech" in text or "office_caltech" in text:
        return "OfficeCaltech"
    if "officehome" in text or "office_home" in text:
        return "OfficeHome"
    if "domainnet" in text:
        return "DomainNetMini"
    if "blood" in text:
        return "BloodMNIST"
    if "pacs" in text:
        return "PACS"
    return config.get("dataset", "unknown")


def infer_seed(path: Path, config: dict[str, str]) -> int:
    if "seed" in config:
        try:
            return int(config["seed"])
        except ValueError:
            pass
    import re

    matches = re.findall(r"seed[_-]?(\d+)", path.as_posix(), flags=re.I)
    if not matches:
        raise ValueError(f"Could not infer seed from {path}")
    return int(matches[-1])


def infer_round(path: Path, config: dict[str, str]) -> int:
    for key in ("round_id", "geometry_round"):
        if key in config:
            try:
                return int(config[key])
            except ValueError:
                pass
    import re

    rounds: set[int] = set()
    for file in path.iterdir():
        match = re.search(r"_round_(\d+)\.", file.name)
        if match:
            rounds.add(int(match.group(1)))
    if len(rounds) == 1:
        return rounds.pop()
    raise ValueError(f"Could not infer a unique round from {path}: {sorted(rounds)}")


def client_order(geometry_dir: Path, round_id: int, config: dict[str, str]) -> list[str]:
    domains = config.get("effective_client_domains") or config.get("domains")
    if domains:
        return [item.strip() for item in domains.split(",") if item.strip()]
    prototype_path = geometry_dir / f"prototypes_round_{round_id}.pkl"
    if prototype_path.is_file():
        try:
            with prototype_path.open("rb") as stream:
                prototypes = pickle.load(stream)
            if isinstance(prototypes, dict) and prototypes:
                keys = list(prototypes.keys())
                if all(str(key).startswith("client_") for key in keys):
                    return [str(key) for key in keys]
        except (ImportError, ModuleNotFoundError):
            # Some legacy summaries contain Torch tensors. Client order is a
            # protocol property, so a missing optional tensor runtime must not
            # make the snapshot contract itself non-portable.
            pass
    matrix = np.load(geometry_dir / f"d_geo_round_{round_id}.npy")
    return [f"client_{index}" for index in range(matrix.shape[0])]


def protocol_paths(source: Source) -> list[Path]:
    paths = [
        source.geometry_dir / f"{stem}_round_{source.round_id}{suffix}"
        for stem, suffix in PROTOCOL_FILES.items()
    ]
    missing = [path for path in paths if not path.is_file()]
    if missing:
        raise FileNotFoundError(
            f"{source.evidence_id} is missing protocol files: "
            + ", ".join(path.name for path in missing)
        )
    for stem, suffix in OPTIONAL_FILES.items():
        path = source.geometry_dir / f"{stem}_round_{source.round_id}{suffix}"
        if path.is_file():
            paths.append(path)
    return paths


def source_from_geometry_dir(evidence_id: str, geometry_dir: Path, role: str) -> Source:
    config = parse_scalar_config(geometry_dir.parent / "config.yaml")
    return Source(
        evidence_id=evidence_id,
        dataset=infer_dataset(geometry_dir, config),
        seed=infer_seed(geometry_dir, config),
        round_id=infer_round(geometry_dir, config),
        geometry_dir=geometry_dir.resolve(),
        role=role,
    )


def collect_sources(provider_root: Path) -> list[Source]:
    sources: list[Source] = []
    registry = json.loads(REGISTRY.read_text(encoding="utf-8"))
    for entry in registry["entries"]:
        if (
            entry.get("status") != "frozen"
            or not entry.get("submission_eligible", True)
        ):
            continue
        entry_root = Path(entry["root"])
        if not entry_root.is_absolute():
            entry_root = ROOT / entry_root
        for geometry_dir in sorted(entry_root.rglob("geometry_outputs")):
            lower_parts = {part.lower() for part in geometry_dir.parts}
            if "quarantined_wrong_import" in lower_parts or any(
                "wrong_import" in part for part in lower_parts
            ):
                continue
            sources.append(
                source_from_geometry_dir(entry["id"], geometry_dir, "frozen_registry")
            )

    main_roots = {
        "main_pacs": ROOT / "results/fam_pacs_manifest_fedavg_fedper_fam_5seed_v1",
        "main_officecaltech": ROOT
        / "results/fam_officecaltech_neighbor_selector_fedrot_w050_v1",
        "main_domainnetmini": ROOT
        / "results/fam_domainnetmini_manifest_fedavg_fedper_fam_5seed_v1",
        "main_bloodmnist": ROOT
        / "results/fam_blood_manifest_fedavg_fedper_fam_5seed_v1",
    }
    for evidence_id, entry_root in main_roots.items():
        for geometry_dir in sorted(entry_root.rglob("geometry_outputs")):
            sources.append(source_from_geometry_dir(evidence_id, geometry_dir, "main_table"))

    office_templates = {
        0: "office_home_pretrained_guardfull_faironly",
        1: "office_home_pretrained_guardfull_faironly_seed1",
        2: "office_home_pretrained_guardfull_faironly_seed2",
        3: "office_home_pretrained_guardfull_faironly_seed3",
        4: "office_home_pretrained_guardfull_faironly_seed4",
    }
    for seed, run_name in office_templates.items():
        geometry_dir = provider_root / run_name / "fedavg" / "geometry_outputs"
        source = Source(
            evidence_id="main_officehome",
            dataset="OfficeHome",
            seed=seed,
            round_id=4,
            geometry_dir=geometry_dir.resolve(),
            role="main_table",
        )
        protocol_paths(source)
        sources.append(source)
    return sources


def snapshot_key(source: Source) -> tuple[str, list[Path], list[tuple[str, str]]]:
    files = protocol_paths(source)
    hashes = [(path.name, sha256(path)) for path in files]
    return combined_sha(hashes), files, hashes


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys()) if rows else []
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def freeze_snapshots(sources: list[Source], output: Path) -> tuple[list[dict], list[dict]]:
    grouped: dict[str, dict] = {}
    for source in sources:
        fingerprint, files, hashes = snapshot_key(source)
        row = grouped.setdefault(
            fingerprint,
            {
                "fingerprint": fingerprint,
                "dataset": source.dataset,
                "seed": source.seed,
                "round_id": source.round_id,
                "files": files,
                "hashes": hashes,
                "references": set(),
                "roles": set(),
                "source_dir": source.geometry_dir,
            },
        )
        if (row["dataset"], row["seed"], row["round_id"]) != (
            source.dataset,
            source.seed,
            source.round_id,
        ):
            raise ValueError(f"Hash collision across incompatible snapshots: {fingerprint}")
        row["references"].add(source.evidence_id)
        row["roles"].add(source.role)

    snapshot_rows: list[dict] = []
    file_rows: list[dict] = []
    for fingerprint, item in sorted(
        grouped.items(), key=lambda pair: (pair[1]["dataset"], pair[1]["seed"], pair[0])
    ):
        snapshot_id = (
            f"{item['dataset'].lower()}_seed{item['seed']}_round{item['round_id']}_"
            f"{fingerprint[:12]}"
        )
        destination = output / "snapshots" / snapshot_id / "geometry_outputs"
        destination.mkdir(parents=True, exist_ok=True)
        config = parse_scalar_config(item["source_dir"].parent / "config.yaml")
        order = client_order(item["source_dir"], item["round_id"], config)
        d_geo = np.load(item["source_dir"] / f"d_geo_round_{item['round_id']}.npy")
        graph = np.load(
            item["source_dir"] / f"geometry_graph_round_{item['round_id']}.npy"
        )
        if d_geo.shape != graph.shape or d_geo.shape[0] != len(order):
            raise ValueError(
                f"Client-order mismatch for {snapshot_id}: d_geo={d_geo.shape}, "
                f"graph={graph.shape}, clients={len(order)}"
            )
        for source_file in item["files"]:
            target = destination / source_file.name
            shutil.copy2(source_file, target)
            file_rows.append(
                {
                    "snapshot_id": snapshot_id,
                    "filename": source_file.name,
                    "sha256": sha256(target),
                    "bytes": target.stat().st_size,
                    "required_six_file_protocol": int(
                        source_file.name.split("_round_")[0] in PROTOCOL_FILES
                    ),
                }
            )
        snapshot_rows.append(
            {
                "snapshot_id": snapshot_id,
                "dataset": item["dataset"],
                "seed": item["seed"],
                "round_id": item["round_id"],
                "num_clients": len(order),
                "client_order": ";".join(order),
                "snapshot_sha256": fingerprint,
                "evidence_references": ";".join(sorted(item["references"])),
                "roles": ";".join(sorted(item["roles"])),
                "relative_geometry_dir": (
                    Path("snapshots") / snapshot_id / "geometry_outputs"
                ).as_posix(),
            }
        )
    write_csv(output / "geometry_snapshot_manifest.csv", snapshot_rows)
    write_csv(output / "geometry_file_manifest.csv", file_rows)
    return snapshot_rows, file_rows


def normalized_distance(matrix: np.ndarray) -> np.ndarray:
    matrix = np.asarray(matrix, dtype=float)
    mask = ~np.eye(matrix.shape[0], dtype=bool)
    positive = matrix[mask & np.isfinite(matrix) & (matrix > 0)]
    scale = float(np.median(positive)) if positive.size else 1.0
    return matrix / max(scale, 1e-12)


def route_weights(distance: np.ndarray, graph: np.ndarray, lambda_geo: float = 0.5) -> np.ndarray:
    n = distance.shape[0]
    weights = np.zeros((n, n), dtype=float)
    for receiver in range(n):
        support = graph[receiver] > 0
        support[receiver] = True
        logits = -lambda_geo * distance[receiver, support]
        logits -= logits.max()
        values = np.exp(logits)
        weights[receiver, support] = values / values.sum()
    return weights


def deterministic_symmetric_noise(n: int, seed: int) -> np.ndarray:
    generator = np.random.default_rng(seed)
    noise = generator.normal(size=(n, n))
    noise = (noise + noise.T) / 2.0
    np.fill_diagonal(noise, 0.0)
    maximum = float(np.max(np.abs(noise)))
    return noise / maximum if maximum else noise


def controlled_perturbation_audit(snapshot_rows: list[dict], output: Path) -> list[dict]:
    rows: list[dict] = []
    for index, snapshot in enumerate(snapshot_rows):
        if "main_table" not in snapshot["roles"].split(";"):
            continue
        geometry_dir = output / snapshot["relative_geometry_dir"]
        round_id = int(snapshot["round_id"])
        d_geo = normalized_distance(np.load(geometry_dir / f"d_geo_round_{round_id}.npy"))
        graph = np.load(geometry_dir / f"geometry_graph_round_{round_id}.npy")
        baseline = route_weights(d_geo, graph)
        noise = deterministic_symmetric_noise(d_geo.shape[0], 1000 + index)
        scale = max(float(np.max(np.abs(d_geo))), 1.0)
        for relative_level in (0.01, 0.05, 0.10):
            perturbed = np.maximum(d_geo + relative_level * scale * noise, 0.0)
            np.fill_diagonal(perturbed, 0.0)
            candidate = route_weights(perturbed, graph)
            epsilon = 0.5 * float(np.max(np.abs(perturbed - d_geo)))
            bound = min(2.0, 2.0 * math.tanh(epsilon))
            for receiver in range(d_geo.shape[0]):
                l1 = float(np.sum(np.abs(candidate[receiver] - baseline[receiver])))
                rows.append(
                    {
                        "snapshot_id": snapshot["snapshot_id"],
                        "dataset": snapshot["dataset"],
                        "seed": snapshot["seed"],
                        "receiver": receiver,
                        "relative_distance_perturbation": relative_level,
                        "actual_route_l1": l1,
                        "theoretical_l1_bound": bound,
                        "bound_pass": int(l1 <= bound + 1e-12),
                        "top_donor_changed": int(
                            int(np.argmax(candidate[receiver]))
                            != int(np.argmax(baseline[receiver]))
                        ),
                        "support_changed": 0,
                    }
                )
    write_csv(output / "provider_drift_audit/controlled_perturbation_units.csv", rows)
    return rows


def compare_provider_roots(provider_root: Path, output: Path) -> list[dict]:
    settings = [
        (
            "PACS",
            "pacs_pretrained_unfrozen_active_sparse30_10round_compare_seed{seed}",
            9,
        ),
        (
            "OfficeCaltech",
            "office_caltech_pretrained_unfrozen_active_sparse30_compare_seed{seed}",
            4,
        ),
    ]
    rows: list[dict] = []
    input_root = output / "provider_drift_audit/alternate_provider_inputs"
    for dataset, template, round_id in settings:
        for seed in range(3):
            run_root = provider_root / template.format(seed=seed)
            base_dir = run_root / "fedavg" / "geometry_outputs"
            base_d = normalized_distance(np.load(base_dir / f"d_geo_round_{round_id}.npy"))
            base_g = np.load(base_dir / f"geometry_graph_round_{round_id}.npy")
            base_w = route_weights(base_d, base_g)
            for provider in ("topk", "utility_only", "fedgeo_full"):
                variant_dir = run_root / provider / "geometry_outputs"
                d_path = variant_dir / f"d_geo_round_{round_id}.npy"
                g_path = variant_dir / f"geometry_graph_round_{round_id}.npy"
                variant_d = normalized_distance(np.load(d_path))
                variant_g = np.load(g_path)
                variant_w = route_weights(variant_d, variant_g)
                dataset_code = {"PACS": "p", "OfficeCaltech": "oc"}[dataset]
                provider_code = {
                    "topk": "t",
                    "utility_only": "u",
                    "fedgeo_full": "f",
                }[provider]
                destination = input_root / dataset_code / f"s{seed}" / provider_code
                destination.mkdir(parents=True, exist_ok=True)
                shutil.copy2(d_path, destination / d_path.name)
                shutil.copy2(g_path, destination / g_path.name)
                for receiver in range(base_d.shape[0]):
                    base_support = set(np.flatnonzero(base_g[receiver] > 0).tolist())
                    variant_support = set(np.flatnonzero(variant_g[receiver] > 0).tolist())
                    base_support.add(receiver)
                    variant_support.add(receiver)
                    union = base_support | variant_support
                    intersection = base_support & variant_support
                    support_same = base_support == variant_support
                    rows.append(
                        {
                            "dataset": dataset,
                            "seed": seed,
                            "round_id": round_id,
                            "base_provider": "fedavg",
                            "candidate_provider": provider,
                            "receiver": receiver,
                            "support_jaccard": len(intersection) / len(union),
                            "support_identical": int(support_same),
                            "route_l1": float(
                                np.sum(np.abs(variant_w[receiver] - base_w[receiver]))
                            ),
                            "top_donor_changed": int(
                                int(np.argmax(variant_w[receiver]))
                                != int(np.argmax(base_w[receiver]))
                            ),
                            "automatic_replacement_allowed": 0,
                            "required_action": (
                                "replay_admission_certificate"
                                if support_same
                                else "regenerate_endpoint_and_replay_certificate"
                            ),
                            "d_geo_sha256": sha256(destination / d_path.name),
                            "graph_sha256": sha256(destination / g_path.name),
                        }
                    )
    write_csv(output / "provider_drift_audit/cross_provider_units.csv", rows)
    return rows


def summarize_audit(controlled: list[dict], cross: list[dict], output: Path) -> dict:
    levels = sorted({float(row["relative_distance_perturbation"]) for row in controlled})
    controlled_summary = []
    for level in levels:
        subset = [row for row in controlled if float(row["relative_distance_perturbation"]) == level]
        controlled_summary.append(
            {
                "relative_distance_perturbation": level,
                "units": len(subset),
                "bound_pass_rate": float(np.mean([row["bound_pass"] for row in subset])),
                "mean_route_l1": float(np.mean([row["actual_route_l1"] for row in subset])),
                "max_route_l1": float(np.max([row["actual_route_l1"] for row in subset])),
                "top_donor_change_rate": float(
                    np.mean([row["top_donor_changed"] for row in subset])
                ),
            }
        )
    write_csv(
        output / "provider_drift_audit/controlled_perturbation_summary.csv",
        controlled_summary,
    )
    cross_summary = []
    for dataset in sorted({row["dataset"] for row in cross}):
        for provider in sorted(
            {row["candidate_provider"] for row in cross if row["dataset"] == dataset}
        ):
            subset = [
                row
                for row in cross
                if row["dataset"] == dataset and row["candidate_provider"] == provider
            ]
            cross_summary.append(
                {
                    "dataset": dataset,
                    "candidate_provider": provider,
                    "units": len(subset),
                    "support_identical_rate": float(
                        np.mean([row["support_identical"] for row in subset])
                    ),
                    "mean_support_jaccard": float(
                        np.mean([row["support_jaccard"] for row in subset])
                    ),
                    "mean_route_l1": float(np.mean([row["route_l1"] for row in subset])),
                    "max_route_l1": float(np.max([row["route_l1"] for row in subset])),
                    "top_donor_change_rate": float(
                        np.mean([row["top_donor_changed"] for row in subset])
                    ),
                    "automatic_replacement_allowed": 0,
                }
            )
    write_csv(output / "provider_drift_audit/cross_provider_summary.csv", cross_summary)
    summary = {
        "controlled_units": len(controlled),
        "controlled_bound_failures": sum(1 - int(row["bound_pass"]) for row in controlled),
        "cross_provider_units": len(cross),
        "cross_provider_auto_replacements": sum(
            int(row["automatic_replacement_allowed"]) for row in cross
        ),
        "policy": {
            "exact_hash_match": "reuse frozen result",
            "same_support_nonidentical_hash": "replay receiver certificate before use",
            "changed_support_or_client_order": (
                "regenerate endpoint and replay receiver certificate before use"
            ),
            "automatic_sync_to_new_provider": False,
        },
        "controlled_summary": controlled_summary,
        "cross_provider_summary": cross_summary,
    }
    (output / "provider_drift_audit/provider_drift_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    report = [
        "# Geometry-provider drift audit",
        "",
        "The audit follows the theory-first contract: provider outputs are separated into "
        "client order, graph support, distance values, and prototype anchors. Exact snapshot "
        "hashes are reusable. Any non-identical provider output must be re-certified; support "
        "or client-order changes additionally require endpoint regeneration.",
        "",
        f"- Controlled fixed-support receiver units: {len(controlled)}.",
        f"- Softmax stability-bound failures: {summary['controlled_bound_failures']}.",
        f"- Cross-provider receiver units: {len(cross)}.",
        "- Automatically interchangeable cross-provider units: 0.",
        "",
        "This is not a claim that every FedGeo revision is harmful. It is evidence that a "
        "provider revision is an experimental-condition change, not a software patch that can "
        "silently replace the frozen geometry used by the paper.",
    ]
    (output / "provider_drift_audit/provider_drift_report.md").write_text(
        "\n".join(report) + "\n", encoding="utf-8"
    )
    return summary


def write_contract(
    output: Path, provider_root: Path, snapshot_rows: list[dict], file_rows: list[dict], summary: dict
) -> None:
    contract = {
        "schema_version": 1,
        "created": "2026-08-13",
        "provider_name": "provider-agnostic visual geometry interface",
        "fedgeo_status": "external evolving research code; not part of the claimed method",
        "snapshot_count": len(snapshot_rows),
        "file_count": len(file_rows),
        "client_order_rule": "manifest order; validated against d_geo and graph dimensions",
        "required_protocol_files": [
            f"{stem}_round_{{t}}{suffix}" for stem, suffix in PROTOCOL_FILES.items()
        ],
        "auxiliary_files": [
            f"{stem}_round_{{t}}{suffix}" for stem, suffix in OPTIONAL_FILES.items()
        ],
        "replacement_policy": summary["policy"],
        "local_source_paths_disclosed": False,
        "provider_results_root_used_only_during_local_packaging": provider_root.name,
    }
    (output / "geometry_contract.json").write_text(
        json.dumps(contract, indent=2) + "\n", encoding="utf-8"
    )
    readme = """# Frozen geometry contract

This directory contains the exact visual-geometry summaries used by the audited
FedAdapterManifold evidence. It deliberately freezes inputs rather than following
later changes in any geometry-provider implementation.

## Replacement rule

1. An exact snapshot SHA-256 match may reuse the frozen result.
2. A non-identical snapshot with the same client order and graph support must replay
   the receiver certificate before use.
3. A changed client order or graph support must regenerate the semantic endpoint and
   replay the receiver certificate.
4. No provider revision is automatically substituted into a reported table.

`geometry_snapshot_manifest.csv` records dataset, seed, round, client order, evidence
references, and snapshot hash. `geometry_file_manifest.csv` records every file hash.
The `provider_drift_audit` directory contains controlled perturbation and actual
multi-provider comparisons. Local absolute source paths are intentionally excluded.
"""
    (output / "README.md").write_text(readme, encoding="utf-8")


def main() -> int:
    args = parse_args()
    output = args.output if args.output.is_absolute() else ROOT / args.output
    provider_root = infer_provider_root(args.provider_results_root)
    safe_clean(output)
    sources = collect_sources(provider_root)
    snapshot_rows, file_rows = freeze_snapshots(sources, output)
    controlled = controlled_perturbation_audit(snapshot_rows, output)
    cross = compare_provider_roots(provider_root, output)
    summary = summarize_audit(controlled, cross, output)
    write_contract(output, provider_root, snapshot_rows, file_rows, summary)
    print(
        json.dumps(
            {
                "output": str(output),
                "sources": len(sources),
                "unique_snapshots": len(snapshot_rows),
                "snapshot_files": len(file_rows),
                **{key: summary[key] for key in (
                    "controlled_units",
                    "controlled_bound_failures",
                    "cross_provider_units",
                    "cross_provider_auto_replacements",
                )},
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
