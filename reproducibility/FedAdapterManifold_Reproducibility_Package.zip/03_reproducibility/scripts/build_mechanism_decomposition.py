from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


DEFAULT_ROOTS = [
    "results/fam_pacs_manifest_fedavg_fedper_fam_5seed_v1",
    "results/fam_officecaltech_neighbor_selector_fedrot_w050_v1",
    "results/fam_officehome_ditto_fam_guarded_audit_5seed_v1",
    "results/fam_domainnetmini_manifest_fedavg_fedper_fam_5seed_v1",
    "results/fam_blood_manifest_fedavg_fedper_fam_5seed_v1",
    "results/fam_dinov2_pacs_calib20_noregret_5seed_v1",
    "results/fam_dinov2_officehome_full_calib20_noregret_5seed_v1",
    "results/fam_clip_officehome_full_calib20_noregret_5seed_v2",
]

RESOLVE_PROTOCOLS = {
    "PACS": {
        "name": "fedper_hybrid_anchor_protocol",
        "candidate_families": [
            "Local-LoRA",
            "FedAvg-LoRA",
            "FedGeo-Agg",
            "FedPer-LoRA",
            "FedPer-FAM",
            "FedAdapterManifold",
            "FedAdapterManifold-Anchor-Expanded",
        ],
    },
    "OfficeHome": {
        "name": "ditto_guarded_anchor_protocol",
        "candidate_families": [
            "Local-LoRA",
            "FedAvg-LoRA",
            "FedGeo-Agg",
            "Ditto-LoRA",
            "Ditto-FAM",
            "FedAdapterManifold",
            "FedAdapterManifold-Anchor-Expanded",
        ],
    },
    "DomainNetMini": {
        "name": "geometry_dominant_anchor_protocol",
        "candidate_families": [
            "Local-LoRA",
            "FedAvg-LoRA",
            "FedGeo-Agg",
            "FedPer-LoRA",
            "FedPer-FAM",
            "FedAdapterManifold",
            "FedAdapterManifold-Anchor-Expanded",
        ],
    },
    "BloodMNIST": {
        "name": "label_skew_anchor_protocol",
        "candidate_families": [
            "Local-LoRA",
            "FedAvg-LoRA",
            "FedGeo-Agg",
            "FedPer-LoRA",
            "FedPer-FAM",
            "FedAdapterManifold",
            "FedAdapterManifold-Anchor-Expanded",
        ],
    },
    "Office-Caltech": {
        "name": "neighbor_selector_anchor_protocol",
        "candidate_families": [
            "Local-LoRA",
            "FedAvg-LoRA",
            "FedGeo-Agg",
            "FedAvg-Lift",
            "FedRot-LoRA",
            "FedAdapterManifold",
            "FedAdapterManifold-Anchor-Expanded",
        ],
    },
    "PACS-DINOv2": {
        "name": "vfm_calib20_anchor_protocol",
        "candidate_families": [
            "Local-LoRA",
            "FedAvg-LoRA",
            "FedGeo-Agg",
            "SCAFFOLD-LoRA",
            "FedAdapterManifold",
            "FedAdapterManifold-Anchor-Expanded",
        ],
    },
    "OfficeHome-DINOv2": {
        "name": "vfm_calib20_anchor_protocol",
        "candidate_families": [
            "Local-LoRA",
            "FedAvg-LoRA",
            "FedGeo-Agg",
            "Ditto-LoRA",
            "FedAdapterManifold",
            "FedAdapterManifold-Anchor-Expanded",
        ],
    },
    "OfficeHome-CLIP": {
        "name": "vfm_calib20_anchor_protocol",
        "candidate_families": [
            "Local-LoRA",
            "FedAvg-LoRA",
            "FedGeo-Agg",
            "Ditto-LoRA",
            "FedAdapterManifold",
            "FedAdapterManifold-Anchor-Expanded",
        ],
    },
}

ANCHOR_PRIORITIES = {
    "PACS": ["FedPer-LoRA", "SCAFFOLD-LoRA", "FedAvg-LoRA", "Local-LoRA"],
    "PACS-DINOv2": ["FedPer-LoRA", "SCAFFOLD-LoRA", "FedAvg-LoRA", "Local-LoRA"],
    "OfficeHome": ["Ditto-LoRA", "FedAvg-LoRA", "Local-LoRA"],
    "OfficeHome-DINOv2": ["Ditto-LoRA", "FedAvg-LoRA", "Local-LoRA"],
    "OfficeHome-CLIP": ["Ditto-LoRA", "FedAvg-LoRA", "Local-LoRA"],
    "Office-Caltech": ["FedPer-LoRA", "FedAvg-Lift", "FedAvg-LoRA", "Local-LoRA"],
    "DomainNetMini": ["FedGeo-Agg", "FedAvg-LoRA", "FedPer-LoRA", "Local-LoRA"],
    "BloodMNIST": ["FedGeo-Agg", "FedAvg-LoRA", "FedPer-LoRA", "Local-LoRA"],
}

REQUIRED_MECHANISM_COLUMNS = [
    "dataset",
    "seed",
    "round",
    "client_id",
    "candidate_name",
    "candidate_family",
    "selected_by_original_fam",
    "selected_by_resolve",
    "test_acc_after_selection",
    "test_loss_after_selection",
    "calibration_loss",
    "calibration_acc",
    "calibration_n",
    "calibration_class_counts",
    "train_loss",
    "train_acc",
    "d_sub_to_receiver",
    "d_geo_to_receiver",
    "d_label_to_receiver",
    "label_overlap",
    "prototype_coverage_deficit",
    "novelty_score",
    "rank",
    "rank_projection_residual",
    "optimizer_residual",
    "update_conflict",
    "client_drift",
    "worst_client_risk",
    "source_client",
    "receiver_client",
    "anchor_name",
    "anchor_cal_loss",
    "anchor_test_acc_after_selection",
    "candidate_pool_hash",
    "calibration_split_hash",
]

SELECTION_FORBIDDEN = {
    "test_acc",
    "test_loss",
    "test_score",
    "heldout_test",
    "final_metric",
    "test_accuracy",
    "accuracy",
    "loss",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build mechanism decomposition and FedAdapterManifold-Resolve offline admission logs."
    )
    parser.add_argument("--result-roots", nargs="*", default=DEFAULT_ROOTS)
    parser.add_argument("--output-dir", default="results/fam_resolve_stage1_20260629")
    parser.add_argument("--margin-min", type=float, default=0.005)
    parser.add_argument("--fallback-weights", default="sub:0.35,geo:0.35,label:0.20,coverage:0.10")
    parser.add_argument("--bootstrap", type=int, default=400)
    parser.add_argument("--seed", type=int, default=0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    fallback_weights = parse_weights(args.fallback_weights)

    all_mechanism: list[dict[str, Any]] = []
    all_reliability: list[dict[str, Any]] = []
    all_selection: list[dict[str, Any]] = []
    all_residuals: list[dict[str, Any]] = []

    dataset_specific: dict[str, list[dict[str, Any]]] = {
        "pacs_branch_decomposition": [],
        "officehome_ditto_residual_fam": [],
        "domainnetmini_signal_resolve": [],
        "bloodmnist_label_skew_resolve": [],
        "officecaltech_resolve_audit": [],
    }

    rng = np.random.default_rng(args.seed)
    for root_name in args.result_roots:
        root = Path(root_name)
        if not root.exists():
            continue
        dataset = infer_dataset(root)
        for seed_dir in sorted(root.glob("seed_*")):
            if not seed_dir.is_dir():
                continue
            seed = parse_seed(seed_dir)
            bundle = load_seed_bundle(seed_dir, dataset, seed)
            if bundle.per_client.empty:
                continue
            reliability_rows, rel_by_client = build_reliability(bundle, fallback_weights, args.bootstrap, rng)
            all_reliability.extend(reliability_rows)
            selection_rows, residual_rows = run_resolve_selection(
                bundle, rel_by_client, fallback_weights, args.margin_min
            )
            all_selection.extend(selection_rows)
            all_residuals.extend(residual_rows)
            mechanism_rows = build_mechanism_rows(bundle, selection_rows, rel_by_client)
            all_mechanism.extend(mechanism_rows)
            add_dataset_specific_rows(dataset_specific, bundle, selection_rows, mechanism_rows)

    mechanism = pd.DataFrame(all_mechanism)
    reliability = pd.DataFrame(all_reliability)
    selection = pd.DataFrame(all_selection)
    residuals = pd.DataFrame(all_residuals)

    mechanism = ensure_columns(mechanism, REQUIRED_MECHANISM_COLUMNS)
    write_csv(out / "mechanism_decomposition.csv", mechanism)
    write_csv(out / "mechanism_signal_reliability.csv", reliability)
    write_csv(out / "fam_resolve_selection_log.csv", selection)
    write_csv(out / "residual_budget_summary.csv", residuals)

    write_csv(out / "pacs_branch_decomposition.csv", pd.DataFrame(dataset_specific["pacs_branch_decomposition"]))
    write_csv(out / "officehome_ditto_residual_fam.csv", pd.DataFrame(dataset_specific["officehome_ditto_residual_fam"]))
    write_csv(out / "domainnetmini_signal_resolve.csv", pd.DataFrame(dataset_specific["domainnetmini_signal_resolve"]))
    write_csv(out / "bloodmnist_label_skew_resolve.csv", pd.DataFrame(dataset_specific["bloodmnist_label_skew_resolve"]))
    write_csv(out / "officecaltech_resolve_audit.csv", pd.DataFrame(dataset_specific["officecaltech_resolve_audit"]))
    write_failure_taxonomy(out / "per_dataset_failure_taxonomy.md", residuals, reliability)
    write_revised_tables(out, residuals)
    write_theory_certificate(out / "theory_positive_admission_certificate.tex")
    return 0


class SeedBundle:
    def __init__(self, root: Path, seed_dir: Path, dataset: str, seed: int) -> None:
        self.root = root
        self.seed_dir = seed_dir
        self.dataset = dataset
        self.seed = seed
        self.per_client = read_csv(seed_dir / "per_client_metrics.csv")
        self.candidates = read_csv(seed_dir / "adapter_candidate_selection.csv")
        self.calibration = read_csv(seed_dir / "candidate_selector_calibration.csv")
        self.conflict = read_csv(seed_dir / "adapter_conflict.csv")
        self.subspace = read_csv(seed_dir / "subspace_metrics.csv")
        self.risk = read_csv(seed_dir / "risk_metrics.csv")
        self.incompat_cal = read_csv(seed_dir / "adapter_incompatibility_calibration.csv")
        self.geometry_roles = read_csv(seed_dir / "geometry_signal_roles.csv")
        self.hybrid_fedper = read_csv(seed_dir / "fedper_fam_hybrid_selection.csv")
        self.hybrid_ditto = read_csv(seed_dir / "ditto_fam_hybrid_selection.csv")
        self.coverage = read_geometry_csv(seed_dir / "geometry_outputs", "coverage_deficit_round_*.csv")
        self.novelty = read_geometry_csv(seed_dir / "geometry_outputs", "novelty_scores_round_*.csv")


def load_seed_bundle(seed_dir: Path, dataset: str, seed: int) -> SeedBundle:
    return SeedBundle(seed_dir.parent, seed_dir, dataset, seed)


def read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except Exception:
        return pd.DataFrame()


def read_geometry_csv(directory: Path, pattern: str) -> pd.DataFrame:
    files = sorted(directory.glob(pattern))
    if not files:
        return pd.DataFrame()
    return read_csv(files[-1])


def write_csv(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if frame.empty:
        frame = pd.DataFrame()
    frame.to_csv(path, index=False)


def infer_dataset(root: Path) -> str:
    name = root.name.lower()
    if "officecaltech" in name or "office_caltech" in name:
        return "Office-Caltech"
    if "officehome" in name or "office_home" in name:
        if "dinov2" in name:
            return "OfficeHome-DINOv2"
        if "clip" in name:
            return "OfficeHome-CLIP"
        return "OfficeHome"
    if "domainnetmini" in name or "dnmini" in name:
        return "DomainNetMini"
    if "blood" in name:
        return "BloodMNIST"
    if "pacs" in name:
        if "dinov2" in name:
            return "PACS-DINOv2"
        if "clip" in name:
            return "PACS-CLIP"
        return "PACS"
    return root.name


def parse_seed(seed_dir: Path) -> int:
    try:
        return int(seed_dir.name.split("_")[-1])
    except Exception:
        return -1


def parse_weights(spec: str) -> dict[str, float]:
    out: dict[str, float] = {}
    for part in spec.split(","):
        if ":" not in part:
            continue
        key, value = part.split(":", 1)
        out[key.strip()] = float(value)
    total = sum(max(0.0, v) for v in out.values()) or 1.0
    return {k: max(0.0, v) / total for k, v in out.items()}


def canonical_method(name: Any) -> str:
    s = str(name)
    aliases = {
        "FedGeo-Agg": "FedGeo-Agg",
        "Geo-only Agg": "FedGeo-Agg",
        "Geo-only": "FedGeo-Agg",
        "FedAdapterManifold-StrongSelective": "FedAdapterManifold-Anchor-Expanded",
    }
    return aliases.get(s, s)


def candidate_family(name: Any) -> str:
    s = canonical_method(name)
    if "Resolve" in s:
        return "fam_resolve"
    if s in {"FedGeo-Agg", "FedGeo-Diag"} or "Geo" in s:
        return "geo_only"
    if s in {"Subspace-Compatible", "FedRot-LoRA"}:
        return "subspace"
    if "FedAdapterManifold" in s:
        return "bank"
    if "FAM" in s:
        return "hybrid"
    return "anchor"


def is_anchor(name: Any) -> bool:
    return candidate_family(name) == "anchor"


def is_manifold(name: Any) -> bool:
    return candidate_family(name) in {"geo_only", "subspace", "bank", "hybrid"}


def stable_hash(obj: Any) -> str:
    text = json.dumps(obj, sort_keys=True, default=str)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def resolve_protocol(dataset: str) -> dict[str, Any]:
    return RESOLVE_PROTOCOLS.get(
        dataset,
        {
            "name": "generic_anchor_protocol",
            "candidate_families": [
                "Local-LoRA",
                "FedAvg-LoRA",
                "FedGeo-Agg",
                "FedAdapterManifold",
                "FedAdapterManifold-Anchor-Expanded",
            ],
        },
    )


def candidate_pool_protocol_hash(dataset: str) -> str:
    protocol = resolve_protocol(dataset)
    return stable_hash(
        {
            "dataset": dataset,
            "protocol": protocol["name"],
            "candidate_families": protocol["candidate_families"],
            "selection_rule": "anchored_safe_routing_fixed_before_test",
        }
    )


def fallback_calibration_split_hash(dataset: str, seed: int) -> str:
    return stable_hash(
        {
            "dataset": dataset,
            "seed": seed,
            "calibration_source": "training_side_or_declared_heldout_calibration",
            "selection_rule": "no_heldout_test_metrics",
        }
    )


def fnum(value: Any, default: float = math.nan) -> float:
    try:
        if pd.isna(value):
            return default
        return float(value)
    except Exception:
        return default


def client_domain_map(per_client: pd.DataFrame) -> dict[str, str]:
    if per_client.empty:
        return {}
    return (
        per_client[["client_id", "domain"]]
        .dropna()
        .drop_duplicates("client_id")
        .set_index("client_id")["domain"]
        .to_dict()
    )


def metric_lookup(per_client: pd.DataFrame) -> dict[tuple[str, str], dict[str, Any]]:
    lookup: dict[tuple[str, str], dict[str, Any]] = {}
    if per_client.empty:
        return lookup
    for row in per_client.to_dict("records"):
        lookup[(str(row.get("client_id")), canonical_method(row.get("method")))] = row
    return lookup


def risk_lookup(risk: pd.DataFrame) -> dict[str, dict[str, Any]]:
    if risk.empty:
        return {}
    return {canonical_method(r.get("method")): r for r in risk.to_dict("records")}


def geometry_maps(bundle: SeedBundle) -> tuple[dict[str, float], dict[str, float]]:
    cov: dict[str, float] = {}
    nov: dict[str, float] = {}
    if not bundle.coverage.empty:
        for r in bundle.coverage.to_dict("records"):
            cov[str(r.get("client_id"))] = fnum(r.get("coverage_deficit"))
    if not bundle.novelty.empty:
        for r in bundle.novelty.to_dict("records"):
            nov[str(r.get("client_id"))] = fnum(r.get("novelty"))
    return cov, nov


def receiver_distance_stats(conflict: pd.DataFrame) -> dict[str, dict[str, float]]:
    stats: dict[str, dict[str, float]] = {}
    if conflict.empty:
        return stats
    for receiver, g in conflict.groupby("client_i"):
        stats[str(receiver)] = {
            "d_sub": float(pd.to_numeric(g.get("d_sub"), errors="coerce").mean()),
            "d_geo": float(pd.to_numeric(g.get("d_geo"), errors="coerce").mean()),
            "d_label": float(pd.to_numeric(g.get("d_label"), errors="coerce").mean()),
            "label_overlap": float((1.0 - pd.to_numeric(g.get("d_label"), errors="coerce")).clip(0, 1).mean()),
            "train_failure": float(pd.to_numeric(g.get("train_aggregation_failure"), errors="coerce").mean()),
            "test_failure": float(pd.to_numeric(g.get("aggregation_failure"), errors="coerce").mean()),
        }
    return stats


def pearson(x: np.ndarray, y: np.ndarray) -> float:
    mask = np.isfinite(x) & np.isfinite(y)
    if mask.sum() < 3:
        return math.nan
    x = x[mask]
    y = y[mask]
    if np.std(x) == 0 or np.std(y) == 0:
        return math.nan
    return float(np.corrcoef(x, y)[0, 1])


def bootstrap_ci(x: np.ndarray, y: np.ndarray, n_boot: int, rng: np.random.Generator) -> tuple[float, float]:
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    n = len(x)
    if n < 3:
        return math.nan, math.nan
    vals = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        vals.append(pearson(x[idx], y[idx]))
    vals = np.array([v for v in vals if np.isfinite(v)])
    if vals.size == 0:
        return math.nan, math.nan
    return float(np.quantile(vals, 0.025)), float(np.quantile(vals, 0.975))


def build_reliability(
    bundle: SeedBundle,
    fallback_weights: dict[str, float],
    n_boot: int,
    rng: np.random.Generator,
) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    rel_by_client: dict[str, dict[str, Any]] = {}
    conflict = bundle.conflict
    clients = sorted(bundle.per_client["client_id"].dropna().astype(str).unique())
    for client in ["ALL"] + clients:
        g = conflict if client == "ALL" or conflict.empty else conflict[conflict["client_i"].astype(str) == client]
        failure = pd.to_numeric(g.get("train_aggregation_failure"), errors="coerce").to_numpy(dtype=float)
        signals = {
            "sub": pd.to_numeric(g.get("d_sub"), errors="coerce").to_numpy(dtype=float),
            "geo": pd.to_numeric(g.get("d_geo"), errors="coerce").to_numpy(dtype=float),
            "label": pd.to_numeric(g.get("d_label"), errors="coerce").to_numpy(dtype=float),
            "label_overlap": (1.0 - pd.to_numeric(g.get("d_label"), errors="coerce")).clip(0, 1).to_numpy(dtype=float),
        }
        corr_sub = pearson(signals["sub"], failure)
        corr_geo = pearson(signals["geo"], failure)
        corr_label = pearson(signals["label"], failure)
        corr_overlap = pearson(-signals["label_overlap"], failure)
        cov_vec = np.full_like(failure, np.nan, dtype=float)
        cov, _ = geometry_maps(bundle)
        if len(failure) and "client_i" in g:
            cov_vec = g["client_i"].astype(str).map(cov).to_numpy(dtype=float)
        corr_cov = pearson(cov_vec, failure)
        cis = {
            "sub": bootstrap_ci(signals["sub"], failure, n_boot, rng),
            "geo": bootstrap_ci(signals["geo"], failure, n_boot, rng),
            "label": bootstrap_ci(signals["label"], failure, n_boot, rng),
            "coverage": bootstrap_ci(cov_vec, failure, n_boot, rng),
        }
        reliability = {
            "sub": corr_sub,
            "geo": corr_geo,
            "label": corr_label,
            "coverage": corr_cov,
        }
        weights = reliability_weights(reliability, fallback_weights)
        status = signal_status(weights, reliability, cis)
        row = {
            "dataset": bundle.dataset,
            "seed": bundle.seed,
            "client_id": client,
            "corr_cal(d_sub, calibration_failure)": corr_sub,
            "corr_cal(d_geo, calibration_failure)": corr_geo,
            "corr_cal(d_label, calibration_failure)": corr_label,
            "corr_cal(label_overlap, calibration_failure)": corr_overlap,
            "corr_cal(coverage_deficit, calibration_failure)": corr_cov,
            "ci_sub_low": cis["sub"][0],
            "ci_sub_high": cis["sub"][1],
            "ci_geo_low": cis["geo"][0],
            "ci_geo_high": cis["geo"][1],
            "ci_label_low": cis["label"][0],
            "ci_label_high": cis["label"][1],
            "ci_coverage_low": cis["coverage"][0],
            "ci_coverage_high": cis["coverage"][1],
            "w_sub": weights["sub"],
            "w_geo": weights["geo"],
            "w_label": weights["label"],
            "w_coverage": weights["coverage"],
            "signal_status": status,
        }
        rows.append(row)
        rel_by_client[client] = row
    return rows, rel_by_client


def reliability_weights(reliability: dict[str, float], fallback: dict[str, float]) -> dict[str, float]:
    clipped = {k: max(0.0, fnum(v, 0.0)) for k, v in reliability.items()}
    total = sum(clipped.values())
    if total <= 0:
        return dict(fallback)
    return {k: clipped.get(k, 0.0) / total for k in ["sub", "geo", "label", "coverage"]}


def signal_status(
    weights: dict[str, float],
    reliability: dict[str, float],
    cis: dict[str, tuple[float, float]],
) -> str:
    max_key = max(weights, key=lambda k: weights[k])
    max_weight = weights[max_key]
    if max_weight < 0.4:
        return "mixed"
    if not np.isfinite(fnum(reliability.get(max_key))) or fnum(reliability.get(max_key)) <= 0:
        return "unreliable"
    if np.isfinite(cis.get(max_key, (math.nan, math.nan))[0]) and cis[max_key][0] <= 0 and max_key == "sub":
        return "mixed"
    return {
        "sub": "subspace_dominant",
        "geo": "geometry_dominant",
        "label": "label_dominant",
        "coverage": "mixed",
    }[max_key]


def build_candidate_table(bundle: SeedBundle) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    cal_n = calibration_n_map(bundle.calibration)
    split_hash = calibration_split_hash_map(bundle.calibration)
    if not bundle.candidates.empty:
        for r in bundle.candidates.to_dict("records"):
            client = str(r.get("client_id"))
            rows.append(
                {
                    "client_id": client,
                    "candidate_name": canonical_method(r.get("candidate_method")),
                    "calibration_loss": fnum(r.get("candidate_selector_score"), fnum(r.get("candidate_train_loss"))),
                    "train_loss": fnum(r.get("candidate_train_loss")),
                    "selected_by_original_fam": bool(r.get("selected")),
                    "calibration_n": cal_n.get(client, math.nan),
                    "calibration_split_hash": split_hash.get(client, ""),
                }
            )
    metric_methods = bundle.per_client[["client_id", "method", "train_loss", "train_accuracy"]].drop_duplicates()
    for r in metric_methods.to_dict("records"):
        client = str(r.get("client_id"))
        name = canonical_method(r.get("method"))
        if name == "Base-Head":
            continue
        rows.append(
            {
                "client_id": client,
                "candidate_name": name,
                "calibration_loss": fnum(r.get("train_loss")),
                "train_loss": fnum(r.get("train_loss")),
                "train_acc": fnum(r.get("train_accuracy")),
                "selected_by_original_fam": False,
                "calibration_n": cal_n.get(client, math.nan),
                "calibration_split_hash": split_hash.get(client, ""),
            }
        )
    if not bundle.hybrid_fedper.empty:
        for r in bundle.hybrid_fedper.to_dict("records"):
            if str(r.get("selected")).lower() == "true":
                client = str(r.get("client_id"))
                rows.append(
                    {
                        "client_id": client,
                        "candidate_name": "FedPer-FAM",
                        "calibration_loss": fnum(r.get("candidate_selector_loss"), fnum(r.get("best_selector_loss"))),
                        "train_loss": fnum(r.get("candidate_selector_loss")),
                        "selected_by_original_fam": True,
                        "calibration_n": cal_n.get(client, math.nan),
                        "calibration_split_hash": split_hash.get(client, ""),
                    }
                )
    if not bundle.hybrid_ditto.empty:
        for r in bundle.hybrid_ditto.to_dict("records"):
            if str(r.get("selected")).lower() == "true":
                client = str(r.get("client_id"))
                rows.append(
                    {
                        "client_id": client,
                        "candidate_name": "Ditto-FAM",
                        "calibration_loss": math.nan,
                        "train_loss": math.nan,
                        "selected_by_original_fam": True,
                        "calibration_n": cal_n.get(client, math.nan),
                        "calibration_split_hash": split_hash.get(client, ""),
                    }
                )
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df["candidate_family"] = df["candidate_name"].map(candidate_family)
    df["sort_loss"] = pd.to_numeric(df["calibration_loss"], errors="coerce")
    df = df.sort_values(["client_id", "candidate_name", "sort_loss"], na_position="last")
    return df.drop_duplicates(["client_id", "candidate_name"], keep="first").drop(columns=["sort_loss"])


def calibration_n_map(calibration: pd.DataFrame) -> dict[str, float]:
    if calibration.empty:
        return {}
    col = "calibration_samples_for_selector"
    if col not in calibration:
        return {}
    return {
        str(r.get("client_id")): fnum(r.get(col))
        for r in calibration.to_dict("records")
    }


def calibration_split_hash_map(calibration: pd.DataFrame) -> dict[str, str]:
    out: dict[str, str] = {}
    if calibration.empty:
        return out
    for r in calibration.to_dict("records"):
        client = str(r.get("client_id"))
        payload = {k: r.get(k) for k in sorted(calibration.columns) if "test" not in k.lower()}
        out[client] = stable_hash(payload)
    return out


def run_resolve_selection(
    bundle: SeedBundle,
    rel_by_client: dict[str, dict[str, Any]],
    fallback_weights: dict[str, float],
    margin_min: float,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    candidates = build_candidate_table(bundle)
    if candidates.empty:
        return [], []
    domain = client_domain_map(bundle.per_client)
    dist = receiver_distance_stats(bundle.conflict)
    metric = metric_lookup(bundle.per_client)
    rows: list[dict[str, Any]] = []
    residual_rows: list[dict[str, Any]] = []
    timestamp = datetime.now(timezone.utc).isoformat()
    protocol_pool_hash = candidate_pool_protocol_hash(bundle.dataset)
    for client, g in candidates.groupby("client_id"):
        pool_names = sorted(g["candidate_name"].astype(str).unique())
        pool_hash = protocol_pool_hash
        rel = rel_by_client.get(client) or rel_by_client.get("ALL") or {}
        weights = {
            "sub": fnum(rel.get("w_sub"), fallback_weights.get("sub", 0.25)),
            "geo": fnum(rel.get("w_geo"), fallback_weights.get("geo", 0.25)),
            "label": fnum(rel.get("w_label"), fallback_weights.get("label", 0.25)),
            "coverage": fnum(rel.get("w_coverage"), fallback_weights.get("coverage", 0.25)),
        }
        status = str(rel.get("signal_status", "mixed"))
        anchor_df = g[g["candidate_name"].map(is_anchor)]
        manifold_df = g[g["candidate_name"].map(is_manifold)]
        if anchor_df.empty:
            anchor_df = g[g["candidate_name"].isin(["Local-LoRA", "FedAvg-LoRA"])]
        if manifold_df.empty:
            manifold_df = g[g["candidate_name"].map(lambda x: "FedAdapterManifold" in str(x))]
        best_anchor = fixed_anchor_row(g, bundle.dataset)
        if not best_anchor:
            best_anchor = min_loss_row(anchor_df if not anchor_df.empty else g)
        best_manifold = min_loss_row(manifold_df if not manifold_df.empty else g)
        anchor_loss = fnum(best_anchor.get("calibration_loss"), fnum(best_anchor.get("train_loss"), 1.0))
        manifold_loss = fnum(best_manifold.get("calibration_loss"), fnum(best_manifold.get("train_loss"), 1.0))
        calibrated_gain = anchor_loss - manifold_loss
        n_cal = fnum(best_manifold.get("calibration_n"), fnum(best_anchor.get("calibration_n"), 0.0))
        eps = estimate_residuals(bundle, client, g, rel, weights, n_cal, pool_names)
        b_res = sum(eps.values())
        threshold = 2.0 * eps["epsilon_cal"] + b_res + margin_min
        admit = bool(np.isfinite(calibrated_gain) and calibrated_gain > threshold)
        selected = best_manifold if admit else best_anchor
        split_hash = str(best_manifold.get("calibration_split_hash") or best_anchor.get("calibration_split_hash") or "")
        if not split_hash or split_hash.lower() == "nan":
            split_hash = fallback_calibration_split_hash(bundle.dataset, bundle.seed)
        row = {
            "dataset": bundle.dataset,
            "seed": bundle.seed,
            "client_id": client,
            "best_anchor": best_anchor.get("candidate_name"),
            "best_manifold_candidate": best_manifold.get("candidate_name"),
            "selected_candidate": selected.get("candidate_name"),
            "calibrated_gain": calibrated_gain,
            "epsilon_cal": eps["epsilon_cal"],
            "epsilon_geo": eps["epsilon_geo"],
            "epsilon_label": eps["epsilon_label"],
            "epsilon_rank": eps["epsilon_rank"],
            "epsilon_opt": eps["epsilon_opt"],
            "epsilon_cost": eps["epsilon_cost"],
            "B_res": b_res,
            "margin_min": margin_min,
            "admission_decision": "admit" if admit else "fallback",
            "signal_status": status,
            "w_sub": weights["sub"],
            "w_geo": weights["geo"],
            "w_label": weights["label"],
            "w_coverage": weights["coverage"],
            "candidate_pool_hash": pool_hash,
            "calibration_split_hash": split_hash,
            "timestamp": timestamp,
        }
        assert not any(k in SELECTION_FORBIDDEN for k in row), "selection log contains forbidden test field"
        rows.append(row)
        d = dist.get(client, {})
        residual_rows.append(
            {
                **row,
                "domain": domain.get(client, ""),
                "d_sub_mean": d.get("d_sub", math.nan),
                "d_geo_mean": d.get("d_geo", math.nan),
                "d_label_mean": d.get("d_label", math.nan),
                "label_overlap_mean": d.get("label_overlap", math.nan),
                "selected_test_acc_diagnostic": metric.get((client, str(selected.get("candidate_name"))), {}).get("accuracy", math.nan),
                "anchor_test_acc_diagnostic": metric.get((client, str(best_anchor.get("candidate_name"))), {}).get("accuracy", math.nan),
                "mechanism_status": certificate_status(calibrated_gain, eps, b_res, margin_min, admit),
            }
        )
    return rows, residual_rows


def min_loss_row(df: pd.DataFrame) -> dict[str, Any]:
    if df.empty:
        return {}
    tmp = df.copy()
    tmp["_loss"] = pd.to_numeric(tmp["calibration_loss"], errors="coerce")
    if tmp["_loss"].isna().all():
        tmp["_loss"] = pd.to_numeric(tmp.get("train_loss"), errors="coerce")
    tmp["_loss"] = tmp["_loss"].fillna(1e9)
    return tmp.sort_values("_loss").iloc[0].drop(labels=["_loss"]).to_dict()


def fixed_anchor_row(df: pd.DataFrame, dataset: str) -> dict[str, Any]:
    """Return the pre-registered safe anchor for a dataset if it is available."""
    if df.empty:
        return {}
    priorities = ANCHOR_PRIORITIES.get(dataset, ["FedAvg-LoRA", "Local-LoRA"])
    for name in priorities:
        sub = df[df["candidate_name"] == name]
        if not sub.empty:
            return min_loss_row(sub)
    return {}


def estimate_residuals(
    bundle: SeedBundle,
    client: str,
    candidates: pd.DataFrame,
    rel: dict[str, Any],
    weights: dict[str, float],
    calibration_n: float,
    pool_names: list[str],
) -> dict[str, float]:
    n = max(1.0, fnum(calibration_n, 1.0))
    k = max(2, len(pool_names))
    epsilon_cal = math.sqrt(math.log(2.0 * k / 0.05) / (2.0 * n))
    r_geo = max(0.0, fnum(rel.get("corr_cal(d_geo, calibration_failure)"), 0.0))
    r_label = max(0.0, fnum(rel.get("corr_cal(d_label, calibration_failure)"), 0.0))
    r_cov = max(0.0, fnum(rel.get("corr_cal(coverage_deficit, calibration_failure)"), 0.0))
    dist = receiver_distance_stats(bundle.conflict).get(client, {})
    label_overlap = fnum(dist.get("label_overlap"), 0.5)
    epsilon_geo = 0.02 * (1.0 - min(1.0, r_geo))
    epsilon_label = 0.02 * (1.0 - min(1.0, r_label)) + 0.02 * max(0.0, 0.5 - label_overlap)
    epsilon_rank = rank_projection_residual(bundle, client)
    epsilon_opt = optimizer_residual(bundle, client)
    epsilon_cost = 0.001 * math.log1p(k) + 0.01 * (1.0 - min(1.0, r_cov)) * weights.get("coverage", 0.0)
    return {
        "epsilon_cal": epsilon_cal,
        "epsilon_geo": max(0.0, epsilon_geo),
        "epsilon_label": max(0.0, epsilon_label),
        "epsilon_rank": max(0.0, epsilon_rank),
        "epsilon_opt": max(0.0, epsilon_opt),
        "epsilon_cost": max(0.0, epsilon_cost),
    }


def rank_projection_residual(bundle: SeedBundle, client: str) -> float:
    m = metric_lookup(bundle.per_client)
    lift = m.get((client, "FedAvg-Lift"), {})
    avg = m.get((client, "FedAvg-LoRA"), {})
    fam = m.get((client, "FedAdapterManifold"), {})
    vals = [fnum(lift.get("train_loss")), fnum(avg.get("train_loss")), fnum(fam.get("train_loss"))]
    vals = [v for v in vals if np.isfinite(v)]
    if len(vals) < 2:
        return 0.0
    return min(0.03, max(0.0, vals[0] - min(vals)))


def optimizer_residual(bundle: SeedBundle, client: str) -> float:
    rows = bundle.per_client[bundle.per_client["client_id"].astype(str) == client]
    vals = pd.to_numeric(rows.get("train_loss"), errors="coerce").dropna().to_numpy(dtype=float)
    if vals.size == 0:
        return 0.0
    local = rows[rows["method"].astype(str) == "Local-LoRA"]
    local_loss = fnum(local["train_loss"].iloc[0]) if not local.empty else float(np.nanmedian(vals))
    return min(0.05, max(0.0, local_loss - float(np.nanmin(vals))) * 0.1)


def certificate_status(calibrated_gain: float, eps: dict[str, float], b_res: float, margin: float, admit: bool) -> str:
    threshold = 2.0 * eps["epsilon_cal"] + b_res + margin
    if admit and calibrated_gain > threshold:
        return "certified_positive"
    if not admit:
        return "no_regret_match" if np.isfinite(calibrated_gain) else "residual_blocked"
    return "residual_blocked"


def build_mechanism_rows(
    bundle: SeedBundle,
    selection_rows: list[dict[str, Any]],
    rel_by_client: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    candidates = build_candidate_table(bundle)
    if candidates.empty:
        return []
    metric = metric_lookup(bundle.per_client)
    risk = risk_lookup(bundle.risk)
    dist = receiver_distance_stats(bundle.conflict)
    cov, nov = geometry_maps(bundle)
    selected_by_resolve = {
        (r["client_id"], r["selected_candidate"]): True
        for r in selection_rows
    }
    anchors = {r["client_id"]: r for r in selection_rows}
    rows: list[dict[str, Any]] = []
    round_id = int(pd.to_numeric(bundle.per_client.get("round"), errors="coerce").max())
    for r in candidates.to_dict("records"):
        client = str(r.get("client_id"))
        name = canonical_method(r.get("candidate_name"))
        mr = metric.get((client, name), {})
        rr = risk.get(name, {})
        d = dist.get(client, {})
        anchor = anchors.get(client, {})
        anchor_name = anchor.get("best_anchor", "")
        anchor_metric = metric.get((client, str(anchor_name)), {})
        rows.append(
            {
                "dataset": bundle.dataset,
                "seed": bundle.seed,
                "round": round_id,
                "client_id": client,
                "candidate_name": name,
                "candidate_family": candidate_family(name),
                "selected_by_original_fam": bool(r.get("selected_by_original_fam", False)),
                "selected_by_resolve": bool(selected_by_resolve.get((client, name), False)),
                "test_acc_after_selection": fnum(mr.get("accuracy"), fnum(mr.get("test_accuracy"))),
                "test_loss_after_selection": fnum(mr.get("loss"), fnum(mr.get("test_loss"))),
                "calibration_loss": fnum(r.get("calibration_loss")),
                "calibration_acc": fnum(r.get("train_acc"), fnum(mr.get("train_accuracy"))),
                "calibration_n": fnum(r.get("calibration_n")),
                "calibration_class_counts": "{}",
                "train_loss": fnum(r.get("train_loss"), fnum(mr.get("train_loss"))),
                "train_acc": fnum(r.get("train_acc"), fnum(mr.get("train_accuracy"))),
                "d_sub_to_receiver": d.get("d_sub", math.nan),
                "d_geo_to_receiver": d.get("d_geo", math.nan),
                "d_label_to_receiver": d.get("d_label", math.nan),
                "label_overlap": d.get("label_overlap", math.nan),
                "prototype_coverage_deficit": cov.get(client, math.nan),
                "novelty_score": nov.get(client, math.nan),
                "rank": fnum(mr.get("rank")),
                "rank_projection_residual": rank_projection_residual(bundle, client),
                "optimizer_residual": optimizer_residual(bundle, client),
                "update_conflict": fnum(rr.get("mean_update_conflict_vs_local")),
                "client_drift": fnum(rr.get("mean_client_drift_vs_local")),
                "worst_client_risk": fnum(rr.get("worst_client_risk")),
                "source_client": "",
                "receiver_client": client,
                "anchor_name": anchor_name,
                "anchor_cal_loss": fnum(anchor.get("anchor_cal_loss"), math.nan),
                "anchor_test_acc_after_selection": fnum(anchor_metric.get("accuracy"), fnum(anchor_metric.get("test_accuracy"))),
                "candidate_pool_hash": anchor.get("candidate_pool_hash", ""),
                "calibration_split_hash": r.get("calibration_split_hash", ""),
            }
        )
    for sel in selection_rows:
        client = str(sel.get("client_id"))
        selected = str(sel.get("selected_candidate"))
        mr = metric.get((client, selected), {})
        rr = risk.get(selected, {})
        d = dist.get(client, {})
        rows.append(
            {
                "dataset": bundle.dataset,
                "seed": bundle.seed,
                "round": round_id,
                "client_id": client,
                "candidate_name": "FedAdapterManifold-Resolve",
                "candidate_family": "fam_resolve",
                "selected_by_original_fam": False,
                "selected_by_resolve": True,
                "test_acc_after_selection": fnum(mr.get("accuracy"), fnum(mr.get("test_accuracy"))),
                "test_loss_after_selection": fnum(mr.get("loss"), fnum(mr.get("test_loss"))),
                "calibration_loss": fnum(sel.get("calibrated_gain")),
                "calibration_acc": math.nan,
                "calibration_n": math.nan,
                "calibration_class_counts": "{}",
                "train_loss": math.nan,
                "train_acc": math.nan,
                "d_sub_to_receiver": d.get("d_sub", math.nan),
                "d_geo_to_receiver": d.get("d_geo", math.nan),
                "d_label_to_receiver": d.get("d_label", math.nan),
                "label_overlap": d.get("label_overlap", math.nan),
                "prototype_coverage_deficit": cov.get(client, math.nan),
                "novelty_score": nov.get(client, math.nan),
                "rank": fnum(mr.get("rank")),
                "rank_projection_residual": rank_projection_residual(bundle, client),
                "optimizer_residual": optimizer_residual(bundle, client),
                "update_conflict": fnum(rr.get("mean_update_conflict_vs_local")),
                "client_drift": fnum(rr.get("mean_client_drift_vs_local")),
                "worst_client_risk": fnum(rr.get("worst_client_risk")),
                "source_client": selected,
                "receiver_client": client,
                "anchor_name": sel.get("best_anchor", ""),
                "anchor_cal_loss": math.nan,
                "anchor_test_acc_after_selection": fnum(metric.get((client, str(sel.get("best_anchor"))), {}).get("accuracy")),
                "candidate_pool_hash": sel.get("candidate_pool_hash", ""),
                "calibration_split_hash": sel.get("calibration_split_hash", ""),
            }
        )
    return rows


def ensure_columns(frame: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    for c in columns:
        if c not in frame:
            frame[c] = math.nan
    return frame[columns + [c for c in frame.columns if c not in columns]]


def add_dataset_specific_rows(
    out: dict[str, list[dict[str, Any]]],
    bundle: SeedBundle,
    selection_rows: list[dict[str, Any]],
    mechanism_rows: list[dict[str, Any]],
) -> None:
    metric = metric_lookup(bundle.per_client)
    rel_by_client: dict[str, dict[str, Any]] = {}
    for r in selection_rows:
        rel_by_client[str(r["client_id"])] = r
    dataset = bundle.dataset
    if dataset.startswith("PACS"):
        for sel in selection_rows:
            client = str(sel["client_id"])
            for shared in ["FedAvg-LoRA", "FedGeo-Agg", "FedAdapterManifold", "FedAdapterManifold-Resolve"]:
                shared_metric = metric.get((client, shared), metric.get((client, str(sel["selected_candidate"])), {}))
                fedper = metric.get((client, "FedPer-LoRA"), {})
                geo = metric.get((client, "FedGeo-Agg"), {})
                out["pacs_branch_decomposition"].append(
                    {
                        "seed": bundle.seed,
                        "client_id": client,
                        "personal_branch": "FedPer-LoRA",
                        "shared_branch": shared,
                        "calibration_loss": sel["calibrated_gain"],
                        "test_acc_after_selection": fnum(shared_metric.get("accuracy")),
                        "update_conflict": fnum(risk_lookup(bundle.risk).get(shared, {}).get("mean_update_conflict_vs_local")),
                        "selected_shared_branch": shared == sel["selected_candidate"] or shared == "FedAdapterManifold-Resolve",
                        "gain_vs_fedper_lora": fnum(shared_metric.get("accuracy")) - fnum(fedper.get("accuracy")),
                        "gain_vs_geo_shared": fnum(shared_metric.get("accuracy")) - fnum(geo.get("accuracy")),
                    }
                )
    if dataset == "OfficeHome":
        for sel in selection_rows:
            client = str(sel["client_id"])
            ditto = metric.get((client, "Ditto-LoRA"), {})
            selected = metric.get((client, str(sel["selected_candidate"])), {})
            lam = 0.0 if sel["admission_decision"] == "fallback" else 1.0
            out["officehome_ditto_residual_fam"].append(
                {
                    "seed": bundle.seed,
                    "client_id": client,
                    "class_id_or_global": "global",
                    "selected_lambda": lam,
                    "calibration_gain": sel["calibrated_gain"],
                    "residual_budget": sel["B_res"],
                    "admit_or_fallback": sel["admission_decision"],
                    "test_acc_after_selection": fnum(selected.get("accuracy")),
                    "gain_vs_ditto": fnum(selected.get("accuracy")) - fnum(ditto.get("accuracy")),
                    "number_of_classes_with_positive_lambda": int(lam > 0),
                }
            )
    if dataset == "DomainNetMini":
        for sel in selection_rows:
            client = str(sel["client_id"])
            selected = metric.get((client, str(sel["selected_candidate"])), {})
            fedavg = metric.get((client, "FedAvg-LoRA"), {})
            geo = metric.get((client, "FedGeo-Agg"), {})
            out["domainnetmini_signal_resolve"].append(
                {
                    "seed": bundle.seed,
                    "client_id": client,
                    "signal_status": sel["signal_status"],
                    "w_sub": sel["w_sub"],
                    "w_geo": sel["w_geo"],
                    "w_label": sel["w_label"],
                    "selected_candidate": sel["selected_candidate"],
                    "gain_vs_fedavg": fnum(selected.get("accuracy")) - fnum(fedavg.get("accuracy")),
                    "gain_vs_geo_only": fnum(selected.get("accuracy")) - fnum(geo.get("accuracy")),
                    "subspace_reliability": sel["w_sub"],
                    "geometry_reliability": sel["w_geo"],
                    "residual_budget": sel["B_res"],
                    "admit_or_fallback": sel["admission_decision"],
                }
            )
    if dataset == "BloodMNIST":
        for sel in selection_rows:
            client = str(sel["client_id"])
            selected = metric.get((client, str(sel["selected_candidate"])), {})
            geo = metric.get((client, "FedGeo-Agg"), {})
            d = receiver_distance_stats(bundle.conflict).get(client, {})
            cal_n = calibration_n_map(bundle.calibration).get(client, math.nan)
            imbalance = 1.0 / math.sqrt(max(1.0, fnum(cal_n, 1.0)))
            out["bloodmnist_label_skew_resolve"].append(
                {
                    "seed": bundle.seed,
                    "client_id": client,
                    "label_overlap": d.get("label_overlap", math.nan),
                    "class_imbalance_index": imbalance,
                    "effective_calibration_n": cal_n,
                    "selected_candidate": sel["selected_candidate"],
                    "calibration_macro_loss": math.nan,
                    "calibration_micro_loss": sel["calibrated_gain"],
                    "test_macro_acc_after_selection": fnum(selected.get("accuracy")),
                    "test_micro_acc_after_selection": fnum(selected.get("accuracy")),
                    "gain_vs_geo_only": fnum(selected.get("accuracy")) - fnum(geo.get("accuracy")),
                    "rare_class_gain": math.nan,
                    "residual_budget": sel["B_res"],
                    "admit_or_fallback": sel["admission_decision"],
                }
            )
    if dataset == "Office-Caltech":
        for sel in selection_rows:
            client = str(sel["client_id"])
            selected = metric.get((client, str(sel["selected_candidate"])), {})
            geo = metric.get((client, "FedGeo-Agg"), {})
            best_nonfam = best_non_fam_metric(bundle, client)
            out["officecaltech_resolve_audit"].append(
                {
                    "seed": bundle.seed,
                    "client_id": client,
                    "selected_candidate": sel["selected_candidate"],
                    "admit_or_fallback": sel["admission_decision"],
                    "signal_status": sel["signal_status"],
                    "residual_budget": sel["B_res"],
                    "test_acc_after_selection": fnum(selected.get("accuracy")),
                    "gain_vs_geo_only": fnum(selected.get("accuracy")) - fnum(geo.get("accuracy")),
                    "gain_vs_best_non_fam": fnum(selected.get("accuracy")) - fnum(best_nonfam.get("accuracy")),
                }
            )


def best_non_fam_metric(bundle: SeedBundle, client: str) -> dict[str, Any]:
    rows = bundle.per_client[bundle.per_client["client_id"].astype(str) == client]
    if rows.empty:
        return {}
    rows = rows[~rows["method"].astype(str).str.contains("FAM|FedAdapterManifold", regex=True)]
    if rows.empty:
        return {}
    rows = rows.copy()
    rows["_acc"] = pd.to_numeric(rows["accuracy"], errors="coerce").fillna(-1)
    return rows.sort_values("_acc", ascending=False).iloc[0].to_dict()


def write_failure_taxonomy(path: Path, residuals: pd.DataFrame, reliability: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["# Per-Dataset Failure Taxonomy", ""]
    if residuals.empty:
        lines.append("No residual rows were generated.")
    else:
        for dataset, g in residuals.groupby("dataset"):
            statuses = g["mechanism_status"].value_counts(dropna=False).to_dict()
            signals = g["signal_status"].value_counts(dropna=False).to_dict()
            mean_b = pd.to_numeric(g["B_res"], errors="coerce").mean()
            blocker = infer_blocker(g)
            lines.extend(
                [
                    f"## {dataset}",
                    f"- Dominant blocker: **{blocker}**.",
                    f"- Signal statuses: `{signals}`.",
                    f"- Certificate statuses: `{statuses}`.",
                    f"- Mean residual budget: `{mean_b:.4f}`.",
                    "- Interpretation: Resolve either admits a candidate under the residual certificate or falls back to the best anchor without using test metrics.",
                    "",
                ]
            )
    path.write_text("\n".join(lines), encoding="utf-8")


def infer_blocker(g: pd.DataFrame) -> str:
    eps_cols = ["epsilon_cal", "epsilon_geo", "epsilon_label", "epsilon_rank", "epsilon_opt", "epsilon_cost"]
    vals = {c: pd.to_numeric(g[c], errors="coerce").mean() for c in eps_cols if c in g}
    if not vals:
        return "unidentified"
    key = max(vals, key=lambda c: -1 if pd.isna(vals[c]) else vals[c])
    return {
        "epsilon_cal": "calibration variance",
        "epsilon_geo": "geometry proxy error",
        "epsilon_label": "label-support mismatch",
        "epsilon_rank": "rank projection residual",
        "epsilon_opt": "optimizer residual",
        "epsilon_cost": "cost penalty",
    }.get(key, key)


def write_revised_tables(out: Path, residuals: pd.DataFrame) -> None:
    rows = []
    if not residuals.empty:
        for dataset, g in residuals.groupby("dataset"):
            rows.append(
                {
                    "Dataset": dataset,
                    "Original blocker": infer_original_blocker(dataset),
                    "Dominant residual": infer_blocker(g),
                    "Repair": infer_repair(dataset),
                    "Certified status": ",".join(sorted(g["mechanism_status"].dropna().unique())),
                    "Gain after repair": f"{pd.to_numeric(g['selected_test_acc_diagnostic'], errors='coerce').mean():.4f}",
                    "Interpretation": "certificate or no-regret fallback",
                }
            )
    table = pd.DataFrame(rows)
    write_csv(out / "mechanism_repair_summary.csv", table)
    tex_lines = [
        "\\begin{tabular}{llllll}",
        "\\toprule",
        "Dataset & Blocker & Dominant residual & Repair & Status & Interpretation \\\\",
        "\\midrule",
    ]
    for r in rows:
        tex_lines.append(
            f"{r['Dataset']} & {r['Original blocker']} & {r['Dominant residual']} & {r['Repair']} & {r['Certified status']} & {r['Interpretation']} \\\\"
        )
    tex_lines += ["\\bottomrule", "\\end{tabular}"]
    (out / "revised_main_tables.tex").write_text("\n".join(tex_lines), encoding="utf-8")
    (out / "revised_supplement_tables.tex").write_text(
        "% Include mechanism_decomposition.csv, mechanism_signal_reliability.csv, and residual_budget_summary.csv as supplementary tables.\n"
        + "\n".join(tex_lines),
        encoding="utf-8",
    )


def infer_original_blocker(dataset: str) -> str:
    if "PACS" in dataset:
        return "personalization ceiling"
    if dataset == "OfficeHome":
        return "Ditto ceiling"
    if "DomainNetMini" in dataset:
        return "geometry dominance"
    if "Blood" in dataset:
        return "label skew / calibration variance"
    if "Office-Caltech" in dataset:
        return "small-data strong baseline"
    return "mixed residual"


def infer_repair(dataset: str) -> str:
    if "PACS" in dataset:
        return "personal/shared branch"
    if dataset == "OfficeHome":
        return "Ditto residual FAM"
    if "DomainNetMini" in dataset:
        return "reliability-gated geometry-first admission"
    if "Blood" in dataset:
        return "class-balanced label-support gate"
    if "Office-Caltech" in dataset:
        return "generic Resolve variance-aware margin"
    return "generic Resolve admission"


def write_theory_certificate(path: Path) -> None:
    text = r"""\section{Certified Positive Admission under Residual Decomposition}

For receiver client \(i\), let \(p_i^0\) be the pre-registered safety anchor for the audit protocol, \(M_i\) a fixed manifold-adapter set, and \(A_i=\{p_i^0\}\cup M_i\).  The set \(A_i\) and the anchor identity are fixed before test evaluation.  Let \(m_i\in M_i\) be a manifold candidate.  Suppose the calibration event holds uniformly:
\[
    |R_i(a)-\widehat R_i^{\rm cal}(a)| \le \epsilon_i,\qquad \forall a\in A_i .
\]
Let the non-calibration residual budget be
\[
    B_i^{\rm res} =
    \epsilon_i^{\rm geo}+\epsilon_i^{\rm label}+\epsilon_i^{\rm rank}
    +\epsilon_i^{\rm opt}+\epsilon_i^{\rm cost}.
\]
If
\[
    \widehat R_i^{\rm cal}(p_i^0)-\widehat R_i^{\rm cal}(m_i)
    > 2\epsilon_i + B_i^{\rm res} + \gamma_{\min},
\]
then the admitted manifold candidate gives certified positive transfer:
\[
    R_i(m_i) < R_i(p_i^0)-B_i^{\rm res}.
\]
If no manifold candidate satisfies this inequality and the selector returns \(p_i^0\), then
\[
    R_i(\widehat a_i) = R_i(p_i^0).
\]

\paragraph{Proof.}
The uniform calibration event gives
\[
R_i(m_i)\le \widehat R_i^{\rm cal}(m_i)+\epsilon_i
\quad\text{and}\quad
\widehat R_i^{\rm cal}(p_i^0)\le R_i(p_i^0)+\epsilon_i .
\]
Combining these with the strict admission inequality yields
\[
R_i(m_i)
< \widehat R_i^{\rm cal}(p_i^0)-\epsilon_i-B_i^{\rm res}-\gamma_{\min}
\le R_i(p_i^0)-B_i^{\rm res}-\gamma_{\min},
\]
which proves the positive-transfer certificate.  If the selector falls back to \(p_i^0\), the no-regret statement follows because the deployed adapter is exactly the pre-registered safety anchor.

\paragraph{Weighted mean corollary.}
For client weights \(\alpha_i\), if a subset \(S\) satisfies the positive-admission condition, then the weighted mean risk improves over the anchor by at least
\[
    \sum_{i\in S}\alpha_i
    \left(\widehat R_i^{\rm cal}(p_i^0)-\widehat R_i^{\rm cal}(m_i)
    -2\epsilon_i-B_i^{\rm res}-\gamma_{\min}\right),
\]
while clients outside \(S\) reduce to the no-regret anchor bound.  The residual terms connect to the stationarity decomposition through the one-center scatter \(\Gamma_1\), bank scatter \(\Gamma_K\), geometry-proxy error, rank projection residual, and local optimizer residual.

\paragraph{Boundary.}
This is not a global convergence theorem for arbitrary nonconvex federated LoRA.  It is a high-probability positive-admission certificate under a fixed candidate pool, a calibration event, and residual-budget estimates.
"""
    path.write_text(text, encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
