#!/usr/bin/env python3
"""Build opportunity/no-regret certificates from FedAdapterManifold selector logs.

The certificate turns the anchored selector output into an auditable claim:
for each client-seed unit, did calibration evidence support manifold sharing,
or did the fixed anchor provide a certified personalization ceiling?
"""

from __future__ import annotations

import argparse
import csv
from collections import Counter, defaultdict
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, help="Result root containing seed_* directories.")
    parser.add_argument("--method", default="FedAdapterManifold-StrongSelective")
    parser.add_argument("--fedavg-method", default="FedAvg-LoRA")
    parser.add_argument("--geo-method", default="FedGeo-Agg")
    parser.add_argument("--out-dir", default="")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.root)
    out_dir = Path(args.out_dir) if args.out_dir else root
    out_dir.mkdir(parents=True, exist_ok=True)

    certificate_rows: list[dict] = []
    per_seed_summary: list[dict] = []
    for seed_dir in sorted(path for path in root.glob("seed_*") if path.is_dir()):
        selection_path = seed_dir / "adapter_candidate_selection.csv"
        per_client_path = seed_dir / "per_client_metrics.csv"
        metrics_path = seed_dir / "metrics.csv"
        if not selection_path.exists() or not per_client_path.exists():
            continue
        per_client = _read_csv(per_client_path)
        metrics = _read_csv(metrics_path) if metrics_path.exists() else []
        metric_lookup = {
            (row.get("method", ""), row.get("client_id", "")): row
            for row in per_client
        }
        selected_rows = [
            row
            for row in _read_csv(selection_path)
            if row.get("method") == args.method and _truthy(row.get("selected"))
        ]
        for row in selected_rows:
            client_id = row.get("client_id", "")
            selected_method = row.get("selected_method", "")
            anchor_method = row.get("anchor_method", "")
            best_manifold_method = row.get("best_manifold_method", "")
            diff_mean = _float(row.get("selector_diff_mean"))
            diff_margin = _float(row.get("selector_diff_margin"))
            tolerance = _float(row.get("selector_loss_tolerance"))
            upper = diff_mean + diff_margin
            anchor_selected = selected_method == anchor_method
            if anchor_selected and upper > -max(tolerance, 0.0) + 1e-12:
                decision = "certified_personalization_ceiling"
                claim_role = "safe_no_regret_fallback"
            elif anchor_selected:
                decision = "anchor_selected_despite_positive_margin"
                claim_role = "audit_required"
            elif "ResidualFAM" in selected_method:
                decision = "residual_positive_transfer_admitted"
                claim_role = "residual_gain"
            else:
                decision = "manifold_positive_transfer_admitted"
                claim_role = "positive_transfer"

            selected_metric = metric_lookup.get((args.method, client_id), {})
            anchor_metric = metric_lookup.get((anchor_method, client_id), {})
            fedavg_metric = metric_lookup.get((args.fedavg_method, client_id), {})
            geo_metric = metric_lookup.get((args.geo_method, client_id), {})
            certificate_rows.append(
                {
                    "seed_dir": seed_dir.name,
                    "client_id": client_id,
                    "domain": row.get("domain", ""),
                    "method": args.method,
                    "selected_method": selected_method,
                    "anchor_method": anchor_method,
                    "best_manifold_method": best_manifold_method,
                    "selector_diff_mean": diff_mean,
                    "selector_diff_margin": diff_margin,
                    "selector_diff_upper": upper,
                    "selector_loss_tolerance": tolerance,
                    "decision": decision,
                    "claim_role": claim_role,
                    "selected_accuracy": _float(selected_metric.get("accuracy")),
                    "anchor_accuracy": _float(anchor_metric.get("accuracy")),
                    "fedavg_accuracy": _float(fedavg_metric.get("accuracy")),
                    "geo_accuracy": _float(geo_metric.get("accuracy")),
                    "gain_vs_fedavg": _float(selected_metric.get("accuracy")) - _float(fedavg_metric.get("accuracy")),
                    "gain_vs_geo": _float(selected_metric.get("accuracy")) - _float(geo_metric.get("accuracy")),
                    "gain_vs_anchor": _float(selected_metric.get("accuracy")) - _float(anchor_metric.get("accuracy")),
                }
            )
        seed_metrics = _seed_metric_summary(metrics, args.method, args.fedavg_method, args.geo_method)
        seed_counts = Counter(row["decision"] for row in certificate_rows if row["seed_dir"] == seed_dir.name)
        per_seed_summary.append(
            {
                "seed_dir": seed_dir.name,
                "num_certificates": sum(seed_counts.values()),
                "certified_personalization_ceiling": seed_counts.get("certified_personalization_ceiling", 0),
                "positive_transfer_admitted": seed_counts.get("manifold_positive_transfer_admitted", 0)
                + seed_counts.get("residual_positive_transfer_admitted", 0),
                "audit_required": seed_counts.get("anchor_selected_despite_positive_margin", 0),
                **seed_metrics,
            }
        )

    summary_rows = _overall_summary(certificate_rows, per_seed_summary)
    _write_csv(out_dir / "opportunity_certificate.csv", certificate_rows)
    _write_csv(out_dir / "opportunity_certificate_summary.csv", summary_rows)
    _write_markdown(out_dir / "opportunity_certificate_report.md", root, certificate_rows, per_seed_summary, summary_rows)
    print(f"Wrote opportunity certificate to {out_dir}")
    return 0


def _seed_metric_summary(metrics: list[dict], method: str, fedavg: str, geo: str) -> dict[str, float | str]:
    lookup = {row.get("method", ""): row for row in metrics}
    method_acc = _float(lookup.get(method, {}).get("mean_accuracy"))
    fedavg_acc = _float(lookup.get(fedavg, {}).get("mean_accuracy"))
    geo_acc = _float(lookup.get(geo, {}).get("mean_accuracy"))
    return {
        "mean_accuracy": method_acc,
        "fedavg_mean_accuracy": fedavg_acc,
        "geo_mean_accuracy": geo_acc,
        "gain_vs_fedavg_mean": method_acc - fedavg_acc,
        "gain_vs_geo_mean": method_acc - geo_acc,
    }


def _overall_summary(certificate_rows: list[dict], per_seed_summary: list[dict]) -> list[dict]:
    counts = Counter(row["decision"] for row in certificate_rows)
    gains = defaultdict(list)
    for row in certificate_rows:
        for key in ("gain_vs_fedavg", "gain_vs_geo", "gain_vs_anchor"):
            value = row.get(key)
            if isinstance(value, float):
                gains[key].append(value)
    seed_gains = defaultdict(list)
    for row in per_seed_summary:
        for key in ("gain_vs_fedavg_mean", "gain_vs_geo_mean"):
            value = row.get(key)
            if isinstance(value, float):
                seed_gains[key].append(value)
    return [
        {
            "num_client_seed_units": len(certificate_rows),
            "certified_personalization_ceiling": counts.get("certified_personalization_ceiling", 0),
            "positive_transfer_admitted": counts.get("manifold_positive_transfer_admitted", 0)
            + counts.get("residual_positive_transfer_admitted", 0),
            "audit_required": counts.get("anchor_selected_despite_positive_margin", 0),
            "mean_client_gain_vs_fedavg": _mean(gains["gain_vs_fedavg"]),
            "mean_client_gain_vs_geo": _mean(gains["gain_vs_geo"]),
            "mean_client_gain_vs_anchor": _mean(gains["gain_vs_anchor"]),
            "mean_seed_gain_vs_fedavg": _mean(seed_gains["gain_vs_fedavg_mean"]),
            "mean_seed_gain_vs_geo": _mean(seed_gains["gain_vs_geo_mean"]),
        }
    ]


def _write_markdown(
    path: Path,
    root: Path,
    certificate_rows: list[dict],
    per_seed_summary: list[dict],
    summary_rows: list[dict],
) -> None:
    summary = summary_rows[0] if summary_rows else {}
    decision_counts = Counter(row["decision"] for row in certificate_rows)
    best_counts = Counter(row["best_manifold_method"] for row in certificate_rows)
    lines = [
        "# Opportunity-Certified Routing Report",
        "",
        f"Result root: `{root}`",
        "",
        "## Overall Certificate",
        "",
        f"- Client-seed units: {summary.get('num_client_seed_units', 0)}",
        f"- Certified personalization ceilings: {summary.get('certified_personalization_ceiling', 0)}",
        f"- Positive-transfer admissions: {summary.get('positive_transfer_admitted', 0)}",
        f"- Audit-required cases: {summary.get('audit_required', 0)}",
        f"- Mean client gain vs FedAvg-LoRA: {_fmt(summary.get('mean_client_gain_vs_fedavg'))}",
        f"- Mean client gain vs FedGeo-Agg: {_fmt(summary.get('mean_client_gain_vs_geo'))}",
        f"- Mean client gain vs anchor: {_fmt(summary.get('mean_client_gain_vs_anchor'))}",
        "",
        "## Decision Counts",
        "",
    ]
    for decision, count in sorted(decision_counts.items()):
        lines.append(f"- {decision}: {count}")
    lines.extend(["", "## Best Manifold-Side Candidate Counts", ""])
    for method, count in sorted(best_counts.items()):
        lines.append(f"- {method}: {count}")
    lines.extend(["", "## Per-Seed Summary", ""])
    lines.append("| Seed | Certificates | Ceiling | Positive transfer | Audit required | Gain vs FedAvg | Gain vs Geo |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|")
    for row in per_seed_summary:
        lines.append(
            "| {seed} | {n} | {ceil} | {pos} | {audit} | {gf} | {gg} |".format(
                seed=row.get("seed_dir", ""),
                n=row.get("num_certificates", 0),
                ceil=row.get("certified_personalization_ceiling", 0),
                pos=row.get("positive_transfer_admitted", 0),
                audit=row.get("audit_required", 0),
                gf=_fmt(row.get("gain_vs_fedavg_mean")),
                gg=_fmt(row.get("gain_vs_geo_mean")),
            )
        )
    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "A certified personalization ceiling means that the best manifold-side candidate did not beat the fixed anchor by the anchored-diff-LCB calibration margin. In such cases, selecting the anchor is a no-regret decision rather than post-hoc method switching.",
            "",
        ]
    )
    path.write_text("\n".join(lines), encoding="utf-8")


def _read_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _float(value) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _fmt(value) -> str:
    try:
        return f"{float(value):+.6f}"
    except (TypeError, ValueError):
        return ""


def _truthy(value) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes"}


if __name__ == "__main__":
    raise SystemExit(main())

