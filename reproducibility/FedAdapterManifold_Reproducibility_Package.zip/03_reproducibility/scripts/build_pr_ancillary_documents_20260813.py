from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "paper_resubmit" / "ancillary"
TITLE = "FedAdapterManifold: Deciding When Federated Visual LoRA Adapters Are Safe to Share"
AUTHORS = "Leyuan Zhang and Yang Long"
DATE = "13 August 2026"

HIGHLIGHTS = [
    "LoRA subspace incompatibility predicts receiver-specific FedAvg failure.",
    "Geometry proposes neighbors; subspace evidence and calibration decide admission.",
    "Exact calibration controls false admission with immutable Local-LoRA fallback.",
    "A five-seed PACS audit gains 5.08 points with no harmful client-seed unit.",
    "CLIP and DINOv2 audits verify the mechanism across visual backbones.",
]


def set_font(run, size: float = 8, bold: bool = False, italic: bool = False) -> None:
    run.font.name = "Times New Roman"
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Times New Roman")
    run.font.size = Pt(size)
    run.bold = bold
    run.italic = italic


def setup_document() -> Document:
    document = Document()
    section = document.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.right_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    normal = document.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    normal.font.size = Pt(8)
    normal.paragraph_format.space_after = Pt(4)
    return document


def add_centered(document: Document, text: str, size: float, bold: bool = False):
    paragraph = document.add_paragraph()
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    paragraph.paragraph_format.space_after = Pt(8)
    set_font(paragraph.add_run(text), size=size, bold=bold)
    return paragraph


def add_labelled(document: Document, label: str, value: str) -> None:
    paragraph = document.add_paragraph()
    paragraph.paragraph_format.space_after = Pt(5)
    set_font(paragraph.add_run(f"{label}: "), bold=True)
    set_font(paragraph.add_run(value))


def apply_real_bullet(paragraph) -> None:
    p_pr = paragraph._p.get_or_add_pPr()
    num_pr = OxmlElement("w:numPr")
    ilvl = OxmlElement("w:ilvl")
    ilvl.set(qn("w:val"), "0")
    num_id = OxmlElement("w:numId")
    num_id.set(qn("w:val"), "1")
    num_pr.extend([ilvl, num_id])
    p_pr.append(num_pr)


def build_highlights() -> Path:
    if any(len(item) > 85 for item in HIGHLIGHTS):
        raise RuntimeError("Every Elsevier highlight must contain at most 85 characters.")
    document = setup_document()
    add_centered(document, "Highlights", 14, True)
    add_centered(document, TITLE, 10)
    for item in HIGHLIGHTS:
        paragraph = document.add_paragraph()
        paragraph.paragraph_format.left_indent = Inches(0.25)
        paragraph.paragraph_format.first_line_indent = Inches(-0.15)
        paragraph.paragraph_format.space_after = Pt(5)
        apply_real_bullet(paragraph)
        set_font(paragraph.add_run(item), size=10)
    path = OUTPUT / "FedAdapterManifold_Highlights.docx"
    document.save(path)
    return path


def build_declaration() -> Path:
    document = setup_document()
    add_centered(document, "Declaration of Competing Interests", 14, True)
    add_labelled(document, "Manuscript title", TITLE)
    add_labelled(document, "Authors", AUTHORS)
    paragraph = document.add_paragraph()
    paragraph.paragraph_format.space_before = Pt(8)
    paragraph.paragraph_format.space_after = Pt(8)
    set_font(
        paragraph.add_run(
            "The authors declare that they have no known competing financial interests "
            "or personal relationships that could have appeared to influence the work "
            "reported in this paper."
        ),
        size=10,
    )
    add_labelled(
        document,
        "Author confirmation",
        "Confirmed by Yang Long, corresponding author, on behalf of all authors",
    )
    add_labelled(document, "Date", DATE)
    path = OUTPUT / "Declaration_of_Competing_Interests_No_Conflict.docx"
    document.save(path)
    return path


def build_title_page() -> Path:
    document = setup_document()
    add_centered(document, TITLE, 14, True)
    add_centered(document, "Leyuan Zhang\u00b9 and Yang Long\u00b9,*", 8)
    add_centered(
        document,
        "\u00b9 Department of Computer Science, Durham University, Durham, DH1 3LE, United Kingdom",
        8,
    )
    document.add_paragraph()
    add_labelled(document, "Corresponding author", "Yang Long")
    add_labelled(document, "Corresponding author email", "yang.long@durham.ac.uk")
    add_labelled(document, "First author email", "leyuan.zhang@durham.ac.uk")
    add_labelled(document, "Article type", "Original research article")
    add_labelled(document, "Target journal", "Pattern Recognition")
    add_labelled(document, "Previous manuscript reference", "PR-D-26-08222")
    path = OUTPUT / "FedAdapterManifold_Title_Page_with_Author_Details.docx"
    document.save(path)
    return path


def build_upload_guide() -> Path:
    content = """# Pattern Recognition Upload Map

Upload the files individually with the following Editorial Manager item types:

1. `Manuscript.pdf` -> Manuscript.
2. `FedAdapterManifold_Highlights.docx` -> Highlights.
3. `Declaration_of_Competing_Interests_No_Conflict.docx` -> Declaration of competing interests.
4. `Cover_Letter.pdf` -> Cover letter. This file contains the point-by-point response to PR-D-26-08222.
5. `FedAdapterManifold_Title_Page_with_Author_Details.docx` -> Title page with author details.
6. `Supplementary_Material.pdf` -> Supplementary material.

No graphical abstract is included. Figure 1 remains an explanatory image in the
manuscript; its AI-assisted initial drafting and author redraw/verification are
disclosed in both its caption and the manuscript's general AI statement.

The manuscript already contains author names, affiliations, funding, CRediT roles,
competing-interest text, data/code availability, and the generative-AI disclosure.
The separate DOCX declaration should remain in DOCX format when uploaded.
"""
    path = OUTPUT / "UPLOAD_MAP.md"
    path.write_text(content, encoding="utf-8")
    return path


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    for path in OUTPUT.iterdir():
        if path.is_file():
            path.unlink()
    outputs = [
        build_highlights(),
        build_declaration(),
        build_title_page(),
        build_upload_guide(),
    ]
    for path in outputs:
        print(path.relative_to(ROOT))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
