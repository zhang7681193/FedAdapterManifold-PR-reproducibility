from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "results" / "recent_lora_receiver_admission_overlay_20260812"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def group_mean(rows: list[dict[str, str]], field: str) -> float:
    return float(np.mean([float(row[field]) for row in rows]))


def pacs_rows() -> list[dict[str, object]]:
    source = (
        ROOT
        / "results"
        / "fedtree_fam_admission_evidence_20260812"
        / "client_seed_units.csv"
    )
    rows = [row for row in read_csv(source) if row["protocol"] == "cal48_marginal"]
    grouped: dict[int, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[int(row["seed"])].append(row)
    return [
        {
            "setting": "PACS-R18",
            "seed": seed,
            "comparison_role": "external-expert residual composition",
            "reference_method": "FedTreeLoRA",
            "reference_accuracy": group_mean(group, "FedTreeLoRA-Visual-Port"),
            "fam_method": "FAM FedTree-anchor residual",
            "fam_accuracy": group_mean(group, "FedAdapterManifold-FedTreeAnchorResidualAdmit"),
            "composition_from_reference": True,
            "calibration_protocol": "48 of 240 training-side examples; 192 adapter-training",
            "source_file": source.relative_to(ROOT).as_posix(),
        }
        for seed, group in sorted(grouped.items())
    ]


def officehome_rows() -> list[dict[str, object]]:
    source = (
        ROOT
        / "results"
        / "direct_anchor_route_officehome_fedgeo_5seed_20260811"
        / "target_constrained_utility_audit"
        / "paired_test_accuracy.csv"
    )
    rows = read_csv(source)
    grouped: dict[int, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[int(row["seed"])].append(row)
    # The frozen cumulative-source audit reports FedSmoothLoRA at 0.7310 in its
    # matched method table. Per-seed FedSmooth values are read from the source
    # experiment so that paired effects are not reconstructed from a grand mean.
    source_root = ROOT / "results" / "direct_anchor_lorafair_officehome_5seed_20260811"
    source_by_seed: dict[int, float] = {}
    for seed in range(5):
        metrics = read_csv(source_root / "officehome_clip_full" / f"seed_{seed}" / "metrics.csv")
        match = [row for row in metrics if row["method"] == "FedSmoothLoRA"]
        if len(match) != 1:
            raise ValueError(f"OfficeHome seed {seed}: expected one FedSmoothLoRA row")
        source_by_seed[seed] = float(match[0]["mean_accuracy"])
    return [
        {
            "setting": "OfficeHome-CLIP",
            "seed": seed,
            "comparison_role": "matched recent-method comparison",
            "reference_method": "FedSmoothLoRA",
            "reference_accuracy": source_by_seed[seed],
            "fam_method": "FAM target-constrained direct route",
            "fam_accuracy": group_mean(group, "FedAdapterManifold-DirectAnchorRoute"),
            "composition_from_reference": False,
            "calibration_protocol": "fixed target-constrained training-side calibration",
            "source_file": source.relative_to(ROOT).as_posix(),
        }
        for seed, group in sorted(grouped.items())
    ]


def domainnet_rows() -> list[dict[str, object]]:
    source = (
        ROOT
        / "results"
        / "recent_lora_fairness_20260804"
        / "domainnetmini_dual_transport_dualanchor_5seed"
        / "dual_transport_seed_metrics.csv"
    )
    return [
        {
            "setting": "DomainNetMini-CLIP",
            "seed": int(row["seed"]),
            "comparison_role": "external-expert residual composition",
            "reference_method": "FedSA-compatible shared-axis center",
            "reference_accuracy": float(row["anchor_accuracy"]),
            "fam_method": "FAM dual transport",
            "fam_accuracy": float(row["method_accuracy"]),
            "composition_from_reference": True,
            "calibration_protocol": "fixed dual-transport receiver correction",
            "source_file": source.relative_to(ROOT).as_posix(),
        }
        for row in read_csv(source)
    ]


def main() -> None:
    seed_rows = pacs_rows() + officehome_rows() + domainnet_rows()
    summaries: list[dict[str, object]] = []
    for setting in ("PACS-R18", "OfficeHome-CLIP", "DomainNetMini-CLIP"):
        group = [row for row in seed_rows if row["setting"] == setting]
        reference = np.array([float(row["reference_accuracy"]) for row in group])
        fam = np.array([float(row["fam_accuracy"]) for row in group])
        summaries.append(
            {
                "setting": setting,
                "comparison_role": group[0]["comparison_role"],
                "reference_method": group[0]["reference_method"],
                "fam_method": group[0]["fam_method"],
                "composition_from_reference": group[0]["composition_from_reference"],
                "seed_count": len(group),
                "reference_accuracy_mean": reference.mean(),
                "fam_accuracy_mean": fam.mean(),
                "fam_accuracy_seed_sd": fam.std(ddof=1),
                "paired_gain": (fam - reference).mean(),
                "positive_seeds": int(np.sum(fam > reference + 1e-12)),
                "tie_seeds": int(np.sum(np.abs(fam - reference) <= 1e-12)),
                "negative_seeds": int(np.sum(fam < reference - 1e-12)),
                "calibration_protocol": group[0]["calibration_protocol"],
            }
        )
    write_csv(OUTPUT / "receiver_admission_seed_metrics.csv", seed_rows)
    write_csv(OUTPUT / "receiver_admission_setting_summary.csv", summaries)
    print(f"Wrote {len(seed_rows)} seed rows and {len(summaries)} setting summaries")


if __name__ == "__main__":
    main()
