#!/usr/bin/env python3
"""Build targeted Stage-2 rerun configs for FedAdapterManifold-Resolve.

Stage 1 identified calibration variance as the dominant unresolved blocker.
This script does not invent new data paths.  It clones audited seed configs from
existing result roots and only changes the pre-registered Resolve controls:
stratified calibration, anchored-no-regret selection, fixed anchor priority, and
dedicated output roots.
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.config import dump_yaml, load_yaml


STAGE2_SPECS: list[dict[str, Any]] = [
    {
        "key": "pacs_resnet18",
        "dataset_label": "PACS",
        "source_root": "results/fam_pacs_manifest_fedavg_fedper_fam_5seed_v1",
        "calibration_fraction": 0.20,
        "anchor_priority": "FedPer-LoRA,SCAFFOLD-LoRA,FedAvg-LoRA,Local-LoRA",
        "neighbor_weight": 0.00,
        "loss_tolerance": 0.001,
        "loss_tolerance_ratio": 0.00,
    },
    {
        "key": "officehome_clip_feature",
        "dataset_label": "OfficeHome",
        "source_root": "results/fam_officehome_ditto_fam_guarded_audit_5seed_v1",
        "calibration_fraction": 0.20,
        "anchor_priority": "Ditto-LoRA,FedAvg-LoRA,Local-LoRA",
        "neighbor_weight": 0.00,
        "loss_tolerance": 0.001,
        "loss_tolerance_ratio": 0.00,
    },
    {
        "key": "domainnetmini_clip",
        "dataset_label": "DomainNetMini",
        "source_root": "results/fam_domainnetmini_manifest_fedavg_fedper_fam_5seed_v1",
        "calibration_fraction": 0.20,
        "anchor_priority": "FedGeo-Agg,FedAvg-LoRA,FedPer-LoRA,Local-LoRA",
        "neighbor_weight": 0.15,
        "loss_tolerance": 0.001,
        "loss_tolerance_ratio": 0.00,
    },
    {
        "key": "bloodmnist_label_skew",
        "dataset_label": "BloodMNIST",
        "source_root": "results/fam_blood_manifest_fedavg_fedper_fam_5seed_v1",
        "calibration_fraction": 0.25,
        "anchor_priority": "FedGeo-Agg,FedAvg-LoRA,FedPer-LoRA,Local-LoRA",
        "neighbor_weight": 0.05,
        "loss_tolerance": 0.001,
        "loss_tolerance_ratio": 0.00,
    },
    {
        "key": "officecaltech_resnet18",
        "dataset_label": "Office-Caltech",
        "source_root": "results/fam_officecaltech_neighbor_selector_fedrot_w050_v1",
        "calibration_fraction": 0.25,
        "anchor_priority": "FedPer-LoRA,FedAvg-Lift,FedRot-LoRA,FedAvg-LoRA,Local-LoRA",
        "neighbor_weight": 0.05,
        "loss_tolerance": 0.001,
        "loss_tolerance_ratio": 0.00,
    },
    {
        "key": "pacs_dinov2",
        "dataset_label": "PACS-DINOv2",
        "source_root": "results/fam_dinov2_pacs_calib20_noregret_5seed_v1",
        "calibration_fraction": 0.20,
        "anchor_priority": "FedPer-LoRA,SCAFFOLD-LoRA,FedAvg-LoRA,Local-LoRA",
        "neighbor_weight": 0.00,
        "loss_tolerance": 0.001,
        "loss_tolerance_ratio": 0.00,
    },
    {
        "key": "officehome_dinov2",
        "dataset_label": "OfficeHome-DINOv2",
        "source_root": "results/fam_dinov2_officehome_full_calib20_noregret_5seed_v1",
        "calibration_fraction": 0.20,
        "anchor_priority": "Ditto-LoRA,FedAvg-LoRA,Local-LoRA",
        "neighbor_weight": 0.00,
        "loss_tolerance": 0.001,
        "loss_tolerance_ratio": 0.00,
    },
    {
        "key": "officehome_clip_full",
        "dataset_label": "OfficeHome-CLIP",
        "source_root": "results/fam_clip_officehome_full_calib20_noregret_5seed_v2",
        "calibration_fraction": 0.20,
        "anchor_priority": "Ditto-LoRA,FedAvg-LoRA,Local-LoRA",
        "neighbor_weight": 0.00,
        "loss_tolerance": 0.001,
        "loss_tolerance_ratio": 0.00,
    },
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config-dir", default="configs/resolve_stage2_20260629")
    parser.add_argument("--output-root", default="results/fam_resolve_stage2_20260629")
    parser.add_argument("--seeds", default="0,1,2,3,4")
    parser.add_argument(
        "--hybrid-policy",
        choices=["keep", "residual-search"],
        default="keep",
        help="When residual-search, FedPer/ Ditto-FAM candidates use loss-min before anchored admission.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    config_dir = Path(args.config_dir)
    output_root = Path(args.output_root)
    config_dir.mkdir(parents=True, exist_ok=True)
    output_root.mkdir(parents=True, exist_ok=True)
    seeds = [int(part.strip()) for part in args.seeds.split(",") if part.strip()]

    manifest_rows: list[dict[str, Any]] = []
    commands: list[str] = []
    py = r"python"

    for spec in STAGE2_SPECS:
        source_root = Path(spec["source_root"])
        if not source_root.exists():
            continue
        for seed in seeds:
            source_config = source_root / f"seed_{seed}" / "config.yaml"
            if not source_config.exists():
                continue
            cfg = load_yaml(source_config)
            cfg.pop("effective_base_head_norm", None)
            cfg.pop("effective_class_names", None)
            cfg.pop("effective_client_domains", None)
            cfg.pop("effective_feature_dim", None)
            cfg.pop("effective_num_classes", None)
            cfg.pop("effective_num_clients", None)
            cfg.pop("effective_test_samples_per_client", None)
            cfg.pop("effective_train_samples_per_client", None)

            cfg["seed"] = seed
            cfg["candidate_selector_calibration_fraction"] = spec["calibration_fraction"]
            cfg["candidate_selector_calibration_strategy"] = "stratified"
            selector_policy = "anchored-diff-lcb" if args.hybrid_policy == "residual-search" else "anchored-no-regret"
            cfg["candidate_selector_policy"] = selector_policy
            cfg["strong_candidate_selector_policy"] = selector_policy
            cfg["candidate_selector_anchor_priority"] = spec["anchor_priority"]
            cfg["strong_candidate_selector_anchor_priority"] = spec["anchor_priority"]
            cfg["candidate_selector_neighbor_weight"] = spec["neighbor_weight"]
            cfg["candidate_selector_loss_tolerance"] = spec["loss_tolerance"]
            cfg["candidate_selector_loss_tolerance_ratio"] = spec["loss_tolerance_ratio"]
            cfg["candidate_selector_lcb_delta"] = 0.05
            if args.hybrid_policy == "residual-search":
                cfg["fedper_fam_policy"] = "loss-min"
                cfg["fedper_fam_loss_tolerance"] = 0.001
                cfg["ditto_fam_policy"] = "loss-min"
                cfg["ditto_fam_loss_tolerance"] = 0.001
                cfg["anchor_residual_epochs"] = 4
                cfg["anchor_residual_lr_scale"] = 0.5
                cfg["anchor_residual_rank"] = 0
                cfg["anchor_residual_validation_fraction"] = 0.20
                cfg["anchor_residual_validation_strategy"] = "stratified"
                cfg["anchor_residual_shrinkage_candidates"] = "1.0"
                cfg["anchor_residual_selector_shrinkage_candidates"] = "0.05,0.10,0.20,0.35,0.50,0.75"
            cfg["continue_on_failed_diagnostic"] = True
            cfg["heterogeneity_setting"] = f"{cfg.get('heterogeneity_setting', spec['dataset_label'])}-resolve-stage2"
            cfg["output_dir"] = str(output_root / spec["key"] / f"seed_{seed}")

            out_path = config_dir / spec["key"] / f"seed_{seed}.yaml"
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(dump_yaml(cfg), encoding="utf-8")

            cmd = f'& "{py}" -m fedadaptermanifold.run_experiment --config "{out_path}"'
            commands.append(cmd)
            manifest_rows.append(
                {
                    "dataset": spec["dataset_label"],
                    "key": spec["key"],
                    "seed": seed,
                    "source_config": str(source_config),
                    "stage2_config": str(out_path),
                    "output_dir": cfg["output_dir"],
                    "calibration_fraction": spec["calibration_fraction"],
                    "calibration_strategy": "stratified",
                    "anchor_priority": spec["anchor_priority"],
                    "neighbor_weight": spec["neighbor_weight"],
                    "loss_tolerance": spec["loss_tolerance"],
                    "loss_tolerance_ratio": spec["loss_tolerance_ratio"],
                }
            )

    manifest_path = config_dir / "stage2_manifest.csv"
    with manifest_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(manifest_rows[0].keys()) if manifest_rows else ["dataset"])
        writer.writeheader()
        writer.writerows(manifest_rows)

    ps1 = config_dir / "run_stage2_resolve.ps1"
    ps1.write_text("\n".join(commands) + "\n", encoding="utf-8")

    md = config_dir / "README.md"
    md.write_text(
        "# FedAdapterManifold-Resolve Stage 2 rerun plan\n\n"
        "Purpose: reduce the remaining calibration-variance blocker found in Stage 1.\n\n"
        "- Uses stratified held-out calibration.\n"
        "- Uses anchored-no-regret selection for both default and expanded selectors.\n"
        "- Uses fixed, pre-registered anchor priority per dataset.\n"
        "- Uses an LCB-only admission margin instead of an additional relative-loss margin.\n"
        "- With `--hybrid-policy residual-search`, adds trained anchor-residual FAM candidates.\n"
        "- Reuses existing seed-specific data roots and geometry outputs from audited runs.\n\n"
        f"Configs: `{config_dir}`\n\n"
        f"Run all commands from the repository root with PowerShell:\n\n```powershell\n.\\{ps1}\n```\n",
        encoding="utf-8",
    )

    print(f"Wrote {len(manifest_rows)} configs to {config_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
