from __future__ import annotations

import argparse
import csv
import random
from pathlib import Path
from statistics import mean


FAM_FAMILY = {
    "FedAdapterManifold",
    "FedAdapterManifold-Selective",
    "FedAdapterManifold-StrongSelective",
    "FedPer-FAM",
    "FedPer-FAM-Selective",
    "Ditto-FAM",
    "Ditto-FAM-Selective",
}


def main() -> int:
    args = parse_args()
    pack = Path(args.evidence_pack)
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    accuracy = read_csv(pack / "main_accuracy_with_strong_baselines.csv")
    paired = read_csv(pack / "paired_significance.csv")
    diagnostics = read_csv(pack / "mechanism_diagnostics.csv")

    ceiling_rows = personalization_ceiling_rows(accuracy)
    geometry_rows = geometry_ceiling_rows(paired, diagnostics)
    mechanism_rows = mechanism_rows_from_diagnostics(diagnostics)
    hybrid_rows = hybrid_paired_rows(accuracy)
    failure_rows = failure_mode_rows(ceiling_rows, geometry_rows, mechanism_rows, hybrid_rows)

    write_csv(out / "personalization_ceiling_audit.csv", ceiling_rows)
    write_csv(out / "geometry_ceiling_audit.csv", geometry_rows)
    write_csv(out / "mechanism_signal_audit.csv", mechanism_rows)
    write_csv(out / "hybrid_no_regret_paired_audit.csv", hybrid_rows)
    write_csv(out / "failure_mode_feedback.csv", failure_rows)
    write_report(out / "theory_experiment_feedback_report.md", failure_rows, ceiling_rows, geometry_rows, mechanism_rows, hybrid_rows)
    return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build theory-to-experiment feedback audit for FedAdapterManifold.")
    parser.add_argument("--evidence-pack", default="results/fam_pami_seven_item_pack_v15")
    parser.add_argument("--output-dir", default="results/fam_theory_experiment_feedback_v1")
    return parser.parse_args()


def read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def fnum(value: str | float | None, default: float = float("nan")) -> float:
    try:
        if value in {"", None}:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def fmt(value: float | str) -> str:
    value = fnum(value)
    if value != value:
        return ""
    return f"{value:.4f}"


def by_dataset_method(rows: list[dict]) -> dict[tuple[str, str], dict]:
    return {(row.get("dataset", ""), row.get("method", "")): row for row in rows}


def personalization_ceiling_rows(accuracy: list[dict]) -> list[dict]:
    table = by_dataset_method(accuracy)
    datasets = sorted({row.get("dataset", "") for row in accuracy if row.get("dataset")})
    rows: list[dict] = []
    for dataset in datasets:
        ds_rows = [row for row in accuracy if row.get("dataset") == dataset]
        best_non_fam = max(
            (row for row in ds_rows if row.get("method") not in FAM_FAMILY),
            key=lambda row: fnum(row.get("mean_accuracy")),
            default={},
        )
        hybrid_method = "Ditto-FAM" if (dataset, "Ditto-FAM") in table else "FedPer-FAM"
        hybrid = table.get((dataset, hybrid_method), {})
        strong = table.get((dataset, "FedAdapterManifold-StrongSelective"), {})
        hybrid_acc = fnum(hybrid.get("mean_accuracy"))
        best_acc = fnum(best_non_fam.get("mean_accuracy"))
        strong_acc = fnum(strong.get("mean_accuracy"))
        rows.append(
            {
                "dataset": dataset,
                "best_non_fam_method": best_non_fam.get("method", ""),
                "best_non_fam_accuracy": fmt(best_acc),
                "hybrid_method": hybrid_method if hybrid else "",
                "hybrid_accuracy": fmt(hybrid_acc),
                "hybrid_minus_best_non_fam": fmt(hybrid_acc - best_acc),
                "strongselective_accuracy": fmt(strong_acc),
                "strongselective_minus_best_non_fam": fmt(strong_acc - best_acc),
                "diagnosis": personalization_diagnosis(hybrid_acc, strong_acc, best_acc),
                "theory_feedback": "Use the fixed-candidate no-regret bound: if the personalized branch is in the candidate set, Hybrid-FAM should not be worse than it beyond calibration error.",
            }
        )
    return rows


def personalization_diagnosis(hybrid_acc: float, strong_acc: float, best_acc: float) -> str:
    if hybrid_acc != hybrid_acc or best_acc != best_acc:
        return "missing_hybrid_or_baseline"
    if hybrid_acc + 1e-12 >= best_acc:
        if abs(hybrid_acc - best_acc) < 5e-4:
            return "no_regret_tie_with_personalized_ceiling"
        return "hybrid_resolves_personalized_ceiling"
    if strong_acc == strong_acc and strong_acc >= best_acc:
        return "expanded_selector_resolves_personalized_ceiling"
    return "remaining_personalization_caveat"


def geometry_ceiling_rows(paired: list[dict], diagnostics: list[dict]) -> list[dict]:
    rows: list[dict] = []
    datasets = sorted({row.get("dataset", "") for row in paired if row.get("dataset")})
    for dataset in datasets:
        strong_vs_geo = find_paired(paired, dataset, "FedAdapterManifold-StrongSelective", "FedGeo-Agg")
        gain = fnum(strong_vs_geo.get("mean_accuracy_diff"))
        ci_low = fnum(strong_vs_geo.get("ci_low"))
        conflict = find_claim(diagnostics, dataset, "update_conflict_reduction_vs_fedavg")
        conflict_gain = fnum(conflict.get("estimate"))
        if ci_low == ci_low and ci_low > 0:
            diagnosis = "accuracy_gain_beyond_geometry_control"
        elif gain == gain and gain >= -1e-12:
            diagnosis = "geometry_ceiling_no_decisive_accuracy_gain"
        else:
            diagnosis = "negative_vs_geometry_control"
        rows.append(
            {
                "dataset": dataset,
                "strongselective_gain_vs_geoagg": fmt(gain),
                "ci_low": fmt(ci_low),
                "update_conflict_reduction_vs_fedavg": fmt(conflict_gain),
                "diagnosis": diagnosis,
                "theory_feedback": "When Geometry-Agg is already near a client-specific ceiling, no-regret routing should be judged by FedAvg repair, conflict reduction, and absence of harm rather than mandatory significant gain over Geometry-Agg.",
            }
        )
    return rows


def mechanism_rows_from_diagnostics(diagnostics: list[dict]) -> list[dict]:
    rows: list[dict] = []
    for row in diagnostics:
        if row.get("claim_id") != "adapter_incompatibility_failure_correlation":
            continue
        r = fnum(row.get("estimate"))
        ci_low = fnum(row.get("ci_low"))
        if ci_low == ci_low and ci_low > 0.25:
            diagnosis = "strong_subspace_mechanism"
        elif ci_low == ci_low and ci_low > 0:
            diagnosis = "positive_but_moderate_subspace_mechanism"
        else:
            diagnosis = "weak_or_mixed_subspace_mechanism"
        if row.get("dataset") == "DomainNetMini":
            diagnosis = "geometry_dominated_hard_case_with_positive_raw_subspace_signal"
        rows.append(
            {
                "dataset": row.get("dataset", ""),
                "adapter_failure_correlation": fmt(r),
                "ci_low": fmt(ci_low),
                "diagnosis": diagnosis,
                "theory_feedback": "Use the multi-signal compatibility model: Grassmannian conflict is a measurable mechanism, but visual geometry and label structure can dominate in hard multi-domain cases.",
            }
        )
    return rows


def hybrid_paired_rows(accuracy: list[dict]) -> list[dict]:
    rows: list[dict] = []
    for dataset in sorted({row.get("dataset", "") for row in accuracy if row.get("dataset")}):
        ds_rows = [row for row in accuracy if row.get("dataset") == dataset]
        best_non_fam = max(
            (row for row in ds_rows if row.get("method") not in FAM_FAMILY),
            key=lambda row: fnum(row.get("mean_accuracy")),
            default={},
        )
        if not best_non_fam:
            continue
        source = Path(best_non_fam.get("source", ""))
        per_client = read_csv(source / "multiseed_per_client_metrics.csv")
        if not per_client:
            continue
        hybrid_method = "Ditto-FAM" if has_method(per_client, "Ditto-FAM") else "FedPer-FAM"
        if not has_method(per_client, hybrid_method):
            continue
        diffs = paired_diffs(per_client, hybrid_method, best_non_fam.get("method", ""))
        if not diffs:
            continue
        ci_low, ci_high = bootstrap_ci(diffs)
        rows.append(
            {
                "dataset": dataset,
                "hybrid_method": hybrid_method,
                "baseline_method": best_non_fam.get("method", ""),
                "paired_units": len(diffs),
                "mean_diff": fmt(mean(diffs)),
                "ci_low": fmt(ci_low),
                "ci_high": fmt(ci_high),
                "diagnosis": "significant_or_positive_hybrid_gain" if ci_low > 0 else "no_regret_or_tied_hybrid_gain",
            }
        )
    return rows


def failure_mode_rows(
    ceiling_rows: list[dict],
    geometry_rows: list[dict],
    mechanism_rows: list[dict],
    hybrid_rows: list[dict],
) -> list[dict]:
    ceiling = {row["dataset"]: row for row in ceiling_rows}
    geometry = {row["dataset"]: row for row in geometry_rows}
    mechanism = {row["dataset"]: row for row in mechanism_rows}
    hybrid = {row["dataset"]: row for row in hybrid_rows}
    datasets = sorted(set(ceiling) | set(geometry) | set(mechanism))
    rows: list[dict] = []
    for dataset in datasets:
        rows.append(
            {
                "dataset": dataset,
                "experimental_problem": summarize_problem(dataset, ceiling.get(dataset, {}), geometry.get(dataset, {}), mechanism.get(dataset, {})),
                "theory_response": summarize_theory(dataset),
                "feedback_to_experiment": summarize_feedback(dataset, ceiling.get(dataset, {}), geometry.get(dataset, {}), hybrid.get(dataset, {})),
                "paper_claim": summarize_claim(dataset),
            }
        )
    return rows


def summarize_problem(dataset: str, ceiling: dict, geometry: dict, mechanism: dict) -> str:
    parts = []
    if ceiling.get("diagnosis") in {"no_regret_tie_with_personalized_ceiling", "hybrid_resolves_personalized_ceiling"}:
        parts.append(f"personalized ceiling: hybrid-best={ceiling.get('hybrid_minus_best_non_fam')}")
    elif ceiling.get("diagnosis"):
        parts.append(ceiling["diagnosis"])
    if geometry.get("diagnosis") == "geometry_ceiling_no_decisive_accuracy_gain":
        parts.append(f"geometry ceiling: gain-vs-GeoAgg={geometry.get('strongselective_gain_vs_geoagg')}, CI-low={geometry.get('ci_low')}")
    if mechanism.get("diagnosis"):
        parts.append(f"mechanism={mechanism.get('diagnosis')}, r={mechanism.get('adapter_failure_correlation')}")
    return "; ".join(parts)


def summarize_theory(dataset: str) -> str:
    if dataset in {"PACS", "OfficeHomeFull"}:
        return "Hybrid no-regret corollary: include the strong personalized branch and select against local calibration loss; the expected risk is bounded by the best pre-registered branch plus finite-sample error."
    if dataset == "DomainNetMini":
        return "Multi-signal compatibility corollary: subspace conflict can be positive but not dominant; visual geometry can control routing in hard multi-domain regimes."
    if dataset == "BloodMNIST":
        return "Geometry-ceiling corollary: when geometry aggregation is already strong, accuracy gaps may be small while conflict/risk diagnostics remain the relevant improvement target."
    return "Safe selection corollary: fixed candidate pools allow routing gains without test-set oracle selection."


def summarize_feedback(dataset: str, ceiling: dict, geometry: dict, hybrid: dict) -> str:
    if dataset == "OfficeHomeFull":
        return "Use guarded Ditto-FAM as a no-regret audit: it matches Ditto-LoRA and prevents the expanded selector drop, but do not claim an extra accuracy win."
    if dataset == "PACS":
        return "Use FedPer-FAM to resolve the FedPer ceiling in mean accuracy; report the paired interval as small/mixed rather than significant dominance."
    if geometry.get("diagnosis") == "accuracy_gain_beyond_geometry_control":
        return "Keep the gain beyond Geometry-Agg as positive evidence."
    return "Report FedAvg repair and conflict/risk support; avoid claiming decisive improvement over Geometry-Agg."


def summarize_claim(dataset: str) -> str:
    if dataset == "DomainNetMini":
        return "Geometry-dominated hard case: supports multi-signal routing, not a subspace-only explanation."
    if dataset == "BloodMNIST":
        return "Medical application with strong FedAvg repair and conflict support; Geometry-Agg accuracy gain is mixed."
    if dataset == "OfficeHomeFull":
        return "Strong mechanism plus no-regret composability with Ditto; not universal SOTA."
    if dataset == "PACS":
        return "Personalization/manifold composition resolves the main PACS benchmark caveat."
    return "Safe routing improves beyond geometry-only control and strong baselines."


def find_paired(rows: list[dict], dataset: str, method: str, baseline: str) -> dict:
    for row in rows:
        if row.get("dataset") == dataset and row.get("method") == method and row.get("baseline") == baseline:
            return row
    return {}


def find_claim(rows: list[dict], dataset: str, claim_id: str) -> dict:
    for row in rows:
        if row.get("dataset") == dataset and row.get("claim_id") == claim_id:
            return row
    return {}


def has_method(rows: list[dict], method: str) -> bool:
    return any(row.get("method") == method for row in rows)


def paired_diffs(rows: list[dict], method: str, baseline: str) -> list[float]:
    table: dict[tuple[str, str], dict[str, float]] = {}
    for row in rows:
        if row.get("method") not in {method, baseline}:
            continue
        seed = row.get("seed", row.get("source_seed", ""))
        client = row.get("client_id", "")
        key = (str(seed), str(client))
        table.setdefault(key, {})[row.get("method", "")] = fnum(row.get("accuracy", row.get("test_accuracy")))
    diffs = []
    for pair in table.values():
        if method in pair and baseline in pair:
            diffs.append(pair[method] - pair[baseline])
    return diffs


def bootstrap_ci(values: list[float], reps: int = 4000) -> tuple[float, float]:
    if not values:
        return float("nan"), float("nan")
    rng = random.Random(0)
    n = len(values)
    stats = []
    for _ in range(reps):
        sample = [values[rng.randrange(n)] for _ in range(n)]
        stats.append(mean(sample))
    stats.sort()
    return stats[int(0.025 * reps)], stats[int(0.975 * reps)]


def write_report(path: Path, failure_rows: list[dict], ceiling_rows: list[dict], geometry_rows: list[dict], mechanism_rows: list[dict], hybrid_rows: list[dict]) -> None:
    lines = [
        "# Theory-Experiment Feedback Audit",
        "",
        "This pack converts the remaining reviewer risks into explicit experimental failure modes, a theory response, and a revised experiment/claim.",
        "",
        "## Main Feedback Loop",
        "",
        "| Dataset | Experimental problem | Theory response | Feedback to experiment | Paper claim |",
        "|---|---|---|---|---|",
    ]
    for row in failure_rows:
        lines.append(
            f"| {row['dataset']} | {row['experimental_problem']} | {row['theory_response']} | {row['feedback_to_experiment']} | {row['paper_claim']} |"
        )
    lines.extend(["", "## Hybrid No-Regret Paired Audit", "", "| Dataset | Hybrid | Baseline | Units | Mean diff | CI low | CI high | Diagnosis |", "|---|---|---|---:|---:|---:|---:|---|"])
    for row in hybrid_rows:
        lines.append(
            f"| {row['dataset']} | {row['hybrid_method']} | {row['baseline_method']} | {row['paired_units']} | {row['mean_diff']} | {row['ci_low']} | {row['ci_high']} | {row['diagnosis']} |"
        )
    lines.extend(["", "## Geometry Ceiling Audit", "", "| Dataset | Gain vs GeoAgg | CI low | Conflict reduction vs FedAvg | Diagnosis |", "|---|---:|---:|---:|---|"])
    for row in geometry_rows:
        lines.append(
            f"| {row['dataset']} | {row['strongselective_gain_vs_geoagg']} | {row['ci_low']} | {row['update_conflict_reduction_vs_fedavg']} | {row['diagnosis']} |"
        )
    lines.extend(["", "## Mechanism Signal Audit", "", "| Dataset | Adapter/failure r | CI low | Diagnosis |", "|---|---:|---:|---|"])
    for row in mechanism_rows:
        lines.append(f"| {row['dataset']} | {row['adapter_failure_correlation']} | {row['ci_low']} | {row['diagnosis']} |")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
