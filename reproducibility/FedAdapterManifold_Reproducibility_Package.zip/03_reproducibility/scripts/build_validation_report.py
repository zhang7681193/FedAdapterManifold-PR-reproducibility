#!/usr/bin/env python3
"""Assemble a compact validation report from individual audit outputs."""

from __future__ import annotations

from pathlib import Path


REPORTS = [
    "paper_resubmit/format_validation_report.md",
    "paper_resubmit/core_evidence_validation.md",
    "paper_resubmit/baseline_fidelity_audit.md",
    "paper_resubmit/reference_audit.md",
    "paper_resubmit/vfm_wording_audit.md",
    "paper_resubmit/no_oracle_audit.md",
    "paper_resubmit/theory_consistency_audit.md",
    "paper_resubmit/results_artifact_audit.md",
    "paper_resubmit/claim_language_audit.md",
    "paper_resubmit/small_gain_claim_audit.md",
    "results/fedadaptermanifold_protocol_audit_final_20260805/protocol_audit.md",
    "results/recent_lora_data_quality_20260805/data_quality_report.md",
    "paper_resubmit/risk_elimination_matrix.md",  # Exact-v3/v5 live matrix; historical score-gate PASS is excluded.
]


def main() -> int:
    lines = [
        "# FedAdapterManifold PR Resubmission Validation Report",
        "",
        "This file aggregates the local audits used before resubmission. It is an internal quality-control artifact, not manuscript text.",
        "",
    ]
    for item in REPORTS:
        path = Path(item)
        lines.append(f"## {path.name}")
        lines.append("")
        if path.exists():
            lines.append(path.read_text(encoding="utf-8", errors="replace"))
        else:
            lines.append(f"- Missing audit report: `{path}`")
        lines.append("")
    out = Path("paper_resubmit/validation_report.md")
    out.write_text("\n".join(lines), encoding="utf-8")
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
