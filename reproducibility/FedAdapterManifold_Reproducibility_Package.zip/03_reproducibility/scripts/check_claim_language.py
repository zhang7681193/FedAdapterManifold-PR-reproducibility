#!/usr/bin/env python3
"""Audit unsafe manuscript claim language."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


UNSAFE = [
    (r"universal\s+SOTA", "Do not claim universal SOTA."),
    (r"dominates\s+all", "Do not claim domination over all baselines."),
    (r"always\s+improves", "Do not claim always improves."),
    (r"guarantees\s+safe\s+transfer", "Safe transfer guarantees must be theorem-scoped."),
    (r"absolute\s+correctness", "Do not claim absolute correctness."),
    (r"outperforms\s+all\s+baselines", "Do not claim outperforming all baselines."),
    (r"complete\s+convergence\s+theorem", "Do not claim complete convergence theorem."),
    (r"graph\s+sharing\s+solves", "Do not imply graph sharing alone solves the problem."),
    (r"geometry\s+certifies", "Geometry proposes candidates; it does not certify admission."),
]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="*", default=[
        "paper_resubmit/fedadaptermanifold_pr_resubmit.tex",
        "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.tex",
    ])
    ap.add_argument("--out", default="paper_resubmit/claim_language_audit.md")
    args = ap.parse_args()

    hits: list[str] = []
    for file in args.files:
        text = Path(file).read_text(encoding="utf-8", errors="replace")
        for line_no, line in enumerate(text.splitlines(), 1):
            lowered = line.lower()
            negated = any(token in lowered for token in ("do not claim", "does not claim", "not a ", "not an ", "not as ", "rather than"))
            for pattern, msg in UNSAFE:
                if re.search(pattern, line, flags=re.I) and not negated:
                    hits.append(f"{file}:{line_no}: {msg}: {line.strip()}")
            if re.search(r"\bsignificant(?:ly)?\b", line, flags=re.I):
                if "not significant" in lowered:
                    continue
                if not re.search(r"CI|confidence|interval|p=|p\\s*=", line, flags=re.I):
                    hits.append(f"{file}:{line_no}: 'significant' should be tied to CI/p-value context: {line.strip()}")

    report = ["# Claim Language Audit", ""]
    report += [f"- {h}" for h in hits] if hits else ["- Passed: no unsafe claim language detected."]
    Path(args.out).write_text("\n".join(report) + "\n", encoding="utf-8")
    print(args.out)
    if hits:
        for h in hits:
            print("ERROR:", h, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
