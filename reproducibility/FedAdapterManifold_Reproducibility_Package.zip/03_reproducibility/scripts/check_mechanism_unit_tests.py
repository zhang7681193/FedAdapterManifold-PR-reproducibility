#!/usr/bin/env python3
"""Unit tests for the adapter-admissibility mechanics."""

from __future__ import annotations

import math
import sys

import numpy as np


def orth(x: np.ndarray) -> np.ndarray:
    q, _ = np.linalg.qr(x)
    return q


def grassmann_sin_distance(u: np.ndarray, v: np.ndarray) -> float:
    s = np.linalg.svd(u.T @ v, compute_uv=False)
    s = np.clip(s, 0.0, 1.0)
    return float(np.linalg.norm(np.sqrt(1.0 - s ** 2)))


def gibbs_weights(mismatch: np.ndarray, tau: float = 0.5) -> np.ndarray:
    z = -mismatch / tau
    z = z - np.max(z)
    w = np.exp(z)
    return w / w.sum()


def anchored_select(anchor_loss: float, manifold_loss: float, margin: float) -> str:
    return "manifold" if anchor_loss - manifold_loss > margin else "anchor"


def residual_select(anchor_loss: float, manifold_loss: float, eps: float, b_res: float, margin: float) -> str:
    return "manifold" if anchor_loss - manifold_loss > 2 * eps + b_res + margin else "anchor"


def main() -> int:
    rng = np.random.default_rng(0)
    u = orth(rng.normal(size=(8, 3)))
    v = orth(rng.normal(size=(8, 3)))
    q = orth(rng.normal(size=(3, 3)))

    checks = []
    checks.append(("zero identical", abs(grassmann_sin_distance(u, u)) < 1e-7))
    checks.append(("symmetry", abs(grassmann_sin_distance(u, v) - grassmann_sin_distance(v, u)) < 1e-10))
    checks.append(("rotation invariance", abs(grassmann_sin_distance(u, v) - grassmann_sin_distance(u, v @ q)) < 1e-10))

    mismatch = np.array([0.1, 0.5, 1.0])
    weights = gibbs_weights(mismatch)
    checks.append(("weights sum one", abs(float(weights.sum()) - 1.0) < 1e-12))
    checks.append(("weights decrease with mismatch", weights[0] > weights[1] > weights[2]))

    checks.append(("anchored fallback below margin", anchored_select(0.50, 0.497, 0.005) == "anchor"))
    checks.append(("anchored admit above margin", anchored_select(0.50, 0.490, 0.005) == "manifold"))
    checks.append(("residual fallback when budget blocks", residual_select(0.50, 0.480, 0.005, 0.020, 0.005) == "anchor"))
    checks.append(("residual admit when certified", residual_select(0.50, 0.450, 0.005, 0.020, 0.005) == "manifold"))

    failed = [name for name, ok in checks if not ok]
    for name, ok in checks:
        print(f"{'PASS' if ok else 'FAIL'}: {name}")
    if failed:
        print("Failed checks: " + ", ".join(failed), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
