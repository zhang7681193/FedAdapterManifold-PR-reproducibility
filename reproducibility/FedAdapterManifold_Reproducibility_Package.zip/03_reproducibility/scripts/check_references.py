#!/usr/bin/env python3
"""Reference audit for the Pattern Recognition resubmission.

The goal is not to judge scientific taste automatically.  It catches the
mechanical reference risks raised by the editor: stale/deleted citations,
missing BibTeX entries, too few Pattern Recognition / PRL sources, and large
unexplained citation clusters.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


DELETED_KEYS = {
    "zaken2022bitfit",
    "koh2021wilds",
    "zhang2025fedhello",
    "shamsian2021pfedhn",
    "tran2026fedpower",
}

PINNED_PREPRINTS = {
    "bian2026fedtreelora": "2603.13282",
}


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tex", nargs="+", default=[
        "paper_resubmit/fedadaptermanifold_pr_resubmit.tex",
        "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.tex",
    ])
    ap.add_argument("--bib", default="paper_resubmit/fedadaptermanifold_upgrade_refs.bib")
    ap.add_argument("--out", default="paper_resubmit/reference_audit.md")
    return ap.parse_args()


def main() -> int:
    args = parse_args()
    bib_text = Path(args.bib).read_text(encoding="utf-8", errors="replace")
    bib_keys = set(re.findall(r"@\w+\s*\{\s*([^,\s]+)", bib_text))

    tex_text = "\n".join(Path(p).read_text(encoding="utf-8", errors="replace") for p in args.tex)
    citation_keys = extract_citations(tex_text)

    errors: list[str] = []
    warnings: list[str] = []
    missing = sorted(citation_keys - bib_keys)
    if missing:
        errors.append("Citation keys missing from .bib: " + ", ".join(missing))

    deleted_used = sorted(citation_keys & DELETED_KEYS)
    if deleted_used:
        errors.append("Deleted/risky citation keys still used: " + ", ".join(deleted_used))

    deleted_present = sorted(bib_keys & DELETED_KEYS)
    if deleted_present:
        errors.append("Deleted/risky BibTeX entries still present: " + ", ".join(deleted_present))

    for key, eprint in PINNED_PREPRINTS.items():
        if key not in citation_keys:
            continue
        entry = re.search(
            rf"@\w+\s*\{{\s*{re.escape(key)}\s*,(.*?)(?=\n@\w+\s*\{{|\Z)",
            bib_text,
            flags=re.DOTALL | re.IGNORECASE,
        )
        if entry is None or eprint not in entry.group(1):
            errors.append(f"Pinned preprint {key} must identify arXiv:{eprint} explicitly.")

    uncited = sorted(bib_keys - citation_keys)
    if uncited:
        errors.append("Uncited BibTeX entries remain: " + ", ".join(uncited[:30]))

    pr_entries = count_pattern_recognition_entries(bib_text)
    if pr_entries < 4:
        errors.append(f"Expected at least four Pattern Recognition / Pattern Recognition Letters entries, found {pr_entries}.")

    clusters = find_large_citation_clusters(tex_text)
    if clusters:
        warnings.extend(clusters)

    bib_count = len(bib_keys)
    if not (35 <= bib_count <= 55):
        errors.append(f"BibTeX entry count should be in [35,55], found {bib_count}.")

    report = [
        "# Reference Audit",
        "",
        f"- BibTeX entries: {bib_count}",
        f"- Citation keys used: {len(citation_keys)}",
        f"- Pattern Recognition / PRL entries: {pr_entries}",
        f"- Pinned preprints checked: {len(PINNED_PREPRINTS)}",
        "",
        "## Errors",
    ]
    report.extend([f"- {e}" for e in errors] if errors else ["- None"])
    report.extend(["", "## Warnings"])
    report.extend([f"- {w}" for w in warnings] if warnings else ["- None"])
    Path(args.out).write_text("\n".join(report) + "\n", encoding="utf-8")
    print(args.out)
    if errors:
        for e in errors:
            print("ERROR:", e, file=sys.stderr)
        return 1
    return 0


def extract_citations(text: str) -> set[str]:
    keys: set[str] = set()
    for match in re.finditer(r"\\cite\w*\{([^}]+)\}", text):
        for key in match.group(1).split(","):
            key = key.strip()
            if key:
                keys.add(key)
    return keys


def count_pattern_recognition_entries(bib_text: str) -> int:
    blocks = re.split(r"\n(?=@\w+\s*\{)", bib_text)
    count = 0
    for block in blocks:
        lowered = block.lower()
        if "pattern recognition letters" in lowered or "pattern recognition" in lowered:
            count += 1
    return count


def find_large_citation_clusters(text: str) -> list[str]:
    warnings: list[str] = []
    for i, line in enumerate(text.splitlines(), 1):
        for match in re.finditer(r"\\cite\w*\{([^}]+)\}", line):
            keys = [k.strip() for k in match.group(1).split(",") if k.strip()]
            if len(keys) > 6:
                warnings.append(f"Line {i}: citation cluster has {len(keys)} keys; consider commenting individually.")
    return warnings


if __name__ == "__main__":
    raise SystemExit(main())
