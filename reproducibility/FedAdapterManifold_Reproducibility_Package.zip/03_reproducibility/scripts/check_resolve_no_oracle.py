#!/usr/bin/env python3
"""Audit FedAdapterManifold-Resolve candidate selection for no-oracle use.

The Resolve selector is allowed to use training-side or declared calibration
signals, but not held-out test metrics.  This script deliberately audits the
selection log only.  Post-selection diagnostic tables may contain accuracies
and losses because they are used for reporting after the candidate has already
been chosen.
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import pandas as pd


FORBIDDEN_COLUMN_PATTERNS = [
    r"\btest\b",
    r"test_",
    r"_test",
    r"heldout_test",
    r"oracle",
    r"eval_accuracy",
    r"evaluation_accuracy",
    r"post_selection_accuracy",
    r"posthoc",
    r"ground_truth",
]

FORBIDDEN_VALUE_PATTERNS = [
    r"test_accuracy",
    r"test_loss",
    r"oracle",
    r"posthoc",
    r"post-hoc",
    r"heldout_test",
]

ALLOWED_SELECTION_COLUMNS = {
    "dataset",
    "seed",
    "client_id",
    "best_anchor",
    "best_manifold_candidate",
    "selected_candidate",
    "calibrated_gain",
    "epsilon_cal",
    "epsilon_geo",
    "epsilon_label",
    "epsilon_rank",
    "epsilon_opt",
    "epsilon_cost",
    "B_res",
    "margin_min",
    "admission_decision",
    "signal_status",
    "w_sub",
    "w_geo",
    "w_label",
    "w_coverage",
    "candidate_pool_hash",
    "calibration_split_hash",
    "timestamp",
}


def _match_any(value: str, patterns: list[str]) -> list[str]:
    hits: list[str] = []
    for pattern in patterns:
        if re.search(pattern, value, flags=re.IGNORECASE):
            hits.append(pattern)
    return hits


def audit_selection_log(path: Path) -> dict:
    if not path.exists():
        raise FileNotFoundError(f"Selection log not found: {path}")

    df = pd.read_csv(path)
    columns = [str(c) for c in df.columns]
    forbidden_columns = {
        c: _match_any(c, FORBIDDEN_COLUMN_PATTERNS)
        for c in columns
        if _match_any(c, FORBIDDEN_COLUMN_PATTERNS)
    }

    unexpected_columns = sorted(set(columns) - ALLOWED_SELECTION_COLUMNS)

    value_hits: list[dict] = []
    object_cols = df.select_dtypes(include=["object", "string"]).columns
    for col in object_cols:
        for row_idx, value in df[col].dropna().astype(str).items():
            hits = _match_any(value, FORBIDDEN_VALUE_PATTERNS)
            if hits:
                value_hits.append(
                    {
                        "row": int(row_idx),
                        "column": str(col),
                        "value": value[:200],
                        "patterns": hits,
                    }
                )

    missing_hashes = []
    for col in ["candidate_pool_hash", "calibration_split_hash"]:
        if col not in df.columns:
            missing_hashes.append(col)
        elif df[col].isna().any() or (df[col].astype(str).str.len() == 0).any():
            missing_hashes.append(col)

    fixed_protocol_summary = []
    if {"dataset", "candidate_pool_hash", "calibration_split_hash"}.issubset(df.columns):
        grouped = (
            df.groupby("dataset", dropna=False)[
                ["candidate_pool_hash", "calibration_split_hash"]
            ]
            .nunique(dropna=False)
            .reset_index()
        )
        for _, row in grouped.iterrows():
            fixed_protocol_summary.append(
                {
                    "dataset": row["dataset"],
                    "candidate_pool_hash_count": int(row["candidate_pool_hash"]),
                    "calibration_split_hash_count": int(row["calibration_split_hash"]),
                }
            )

    passed = not forbidden_columns and not value_hits and not missing_hashes

    return {
        "selection_log": str(path),
        "n_rows": int(len(df)),
        "n_columns": int(len(df.columns)),
        "passed": bool(passed),
        "forbidden_columns": forbidden_columns,
        "unexpected_columns": unexpected_columns,
        "forbidden_value_hits": value_hits,
        "missing_or_empty_protocol_hashes": missing_hashes,
        "fixed_protocol_summary": fixed_protocol_summary,
        "note": (
            "This audit checks candidate selection only. Accuracy and test metrics "
            "may appear in post-selection diagnostic tables, but not here."
        ),
    }


def write_markdown(report: dict, path: Path) -> None:
    status = "PASS" if report["passed"] else "FAIL"
    lines = [
        "# FedAdapterManifold-Resolve No-Oracle Audit",
        "",
        f"**Status:** {status}",
        "",
        f"- Selection log: `{report['selection_log']}`",
        f"- Rows checked: {report['n_rows']}",
        f"- Columns checked: {report['n_columns']}",
        "- Rule: candidate selection may use training/calibration signals only; "
        "held-out test metrics are allowed only in post-selection diagnostics.",
        "",
        "## Forbidden Column Scan",
        "",
    ]
    if report["forbidden_columns"]:
        for col, hits in report["forbidden_columns"].items():
            lines.append(f"- `{col}` matched {hits}")
    else:
        lines.append("- No forbidden test/oracle column names were found.")

    lines.extend(["", "## Forbidden Value Scan", ""])
    if report["forbidden_value_hits"]:
        for hit in report["forbidden_value_hits"][:50]:
            lines.append(
                f"- row {hit['row']}, column `{hit['column']}` matched "
                f"{hit['patterns']}: `{hit['value']}`"
            )
        if len(report["forbidden_value_hits"]) > 50:
            lines.append(f"- ... {len(report['forbidden_value_hits']) - 50} more hits")
    else:
        lines.append("- No forbidden test/oracle tokens were found in selection values.")

    lines.extend(["", "## Protocol Hashes", ""])
    if report["missing_or_empty_protocol_hashes"]:
        lines.append(
            "- Missing or empty protocol hash columns: "
            + ", ".join(f"`{c}`" for c in report["missing_or_empty_protocol_hashes"])
        )
    else:
        lines.append("- Candidate-pool and calibration-split hashes are present for all rows.")

    lines.extend(["", "## Fixed-Protocol Summary", ""])
    for row in report["fixed_protocol_summary"]:
        lines.append(
            f"- {row['dataset']}: "
            f"{row['candidate_pool_hash_count']} candidate-pool hash value(s), "
            f"{row['calibration_split_hash_count']} calibration-split hash value(s)."
        )

    lines.extend(["", "## Interpretation", ""])
    if report["passed"]:
        lines.append(
            "The Resolve selector passes the no-oracle audit: the selection log "
            "contains calibrated gains, residual budgets, reliability weights, "
            "fixed protocol hashes, and decisions, but no held-out test metrics."
        )
    else:
        lines.append(
            "The Resolve selector did not pass the no-oracle audit.  Remove the "
            "flagged fields or values from the selection-stage log before using "
            "the results in a manuscript."
        )

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", type=Path, required=True)
    parser.add_argument(
        "--selection-log",
        type=str,
        default="fam_resolve_selection_log.csv",
        help="Selection-stage CSV relative to --input-dir.",
    )
    args = parser.parse_args()

    input_dir = args.input_dir
    report = audit_selection_log(input_dir / args.selection_log)

    (input_dir / "resolve_no_oracle_audit.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    write_markdown(report, input_dir / "resolve_no_oracle_audit.md")

    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
