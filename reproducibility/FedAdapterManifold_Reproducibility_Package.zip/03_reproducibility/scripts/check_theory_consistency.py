#!/usr/bin/env python3
"""Check that theory claims are present and bounded to the audited setting."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


REQUIRED_MAIN_TERMS = [
    "Residual-certified positive admission",
    "finite-round nonconvex stationarity bound",
    "not imply convergence to a global optimum",
    "fixed pre-test pool",
    "Gibbs solution",
    "one-center scatter",
    "$K$-center",
    "immutable Local-LoRA",
    "restricted quadratic growth",
    "anchor suboptimality",
    "for each receiver",
    "Simultaneous control over $N$ receivers",
    "it is not presented as that formal confidence radius",
    "independent receiver certificate",
]

REQUIRED_MAIN_LABELS = [
    r"\\label\{thm:subspace-harm\}",
    r"\\label\{thm:multimanifold\}",
    r"\\label\{thm:routed-convergence\}",
    r"\\label\{thm:gibbs\}",
    r"\\label\{thm:no-regret\}",
    r"\\label\{prop:positive-admission\}",
]

REQUIRED_SUPP_LABELS = [
    r"\\label\{thm:supp-label-noise\}",
    r"\\label\{thm:supp-stationarity\}",
    r"\\label\{lem:supp-routing-bias\}",
    r"\\label\{cor:supp-pl\}",
]

REQUIRED_SUPP_TERMS = [
    "G. Receiver-axis projection and dual-anchor admission",
    "H. Joint anchored action paths",
    "J. Hierarchical expert generation versus receiver admission",
    "Symmetric label-noise stability of bounded admission",
    "nonzero singular values are uniformly bounded below",
    "receiver-wise strong familywise control",
    "Bonferroni levels $\\alpha/N$",
    "Subspace inadmissibility lower bound",
    "Implementation boundary",
    "empirical dispersion from one projector is identically zero",
    "does not instantiate $q_\\delta$, $u_i$",
]

REQUIRED_NOTATION = [
    r"\\mathcal\{P\}_i",
    r"\\mathcal\{M\}_i",
    r"\\Gamma_K",
    r"\\Gamma_1",
    r"\\varepsilon_\{\\rm cal\}",
    r"\\varepsilon_\{\\rm geo\}",
    r"\\varepsilon_\{\\rm rank\}",
    r"\\varepsilon_\{\\rm opt\}",
]

FORBIDDEN = [
    r"complete\s+global\s+convergence",
    r"global\s+convergence\s+theorem\s+for\s+arbitrary",
    r"guaranteed\s+improvement(?![^.]{0,120}(?:fixed|calibration|theorem|event))",
    r"absolute\s+correctness",
]


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--main", default="paper_resubmit/fedadaptermanifold_pr_resubmit.tex")
    ap.add_argument("--supp", default="paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.tex")
    ap.add_argument("--out", default="paper_resubmit/theory_consistency_audit.md")
    return ap.parse_args()


def main() -> int:
    args = parse_args()
    main_text = Path(args.main).read_text(encoding="utf-8", errors="replace")
    supp_text = Path(args.supp).read_text(encoding="utf-8", errors="replace")
    combined = main_text + "\n" + supp_text
    errors: list[str] = []
    warnings: list[str] = []

    for term in REQUIRED_MAIN_TERMS:
        if term not in main_text:
            errors.append(f"Main theory section is missing required term: {term}")

    for pattern in REQUIRED_MAIN_LABELS:
        if not re.search(pattern, main_text):
            errors.append(f"Main theory section is missing required theorem/proposition label: {pattern}")

    for pattern in REQUIRED_SUPP_LABELS:
        if not re.search(pattern, supp_text):
            errors.append(f"Supplement is missing required theorem label: {pattern}")

    for term in REQUIRED_SUPP_TERMS:
        if term not in supp_text:
            errors.append(f"Supplement is missing required theory detail: {term}")

    for pattern in REQUIRED_NOTATION:
        if not re.search(pattern, combined):
            warnings.append(f"Notation not found or renamed: {pattern}")

    lines = combined.splitlines()
    for pattern in FORBIDDEN:
        for line_no, line in enumerate(lines, 1):
            if re.search(pattern, line, flags=re.I):
                lowered = line.lower()
                if any(token in lowered for token in ("not a ", "not an ", "does not claim", "do not claim", "rather than")):
                    continue
                errors.append(f"Forbidden theory overclaim near line {line_no}: {line.strip()}")

    if "supplement-only" in supp_text.lower() and "supplement-only" not in main_text.lower():
        warnings.append("Supplement-only theory label appears only in supplement; verify this is intentional.")

    report = [
        "# Theory Consistency Audit",
        "",
        "## Errors",
    ]
    report.extend([f"- {e}" for e in errors] if errors else ["- None"])
    report.extend(["", "## Warnings"])
    report.extend([f"- {w}" for w in warnings] if warnings else ["- None"])
    Path(args.out).write_text("\n".join(report) + "\n", encoding="utf-8")
    print(args.out)
    if errors:
        for e in errors:
            print("ERROR:", e, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
