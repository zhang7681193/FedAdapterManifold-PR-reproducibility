#!/usr/bin/env python3
"""Fail if frozen-feature CLIP/DINOv2 audits are described as end-to-end."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


BAD_PATTERNS = [
    (re.compile(r"end-to-end[^.\n]{0,120}DINOv2", re.I), "DINOv2 frozen-feature audits must not be called end-to-end."),
    (re.compile(r"end-to-end[^.\n]{0,120}frozen-feature", re.I), "Frozen-feature audits must not be called end-to-end."),
    (re.compile(r"frozen-feature[^.\n]{0,120}end-to-end", re.I), "Frozen-feature audits must not be called end-to-end."),
    (re.compile(r"full-data[^.\n]{0,80}VFM[^.\n]{0,80}end-to-end", re.I), "Full-data VFM-backbone audits are not necessarily end-to-end."),
]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="*", default=[
        "paper_resubmit/fedadaptermanifold_pr_resubmit.tex",
        "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.tex",
    ])
    ap.add_argument("--out", default="paper_resubmit/vfm_wording_audit.md")
    args = ap.parse_args()

    errors: list[str] = []
    for file in args.files:
        text = Path(file).read_text(encoding="utf-8", errors="replace")
        for line_no, line in enumerate(text.splitlines(), start=1):
            for rx, msg in BAD_PATTERNS:
                if rx.search(line):
                    errors.append(f"{file}:{line_no}: {msg}: {line.strip()}")

    report = ["# VFM Wording Audit", ""]
    report += [f"- {e}" for e in errors] if errors else ["- Passed: no frozen-feature audit is described as end-to-end."]
    Path(args.out).write_text("\n".join(report) + "\n", encoding="utf-8")
    print(args.out)
    if errors:
        for e in errors:
            print("ERROR:", e, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
