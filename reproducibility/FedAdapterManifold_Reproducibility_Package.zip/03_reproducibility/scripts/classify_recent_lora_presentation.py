from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


PRIMARY_METHOD = "FedAdapterManifold-Admit"
COMPARATORS = (
    "FedRot-LoRA",
    "FedEx-LoRA",
    "FedSA-LoRA",
    "Ditto-LoRA",
    "FedAvg-Lift",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Apply the pre-specified main/supplement presentation rule."
    )
    parser.add_argument("--result-root", required=True)
    parser.add_argument("--dataset-key", required=True)
    parser.add_argument("--quality-csv", required=True)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def main() -> int:
    args = parse_args()
    root = Path(args.result_root)
    stats = root / "fairness_statistics"
    methods = read_csv(stats / "method_summary.csv")
    comparisons = read_csv(stats / "paired_method_comparisons.csv")
    quality = read_csv(Path(args.quality_csv))

    dataset_methods = {
        row["method"]: row
        for row in methods
        if row["dataset"] == args.dataset_key
    }
    missing = [method for method in (PRIMARY_METHOD, *COMPARATORS) if method not in dataset_methods]
    if missing:
        raise ValueError(f"Missing frozen-protocol methods: {missing}")

    comparator = max(
        COMPARATORS,
        key=lambda method: float(dataset_methods[method]["mean_accuracy"]),
    )
    paired = next(
        row
        for row in comparisons
        if row["dataset"] == args.dataset_key
        and row["method"] == PRIMARY_METHOD
        and row["baseline"] == comparator
    )
    quality_pass = not any(row.get("status") == "fail" for row in quality)
    conditions = {
        "five_complete_seeds": int(paired["seed_count"]) == 5,
        "data_quality_pass": quality_pass,
        "positive_mean_accuracy_gain": float(paired["mean_accuracy_gain"]) > 0.0,
        "nonnegative_accuracy_ci_low": float(paired["accuracy_gain_ci95_low"]) >= 0.0,
        "nonnegative_worst_client_gain": float(paired["mean_worst_client_accuracy_gain"]) >= 0.0,
        "nonnegative_mean_loss_reduction": float(paired["mean_loss_reduction"]) >= 0.0,
        "intrinsic_method_not_external_anchor_pool": True,
    }
    eligible = all(conditions.values())
    decision = {
        "dataset": args.dataset_key,
        "primary_method": PRIMARY_METHOD,
        "strongest_frozen_comparator": comparator,
        "primary_mean_accuracy": float(dataset_methods[PRIMARY_METHOD]["mean_accuracy"]),
        "comparator_mean_accuracy": float(dataset_methods[comparator]["mean_accuracy"]),
        "paired_accuracy_gain": float(paired["mean_accuracy_gain"]),
        "paired_accuracy_ci95_low": float(paired["accuracy_gain_ci95_low"]),
        "paired_accuracy_ci95_high": float(paired["accuracy_gain_ci95_high"]),
        "paired_worst_client_gain": float(paired["mean_worst_client_accuracy_gain"]),
        "paired_loss_reduction": float(paired["mean_loss_reduction"]),
        "conditions": conditions,
        "main_manuscript_eligible": eligible,
        "presentation_destination": "main" if eligible else "supplement",
    }
    output_json = root / "presentation_decision.json"
    output_json.write_text(json.dumps(decision, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# Presentation decision",
        "",
        f"- Primary method: `{PRIMARY_METHOD}`",
        f"- Strongest frozen comparator: `{comparator}`",
        f"- Accuracy gain: {decision['paired_accuracy_gain']:+.6f} "
        f"[{decision['paired_accuracy_ci95_low']:+.6f}, "
        f"{decision['paired_accuracy_ci95_high']:+.6f}]",
        f"- Worst-client gain: {decision['paired_worst_client_gain']:+.6f}",
        f"- Loss reduction: {decision['paired_loss_reduction']:+.6f}",
        f"- Destination: **{decision['presentation_destination']}**",
        "",
        "## Frozen conditions",
        "",
        *(f"- {'PASS' if passed else 'FAIL'}: {name}" for name, passed in conditions.items()),
        "",
        "The destination is determined mechanically from the pre-specified rule; no test-time",
        "method or candidate-pool switching is performed.",
    ]
    (root / "presentation_decision.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(root / "presentation_decision.md")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
