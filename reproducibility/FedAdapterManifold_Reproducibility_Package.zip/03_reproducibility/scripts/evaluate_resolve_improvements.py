from __future__ import annotations

import argparse
import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


FAM_MARKERS = ("FedAdapterManifold", "FAM")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate FedAdapterManifold-Resolve paired improvements.")
    parser.add_argument("--input-dir", default="results/fam_resolve_stage1_20260629")
    parser.add_argument("--output", default=None)
    parser.add_argument("--bootstrap", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=0)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.input_dir)
    out = Path(args.output) if args.output else root / "resolve_improvement_summary.csv"
    decomp = pd.read_csv(root / "mechanism_decomposition.csv")
    residuals = pd.read_csv(root / "residual_budget_summary.csv")
    rows: list[dict[str, Any]] = []
    rng = np.random.default_rng(args.seed)

    comparisons = [
        ("PACS", "FedAdapterManifold-Resolve", "FedPer-LoRA", "FedPer-Resolve-FAM vs FedPer-LoRA"),
        ("PACS", "FedAdapterManifold-Resolve", "FedAvg-LoRA", "Resolve-FAM shared branch vs FedAvg-LoRA"),
        ("PACS", "FedAdapterManifold-Resolve", "FedGeo-Agg", "Resolve-FAM shared branch vs Geo-only"),
        ("OfficeHome", "FedAdapterManifold-Resolve", "Ditto-LoRA", "Ditto residual FAM vs Ditto-LoRA"),
        ("DomainNetMini", "FedAdapterManifold-Resolve", "FedGeo-Agg", "Resolve vs Geo-only"),
        ("DomainNetMini", "FedAdapterManifold-Resolve", "FedAvg-LoRA", "Resolve vs FedAvg-LoRA"),
        ("BloodMNIST", "FedAdapterManifold-Resolve", "FedGeo-Agg", "Resolve vs Geo-only micro"),
        ("BloodMNIST", "FedAdapterManifold-Resolve", "FedAvg-LoRA", "Resolve vs FedAvg-LoRA"),
        ("Office-Caltech", "FedAdapterManifold-Resolve", "FedGeo-Agg", "Resolve vs Geo-only"),
        ("Office-Caltech", "FedAdapterManifold-Resolve", "__best_non_fam__", "Resolve vs best non-FAM"),
        ("OfficeHome-DINOv2", "FedAdapterManifold-Resolve", "Ditto-LoRA", "Resolve vs Ditto-LoRA"),
        ("OfficeHome-DINOv2", "FedAdapterManifold-Resolve", "FedGeo-Agg", "Resolve vs Geo-only"),
        ("OfficeHome-CLIP", "FedAdapterManifold-Resolve", "Ditto-LoRA", "Resolve vs Ditto-LoRA"),
        ("OfficeHome-CLIP", "FedAdapterManifold-Resolve", "FedGeo-Agg", "Resolve vs Geo-only"),
        ("PACS-DINOv2", "FedAdapterManifold-Resolve", "FedPer-LoRA", "Resolve vs FedPer-LoRA"),
        ("PACS-DINOv2", "FedAdapterManifold-Resolve", "FedGeo-Agg", "Resolve vs Geo-only"),
    ]

    for dataset, method, baseline, label in comparisons:
        g = decomp[decomp["dataset"] == dataset]
        if g.empty:
            continue
        pairs = paired_gain(g, method, baseline)
        if pairs.empty:
            continue
        gains = pairs["gain"].to_numpy(dtype=float)
        ci_low, ci_high = bootstrap_ci(gains, args.bootstrap, rng)
        seed_ci_low, seed_ci_high = seed_cluster_ci(pairs, args.bootstrap, rng)
        p_value = sign_flip_p(gains, args.bootstrap, rng)
        r = residuals[residuals["dataset"] == dataset]
        status_counts = r.get("mechanism_status", pd.Series(dtype=str)).value_counts().to_dict()
        fallback_count = int((r.get("admission_decision", pd.Series(dtype=str)) == "fallback").sum())
        admit_count = int((r.get("admission_decision", pd.Series(dtype=str)) == "admit").sum())
        residual_blocker = dominant_residual(r)
        label_status = acceptance_label(float(np.nanmean(gains)), ci_low, status_counts, residual_blocker)
        rows.append(
            {
                "dataset": dataset,
                "comparison": label,
                "method": method,
                "baseline": baseline,
                "n_pairs": int(len(pairs)),
                "mean_gain": float(np.nanmean(gains)),
                "client_seed_ci_low": ci_low,
                "client_seed_ci_high": ci_high,
                "seed_cluster_ci_low": seed_ci_low,
                "seed_cluster_ci_high": seed_ci_high,
                "sign_flip_p": p_value,
                "per_client_positive_count": int((gains > 0).sum()),
                "per_client_nonnegative_count": int((gains >= 0).sum()),
                "per_seed_positive_count": int((pairs.groupby("seed")["gain"].mean() > 0).sum()),
                "per_seed_count": int(pairs["seed"].nunique()),
                "fallback_count": fallback_count,
                "admit_count": admit_count,
                "residual_blocker": residual_blocker,
                "acceptance_label": label_status,
                "worst_client_gain": float(np.nanmin(gains)),
                "macro_gain": float(np.nanmean(gains)),
                "micro_gain": float(np.nanmean(gains)),
            }
        )

    frame = pd.DataFrame(rows)
    frame.to_csv(out, index=False)
    write_report(root / "resolve_improvement_summary.md", frame)
    return 0


def paired_gain(g: pd.DataFrame, method: str, baseline: str) -> pd.DataFrame:
    keep = g[["seed", "client_id", "candidate_name", "test_acc_after_selection", "candidate_family"]].copy()
    keep["candidate_name"] = keep["candidate_name"].astype(str)
    if baseline == "__best_non_fam__":
        nonfam = keep[~keep["candidate_name"].str.contains("|".join(FAM_MARKERS), regex=True, na=False)]
        if nonfam.empty:
            return pd.DataFrame()
        best_name = (
            nonfam.groupby("candidate_name")["test_acc_after_selection"]
            .mean()
            .sort_values(ascending=False)
            .index[0]
        )
        base = nonfam[nonfam["candidate_name"] == best_name][
            ["seed", "client_id", "test_acc_after_selection"]
        ].rename(columns={"test_acc_after_selection": "baseline_acc"})
    else:
        base = keep[keep["candidate_name"] == baseline][["seed", "client_id", "test_acc_after_selection"]].rename(
            columns={"test_acc_after_selection": "baseline_acc"}
        )
    meth = keep[keep["candidate_name"] == method][["seed", "client_id", "test_acc_after_selection"]].rename(
        columns={"test_acc_after_selection": "method_acc"}
    )
    pairs = meth.merge(base, on=["seed", "client_id"], how="inner")
    pairs["gain"] = pd.to_numeric(pairs["method_acc"], errors="coerce") - pd.to_numeric(
        pairs["baseline_acc"], errors="coerce"
    )
    return pairs.dropna(subset=["gain"])


def bootstrap_ci(values: np.ndarray, n_boot: int, rng: np.random.Generator) -> tuple[float, float]:
    values = values[np.isfinite(values)]
    if values.size == 0:
        return math.nan, math.nan
    means = []
    for _ in range(n_boot):
        idx = rng.integers(0, values.size, values.size)
        means.append(float(np.mean(values[idx])))
    return float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def seed_cluster_ci(pairs: pd.DataFrame, n_boot: int, rng: np.random.Generator) -> tuple[float, float]:
    if pairs.empty:
        return math.nan, math.nan
    seed_means = pairs.groupby("seed")["gain"].mean().to_numpy(dtype=float)
    return bootstrap_ci(seed_means, n_boot, rng)


def sign_flip_p(values: np.ndarray, n_draws: int, rng: np.random.Generator) -> float:
    values = values[np.isfinite(values)]
    if values.size == 0:
        return math.nan
    obs = abs(float(np.mean(values)))
    count = 0
    for _ in range(n_draws):
        signs = rng.choice([-1.0, 1.0], size=values.size)
        if abs(float(np.mean(values * signs))) >= obs:
            count += 1
    return (count + 1.0) / (n_draws + 1.0)


def dominant_residual(r: pd.DataFrame) -> str:
    if r.empty:
        return "unidentified"
    cols = ["epsilon_cal", "epsilon_geo", "epsilon_label", "epsilon_rank", "epsilon_opt", "epsilon_cost"]
    vals = {c: pd.to_numeric(r[c], errors="coerce").mean() for c in cols if c in r}
    if not vals:
        return "unidentified"
    key = max(vals, key=lambda k: -1 if pd.isna(vals[k]) else vals[k])
    return {
        "epsilon_cal": "calibration variance",
        "epsilon_geo": "geometry proxy error",
        "epsilon_label": "label-support mismatch",
        "epsilon_rank": "rank projection residual",
        "epsilon_opt": "optimizer residual",
        "epsilon_cost": "cost penalty",
    }.get(key, key)


def acceptance_label(mean_gain: float, ci_low: float, status_counts: dict[str, int], blocker: str) -> str:
    if ci_low > 0 and status_counts.get("certified_positive", 0) > 0:
        return "certified_positive"
    if mean_gain >= 0 and status_counts.get("no_regret_match", 0) > 0:
        return "no_regret_match"
    if blocker != "unidentified":
        return "residual_blocked"
    return "failed_unexplained"


def write_report(path: Path, frame: pd.DataFrame) -> None:
    lines = ["# FedAdapterManifold-Resolve Improvement Summary", ""]
    if frame.empty:
        lines.append("No comparisons were available.")
    else:
        for r in frame.to_dict("records"):
            lines.append(
                f"- **{r['dataset']} / {r['comparison']}**: mean gain {r['mean_gain']:.4f}, "
                f"client-seed CI [{r['client_seed_ci_low']:.4f}, {r['client_seed_ci_high']:.4f}], "
                f"seed-cluster CI [{r['seed_cluster_ci_low']:.4f}, {r['seed_cluster_ci_high']:.4f}], "
                f"label `{r['acceptance_label']}`, blocker `{r['residual_blocker']}`."
            )
    path.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
