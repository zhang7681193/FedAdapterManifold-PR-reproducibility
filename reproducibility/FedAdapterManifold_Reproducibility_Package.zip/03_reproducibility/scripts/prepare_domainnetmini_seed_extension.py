from __future__ import annotations

import argparse
from copy import deepcopy
from pathlib import Path

from fedadaptermanifold.config import load_yaml, save_yaml_copy


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Prepare the pre-registered DomainNetMini-60 seed extension."
    )
    parser.add_argument(
        "--source-config",
        default="results/recent_lora_fairness_20260804/configs/domainnetmini_clip_60class/seed_0.yaml",
    )
    parser.add_argument(
        "--output-root",
        default="results/recent_lora_fairness_20260805/configs/domainnetmini_clip_60class_extension",
    )
    parser.add_argument(
        "--geometry-template",
        default=(
            r"${GEOMETRY_PROVIDER_ROOT}"
            r"\results\domainnetmini_pretrained_active_sparse50_compare_seed{seed}"
            r"\geometry_outputs"
        ),
    )
    parser.add_argument("--seeds", default="5,6,7,8,9")
    parser.add_argument(
        "--result-root",
        default="results/recent_lora_fairness_20260805/domainnetmini_clip_60class_extension",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    source = load_yaml(args.source_config)
    seeds = [int(token.strip()) for token in str(args.seeds).split(",") if token.strip()]
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    for seed in seeds:
        geometry_dir = Path(str(args.geometry_template).format(seed=seed))
        round_id = int(source.get("geometry_round", 4))
        required = [
            geometry_dir / f"d_geo_round_{round_id}.npy",
            geometry_dir / f"geometry_graph_round_{round_id}.npy",
            geometry_dir / f"prototypes_round_{round_id}.pkl",
            geometry_dir / f"client_signatures_round_{round_id}.pkl",
        ]
        missing = [path for path in required if not path.exists()]
        if missing:
            raise FileNotFoundError(
                f"Seed {seed} geometry is incomplete: missing {missing}. "
                "Finish the pre-registered geometry sweep before preparing adapter configs."
            )
        geometry_config = load_yaml(geometry_dir.parent / "config.yaml")
        if int(geometry_config.get("run", {}).get("seed", -1)) != seed:
            raise ValueError(f"Geometry seed mismatch for seed {seed}: {geometry_dir}")
        if list(geometry_config.get("methods", [])) != ["fedavg"]:
            raise ValueError(f"Geometry source must contain only fedavg: {geometry_dir}")
        config = deepcopy(source)
        config["seed"] = seed
        config["num_classes"] = 60
        config["geometry_outputs_dir"] = str(geometry_dir)
        config["output_dir"] = str(Path(args.result_root) / f"seed_{seed}")
        config["heterogeneity_setting"] = (
            "domainnetmini-60-domain-split-clip-text-head-"
            "recent-lora-fair-fixed-rank-seed-extension"
        )
        save_yaml_copy(output_root / f"seed_{seed}.yaml", config)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
