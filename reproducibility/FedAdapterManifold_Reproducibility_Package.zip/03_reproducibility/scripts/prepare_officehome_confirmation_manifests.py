from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.run_clip_vit_lora_federated_main import _build_clients, _select_classes


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Freeze OfficeHome sample manifests before FedGeo confirmation geometry is generated."
    )
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--domains", default="Art,Clipart,Product,Real_World")
    parser.add_argument("--num-classes", type=int, default=65)
    parser.add_argument("--train-per-class", type=int, default=8)
    parser.add_argument("--test-per-class", type=int, default=8)
    parser.add_argument("--calibration-fraction", type=float, default=0.25)
    parser.add_argument("--seeds", default="10,11,12,13,14")
    parser.add_argument("--class-label-map", default="")
    return parser


def _sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _manifest_rows(clients: list[dict], data_root: Path) -> list[dict]:
    rows: list[dict] = []
    for client in clients:
        for split in ("train", "calibration", "test"):
            for sample in client[split]:
                sample_path = Path(sample["path"])
                relative = sample_path.resolve().relative_to(data_root.resolve()).as_posix()
                rows.append(
                    {
                        "client_id": int(client["client_id"]),
                        "domain": str(client["domain"]),
                        "split": split,
                        "path": relative,
                        "label": str(sample["label"]),
                    }
                )
    return rows


def _write_json(path: Path, payload) -> str:
    encoded = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
    path.write_bytes(encoded)
    return _sha256(encoded)


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    data_root = Path(args.data_root).resolve()
    output_root = Path(args.output_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    domains = [item.strip() for item in args.domains.split(",") if item.strip()]
    seeds = [int(item.strip()) for item in args.seeds.split(",") if item.strip()]
    class_names = _select_classes(data_root, domains, args.num_classes)
    if len(class_names) != args.num_classes:
        raise ValueError(
            f"Expected {args.num_classes} shared classes, found {len(class_names)} under {data_root}."
        )

    label_map_sha256 = ""
    if args.class_label_map:
        label_map_sha256 = _sha256(Path(args.class_label_map).read_bytes())

    summary: list[dict] = []
    for seed in seeds:
        clients = _build_clients(
            data_root=data_root,
            domains=domains,
            class_names=class_names,
            train_per_class=args.train_per_class,
            test_per_class=args.test_per_class,
            calibration_fraction=args.calibration_fraction,
            seed=seed,
        )
        rows = _manifest_rows(clients, data_root)
        training_rows = [row for row in rows if row["split"] == "train"]
        seed_dir = output_root / f"seed_{seed}"
        seed_dir.mkdir(parents=True, exist_ok=True)
        split_hash = _write_json(seed_dir / "split_manifest.json", rows)
        training_hash = _write_json(seed_dir / "fedgeo_training_manifest.json", training_rows)
        metadata = {
            "dataset": "OfficeHome-65",
            "seed": seed,
            "domains": domains,
            "client_ids": [int(client["client_id"]) for client in clients],
            "class_names": class_names,
            "class_label_map_sha256": label_map_sha256,
            "train_per_class_before_calibration": args.train_per_class,
            "test_per_class": args.test_per_class,
            "calibration_fraction": args.calibration_fraction,
            "split_manifest_sha256": split_hash,
            "fedgeo_training_manifest_sha256": training_hash,
            "split_rows": len(rows),
            "fedgeo_training_rows": len(training_rows),
            "calibration_rows": sum(row["split"] == "calibration" for row in rows),
            "test_rows": sum(row["split"] == "test" for row in rows),
        }
        _write_json(seed_dir / "manifest_metadata.json", metadata)
        summary.append(metadata)

    _write_json(output_root / "manifest_summary.json", summary)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
