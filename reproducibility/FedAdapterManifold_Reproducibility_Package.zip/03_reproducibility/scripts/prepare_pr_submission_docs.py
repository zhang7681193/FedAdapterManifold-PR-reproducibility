from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt


ROOT = Path(__file__).resolve().parents[1]
UPLOAD = (
    ROOT
    / "submission"
    / "FedAdapterManifold_PR_D_26_08222_resubmission_ready_20260811"
    / "upload_items"
)


def set_run_font(run, size_pt=None, bold=None):
    run.font.name = "Times New Roman"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    if size_pt is not None:
        run.font.size = Pt(size_pt)
    if bold is not None:
        run.bold = bold


def set_doc_defaults(doc):
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    normal.font.size = Pt(10)


def delete_paragraph(paragraph):
    element = paragraph._element
    element.getparent().remove(element)
    paragraph._p = paragraph._element = None


def clean_highlights():
    path = UPLOAD / "FedAdapterManifold_Highlights.docx"
    doc = Document(path)
    for paragraph in list(doc.paragraphs):
        if paragraph.text.strip().lower().startswith("note: each highlight"):
            delete_paragraph(paragraph)
    set_doc_defaults(doc)
    for index, paragraph in enumerate(doc.paragraphs):
        if index == 0:
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in paragraph.runs:
                set_run_font(run, 14, True)
        elif index == 1:
            paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in paragraph.runs:
                set_run_font(run, 10, False)
        else:
            for run in paragraph.runs:
                set_run_font(run, 10)
    doc.save(path)


def normalize_title_page():
    path = UPLOAD / "FedAdapterManifold_Title_Page_with_Author_Details.docx"
    doc = Document(path)
    set_doc_defaults(doc)
    for paragraph in doc.paragraphs:
        if "Acknowledgements/Funding:" in paragraph.text:
            paragraph.text = (
                "Acknowledgements/Funding: This work was supported by a China "
                "Scholarship Council (CSC) scholarship to Leyuan Zhang. The funder "
                "had no role in the study or the decision to submit the article."
            )
        for run in paragraph.runs:
            set_run_font(run)
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    for run in paragraph.runs:
                        set_run_font(run)
    doc.save(path)


def add_real_bullet(paragraph):
    p_pr = paragraph._p.get_or_add_pPr()
    num_pr = OxmlElement("w:numPr")
    ilvl = OxmlElement("w:ilvl")
    ilvl.set(qn("w:val"), "0")
    num_id = OxmlElement("w:numId")
    num_id.set(qn("w:val"), "1")
    num_pr.extend([ilvl, num_id])
    p_pr.append(num_pr)


def create_figure_captions():
    captions = [
        (
            "Figure 1. Receiver-specific adapter admissibility. "
            "Heterogeneous visual clients can learn incompatible LoRA action "
            "subspaces, so FedAvg-LoRA may increase accuracy loss, drift, and "
            "update conflict. FedAdapterManifold diagnoses this mismatch before "
            "compatibility-aware routing and anchored selection from a fixed "
            "pre-test pool. Visual geometry proposes neighborhoods; adapter "
            "subspaces and receiver calibration decide whether sharing is safe."
        ),
        (
            "Figure 2. Adapter-subspace diagnostics on OfficeHome. The seed-0 "
            "run is pre-specified rather than selected by correlation. (A) Client "
            "LoRA adapters occupy non-identical subspaces. (B) Incompatibility "
            "predicts receiver-normalized FedAvg-LoRA failure. (C) Prototype and "
            "subspace distances are related but non-redundant, motivating their "
            "joint use. Confirmatory claims use pooled, clustered multi-seed analyses."
        ),
    ]
    doc = Document()
    set_doc_defaults(doc)
    title = doc.add_paragraph("Figure Captions")
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in title.runs:
        set_run_font(run, 14, True)
    for caption in captions:
        paragraph = doc.add_paragraph()
        paragraph.paragraph_format.space_before = Pt(8)
        paragraph.paragraph_format.space_after = Pt(4)
        paragraph.paragraph_format.line_spacing = 1.15
        run = paragraph.add_run(caption)
        set_run_font(run, 8)
    doc.save(UPLOAD / "FedAdapterManifold_Figure_Captions.docx")


if __name__ == "__main__":
    clean_highlights()
    normalize_title_page()
    create_figure_captions()
