from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
WAIT_ROOTS = (
    (
        PROJECT_ROOT / "results" / "fam_final_risk_closure_exact_v3_5seed_20260813",
        15,
    ),
    (
        PROJECT_ROOT / "results" / "fam_generator_admission_power_v4_crossdataset_5seed_20260813",
        10,
    ),
)


def complete_count(root: Path) -> int:
    return len(list(root.glob("*/seed_*/metrics.csv")))


def main() -> int:
    while True:
        counts = [(str(root), complete_count(root), required) for root, required in WAIT_ROOTS]
        if all(count >= required for _, count, required in counts):
            break
        print(f"WAIT {counts}", flush=True)
        time.sleep(120)
    command = [sys.executable, str(PROJECT_ROOT / "scripts" / "run_fedpissa_equation_port_confirmation.py")]
    completed = subprocess.run(command, cwd=PROJECT_ROOT, check=False)
    if completed.returncode != 0:
        return completed.returncode
    analysis = [sys.executable, str(PROJECT_ROOT / "scripts" / "analyze_fedpissa_confirmation.py")]
    return subprocess.run(analysis, cwd=PROJECT_ROOT, check=False).returncode


if __name__ == "__main__":
    raise SystemExit(main())
