from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path


WORKSPACE = Path(__file__).resolve().parents[1]
V3 = WORKSPACE / "results" / "fam_final_risk_closure_exact_v3_5seed_20260813"
V4 = WORKSPACE / "results" / "fam_generator_admission_power_v4_crossdataset_5seed_20260813"
OUTPUT = WORKSPACE / "results" / "fam_topology_calibrated_admission_v5_crossdataset_5seed_20260813"
STAGING = WORKSPACE / "staging_topology_calibrated_v5_20260813"


def metric_count(root: Path) -> int:
    return sum(1 for _ in root.glob("**/metrics.csv"))


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    queue_log = OUTPUT / "queue.log"
    with queue_log.open("a", encoding="utf-8") as log:
        while metric_count(V3) < 15 or metric_count(V4) < 10:
            log.write(f"WAIT v3={metric_count(V3)}/15 v4={metric_count(V4)}/10\n")
            log.flush()
            time.sleep(60)
        command = [
            sys.executable,
            str(STAGING / "scripts" / "run_topology_calibrated_confirmation.py"),
            "--workspace",
            str(WORKSPACE),
            "--source-root",
            str(V3),
            "--output-root",
            str(OUTPUT),
        ]
        log.write("START " + " ".join(command) + "\n")
        log.flush()
        return subprocess.run(command, cwd=STAGING, stdout=log, stderr=subprocess.STDOUT).returncode


if __name__ == "__main__":
    raise SystemExit(main())
