from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path


METHOD = "FedAdapterManifold-DualTransport"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Propagate audited gate selections into per-client metrics.")
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--audit-output", default="dual_transport_selection_metadata_repairs.csv")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.input_dir)
    audit_rows = []
    for metrics_path in sorted(root.glob("seed_*_per_client_metrics.csv")):
        seed = int(metrics_path.name.split("_", 2)[1])
        gates_path = root / f"seed_{seed}_admission_gates.csv"
        audit_rows.append(_repair(metrics_path, gates_path, seed))
    audit_rows.append(_repair(root / "per_client_metrics.csv", root / "admission_gates.csv", None))
    output = root / args.audit_output
    _write_csv(output, audit_rows)
    print(output)
    return 0


def _repair(metrics_path: Path, gates_path: Path, seed: int | None) -> dict:
    metrics, metric_fields = _read_csv(metrics_path)
    gates, _ = _read_csv(gates_path)
    selected = {}
    for row in gates:
        if row.get("method") != METHOD or str(row.get("selected", "")).lower() not in {"true", "1"}:
            continue
        row_seed = int(row["seed"])
        selected[(row_seed, row["client_id"])] = row["selected_adapter"]
    before = _content_fingerprint(metrics, excluded={"selected_candidate"})
    if "selected_candidate" not in metric_fields:
        metric_fields.append("selected_candidate")
    repaired = 0
    for row in metrics:
        if row.get("method") != METHOD:
            continue
        row_seed = int(row["seed"])
        if seed is not None and row_seed != seed:
            raise ValueError(f"Unexpected seed {row_seed} in {metrics_path}")
        key = (row_seed, row["client_id"])
        if key not in selected:
            raise ValueError(f"Missing selected gate row for {key} in {gates_path}")
        row["selected_candidate"] = selected[key]
        repaired += 1
    after = _content_fingerprint(metrics, excluded={"selected_candidate"})
    if before != after:
        raise AssertionError(f"Non-selection content changed in {metrics_path}")
    before_hash = hashlib.sha256(metrics_path.read_bytes()).hexdigest()
    _write_csv(metrics_path, metrics, fieldnames=metric_fields)
    after_hash = hashlib.sha256(metrics_path.read_bytes()).hexdigest()
    return {
        "path": metrics_path.as_posix(),
        "rows_repaired": repaired,
        "sha256_before": before_hash,
        "sha256_after": after_hash,
        "non_selection_values_changed": False,
        "content_fingerprint": before,
    }


def _content_fingerprint(rows: list[dict], excluded: set[str]) -> str:
    normalized = [{key: value for key, value in row.items() if key not in excluded} for row in rows]
    payload = json.dumps(normalized, sort_keys=True, ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _read_csv(path: Path) -> tuple[list[dict], list[str]]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        return list(reader), list(reader.fieldnames or [])


def _write_csv(path: Path, rows: list[dict], fieldnames: list[str] | None = None) -> None:
    fields = fieldnames or list(rows[0])
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
