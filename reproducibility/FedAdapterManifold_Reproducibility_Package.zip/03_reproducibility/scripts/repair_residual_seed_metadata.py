from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path


DEFAULT_ROOTS = (
    "results/recent_lora_fairness_20260804/pacs_resnet18",
    "results/recent_lora_fairness_20260804/officehome_clip_full",
    "results/recent_lora_fairness_20260804/domainnetmini_clip_60class",
)
METHOD = "Ditto-ResidualFAM"
METHOD_SEED_OFFSET = 70000


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Repair an overloaded experiment-seed field without changing metric values."
    )
    parser.add_argument("--root", action="append", default=[])
    parser.add_argument(
        "--audit-output",
        default="results/recent_lora_data_quality_20260805/seed_metadata_repairs.csv",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    audit_rows: list[dict] = []
    for root_text in args.root or list(DEFAULT_ROOTS):
        root = Path(root_text)
        for path in sorted(root.glob("seed_*/*.csv")):
            run_seed = _seed_from_path(path)
            if run_seed is None:
                continue
            repair = _repair_csv(path, run_seed)
            if repair is not None:
                audit_rows.append(repair)
    audit_path = Path(args.audit_output)
    audit_path.parent.mkdir(parents=True, exist_ok=True)
    _write_csv(audit_path, audit_rows)
    print(f"Repaired {sum(int(row['rows_repaired']) for row in audit_rows)} rows in {len(audit_rows)} files.")
    print(f"Audit log: {audit_path}")
    return 0


def _seed_from_path(path: Path) -> int | None:
    for part in path.parts:
        if part.startswith("seed_"):
            try:
                return int(part.split("_", 1)[1])
            except ValueError:
                return None
    return None


def _repair_csv(path: Path, run_seed: int) -> dict | None:
    before_bytes = path.read_bytes()
    with path.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        fieldnames = list(reader.fieldnames or [])
    target_rows = [row for row in rows if row.get("method") == METHOD]
    if not target_rows:
        return None
    content_before = _content_fingerprint(rows)
    for field in ("seed", "method_seed"):
        if field not in fieldnames:
            fieldnames.append(field)
    expected_method_seed = run_seed + METHOD_SEED_OFFSET
    for row in target_rows:
        raw_seed = str(row.get("seed", "")).strip()
        if raw_seed:
            observed_seed = int(float(raw_seed))
            if observed_seed not in {run_seed, expected_method_seed}:
                raise ValueError(
                    f"Unexpected {METHOD} seed {observed_seed} in {path}; "
                    f"expected {run_seed} or {expected_method_seed}."
                )
        row["seed"] = str(run_seed)
        row["method_seed"] = str(expected_method_seed)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    after_bytes = path.read_bytes()
    content_after = _content_fingerprint(rows)
    if content_before != content_after:
        raise AssertionError(f"Non-metadata content changed while repairing {path}")
    return {
        "path": path.as_posix(),
        "method": METHOD,
        "run_seed": run_seed,
        "method_seed": expected_method_seed,
        "rows_repaired": len(target_rows),
        "sha256_before": hashlib.sha256(before_bytes).hexdigest(),
        "sha256_after": hashlib.sha256(after_bytes).hexdigest(),
        "content_fingerprint_before": content_before,
        "content_fingerprint_after": content_after,
        "non_metadata_values_changed": False,
        "repair": "split overloaded seed into run seed and method-specific RNG seed",
    }


def _content_fingerprint(rows: list[dict]) -> str:
    normalized = [
        {key: value for key, value in row.items() if key not in {"seed", "method_seed"}}
        for row in rows
    ]
    payload = json.dumps(normalized, sort_keys=True, ensure_ascii=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _write_csv(path: Path, rows: list[dict]) -> None:
    fields = list(rows[0]) if rows else ["path", "rows_repaired"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
