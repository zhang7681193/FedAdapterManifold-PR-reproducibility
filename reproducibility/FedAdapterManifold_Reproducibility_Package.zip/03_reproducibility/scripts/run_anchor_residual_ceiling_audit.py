from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.config import load_yaml, save_yaml_copy


CONFIGS = {
    "pacs_resnet18": "configs/resolve_stage2_shrinkresidual_20260629/pacs_resnet18/seed_{seed}.yaml",
    "officecaltech_resnet18": "configs/resolve_stage2_shrinkresidual_20260629/officecaltech_resnet18/seed_{seed}.yaml",
    "officehome_clip_full": "configs/resolve_stage2_shrinkresidual_20260629/officehome_clip_full/seed_{seed}.yaml",
    "domainnetmini_clip_60class": "configs/resolve_stage2_shrinkresidual_20260629/domainnetmini_clip/seed_{seed}.yaml",
    "bloodmnist_label_skew": "configs/resolve_stage2_shrinkresidual_20260629/bloodmnist_label_skew/seed_{seed}.yaml",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the predeclared receiver-residual personalization-ceiling audit."
    )
    parser.add_argument("--datasets", default=",".join(CONFIGS))
    parser.add_argument("--seeds", default="0,1,2,3,4")
    parser.add_argument(
        "--output-root",
        default="results/anchor_residual_ceiling_audit_20260812",
    )
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--force", action="store_true")
    parser.add_argument(
        "--calibration-shift-mode",
        choices=["marginal", "confidence-stratified"],
        default="marginal",
    )
    parser.add_argument("--calibration-shift-bins", type=int, default=2)
    parser.add_argument("--calibration-shift-min-stratum-size", type=int, default=16)
    parser.add_argument(
        "--route-candidate-search-mode",
        choices=["calibration-grid", "training-fixed"],
        default="calibration-grid",
    )
    parser.add_argument(
        "--rank",
        type=int,
        default=8,
        help=(
            "Common LoRA rank used by every client and baseline. The ceiling "
            "audit includes FedRot-LoRA, whose official protocol requires a "
            "shared rank; resource heterogeneity is evaluated separately."
        ),
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.rank <= 0:
        raise ValueError("--rank must be positive")
    datasets = [item.strip() for item in args.datasets.split(",") if item.strip()]
    seeds = [int(item.strip()) for item in args.seeds.split(",") if item.strip()]
    unknown = sorted(set(datasets) - set(CONFIGS))
    if unknown:
        raise ValueError("Unknown datasets: " + ", ".join(unknown))

    root = Path(args.output_root)
    config_root = root / "configs"
    log_root = root / "logs"
    config_root.mkdir(parents=True, exist_ok=True)
    log_root.mkdir(parents=True, exist_ok=True)
    for dataset in datasets:
        for seed in seeds:
            source = Path(CONFIGS[dataset].format(seed=seed))
            config = load_yaml(source)
            output_dir = root / dataset / f"seed_{seed}"
            config.update(
                {
                    "output_dir": str(output_dir),
                    "seed": seed,
                    "run_anchor_residual_admission": True,
                    "anchor_residual_admission_sources": "geo,subspace,bank",
                    "run_decoupled_transport": False,
                    "run_cumulative_action_admission": False,
                    "run_recent_lora_baselines": False,
                    "rank_policy": "fixed",
                    "rank": int(args.rank),
                    "min_rank": int(args.rank),
                    "max_rank": int(args.rank),
                    "anchor_residual_epochs": 0,
                    "skip_heavy_personalized_baselines": True,
                    "continue_on_failed_diagnostic": True,
                    "candidate_selector_calibration_fraction": 0.2,
                    "candidate_selector_calibration_strategy": "stratified",
                    "decoupled_transport_candidates": "0,0.25,0.50,0.75,1.0",
                    "decoupled_transport_delta": 0.05,
                    "decoupled_transport_risk_tolerance": 0.0,
                    "calibration_shift_mode": args.calibration_shift_mode,
                    "calibration_shift_bins": args.calibration_shift_bins,
                    "calibration_shift_min_stratum_size": args.calibration_shift_min_stratum_size,
                    "route_candidate_search_mode": args.route_candidate_search_mode,
                    "heterogeneity_setting": (
                        f"{config['heterogeneity_setting']}-receiver-residual-ceiling-audit-"
                        f"fixed-rank-{int(args.rank)}"
                    ),
                }
            )
            prepared = config_root / dataset / f"seed_{seed}.yaml"
            prepared.parent.mkdir(parents=True, exist_ok=True)
            save_yaml_copy(prepared, config)
            if args.prepare_only:
                continue
            if (output_dir / "metrics.csv").exists() and not args.force:
                print(f"SKIP {dataset} seed={seed}", flush=True)
                continue
            log_path = log_root / f"{dataset}_seed_{seed}.log"
            print(f"RUN {dataset} seed={seed}", flush=True)
            command = [
                sys.executable,
                "-m",
                "fedadaptermanifold.run_experiment",
                "--config",
                str(prepared),
            ]
            with log_path.open("w", encoding="utf-8") as log_file:
                completed = subprocess.run(
                    command,
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    check=False,
                )
            if completed.returncode != 0:
                raise RuntimeError(f"Run failed ({completed.returncode}); inspect {log_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
