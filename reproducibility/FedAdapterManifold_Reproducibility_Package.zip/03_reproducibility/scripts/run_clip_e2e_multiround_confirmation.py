from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the frozen DomainNetMini-60 multi-round CLIP-LoRA confirmation."
    )
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--geometry-pattern", required=True, help="Path containing {seed}.")
    parser.add_argument(
        "--output-root",
        default="results/fam_clip_e2e_domainnet60_multiround_exactlocal_5seed_20260813",
    )
    parser.add_argument("--seeds", default="0,1,2,3,4")
    parser.add_argument("--shots", default="2,4")
    parser.add_argument("--rounds", type=int, default=5)
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    seeds = [int(value) for value in args.seeds.split(",") if value.strip()]
    shots = [int(value) for value in args.shots.split(",") if value.strip()]
    if seeds != [0, 1, 2, 3, 4]:
        raise ValueError("The confirmation protocol requires seeds 0,1,2,3,4")
    if shots != [2, 4]:
        raise ValueError("The confirmation protocol requires the fixed 2,4-shot sweep")
    if args.rounds != 5:
        raise ValueError("The confirmation protocol requires five communication rounds")

    output_root = Path(args.output_root)
    log_root = output_root / "logs"
    log_root.mkdir(parents=True, exist_ok=True)
    manifest = {
        "protocol": "domainnetmini60_clip_vit_b16_attention_lora_multiround_exactlocal_v2",
        "seeds": seeds,
        "shots": shots,
        "communication_rounds": args.rounds,
        "local_epochs_per_round": 1,
        "rank": 4,
        "lora_blocks": 2,
        "calibration_fraction": 0.20,
        "certificate_family_alpha": 0.05,
        "certificate_comparisons_per_receiver": 3,
        "certificate_per_comparison_alpha": 0.05 / 3.0,
        "immutable_safety_anchor": "Local-CLIP-LoRA",
        "test_used_for_selection": False,
        "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "experiment_entrypoint_sha256": hashlib.sha256(
            (ROOT / "scripts" / "run_clip_vit_lora_federated_main.py").read_bytes()
        ).hexdigest(),
    }
    (output_root / "frozen_protocol.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    for shot in shots:
        for seed in seeds:
            output_dir = output_root / f"shot_{shot}" / f"seed_{seed}"
            if (output_dir / "metrics.csv").exists() and not args.force:
                print(f"SKIP shot={shot} seed={seed}", flush=True)
                continue
            geometry_dir = Path(str(args.geometry_pattern).format(seed=seed))
            if not geometry_dir.exists():
                raise FileNotFoundError(geometry_dir)
            command = [
                sys.executable,
                str(ROOT / "scripts" / "run_clip_vit_lora_federated_main.py"),
                "--data-root",
                str(Path(args.data_root)),
                "--output-dir",
                str(output_dir),
                "--dataset",
                "DomainNetMini-60",
                "--domains",
                "clipart,infograph,painting,quickdraw,real,sketch",
                "--num-classes",
                "60",
                "--train-per-class",
                str(shot),
                "--test-per-class",
                "8",
                "--calibration-fraction",
                "0.20",
                "--communication-rounds",
                str(args.rounds),
                "--local-epochs",
                "1",
                "--batch-size",
                "8",
                "--rank",
                "4",
                "--lr",
                "0.0005",
                "--seed",
                str(seed),
                "--device",
                "cuda",
                "--model-name",
                "ViT-B/16",
                "--lora-blocks",
                "2",
                "--geometry-outputs-dir",
                str(geometry_dir),
                "--round-id",
                "4",
                "--tangent-admission",
                "--tangent-certified",
                "--tangent-certificate-alpha",
                str(0.05 / 3.0),
            ]
            log_path = log_root / f"shot_{shot}_seed_{seed}.log"
            print(f"RUN shot={shot} seed={seed}", flush=True)
            with log_path.open("w", encoding="utf-8") as log_file:
                completed = subprocess.run(
                    command,
                    cwd=ROOT,
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    check=False,
                )
            if completed.returncode != 0:
                raise RuntimeError(f"Run failed ({completed.returncode}); inspect {log_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
