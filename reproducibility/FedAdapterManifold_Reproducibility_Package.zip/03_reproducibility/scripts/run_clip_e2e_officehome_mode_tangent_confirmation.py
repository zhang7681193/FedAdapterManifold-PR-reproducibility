from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
CONTRACT = ROOT / "results" / "geometry_contract_20260813"
ENTRYPOINT = ROOT / "scripts" / "run_clip_vit_lora_federated_main.py"
THEORY = ROOT / "docs" / "mode_tangent_routing_theory_20260814.md"
ANALYZER = ROOT / "scripts" / "analyze_clip_e2e_officehome_mode_tangent_confirmation.py"
REFERENCE = (
    ROOT
    / "results"
    / "fam_clip_e2e_officehome65_temporal_projector_20260814"
    / "final-residual"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the frozen OfficeHome mode-tangent CLIP-LoRA confirmation."
    )
    parser.add_argument("--data-root", required=True)
    parser.add_argument(
        "--output-root",
        default="results/fam_clip_e2e_officehome65_mode_tangent_20260814",
    )
    parser.add_argument("--run-seeds", default="0,1,2,3,4")
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def geometry_by_seed() -> dict[int, Path]:
    manifest = pd.read_csv(CONTRACT / "geometry_snapshot_manifest.csv")
    rows = manifest[
        (manifest["dataset"] == "OfficeHome")
        & (manifest["round_id"] == 4)
        & manifest["roles"].astype(str).str.contains("main_table", regex=False)
    ]
    mapping: dict[int, Path] = {}
    for row in rows.to_dict("records"):
        seed = int(row["seed"])
        path = CONTRACT / str(row["relative_geometry_dir"])
        if seed in mapping:
            raise ValueError(f"multiple geometry snapshots for seed {seed}")
        if not path.is_dir():
            raise FileNotFoundError(path)
        mapping[seed] = path
    if set(mapping) != set(range(5)):
        raise ValueError(f"expected geometry seeds 0--4, found {sorted(mapping)}")
    return mapping


def main() -> int:
    args = parse_args()
    frozen_seeds = list(range(5))
    run_seeds = [int(value) for value in args.run_seeds.split(",") if value.strip()]
    if not run_seeds or not set(run_seeds).issubset(frozen_seeds):
        raise ValueError("run-seeds must be a non-empty subset of 0,1,2,3,4")
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    geometry = geometry_by_seed()
    reference_hashes = {
        str(seed): sha256(REFERENCE / f"seed_{seed}" / "per_client_metrics.csv")
        for seed in frozen_seeds
    }
    protocol = {
        "protocol": "officehome65_clip_vit_b32_mode_tangent_exact_v1",
        "frozen_seeds": frozen_seeds,
        "dataset": "OfficeHome",
        "domains": ["Art", "Clipart", "Product", "Real_World"],
        "num_classes": 65,
        "train_per_class": 8,
        "test_per_class": 8,
        "calibration_fraction": 0.25,
        "communication_rounds": 5,
        "local_epochs": 1,
        "batch_size": 16,
        "rank": 4,
        "learning_rate": 0.0005,
        "model_name": "ViT-B/32",
        "lora_blocks": 2,
        "subspace_estimator": "final-residual",
        "mode_tangent_alphas": [0.25, 0.5, 1.0],
        "screen_accuracy_tolerance": 0.005,
        "routing_prior_weight": 0.1,
        "certificate_alpha_per_receiver": 0.05 / 4.0,
        "class_label_map_sha256": sha256(
            ROOT / "configs" / "officehome_65_class_label_map.json"
        ),
        "geometry_contract_sha256": sha256(CONTRACT / "geometry_contract.json"),
        "entrypoint_sha256": sha256(ENTRYPOINT),
        "runner_sha256": sha256(Path(__file__)),
        "analyzer_sha256": sha256(ANALYZER),
        "theory_sha256": sha256(THEORY),
        "matched_control_per_client_sha256": reference_hashes,
        "success_criteria": [
            "seed bootstrap CI lower bound versus Geo-only is positive",
            "seed bootstrap CI lower bound versus Local is positive",
            "at least one of 20 receiver-seed units is certified non-local",
            "zero certified non-local test outcomes are worse than Local",
            "zero negative seed-level certified gains versus Local",
            "matched controls reproduce to maximum absolute delta <= 1e-12",
            "aggregate test routing contains both self and external routes",
        ],
        "test_used_for_routing_or_selection": False,
    }
    protocol_path = output_root / "frozen_protocol.json"
    encoded = json.dumps(protocol, indent=2, sort_keys=True) + "\n"
    if protocol_path.exists() and protocol_path.read_text(encoding="utf-8") != encoded:
        raise RuntimeError("frozen protocol already exists with different content")
    protocol_path.write_text(encoded, encoding="utf-8")

    log_root = output_root / "logs"
    log_root.mkdir(parents=True, exist_ok=True)
    for seed in run_seeds:
        output_dir = output_root / f"seed_{seed}"
        if (output_dir / "metrics.csv").is_file() and not args.force:
            print(f"SKIP seed={seed}", flush=True)
            continue
        command = [
            sys.executable,
            str(ENTRYPOINT),
            "--data-root",
            str(Path(args.data_root)),
            "--output-dir",
            str(output_dir),
            "--dataset",
            "OfficeHome-65",
            "--domains",
            "Art,Clipart,Product,Real_World",
            "--num-classes",
            "65",
            "--train-per-class",
            "8",
            "--test-per-class",
            "8",
            "--calibration-fraction",
            "0.25",
            "--communication-rounds",
            "5",
            "--local-epochs",
            "1",
            "--batch-size",
            "16",
            "--rank",
            "4",
            "--lr",
            "0.0005",
            "--seed",
            str(seed),
            "--device",
            "cuda",
            "--model-name",
            "ViT-B/32",
            "--lora-blocks",
            "2",
            "--class-label-map",
            str(ROOT / "configs" / "officehome_65_class_label_map.json"),
            "--geometry-outputs-dir",
            str(geometry[seed]),
            "--round-id",
            "4",
            "--subspace-estimator",
            "final-residual",
            "--mode-tangent-routing",
            "--mode-tangent-alphas",
            "0.25,0.5,1.0",
            "--mode-tangent-screen-accuracy-tolerance",
            "0.005",
            "--mode-tangent-certificate-alpha",
            str(0.05 / 4.0),
            "--routing-prior-weight",
            "0.1",
        ]
        log_path = log_root / f"seed_{seed}.log"
        print(f"RUN seed={seed}", flush=True)
        with log_path.open("w", encoding="utf-8") as log_file:
            completed = subprocess.run(
                command,
                cwd=ROOT,
                stdout=log_file,
                stderr=subprocess.STDOUT,
                check=False,
            )
        if completed.returncode != 0:
            raise RuntimeError(
                f"run failed ({completed.returncode}); inspect {log_path}"
            )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
