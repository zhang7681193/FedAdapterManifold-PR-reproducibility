from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
ENTRYPOINT = ROOT / "scripts" / "run_clip_vit_lora_federated_main.py"
CONTRACT = ROOT / "results" / "geometry_contract_20260813"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the isolated OfficeHome utility-tangent development seed."
    )
    parser.add_argument("--data-root", required=True)
    parser.add_argument(
        "--output-dir",
        default="results/fam_clip_e2e_officehome65_utility_tangent_dev_20260814/seed_18",
    )
    parser.add_argument("--seed", type=int, default=18)
    return parser.parse_args()


def geometry_seed_zero() -> Path:
    manifest = pd.read_csv(CONTRACT / "geometry_snapshot_manifest.csv")
    rows = manifest[
        (manifest["dataset"] == "OfficeHome")
        & (manifest["round_id"] == 4)
        & (manifest["seed"] == 0)
        & manifest["roles"].astype(str).str.contains("main_table", regex=False)
    ]
    if len(rows) != 1:
        raise RuntimeError("expected one OfficeHome seed-0 geometry snapshot")
    path = CONTRACT / str(rows.iloc[0]["relative_geometry_dir"])
    if not path.is_dir():
        raise FileNotFoundError(path)
    return path


def main() -> int:
    args = parse_args()
    command = [
        sys.executable,
        str(ENTRYPOINT),
        "--data-root",
        str(Path(args.data_root)),
        "--output-dir",
        str(Path(args.output_dir)),
        "--dataset",
        "OfficeHome-65-UtilityTangent-Development",
        "--domains",
        "Art,Clipart,Product,Real_World",
        "--num-classes",
        "65",
        "--train-per-class",
        "8",
        "--test-per-class",
        "8",
        "--calibration-fraction",
        "0.25",
        "--communication-rounds",
        "5",
        "--local-epochs",
        "1",
        "--batch-size",
        "16",
        "--rank",
        "4",
        "--lr",
        "0.0005",
        "--seed",
        str(args.seed),
        "--device",
        "cuda",
        "--model-name",
        "ViT-B/32",
        "--lora-blocks",
        "2",
        "--class-label-map",
        str(ROOT / "configs" / "officehome_65_class_label_map.json"),
        "--geometry-outputs-dir",
        str(geometry_seed_zero()),
        "--round-id",
        "4",
        "--subspace-estimator",
        "final-residual",
        "--utility-tangent-routing",
        "--utility-tangent-alphas",
        "0.5,1.0,2.0,4.0,8.0",
        "--utility-tangent-modes",
        "4",
        "--utility-tangent-screen-accuracy-tolerance",
        "0.005",
        "--utility-tangent-min-mode-samples",
        "12",
        "--utility-tangent-certificate-alpha",
        str(0.05 / 4.0),
    ]
    return subprocess.run(command, cwd=ROOT, check=False).returncode


if __name__ == "__main__":
    raise SystemExit(main())
