from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import json
import math
import platform
import random
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.source_coverage import common_descent_in_span, source_coverage
from fedadaptermanifold.function_space_transport import (
    audit_function_transport_risk,
    class_conditional_probability_teacher,
    crossfit_convex_expert_screen,
    log_probabilities_from_logits,
    probability_mixture_teacher,
)


IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


@dataclass
class Config:
    data_root: str
    output_dir: str
    dataset: str
    domains: str
    num_classes: int
    train_per_class: int
    test_per_class: int
    calibration_fraction: float
    communication_rounds: int
    local_epochs: int
    batch_size: int
    rank: int
    lr: float
    seed: int
    device: str
    model_name: str
    lora_blocks: int
    prompt_template: str
    class_labels: str
    class_label_map: str
    geometry_outputs_dir: str
    round_id: int
    graph_self_weight: float
    tau_geo: float
    tau_fam: float
    lambda_geo: float
    fam_self_weight: float
    graph_k: int
    tangent_admission: bool
    tangent_alphas: str
    tangent_min_loss_gain: float
    tangent_accuracy_tolerance: float
    tangent_certified: bool
    tangent_certificate_alpha: float
    prototype_bank_routing: bool
    routing_prior_weight: float
    prototype_routing_exclude_self: bool
    mode_tangent_routing: bool
    mode_tangent_alphas: str
    mode_tangent_screen_accuracy_tolerance: float
    mode_tangent_certificate_alpha: float
    utility_tangent_routing: bool
    utility_tangent_alphas: str
    utility_tangent_modes: int
    utility_tangent_screen_accuracy_tolerance: float
    utility_tangent_min_mode_samples: int
    utility_tangent_certificate_alpha: float
    subspace_estimator: str
    subspace_ema_decay: float
    source_coverage_audit: bool
    source_coverage_only: bool
    signed_span_admission: bool
    signed_span_certificate_alpha: float
    common_descent_admission: bool
    common_descent_certificate_alpha: float
    function_transport_admission: bool
    function_transport_expert_ablation_only: bool
    function_transport_kl_strength: float
    function_transport_fold_temperature: float
    function_transport_distill_epochs: int
    function_transport_distill_lr: float
    function_transport_distill_weight: float
    function_transport_anchor_weight: float
    function_transport_prototype_temperature: float
    function_transport_certificate_alpha: float


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Federated end-to-end CLIP ViT LoRA experiment for FedAdapterManifold. "
            "Each domain is a client; local visual attention LoRA adapters are trained, "
            "then combined by FedAvg, lifted averaging, FedGeo graph aggregation, and "
            "subspace/geometry-conditioned FAM."
        )
    )
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--output-dir", default="results/fam_clip_vit_lora_federated_main_v1/seed_0")
    parser.add_argument("--dataset", default="DomainNetMini")
    parser.add_argument("--domains", default="clipart,infograph,painting,quickdraw,real,sketch")
    parser.add_argument("--num-classes", type=int, default=20)
    parser.add_argument("--train-per-class", type=int, default=4)
    parser.add_argument("--test-per-class", type=int, default=4)
    parser.add_argument("--calibration-fraction", type=float, default=0.2)
    parser.add_argument("--communication-rounds", type=int, default=1)
    parser.add_argument("--local-epochs", type=int, default=2)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--rank", type=int, default=4)
    parser.add_argument("--lr", type=float, default=5e-4)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--model-name", default="ViT-B/16")
    parser.add_argument("--lora-blocks", type=int, default=2)
    parser.add_argument("--prompt-template", default="a photo of a {label}.")
    parser.add_argument(
        "--class-labels",
        default="",
        help="Optional comma-separated semantic labels aligned with sorted class folders.",
    )
    parser.add_argument(
        "--class-label-map",
        default="",
        help=(
            "Optional JSON object mapping class-folder identifiers to semantic prompt labels. "
            "This is preferred when folders use numeric or otherwise non-semantic names."
        ),
    )
    parser.add_argument("--geometry-outputs-dir", default="")
    parser.add_argument("--round-id", type=int, default=0)
    parser.add_argument("--graph-self-weight", type=float, default=0.35)
    parser.add_argument("--tau-geo", type=float, default=0.5)
    parser.add_argument("--tau-fam", type=float, default=0.75)
    parser.add_argument("--lambda-geo", type=float, default=0.35)
    parser.add_argument("--fam-self-weight", type=float, default=0.45)
    parser.add_argument("--graph-k", type=int, default=2)
    parser.add_argument(
        "--tangent-admission",
        action="store_true",
        help=(
            "Enable the pre-registered receiver-tangent residual candidates. "
            "The default path is unchanged when this flag is absent."
        ),
    )
    parser.add_argument("--tangent-alphas", default="0.125,0.25,0.5,1.0")
    parser.add_argument("--tangent-min-loss-gain", type=float, default=0.0)
    parser.add_argument("--tangent-accuracy-tolerance", type=float, default=0.0)
    parser.add_argument(
        "--tangent-certified",
        action="store_true",
        help="Use training-screened, independently calibrated exact paired admission.",
    )
    parser.add_argument("--tangent-certificate-alpha", type=float, default=0.05)
    parser.add_argument(
        "--prototype-bank-routing",
        action="store_true",
        help="Enable class-conditional input routing over the local adapter bank.",
    )
    parser.add_argument("--routing-prior-weight", type=float, default=0.1)
    parser.add_argument(
        "--prototype-routing-exclude-self",
        action="store_true",
        help="Construct an explicitly non-local bank proposal; Local remains the certified anchor.",
    )
    parser.add_argument(
        "--mode-tangent-routing",
        action="store_true",
        help=(
            "Enable class-conditional receiver-tangent adapter-bank routing. "
            "The step is screened on training-side loss and certified once on "
            "the independent calibration split."
        ),
    )
    parser.add_argument("--mode-tangent-alphas", default="0.25,0.5,1.0")
    parser.add_argument(
        "--mode-tangent-screen-accuracy-tolerance", type=float, default=0.005
    )
    parser.add_argument(
        "--mode-tangent-certificate-alpha", type=float, default=0.0125
    )
    parser.add_argument(
        "--utility-tangent-routing",
        action="store_true",
        help=(
            "Enable cross-fitted semantic-mode routing with training-side "
            "directional-utility screening and an independent exact certificate."
        ),
    )
    parser.add_argument("--utility-tangent-alphas", default="0.5,1.0,2.0,4.0")
    parser.add_argument("--utility-tangent-modes", type=int, default=8)
    parser.add_argument(
        "--utility-tangent-screen-accuracy-tolerance", type=float, default=0.005
    )
    parser.add_argument("--utility-tangent-min-mode-samples", type=int, default=8)
    parser.add_argument(
        "--utility-tangent-certificate-alpha", type=float, default=0.0125
    )
    parser.add_argument(
        "--subspace-estimator",
        choices=("final-residual", "temporal-projector"),
        default="final-residual",
        help=(
            "Estimate routing subspaces from the current round residual or from "
            "a gauge-invariant weighted average of all round projectors."
        ),
    )
    parser.add_argument(
        "--subspace-ema-decay",
        type=float,
        default=1.0,
        help=(
            "Temporal projector weight decay in (0,1]; 1 gives the uniform "
            "minimum-variance average under stationary round noise."
        ),
    )
    parser.add_argument(
        "--source-coverage-audit",
        action="store_true",
        help=(
            "Audit whether the fixed external adapter dictionary covers each "
            "receiver's training-side LoRA descent direction. This diagnostic "
            "does not use calibration or test data and does not change deployment."
        ),
    )
    parser.add_argument(
        "--source-coverage-only",
        action="store_true",
        help=(
            "Replay only the deterministic Local-CLIP-LoRA branch and source-coverage "
            "diagnostic. This is equivalent to the Local branch of the full runner "
            "and avoids retraining unrelated baselines."
        ),
    )
    parser.add_argument(
        "--signed-span-admission",
        action="store_true",
        help=(
            "Construct one training-fitted signed-span donor candidate, apply deterministic "
            "rank-aware backtracking, and deploy it only after an independent paired certificate."
        ),
    )
    parser.add_argument("--signed-span-certificate-alpha", type=float, default=0.0125)
    parser.add_argument(
        "--common-descent-admission",
        action="store_true",
        help=(
            "Construct one max-min donor-span direction that decreases every deterministic "
            "training-fold linearization, require rank-projected loss progress on every fold, "
            "and deploy only after an independent paired certificate."
        ),
    )
    parser.add_argument("--common-descent-certificate-alpha", type=float, default=0.0125)
    parser.add_argument(
        "--function-transport-admission",
        action="store_true",
        help=(
            "Fit a receiver-relative convex mixture of fixed donor-function experts, "
            "distill it into one local LoRA adapter, and deploy only after the "
            "independent paired certificate. Disabled by default."
        ),
    )
    parser.add_argument(
        "--function-transport-expert-ablation-only",
        action="store_true",
        help=(
            "Audit Local/Geo/FAM expert subsets on training-only cross-fit folds and "
            "exit before calibration or test evaluation."
        ),
    )
    parser.add_argument("--function-transport-kl-strength", type=float, default=0.01)
    parser.add_argument("--function-transport-fold-temperature", type=float, default=0.05)
    parser.add_argument("--function-transport-distill-epochs", type=int, default=4)
    parser.add_argument("--function-transport-distill-lr", type=float, default=1e-4)
    parser.add_argument("--function-transport-distill-weight", type=float, default=1.0)
    parser.add_argument("--function-transport-anchor-weight", type=float, default=0.25)
    parser.add_argument("--function-transport-prototype-temperature", type=float, default=0.1)
    parser.add_argument("--function-transport-certificate-alpha", type=float, default=0.0125)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    config = Config(**vars(args))
    if config.function_transport_admission and (
        config.signed_span_admission or config.common_descent_admission
    ):
        raise ValueError(
            "--function-transport-admission must run in an isolated replay so every "
            "candidate and calibration decision is frozen before the first test forward pass"
        )
    if config.function_transport_expert_ablation_only and not (
        config.function_transport_admission
        and config.source_coverage_audit
        and config.source_coverage_only
    ):
        raise ValueError(
            "--function-transport-expert-ablation-only requires the isolated "
            "--function-transport-admission --source-coverage-audit "
            "--source-coverage-only path"
        )
    output_dir = Path(config.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        import clip
        import torch
        import torch.nn as nn
        import torch.nn.functional as F
        from PIL import Image
    except Exception as exc:  # pragma: no cover - optional runtime
        _write_blocker(output_dir, config, f"Missing torch/clip/PIL dependency: {exc}")
        return 2

    device = config.device
    if device == "cuda" and not torch.cuda.is_available():
        device = "cpu"
    _set_seed(config.seed, torch)

    data_root = Path(config.data_root)
    domains = [value.strip() for value in config.domains.split(",") if value.strip()]
    class_names = _select_classes(data_root, domains, config.num_classes)
    if not class_names:
        _write_blocker(output_dir, config, "No shared classes found for requested domains.")
        return 2

    clients = _build_clients(
        data_root=data_root,
        domains=domains,
        class_names=class_names,
        train_per_class=config.train_per_class,
        test_per_class=config.test_per_class,
        calibration_fraction=config.calibration_fraction,
        seed=config.seed,
    )
    if not clients or any(not client["train"] or not client["test"] for client in clients):
        _write_blocker(output_dir, config, "Could not collect non-empty train/test splits for every client.")
        return 2

    model, preprocess = clip.load(config.model_name, device=device)
    model.float()
    model.train()
    for param in model.parameters():
        param.requires_grad_(False)
    lora_modules = inject_visual_attention_lora(model, rank=config.rank, blocks=config.lora_blocks, torch=torch, nn=nn, F=F)
    for module in lora_modules:
        module.to(device)

    prompt_labels = _prompt_labels(class_names, config.class_labels, config.class_label_map)
    text_features = _text_features(model, clip, prompt_labels, config.prompt_template, device, torch)
    zero_state = zero_lora_state(lora_modules)

    d_geo, graph, geometry_provider = _load_geometry(config, clients)
    d_geo_norm = _normalize_distance(d_geo)
    graph_support = _support_from_graph(graph, d_geo_norm, k=config.graph_k)
    geo_weights = _graph_weights(graph_support, d_geo_norm, self_weight=config.graph_self_weight, tau=config.tau_geo)

    if config.communication_rounds < 1:
        raise ValueError("--communication-rounds must be at least 1")

    # Every client and every method starts from the same server LoRA gauge.
    # This is required for a fair factor-averaging control: independently
    # sampled A factors would create an artificial rotational mismatch before
    # any client had observed data.
    reset_lora_parameters(lora_modules, seed=config.seed * 1009 + 7919, torch=torch)
    server_initial_state = get_lora_state(lora_modules)
    if config.source_coverage_only:
        if not config.source_coverage_audit:
            raise ValueError("--source-coverage-only requires --source-coverage-audit")
        local_states = [_copy_lora_state(server_initial_state) for _ in clients]
        local_history: list[dict] = []
        for communication_round in range(config.communication_rounds):
            trained_states: list[list[dict[str, np.ndarray]]] = []
            for client_index, client in enumerate(clients):
                state, history = _train_client(
                    model=model,
                    modules=lora_modules,
                    preprocess=preprocess,
                    text_features=text_features,
                    samples=client["train"],
                    class_names=class_names,
                    device=device,
                    batch_size=config.batch_size,
                    epochs=config.local_epochs,
                    lr=config.lr,
                    seed=(
                        config.seed * 1000003
                        + communication_round * 1009
                        + int(client["client_id"])
                    ),
                    initial_state=local_states[client_index],
                    Image=Image,
                    torch=torch,
                    F=F,
                )
                trained_states.append(state)
                for row in history:
                    row.update(
                        {
                            "client_id": client["client_id"],
                            "domain": client["domain"],
                            "method": "Local-CLIP-LoRA",
                            "seed": config.seed,
                            "dataset": config.dataset,
                            "round": communication_round,
                        }
                    )
                    local_history.append(row)
            local_states = trained_states
        if config.function_transport_expert_ablation_only:
            function_d_sub = _subspace_distance_matrix(local_states)
            function_fam_weights = _fam_weights(
                graph=graph_support,
                d_sub=_normalize_distance(function_d_sub),
                d_geo=d_geo_norm,
                lambda_geo=config.lambda_geo,
                tau=config.tau_fam,
                self_weight=config.fam_self_weight,
            )
            function_prototypes, function_prototype_mask = _compute_state_class_prototypes(
                model=model,
                modules=lora_modules,
                preprocess=preprocess,
                clients=clients,
                local_states=local_states,
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                Image=Image,
                torch=torch,
            )
            expert_ablation_rows = _run_training_only_function_expert_ablation(
                model=model,
                modules=lora_modules,
                preprocess=preprocess,
                text_features=text_features,
                clients=clients,
                local_states=local_states,
                initial_state=server_initial_state,
                geo_weights=geo_weights,
                graph_support=graph_support,
                d_geo_norm=d_geo_norm,
                prototypes=function_prototypes,
                prototype_mask=function_prototype_mask,
                class_names=class_names,
                config=config,
                device=device,
                Image=Image,
                torch=torch,
                F=F,
            )
            _write_csv(
                output_dir / "function_expert_ablation.csv", expert_ablation_rows
            )
            _write_csv(output_dir / "training_history.csv", local_history)
            _write_config(
                output_dir / "config.yaml",
                config,
                class_names,
                geometry_provider,
                clients,
                prompt_labels,
            )
            _write_run_provenance(
                output_dir / "run_provenance.json",
                config=config,
                clients=clients,
                data_root=data_root,
                geometry_provider=geometry_provider,
                torch=torch,
            )
            set_lora_state(lora_modules, zero_state, device=device, torch=torch)
            return 0
        coverage_rows, coverage_donor_rows = _audit_source_coverage(
            model=model,
            modules=lora_modules,
            preprocess=preprocess,
            text_features=text_features,
            clients=clients,
            local_states=local_states,
            fam_weights=np.asarray(graph_support, dtype=np.float64),
            class_names=class_names,
            device=device,
            batch_size=config.batch_size,
            Image=Image,
            torch=torch,
            F=F,
            seed=config.seed,
            dataset=config.dataset,
            communication_round=config.communication_rounds - 1,
        )
        replay_rows: list[dict] = []
        signed_span_rows: list[dict] = []
        common_descent_rows: list[dict] = []
        function_transport_rows: list[dict] = []
        function_fam_weights = np.eye(len(clients), dtype=np.float64)
        function_prototypes = None
        function_prototype_mask = None
        if config.function_transport_admission:
            function_d_sub = _subspace_distance_matrix(local_states)
            function_fam_weights = _fam_weights(
                graph=graph_support,
                d_sub=_normalize_distance(function_d_sub),
                d_geo=d_geo_norm,
                lambda_geo=config.lambda_geo,
                tau=config.tau_fam,
                self_weight=config.fam_self_weight,
            )
            function_prototypes, function_prototype_mask = _compute_state_class_prototypes(
                model=model,
                modules=lora_modules,
                preprocess=preprocess,
                clients=clients,
                local_states=local_states,
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                Image=Image,
                torch=torch,
            )
            function_transport_rows, replay_rows = _run_function_transport_replay(
                model=model,
                modules=lora_modules,
                preprocess=preprocess,
                text_features=text_features,
                clients=clients,
                local_states=local_states,
                initial_state=server_initial_state,
                geo_weights=geo_weights,
                fam_weights=function_fam_weights,
                graph_support=graph_support,
                d_geo_norm=d_geo_norm,
                prototypes=function_prototypes,
                prototype_mask=function_prototype_mask,
                class_names=class_names,
                config=config,
                device=device,
                Image=Image,
                torch=torch,
                F=F,
            )
            _write_csv(output_dir / "source_coverage.csv", coverage_rows)
            _write_csv(output_dir / "source_coverage_donors.csv", coverage_donor_rows)
            _write_csv(output_dir / "local_replay_metrics.csv", replay_rows)
            _write_csv(
                output_dir / "function_transport_admission.csv", function_transport_rows
            )
            _write_csv(output_dir / "training_history.csv", local_history)
            _write_config(
                output_dir / "config.yaml",
                config,
                class_names,
                geometry_provider,
                clients,
                prompt_labels,
            )
            _write_run_provenance(
                output_dir / "run_provenance.json",
                config=config,
                clients=clients,
                data_root=data_root,
                geometry_provider=geometry_provider,
                torch=torch,
            )
            set_lora_state(lora_modules, zero_state, device=device, torch=torch)
            return 0
        for client_index, client in enumerate(clients):
            if not config.function_transport_admission:
                set_lora_state(lora_modules, local_states[client_index], device=device, torch=torch)
                metrics = _evaluate(
                    model=model,
                    preprocess=preprocess,
                    text_features=text_features,
                    samples=client["test"],
                    class_names=class_names,
                    device=device,
                    batch_size=config.batch_size,
                    Image=Image,
                    torch=torch,
                )
                replay_rows.append(
                    {
                        "method": "Local-CLIP-LoRA",
                        "seed": config.seed,
                        "dataset": config.dataset,
                        "round": config.communication_rounds - 1,
                        "client_id": client["client_id"],
                        "domain": client["domain"],
                        "accuracy": metrics["accuracy"],
                        "loss": metrics["loss"],
                        "num_samples": metrics["num_samples"],
                        "test_used_for_coverage": False,
                    }
                )
            if config.signed_span_admission:
                candidate_state, construction = _build_signed_span_candidate(
                    model=model,
                    modules=lora_modules,
                    preprocess=preprocess,
                    text_features=text_features,
                    client=client,
                    clients=clients,
                    receiver_idx=client_index,
                    local_states=local_states,
                    class_names=class_names,
                    device=device,
                    batch_size=config.batch_size,
                    rank=config.rank,
                    Image=Image,
                    torch=torch,
                    F=F,
                )
                set_lora_state(lora_modules, local_states[client_index], device=device, torch=torch)
                local_calibration = _evaluate_detailed(
                    model, preprocess, text_features, client["calibration"], class_names,
                    device, config.batch_size, Image, torch,
                )
                set_lora_state(lora_modules, candidate_state, device=device, torch=torch)
                candidate_calibration = _evaluate_detailed(
                    model, preprocess, text_features, client["calibration"], class_names,
                    device, config.batch_size, Image, torch,
                )
                certificate = _paired_dual_risk_certificate(
                    local_calibration,
                    candidate_calibration,
                    config.signed_span_certificate_alpha,
                )
                certified = bool(construction["constructed"] and certificate["certified"])
                # Freeze the deployment decision before any test-set forward pass.
                set_lora_state(lora_modules, local_states[client_index], device=device, torch=torch)
                local_test = _evaluate_detailed(
                    model, preprocess, text_features, client["test"], class_names,
                    device, config.batch_size, Image, torch,
                )
                set_lora_state(lora_modules, candidate_state, device=device, torch=torch)
                candidate_test = _evaluate_detailed(
                    model, preprocess, text_features, client["test"], class_names,
                    device, config.batch_size, Image, torch,
                )
                deployed_test = candidate_test if certified else local_test
                signed_span_rows.append(
                    {
                        "method": "FedAdapterManifold-SignedSpan-Admit-CLIP-LoRA",
                        "seed": config.seed,
                        "dataset": config.dataset,
                        "round": config.communication_rounds - 1,
                        "client_id": client["client_id"],
                        "domain": client["domain"],
                        **construction,
                        "calibration_size": local_calibration["num_samples"],
                        "local_calibration_accuracy": local_calibration["accuracy"],
                        "candidate_calibration_accuracy": candidate_calibration["accuracy"],
                        "local_calibration_loss": local_calibration["loss"],
                        "candidate_calibration_loss": candidate_calibration["loss"],
                        "beneficial_discordances": certificate["beneficial"],
                        "harmful_discordances": certificate["harmful"],
                        "one_sided_exact_p": certificate["p_value"],
                        "loss_one_sided_exact_p": certificate["loss_p_value"],
                        "certificate_basis": certificate["certificate_basis"],
                        "certified": certified,
                        "deployed_method": "SignedSpan" if certified else "Local-CLIP-LoRA",
                        "local_test_accuracy": local_test["accuracy"],
                        "candidate_test_accuracy": candidate_test["accuracy"],
                        "deployed_test_accuracy": deployed_test["accuracy"],
                        "num_test_samples": local_test["num_samples"],
                        "test_gain_vs_local": deployed_test["accuracy"] - local_test["accuracy"],
                        "candidate_test_gain_vs_local": candidate_test["accuracy"] - local_test["accuracy"],
                        "harmful_admission": bool(
                            certified and candidate_test["accuracy"] < local_test["accuracy"] - 1e-12
                        ),
                        "test_used_for_construction_or_selection": False,
                    }
                )
            if config.common_descent_admission:
                candidate_state, construction = _build_common_descent_candidate(
                    model=model,
                    modules=lora_modules,
                    preprocess=preprocess,
                    text_features=text_features,
                    client=client,
                    clients=clients,
                    receiver_idx=client_index,
                    local_states=local_states,
                    class_names=class_names,
                    device=device,
                    batch_size=config.batch_size,
                    rank=config.rank,
                    split_seed=config.seed * 1009 + int(client["client_id"]) + 20260814,
                    Image=Image,
                    torch=torch,
                    F=F,
                )
                set_lora_state(lora_modules, local_states[client_index], device=device, torch=torch)
                local_calibration = _evaluate_detailed(
                    model, preprocess, text_features, client["calibration"], class_names,
                    device, config.batch_size, Image, torch,
                )
                set_lora_state(lora_modules, candidate_state, device=device, torch=torch)
                candidate_calibration = _evaluate_detailed(
                    model, preprocess, text_features, client["calibration"], class_names,
                    device, config.batch_size, Image, torch,
                )
                certificate = _paired_dual_risk_certificate(
                    local_calibration,
                    candidate_calibration,
                    config.common_descent_certificate_alpha,
                )
                certified = bool(construction["constructed"] and certificate["certified"])
                set_lora_state(lora_modules, local_states[client_index], device=device, torch=torch)
                local_test = _evaluate_detailed(
                    model, preprocess, text_features, client["test"], class_names,
                    device, config.batch_size, Image, torch,
                )
                set_lora_state(lora_modules, candidate_state, device=device, torch=torch)
                candidate_test = _evaluate_detailed(
                    model, preprocess, text_features, client["test"], class_names,
                    device, config.batch_size, Image, torch,
                )
                deployed_test = candidate_test if certified else local_test
                common_descent_rows.append(
                    {
                        "method": "FedAdapterManifold-CommonDescent-Admit-CLIP-LoRA",
                        "seed": config.seed,
                        "dataset": config.dataset,
                        "round": config.communication_rounds - 1,
                        "client_id": client["client_id"],
                        "domain": client["domain"],
                        **construction,
                        "calibration_size": local_calibration["num_samples"],
                        "local_calibration_accuracy": local_calibration["accuracy"],
                        "candidate_calibration_accuracy": candidate_calibration["accuracy"],
                        "local_calibration_loss": local_calibration["loss"],
                        "candidate_calibration_loss": candidate_calibration["loss"],
                        "beneficial_discordances": certificate["beneficial"],
                        "harmful_discordances": certificate["harmful"],
                        "one_sided_exact_p": certificate["p_value"],
                        "loss_one_sided_exact_p": certificate["loss_p_value"],
                        "certificate_basis": certificate["certificate_basis"],
                        "certified": certified,
                        "deployed_method": "CommonDescent" if certified else "Local-CLIP-LoRA",
                        "local_test_accuracy": local_test["accuracy"],
                        "candidate_test_accuracy": candidate_test["accuracy"],
                        "deployed_test_accuracy": deployed_test["accuracy"],
                        "num_test_samples": local_test["num_samples"],
                        "test_gain_vs_local": deployed_test["accuracy"] - local_test["accuracy"],
                        "candidate_test_gain_vs_local": candidate_test["accuracy"] - local_test["accuracy"],
                        "harmful_admission": bool(
                            certified and candidate_test["accuracy"] < local_test["accuracy"] - 1e-12
                        ),
                        "test_used_for_construction_or_selection": False,
                    }
                )
        _write_csv(output_dir / "source_coverage.csv", coverage_rows)
        _write_csv(output_dir / "source_coverage_donors.csv", coverage_donor_rows)
        _write_csv(output_dir / "local_replay_metrics.csv", replay_rows)
        _write_csv(output_dir / "signed_span_admission.csv", signed_span_rows)
        _write_csv(output_dir / "common_descent_admission.csv", common_descent_rows)
        _write_csv(output_dir / "function_transport_admission.csv", function_transport_rows)
        _write_csv(output_dir / "training_history.csv", local_history)
        _write_config(output_dir / "config.yaml", config, class_names, geometry_provider, clients, prompt_labels)
        _write_run_provenance(
            output_dir / "run_provenance.json",
            config=config,
            clients=clients,
            data_root=data_root,
            geometry_provider=geometry_provider,
            torch=torch,
        )
        set_lora_state(lora_modules, zero_state, device=device, torch=torch)
        return 0
    branch_states = {
        name: [_copy_lora_state(server_initial_state) for _ in clients]
        for name in ["local", "fedavg", "lift", "geo", "fam"]
    }
    train_history: list[dict] = []
    uniform = np.full(len(clients), 1.0 / max(1, len(clients)), dtype=np.float64)
    fam_weights = np.eye(len(clients), dtype=np.float64)
    final_trained_states: dict[str, list[list[dict[str, np.ndarray]]]] = {}
    round_residual_history: list[list[list[dict[str, np.ndarray]]]] = []
    branch_labels = {
        "local": "Local-CLIP-LoRA",
        "fedavg": "FedAvg-CLIP-LoRA",
        "lift": "FedAvg-Lift-CLIP-LoRA",
        "geo": "FedGeo-Agg-CLIP-LoRA",
        "fam": "FedAdapterManifold-CLIP-LoRA",
    }
    for communication_round in range(config.communication_rounds):
        trained_by_branch: dict[str, list[list[dict[str, np.ndarray]]]] = {}
        for branch_name, initial_states in branch_states.items():
            trained_states: list[list[dict[str, np.ndarray]]] = []
            for client_index, client in enumerate(clients):
                state, history = _train_client(
                    model=model,
                    modules=lora_modules,
                    preprocess=preprocess,
                    text_features=text_features,
                    samples=client["train"],
                    class_names=class_names,
                    device=device,
                    batch_size=config.batch_size,
                    epochs=config.local_epochs,
                    lr=config.lr,
                    seed=(
                        config.seed * 1000003
                        + communication_round * 1009
                        + int(client["client_id"])
                    ),
                    initial_state=initial_states[client_index],
                    Image=Image,
                    torch=torch,
                    F=F,
                )
                trained_states.append(state)
                for row in history:
                    row.update(
                        {
                            "client_id": client["client_id"],
                            "domain": client["domain"],
                            "method": branch_labels[branch_name],
                            "seed": config.seed,
                            "dataset": config.dataset,
                            "round": communication_round,
                        }
                    )
                    train_history.append(row)
            trained_by_branch[branch_name] = trained_states

        fedavg_state = average_factor_state(trained_by_branch["fedavg"], uniform)
        fedavg_lift_state = average_lifted_state(
            trained_by_branch["lift"], uniform, rank=config.rank
        )
        fedgeo_states = [
            average_lifted_state(trained_by_branch["geo"], geo_weights[i], rank=config.rank)
            for i in range(len(clients))
        ]
        round_residual_states = [
            _residual_lora_state(
                trained_by_branch["fam"][client_index],
                branch_states["fam"][client_index],
                rank=config.rank,
            )
            for client_index in range(len(clients))
        ]
        round_residual_history.append(round_residual_states)
        if config.subspace_estimator == "temporal-projector":
            round_d_sub = _temporal_subspace_distance_matrix(
                round_residual_history,
                decay=config.subspace_ema_decay,
            )
        else:
            round_d_sub = _subspace_distance_matrix(round_residual_states)
        fam_weights = _fam_weights(
            graph=graph_support,
            d_sub=_normalize_distance(round_d_sub),
            d_geo=d_geo_norm,
            lambda_geo=config.lambda_geo,
            tau=config.tau_fam,
            self_weight=config.fam_self_weight,
        )
        fam_states = [
            average_lifted_state(trained_by_branch["fam"], fam_weights[i], rank=config.rank)
            for i in range(len(clients))
        ]
        final_trained_states = trained_by_branch
        branch_states = {
            "local": trained_by_branch["local"],
            "fedavg": [_copy_lora_state(fedavg_state) for _ in clients],
            "lift": [_copy_lora_state(fedavg_lift_state) for _ in clients],
            "geo": fedgeo_states,
            "fam": fam_states,
        }

    local_states = branch_states["local"]
    fedavg_state = branch_states["fedavg"][0]
    fedavg_lift_state = branch_states["lift"][0]
    fedgeo_states = branch_states["geo"]
    fam_states = branch_states["fam"]
    source_coverage_rows: list[dict] = []
    source_coverage_donor_rows: list[dict] = []
    if config.source_coverage_audit:
        source_coverage_rows, source_coverage_donor_rows = _audit_source_coverage(
            model=model,
            modules=lora_modules,
            preprocess=preprocess,
            text_features=text_features,
            clients=clients,
            local_states=local_states,
            fam_weights=fam_weights,
            class_names=class_names,
            device=device,
            batch_size=config.batch_size,
            Image=Image,
            torch=torch,
            F=F,
            seed=config.seed,
            dataset=config.dataset,
            communication_round=config.communication_rounds - 1,
        )
    # Diagnostics use the pre-aggregation client updates from the final round,
    # while evaluation uses the corresponding post-aggregation states.
    d_sub = _subspace_distance_matrix(local_states)
    routing_d_sub = (
        _temporal_subspace_distance_matrix(
            round_residual_history,
            decay=config.subspace_ema_decay,
        )
        if config.subspace_estimator == "temporal-projector"
        else _subspace_distance_matrix(round_residual_history[-1])
    )

    method_states: dict[str, list[list[dict[str, np.ndarray]]]] = {
        "CLIP-ZeroShot": [zero_state for _ in clients],
        "Local-CLIP-LoRA": local_states,
        "FedAvg-CLIP-LoRA": [fedavg_state for _ in clients],
        "FedAvg-Lift-CLIP-LoRA": [fedavg_lift_state for _ in clients],
        "FedGeo-Agg-CLIP-LoRA": fedgeo_states,
        "FedAdapterManifold-CLIP-LoRA": fam_states,
    }

    tangent_manifest: list[dict] = []
    tangent_method_states = method_states
    if config.tangent_admission or config.tangent_certified:
        tangent_alphas = _parse_tangent_alphas(config.tangent_alphas)
        bank_top1_states, bank_top1_donors = _top_compatible_bank_source(local_states, fam_weights)
        tangent_candidates, tangent_manifest = _build_tangent_candidate_states(
            receiver_states=local_states,
            anchor_states={
                "Local": local_states,
                "Geo": fedgeo_states,
            },
            source_states={
                "FAM": fam_states,
                "BankTop1": bank_top1_states,
            },
            alphas=tangent_alphas,
            rank=config.rank,
        )
        for row in tangent_manifest:
            row["source_client_id"] = (
                bank_top1_donors[int(row["client_id"])] if row["source"] == "BankTop1" else "weighted_bank"
            )
        tangent_method_states = dict(method_states)
        tangent_method_states.update(tangent_candidates)

    selective_states, selection_rows = _select_by_calibration(
        model=model,
        modules=lora_modules,
        preprocess=preprocess,
        text_features=text_features,
        clients=clients,
        method_states=method_states,
        class_names=class_names,
        device=device,
        batch_size=config.batch_size,
        Image=Image,
        torch=torch,
    )
    method_states["FedAdapterManifold-Selective-CLIP-LoRA"] = selective_states

    if config.tangent_admission:
        tangent_states, tangent_selection_rows = _select_tangent_by_calibration(
            model=model,
            modules=lora_modules,
            preprocess=preprocess,
            text_features=text_features,
            clients=clients,
            method_states=tangent_method_states,
            class_names=class_names,
            device=device,
            batch_size=config.batch_size,
            min_loss_gain=config.tangent_min_loss_gain,
            accuracy_tolerance=config.tangent_accuracy_tolerance,
            Image=Image,
            torch=torch,
        )
        method_states["FedAdapterManifold-Tangent-Admit-CLIP-LoRA"] = tangent_states
        selection_rows.extend(tangent_selection_rows)

    if config.tangent_certified:
        certified_states, certified_rows = _select_tangent_certified(
            model=model,
            modules=lora_modules,
            preprocess=preprocess,
            text_features=text_features,
            clients=clients,
            method_states=tangent_method_states,
            class_names=class_names,
            device=device,
            batch_size=config.batch_size,
            certificate_alpha=config.tangent_certificate_alpha,
            Image=Image,
            torch=torch,
        )
        method_states["FedAdapterManifold-Tangent-Certified-CLIP-LoRA"] = certified_states
        selection_rows.extend(certified_rows)

    per_client_rows: list[dict] = []
    for method, states in method_states.items():
        for client_index, client in enumerate(clients):
            set_lora_state(lora_modules, states[client_index], device=device, torch=torch)
            metrics = _evaluate(
                model=model,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["test"],
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                Image=Image,
                torch=torch,
            )
            per_client_rows.append(
                {
                    "method": method,
                    "seed": config.seed,
                    "dataset": config.dataset,
                    "heterogeneity": config.domains,
                    "round": config.communication_rounds - 1,
                    "geometry_round": config.round_id,
                    "client_id": client["client_id"],
                    "domain": client["domain"],
                    "accuracy": metrics["accuracy"],
                    "loss": metrics["loss"],
                    "num_samples": metrics["num_samples"],
                    "geometry_provider": geometry_provider,
                }
            )

    routing_rows: list[dict] = []
    mode_tangent_rows: list[dict] = []
    utility_tangent_rows: list[dict] = []
    if config.prototype_bank_routing:
        set_lora_state(lora_modules, zero_state, device=device, torch=torch)
        prototypes, prototype_mask = _compute_client_class_prototypes(
            model=model,
            preprocess=preprocess,
            clients=clients,
            class_names=class_names,
            device=device,
            batch_size=config.batch_size,
            Image=Image,
            torch=torch,
        )
        for client_idx, client in enumerate(clients):
            calibration_routes, calibration_route_rows = _prototype_routes(
                model=model,
                modules=lora_modules,
                zero_state=zero_state,
                preprocess=preprocess,
                samples=client["calibration"],
                prototypes=prototypes,
                prototype_mask=prototype_mask,
                receiver_idx=client_idx,
                compatibility_weights=fam_weights,
                prior_weight=config.routing_prior_weight,
                exclude_self=config.prototype_routing_exclude_self,
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                split="calibration",
                Image=Image,
                torch=torch,
            )
            test_routes, test_route_rows = _prototype_routes(
                model=model,
                modules=lora_modules,
                zero_state=zero_state,
                preprocess=preprocess,
                samples=client["test"],
                prototypes=prototypes,
                prototype_mask=prototype_mask,
                receiver_idx=client_idx,
                compatibility_weights=fam_weights,
                prior_weight=config.routing_prior_weight,
                exclude_self=config.prototype_routing_exclude_self,
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                split="test",
                Image=Image,
                torch=torch,
            )
            raw_calibration = _evaluate_adapter_routes(
                model=model,
                modules=lora_modules,
                local_states=local_states,
                routes=calibration_routes,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["calibration"],
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                Image=Image,
                torch=torch,
            )
            raw_test = _evaluate_adapter_routes(
                model=model,
                modules=lora_modules,
                local_states=local_states,
                routes=test_routes,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["test"],
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                Image=Image,
                torch=torch,
            )
            set_lora_state(lora_modules, local_states[client_idx], device=device, torch=torch)
            local_calibration = _evaluate_detailed(
                model=model,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["calibration"],
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                Image=Image,
                torch=torch,
            )
            local_test = _evaluate_detailed(
                model=model,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["test"],
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                Image=Image,
                torch=torch,
            )
            beneficial, harmful = _paired_discordance_counts(
                local_calibration["correctness"], raw_calibration["correctness"]
            )
            p_value = _exact_one_sided_discordance_p(beneficial=beneficial, harmful=harmful)
            certified = bool(
                raw_calibration["accuracy"] > local_calibration["accuracy"]
                and raw_calibration["loss"] < local_calibration["loss"]
                and p_value <= float(config.tangent_certificate_alpha)
            )
            safe_test = raw_test if certified else local_test
            for method, metrics in [
                ("FedAdapterManifold-PrototypeBank-Raw-CLIP-LoRA", raw_test),
                ("FedAdapterManifold-PrototypeBank-Certified-CLIP-LoRA", safe_test),
            ]:
                per_client_rows.append(
                    {
                        "method": method,
                        "seed": config.seed,
                        "dataset": config.dataset,
                        "heterogeneity": config.domains,
                        "round": config.communication_rounds - 1,
                        "geometry_round": config.round_id,
                        "client_id": client["client_id"],
                        "domain": client["domain"],
                        "accuracy": metrics["accuracy"],
                        "loss": metrics["loss"],
                        "num_samples": metrics["num_samples"],
                        "geometry_provider": geometry_provider,
                    }
                )
            for row in calibration_route_rows + test_route_rows:
                row.update(
                    {
                        "client_id": client["client_id"],
                        "domain": client["domain"],
                        "calibration_raw_accuracy": raw_calibration["accuracy"],
                        "calibration_local_accuracy": local_calibration["accuracy"],
                        "calibration_raw_loss": raw_calibration["loss"],
                        "calibration_local_loss": local_calibration["loss"],
                        "beneficial_discordances": beneficial,
                        "harmful_discordances": harmful,
                        "one_sided_exact_p": p_value,
                        "certified": certified,
                    }
                )
            routing_rows.extend(calibration_route_rows + test_route_rows)

    if config.mode_tangent_routing:
        mode_alphas = _parse_tangent_alphas(config.mode_tangent_alphas)
        if config.mode_tangent_screen_accuracy_tolerance < 0.0:
            raise ValueError("mode tangent screen accuracy tolerance must be non-negative")
        if not 0.0 < config.mode_tangent_certificate_alpha < 1.0:
            raise ValueError("mode tangent certificate alpha must be in (0, 1)")
        set_lora_state(lora_modules, zero_state, device=device, torch=torch)
        prototypes, prototype_mask = _compute_client_class_prototypes(
            model=model,
            preprocess=preprocess,
            clients=clients,
            class_names=class_names,
            device=device,
            batch_size=config.batch_size,
            Image=Image,
            torch=torch,
        )
        for client_idx, client in enumerate(clients):
            routes_by_split: dict[str, list[int]] = {}
            route_rows_by_split: dict[str, list[dict]] = {}
            for split, samples in [
                ("screen", client["train"]),
                ("calibration", client["calibration"]),
                ("test", client["test"]),
            ]:
                routes, rows = _prototype_routes(
                    model=model,
                    modules=lora_modules,
                    zero_state=zero_state,
                    preprocess=preprocess,
                    samples=samples,
                    prototypes=prototypes,
                    prototype_mask=prototype_mask,
                    receiver_idx=client_idx,
                    compatibility_weights=fam_weights,
                    prior_weight=config.routing_prior_weight,
                    exclude_self=False,
                    class_names=class_names,
                    device=device,
                    batch_size=config.batch_size,
                    split=split,
                    Image=Image,
                    torch=torch,
                )
                routes_by_split[split] = routes
                route_rows_by_split[split] = rows

            local_details: dict[str, dict] = {}
            set_lora_state(
                lora_modules, local_states[client_idx], device=device, torch=torch
            )
            for split, samples in [
                ("screen", client["train"]),
                ("calibration", client["calibration"]),
                ("test", client["test"]),
            ]:
                local_details[split] = _evaluate_detailed(
                    model=model,
                    preprocess=preprocess,
                    text_features=text_features,
                    samples=samples,
                    class_names=class_names,
                    device=device,
                    batch_size=config.batch_size,
                    Image=Image,
                    torch=torch,
                )

            screen_candidates: list[dict] = []
            routed_states_by_alpha: dict[float, list[list[dict[str, np.ndarray]]]] = {}
            for alpha in mode_alphas:
                routed_states, tangent_diagnostics = _receiver_mode_tangent_states(
                    local_states=local_states,
                    receiver_idx=client_idx,
                    alpha=alpha,
                    rank=config.rank,
                )
                routed_states_by_alpha[alpha] = routed_states
                details = _evaluate_adapter_routes(
                    model=model,
                    modules=lora_modules,
                    local_states=routed_states,
                    routes=routes_by_split["screen"],
                    preprocess=preprocess,
                    text_features=text_features,
                    samples=client["train"],
                    class_names=class_names,
                    device=device,
                    batch_size=config.batch_size,
                    Image=Image,
                    torch=torch,
                )
                external_fraction = float(
                    np.mean(np.asarray(routes_by_split["screen"]) != client_idx)
                )
                eligible = bool(
                    details["loss"] < local_details["screen"]["loss"] - 1e-12
                    and details["accuracy"]
                    >= local_details["screen"]["accuracy"]
                    - config.mode_tangent_screen_accuracy_tolerance
                    - 1e-12
                    and external_fraction > 0.0
                )
                screen_candidates.append(
                    {
                        "alpha": alpha,
                        "screen_accuracy": details["accuracy"],
                        "screen_loss": details["loss"],
                        "screen_accuracy_gain_vs_local": details["accuracy"]
                        - local_details["screen"]["accuracy"],
                        "screen_loss_gain_vs_local": local_details["screen"]["loss"]
                        - details["loss"],
                        "screen_external_fraction": external_fraction,
                        "screen_eligible": eligible,
                        "mean_tangent_energy_ratio": float(
                            np.mean(
                                [
                                    item["tangent_energy_ratio"]
                                    for donor_idx, item in enumerate(tangent_diagnostics)
                                    if donor_idx != client_idx
                                ]
                            )
                        ),
                    }
                )

            selected = _select_loss_first_mode_tangent(screen_candidates)
            selected_alpha = float(selected["alpha"])
            selected_states = routed_states_by_alpha[selected_alpha]
            routed_calibration = _evaluate_adapter_routes(
                model=model,
                modules=lora_modules,
                local_states=selected_states,
                routes=routes_by_split["calibration"],
                preprocess=preprocess,
                text_features=text_features,
                samples=client["calibration"],
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                Image=Image,
                torch=torch,
            )
            routed_test = _evaluate_adapter_routes(
                model=model,
                modules=lora_modules,
                local_states=selected_states,
                routes=routes_by_split["test"],
                preprocess=preprocess,
                text_features=text_features,
                samples=client["test"],
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                Image=Image,
                torch=torch,
            )
            certificate = _paired_candidate_certificate(
                local_details["calibration"],
                routed_calibration,
                config.mode_tangent_certificate_alpha,
            )
            certified = bool(certificate["certified"])
            safe_test = routed_test if certified else local_details["test"]
            for method, metrics in [
                ("FedAdapterManifold-ModeTangent-Raw-CLIP-LoRA", routed_test),
                ("FedAdapterManifold-ModeTangent-Certified-CLIP-LoRA", safe_test),
            ]:
                per_client_rows.append(
                    {
                        "method": method,
                        "seed": config.seed,
                        "dataset": config.dataset,
                        "heterogeneity": config.domains,
                        "round": config.communication_rounds - 1,
                        "geometry_round": config.round_id,
                        "client_id": client["client_id"],
                        "domain": client["domain"],
                        "accuracy": metrics["accuracy"],
                        "loss": metrics["loss"],
                        "num_samples": metrics["num_samples"],
                        "geometry_provider": geometry_provider,
                    }
                )

            for candidate in screen_candidates:
                mode_tangent_rows.append(
                    {
                        "selection_protocol": "mode_tangent_loss_first_exact_v1",
                        "seed": config.seed,
                        "client_id": client["client_id"],
                        "domain": client["domain"],
                        **candidate,
                        "selected_alpha": selected_alpha,
                        "selected": float(candidate["alpha"]) == selected_alpha,
                        "calibration_accuracy": routed_calibration["accuracy"]
                        if float(candidate["alpha"]) == selected_alpha
                        else "",
                        "calibration_loss": routed_calibration["loss"]
                        if float(candidate["alpha"]) == selected_alpha
                        else "",
                        "local_calibration_accuracy": local_details["calibration"][
                            "accuracy"
                        ]
                        if float(candidate["alpha"]) == selected_alpha
                        else "",
                        "local_calibration_loss": local_details["calibration"]["loss"]
                        if float(candidate["alpha"]) == selected_alpha
                        else "",
                        "beneficial_discordances": certificate["beneficial"]
                        if float(candidate["alpha"]) == selected_alpha
                        else "",
                        "harmful_discordances": certificate["harmful"]
                        if float(candidate["alpha"]) == selected_alpha
                        else "",
                        "one_sided_exact_p": certificate["p_value"]
                        if float(candidate["alpha"]) == selected_alpha
                        else "",
                        "certificate_alpha": config.mode_tangent_certificate_alpha,
                        "certified": certified
                        if float(candidate["alpha"]) == selected_alpha
                        else False,
                        "calibration_external_fraction": float(
                            np.mean(
                                np.asarray(routes_by_split["calibration"])
                                != client_idx
                            )
                        ),
                        "test_external_fraction": float(
                            np.mean(np.asarray(routes_by_split["test"]) != client_idx)
                        ),
                        "deployed_method": "ModeTangent-Raw"
                        if certified
                        else "Local-CLIP-LoRA",
                    }
                )
            for split_rows in route_rows_by_split.values():
                for row in split_rows:
                    row.update(
                        {
                            "selection_protocol": "mode_tangent_loss_first_exact_v1",
                            "seed": config.seed,
                            "client_id": client["client_id"],
                            "domain": client["domain"],
                            "selected_alpha": selected_alpha,
                            "certified": certified,
                        }
                    )
                mode_tangent_rows.extend(split_rows)

    if config.utility_tangent_routing:
        utility_alphas = _parse_utility_tangent_alphas(
            config.utility_tangent_alphas
        )
        if config.utility_tangent_modes < 1:
            raise ValueError("utility tangent modes must be positive")
        if config.utility_tangent_min_mode_samples < 1:
            raise ValueError("utility tangent minimum mode samples must be positive")
        if config.utility_tangent_screen_accuracy_tolerance < 0.0:
            raise ValueError("utility tangent accuracy tolerance must be non-negative")
        if not 0.0 < config.utility_tangent_certificate_alpha < 1.0:
            raise ValueError("utility tangent certificate alpha must be in (0, 1)")

        set_lora_state(lora_modules, zero_state, device=device, torch=torch)
        utility_prototypes, utility_prototype_mask = _compute_client_class_prototypes(
            model=model,
            preprocess=preprocess,
            clients=clients,
            class_names=class_names,
            device=device,
            batch_size=config.batch_size,
            Image=Image,
            torch=torch,
        )
        for client_idx, client in enumerate(clients):
            set_lora_state(lora_modules, zero_state, device=device, torch=torch)
            split_features = {
                split: _encode_image_features(
                    model=model,
                    preprocess=preprocess,
                    samples=samples,
                    class_names=class_names,
                    device=device,
                    batch_size=config.batch_size,
                    Image=Image,
                    torch=torch,
                )
                for split, samples in [
                    ("screen", client["train"]),
                    ("calibration", client["calibration"]),
                    ("test", client["test"]),
                ]
            }
            screen_labels = [
                class_names.index(sample["label"]) for sample in client["train"]
            ]
            crossfit_prototypes, crossfit_masks, screen_folds = (
                _crossfit_class_prototypes(
                    split_features["screen"], screen_labels, len(class_names)
                )
            )
            class_to_mode, mode_centroids = _deterministic_semantic_modes(
                utility_prototypes[client_idx],
                utility_prototype_mask[client_idx],
                num_modes=config.utility_tangent_modes,
            )
            split_modes: dict[str, list[int]] = {}
            split_classes: dict[str, list[int]] = {}
            split_similarities: dict[str, list[float]] = {}
            screen_modes = [-1] * len(client["train"])
            screen_classes = [-1] * len(client["train"])
            screen_similarities = [float("nan")] * len(client["train"])
            for held_out_fold in range(2):
                indices = np.flatnonzero(screen_folds == held_out_fold)
                modes, classes, similarities = _semantic_mode_assignments(
                    split_features["screen"][indices],
                    crossfit_prototypes[held_out_fold],
                    crossfit_masks[held_out_fold],
                    class_to_mode,
                )
                for offset, sample_idx in enumerate(indices):
                    screen_modes[int(sample_idx)] = int(modes[offset])
                    screen_classes[int(sample_idx)] = int(classes[offset])
                    screen_similarities[int(sample_idx)] = float(similarities[offset])
            split_modes["screen"] = screen_modes
            split_classes["screen"] = screen_classes
            split_similarities["screen"] = screen_similarities
            for split in ["calibration", "test"]:
                modes, classes, similarities = _semantic_mode_assignments(
                    split_features[split],
                    utility_prototypes[client_idx],
                    utility_prototype_mask[client_idx],
                    class_to_mode,
                )
                split_modes[split] = modes
                split_classes[split] = classes
                split_similarities[split] = similarities

            local_details: dict[str, dict] = {}
            set_lora_state(
                lora_modules, local_states[client_idx], device=device, torch=torch
            )
            for split, samples in [
                ("screen", client["train"]),
                ("calibration", client["calibration"]),
                ("test", client["test"]),
            ]:
                local_details[split] = _evaluate_detailed(
                    model=model,
                    preprocess=preprocess,
                    text_features=text_features,
                    samples=samples,
                    class_names=class_names,
                    device=device,
                    batch_size=config.batch_size,
                    Image=Image,
                    torch=torch,
                )

            supported_donors = [
                donor_idx
                for donor_idx in range(len(clients))
                if donor_idx != client_idx and float(fam_weights[client_idx, donor_idx]) > 0.0
            ]
            candidate_states: dict[tuple[int, float], list[dict[str, np.ndarray]]] = {}
            candidate_details: dict[tuple[int, float], dict] = {}
            candidate_diagnostics: dict[tuple[int, float], dict] = {}
            for alpha in utility_alphas:
                states, diagnostics = _receiver_mode_tangent_states(
                    local_states=local_states,
                    receiver_idx=client_idx,
                    alpha=alpha,
                    rank=config.rank,
                )
                for donor_idx in supported_donors:
                    key = (int(donor_idx), float(alpha))
                    candidate_states[key] = states[donor_idx]
                    candidate_diagnostics[key] = diagnostics[donor_idx]
                    set_lora_state(
                        lora_modules, states[donor_idx], device=device, torch=torch
                    )
                    candidate_details[key] = _evaluate_detailed(
                        model=model,
                        preprocess=preprocess,
                        text_features=text_features,
                        samples=client["train"],
                        class_names=class_names,
                        device=device,
                        batch_size=config.batch_size,
                        Image=Image,
                        torch=torch,
                    )

            utility_rule, utility_rows = _fit_mode_utility_rule(
                mode_ids=split_modes["screen"],
                local_details=local_details["screen"],
                candidate_details=candidate_details,
                min_mode_samples=config.utility_tangent_min_mode_samples,
                accuracy_tolerance=config.utility_tangent_screen_accuracy_tolerance,
            )
            selected_keys = sorted(
                {
                    (int(item["donor_client_id"]), float(item["alpha"]))
                    for item in utility_rule.values()
                }
            )
            state_bank = [_copy_lora_state(local_states[client_idx])] + [
                candidate_states[key] for key in selected_keys
            ]
            state_index = {key: index + 1 for index, key in enumerate(selected_keys)}
            routes_by_split = {
                split: _utility_state_routes(modes, utility_rule, state_index)
                for split, modes in split_modes.items()
            }
            routed_details = {
                split: _evaluate_adapter_routes(
                    model=model,
                    modules=lora_modules,
                    local_states=state_bank,
                    routes=routes_by_split[split],
                    preprocess=preprocess,
                    text_features=text_features,
                    samples=samples,
                    class_names=class_names,
                    device=device,
                    batch_size=config.batch_size,
                    Image=Image,
                    torch=torch,
                )
                for split, samples in [
                    ("screen", client["train"]),
                    ("calibration", client["calibration"]),
                    ("test", client["test"]),
                ]
            }
            certificate = _paired_dual_risk_certificate(
                local_details["calibration"],
                routed_details["calibration"],
                config.utility_tangent_certificate_alpha,
            )
            certified = bool(certificate["certified"])
            safe_test = (
                routed_details["test"] if certified else local_details["test"]
            )
            for method, metrics in [
                ("FedAdapterManifold-UtilityTangent-Raw-CLIP-LoRA", routed_details["test"]),
                ("FedAdapterManifold-UtilityTangent-Certified-CLIP-LoRA", safe_test),
            ]:
                per_client_rows.append(
                    {
                        "method": method,
                        "seed": config.seed,
                        "dataset": config.dataset,
                        "heterogeneity": config.domains,
                        "round": config.communication_rounds - 1,
                        "geometry_round": config.round_id,
                        "client_id": client["client_id"],
                        "domain": client["domain"],
                        "accuracy": metrics["accuracy"],
                        "loss": metrics["loss"],
                        "num_samples": metrics["num_samples"],
                        "geometry_provider": geometry_provider,
                    }
                )

            for row in utility_rows:
                key = (int(row["donor_client_id"]), float(row["alpha"]))
                row.update(
                    {
                        "record_type": "mode_candidate",
                        "selection_protocol": "crossfit_utility_tangent_exact_v1",
                        "seed": config.seed,
                        "client_id": client["client_id"],
                        "domain": client["domain"],
                        "compatibility_weight": float(
                            fam_weights[client_idx, int(row["donor_client_id"])]
                        ),
                        "tangent_energy_ratio": float(
                            candidate_diagnostics[key]["tangent_energy_ratio"]
                        ),
                    }
                )
                utility_tangent_rows.append(row)
            utility_tangent_rows.append(
                {
                    "record_type": "receiver_summary",
                    "selection_protocol": "crossfit_utility_tangent_exact_v1",
                    "seed": config.seed,
                    "client_id": client["client_id"],
                    "domain": client["domain"],
                    "num_semantic_modes": int(mode_centroids.shape[0]),
                    "selected_external_modes": len(utility_rule),
                    "screen_accuracy": routed_details["screen"]["accuracy"],
                    "screen_loss": routed_details["screen"]["loss"],
                    "local_screen_accuracy": local_details["screen"]["accuracy"],
                    "local_screen_loss": local_details["screen"]["loss"],
                    "calibration_accuracy": routed_details["calibration"]["accuracy"],
                    "calibration_loss": routed_details["calibration"]["loss"],
                    "local_calibration_accuracy": local_details["calibration"]["accuracy"],
                    "local_calibration_loss": local_details["calibration"]["loss"],
                    "beneficial_discordances": certificate["beneficial"],
                    "harmful_discordances": certificate["harmful"],
                    "one_sided_exact_p": certificate["p_value"],
                    "loss_beneficial_pairs": certificate["loss_beneficial"],
                    "loss_harmful_pairs": certificate["loss_harmful"],
                    "loss_one_sided_exact_p": certificate["loss_p_value"],
                    "accuracy_certified": certificate["accuracy_certified"],
                    "loss_certified": certificate["loss_certified"],
                    "certificate_basis": certificate["certificate_basis"],
                    "certificate_alpha": config.utility_tangent_certificate_alpha,
                    "certified": certified,
                    "deployed_method": "UtilityTangent-Raw"
                    if certified
                    else "Local-CLIP-LoRA",
                }
            )
            for split in ["screen", "calibration", "test"]:
                for sample_idx, (mode_idx, class_idx, similarity, state_route) in enumerate(
                    zip(
                        split_modes[split],
                        split_classes[split],
                        split_similarities[split],
                        routes_by_split[split],
                    )
                ):
                    item = utility_rule.get(int(mode_idx))
                    utility_tangent_rows.append(
                        {
                            "record_type": "route",
                            "selection_protocol": "crossfit_utility_tangent_exact_v1",
                            "seed": config.seed,
                            "client_id": client["client_id"],
                            "domain": client["domain"],
                            "split": split,
                            "sample_index": sample_idx,
                            "semantic_mode_id": int(mode_idx),
                            "prototype_class_id": int(class_idx),
                            "prototype_class": class_names[int(class_idx)]
                            if int(class_idx) >= 0
                            else "",
                            "prototype_cosine": float(similarity),
                            "receiver_client_id": client_idx,
                            "donor_client_id": int(item["donor_client_id"])
                            if item is not None
                            else client_idx,
                            "alpha": float(item["alpha"]) if item is not None else 0.0,
                            "state_route": int(state_route),
                            "external_route": item is not None,
                            "cross_fitted_prototype": split == "screen",
                            "certified": certified,
                        }
                    )

    local_acc = {
        int(row["client_id"]): float(row["accuracy"])
        for row in per_client_rows
        if row["method"] == "Local-CLIP-LoRA"
    }
    for row in per_client_rows:
        cid = int(row["client_id"])
        row["accuracy_drop_vs_local"] = local_acc.get(cid, float("nan")) - float(row["accuracy"])
        row["update_conflict_vs_local"] = max(0.0, row["accuracy_drop_vs_local"])
        row["client_risk"] = 1.0 - float(row["accuracy"])

    metrics_rows = _aggregate_metrics(per_client_rows, config)
    subspace_rows = _subspace_failure_rows(
        model=model,
        modules=lora_modules,
        preprocess=preprocess,
        text_features=text_features,
        clients=clients,
        local_states=local_states,
        local_acc=local_acc,
        d_sub=d_sub,
        d_geo=d_geo,
        class_names=class_names,
        device=device,
        batch_size=config.batch_size,
        rank=config.rank,
        Image=Image,
        torch=torch,
    )
    conflict_rows = _conflict_rows(metrics_rows)
    bank_rows = _weight_rows(clients, "FedGeo-Agg-CLIP-LoRA", geo_weights) + _weight_rows(
        clients, "FedAdapterManifold-CLIP-LoRA", fam_weights
    )

    _write_csv(output_dir / "metrics.csv", metrics_rows)
    _write_csv(output_dir / "per_client_metrics.csv", per_client_rows)
    _write_csv(output_dir / "subspace_metrics.csv", subspace_rows)
    _write_csv(output_dir / "adapter_conflict.csv", conflict_rows)
    _write_csv(output_dir / "adapter_bank_weights.csv", bank_rows)
    _write_csv(output_dir / "candidate_selection.csv", selection_rows)
    _write_csv(output_dir / "tangent_candidate_manifest.csv", tangent_manifest)
    _write_csv(output_dir / "prototype_bank_routing.csv", routing_rows)
    _write_csv(output_dir / "mode_tangent_routing.csv", mode_tangent_rows)
    _write_csv(output_dir / "utility_tangent_routing.csv", utility_tangent_rows)
    _write_csv(output_dir / "source_coverage.csv", source_coverage_rows)
    _write_csv(output_dir / "source_coverage_donors.csv", source_coverage_donor_rows)
    _write_csv(output_dir / "training_history.csv", train_history)
    np.save(output_dir / "routing_subspace_distance.npy", routing_d_sub)
    _write_config(output_dir / "config.yaml", config, class_names, geometry_provider, clients, prompt_labels)
    _write_report(output_dir / "run_report.md", metrics_rows, subspace_rows)
    _write_run_provenance(
        output_dir / "run_provenance.json",
        config=config,
        clients=clients,
        data_root=data_root,
        geometry_provider=geometry_provider,
        torch=torch,
    )
    set_lora_state(lora_modules, zero_state, device=device, torch=torch)
    return 0


def inject_visual_attention_lora(model, rank: int, blocks: int, torch, nn, F):
    resblocks = model.visual.transformer.resblocks
    modules = []
    for idx in range(len(resblocks) - max(1, blocks), len(resblocks)):
        base_attn = resblocks[idx].attn
        wrapped = LoRAMultiheadAttention(base_attn, rank=rank, torch=torch, nn=nn, F=F)
        resblocks[idx].attn = wrapped
        modules.append(wrapped)
    return modules


class LoRAMultiheadAttention:
    def __new__(cls, base_attn, rank: int, torch, nn, F):
        class _Wrapped(nn.Module):
            def __init__(self):
                super().__init__()
                self.base = base_attn
                self.rank = int(rank)
                self.scale = 1.0 / max(1, self.rank)
                embed_dim = int(base_attn.embed_dim)
                self.embed_dim = embed_dim
                self.lora_a = nn.Parameter(torch.empty(self.rank, embed_dim))
                self.lora_b = nn.Parameter(torch.zeros(3 * embed_dim, self.rank))
                nn.init.kaiming_uniform_(self.lora_a, a=5**0.5)
                for param in self.base.parameters():
                    param.requires_grad_(False)

            def forward(self, query, key, value, key_padding_mask=None, need_weights=True, attn_mask=None):
                delta = (self.lora_b @ self.lora_a) * self.scale
                if getattr(self, "capture_delta_grad", False):
                    delta.retain_grad()
                    self.captured_delta = delta
                in_proj_weight = self.base.in_proj_weight + delta.to(dtype=self.base.in_proj_weight.dtype)
                return F.multi_head_attention_forward(
                    query,
                    key,
                    value,
                    self.base.embed_dim,
                    self.base.num_heads,
                    in_proj_weight,
                    self.base.in_proj_bias,
                    self.base.bias_k,
                    self.base.bias_v,
                    self.base.add_zero_attn,
                    self.base.dropout,
                    self.base.out_proj.weight,
                    self.base.out_proj.bias,
                    self.training,
                    key_padding_mask,
                    need_weights,
                    attn_mask,
                    use_separate_proj_weight=False,
                    average_attn_weights=True,
                )

        return _Wrapped()


def _select_classes(data_root: Path, domains: list[str], limit: int) -> list[str]:
    shared: set[str] | None = None
    for domain in domains:
        class_dir = data_root / domain / "train"
        names = {path.name for path in class_dir.iterdir() if path.is_dir()} if class_dir.exists() else set()
        shared = names if shared is None else shared & names
    return sorted(shared or [])[: max(1, int(limit))]


def _build_clients(
    data_root: Path,
    domains: list[str],
    class_names: list[str],
    train_per_class: int,
    test_per_class: int,
    calibration_fraction: float,
    seed: int,
) -> list[dict]:
    clients = []
    for client_id, domain in enumerate(domains):
        train_all = _collect_domain_samples(data_root, domain, class_names, "train", train_per_class, seed + client_id * 13)
        test = _collect_domain_samples(data_root, domain, class_names, "test", test_per_class, seed + 1000 + client_id * 13)
        train, calibration = _split_train_calibration(train_all, calibration_fraction, seed + 2000 + client_id)
        if not calibration:
            calibration = train[:]
        clients.append(
            {
                "client_id": client_id,
                "domain": domain,
                "train": train,
                "calibration": calibration,
                "test": test,
                "num_train": len(train),
                "num_calibration": len(calibration),
                "num_test": len(test),
            }
        )
    return clients


def _collect_domain_samples(
    data_root: Path,
    domain: str,
    class_names: list[str],
    split: str,
    per_class: int,
    seed: int,
) -> list[dict[str, str]]:
    rng = random.Random(seed)
    samples: list[dict[str, str]] = []
    for label in class_names:
        folder = data_root / domain / split / label
        files = sorted(path for path in folder.glob("*") if path.suffix.lower() in IMAGE_SUFFIXES)
        rng.shuffle(files)
        for path in files[: max(1, per_class)]:
            samples.append({"path": str(path), "label": label, "domain": domain})
    rng.shuffle(samples)
    return samples


def _split_train_calibration(samples: list[dict[str, str]], fraction: float, seed: int) -> tuple[list[dict], list[dict]]:
    if not samples:
        return [], []
    by_label: dict[str, list[dict]] = {}
    for sample in samples:
        by_label.setdefault(sample["label"], []).append(sample)
    rng = random.Random(seed)
    train: list[dict] = []
    calibration: list[dict] = []
    for label_samples in by_label.values():
        items = label_samples[:]
        rng.shuffle(items)
        cal_count = int(round(len(items) * max(0.0, min(0.9, fraction))))
        if len(items) > 1:
            cal_count = max(1, min(len(items) - 1, cal_count))
        calibration.extend(items[:cal_count])
        train.extend(items[cal_count:])
    rng.shuffle(train)
    rng.shuffle(calibration)
    return train, calibration


def _text_features(model, clip, class_names: list[str], template: str, device: str, torch):
    prompts = [template.format(label=name.replace("_", " ")) for name in class_names]
    with torch.no_grad():
        tokens = clip.tokenize(prompts, truncate=True).to(device)
        features = model.encode_text(tokens).float()
        return features / features.norm(dim=-1, keepdim=True).clamp_min(1e-12)


def _prompt_labels(class_names: list[str], class_labels: str, class_label_map: str = "") -> list[str]:
    if class_labels.strip() and class_label_map.strip():
        raise ValueError("Use only one of --class-labels and --class-label-map.")

    if class_label_map.strip():
        map_path = Path(class_label_map).expanduser()
        if not map_path.is_absolute():
            map_path = (Path.cwd() / map_path).resolve()
        with map_path.open("r", encoding="utf-8") as handle:
            mapping = json.load(handle)
        if not isinstance(mapping, dict):
            raise ValueError("--class-label-map must contain a JSON object keyed by class-folder identifier.")
        missing = [name for name in class_names if name not in mapping]
        if missing:
            raise ValueError(f"--class-label-map is missing {len(missing)} selected classes: {missing[:5]}")
        labels = [str(mapping[name]).strip() for name in class_names]
        if any(not label for label in labels):
            raise ValueError("--class-label-map contains an empty semantic label.")
        return labels

    labels = [value.strip() for value in class_labels.split(",") if value.strip()]
    if not labels:
        if class_names and all(name.strip().isdigit() for name in class_names):
            raise ValueError(
                "All selected class folders are numeric. Provide --class-label-map or "
                "--class-labels so CLIP receives semantic object prompts."
            )
        return class_names
    if len(labels) != len(class_names):
        raise ValueError(f"--class-labels has {len(labels)} entries but {len(class_names)} classes were selected.")
    return labels


def _class_label_map_sha256(class_label_map: str) -> str:
    if not class_label_map.strip():
        return ""
    map_path = Path(class_label_map).expanduser()
    if not map_path.is_absolute():
        map_path = (Path.cwd() / map_path).resolve()
    return hashlib.sha256(map_path.read_bytes()).hexdigest()


def _train_client(
    model,
    modules,
    preprocess,
    text_features,
    samples,
    class_names,
    device,
    batch_size,
    epochs,
    lr,
    seed,
    initial_state,
    Image,
    torch,
    F,
) -> tuple[list[dict[str, np.ndarray]], list[dict]]:
    set_lora_state(modules, initial_state, device=device, torch=torch)
    trainable = [param for module in modules for param in module.parameters() if param.requires_grad]
    optimizer = torch.optim.AdamW(trainable, lr=lr)
    model.train()
    history: list[dict] = []
    rng = random.Random(seed)
    for epoch in range(max(1, epochs)):
        shuffled = samples[:]
        rng.shuffle(shuffled)
        losses: list[float] = []
        for batch in _batches(shuffled, batch_size):
            images, labels = _load_batch(batch, preprocess, class_names, device, Image, torch)
            optimizer.zero_grad(set_to_none=True)
            image_features = model.encode_image(images)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True).clamp_min(1e-12)
            logits = model.logit_scale.exp().float() * image_features.float() @ text_features.float().t()
            loss = F.cross_entropy(logits, labels)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, 1.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
        history.append({"epoch": epoch, "mean_train_loss": sum(losses) / max(1, len(losses))})
    model.eval()
    return get_lora_state(modules), history


def _evaluate(model, preprocess, text_features, samples, class_names, device, batch_size, Image, torch) -> dict[str, float]:
    details = _evaluate_detailed(
        model=model,
        preprocess=preprocess,
        text_features=text_features,
        samples=samples,
        class_names=class_names,
        device=device,
        batch_size=batch_size,
        Image=Image,
        torch=torch,
    )
    return {key: details[key] for key in ["accuracy", "loss", "num_samples"]}


def _evaluate_detailed(model, preprocess, text_features, samples, class_names, device, batch_size, Image, torch) -> dict:
    import torch.nn.functional as F

    model.eval()
    losses: list[float] = []
    correctness: list[int] = []
    true_margins: list[float] = []
    with torch.no_grad():
        for batch in _batches(samples, batch_size):
            images, labels = _load_batch(batch, preprocess, class_names, device, Image, torch)
            image_features = model.encode_image(images)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True).clamp_min(1e-12)
            logits = model.logit_scale.exp().float() * image_features.float() @ text_features.float().t()
            losses.extend(float(value) for value in F.cross_entropy(logits, labels, reduction="none").detach().cpu())
            correctness.extend(int(value) for value in (logits.argmax(dim=1) == labels).detach().cpu())
            true_logits = logits.gather(1, labels[:, None]).squeeze(1)
            competing = logits.clone()
            competing.scatter_(1, labels[:, None], float("-inf"))
            margins = true_logits - competing.max(dim=1).values
            true_margins.extend(float(value) for value in margins.detach().cpu())
    total = len(correctness)
    return {
        "accuracy": sum(correctness) / max(1, total),
        "loss": sum(losses) / max(1, len(losses)),
        "num_samples": total,
        "correctness": correctness,
        "sample_losses": losses,
        "true_margins": true_margins,
    }


def _lifted_delta_gradients(
    model,
    modules,
    preprocess,
    text_features,
    samples,
    class_names,
    device,
    batch_size,
    Image,
    torch,
    F,
) -> tuple[list[np.ndarray], float]:
    """Differentiate mean receiver loss with respect to lifted LoRA updates."""

    model.eval()
    gradients = [
        np.zeros((3 * int(module.embed_dim), int(module.embed_dim)), dtype=np.float64)
        for module in modules
    ]
    total_samples = max(1, len(samples))
    total_loss = 0.0
    for module in modules:
        module.capture_delta_grad = True
        module.captured_delta = None
    try:
        for batch in _batches(samples, batch_size):
            model.zero_grad(set_to_none=True)
            images, labels = _load_batch(batch, preprocess, class_names, device, Image, torch)
            image_features = model.encode_image(images)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True).clamp_min(1e-12)
            logits = model.logit_scale.exp().float() * image_features.float() @ text_features.float().t()
            batch_loss = F.cross_entropy(logits, labels, reduction="sum")
            total_loss += float(batch_loss.detach().cpu())
            (batch_loss / float(total_samples)).backward()
            for module_idx, module in enumerate(modules):
                captured = module.captured_delta
                if captured is None or captured.grad is None:
                    raise RuntimeError("failed to capture a lifted LoRA update gradient")
                gradients[module_idx] += np.asarray(captured.grad.detach().cpu(), dtype=np.float64)
                module.captured_delta = None
    finally:
        model.zero_grad(set_to_none=True)
        for module in modules:
            module.capture_delta_grad = False
            module.captured_delta = None
    return gradients, float(total_loss / total_samples)


def _audit_source_coverage(
    model,
    modules,
    preprocess,
    text_features,
    clients,
    local_states,
    fam_weights,
    class_names,
    device,
    batch_size,
    Image,
    torch,
    F,
    seed: int,
    dataset: str,
    communication_round: int,
) -> tuple[list[dict], list[dict]]:
    """Audit source-cone coverage without changing any deployed endpoint."""

    summary_rows: list[dict] = []
    donor_rows: list[dict] = []
    num_clients = len(clients)
    for receiver_idx, client in enumerate(clients):
        receiver_state = local_states[receiver_idx]
        set_lora_state(modules, receiver_state, device=device, torch=torch)
        split_gradients: dict[str, np.ndarray] = {}
        split_losses: dict[str, float] = {}
        for risk_split, samples in [
            ("adapter_training", client["train"]),
            ("outer_calibration", client["calibration"]),
        ]:
            lifted_gradients, risk_loss = _lifted_delta_gradients(
                model=model,
                modules=modules,
                preprocess=preprocess,
                text_features=text_features,
                samples=samples,
                class_names=class_names,
                device=device,
                batch_size=batch_size,
                Image=Image,
                torch=torch,
                F=F,
            )
            tangent_gradients = [
                _receiver_tangent_projection(gradient, receiver_item)
                for gradient, receiver_item in zip(lifted_gradients, receiver_state)
            ]
            split_gradients[risk_split] = np.concatenate(
                [value.reshape(-1) for value in tangent_gradients]
            )
            split_losses[risk_split] = risk_loss

        dictionary_specs = {
            "all_external": [index for index in range(num_clients) if index != receiver_idx],
            "graph_supported": [
                index
                for index in range(num_clients)
                if index != receiver_idx and float(fam_weights[receiver_idx, index]) > 1e-12
            ],
        }
        for dictionary_name, donor_indices in dictionary_specs.items():
            directions: list[np.ndarray] = []
            direction_norms: list[float] = []
            for donor_idx in donor_indices:
                module_directions: list[np.ndarray] = []
                for receiver_item, donor_item in zip(receiver_state, local_states[donor_idx]):
                    residual = _state_delta(donor_item) - _state_delta(receiver_item)
                    module_directions.append(_receiver_tangent_projection(residual, receiver_item))
                direction = np.concatenate([value.reshape(-1) for value in module_directions])
                directions.append(direction)
                direction_norms.append(float(np.linalg.norm(direction)))
            direction_matrix = (
                np.stack(directions, axis=0)
                if directions
                else np.zeros((0, split_gradients["adapter_training"].size), dtype=np.float64)
            )
            coverages = {
                risk_split: source_coverage(gradient, direction_matrix)
                for risk_split, gradient in split_gradients.items()
            }
            training_coverage = coverages["adapter_training"]
            calibration_gradient = split_gradients["outer_calibration"]
            calibration_gradient_norm = max(float(np.linalg.norm(calibration_gradient)), 1e-12)

            def transferred_descent_cosine(direction: np.ndarray) -> float:
                norm = float(np.linalg.norm(direction))
                if norm <= 1e-12:
                    return 0.0
                derivative = float(np.dot(calibration_gradient, direction / norm))
                return max(0.0, -derivative) / calibration_gradient_norm

            training_cone_calibration_cosine = transferred_descent_cosine(
                training_coverage.cone_projection
            )
            training_span_calibration_cosine = transferred_descent_cosine(
                training_coverage.span_projection
            )
            for risk_split, coverage in coverages.items():
                best_donor = (
                    int(donor_indices[coverage.best_source]) if coverage.best_source >= 0 else -1
                )
                summary_rows.append(
                    {
                        "seed": seed,
                        "dataset": dataset,
                        "round": communication_round,
                        "client_id": client["client_id"],
                        "domain": client["domain"],
                        "risk_split": risk_split,
                        "dictionary": dictionary_name,
                        "num_sources": len(donor_indices),
                        "risk_loss": split_losses[risk_split],
                        "tangent_gradient_norm": coverage.gradient_norm,
                        "gamma_atom": coverage.atom_coverage,
                        "gamma_cone": coverage.cone_coverage,
                        "gamma_span": coverage.span_coverage,
                        "multi_donor_gap": coverage.cone_coverage - coverage.atom_coverage,
                        "signed_span_gap": coverage.span_coverage - coverage.cone_coverage,
                        "uncovered_fraction": 1.0 - coverage.span_coverage,
                        "best_donor_client_id": best_donor,
                        "positive_single_sources": coverage.positive_sources,
                        "active_cone_sources": coverage.active_cone_sources,
                        "cone_projected_gradient_norm_sq": (
                            coverage.cone_coverage * coverage.gradient_norm
                        )
                        ** 2,
                        "training_cone_direction_calibration_cosine": training_cone_calibration_cosine,
                        "training_span_direction_calibration_cosine": training_span_calibration_cosine,
                        "selection_uses_test": False,
                        "changes_deployment": False,
                    }
                )
                for source_pos, donor_idx in enumerate(donor_indices):
                    derivative = float(coverage.directional_derivatives[source_pos])
                    descent_cosine = (
                        max(0.0, -derivative) / max(coverage.gradient_norm, 1e-12)
                    )
                    donor_rows.append(
                        {
                            "seed": seed,
                            "dataset": dataset,
                            "round": communication_round,
                            "receiver_client_id": client["client_id"],
                            "receiver_domain": client["domain"],
                            "risk_split": risk_split,
                            "donor_client_id": clients[donor_idx]["client_id"],
                            "donor_domain": clients[donor_idx]["domain"],
                            "dictionary": dictionary_name,
                            "direction_norm": direction_norms[source_pos],
                            "normalized_directional_derivative": derivative,
                            "descent_cosine": descent_cosine,
                            "cone_coefficient": float(coverage.cone_coefficients[source_pos]),
                            "is_best_atom": donor_idx == best_donor,
                        }
                    )
    return summary_rows, donor_rows


def _build_signed_span_candidate(
    model,
    modules,
    preprocess,
    text_features,
    client,
    clients,
    receiver_idx: int,
    local_states,
    class_names,
    device,
    batch_size,
    rank: int,
    Image,
    torch,
    F,
) -> tuple[list[dict[str, np.ndarray]], dict, np.ndarray]:
    """Construct one rank-aware signed-span candidate using training data only."""

    receiver_state = local_states[receiver_idx]
    set_lora_state(modules, receiver_state, device=device, torch=torch)
    lifted_gradients, _ = _lifted_delta_gradients(
        model=model,
        modules=modules,
        preprocess=preprocess,
        text_features=text_features,
        samples=client["train"],
        class_names=class_names,
        device=device,
        batch_size=batch_size,
        Image=Image,
        torch=torch,
        F=F,
    )
    tangent_gradient = np.concatenate(
        [
            _receiver_tangent_projection(gradient, receiver_item).reshape(-1)
            for gradient, receiver_item in zip(lifted_gradients, receiver_state)
        ]
    )
    donor_indices = [index for index in range(len(clients)) if index != receiver_idx]
    donor_directions: list[np.ndarray] = []
    for donor_idx in donor_indices:
        modules_for_donor = []
        for receiver_item, donor_item in zip(receiver_state, local_states[donor_idx]):
            residual = _state_delta(donor_item) - _state_delta(receiver_item)
            modules_for_donor.append(_receiver_tangent_projection(residual, receiver_item))
        donor_directions.append(np.concatenate([value.reshape(-1) for value in modules_for_donor]))
    direction_matrix = (
        np.stack(donor_directions, axis=0)
        if donor_directions
        else np.zeros((0, tangent_gradient.size), dtype=np.float64)
    )
    coverage = source_coverage(tangent_gradient, direction_matrix)
    span_direction = np.asarray(coverage.span_projection, dtype=np.float64)
    span_norm = float(np.linalg.norm(span_direction))
    donor_norms = np.asarray([np.linalg.norm(value) for value in donor_directions], dtype=np.float64)
    positive_norms = donor_norms[donor_norms > 1e-12]
    trust_radius = (
        float(np.sqrt(np.mean(positive_norms * positive_norms))) if positive_norms.size else 0.0
    )
    coefficient_l1 = float(np.sum(np.abs(coverage.span_coefficients)))
    coefficient_l2 = float(np.linalg.norm(coverage.span_coefficients))
    common = {
        "gamma_atom_train": coverage.atom_coverage,
        "gamma_cone_train": coverage.cone_coverage,
        "gamma_span_train": coverage.span_coverage,
        "span_projection_norm": span_norm,
        "trust_radius": trust_radius,
        "span_coefficient_l1": coefficient_l1,
        "span_coefficient_l2": coefficient_l2,
        "positive_span_coefficients": int(np.sum(coverage.span_coefficients > 1e-10)),
        "negative_span_coefficients": int(np.sum(coverage.span_coefficients < -1e-10)),
        "candidate_fixed_before_calibration": True,
    }
    if span_norm <= 1e-12 or trust_radius <= 1e-12:
        return _copy_lora_state(receiver_state), {
            **common,
            "constructed": False,
            "backtracking_steps": -1,
            "accepted_step": 0.0,
            "training_loss_gain": 0.0,
            "rank_projection_displacement": 0.0,
        }

    unit_direction = span_direction / span_norm
    module_shapes = [_state_delta(item).shape for item in receiver_state]
    module_sizes = [int(np.prod(shape)) for shape in module_shapes]
    offsets = np.cumsum([0, *module_sizes])
    module_directions = [
        unit_direction[offsets[index] : offsets[index + 1]].reshape(shape)
        for index, shape in enumerate(module_shapes)
    ]
    set_lora_state(modules, receiver_state, device=device, torch=torch)
    local_details = _evaluate_detailed(
        model, preprocess, text_features, client["train"], class_names,
        device, batch_size, Image, torch,
    )
    for backtracking_steps in range(17):
        step = trust_radius * (0.5 ** backtracking_steps)
        candidate_state: list[dict[str, np.ndarray]] = []
        unprojected: list[np.ndarray] = []
        projection_error_sq = 0.0
        for receiver_item, direction in zip(receiver_state, module_directions):
            candidate_delta = _state_delta(receiver_item) + step * direction
            projected = _project_delta_to_lora(
                candidate_delta,
                rank=rank,
                scale=float(receiver_item["scale"]),
            )
            candidate_state.append(projected)
            unprojected.append(candidate_delta)
            projection_error_sq += float(np.sum((_state_delta(projected) - candidate_delta) ** 2))
        set_lora_state(modules, candidate_state, device=device, torch=torch)
        candidate_details = _evaluate_detailed(
            model, preprocess, text_features, client["train"], class_names,
            device, batch_size, Image, torch,
        )
        gain = float(local_details["loss"] - candidate_details["loss"])
        if gain > 1e-8:
            return candidate_state, {
                **common,
                "constructed": True,
                "backtracking_steps": backtracking_steps,
                "accepted_step": step,
                "training_loss_gain": gain,
                "rank_projection_displacement": math.sqrt(max(0.0, projection_error_sq)),
            }
    return _copy_lora_state(receiver_state), {
        **common,
        "constructed": False,
        "backtracking_steps": 17,
        "accepted_step": 0.0,
        "training_loss_gain": 0.0,
        "rank_projection_displacement": 0.0,
    }


def _build_common_descent_candidate(
    model,
    modules,
    preprocess,
    text_features,
    client,
    clients,
    receiver_idx: int,
    local_states,
    class_names,
    device,
    batch_size,
    rank: int,
    split_seed: int,
    Image,
    torch,
    F,
) -> tuple[list[dict[str, np.ndarray]], dict]:
    """Construct a rank-aware donor-span direction that descends on both folds."""

    receiver_state = local_states[receiver_idx]
    fold_a, fold_b = _split_train_calibration(client["train"], 0.5, split_seed)
    folds = [fold_a, fold_b]
    if any(not fold for fold in folds):
        return _copy_lora_state(receiver_state), {
            "common_descent_feasible": False,
            "common_descent_margin": 0.0,
            "fold_gradient_cosine": 0.0,
            "fold_0_weight": 0.5,
            "fold_1_weight": 0.5,
            "fold_0_size": len(fold_a),
            "fold_1_size": len(fold_b),
            "trust_radius": 0.0,
            "constructed": False,
            "backtracking_steps": -1,
            "accepted_step": 0.0,
            "mean_fold_training_loss_gain": 0.0,
            "min_fold_training_loss_gain": 0.0,
            "rank_projection_displacement": 0.0,
            "candidate_fixed_before_calibration": True,
        }

    set_lora_state(modules, receiver_state, device=device, torch=torch)
    fold_tangent_gradients: list[np.ndarray] = []
    for fold in folds:
        lifted_gradients, _ = _lifted_delta_gradients(
            model=model,
            modules=modules,
            preprocess=preprocess,
            text_features=text_features,
            samples=fold,
            class_names=class_names,
            device=device,
            batch_size=batch_size,
            Image=Image,
            torch=torch,
            F=F,
        )
        fold_tangent_gradients.append(
            np.concatenate(
                [
                    _receiver_tangent_projection(gradient, receiver_item).reshape(-1)
                    for gradient, receiver_item in zip(lifted_gradients, receiver_state)
                ]
            )
        )

    donor_directions: list[np.ndarray] = []
    for donor_idx in range(len(clients)):
        if donor_idx == receiver_idx:
            continue
        modules_for_donor = []
        for receiver_item, donor_item in zip(receiver_state, local_states[donor_idx]):
            residual = _state_delta(donor_item) - _state_delta(receiver_item)
            modules_for_donor.append(_receiver_tangent_projection(residual, receiver_item))
        donor_directions.append(np.concatenate([value.reshape(-1) for value in modules_for_donor]))
    direction_matrix = (
        np.stack(donor_directions, axis=0)
        if donor_directions
        else np.zeros((0, fold_tangent_gradients[0].size), dtype=np.float64)
    )
    common_descent = common_descent_in_span(np.stack(fold_tangent_gradients), direction_matrix)
    fold_norms = [float(np.linalg.norm(value)) for value in fold_tangent_gradients]
    fold_gradient_cosine = 0.0
    if min(fold_norms) > 1e-12:
        fold_gradient_cosine = float(
            np.dot(fold_tangent_gradients[0], fold_tangent_gradients[1])
            / (fold_norms[0] * fold_norms[1])
        )
    donor_norms = np.asarray([np.linalg.norm(value) for value in donor_directions], dtype=np.float64)
    donor_norms = donor_norms[donor_norms > 1e-12]
    trust_radius = float(np.sqrt(np.mean(donor_norms * donor_norms))) if donor_norms.size else 0.0
    common = {
        "common_descent_feasible": common_descent.feasible,
        "common_descent_margin": common_descent.margin,
        "fold_gradient_cosine": fold_gradient_cosine,
        "fold_0_weight": float(common_descent.convex_weights[0]),
        "fold_1_weight": float(common_descent.convex_weights[1]),
        "fold_0_size": len(fold_a),
        "fold_1_size": len(fold_b),
        "trust_radius": trust_radius,
        "candidate_fixed_before_calibration": True,
    }
    if not common_descent.feasible or trust_radius <= 1e-12:
        return _copy_lora_state(receiver_state), {
            **common,
            "constructed": False,
            "backtracking_steps": -1,
            "accepted_step": 0.0,
            "mean_fold_training_loss_gain": 0.0,
            "min_fold_training_loss_gain": 0.0,
            "rank_projection_displacement": 0.0,
        }

    module_shapes = [_state_delta(item).shape for item in receiver_state]
    module_sizes = [int(np.prod(shape)) for shape in module_shapes]
    offsets = np.cumsum([0, *module_sizes])
    module_directions = [
        common_descent.direction[offsets[index] : offsets[index + 1]].reshape(shape)
        for index, shape in enumerate(module_shapes)
    ]
    local_fold_losses: list[float] = []
    set_lora_state(modules, receiver_state, device=device, torch=torch)
    for fold in folds:
        details = _evaluate_detailed(
            model, preprocess, text_features, fold, class_names,
            device, batch_size, Image, torch,
        )
        local_fold_losses.append(float(details["loss"]))

    for backtracking_steps in range(17):
        step = trust_radius * (0.5 ** backtracking_steps)
        candidate_state: list[dict[str, np.ndarray]] = []
        projection_error_sq = 0.0
        for receiver_item, direction in zip(receiver_state, module_directions):
            candidate_delta = _state_delta(receiver_item) + step * direction
            projected = _project_delta_to_lora(
                candidate_delta,
                rank=rank,
                scale=float(receiver_item["scale"]),
            )
            candidate_state.append(projected)
            projection_error_sq += float(np.sum((_state_delta(projected) - candidate_delta) ** 2))
        set_lora_state(modules, candidate_state, device=device, torch=torch)
        gains: list[float] = []
        for local_loss, fold in zip(local_fold_losses, folds):
            candidate_details = _evaluate_detailed(
                model, preprocess, text_features, fold, class_names,
                device, batch_size, Image, torch,
            )
            gains.append(float(local_loss - candidate_details["loss"]))
        if min(gains) > 1e-8:
            return candidate_state, {
                **common,
                "constructed": True,
                "backtracking_steps": backtracking_steps,
                "accepted_step": step,
                "mean_fold_training_loss_gain": float(np.mean(gains)),
                "min_fold_training_loss_gain": float(min(gains)),
                "rank_projection_displacement": math.sqrt(max(0.0, projection_error_sq)),
            }
    return _copy_lora_state(receiver_state), {
        **common,
        "constructed": False,
        "backtracking_steps": 17,
        "accepted_step": 0.0,
        "mean_fold_training_loss_gain": 0.0,
        "min_fold_training_loss_gain": 0.0,
        "rank_projection_displacement": 0.0,
    }


def _fixed_function_expert_logits(
    donor_logits: np.ndarray,
    receiver_features: np.ndarray,
    geo_weights: np.ndarray,
    fam_weights: np.ndarray,
    prototypes: np.ndarray,
    prototype_mask: np.ndarray,
    receiver_idx: int,
    prototype_temperature: float,
) -> tuple[np.ndarray, bool]:
    """Construct gauge-invariant fixed prediction experts for one receiver."""

    donor_values = np.asarray(donor_logits, dtype=np.float64)
    local_logits = log_probabilities_from_logits(donor_values[:, receiver_idx, :])
    geo_logits = probability_mixture_teacher(donor_values, geo_weights)
    fam_logits = probability_mixture_teacher(donor_values, fam_weights)
    classwise_logits, classwise_routes = class_conditional_probability_teacher(
        donor_values,
        receiver_features,
        prototypes,
        prototype_mask,
        fam_weights,
        receiver_index=receiver_idx,
        temperature=prototype_temperature,
        exclude_receiver=True,
    )
    external_route_mass = np.sum(classwise_routes, axis=2)
    external_route_mass[:, receiver_idx] = 0.0
    route_available = bool(np.any(external_route_mass > 1e-12))
    return (
        np.stack([local_logits, geo_logits, fam_logits, classwise_logits], axis=1),
        route_available,
    )


def _collect_crossfitted_function_experts(
    model,
    modules,
    preprocess,
    text_features,
    client,
    receiver_idx: int,
    local_states,
    initial_state,
    geo_weights,
    graph_support,
    d_geo_norm,
    prototypes,
    prototype_mask,
    class_names,
    device,
    batch_size: int,
    rank: int,
    split_seed: int,
    training_seed: int,
    communication_rounds: int,
    local_epochs: int,
    local_lr: float,
    lambda_geo: float,
    tau_fam: float,
    fam_self_weight: float,
    prototype_temperature: float,
    Image,
    torch,
    F,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict]:
    """Generate out-of-fold Local and sharing experts without label reuse."""

    del rank  # The injected module rank already fixes every trained state.
    samples = client["train"]
    fold_ids = _deterministic_stratified_fold_ids(
        samples, class_names, split_seed, num_folds=3
    )
    labels = np.full(len(samples), -1, dtype=np.int64)
    anchor_logits = np.zeros((len(samples), len(class_names)), dtype=np.float64)
    expert_logits = np.zeros(
        (len(samples), 4, len(class_names)), dtype=np.float64
    )
    route_available_by_fold: list[bool] = []
    train_sizes: list[int] = []
    for heldout_fold in np.unique(fold_ids):
        fit_indices = np.flatnonzero(fold_ids != heldout_fold)
        heldout_indices = np.flatnonzero(fold_ids == heldout_fold)
        fit_samples = [samples[int(index)] for index in fit_indices]
        heldout_samples = [samples[int(index)] for index in heldout_indices]
        crossfit_state = _copy_lora_state(initial_state)
        for communication_round in range(int(communication_rounds)):
            crossfit_state, _ = _train_client(
                model=model,
                modules=modules,
                preprocess=preprocess,
                text_features=text_features,
                samples=fit_samples,
                class_names=class_names,
                device=device,
                batch_size=batch_size,
                epochs=local_epochs,
                lr=local_lr,
                seed=(
                    int(training_seed) * 1000003
                    + communication_round * 1009
                    + int(client["client_id"])
                ),
                initial_state=crossfit_state,
                Image=Image,
                torch=torch,
                F=F,
            )

        fold_states = list(local_states)
        fold_states[receiver_idx] = crossfit_state
        fold_d_sub = _normalize_distance(_subspace_distance_matrix(fold_states))
        fold_fam_weights = _fam_weights(
            graph=graph_support,
            d_sub=fold_d_sub,
            d_geo=d_geo_norm,
            lambda_geo=lambda_geo,
            tau=tau_fam,
            self_weight=fam_self_weight,
        )
        donor_predictions: list[np.ndarray] = []
        fold_labels = None
        for state in fold_states:
            values, state_labels = _collect_state_logits(
                model=model,
                modules=modules,
                preprocess=preprocess,
                text_features=text_features,
                samples=heldout_samples,
                class_names=class_names,
                state=state,
                device=device,
                batch_size=batch_size,
                Image=Image,
                torch=torch,
            )
            donor_predictions.append(values)
            if fold_labels is None:
                fold_labels = state_labels
            elif not np.array_equal(fold_labels, state_labels):
                raise RuntimeError("cross-fitted donor predictions changed sample order")
        set_lora_state(modules, crossfit_state, device=device, torch=torch)
        receiver_features = _encode_image_features(
            model=model,
            preprocess=preprocess,
            samples=heldout_samples,
            class_names=class_names,
            device=device,
            batch_size=batch_size,
            Image=Image,
            torch=torch,
        )
        fold_experts, route_available = _fixed_function_expert_logits(
            np.stack(donor_predictions, axis=1),
            receiver_features,
            geo_weights=np.asarray(geo_weights[receiver_idx]),
            fam_weights=np.asarray(fold_fam_weights[receiver_idx]),
            prototypes=prototypes,
            prototype_mask=prototype_mask,
            receiver_idx=receiver_idx,
            prototype_temperature=prototype_temperature,
        )
        expert_logits[heldout_indices] = fold_experts
        anchor_logits[heldout_indices] = fold_experts[:, 0, :]
        labels[heldout_indices] = np.asarray(fold_labels, dtype=np.int64)
        route_available_by_fold.append(route_available)
        train_sizes.append(len(fit_samples))

    if np.any(labels < 0) or np.any(~np.isfinite(expert_logits)):
        raise RuntimeError("cross-fitted expert construction left incomplete outputs")
    return expert_logits, anchor_logits, labels, fold_ids, {
        "crossfit_fold_count": int(np.unique(fold_ids).size),
        "crossfit_train_sizes": ";".join(str(value) for value in train_sizes),
        "crossfit_classwise_route_available": bool(all(route_available_by_fold)),
        "crossfit_geometry_treated_as_fixed_exogenous_input": True,
    }


def _training_only_function_expert_ablation(
    expert_logits: np.ndarray,
    labels: np.ndarray,
    fold_ids: np.ndarray,
    anchor_logits: np.ndarray,
    expert_prior: np.ndarray,
    *,
    kl_strength: float,
    fold_temperature: float,
    full_audit,
) -> dict[str, dict[str, float | bool | list[float]] | float]:
    """Isolate FAM function utility on the same training-only cross-fit folds."""

    values = np.asarray(expert_logits, dtype=np.float64)
    prior = np.asarray(expert_prior, dtype=np.float64)
    subsets = {
        "local_geo": (0, 1),
        "local_fam": (0, 2),
        "local_geo_fam": (0, 1, 2),
        "all": (0, 1, 2, 3),
    }
    audits = {}
    for name, indices in subsets.items():
        if name == "all":
            audit = full_audit
        else:
            selected = np.asarray(indices, dtype=np.int64)
            selected_prior = prior[selected]
            selected_prior /= np.sum(selected_prior)
            audit = crossfit_convex_expert_screen(
                values[:, selected, :],
                labels,
                fold_ids,
                anchor_logits,
                expert_prior=selected_prior,
                kl_strength=kl_strength,
                fold_temperature=fold_temperature,
            )
        audits[name] = {
            "mean_heldout_regret": float(np.mean(audit.heldout_regrets)),
            "max_heldout_regret": float(np.max(audit.heldout_regrets)),
            "all_heldout_regrets_negative": bool(
                audit.all_heldout_regrets_negative
            ),
            "heldout_regrets": [
                float(value) for value in audit.heldout_regrets
            ],
            "final_objective": float(audit.final_teacher.objective),
            "final_optimality_gap": float(audit.final_teacher.optimality_gap),
        }
    geo_regret = float(audits["local_geo"]["mean_heldout_regret"])
    fam_regret = float(audits["local_fam"]["mean_heldout_regret"])
    joint_regret = float(audits["local_geo_fam"]["mean_heldout_regret"])
    return {
        **audits,
        "fam_endpoint_gain_vs_geo": geo_regret - fam_regret,
        "fam_increment_given_geo": geo_regret - joint_regret,
    }


def _run_training_only_function_expert_ablation(
    model,
    modules,
    preprocess,
    text_features,
    clients,
    local_states,
    initial_state,
    geo_weights,
    graph_support,
    d_geo_norm,
    prototypes,
    prototype_mask,
    class_names,
    config,
    device,
    Image,
    torch,
    F,
) -> list[dict]:
    """Run the frozen expert-subset estimand without outer-split evaluation."""

    rows: list[dict] = []
    expert_prior = np.asarray([0.5, 1.0 / 6.0, 1.0 / 6.0, 1.0 / 6.0])
    for receiver_idx, client in enumerate(clients):
        (
            experts,
            anchor,
            labels,
            fold_ids,
            details,
        ) = _collect_crossfitted_function_experts(
            model=model,
            modules=modules,
            preprocess=preprocess,
            text_features=text_features,
            client=client,
            receiver_idx=receiver_idx,
            local_states=local_states,
            initial_state=initial_state,
            geo_weights=geo_weights,
            graph_support=graph_support,
            d_geo_norm=d_geo_norm,
            prototypes=prototypes,
            prototype_mask=prototype_mask,
            class_names=class_names,
            device=device,
            batch_size=config.batch_size,
            rank=config.rank,
            split_seed=(
                config.seed * 1009 + int(client["client_id"]) + 20260815
            ),
            training_seed=config.seed,
            communication_rounds=config.communication_rounds,
            local_epochs=config.local_epochs,
            local_lr=config.lr,
            lambda_geo=config.lambda_geo,
            tau_fam=config.tau_fam,
            fam_self_weight=config.fam_self_weight,
            prototype_temperature=config.function_transport_prototype_temperature,
            Image=Image,
            torch=torch,
            F=F,
        )
        full = crossfit_convex_expert_screen(
            experts,
            labels,
            fold_ids,
            anchor,
            expert_prior=expert_prior,
            kl_strength=config.function_transport_kl_strength,
            fold_temperature=config.function_transport_fold_temperature,
        )
        audit = _training_only_function_expert_ablation(
            experts,
            labels,
            fold_ids,
            anchor,
            expert_prior,
            kl_strength=config.function_transport_kl_strength,
            fold_temperature=config.function_transport_fold_temperature,
            full_audit=full,
        )
        row = {
            "method": "FedAdapterManifold-TrainingOnlyExpertAblation",
            "seed": config.seed,
            "dataset": config.dataset,
            "round": config.communication_rounds - 1,
            "client_id": client["client_id"],
            "domain": client["domain"],
            "training_samples": len(client["train"]),
            "fam_endpoint_gain_vs_geo": audit["fam_endpoint_gain_vs_geo"],
            "fam_increment_given_geo": audit["fam_increment_given_geo"],
            "test_used_for_construction_or_evaluation": False,
            **details,
        }
        for subset in ("local_geo", "local_fam", "local_geo_fam", "all"):
            subset_audit = audit[subset]
            for metric in (
                "mean_heldout_regret",
                "max_heldout_regret",
                "all_heldout_regrets_negative",
                "final_objective",
                "final_optimality_gap",
            ):
                row[f"{subset}_{metric}"] = subset_audit[metric]
            row[f"{subset}_heldout_regrets"] = ";".join(
                f"{value:.12g}" for value in subset_audit["heldout_regrets"]
            )
        rows.append(row)
    return rows


def _build_function_transport_candidate(
    model,
    modules,
    preprocess,
    text_features,
    client,
    clients,
    receiver_idx: int,
    local_states,
    initial_state,
    geo_weights,
    fam_weights,
    graph_support,
    d_geo_norm,
    prototypes,
    prototype_mask,
    class_names,
    device,
    batch_size,
    rank: int,
    split_seed: int,
    training_seed: int,
    communication_rounds: int,
    local_epochs: int,
    local_lr: float,
    lambda_geo: float,
    tau_fam: float,
    fam_self_weight: float,
    kl_strength: float,
    fold_temperature: float,
    distill_epochs: int,
    distill_lr: float,
    distill_weight: float,
    anchor_weight: float,
    prototype_temperature: float,
    Image,
    torch,
    F,
) -> tuple[list[dict[str, np.ndarray]], dict]:
    """Build a cross-fitted function teacher and distill it into receiver LoRA."""

    samples = client["train"]
    receiver_state = local_states[receiver_idx]
    expert_prior = np.asarray([0.5, 1.0 / 6.0, 1.0 / 6.0, 1.0 / 6.0])
    (
        crossfit_experts,
        crossfit_anchor,
        crossfit_labels,
        crossfit_folds,
        crossfit_details,
    ) = _collect_crossfitted_function_experts(
        model=model,
        modules=modules,
        preprocess=preprocess,
        text_features=text_features,
        client=client,
        receiver_idx=receiver_idx,
        local_states=local_states,
        initial_state=initial_state,
        geo_weights=geo_weights,
        graph_support=graph_support,
        d_geo_norm=d_geo_norm,
        prototypes=prototypes,
        prototype_mask=prototype_mask,
        class_names=class_names,
        device=device,
        batch_size=batch_size,
        rank=rank,
        split_seed=split_seed,
        training_seed=training_seed,
        communication_rounds=communication_rounds,
        local_epochs=local_epochs,
        local_lr=local_lr,
        lambda_geo=lambda_geo,
        tau_fam=tau_fam,
        fam_self_weight=fam_self_weight,
        prototype_temperature=prototype_temperature,
        Image=Image,
        torch=torch,
        F=F,
    )
    crossfit = crossfit_convex_expert_screen(
        crossfit_experts,
        crossfit_labels,
        crossfit_folds,
        crossfit_anchor,
        expert_prior=expert_prior,
        kl_strength=kl_strength,
        fold_temperature=fold_temperature,
    )
    expert_ablation = _training_only_function_expert_ablation(
        crossfit_experts,
        crossfit_labels,
        crossfit_folds,
        crossfit_anchor,
        expert_prior,
        kl_strength=kl_strength,
        fold_temperature=fold_temperature,
        full_audit=crossfit,
    )

    donor_logits: list[np.ndarray] = []
    labels = None
    for state in local_states:
        values, state_labels = _collect_state_logits(
            model=model,
            modules=modules,
            preprocess=preprocess,
            text_features=text_features,
            samples=samples,
            class_names=class_names,
            state=state,
            device=device,
            batch_size=batch_size,
            Image=Image,
            torch=torch,
        )
        donor_logits.append(values)
        if labels is None:
            labels = state_labels
        elif not np.array_equal(labels, state_labels):
            raise RuntimeError("donor logits changed receiver sample order")
    donor_values = np.stack(donor_logits, axis=1)
    set_lora_state(modules, receiver_state, device=device, torch=torch)
    receiver_features = _encode_image_features(
        model=model,
        preprocess=preprocess,
        samples=samples,
        class_names=class_names,
        device=device,
        batch_size=batch_size,
        Image=Image,
        torch=torch,
    )
    expert_logits, prototype_available = _fixed_function_expert_logits(
        donor_values,
        receiver_features,
        geo_weights=np.asarray(geo_weights[receiver_idx]),
        fam_weights=np.asarray(fam_weights[receiver_idx]),
        prototypes=prototypes,
        prototype_mask=prototype_mask,
        receiver_idx=receiver_idx,
        prototype_temperature=prototype_temperature,
    )
    local_logits = expert_logits[:, 0, :]
    fold_ids = crossfit_folds
    teacher = crossfit.final_teacher
    full_teacher_logits = np.einsum(
        "e,nec->nc", teacher.expert_weights, expert_logits
    )

    candidate_state = _copy_lora_state(receiver_state)
    distillation = {
        "distillation_epochs_completed": 0,
        "final_supervised_loss": 0.0,
        "final_teacher_kl": 0.0,
        "final_anchor_kl": 0.0,
    }
    all_optimizer_gaps = np.concatenate(
        [crossfit.heldout_optimality_gaps, [teacher.optimality_gap]]
    )
    crossfit_positive = bool(
        crossfit.all_heldout_regrets_negative
        and np.max(all_optimizer_gaps) <= 1e-5
    )
    if crossfit_positive:
        candidate_state, distillation = _train_function_distilled_client(
            model=model,
            modules=modules,
            preprocess=preprocess,
            text_features=text_features,
            samples=samples,
            class_names=class_names,
            teacher_logits=full_teacher_logits,
            anchor_logits=local_logits,
            device=device,
            batch_size=batch_size,
            epochs=distill_epochs,
            lr=distill_lr,
            distill_weight=distill_weight,
            anchor_weight=anchor_weight,
            seed=split_seed + 104729,
            initial_state=receiver_state,
            Image=Image,
            torch=torch,
            F=F,
        )
    candidate_logits, candidate_labels = _collect_state_logits(
        model=model,
        modules=modules,
        preprocess=preprocess,
        text_features=text_features,
        samples=samples,
        class_names=class_names,
        state=candidate_state,
        device=device,
        batch_size=batch_size,
        Image=Image,
        torch=torch,
    )
    if not np.array_equal(labels, candidate_labels):
        raise RuntimeError("distilled candidate changed receiver sample order")
    risk = audit_function_transport_risk(
        local_logits,
        full_teacher_logits,
        candidate_logits,
        labels,
        fold_ids,
    )
    constructed = crossfit_positive
    expert_names = ["local", "geo_function", "fam_function", "prototype_fam_function"]
    return candidate_state, {
        "constructed": constructed,
        "candidate_fixed_before_calibration": True,
        "candidate_generator": "crossfitted_classwise_probability_transport_v2",
        "parameter_space_donor_mixing": False,
        "prototype_route_available": bool(prototype_available),
        "rank": int(rank),
        "training_samples": len(samples),
        "training_fold_count": int(np.unique(fold_ids).size),
        "teacher_objective": teacher.objective,
        "teacher_smooth_worst_fold_regret": teacher.smooth_worst_fold_regret,
        "teacher_prior_kl": teacher.prior_kl,
        "teacher_optimality_gap": teacher.optimality_gap,
        "teacher_optimizer_converged": teacher.converged,
        "teacher_improves_every_fold": crossfit.all_heldout_regrets_negative,
        "teacher_fold_regrets": ";".join(
            f"{value:.12g}" for value in crossfit.heldout_regrets
        ),
        "crossfit_heldout_losses": ";".join(
            f"{value:.12g}" for value in crossfit.heldout_losses
        ),
        "crossfit_heldout_anchor_losses": ";".join(
            f"{value:.12g}" for value in crossfit.heldout_anchor_losses
        ),
        "crossfit_max_heldout_regret": float(np.max(crossfit.heldout_regrets)),
        "crossfit_mean_heldout_regret": float(np.mean(crossfit.heldout_regrets)),
        "crossfit_heldout_optimality_gaps": ";".join(
            f"{value:.12g}" for value in crossfit.heldout_optimality_gaps
        ),
        "crossfit_positive": crossfit_positive,
        "training_only_expert_ablation": json.dumps(
            expert_ablation, sort_keys=True, separators=(",", ":")
        ),
        "fam_endpoint_gain_vs_geo": float(
            expert_ablation["fam_endpoint_gain_vs_geo"]
        ),
        "fam_increment_given_geo": float(
            expert_ablation["fam_increment_given_geo"]
        ),
        "expert_weights": ";".join(
            f"{name}:{weight:.12g}"
            for name, weight in zip(expert_names, teacher.expert_weights)
        ),
        "teacher_margin": float(-np.mean(crossfit.heldout_regrets)),
        "full_training_teacher_margin_diagnostic": risk.teacher_margin,
        "mean_logit_distillation_error": risk.mean_logit_distillation_error,
        "student_empirical_gap": risk.empirical_student_gap,
        "student_fold_regrets": ";".join(
            f"{value:.12g}" for value in risk.fold_student_regrets
        ),
        "student_improves_every_fold": risk.improves_every_training_fold,
        "ft3_lipschitz_upper_bound": risk.positive_utility_upper_bound,
        "ft3_lipschitz_certified": risk.certified_positive_utility,
        **crossfit_details,
        **distillation,
        "calibration_used_for_construction": False,
        "test_used_for_construction": False,
    }, teacher.expert_weights.copy()


def _details_from_numpy_logits(logits: np.ndarray, labels: np.ndarray) -> dict:
    """Create the same paired-risk fields as the model evaluation path."""

    values = np.asarray(logits, dtype=np.float64)
    targets = np.asarray(labels, dtype=np.int64)
    if values.ndim != 2 or targets.shape != (values.shape[0],):
        raise ValueError("logits and labels must align")
    log_probabilities = log_probabilities_from_logits(values)
    sample_losses = -log_probabilities[np.arange(targets.size), targets]
    predictions = np.argmax(values, axis=1)
    correctness = (predictions == targets).astype(np.int64)
    true_values = values[np.arange(targets.size), targets]
    competing = values.copy()
    competing[np.arange(targets.size), targets] = -np.inf
    margins = true_values - np.max(competing, axis=1)
    return {
        "accuracy": float(np.mean(correctness)),
        "loss": float(np.mean(sample_losses)),
        "num_samples": int(targets.size),
        "correctness": correctness.tolist(),
        "sample_losses": sample_losses.tolist(),
        "true_margins": margins.tolist(),
    }


def _argmax_preserving_logits(
    anchor_logits: np.ndarray, candidate_logits: np.ndarray
) -> np.ndarray:
    """Refine scores while preserving the Local top-1 decision pointwise."""

    anchor = np.asarray(anchor_logits, dtype=np.float64)
    candidate = np.asarray(candidate_logits, dtype=np.float64)
    if anchor.shape != candidate.shape or anchor.ndim != 2:
        raise ValueError("anchor and candidate logits must have the same matrix shape")
    output = candidate.copy()
    changed = np.argmax(anchor, axis=1) != np.argmax(candidate, axis=1)
    output[changed] = anchor[changed]
    if not np.array_equal(np.argmax(output, axis=1), np.argmax(anchor, axis=1)):
        raise RuntimeError("argmax-preserving projection changed an anchor prediction")
    return output


def _function_teacher_logits_on_samples(
    model,
    modules,
    preprocess,
    text_features,
    samples,
    receiver_idx: int,
    local_states,
    geo_weights,
    fam_weights,
    prototypes,
    prototype_mask,
    expert_weights: np.ndarray,
    prototype_temperature: float,
    class_names,
    device,
    batch_size: int,
    Image,
    torch,
) -> tuple[np.ndarray, np.ndarray]:
    """Evaluate the fixed function-bank endpoint on a new receiver split."""

    donor_predictions: list[np.ndarray] = []
    labels = None
    for state in local_states:
        values, state_labels = _collect_state_logits(
            model=model,
            modules=modules,
            preprocess=preprocess,
            text_features=text_features,
            samples=samples,
            class_names=class_names,
            state=state,
            device=device,
            batch_size=batch_size,
            Image=Image,
            torch=torch,
        )
        donor_predictions.append(values)
        if labels is None:
            labels = state_labels
        elif not np.array_equal(labels, state_labels):
            raise RuntimeError("function-bank donors changed receiver sample order")
    set_lora_state(modules, local_states[receiver_idx], device=device, torch=torch)
    receiver_features = _encode_image_features(
        model=model,
        preprocess=preprocess,
        samples=samples,
        class_names=class_names,
        device=device,
        batch_size=batch_size,
        Image=Image,
        torch=torch,
    )
    experts, _ = _fixed_function_expert_logits(
        np.stack(donor_predictions, axis=1),
        receiver_features,
        geo_weights=np.asarray(geo_weights[receiver_idx]),
        fam_weights=np.asarray(fam_weights[receiver_idx]),
        prototypes=prototypes,
        prototype_mask=prototype_mask,
        receiver_idx=receiver_idx,
        prototype_temperature=prototype_temperature,
    )
    weights = np.asarray(expert_weights, dtype=np.float64)
    if weights.shape != (experts.shape[1],):
        raise ValueError("function teacher weights do not match the expert bank")
    return np.einsum("e,nec->nc", weights, experts), np.asarray(labels)


def _paired_loss_progress_certificate(
    anchor: dict,
    candidate: dict,
    certificate_alpha: float,
    loss_tolerance: float = 1e-8,
) -> dict[str, float | int | bool]:
    anchor_losses = np.asarray(anchor["sample_losses"], dtype=np.float64)
    candidate_losses = np.asarray(candidate["sample_losses"], dtype=np.float64)
    if anchor_losses.shape != candidate_losses.shape:
        raise ValueError("paired sample losses must have the same shape")
    improvement = anchor_losses - candidate_losses
    beneficial = int(np.sum(improvement > float(loss_tolerance)))
    harmful = int(np.sum(improvement < -float(loss_tolerance)))
    p_value = _exact_one_sided_discordance_p(beneficial, harmful)
    certified = bool(
        float(candidate["loss"]) < float(anchor["loss"]) - float(loss_tolerance)
        and p_value <= float(certificate_alpha)
    )
    return {
        "loss_beneficial": beneficial,
        "loss_harmful": harmful,
        "loss_p_value": float(p_value),
        "certified": certified,
    }


def _select_function_transport_endpoint(
    anchor: dict,
    endpoints: dict[str, tuple[str, dict]],
    certificate_alpha: float,
) -> tuple[str, dict[str, dict]]:
    """Simultaneously certify class-changing and prediction-preserving paths."""

    if not endpoints:
        return "local", {}
    per_endpoint_alpha = float(certificate_alpha) / len(endpoints)
    audits: dict[str, dict] = {}
    certified_names: list[str] = []
    for name, (kind, details) in endpoints.items():
        if kind == "class_changing":
            audit = _paired_candidate_certificate(
                anchor, details, per_endpoint_alpha
            )
            audit = {
                **audit,
                "certificate_basis": "strict_accuracy_superiority",
                "accuracy_pointwise_preserved": False,
            }
        elif kind == "argmax_preserving":
            if details["correctness"] != anchor["correctness"]:
                raise RuntimeError("argmax-preserving endpoint changed correctness")
            loss_audit = _paired_loss_progress_certificate(
                anchor, details, per_endpoint_alpha
            )
            audit = {
                "beneficial": 0,
                "harmful": 0,
                "p_value": 1.0,
                **loss_audit,
                "certificate_basis": "pointwise_top1_identity_and_proper_loss",
                "accuracy_pointwise_preserved": True,
            }
        else:
            raise ValueError(f"unknown function endpoint kind: {kind}")
        audit["endpoint_alpha"] = per_endpoint_alpha
        audits[name] = audit
        if bool(audit["certified"]):
            certified_names.append(name)
    if not certified_names:
        return "local", audits
    priority = {name: index for index, name in enumerate(endpoints)}
    selected = min(
        certified_names,
        key=lambda name: (
            -float(endpoints[name][1]["accuracy"]),
            float(endpoints[name][1]["loss"]),
            priority[name],
        ),
    )
    return selected, audits


def _run_function_transport_replay(
    model,
    modules,
    preprocess,
    text_features,
    clients,
    local_states,
    initial_state,
    geo_weights,
    fam_weights,
    graph_support,
    d_geo_norm,
    prototypes,
    prototype_mask,
    class_names,
    config,
    device,
    Image,
    torch,
    F,
) -> tuple[list[dict], list[dict]]:
    """Freeze every receiver deployment before the first test forward pass."""

    frozen: list[dict] = []
    for receiver_idx, client in enumerate(clients):
        candidate_state, construction, teacher_weights = _build_function_transport_candidate(
            model=model,
            modules=modules,
            preprocess=preprocess,
            text_features=text_features,
            client=client,
            clients=clients,
            receiver_idx=receiver_idx,
            local_states=local_states,
            initial_state=initial_state,
            geo_weights=geo_weights,
            fam_weights=fam_weights,
            graph_support=graph_support,
            d_geo_norm=d_geo_norm,
            prototypes=prototypes,
            prototype_mask=prototype_mask,
            class_names=class_names,
            device=device,
            batch_size=config.batch_size,
            rank=config.rank,
            split_seed=config.seed * 1009 + int(client["client_id"]) + 20260815,
            training_seed=config.seed,
            communication_rounds=config.communication_rounds,
            local_epochs=config.local_epochs,
            local_lr=config.lr,
            lambda_geo=config.lambda_geo,
            tau_fam=config.tau_fam,
            fam_self_weight=config.fam_self_weight,
            kl_strength=config.function_transport_kl_strength,
            fold_temperature=config.function_transport_fold_temperature,
            distill_epochs=config.function_transport_distill_epochs,
            distill_lr=config.function_transport_distill_lr,
            distill_weight=config.function_transport_distill_weight,
            anchor_weight=config.function_transport_anchor_weight,
            prototype_temperature=config.function_transport_prototype_temperature,
            Image=Image,
            torch=torch,
            F=F,
        )
        local_logits, calibration_labels = _collect_state_logits(
            model=model,
            modules=modules,
            preprocess=preprocess,
            text_features=text_features,
            samples=client["calibration"],
            class_names=class_names,
            state=local_states[receiver_idx],
            device=device,
            batch_size=config.batch_size,
            Image=Image,
            torch=torch,
        )
        student_logits, student_labels = _collect_state_logits(
            model=model,
            modules=modules,
            preprocess=preprocess,
            text_features=text_features,
            samples=client["calibration"],
            class_names=class_names,
            state=candidate_state,
            device=device,
            batch_size=config.batch_size,
            Image=Image,
            torch=torch,
        )
        if not np.array_equal(calibration_labels, student_labels):
            raise RuntimeError("student calibration predictions changed sample order")
        if construction["constructed"]:
            direct_logits, direct_labels = _function_teacher_logits_on_samples(
                model=model,
                modules=modules,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["calibration"],
                receiver_idx=receiver_idx,
                local_states=local_states,
                geo_weights=geo_weights,
                fam_weights=fam_weights,
                prototypes=prototypes,
                prototype_mask=prototype_mask,
                expert_weights=teacher_weights,
                prototype_temperature=config.function_transport_prototype_temperature,
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                Image=Image,
                torch=torch,
            )
            if not np.array_equal(calibration_labels, direct_labels):
                raise RuntimeError("direct calibration predictions changed sample order")
        else:
            direct_logits = local_logits.copy()
        local_calibration = _details_from_numpy_logits(local_logits, calibration_labels)
        calibration_endpoints = {
            "direct_raw": (
                "class_changing",
                _details_from_numpy_logits(direct_logits, calibration_labels),
            ),
            "student_raw": (
                "class_changing",
                _details_from_numpy_logits(student_logits, calibration_labels),
            ),
            "direct_top1_preserving": (
                "argmax_preserving",
                _details_from_numpy_logits(
                    _argmax_preserving_logits(local_logits, direct_logits),
                    calibration_labels,
                ),
            ),
            "student_top1_preserving": (
                "argmax_preserving",
                _details_from_numpy_logits(
                    _argmax_preserving_logits(local_logits, student_logits),
                    calibration_labels,
                ),
            ),
        }
        if construction["constructed"]:
            selected_endpoint, endpoint_audits = _select_function_transport_endpoint(
                local_calibration,
                calibration_endpoints,
                config.function_transport_certificate_alpha,
            )
        else:
            selected_endpoint, endpoint_audits = "local", {}
        certified = selected_endpoint != "local"
        candidate_calibration = (
            calibration_endpoints[selected_endpoint][1]
            if certified
            else local_calibration
        )
        frozen.append(
            {
                "receiver_idx": receiver_idx,
                "client": client,
                "candidate_state": candidate_state,
                "teacher_weights": teacher_weights,
                "construction": construction,
                "local_calibration": local_calibration,
                "candidate_calibration": candidate_calibration,
                "calibration_endpoints": calibration_endpoints,
                "endpoint_audits": endpoint_audits,
                "selected_endpoint": selected_endpoint,
                "certified": certified,
            }
        )

    rows: list[dict] = []
    replay_rows: list[dict] = []
    for item in frozen:
        receiver_idx = int(item["receiver_idx"])
        client = item["client"]
        local_logits, test_labels = _collect_state_logits(
            model=model,
            modules=modules,
            preprocess=preprocess,
            text_features=text_features,
            samples=client["test"],
            class_names=class_names,
            state=local_states[receiver_idx],
            device=device,
            batch_size=config.batch_size,
            Image=Image,
            torch=torch,
        )
        student_logits, student_labels = _collect_state_logits(
            model=model,
            modules=modules,
            preprocess=preprocess,
            text_features=text_features,
            samples=client["test"],
            class_names=class_names,
            state=item["candidate_state"],
            device=device,
            batch_size=config.batch_size,
            Image=Image,
            torch=torch,
        )
        if not np.array_equal(test_labels, student_labels):
            raise RuntimeError("student test predictions changed sample order")
        if item["construction"]["constructed"]:
            direct_logits, direct_labels = _function_teacher_logits_on_samples(
                model=model,
                modules=modules,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["test"],
                receiver_idx=receiver_idx,
                local_states=local_states,
                geo_weights=geo_weights,
                fam_weights=fam_weights,
                prototypes=prototypes,
                prototype_mask=prototype_mask,
                expert_weights=item["teacher_weights"],
                prototype_temperature=config.function_transport_prototype_temperature,
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                Image=Image,
                torch=torch,
            )
            if not np.array_equal(test_labels, direct_labels):
                raise RuntimeError("direct test predictions changed sample order")
        else:
            direct_logits = local_logits.copy()
        local_test = _details_from_numpy_logits(local_logits, test_labels)
        test_endpoints = {
            "direct_raw": _details_from_numpy_logits(direct_logits, test_labels),
            "student_raw": _details_from_numpy_logits(student_logits, test_labels),
            "direct_top1_preserving": _details_from_numpy_logits(
                _argmax_preserving_logits(local_logits, direct_logits), test_labels
            ),
            "student_top1_preserving": _details_from_numpy_logits(
                _argmax_preserving_logits(local_logits, student_logits), test_labels
            ),
        }
        selected_endpoint = item["selected_endpoint"]
        candidate_test = (
            test_endpoints[selected_endpoint]
            if selected_endpoint != "local"
            else local_test
        )
        deployed_test = candidate_test
        certificate = item["endpoint_audits"].get(selected_endpoint, {})
        local_calibration = item["local_calibration"]
        candidate_calibration = item["candidate_calibration"]
        rows.append(
            {
                "method": "FedAdapterManifold-FunctionTransport-Admit-CLIP-LoRA",
                "seed": config.seed,
                "dataset": config.dataset,
                "round": config.communication_rounds - 1,
                "client_id": client["client_id"],
                "domain": client["domain"],
                **item["construction"],
                "all_deployments_frozen_before_test": True,
                "calibration_size": local_calibration["num_samples"],
                "local_calibration_accuracy": local_calibration["accuracy"],
                "candidate_calibration_accuracy": candidate_calibration["accuracy"],
                "local_calibration_loss": local_calibration["loss"],
                "candidate_calibration_loss": candidate_calibration["loss"],
                "beneficial_discordances": certificate.get("beneficial", 0),
                "harmful_discordances": certificate.get("harmful", 0),
                "one_sided_exact_p": certificate.get("p_value", 1.0),
                "loss_one_sided_exact_p": certificate.get("loss_p_value", 1.0),
                "certificate_basis": certificate.get("certificate_basis", "none"),
                "accuracy_pointwise_preserved": certificate.get(
                    "accuracy_pointwise_preserved", False
                ),
                "familywise_endpoint_alpha": certificate.get("endpoint_alpha", 0.0),
                "selected_endpoint": selected_endpoint,
                "endpoint_calibration_audits": json.dumps(
                    item["endpoint_audits"], sort_keys=True
                ),
                "certified": item["certified"],
                "deployed_method": (
                    f"FunctionTransport-{selected_endpoint}"
                    if item["certified"]
                    else "Local-CLIP-LoRA"
                ),
                "local_test_accuracy": local_test["accuracy"],
                "candidate_test_accuracy": candidate_test["accuracy"],
                "deployed_test_accuracy": deployed_test["accuracy"],
                "local_test_loss": local_test["loss"],
                "candidate_test_loss": candidate_test["loss"],
                "deployed_test_loss": deployed_test["loss"],
                "direct_raw_calibration_accuracy": item["calibration_endpoints"][
                    "direct_raw"
                ][1]["accuracy"],
                "student_raw_calibration_accuracy": item["calibration_endpoints"][
                    "student_raw"
                ][1]["accuracy"],
                "direct_raw_test_accuracy": test_endpoints["direct_raw"]["accuracy"],
                "student_raw_test_accuracy": test_endpoints["student_raw"]["accuracy"],
                "direct_raw_test_loss": test_endpoints["direct_raw"]["loss"],
                "student_raw_test_loss": test_endpoints["student_raw"]["loss"],
                "num_test_samples": local_test["num_samples"],
                "test_gain_vs_local": deployed_test["accuracy"] - local_test["accuracy"],
                "candidate_test_gain_vs_local": (
                    candidate_test["accuracy"] - local_test["accuracy"]
                ),
                "harmful_admission": bool(
                    item["certified"]
                    and candidate_test["accuracy"] < local_test["accuracy"] - 1e-12
                ),
                "test_used_for_construction_or_selection": False,
            }
        )
        replay_rows.append(
            {
                "method": "Local-CLIP-LoRA",
                "seed": config.seed,
                "dataset": config.dataset,
                "round": config.communication_rounds - 1,
                "client_id": client["client_id"],
                "domain": client["domain"],
                "accuracy": local_test["accuracy"],
                "loss": local_test["loss"],
                "num_samples": local_test["num_samples"],
                "test_used_for_coverage": False,
            }
        )
    return rows, replay_rows


def _collect_state_logits(
    model,
    modules,
    preprocess,
    text_features,
    samples,
    class_names,
    state,
    device,
    batch_size,
    Image,
    torch,
) -> tuple[np.ndarray, np.ndarray]:
    set_lora_state(modules, state, device=device, torch=torch)
    model.eval()
    values: list[np.ndarray] = []
    labels_out: list[int] = []
    with torch.no_grad():
        for batch in _batches(samples, batch_size):
            images, labels = _load_batch(batch, preprocess, class_names, device, Image, torch)
            image_features = model.encode_image(images).float()
            image_features = image_features / image_features.norm(
                dim=-1, keepdim=True
            ).clamp_min(1e-12)
            logits = model.logit_scale.exp().float() * image_features @ text_features.float().t()
            values.extend(np.asarray(logits.detach().cpu(), dtype=np.float64))
            labels_out.extend(int(value) for value in labels.detach().cpu())
    if not values:
        raise ValueError("function transport requires nonempty receiver training samples")
    return np.stack(values, axis=0), np.asarray(labels_out, dtype=np.int64)


def _train_function_distilled_client(
    model,
    modules,
    preprocess,
    text_features,
    samples,
    class_names,
    teacher_logits,
    anchor_logits,
    device,
    batch_size,
    epochs,
    lr,
    distill_weight,
    anchor_weight,
    seed,
    initial_state,
    Image,
    torch,
    F,
) -> tuple[list[dict[str, np.ndarray]], dict]:
    """Distill a training-fixed teacher; no calibration or test input is accepted."""

    if len(samples) != len(teacher_logits) or len(samples) != len(anchor_logits):
        raise ValueError("teacher and anchor logits must align with training samples")
    if float(distill_weight) < 0.0 or float(anchor_weight) < 0.0:
        raise ValueError("distillation and anchor weights must be nonnegative")
    set_lora_state(modules, initial_state, device=device, torch=torch)
    trainable = [
        parameter
        for module in modules
        for parameter in module.parameters()
        if parameter.requires_grad
    ]
    optimizer = torch.optim.AdamW(trainable, lr=lr)
    index_by_path = {sample["path"]: index for index, sample in enumerate(samples)}
    if len(index_by_path) != len(samples):
        raise ValueError("function distillation requires unique training sample paths")
    temperature = 1.0
    rng = random.Random(seed)
    final = {
        "distillation_epochs_completed": 0,
        "final_supervised_loss": 0.0,
        "final_teacher_kl": 0.0,
        "final_anchor_kl": 0.0,
    }
    model.train()
    for epoch in range(max(1, int(epochs))):
        shuffled = samples[:]
        rng.shuffle(shuffled)
        supervised_values: list[float] = []
        teacher_values: list[float] = []
        anchor_values: list[float] = []
        for batch in _batches(shuffled, batch_size):
            indices = [index_by_path[sample["path"]] for sample in batch]
            images, labels = _load_batch(batch, preprocess, class_names, device, Image, torch)
            target_teacher = torch.as_tensor(
                np.asarray(teacher_logits)[indices], dtype=torch.float32, device=device
            )
            target_anchor = torch.as_tensor(
                np.asarray(anchor_logits)[indices], dtype=torch.float32, device=device
            )
            optimizer.zero_grad(set_to_none=True)
            image_features = model.encode_image(images).float()
            image_features = image_features / image_features.norm(
                dim=-1, keepdim=True
            ).clamp_min(1e-12)
            logits = model.logit_scale.exp().float() * image_features @ text_features.float().t()
            supervised = F.cross_entropy(logits, labels)
            teacher_kl = F.kl_div(
                F.log_softmax(logits / temperature, dim=1),
                F.softmax(target_teacher / temperature, dim=1),
                reduction="batchmean",
            ) * (temperature ** 2)
            anchor_kl = F.kl_div(
                F.log_softmax(logits / temperature, dim=1),
                F.softmax(target_anchor / temperature, dim=1),
                reduction="batchmean",
            ) * (temperature ** 2)
            loss = supervised + float(distill_weight) * teacher_kl + float(anchor_weight) * anchor_kl
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, 1.0)
            optimizer.step()
            supervised_values.append(float(supervised.detach().cpu()))
            teacher_values.append(float(teacher_kl.detach().cpu()))
            anchor_values.append(float(anchor_kl.detach().cpu()))
        final = {
            "distillation_epochs_completed": epoch + 1,
            "final_supervised_loss": float(np.mean(supervised_values)),
            "final_teacher_kl": float(np.mean(teacher_values)),
            "final_anchor_kl": float(np.mean(anchor_values)),
        }
    model.eval()
    return get_lora_state(modules), final


def _deterministic_stratified_fold_ids(
    samples, class_names, seed: int, num_folds: int = 2
) -> np.ndarray:
    if int(num_folds) < 2:
        raise ValueError("num_folds must be at least two")
    class_index = {name: index for index, name in enumerate(class_names)}
    labels = np.asarray([class_index[sample["label"]] for sample in samples], dtype=np.int64)
    fold_ids = np.zeros(len(samples), dtype=np.int64)
    cursor = 0
    for class_id in sorted(np.unique(labels)):
        indices = np.flatnonzero(labels == class_id)
        ordered = sorted(
            (int(index) for index in indices),
            key=lambda index: hashlib.sha256(
                f"{seed}:{samples[index]['path']}".encode("utf-8")
            ).hexdigest(),
        )
        for position, index in enumerate(ordered):
            fold_ids[index] = (cursor + position) % int(num_folds)
        cursor += len(ordered)
    if np.unique(fold_ids).size < int(num_folds):
        raise ValueError("function transport could not populate every deterministic fold")
    return fold_ids


def _compute_state_class_prototypes(
    model,
    modules,
    preprocess,
    clients,
    local_states,
    class_names,
    device,
    batch_size,
    Image,
    torch,
) -> tuple[np.ndarray, np.ndarray]:
    feature_sets: list[np.ndarray] = []
    feature_dim = 0
    for client, state in zip(clients, local_states):
        set_lora_state(modules, state, device=device, torch=torch)
        features = _encode_image_features(
            model, preprocess, client["train"], class_names,
            device, batch_size, Image, torch,
        )
        feature_sets.append(features)
        if features.size:
            feature_dim = int(features.shape[1])
    prototypes = np.zeros(
        (len(clients), len(class_names), feature_dim), dtype=np.float64
    )
    mask = np.zeros((len(clients), len(class_names)), dtype=bool)
    class_index = {name: index for index, name in enumerate(class_names)}
    for client_index, (client, features) in enumerate(zip(clients, feature_sets)):
        for class_name, class_id in class_index.items():
            indices = [
                index
                for index, sample in enumerate(client["train"])
                if sample["label"] == class_name
            ]
            if not indices:
                continue
            value = np.mean(features[np.asarray(indices)], axis=0)
            norm = float(np.linalg.norm(value))
            if norm > 1e-12:
                prototypes[client_index, class_id] = value / norm
                mask[client_index, class_id] = True
    return prototypes, mask


def _prototype_function_routes(
    receiver_features: np.ndarray,
    prototypes: np.ndarray,
    prototype_mask: np.ndarray,
    compatibility: np.ndarray,
    receiver_idx: int,
    temperature: float,
) -> tuple[np.ndarray, bool]:
    features = np.asarray(receiver_features, dtype=np.float64)
    anchors = np.asarray(prototypes, dtype=np.float64)
    mask = np.asarray(prototype_mask, dtype=bool)
    prior = np.maximum(0.0, np.asarray(compatibility, dtype=np.float64))
    if features.ndim != 2 or anchors.ndim != 3 or anchors.shape[:2] != mask.shape:
        raise ValueError("prototype function routing received incompatible arrays")
    if anchors.shape[0] != prior.size or anchors.shape[2] != features.shape[1]:
        raise ValueError("prototype function routing dimensions do not align")
    prior[int(receiver_idx)] = 0.0
    support = (prior > 0.0) & np.any(mask, axis=1)
    routes = np.zeros((features.shape[0], anchors.shape[0]), dtype=np.float64)
    if not np.any(support):
        routes[:, int(receiver_idx)] = 1.0
        return routes, False
    scores = np.full_like(routes, -np.inf)
    for donor_idx in np.flatnonzero(support):
        valid = mask[donor_idx]
        similarities = features @ anchors[donor_idx, valid].T
        scores[:, donor_idx] = (
            np.max(similarities, axis=1) / max(float(temperature), 1e-6)
            + math.log(max(prior[donor_idx], 1e-15))
        )
    maximum = np.max(scores[:, support], axis=1, keepdims=True)
    routes[:, support] = np.exp(scores[:, support] - maximum)
    routes /= np.sum(routes, axis=1, keepdims=True)
    return routes, True


def _encode_image_features(model, preprocess, samples, class_names, device, batch_size, Image, torch) -> np.ndarray:
    model.eval()
    features: list[np.ndarray] = []
    with torch.no_grad():
        for batch in _batches(samples, batch_size):
            images, _ = _load_batch(batch, preprocess, class_names, device, Image, torch)
            encoded = model.encode_image(images).float()
            encoded = encoded / encoded.norm(dim=-1, keepdim=True).clamp_min(1e-12)
            features.extend(np.asarray(encoded.detach().cpu(), dtype=np.float64))
    if not features:
        return np.zeros((0, 0), dtype=np.float64)
    return np.stack(features, axis=0)


def _compute_client_class_prototypes(
    model,
    preprocess,
    clients,
    class_names,
    device,
    batch_size,
    Image,
    torch,
) -> tuple[np.ndarray, np.ndarray]:
    all_features: list[np.ndarray] = []
    feature_dim = 0
    for client in clients:
        features = _encode_image_features(
            model=model,
            preprocess=preprocess,
            samples=client["train"],
            class_names=class_names,
            device=device,
            batch_size=batch_size,
            Image=Image,
            torch=torch,
        )
        all_features.append(features)
        if features.size:
            feature_dim = features.shape[1]
    prototypes = np.zeros((len(clients), len(class_names), feature_dim), dtype=np.float64)
    mask = np.zeros((len(clients), len(class_names)), dtype=bool)
    for client_idx, (client, features) in enumerate(zip(clients, all_features)):
        by_class: dict[int, list[np.ndarray]] = {}
        for sample, feature in zip(client["train"], features):
            class_idx = class_names.index(sample["label"])
            by_class.setdefault(class_idx, []).append(feature)
        for class_idx, values in by_class.items():
            prototype = np.mean(np.stack(values, axis=0), axis=0)
            norm = float(np.linalg.norm(prototype))
            if norm > 1e-12:
                prototypes[client_idx, class_idx] = prototype / norm
                mask[client_idx, class_idx] = True
    return prototypes, mask


def _crossfit_class_prototypes(
    features: np.ndarray,
    labels: list[int] | np.ndarray,
    num_classes: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return two-fold leave-fold-out prototypes and deterministic fold ids.

    Alternating examples within each class makes both folds class-complete when
    at least two examples are available. A sample is always routed with the
    prototype bank that excludes its own fold.
    """

    features = np.asarray(features, dtype=np.float64)
    labels = np.asarray(labels, dtype=np.int64)
    if features.ndim != 2 or features.shape[0] != labels.shape[0]:
        raise ValueError("cross-fitted features and labels must align")
    if int(num_classes) <= 0:
        raise ValueError("num_classes must be positive")
    fold_ids = np.zeros(labels.shape[0], dtype=np.int64)
    for class_idx in range(int(num_classes)):
        indices = np.flatnonzero(labels == class_idx)
        fold_ids[indices] = np.arange(indices.size, dtype=np.int64) % 2

    prototypes = np.zeros((2, int(num_classes), features.shape[1]), dtype=np.float64)
    masks = np.zeros((2, int(num_classes)), dtype=bool)
    for held_out_fold in range(2):
        for class_idx in range(int(num_classes)):
            keep = (labels == class_idx) & (fold_ids != held_out_fold)
            if not np.any(keep):
                continue
            value = features[keep].mean(axis=0)
            norm = float(np.linalg.norm(value))
            if norm > 1e-12:
                prototypes[held_out_fold, class_idx] = value / norm
                masks[held_out_fold, class_idx] = True
    return prototypes, masks, fold_ids


def _deterministic_semantic_modes(
    class_prototypes: np.ndarray,
    class_mask: np.ndarray,
    num_modes: int,
    iterations: int = 20,
) -> tuple[np.ndarray, np.ndarray]:
    """Cluster class anchors into deterministic cosine semantic modes."""

    prototypes = np.asarray(class_prototypes, dtype=np.float64)
    mask = np.asarray(class_mask, dtype=bool)
    if prototypes.ndim != 2 or mask.shape != (prototypes.shape[0],):
        raise ValueError("class prototype mask has incompatible shape")
    valid = np.flatnonzero(mask)
    if valid.size == 0:
        return np.full(prototypes.shape[0], -1, dtype=np.int64), np.zeros(
            (0, prototypes.shape[1]), dtype=np.float64
        )
    k = min(max(1, int(num_modes)), int(valid.size))
    chosen = [int(valid[0])]
    while len(chosen) < k:
        similarity = prototypes[valid] @ prototypes[np.asarray(chosen)].T
        nearest = similarity.max(axis=1)
        order = np.lexsort((valid, nearest))
        next_class = int(valid[int(order[0])])
        if next_class in chosen:
            next_class = next(int(item) for item in valid if int(item) not in chosen)
        chosen.append(next_class)
    centroids = prototypes[np.asarray(chosen)].copy()
    assignments = np.zeros(valid.size, dtype=np.int64)
    for _ in range(max(1, int(iterations))):
        new_assignments = np.argmax(prototypes[valid] @ centroids.T, axis=1)
        updated = centroids.copy()
        for mode_idx in range(k):
            members = prototypes[valid[new_assignments == mode_idx]]
            if members.size == 0:
                continue
            value = members.mean(axis=0)
            norm = float(np.linalg.norm(value))
            if norm > 1e-12:
                updated[mode_idx] = value / norm
        if np.array_equal(assignments, new_assignments) and np.allclose(
            centroids, updated, atol=1e-12
        ):
            centroids = updated
            break
        assignments = new_assignments
        centroids = updated
    class_to_mode = np.full(prototypes.shape[0], -1, dtype=np.int64)
    class_to_mode[valid] = assignments
    return class_to_mode, centroids


def _semantic_mode_assignments(
    features: np.ndarray,
    class_prototypes: np.ndarray,
    class_mask: np.ndarray,
    class_to_mode: np.ndarray,
) -> tuple[list[int], list[int], list[float]]:
    """Assign each feature through its closest class anchor to a semantic mode."""

    features = np.asarray(features, dtype=np.float64)
    prototypes = np.asarray(class_prototypes, dtype=np.float64)
    mask = np.asarray(class_mask, dtype=bool)
    mapping = np.asarray(class_to_mode, dtype=np.int64)
    if prototypes.ndim != 2 or mapping.shape != (prototypes.shape[0],):
        raise ValueError("semantic mode mapping has incompatible shape")
    valid = mask & (mapping >= 0)
    modes: list[int] = []
    classes: list[int] = []
    similarities: list[float] = []
    for feature in features:
        scores = prototypes @ feature
        scores[~valid] = -np.inf
        if not np.isfinite(scores).any():
            modes.append(-1)
            classes.append(-1)
            similarities.append(float("nan"))
            continue
        class_idx = int(np.argmax(scores))
        modes.append(int(mapping[class_idx]))
        classes.append(class_idx)
        similarities.append(float(scores[class_idx]))
    return modes, classes, similarities


def _fit_mode_utility_rule(
    mode_ids: list[int],
    local_details: dict,
    candidate_details: dict[tuple[int, float], dict],
    min_mode_samples: int,
    accuracy_tolerance: float,
) -> tuple[dict[int, dict], list[dict]]:
    """Fit one external tangent action per mode from training-side utility.

    Correctness gain is primary because the independent endpoint is accuracy.
    Proper-loss gain breaks ties and verifies the local descent direction.
    Modes without positive empirical utility stay at the Local anchor.
    """

    modes = np.asarray(mode_ids, dtype=np.int64)
    local_correct = np.asarray(local_details["correctness"], dtype=np.int64)
    local_losses = np.asarray(local_details["sample_losses"], dtype=np.float64)
    local_margins = np.asarray(
        local_details.get("true_margins", np.zeros_like(local_losses)),
        dtype=np.float64,
    )
    if modes.shape[0] != local_correct.shape[0] or modes.shape[0] != local_losses.shape[0]:
        raise ValueError("mode assignments and local screen details must align")
    rule: dict[int, dict] = {}
    rows: list[dict] = []
    for mode_idx in sorted(int(value) for value in np.unique(modes) if int(value) >= 0):
        indices = np.flatnonzero(modes == mode_idx)
        options: list[dict] = []
        for (donor_idx, alpha), details in sorted(candidate_details.items()):
            candidate_correct = np.asarray(details["correctness"], dtype=np.int64)
            candidate_losses = np.asarray(details["sample_losses"], dtype=np.float64)
            candidate_margins = np.asarray(
                details.get("true_margins", np.zeros_like(candidate_losses)),
                dtype=np.float64,
            )
            if candidate_correct.shape != local_correct.shape or candidate_losses.shape != local_losses.shape:
                raise ValueError("candidate and local screen details must align")
            beneficial = int(np.sum((local_correct[indices] == 0) & (candidate_correct[indices] == 1)))
            harmful = int(np.sum((local_correct[indices] == 1) & (candidate_correct[indices] == 0)))
            accuracy_gain = float((beneficial - harmful) / max(1, indices.size))
            loss_gain = float(np.mean(local_losses[indices] - candidate_losses[indices]))
            margin_gain = float(
                np.mean(candidate_margins[indices] - local_margins[indices])
            )
            eligible = bool(
                indices.size >= int(min_mode_samples)
                and beneficial >= harmful
                and accuracy_gain >= -float(accuracy_tolerance) - 1e-12
                and loss_gain > 1e-12
                and margin_gain > 1e-12
            )
            row = {
                "mode_id": mode_idx,
                "mode_samples": int(indices.size),
                "donor_client_id": int(donor_idx),
                "alpha": float(alpha),
                "beneficial_discordances": beneficial,
                "harmful_discordances": harmful,
                "screen_accuracy_gain_vs_local": accuracy_gain,
                "screen_loss_gain_vs_local": loss_gain,
                "screen_true_margin_gain_vs_local": margin_gain,
                "eligible": eligible,
            }
            rows.append(row)
            if eligible:
                options.append(row)
        if options:
            best = max(
                options,
                key=lambda row: (
                    int(row["beneficial_discordances"])
                    - int(row["harmful_discordances"]),
                    float(row["screen_true_margin_gain_vs_local"]),
                    float(row["screen_loss_gain_vs_local"]),
                    -float(row["alpha"]),
                    -int(row["donor_client_id"]),
                ),
            )
            rule[mode_idx] = dict(best)
    selected = {
        (int(item["mode_id"]), int(item["donor_client_id"]), float(item["alpha"]))
        for item in rule.values()
    }
    for row in rows:
        row["selected"] = (
            int(row["mode_id"]), int(row["donor_client_id"]), float(row["alpha"])
        ) in selected
    return rule, rows


def _utility_state_routes(
    mode_ids: list[int],
    rule: dict[int, dict],
    state_index: dict[tuple[int, float], int],
) -> list[int]:
    routes: list[int] = []
    for mode_idx in mode_ids:
        item = rule.get(int(mode_idx))
        if item is None:
            routes.append(0)
            continue
        routes.append(state_index[(int(item["donor_client_id"]), float(item["alpha"]))])
    return routes


def _prototype_route_assignments(
    features: np.ndarray,
    prototypes: np.ndarray,
    prototype_mask: np.ndarray,
    receiver_idx: int,
    compatibility_weights: np.ndarray,
    prior_weight: float,
    exclude_self: bool = False,
) -> tuple[list[int], list[int], list[float], list[float]]:
    weights = np.maximum(0.0, np.asarray(compatibility_weights[receiver_idx], dtype=np.float64))
    support = weights > 0.0
    support[receiver_idx] = not bool(exclude_self)
    prior = float(prior_weight) * np.log(np.maximum(weights, 1e-12))
    routes: list[int] = []
    routed_classes: list[int] = []
    similarities: list[float] = []
    scores: list[float] = []
    for feature in features:
        cosine = np.einsum("ncd,d->nc", prototypes, feature)
        valid = prototype_mask & support[:, None]
        joint = cosine + prior[:, None]
        joint[~valid] = -np.inf
        if not np.isfinite(joint).any():
            routes.append(receiver_idx)
            routed_classes.append(-1)
            similarities.append(float("nan"))
            scores.append(float("nan"))
            continue
        flat = int(np.argmax(joint))
        donor, class_idx = np.unravel_index(flat, joint.shape)
        routes.append(int(donor))
        routed_classes.append(int(class_idx))
        similarities.append(float(cosine[donor, class_idx]))
        scores.append(float(joint[donor, class_idx]))
    return routes, routed_classes, similarities, scores


def _receiver_mode_tangent_states(
    local_states: list[list[dict[str, np.ndarray]]],
    receiver_idx: int,
    alpha: float,
    rank: int,
) -> tuple[list[list[dict[str, np.ndarray]]], list[dict[str, float]]]:
    """Build one receiver-conditioned adapter state for every bank donor.

    The self route is the unchanged local anchor. External donor residuals are
    projected onto the receiver's LoRA tangent space before the fixed step is
    applied, so prototype routing cannot inject the donor's normal component.
    """

    if not 0 <= int(receiver_idx) < len(local_states):
        raise ValueError("receiver index is outside the adapter bank")
    if not np.isfinite(alpha) or not 0.0 < float(alpha):
        raise ValueError("mode tangent alpha must be positive")
    receiver = local_states[int(receiver_idx)]
    routed_states: list[list[dict[str, np.ndarray]]] = []
    diagnostics: list[dict[str, float]] = []
    for donor_idx, donor in enumerate(local_states):
        if donor_idx == int(receiver_idx):
            routed_states.append(_copy_lora_state(receiver))
            diagnostics.append(
                {
                    "residual_norm": 0.0,
                    "tangent_norm": 0.0,
                    "admitted_residual_norm": 0.0,
                    "tangent_energy_ratio": 1.0,
                }
            )
            continue
        state, item = _tangent_residual_state(
            receiver_state=receiver,
            anchor_state=receiver,
            source_state=donor,
            alpha=float(alpha),
            rank=rank,
        )
        routed_states.append(state)
        diagnostics.append(item)
    return routed_states, diagnostics


def _select_loss_first_mode_tangent(candidates: list[dict]) -> dict:
    """Choose a fixed mode-tangent step on the training-side screen.

    Proper loss is the primary target because empirical accuracy is piecewise
    constant in the step size. The pre-declared accuracy constraint remains a
    guardrail. If no candidate satisfies the guardrail and improves screen
    loss, the least-loss candidate is still fixed for independent calibration;
    it cannot deploy unless the exact held-out certificate succeeds.
    """

    if not candidates:
        raise ValueError("mode tangent screening requires at least one candidate")
    eligible = [row for row in candidates if bool(row["screen_eligible"])]
    pool = eligible if eligible else candidates
    return min(
        pool,
        key=lambda row: (
            float(row["screen_loss"]),
            -float(row["screen_accuracy"]),
            -float(row["screen_external_fraction"]),
            float(row["alpha"]),
        ),
    )


def _prototype_routes(
    model,
    modules,
    zero_state,
    preprocess,
    samples,
    prototypes,
    prototype_mask,
    receiver_idx,
    compatibility_weights,
    prior_weight,
    exclude_self,
    class_names,
    device,
    batch_size,
    split,
    Image,
    torch,
) -> tuple[list[int], list[dict]]:
    set_lora_state(modules, zero_state, device=device, torch=torch)
    features = _encode_image_features(
        model=model,
        preprocess=preprocess,
        samples=samples,
        class_names=class_names,
        device=device,
        batch_size=batch_size,
        Image=Image,
        torch=torch,
    )
    routes, routed_classes, similarities, scores = _prototype_route_assignments(
        features=features,
        prototypes=prototypes,
        prototype_mask=prototype_mask,
        receiver_idx=receiver_idx,
        compatibility_weights=compatibility_weights,
        prior_weight=prior_weight,
        exclude_self=exclude_self,
    )
    rows = [
        {
            "selection_protocol": "class_conditional_prototype_bank_v1",
            "split": split,
            "sample_index": index,
            "receiver_client_id": receiver_idx,
            "donor_client_id": donor,
            "external_route": donor != receiver_idx,
            "prototype_class_id": class_idx,
            "prototype_class": class_names[class_idx] if class_idx >= 0 else "",
            "prototype_cosine": similarity,
            "route_score": score,
            "routing_prior_weight": prior_weight,
            "exclude_self": bool(exclude_self),
        }
        for index, (donor, class_idx, similarity, score) in enumerate(
            zip(routes, routed_classes, similarities, scores)
        )
    ]
    return routes, rows


def _evaluate_adapter_routes(
    model,
    modules,
    local_states,
    routes,
    preprocess,
    text_features,
    samples,
    class_names,
    device,
    batch_size,
    Image,
    torch,
) -> dict:
    if len(routes) != len(samples):
        raise ValueError("prototype routes must align with samples")
    losses = [float("nan")] * len(samples)
    correctness = [0] * len(samples)
    true_margins = [float("nan")] * len(samples)
    by_donor: dict[int, list[int]] = {}
    for sample_idx, donor in enumerate(routes):
        by_donor.setdefault(int(donor), []).append(sample_idx)
    for donor, indices in by_donor.items():
        set_lora_state(modules, local_states[donor], device=device, torch=torch)
        details = _evaluate_detailed(
            model=model,
            preprocess=preprocess,
            text_features=text_features,
            samples=[samples[index] for index in indices],
            class_names=class_names,
            device=device,
            batch_size=batch_size,
            Image=Image,
            torch=torch,
        )
        for offset, sample_idx in enumerate(indices):
            losses[sample_idx] = float(details["sample_losses"][offset])
            correctness[sample_idx] = int(details["correctness"][offset])
            true_margins[sample_idx] = float(details["true_margins"][offset])
    return {
        "accuracy": sum(correctness) / max(1, len(correctness)),
        "loss": sum(losses) / max(1, len(losses)),
        "num_samples": len(samples),
        "correctness": correctness,
        "sample_losses": losses,
        "true_margins": true_margins,
    }


def _load_batch(batch, preprocess, class_names, device, Image, torch):
    tensors = []
    labels = []
    for sample in batch:
        with Image.open(sample["path"]) as image:
            tensors.append(preprocess(image.convert("RGB")))
        labels.append(class_names.index(sample["label"]))
    return torch.stack(tensors, dim=0).to(device), torch.tensor(labels, dtype=torch.long, device=device)


def _batches(items, batch_size: int):
    for start in range(0, len(items), max(1, batch_size)):
        yield items[start : start + max(1, batch_size)]


def reset_lora_parameters(modules, seed: int, torch) -> None:
    generator = torch.Generator(device=modules[0].lora_a.device if modules else "cpu")
    generator.manual_seed(int(seed))
    for module in modules:
        with torch.no_grad():
            module.lora_a.normal_(0.0, 1.0 / math.sqrt(max(1, module.embed_dim)), generator=generator)
            module.lora_b.zero_()


def get_lora_state(modules) -> list[dict[str, np.ndarray]]:
    out = []
    for module in modules:
        out.append(
            {
                "a": module.lora_a.detach().float().cpu().numpy().copy(),
                "b": module.lora_b.detach().float().cpu().numpy().copy(),
                "scale": np.array(float(module.scale), dtype=np.float64),
            }
        )
    return out


def _copy_lora_state(state: list[dict[str, np.ndarray]]) -> list[dict[str, np.ndarray]]:
    return [
        {
            "a": np.asarray(item["a"]).copy(),
            "b": np.asarray(item["b"]).copy(),
            "scale": np.asarray(item["scale"]).copy(),
        }
        for item in state
    ]


def _residual_lora_state(
    trained: list[dict[str, np.ndarray]],
    received: list[dict[str, np.ndarray]],
    rank: int,
) -> list[dict[str, np.ndarray]]:
    """Represent a client's current-round update in a fixed-rank LoRA gauge."""

    if len(trained) != len(received):
        raise ValueError("trained and received LoRA states must align")
    residual = []
    for trained_item, received_item in zip(trained, received):
        trained_delta = float(trained_item["scale"]) * (
            np.asarray(trained_item["b"]) @ np.asarray(trained_item["a"])
        )
        received_delta = float(received_item["scale"]) * (
            np.asarray(received_item["b"]) @ np.asarray(received_item["a"])
        )
        residual.append(
            _project_delta_to_lora(
                trained_delta - received_delta,
                rank=rank,
                scale=float(trained_item["scale"]),
            )
        )
    return residual


def zero_lora_state(modules) -> list[dict[str, np.ndarray]]:
    return [
        {
            "a": np.zeros_like(module.lora_a.detach().float().cpu().numpy()),
            "b": np.zeros_like(module.lora_b.detach().float().cpu().numpy()),
            "scale": np.array(float(module.scale), dtype=np.float64),
        }
        for module in modules
    ]


def set_lora_state(modules, state: list[dict[str, np.ndarray]], device: str, torch) -> None:
    for module, item in zip(modules, state):
        with torch.no_grad():
            module.lora_a.copy_(torch.as_tensor(item["a"], dtype=module.lora_a.dtype, device=device))
            module.lora_b.copy_(torch.as_tensor(item["b"], dtype=module.lora_b.dtype, device=device))


def average_factor_state(states: list[list[dict[str, np.ndarray]]], weights: np.ndarray) -> list[dict[str, np.ndarray]]:
    weights = _normalize_weights(weights)
    out = []
    for module_idx in range(len(states[0])):
        a = sum(float(weights[i]) * states[i][module_idx]["a"] for i in range(len(states)))
        b = sum(float(weights[i]) * states[i][module_idx]["b"] for i in range(len(states)))
        out.append({"a": a, "b": b, "scale": states[0][module_idx]["scale"]})
    return out


def average_lifted_state(states: list[list[dict[str, np.ndarray]]], weights: np.ndarray, rank: int) -> list[dict[str, np.ndarray]]:
    weights = _normalize_weights(weights)
    out = []
    for module_idx in range(len(states[0])):
        delta = None
        scale = float(states[0][module_idx]["scale"])
        for client_idx, state in enumerate(states):
            item = state[module_idx]
            local_delta = float(item["scale"]) * (item["b"] @ item["a"])
            delta = float(weights[client_idx]) * local_delta if delta is None else delta + float(weights[client_idx]) * local_delta
        out.append(_project_delta_to_lora(delta, rank=rank, scale=scale))
    return out


def _project_delta_to_lora(delta: np.ndarray, rank: int, scale: float) -> dict[str, np.ndarray]:
    rows, cols = delta.shape
    rank = int(max(1, min(rank, rows, cols)))
    delta = np.nan_to_num(delta.astype(np.float64), nan=0.0, posinf=1e4, neginf=-1e4)
    try:
        u, s, vt = np.linalg.svd(delta, full_matrices=False)
    except np.linalg.LinAlgError:
        u, s, vt = _fallback_svd(delta)
    u = u[:, :rank]
    s = s[:rank]
    vt = vt[:rank, :]
    b = u * (s / max(scale, 1e-12))[np.newaxis, :]
    return {"a": vt.astype(np.float32), "b": b.astype(np.float32), "scale": np.array(scale, dtype=np.float64)}


def _parse_tangent_alphas(value: str) -> list[float]:
    alphas = sorted({float(item.strip()) for item in value.split(",") if item.strip()})
    if not alphas or any(not np.isfinite(alpha) or alpha <= 0.0 or alpha > 1.0 for alpha in alphas):
        raise ValueError("tangent_alphas must contain finite values in (0, 1]")
    return alphas


def _parse_utility_tangent_alphas(value: str) -> list[float]:
    alphas = sorted({float(item.strip()) for item in value.split(",") if item.strip()})
    if not alphas or any(not np.isfinite(alpha) or alpha <= 0.0 for alpha in alphas):
        raise ValueError("utility_tangent_alphas must contain finite positive values")
    return alphas


def _state_delta(item: dict[str, np.ndarray]) -> np.ndarray:
    return float(item["scale"]) * (np.asarray(item["b"], dtype=np.float64) @ np.asarray(item["a"], dtype=np.float64))


def _receiver_tangent_projection(residual: np.ndarray, receiver_item: dict[str, np.ndarray]) -> np.ndarray:
    """Project a lifted update residual onto the receiver's rank-r tangent space.

    For receiver column/row bases U and V, the tangent projector is
    P_U R + R P_V - P_U R P_V. The factorized implementation below avoids
    materializing the large ambient projectors.
    """

    residual = np.nan_to_num(np.asarray(residual, dtype=np.float64))
    u = _orth(np.asarray(receiver_item["b"], dtype=np.float64))
    v = _orth(np.asarray(receiver_item["a"], dtype=np.float64).T)
    if u.size == 0 and v.size == 0:
        return np.zeros_like(residual)
    left = u @ (u.T @ residual) if u.size else np.zeros_like(residual)
    right = (residual @ v) @ v.T if v.size else np.zeros_like(residual)
    overlap = u @ ((u.T @ residual @ v) @ v.T) if u.size and v.size else np.zeros_like(residual)
    return left + right - overlap


def _tangent_residual_state(
    receiver_state: list[dict[str, np.ndarray]],
    anchor_state: list[dict[str, np.ndarray]],
    source_state: list[dict[str, np.ndarray]],
    alpha: float,
    rank: int,
) -> tuple[list[dict[str, np.ndarray]], dict[str, float]]:
    out: list[dict[str, np.ndarray]] = []
    tangent_energy = 0.0
    residual_energy = 0.0
    admitted_energy = 0.0
    for receiver_item, anchor_item, source_item in zip(receiver_state, anchor_state, source_state):
        anchor_delta = _state_delta(anchor_item)
        residual = _state_delta(source_item) - anchor_delta
        tangent = _receiver_tangent_projection(residual, receiver_item)
        candidate_delta = anchor_delta + float(alpha) * tangent
        scale = float(anchor_item["scale"])
        out.append(_project_delta_to_lora(candidate_delta, rank=rank, scale=scale))
        residual_energy += float(np.sum(residual * residual))
        tangent_energy += float(np.sum(tangent * tangent))
        admitted_energy += float(np.sum((float(alpha) * tangent) ** 2))
    diagnostics = {
        "residual_norm": math.sqrt(max(0.0, residual_energy)),
        "tangent_norm": math.sqrt(max(0.0, tangent_energy)),
        "admitted_residual_norm": math.sqrt(max(0.0, admitted_energy)),
        "tangent_energy_ratio": tangent_energy / max(residual_energy, 1e-12),
    }
    return out, diagnostics


def _build_tangent_candidate_states(
    receiver_states: list[list[dict[str, np.ndarray]]],
    anchor_states: dict[str, list[list[dict[str, np.ndarray]]]],
    source_states: dict[str, list[list[dict[str, np.ndarray]]]],
    alphas: list[float],
    rank: int,
) -> tuple[dict[str, list[list[dict[str, np.ndarray]]]], list[dict]]:
    candidates: dict[str, list[list[dict[str, np.ndarray]]]] = {}
    manifest: list[dict] = []
    for anchor_name, anchor_client_states in anchor_states.items():
        for source_name, source_client_states in source_states.items():
            for alpha in alphas:
                method = f"FAM-Tangent-{anchor_name}-from-{source_name}-a{alpha:g}"
                method_states: list[list[dict[str, np.ndarray]]] = []
                for client_idx, receiver_state in enumerate(receiver_states):
                    state, diagnostics = _tangent_residual_state(
                        receiver_state=receiver_state,
                        anchor_state=anchor_client_states[client_idx],
                        source_state=source_client_states[client_idx],
                        alpha=alpha,
                        rank=rank,
                    )
                    method_states.append(state)
                    manifest.append(
                        {
                            "candidate_method": method,
                            "client_id": client_idx,
                            "anchor": anchor_name,
                            "source": source_name,
                            "alpha": alpha,
                            **diagnostics,
                        }
                    )
                candidates[method] = method_states
    return candidates, manifest


def _top_compatible_bank_source(
    local_states: list[list[dict[str, np.ndarray]]],
    compatibility_weights: np.ndarray,
) -> tuple[list[list[dict[str, np.ndarray]]], list[int]]:
    """Choose one non-self adapter-bank source per receiver without labels."""

    weights = np.nan_to_num(np.asarray(compatibility_weights, dtype=np.float64))
    if weights.shape != (len(local_states), len(local_states)):
        raise ValueError("compatibility_weights must be square and aligned with local_states")
    sources: list[list[dict[str, np.ndarray]]] = []
    donors: list[int] = []
    for receiver in range(len(local_states)):
        row = weights[receiver].copy()
        row[receiver] = -np.inf
        donor = int(np.argmax(row))
        if not np.isfinite(row[donor]) or row[donor] <= 0.0:
            donor = receiver
        donors.append(donor)
        sources.append(local_states[donor])
    return sources, donors


def _fallback_svd(delta: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    gram = np.nan_to_num(delta @ delta.T)
    eigvals, u = np.linalg.eigh(gram)
    order = np.argsort(np.maximum(eigvals, 0.0))[::-1]
    eigvals = np.maximum(eigvals[order], 0.0)
    u = u[:, order]
    s = np.sqrt(eigvals)
    vt = np.zeros((u.shape[1], delta.shape[1]), dtype=np.float64)
    nonzero = s > 1e-12
    vt[nonzero] = (u[:, nonzero].T @ delta) / s[nonzero, None]
    return u, s, vt


def _subspace_distance_matrix(states: list[list[dict[str, np.ndarray]]]) -> np.ndarray:
    n = len(states)
    out = np.zeros((n, n), dtype=np.float64)
    for i in range(n):
        for j in range(i + 1, n):
            total = 0.0
            for module_idx in range(len(states[i])):
                total += _grassmann(states[i][module_idx]["b"], states[j][module_idx]["b"])
                total += _grassmann(states[i][module_idx]["a"].T, states[j][module_idx]["a"].T)
            out[i, j] = out[j, i] = total
    return out


def _temporal_subspace_distance_matrix(
    history: list[list[list[dict[str, np.ndarray]]]],
    *,
    decay: float = 1.0,
) -> np.ndarray:
    """Grassmann distance between leading eigenspaces of averaged projectors.

    Averaging projectors, rather than LoRA factors, is invariant to factor gauge.
    Under stationary independent round noise, uniform weights reduce the variance
    proxy from one to 1/T; decay below one trades variance for recency.
    """

    if not history:
        raise ValueError("temporal subspace history must be non-empty")
    if not np.isfinite(decay) or decay <= 0.0 or decay > 1.0:
        raise ValueError("subspace_ema_decay must lie in (0, 1]")
    num_clients = len(history[0])
    if num_clients == 0 or any(len(round_states) != num_clients for round_states in history):
        raise ValueError("all temporal rounds must contain the same clients")
    num_modules = len(history[0][0])
    if any(len(client) != num_modules for round_states in history for client in round_states):
        raise ValueError("all temporal states must contain the same LoRA modules")

    raw_weights = np.asarray(
        [decay ** (len(history) - 1 - index) for index in range(len(history))],
        dtype=np.float64,
    )
    weights = raw_weights / raw_weights.sum()
    bases: list[list[tuple[np.ndarray, np.ndarray]]] = []
    for client_index in range(num_clients):
        client_bases: list[tuple[np.ndarray, np.ndarray]] = []
        for module_index in range(num_modules):
            column_rounds = [
                _orth(round_states[client_index][module_index]["b"])
                for round_states in history
            ]
            row_rounds = [
                _orth(round_states[client_index][module_index]["a"].T)
                for round_states in history
            ]
            client_bases.append(
                (
                    _leading_average_projector_basis(column_rounds, weights),
                    _leading_average_projector_basis(row_rounds, weights),
                )
            )
        bases.append(client_bases)

    out = np.zeros((num_clients, num_clients), dtype=np.float64)
    for i in range(num_clients):
        for j in range(i + 1, num_clients):
            total = 0.0
            for module_index in range(num_modules):
                column_i, row_i = bases[i][module_index]
                column_j, row_j = bases[j][module_index]
                total += _grassmann(column_i, column_j)
                total += _grassmann(row_i, row_j)
            out[i, j] = out[j, i] = total
    return out


def _leading_average_projector_basis(
    round_bases: list[np.ndarray],
    weights: np.ndarray,
) -> np.ndarray:
    ambient = round_bases[0].shape[0]
    target_rank = max((basis.shape[1] for basis in round_bases), default=0)
    if target_rank == 0:
        return np.zeros((ambient, 0), dtype=np.float64)
    average = np.zeros((ambient, ambient), dtype=np.float64)
    for weight, basis in zip(weights, round_bases):
        if basis.size:
            average += float(weight) * (basis @ basis.T)
    eigenvalues, eigenvectors = np.linalg.eigh((average + average.T) * 0.5)
    order = np.argsort(eigenvalues)[::-1]
    keep = order[: min(target_rank, ambient)]
    positive = eigenvalues[keep] > 1e-10
    return eigenvectors[:, keep[positive]]


def _grassmann(x: np.ndarray, y: np.ndarray) -> float:
    qx = _orth(x)
    qy = _orth(y)
    if qx.size == 0 or qy.size == 0:
        return 0.0
    s = np.linalg.svd(qx.T @ qy, compute_uv=False)
    s = np.clip(s, -1.0, 1.0)
    return float(np.linalg.norm(np.arccos(s)))


def _orth(x: np.ndarray) -> np.ndarray:
    x = np.nan_to_num(np.asarray(x, dtype=np.float64))
    if x.ndim != 2 or min(x.shape) == 0 or np.linalg.norm(x) < 1e-12:
        return np.zeros((x.shape[0], 0), dtype=np.float64)
    q, r = np.linalg.qr(x)
    keep = np.abs(np.diag(r)) > 1e-10 if r.ndim == 2 else np.ones(q.shape[1], dtype=bool)
    return q[:, keep]


def _load_geometry(config: Config, clients: list[dict]) -> tuple[np.ndarray, np.ndarray, str]:
    n = len(clients)
    if config.geometry_outputs_dir:
        root = Path(config.geometry_outputs_dir)
        d_path = root / f"d_geo_round_{config.round_id}.npy"
        g_path = root / f"geometry_graph_round_{config.round_id}.npy"
        if d_path.exists():
            d_geo = np.asarray(np.load(d_path), dtype=np.float64)
            if d_geo.shape == (n, n):
                graph = np.asarray(np.load(g_path), dtype=np.float64) if g_path.exists() else _knn_graph(d_geo, config.graph_k)
                if graph.shape != (n, n):
                    graph = _knn_graph(d_geo, config.graph_k)
                return d_geo, graph, "FedGeo"
    d_geo = _domain_name_distance([client["domain"] for client in clients])
    return d_geo, _knn_graph(d_geo, config.graph_k), "domain_name_fallback"


def _domain_name_distance(domains: list[str]) -> np.ndarray:
    n = len(domains)
    out = np.ones((n, n), dtype=np.float64)
    np.fill_diagonal(out, 0.0)
    return out


def _knn_graph(d_geo: np.ndarray, k: int) -> np.ndarray:
    n = d_geo.shape[0]
    graph = np.zeros((n, n), dtype=np.float64)
    for i in range(n):
        order = np.argsort(d_geo[i])
        for j in order[1 : min(n, max(1, k) + 1)]:
            graph[i, j] = 1.0
            graph[j, i] = 1.0
    return graph


def _normalize_distance(matrix: np.ndarray) -> np.ndarray:
    matrix = np.asarray(matrix, dtype=np.float64)
    finite = matrix[np.isfinite(matrix)]
    if finite.size == 0:
        return np.zeros_like(matrix)
    off_diag = matrix[~np.eye(matrix.shape[0], dtype=bool)]
    scale = np.nanmax(off_diag) if off_diag.size else np.nanmax(finite)
    if not np.isfinite(scale) or scale <= 1e-12:
        return np.zeros_like(matrix)
    return np.nan_to_num(matrix / scale)


def _support_from_graph(graph: np.ndarray, d_geo: np.ndarray, k: int) -> np.ndarray:
    """Convert FedGeo graph output to an adjacency support.

    Some FedGeo providers store a weighted affinity graph whose off-diagonal
    values can be extremely small after kernel scaling. Treating those values as
    aggregation weights collapses graph sharing back to self-only. For adapter
    sharing we need the manifold support, so dense or underflowed weighted
    graphs are converted to a k-nearest-neighbor support using d_geo.
    """

    graph = np.nan_to_num(np.asarray(graph, dtype=np.float64))
    n = graph.shape[0]
    off_diag = graph[~np.eye(n, dtype=bool)]
    positive = off_diag[off_diag > 0.0]
    density = positive.size / max(1, off_diag.size)
    max_positive = float(np.max(positive)) if positive.size else 0.0
    if positive.size == 0 or density > 0.75 or max_positive < 1e-6:
        return _knn_graph(d_geo, k)
    support = (graph > 0.0).astype(np.float64)
    np.fill_diagonal(support, 0.0)
    support = np.maximum(support, support.T)
    return support


def _graph_weights(graph: np.ndarray, d_geo: np.ndarray, self_weight: float, tau: float) -> np.ndarray:
    n = graph.shape[0]
    weights = np.zeros((n, n), dtype=np.float64)
    affinity = np.exp(-np.nan_to_num(d_geo) / max(tau, 1e-6))
    for i in range(n):
        row = np.asarray(graph[i], dtype=np.float64) * affinity[i]
        row[i] = max(row[i], self_weight)
        if row.sum() <= 1e-12:
            row[i] = 1.0
        weights[i] = row / row.sum()
    return weights


def _fam_weights(
    graph: np.ndarray,
    d_sub: np.ndarray,
    d_geo: np.ndarray,
    lambda_geo: float,
    tau: float,
    self_weight: float,
) -> np.ndarray:
    n = graph.shape[0]
    combined = np.nan_to_num(d_sub) + float(lambda_geo) * np.nan_to_num(d_geo)
    affinity = np.exp(-combined / max(tau, 1e-6))
    weights = np.zeros((n, n), dtype=np.float64)
    support = (np.asarray(graph) > 0).astype(np.float64)
    for i in range(n):
        row = support[i] * affinity[i]
        row[i] = max(row[i], self_weight)
        if row.sum() <= 1e-12:
            row[i] = 1.0
        weights[i] = row / row.sum()
    return weights


def _normalize_weights(weights: np.ndarray) -> np.ndarray:
    weights = np.maximum(0.0, np.nan_to_num(np.asarray(weights, dtype=np.float64)))
    total = weights.sum()
    if total <= 1e-12:
        return np.full_like(weights, 1.0 / max(1, len(weights)))
    return weights / total


def _select_by_calibration(
    model,
    modules,
    preprocess,
    text_features,
    clients,
    method_states,
    class_names,
    device,
    batch_size,
    Image,
    torch,
) -> tuple[list[list[dict[str, np.ndarray]]], list[dict]]:
    selected_states = []
    rows: list[dict] = []
    candidates = [
        "Local-CLIP-LoRA",
        "FedAvg-CLIP-LoRA",
        "FedAvg-Lift-CLIP-LoRA",
        "FedGeo-Agg-CLIP-LoRA",
        "FedAdapterManifold-CLIP-LoRA",
    ]
    for client_idx, client in enumerate(clients):
        best_method = ""
        best_loss = float("inf")
        for method in candidates:
            set_lora_state(modules, method_states[method][client_idx], device=device, torch=torch)
            metrics = _evaluate(
                model=model,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["calibration"],
                class_names=class_names,
                device=device,
                batch_size=batch_size,
                Image=Image,
                torch=torch,
            )
            rows.append(
                {
                    "client_id": client["client_id"],
                    "domain": client["domain"],
                    "candidate_method": method,
                    "calibration_loss": metrics["loss"],
                    "calibration_accuracy": metrics["accuracy"],
                    "num_calibration": metrics["num_samples"],
                }
            )
            if metrics["loss"] < best_loss:
                best_loss = metrics["loss"]
                best_method = method
        for row in rows:
            if row["client_id"] == client["client_id"] and row["candidate_method"] == best_method:
                row["selected"] = True
            elif row["client_id"] == client["client_id"]:
                row.setdefault("selected", False)
        selected_states.append(method_states[best_method][client_idx])
    return selected_states, rows


def _select_tangent_by_calibration(
    model,
    modules,
    preprocess,
    text_features,
    clients,
    method_states,
    class_names,
    device,
    batch_size,
    min_loss_gain,
    accuracy_tolerance,
    Image,
    torch,
) -> tuple[list[list[dict[str, np.ndarray]]], list[dict]]:
    """Select one fixed-pool tangent candidate without test-set feedback.

    Local and Geo are the only anchors. A non-anchor residual is admissible
    only when its calibration accuracy is non-inferior to the best anchor and
    its calibration loss improves by the pre-declared margin.
    """

    anchor_methods = ["Local-CLIP-LoRA", "FedGeo-Agg-CLIP-LoRA"]
    residual_methods = sorted(method for method in method_states if method.startswith("FAM-Tangent-"))
    candidates = anchor_methods + residual_methods
    selected_states: list[list[dict[str, np.ndarray]]] = []
    rows: list[dict] = []
    pool_signature = "|".join(candidates)

    for client_idx, client in enumerate(clients):
        client_rows: list[dict] = []
        for method in candidates:
            set_lora_state(modules, method_states[method][client_idx], device=device, torch=torch)
            metrics = _evaluate(
                model=model,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["calibration"],
                class_names=class_names,
                device=device,
                batch_size=batch_size,
                Image=Image,
                torch=torch,
            )
            client_rows.append(
                {
                    "selection_protocol": "receiver_tangent_admission_v1",
                    "candidate_pool_signature": pool_signature,
                    "client_id": client["client_id"],
                    "domain": client["domain"],
                    "candidate_method": method,
                    "is_anchor": method in anchor_methods,
                    "calibration_loss": metrics["loss"],
                    "calibration_accuracy": metrics["accuracy"],
                    "num_calibration": metrics["num_samples"],
                    "min_loss_gain": float(min_loss_gain),
                    "accuracy_tolerance": float(accuracy_tolerance),
                }
            )

        selected_row, eligible = _choose_tangent_candidate(
            client_rows,
            min_loss_gain=float(min_loss_gain),
            accuracy_tolerance=float(accuracy_tolerance),
        )
        selected_method = str(selected_row["candidate_method"])
        for row in client_rows:
            row["selected"] = row["candidate_method"] == selected_method
            row["fell_back_to_anchor"] = not eligible
        rows.extend(client_rows)
        selected_states.append(method_states[selected_method][client_idx])
    return selected_states, rows


def _choose_tangent_candidate(
    client_rows: list[dict],
    min_loss_gain: float,
    accuracy_tolerance: float,
) -> tuple[dict, list[dict]]:
    anchor_rows = [row for row in client_rows if bool(row["is_anchor"])]
    if not anchor_rows:
        raise ValueError("receiver-tangent admission requires at least one anchor")
    anchor_row = min(
        anchor_rows,
        key=lambda row: (
            -float(row["calibration_accuracy"]),
            0 if row["candidate_method"] == "Local-CLIP-LoRA" else 1,
            float(row["calibration_loss"]),
        ),
    )
    anchor_loss = float(anchor_row["calibration_loss"])
    anchor_accuracy = float(anchor_row["calibration_accuracy"])
    eligible: list[dict] = []
    for row in client_rows:
        is_residual = not bool(row["is_anchor"])
        improves_loss = float(row["calibration_loss"]) <= anchor_loss - float(min_loss_gain) - 1e-12
        accuracy_gain = float(row["calibration_accuracy"]) - anchor_accuracy
        improves_target = accuracy_gain > float(accuracy_tolerance) + 1e-12
        row["anchor_method"] = anchor_row["candidate_method"]
        row["anchor_calibration_loss"] = anchor_loss
        row["anchor_calibration_accuracy"] = anchor_accuracy
        row["loss_gain_vs_anchor"] = anchor_loss - float(row["calibration_loss"])
        row["accuracy_gain_vs_anchor"] = accuracy_gain
        row["eligible_residual"] = bool(is_residual and improves_loss and improves_target)
        if row["eligible_residual"]:
            eligible.append(row)
    selected = (
        min(eligible, key=lambda row: (-float(row["calibration_accuracy"]), float(row["calibration_loss"])))
        if eligible
        else anchor_row
    )
    return selected, eligible


def _select_tangent_certified(
    model,
    modules,
    preprocess,
    text_features,
    clients,
    method_states,
    class_names,
    device,
    batch_size,
    certificate_alpha,
    Image,
    torch,
) -> tuple[list[list[dict[str, np.ndarray]]], list[dict]]:
    """Screen on adapter-training data and certify a hierarchy on calibration.

    Conditional on the training split, the residual family is fixed. Local is
    the immutable safety anchor. Geo must first beat Local under an exact
    paired certificate; the screened FAM residual must beat Local and, when
    Geo is itself certified, must also beat Geo. The caller supplies the
    multiplicity-adjusted per-comparison alpha. Test predictions are not used.
    """

    if not 0.0 < float(certificate_alpha) < 1.0:
        raise ValueError("tangent_certificate_alpha must be in (0, 1)")
    local_method = "Local-CLIP-LoRA"
    geo_method = "FedGeo-Agg-CLIP-LoRA"
    residual_methods = sorted(method for method in method_states if method.startswith("FAM-Tangent-"))
    if not residual_methods:
        raise ValueError("tangent certification requires receiver-tangent candidates")
    selected_states: list[list[dict[str, np.ndarray]]] = []
    rows: list[dict] = []
    pool_signature = "|".join(residual_methods)

    for client_idx, client in enumerate(clients):
        screen_rows: list[dict] = []
        for method in residual_methods:
            set_lora_state(modules, method_states[method][client_idx], device=device, torch=torch)
            metrics = _evaluate(
                model=model,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["train"],
                class_names=class_names,
                device=device,
                batch_size=batch_size,
                Image=Image,
                torch=torch,
            )
            screen_rows.append(
                {
                    "selection_protocol": "receiver_tangent_exact_certificate_v1",
                    "candidate_pool_signature": pool_signature,
                    "client_id": client["client_id"],
                    "domain": client["domain"],
                    "candidate_method": method,
                    "screen_accuracy": metrics["accuracy"],
                    "screen_loss": metrics["loss"],
                    "num_screen": metrics["num_samples"],
                }
            )
        screened = min(
            screen_rows,
            key=lambda row: (-float(row["screen_accuracy"]), float(row["screen_loss"]), row["candidate_method"]),
        )
        screened_method = str(screened["candidate_method"])

        details: dict[str, dict] = {}
        for method in [local_method, geo_method, screened_method]:
            set_lora_state(modules, method_states[method][client_idx], device=device, torch=torch)
            details[method] = _evaluate_detailed(
                model=model,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["calibration"],
                class_names=class_names,
                device=device,
                batch_size=batch_size,
                Image=Image,
                torch=torch,
            )
        deployed_method, certificates = _select_hierarchically_certified_deployment(
            details,
            screened_method=screened_method,
            certificate_alpha=float(certificate_alpha),
        )
        fam_local = certificates["fam_vs_local"]
        fam_geo = certificates["fam_vs_geo"]
        geo_local = certificates["geo_vs_local"]
        certified = bool(certificates["fam_deployable"])
        selected_states.append(method_states[deployed_method][client_idx])
        for row in screen_rows:
            row.update(
                {
                    "screen_selected": row["candidate_method"] == screened_method,
                    "anchor_method": local_method,
                    "anchor_family_size": 1,
                    "calibration_accuracy": details[screened_method]["accuracy"] if row["candidate_method"] == screened_method else "",
                    "calibration_loss": details[screened_method]["loss"] if row["candidate_method"] == screened_method else "",
                    "anchor_calibration_accuracy": details[local_method]["accuracy"] if row["candidate_method"] == screened_method else "",
                    "anchor_calibration_loss": details[local_method]["loss"] if row["candidate_method"] == screened_method else "",
                    "beneficial_discordances": fam_local["beneficial"] if row["candidate_method"] == screened_method else "",
                    "harmful_discordances": fam_local["harmful"] if row["candidate_method"] == screened_method else "",
                    "one_sided_exact_p": fam_local["p_value"] if row["candidate_method"] == screened_method else "",
                    "certificate_alpha": certificate_alpha,
                    "certified": certified if row["candidate_method"] == screened_method else False,
                    "geo_vs_local_beneficial": geo_local["beneficial"] if row["candidate_method"] == screened_method else "",
                    "geo_vs_local_harmful": geo_local["harmful"] if row["candidate_method"] == screened_method else "",
                    "geo_vs_local_exact_p": geo_local["p_value"] if row["candidate_method"] == screened_method else "",
                    "geo_certified_vs_local": geo_local["certified"] if row["candidate_method"] == screened_method else False,
                    "fam_vs_geo_beneficial": fam_geo["beneficial"] if row["candidate_method"] == screened_method else "",
                    "fam_vs_geo_harmful": fam_geo["harmful"] if row["candidate_method"] == screened_method else "",
                    "fam_vs_geo_exact_p": fam_geo["p_value"] if row["candidate_method"] == screened_method else "",
                    "fam_certified_vs_local": fam_local["certified"] if row["candidate_method"] == screened_method else False,
                    "fam_certified_vs_geo": fam_geo["certified"] if row["candidate_method"] == screened_method else False,
                    "certificate_hierarchy": "local_safe;geo_vs_local;fam_vs_local_and_admitted_geo",
                    "selected": row["candidate_method"] == deployed_method,
                    "deployed_method": deployed_method,
                    "fell_back_to_local": deployed_method == local_method,
                }
            )
        rows.extend(screen_rows)
    return selected_states, rows


def _select_hierarchically_certified_deployment(
    details: dict[str, dict],
    *,
    screened_method: str,
    certificate_alpha: float,
) -> tuple[str, dict[str, dict | bool]]:
    """Return the best endpoint that is certified above immutable Local."""

    local_method = "Local-CLIP-LoRA"
    geo_method = "FedGeo-Agg-CLIP-LoRA"
    required = [local_method, geo_method, screened_method]
    if any(method not in details for method in required):
        raise ValueError("Local, Geo, and the screened FAM candidate require calibration details")
    if not 0.0 < float(certificate_alpha) < 1.0:
        raise ValueError("certificate_alpha must be in (0, 1)")

    geo_local = _paired_candidate_certificate(
        details[local_method], details[geo_method], certificate_alpha
    )
    fam_local = _paired_candidate_certificate(
        details[local_method], details[screened_method], certificate_alpha
    )
    fam_geo = _paired_candidate_certificate(
        details[geo_method], details[screened_method], certificate_alpha
    )
    geo_deployable = bool(geo_local["certified"])
    fam_deployable = bool(
        fam_local["certified"]
        and (not geo_deployable or fam_geo["certified"])
    )
    eligible = [local_method]
    if geo_deployable:
        eligible.append(geo_method)
    if fam_deployable:
        eligible.append(screened_method)
    order = {local_method: 0, geo_method: 1, screened_method: 2}
    deployed = min(
        eligible,
        key=lambda method: (
            -float(details[method]["accuracy"]),
            float(details[method]["loss"]),
            order[method],
        ),
    )
    return deployed, {
        "geo_vs_local": geo_local,
        "fam_vs_local": fam_local,
        "fam_vs_geo": fam_geo,
        "geo_deployable": geo_deployable,
        "fam_deployable": fam_deployable,
    }


def _paired_candidate_certificate(
    anchor: dict,
    candidate: dict,
    certificate_alpha: float,
) -> dict[str, float | int | bool]:
    beneficial, harmful = _paired_discordance_counts(
        anchor["correctness"], candidate["correctness"]
    )
    p_value = _exact_one_sided_discordance_p(
        beneficial=beneficial, harmful=harmful
    )
    certified = bool(
        float(candidate["accuracy"]) > float(anchor["accuracy"])
        and float(candidate["loss"]) < float(anchor["loss"])
        and p_value <= float(certificate_alpha)
    )
    return {
        "beneficial": int(beneficial),
        "harmful": int(harmful),
        "p_value": float(p_value),
        "certified": certified,
    }


def _paired_dual_risk_certificate(
    anchor: dict,
    candidate: dict,
    certificate_alpha: float,
    loss_tolerance: float = 1e-8,
) -> dict[str, float | int | bool | str]:
    """Certify accuracy superiority or proper-loss progress without test data.

    The candidate is fixed before calibration. The supplied receiver-level
    alpha is split between the correctness and proper-loss endpoints, so a
    union bound preserves the original family-wise receiver budget.
    """

    endpoint_alpha = float(certificate_alpha) / 2.0
    accuracy = _paired_candidate_certificate(anchor, candidate, endpoint_alpha)
    anchor_losses = np.asarray(anchor["sample_losses"], dtype=np.float64)
    candidate_losses = np.asarray(candidate["sample_losses"], dtype=np.float64)
    if anchor_losses.shape != candidate_losses.shape:
        raise ValueError("paired sample losses must have the same shape")
    improvement = anchor_losses - candidate_losses
    loss_beneficial = int(np.sum(improvement > float(loss_tolerance)))
    loss_harmful = int(np.sum(improvement < -float(loss_tolerance)))
    loss_p_value = _exact_one_sided_discordance_p(loss_beneficial, loss_harmful)
    loss_certified = bool(
        float(candidate["accuracy"]) >= float(anchor["accuracy"]) - 1e-12
        and float(candidate["loss"]) < float(anchor["loss"]) - float(loss_tolerance)
        and loss_p_value <= endpoint_alpha
    )
    accuracy_certified = bool(accuracy["certified"])
    if accuracy_certified:
        basis = "accuracy"
    elif loss_certified:
        basis = "proper_loss_with_accuracy_noninferiority"
    else:
        basis = "none"
    return {
        **accuracy,
        "accuracy_certified": accuracy_certified,
        "loss_beneficial": loss_beneficial,
        "loss_harmful": loss_harmful,
        "loss_p_value": float(loss_p_value),
        "loss_certified": loss_certified,
        "certificate_basis": basis,
        "certified": bool(accuracy_certified or loss_certified),
        "endpoint_alpha": endpoint_alpha,
    }


def _paired_discordance_counts(anchor_correctness: list[int], candidate_correctness: list[int]) -> tuple[int, int]:
    if len(anchor_correctness) != len(candidate_correctness):
        raise ValueError("paired predictions must have the same length")
    beneficial = sum(int(anchor == 0 and candidate == 1) for anchor, candidate in zip(anchor_correctness, candidate_correctness))
    harmful = sum(int(anchor == 1 and candidate == 0) for anchor, candidate in zip(anchor_correctness, candidate_correctness))
    return beneficial, harmful


def _exact_one_sided_discordance_p(beneficial: int, harmful: int) -> float:
    """Exact one-sided McNemar/sign test for candidate improvement."""

    beneficial = int(beneficial)
    harmful = int(harmful)
    total = beneficial + harmful
    if total <= 0 or beneficial <= harmful:
        return 1.0
    numerator = sum(math.comb(total, k) for k in range(0, harmful + 1))
    return float(numerator / (2**total))


def _aggregate_metrics(per_client_rows: list[dict], config: Config) -> list[dict]:
    methods = sorted({row["method"] for row in per_client_rows})
    out = []
    for method in methods:
        rows = [row for row in per_client_rows if row["method"] == method]
        accuracies = [float(row["accuracy"]) for row in rows]
        losses = [float(row["loss"]) for row in rows]
        conflicts = [float(row["update_conflict_vs_local"]) for row in rows]
        risks = [float(row["client_risk"]) for row in rows]
        out.append(
            {
                "method": method,
                "seed": config.seed,
                "dataset": config.dataset,
                "heterogeneity": config.domains,
                "round": config.communication_rounds - 1,
                "geometry_round": config.round_id,
                "mean_accuracy": _mean(accuracies),
                "std_accuracy": _std(accuracies),
                "mean_loss": _mean(losses),
                "worst_client_risk": max(risks) if risks else float("nan"),
                "mean_update_conflict_vs_local": _mean(conflicts),
                "num_clients": len(rows),
                "num_test_samples": sum(int(row["num_samples"]) for row in rows),
            }
        )
    return out


def _subspace_failure_rows(
    model,
    modules,
    preprocess,
    text_features,
    clients,
    local_states,
    local_acc,
    d_sub,
    d_geo,
    class_names,
    device,
    batch_size,
    rank,
    Image,
    torch,
) -> list[dict]:
    rows: list[dict] = []
    for receiver_idx, receiver in enumerate(clients):
        for donor_idx, donor in enumerate(clients):
            if receiver_idx == donor_idx:
                continue
            pair_state = average_lifted_state(
                [local_states[receiver_idx], local_states[donor_idx]],
                np.array([0.5, 0.5], dtype=np.float64),
                rank=rank,
            )
            set_lora_state(modules, pair_state, device=device, torch=torch)
            metrics = _evaluate(
                model=model,
                preprocess=preprocess,
                text_features=text_features,
                samples=receiver["test"],
                class_names=class_names,
                device=device,
                batch_size=batch_size,
                Image=Image,
                torch=torch,
            )
            failure = local_acc[int(receiver["client_id"])] - metrics["accuracy"]
            rows.append(
                {
                    "receiver_client_id": receiver["client_id"],
                    "receiver_domain": receiver["domain"],
                    "donor_client_id": donor["client_id"],
                    "donor_domain": donor["domain"],
                    "d_sub": float(d_sub[receiver_idx, donor_idx]),
                    "d_geo": float(d_geo[receiver_idx, donor_idx]),
                    "pair_accuracy": metrics["accuracy"],
                    "local_accuracy": local_acc[int(receiver["client_id"])],
                    "aggregation_failure": failure,
                    "positive_failure": max(0.0, failure),
                }
            )
    r_sub = _pearson([row["d_sub"] for row in rows], [row["aggregation_failure"] for row in rows])
    r_geo = _pearson([row["d_geo"] for row in rows], [row["aggregation_failure"] for row in rows])
    for row in rows:
        row["subspace_failure_pearson_r"] = r_sub
        row["geometry_failure_pearson_r"] = r_geo
    return rows


def _conflict_rows(metrics_rows: list[dict]) -> list[dict]:
    out = []
    local = _find(metrics_rows, "Local-CLIP-LoRA")
    fedavg = _find(metrics_rows, "FedAvg-CLIP-LoRA")
    for row in metrics_rows:
        out.append(
            {
                "method": row["method"],
                "seed": row["seed"],
                "dataset": row["dataset"],
                "round": row["round"],
                "mean_update_conflict_vs_local": row["mean_update_conflict_vs_local"],
                "worst_client_risk": row["worst_client_risk"],
                "mean_accuracy": row["mean_accuracy"],
                "accuracy_gain_vs_fedavg": float(row["mean_accuracy"]) - float(fedavg.get("mean_accuracy", float("nan"))),
                "accuracy_gain_vs_local": float(row["mean_accuracy"]) - float(local.get("mean_accuracy", float("nan"))),
            }
        )
    return out


def _weight_rows(clients: list[dict], method: str, weights: np.ndarray) -> list[dict]:
    rows = []
    for i, receiver in enumerate(clients):
        for j, donor in enumerate(clients):
            rows.append(
                {
                    "method": method,
                    "receiver_client_id": receiver["client_id"],
                    "receiver_domain": receiver["domain"],
                    "donor_client_id": donor["client_id"],
                    "donor_domain": donor["domain"],
                    "weight": float(weights[i, j]),
                }
            )
    return rows


def _find(rows: list[dict], method: str) -> dict:
    for row in rows:
        if row.get("method") == method:
            return row
    return {}


def _mean(values: Iterable[float]) -> float:
    vals = [float(v) for v in values if math.isfinite(float(v))]
    return sum(vals) / len(vals) if vals else float("nan")


def _std(values: Iterable[float]) -> float:
    vals = [float(v) for v in values if math.isfinite(float(v))]
    if len(vals) <= 1:
        return 0.0 if vals else float("nan")
    mu = _mean(vals)
    return math.sqrt(sum((v - mu) ** 2 for v in vals) / (len(vals) - 1))


def _pearson(xs: Iterable[float], ys: Iterable[float]) -> float:
    x = np.asarray(list(xs), dtype=np.float64)
    y = np.asarray(list(ys), dtype=np.float64)
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    if x.size < 3 or np.std(x) <= 1e-12 or np.std(y) <= 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def _set_seed(seed: int, torch) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    if not fieldnames:
        fieldnames = ["empty"]
        rows = [{"empty": ""}]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _write_config(
    path: Path,
    config: Config,
    class_names: list[str],
    geometry_provider: str,
    clients: list[dict],
    prompt_labels: list[str],
) -> None:
    payload = asdict(config)
    payload["class_names"] = class_names
    payload["prompt_labels"] = prompt_labels
    payload["class_label_map_sha256"] = _class_label_map_sha256(config.class_label_map)
    payload["geometry_provider"] = geometry_provider
    payload["clients"] = [
        {
            "client_id": client["client_id"],
            "domain": client["domain"],
            "num_train": client["num_train"],
            "num_calibration": client["num_calibration"],
            "num_test": client["num_test"],
        }
        for client in clients
    ]
    lines = []
    for key, value in payload.items():
        if isinstance(value, (list, dict)):
            lines.append(f"{key}: {json.dumps(value)}")
        else:
            lines.append(f"{key}: {value}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_run_provenance(
    path: Path,
    *,
    config: Config,
    clients: list[dict],
    data_root: Path,
    geometry_provider: str,
    torch,
) -> None:
    split_payload = []
    for client in clients:
        for split in ["train", "calibration", "test"]:
            for sample in client[split]:
                sample_path = Path(sample["path"])
                try:
                    relative = sample_path.resolve().relative_to(data_root.resolve()).as_posix()
                except ValueError:
                    relative = str(sample_path.resolve())
                split_payload.append(
                    {
                        "client_id": int(client["client_id"]),
                        "split": split,
                        "path": relative,
                        "label": str(sample["label"]),
                    }
                )
    split_bytes = (json.dumps(split_payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
    split_manifest_path = path.with_name("split_manifest.json")
    split_manifest_path.write_bytes(split_bytes)
    geometry_files = []
    geometry_root = Path(config.geometry_outputs_dir) if config.geometry_outputs_dir else None
    if geometry_root and geometry_root.exists():
        for item in sorted(geometry_root.glob(f"*round_{config.round_id}.*")):
            if item.is_file():
                geometry_files.append(
                    {
                        "name": item.name,
                        "sha256": hashlib.sha256(item.read_bytes()).hexdigest(),
                    }
                )
    payload = {
        "created_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "entrypoint": str(Path(__file__).resolve()),
        "entrypoint_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "config_sha256": hashlib.sha256(
            json.dumps(asdict(config), sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest(),
        "split_manifest_sha256": hashlib.sha256(split_bytes).hexdigest(),
        "split_manifest_rows": len(split_payload),
        "split_manifest_file": split_manifest_path.name,
        "geometry_provider": geometry_provider,
        "geometry_files": geometry_files,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "numpy": np.__version__,
        "torch": str(torch.__version__),
        "candidate_pool_fixed_before_test": True,
        "test_used_for_selection": False,
        "shared_server_lora_initialization": True,
        "round_subspace_object": "received_to_trained_delta",
        "subspace_estimator": config.subspace_estimator,
        "subspace_ema_decay": config.subspace_ema_decay,
        "temporal_variance_proxy": (
            float(
                np.sum(
                    np.square(
                        np.asarray(
                            [
                                config.subspace_ema_decay ** (config.communication_rounds - 1 - index)
                                for index in range(config.communication_rounds)
                            ],
                            dtype=np.float64,
                        )
                        / np.sum(
                            [
                                config.subspace_ema_decay ** (config.communication_rounds - 1 - index)
                                for index in range(config.communication_rounds)
                            ]
                        )
                    )
                )
            )
            if config.subspace_estimator == "temporal-projector"
            else 1.0
        ),
    }
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _write_report(path: Path, metrics_rows: list[dict], subspace_rows: list[dict]) -> None:
    r_sub = subspace_rows[0].get("subspace_failure_pearson_r", "") if subspace_rows else ""
    lines = [
        "# Federated End-to-End CLIP ViT LoRA",
        "",
        "| Method | Mean accuracy | Worst-client risk | Conflict vs local |",
        "|---|---:|---:|---:|",
    ]
    for row in sorted(metrics_rows, key=lambda item: item["method"]):
        lines.append(
            f"| {row['method']} | {float(row['mean_accuracy']):.4f} | {float(row['worst_client_risk']):.4f} | {float(row['mean_update_conflict_vs_local']):.4f} |"
        )
    lines.extend(["", f"Subspace/failure Pearson r: {r_sub}", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def _write_blocker(output_dir: Path, config: Config, reason: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "blocker.json").write_text(json.dumps({"reason": reason, "config": asdict(config)}, indent=2), encoding="utf-8")
    _write_csv(output_dir / "metrics.csv", [{"method": "EndToEnd-Federated-CLIPViT-LoRA", "status": "blocked", "reason": reason}])


if __name__ == "__main__":
    raise SystemExit(main())
