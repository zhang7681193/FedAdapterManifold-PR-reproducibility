from __future__ import annotations

import argparse
import csv
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fedadaptermanifold.config import load_yaml, save_yaml_copy


DATASETS = {
    "pacs_resnet18": "configs/resolve_stage2_shrinkresidual_20260629/pacs_resnet18/seed_{seed}.yaml",
    "officehome_clip_full": "configs/resolve_stage2_shrinkresidual_20260629/officehome_clip_full/seed_{seed}.yaml",
    "officehome_dinov2_full": "configs/resolve_stage2_shrinkresidual_20260629/officehome_dinov2/seed_{seed}.yaml",
    "domainnetmini_clip_60class": "configs/resolve_stage2_shrinkresidual_20260629/domainnetmini_clip/seed_{seed}.yaml",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the theory-derived receiver-action transport audit.")
    parser.add_argument("--datasets", default="officehome_clip_full")
    parser.add_argument("--seeds", default="0,1")
    parser.add_argument("--output-root", default="results/decoupled_transport_audit_20260810")
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--recent-baselines", action="store_true")
    parser.add_argument(
        "--recent-lora-methods",
        default="all",
        help="Use fedsmooth for focused confirmation or all for the full fairness audit.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    datasets = [item.strip() for item in args.datasets.split(",") if item.strip()]
    seeds = [int(item.strip()) for item in args.seeds.split(",") if item.strip()]
    root = Path(args.output_root)
    config_root = root / "configs"
    log_root = root / "logs"
    config_root.mkdir(parents=True, exist_ok=True)
    log_root.mkdir(parents=True, exist_ok=True)
    for dataset_key in datasets:
        source_pattern = DATASETS[dataset_key]
        for seed in seeds:
            source = Path(source_pattern.format(seed=seed))
            config = load_yaml(source)
            output_dir = root / dataset_key / f"seed_{seed}"
            config.update(
                {
                    "output_dir": str(output_dir),
                    "seed": seed,
                    "run_decoupled_transport": True,
                    "decoupled_transport_modes": "core,column,row,tangent,full",
                    "decoupled_transport_candidates": "0,0.25,0.50,0.75,1.0",
                    "decoupled_transport_delta": 0.05,
                    "decoupled_transport_risk_tolerance": 0.0,
                    "decoupled_transport_confidence_bound": "paired-discordance",
                    "run_multiround_semantic_admission": True,
                    "run_path_admission": False,
                    "run_recent_lora_baselines": bool(args.recent_baselines),
                    "recent_lora_methods": str(args.recent_lora_methods),
                    "report_fedsmooth_rank_matched": bool(args.recent_baselines),
                    "run_cumulative_action_admission": bool(args.recent_baselines),
                    "skip_heavy_personalized_baselines": True,
                    "heterogeneity_setting": f"{config['heterogeneity_setting']}-decoupled-action-transport",
                }
            )
            prepared = config_root / dataset_key / f"seed_{seed}.yaml"
            prepared.parent.mkdir(parents=True, exist_ok=True)
            save_yaml_copy(prepared, config)
            if args.prepare_only:
                continue
            if (output_dir / "metrics.csv").exists() and not args.force:
                print(f"SKIP {dataset_key} seed={seed}", flush=True)
                continue
            log_path = log_root / f"{dataset_key}_seed_{seed}.log"
            print(f"RUN {dataset_key} seed={seed}", flush=True)
            command = [sys.executable, "-m", "fedadaptermanifold.run_experiment", "--config", str(prepared)]
            with log_path.open("w", encoding="utf-8") as log_file:
                completed = subprocess.run(command, stdout=log_file, stderr=subprocess.STDOUT, check=False)
            if completed.returncode != 0:
                raise RuntimeError(f"Run failed ({completed.returncode}); inspect {log_path}")
    _aggregate(root)
    return 0


def _aggregate(root: Path) -> None:
    rows: list[dict] = []
    for path in root.glob("*/seed_*/per_client_metrics.csv"):
        dataset_key = path.parents[1].name
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            current = list(csv.DictReader(handle))
        for row in current:
            row["audit_dataset"] = dataset_key
        rows.extend(current)
    if not rows:
        return
    fields = sorted({key for row in rows for key in row})
    with (root / "all_seed_per_client_metrics.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
