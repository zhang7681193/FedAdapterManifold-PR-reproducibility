from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.config import load_yaml, save_yaml_copy


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the training-fixed, prior-shift-robust direct-anchor audit."
    )
    parser.add_argument(
        "--source-root",
        type=Path,
        default=Path("results/direct_anchor_route_officehome_fedgeo_5seed_20260811/officehome_clip_full"),
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("results/direct_anchor_route_officehome_searchcert_shift_20260812"),
    )
    parser.add_argument("--seeds", default="0,1,2,3,4")
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    seeds = [int(value) for value in args.seeds.split(",") if value.strip()]
    config_root = args.output_root / "configs"
    log_root = args.output_root / "logs"
    config_root.mkdir(parents=True, exist_ok=True)
    log_root.mkdir(parents=True, exist_ok=True)
    for seed in seeds:
        source = args.source_root / f"seed_{seed}" / "config.yaml"
        config = load_yaml(source)
        output = args.output_root / "officehome_clip_full" / f"seed_{seed}"
        config.update(
            {
                "output_dir": str(output),
                "seed": seed,
                "calibration_shift_mode": "confidence-stratified",
                "calibration_shift_bins": 2,
                "calibration_shift_min_stratum_size": 1,
                "route_candidate_search_mode": "training-fixed",
                # The direct-anchor route is constructed from the declared
                # FedSmooth cumulative source.  Keep that single prerequisite
                # enabled; disabling all recent baselines silently removes the
                # direct-route branch and leaves only the generic transport
                # audit.
                "run_recent_lora_baselines": True,
                "recent_lora_methods": "fedsmooth",
                "anchor_residual_epochs": 0,
                "heterogeneity_setting": (
                    "office-home-domain-split-direct-anchor-training-fixed-prior-shift-audit"
                ),
            }
        )
        prepared = config_root / f"seed_{seed}.yaml"
        save_yaml_copy(prepared, config)
        if (output / "metrics.csv").exists() and not args.force:
            print(f"SKIP seed={seed}", flush=True)
            continue
        print(f"RUN seed={seed}", flush=True)
        with (log_root / f"seed_{seed}.log").open("w", encoding="utf-8") as stream:
            completed = subprocess.run(
                [sys.executable, "-m", "fedadaptermanifold.run_experiment", "--config", str(prepared)],
                stdout=stream,
                stderr=subprocess.STDOUT,
                check=False,
            )
        if completed.returncode != 0:
            raise RuntimeError(f"seed {seed} failed; inspect {log_root / f'seed_{seed}.log'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
