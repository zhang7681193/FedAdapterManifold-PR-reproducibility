from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fedadaptermanifold.config import load_yaml, save_yaml_copy


DATASETS = {
    "pacs_resnet18": {
        "source": "configs/resolve_stage2_shrinkresidual_20260629/pacs_resnet18/seed_{seed}.yaml",
        "rank": 8,
        "tail_start": 5,
    },
    "domainnetmini_clip_60class": {
        "source": "configs/resolve_stage2_shrinkresidual_20260629/domainnetmini_clip/seed_{seed}.yaml",
        "rank": 6,
        "tail_start": 4,
    },
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the pre-registered FedPissa equation-port comparison.")
    parser.add_argument("--datasets", default=",".join(DATASETS))
    parser.add_argument("--seeds", default="0,1,2,3,4")
    parser.add_argument(
        "--output-root",
        default=str(PROJECT_ROOT / "results" / "fedpissa_equation_port_crossdataset_5seed_20260813"),
    )
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    datasets = [item.strip() for item in args.datasets.split(",") if item.strip()]
    seeds = [int(item.strip()) for item in args.seeds.split(",") if item.strip()]
    if seeds != [0, 1, 2, 3, 4]:
        raise ValueError("The pre-registered confirmation requires seeds 0,1,2,3,4")
    unknown = set(datasets) - set(DATASETS)
    if unknown:
        raise ValueError(f"Unknown datasets: {sorted(unknown)}")

    output_root = Path(args.output_root).resolve()
    config_root = output_root / "configs"
    log_root = output_root / "logs"
    config_root.mkdir(parents=True, exist_ok=True)
    log_root.mkdir(parents=True, exist_ok=True)
    manifest = {
        "protocol_status": "pre-registered-before-test-evaluation",
        "datasets": datasets,
        "seeds": seeds,
        "round_budget_source": "unchanged canonical dataset config",
        "local_optimizer_source": "unchanged canonical dataset config",
        "fedpissa_lambda": 0.05,
        "fedpissa_aggregation_formula": (
            "B_agg=B_avg+lambda*sum_k p_k*(B_k-B_avg)*P_k"
        ),
        "communication_semantics": (
            "clients upload A and B for B aggregation and AA^T covariance; "
            "server broadcasts only aggregated B; A remains personalized"
        ),
        "tail_rule": "Rank 5 for rank 8; Rank 4 for rank 6 (second-half covariance tail)",
        "implementation_fidelity": "paper-equation-port-no-public-code",
        "primary_comparisons": [
            "FedPissa-EquationPort minus FedAvg-LoRA",
            "FedAdapterManifold-Selective minus FedPissa-EquationPort",
            "FedAdapterManifold-Admit minus FedPissa-EquationPort",
        ],
        "statistical_unit": "client nested within seed; seed-cluster bootstrap",
        "test_labels_used_for_selection": False,
        "source_hashes": {
            str(path.relative_to(PROJECT_ROOT)): _sha256(path)
            for path in (
                PROJECT_ROOT / "fedadaptermanifold" / "recent_lora_baselines.py",
                PROJECT_ROOT / "scripts" / "run_fedpissa_equation_port_confirmation.py",
                PROJECT_ROOT / "scripts" / "analyze_fedpissa_confirmation.py",
            )
        },
    }
    (output_root / "protocol_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True), encoding="utf-8"
    )
    child_env = os.environ.copy()
    child_env["PYTHONPATH"] = os.pathsep.join([str(PROJECT_ROOT), child_env.get("PYTHONPATH", "")])

    for dataset_key in datasets:
        spec = DATASETS[dataset_key]
        for seed in seeds:
            source = PROJECT_ROOT / str(spec["source"]).format(seed=seed)
            config = load_yaml(source)
            output_dir = output_root / dataset_key / f"seed_{seed}"
            rank = int(spec["rank"])
            config.update(
                {
                    "output_dir": str(output_dir),
                    "seed": seed,
                    "rank_policy": "fixed",
                    "rank": rank,
                    "min_rank": rank,
                    "max_rank": rank,
                    "run_recent_lora_baselines": True,
                    "recent_lora_methods": "fedpissa",
                    "fedpissa_lambda": 0.05,
                    "fedpissa_tail_start": int(spec["tail_start"]),
                    "skip_heavy_personalized_baselines": True,
                    "continue_on_failed_diagnostic": True,
                    "heterogeneity_setting": str(config["heterogeneity_setting"])
                    + "-fedpissa-equation-port-preregistered",
                }
            )
            prepared = config_root / dataset_key / f"seed_{seed}.yaml"
            save_yaml_copy(prepared, config)
            if args.prepare_only:
                continue
            if (output_dir / "metrics.csv").is_file() and not args.force:
                print(f"SKIP complete: {dataset_key} seed={seed}", flush=True)
                continue
            log_path = log_root / f"{dataset_key}_seed_{seed}.log"
            print(f"RUN {dataset_key} seed={seed}", flush=True)
            with log_path.open("w", encoding="utf-8") as log_file:
                completed = subprocess.run(
                    [sys.executable, "-m", "fedadaptermanifold.run_experiment", "--config", str(prepared)],
                    cwd=PROJECT_ROOT,
                    env=child_env,
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    check=False,
                )
            if completed.returncode != 0:
                raise RuntimeError(f"Run failed ({completed.returncode}); inspect {log_path}")
    _aggregate(output_root, datasets, seeds)
    return 0


def _aggregate(root: Path, datasets: list[str], seeds: list[int]) -> None:
    for filename in ["metrics.csv", "per_client_metrics.csv", "fedpissa_equation_port_history.csv"]:
        rows: list[dict] = []
        for dataset_key in datasets:
            for seed in seeds:
                path = root / dataset_key / f"seed_{seed}" / filename
                if not path.is_file():
                    continue
                with path.open("r", encoding="utf-8-sig", newline="") as handle:
                    for row in csv.DictReader(handle):
                        row["fairness_dataset_key"] = dataset_key
                        rows.append(row)
        if rows:
            fields = sorted({key for row in rows for key in row})
            with (root / f"all_seed_{filename}").open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=fields)
                writer.writeheader()
                writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
