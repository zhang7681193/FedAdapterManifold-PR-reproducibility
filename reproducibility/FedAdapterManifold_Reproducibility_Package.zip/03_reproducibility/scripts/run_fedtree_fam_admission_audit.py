from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.config import load_yaml, save_yaml_copy


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run fixed-protocol FedTree-anchor FAM residual admission on PACS."
    )
    parser.add_argument(
        "--source-root",
        type=Path,
        default=Path("results/fedtree_visual_audit_20260812/configs/pacs_resnet18"),
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("results/fedtree_fam_admission_pacs_20260812"),
    )
    parser.add_argument("--seeds", default="0,1,2,3,4")
    parser.add_argument(
        "--train-per-client",
        type=int,
        default=240,
        help="Total pre-split training-side cap (adapter training plus calibration).",
    )
    parser.add_argument(
        "--calibration-fraction",
        type=float,
        default=0.2,
        help="Predeclared held-out fraction of the training-side cap.",
    )
    parser.add_argument(
        "--calibration-shift-mode",
        choices=("marginal", "confidence-stratified"),
        default="marginal",
    )
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    seeds = [int(value) for value in args.seeds.split(",") if value.strip()]
    config_root = args.output_root / "configs"
    log_root = args.output_root / "logs"
    config_root.mkdir(parents=True, exist_ok=True)
    log_root.mkdir(parents=True, exist_ok=True)
    for seed in seeds:
        config = load_yaml(args.source_root / f"seed_{seed}.yaml")
        output = args.output_root / "pacs_resnet18" / f"seed_{seed}"
        config.update(
            {
                "output_dir": str(output),
                "seed": seed,
                "rank_policy": "fixed",
                "train_per_client": int(args.train_per_client),
                "candidate_selector_calibration_fraction": float(args.calibration_fraction),
                "candidate_selector_calibration_strategy": "stratified",
                "run_recent_lora_baselines": True,
                "recent_lora_methods": "fedtree",
                "run_anchor_residual_admission": True,
                "anchor_residual_admission_sources": "geo,subspace,bank",
                "route_candidate_search_mode": "training-fixed",
                "calibration_shift_mode": args.calibration_shift_mode,
                "calibration_shift_bins": 2,
                "calibration_shift_min_stratum_size": 1,
                "heterogeneity_setting": (
                    "pacs-domain-split-fedtree-anchor-fam-residual-admission-"
                    f"{args.calibration_shift_mode}-n{args.train_per_client}-"
                    f"cal{args.calibration_fraction:.6f}"
                ),
            }
        )
        prepared = config_root / f"seed_{seed}.yaml"
        save_yaml_copy(prepared, config)
        if (output / "metrics.csv").exists() and not args.force:
            print(f"SKIP seed={seed}", flush=True)
            continue
        print(f"RUN seed={seed}", flush=True)
        with (log_root / f"seed_{seed}.log").open("w", encoding="utf-8") as stream:
            completed = subprocess.run(
                [sys.executable, "-m", "fedadaptermanifold.run_experiment", "--config", str(prepared)],
                stdout=stream,
                stderr=subprocess.STDOUT,
                check=False,
            )
        if completed.returncode != 0:
            raise RuntimeError(f"seed {seed} failed; inspect {log_root / f'seed_{seed}.log'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
