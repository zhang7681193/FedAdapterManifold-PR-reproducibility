from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.config import load_yaml, save_yaml_copy


CONFIGS = {
    "pacs_resnet18": "configs/resolve_stage2_shrinkresidual_20260629/pacs_resnet18/seed_{seed}.yaml",
    "officehome_clip_full": "configs/resolve_stage2_shrinkresidual_20260629/officehome_clip_full/seed_{seed}.yaml",
    "domainnetmini_clip_60class": "configs/resolve_stage2_shrinkresidual_20260629/domainnetmini_clip/seed_{seed}.yaml",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the pinned FedTreeLoRA single-layer visual audit.")
    parser.add_argument("--datasets", default=",".join(CONFIGS))
    parser.add_argument("--seeds", default="0,1,2,3,4")
    parser.add_argument("--output-root", default="results/fedtree_visual_audit_20260812")
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    datasets = [item.strip() for item in args.datasets.split(",") if item.strip()]
    seeds = [int(item.strip()) for item in args.seeds.split(",") if item.strip()]
    unknown = sorted(set(datasets) - set(CONFIGS))
    if unknown:
        raise ValueError("Unknown datasets: " + ", ".join(unknown))

    root = Path(args.output_root)
    config_root = root / "configs"
    log_root = root / "logs"
    config_root.mkdir(parents=True, exist_ok=True)
    log_root.mkdir(parents=True, exist_ok=True)
    for dataset in datasets:
        for seed in seeds:
            config = load_yaml(Path(CONFIGS[dataset].format(seed=seed)))
            output_dir = root / dataset / f"seed_{seed}"
            config.update(
                {
                    "output_dir": str(output_dir),
                    "seed": seed,
                    "run_recent_lora_baselines": True,
                    "recent_lora_methods": "fedtree",
                    "fedtree_warmup_rounds": 5,
                    "fedtree_search_range_k": 3,
                    "fedtree_single_cluster_score": 0.02,
                    "fedtree_routing_candidates": "0,0.25,0.5,0.75,1.0",
                    # FedTree's official distance and expert recurrence assume
                    # a common LoRA shape.  Make that requirement explicit so
                    # every seed uses the same matched protocol instead of
                    # depending on whether a conflict-aware allocator happens
                    # to return equal ranks.
                    "rank_policy": "fixed",
                    "run_anchor_residual_admission": False,
                    "run_decoupled_transport": False,
                    "run_cumulative_action_admission": False,
                    "skip_heavy_personalized_baselines": True,
                    "continue_on_failed_diagnostic": True,
                    "heterogeneity_setting": f"{config['heterogeneity_setting']}-fedtree-official-port-audit",
                }
            )
            prepared = config_root / dataset / f"seed_{seed}.yaml"
            prepared.parent.mkdir(parents=True, exist_ok=True)
            save_yaml_copy(prepared, config)
            if args.prepare_only:
                continue
            if (output_dir / "metrics.csv").exists() and not args.force:
                print(f"SKIP {dataset} seed={seed}", flush=True)
                continue
            log_path = log_root / f"{dataset}_seed_{seed}.log"
            print(f"RUN {dataset} seed={seed}", flush=True)
            with log_path.open("w", encoding="utf-8") as log_file:
                completed = subprocess.run(
                    [sys.executable, "-m", "fedadaptermanifold.run_experiment", "--config", str(prepared)],
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    check=False,
                )
            if completed.returncode != 0:
                raise RuntimeError(f"Run failed ({completed.returncode}); inspect {log_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
