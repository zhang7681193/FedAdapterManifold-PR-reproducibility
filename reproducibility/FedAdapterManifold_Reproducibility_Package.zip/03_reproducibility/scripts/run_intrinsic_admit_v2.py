from __future__ import annotations

import argparse
import csv
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fedadaptermanifold.baselines import run_local_lora, summarize_method
from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.config import merge_defaults, save_yaml_copy
from fedadaptermanifold.decoupled_transport import (
    build_curvature_semantic_candidates,
    fit_residual_blockwise_action_endpoints,
    select_disagreement_localized_routes,
    select_dual_certified_prototype_bank_routes,
    select_fixed_intrinsic_candidate_pool,
    select_split_certified_residual_paths,
    split_calibration_client_views,
)
from fedadaptermanifold.diagnostics import (
    run_subspace_failure_diagnostic,
    write_subspace_diagnostic_artifacts,
)
from fedadaptermanifold.geometry import (
    FedGeoFileGeometryProvider,
    LocalPrototypeGeometry,
    label_distance_matrix,
    write_geometry_outputs,
)
from fedadaptermanifold.intrinsic_cumulative import run_intrinsic_cumulative_lift
from fedadaptermanifold.reporting import ensure_dir, write_csv
from fedadaptermanifold.run_experiment import _load_clients, _split_clients_for_candidate_selection


def main() -> int:
    parser = argparse.ArgumentParser(description="Lean no-test replay for intrinsic FAM-Admit v2.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--server-steps", default="")
    parser.add_argument("--lambda-subspace", type=float, default=None)
    parser.add_argument("--lambda-risk", type=float, default=None)
    parser.add_argument("--top-k", type=int, default=None)
    parser.add_argument("--correction-scale", type=float, default=None)
    parser.add_argument("--target-rank", type=int, default=None)
    parser.add_argument("--risk-tolerance", type=float, default=None)
    parser.add_argument("--competitive-tolerance", type=float, default=None)
    parser.add_argument("--selection-fraction", type=float, default=0.5)
    parser.add_argument("--mixture-kl", type=float, default=0.05)
    parser.add_argument("--donor-source", choices=("local", "cumulative"), default="local")
    parser.add_argument("--geometry-dir", default="")
    parser.add_argument("--reuse-dir", default="")
    parser.add_argument(
        "--diagnostics-only",
        action="store_true",
        help="Reuse or train Local-LoRA, write the subspace/failure diagnostic, and stop before candidate construction.",
    )
    cli = parser.parse_args()

    config = merge_defaults(cli.config)
    if cli.seed is not None:
        config["seed"] = int(cli.seed)
    if cli.server_steps:
        config["cumulative_server_step_candidates"] = cli.server_steps
    if cli.lambda_subspace is not None:
        config["cumulative_semantic_lambda_subspace"] = float(cli.lambda_subspace)
    if cli.lambda_risk is not None:
        config["cumulative_semantic_lambda_risk"] = float(cli.lambda_risk)
    if cli.top_k is not None:
        config["cumulative_semantic_top_k"] = int(cli.top_k)
    if cli.correction_scale is not None:
        config["cumulative_semantic_correction_scale"] = float(cli.correction_scale)
    if cli.target_rank is not None:
        config["cumulative_semantic_target_rank"] = int(cli.target_rank)
    if cli.risk_tolerance is not None:
        config["decoupled_transport_risk_tolerance"] = float(cli.risk_tolerance)
    if cli.geometry_dir:
        config["geometry_outputs_dir"] = str(cli.geometry_dir)
    config["output_dir"] = str(cli.output_dir)
    args = SimpleNamespace(**config)

    output_dir = ensure_dir(cli.output_dir)
    clients, base_weight, class_names = _load_clients(args)
    clients, selector_clients, calibration_rows = _split_clients_for_candidate_selection(
        clients,
        fraction=float(args.candidate_selector_calibration_fraction),
        strategy=str(args.candidate_selector_calibration_strategy),
        seed=int(args.seed),
    )
    geometry_dir = str(getattr(args, "geometry_outputs_dir", "") or getattr(args, "fedgeo_dir", ""))
    geometry_round = int(getattr(args, "round_id", getattr(args, "geometry_round", 0)))
    provider = FedGeoFileGeometryProvider(geometry_dir) if geometry_dir else LocalPrototypeGeometry()
    geometry = provider.build(clients, num_classes=base_weight.shape[0], round_id=geometry_round)
    write_geometry_outputs(output_dir / "geometry_outputs", geometry, round_id=geometry_round)

    n_clients = len(clients)
    selection_clients, certification_clients, certification_split_rows = split_calibration_client_views(
        selector_clients,
        fraction=float(cli.selection_fraction),
        seed=int(args.seed),
    )
    ranks = [int(args.rank)] * n_clients
    reuse_dir = Path(cli.reuse_dir) if cli.reuse_dir else None
    if reuse_dir is not None:
        local_deltas = np.load(reuse_dir / "local_anchor_deltas.npy")
        if local_deltas.shape[0] != n_clients:
            raise ValueError("Reuse artifacts do not align with the loaded clients")
        local = SimpleNamespace(
            adapters=[
                LoRAAdapter.from_delta(delta, rank=int(rank), alpha=float(rank), name=f"reused_local_{idx}")
                for idx, (delta, rank) in enumerate(zip(local_deltas, ranks))
            ],
            per_client_metrics=_read_method_rows(reuse_dir / "per_client_metrics.csv", "Local-LoRA"),
        )
        if cli.donor_source == "cumulative":
            client_streams = np.load(reuse_dir / "intrinsic_cumulative_client_deltas.npy")
            cumulative_delta = np.load(reuse_dir / "intrinsic_cumulative_delta.npy")
            projection_residual = np.load(reuse_dir / "intrinsic_cumulative_projection_residual.npy")
            if client_streams.shape[0] != n_clients:
                raise ValueError("Reused cumulative streams do not align with clients")
            exact_rank = int(min(cumulative_delta.shape))
            stream = SimpleNamespace(
                effective_adapter=LoRAAdapter.from_delta(
                    cumulative_delta,
                    rank=exact_rank,
                    alpha=float(exact_rank),
                    name="reused_intrinsic_cumulative",
                ),
                cumulative_base_delta=cumulative_delta,
                client_cumulative_deltas=[delta for delta in client_streams],
                cumulative_projection_residual=projection_residual,
                per_client_metrics=_read_method_rows(reuse_dir / "per_client_metrics.csv", "Intrinsic-Cumulative-Lift"),
                round_history=_read_csv_rows(reuse_dir / "intrinsic_cumulative_history.csv"),
            )
        else:
            stream = None
    else:
        local = run_local_lora(
            clients,
            base_weight,
            ranks=ranks,
            epochs=int(args.rounds) * int(args.local_epochs),
            lr=float(args.lr),
            batch_size=int(args.batch_size),
            seed=int(args.seed),
            dataset=str(args.dataset),
            heterogeneity_setting=str(args.heterogeneity_setting),
            round_id=int(args.rounds),
        )
        stream = None
        if cli.donor_source == "cumulative":
            stream = run_intrinsic_cumulative_lift(
                clients,
                base_weight,
                ranks=ranks,
                rounds=int(args.rounds),
                local_epochs=int(args.local_epochs),
                lr=float(args.lr),
                batch_size=int(args.batch_size),
                seed=int(args.seed),
                dataset=str(args.dataset),
                heterogeneity_setting=str(args.heterogeneity_setting),
                server_step_candidates=str(args.cumulative_server_step_candidates),
                warm_start_subspace=bool(args.cumulative_subspace_warm_start),
            )
    d_label = label_distance_matrix(clients, base_weight.shape[0])
    if cli.diagnostics_only:
        diagnostic = run_subspace_failure_diagnostic(
            clients=clients,
            base_weight=base_weight,
            local_adapters=local.adapters,
            d_geo=geometry.d_geo,
            d_label=d_label,
            lambda_geo=float(args.lambda_geo),
            lambda_label=float(args.lambda_label),
            tau=float(args.tau),
            diagnostic_threshold=float(args.diagnostic_threshold),
        )
        write_subspace_diagnostic_artifacts(
            diagnostic,
            clients,
            geometry.d_geo,
            output_dir,
        )
        metrics = summarize_method(local.per_client_metrics)
        effective_config = dict(config)
        effective_config.update(
            {
                "effective_num_clients": n_clients,
                "effective_num_classes": int(base_weight.shape[0]),
                "effective_feature_dim": int(base_weight.shape[1]),
                "effective_class_names": class_names,
                "diagnostics_only": True,
                "diagnostic_reused_local_updates": bool(reuse_dir is not None),
                "candidate_pool_fixed_pretest": True,
                "test_used_for_selection": False,
            }
        )
        save_yaml_copy(output_dir / "config.yaml", effective_config)
        write_csv(output_dir / "metrics.csv", metrics)
        write_csv(output_dir / "per_client_metrics.csv", local.per_client_metrics)
        write_csv(output_dir / "candidate_selector_calibration.csv", calibration_rows)
        write_csv(output_dir / "calibration_selection_certification_split.csv", certification_split_rows)
        write_csv(
            output_dir / "diagnostic_summary.csv",
            [
                {
                    "seed": int(args.seed),
                    "dataset": str(args.dataset),
                    "heterogeneity_setting": str(args.heterogeneity_setting),
                    "n_clients": n_clients,
                    "n_directional_pairs": len(diagnostic.conflict_rows),
                    "subspace_failure_pearson_r": diagnostic.pearson_r,
                    "subspace_semantic_loss_pearson_r": diagnostic.subspace_semantic_loss_pearson_r,
                    "diagnostic_passed": diagnostic.passed,
                }
            ],
        )
        np.save(output_dir / "local_anchor_deltas.npy", np.stack([adapter.delta() for adapter in local.adapters]))
        return 0
    sample_prior = np.asarray([max(len(client.x_train), 1) for client in clients], dtype=np.float64)
    sample_prior /= sample_prior.sum()
    if cli.donor_source == "local":
        donor_deltas = [adapter.delta() for adapter in local.adapters]
        full_center_delta = sum(
            float(weight) * delta for weight, delta in zip(sample_prior, donor_deltas)
        )
        algebraic_residual = np.zeros_like(full_center_delta)
        exact_rank = int(max(np.linalg.matrix_rank(full_center_delta), 1))
        full_center_adapter = LoRAAdapter.from_delta(
            full_center_delta,
            rank=exact_rank,
            alpha=float(exact_rank),
            name="local_update_full_lift_control",
        )
    else:
        if stream is None:
            raise ValueError("cumulative donor source requires an intrinsic cumulative stream")
        donor_deltas = stream.client_cumulative_deltas
        algebraic_residual = stream.cumulative_projection_residual
        exact_rank = int(stream.effective_adapter.rank)
        full_center_adapter = stream.effective_adapter
    full_center_delta = full_center_adapter.delta()
    configured_rank = int(args.cumulative_semantic_target_rank)
    target_rank = exact_rank if configured_rank <= 0 else min(configured_rank, exact_rank)
    semantic_endpoints, semantic_rows = build_curvature_semantic_candidates(
        training_clients=clients,
        base_weight=base_weight,
        receivers=local.adapters,
        donor_cumulative_deltas=donor_deltas,
        algebraic_residual=algebraic_residual,
        prior_weights=sample_prior,
        graph=geometry.graph,
        d_geo=geometry.d_geo,
        label_distance=d_label,
        tau=float(args.tau),
        lambda_subspace=float(args.cumulative_semantic_lambda_subspace),
        lambda_geo=float(args.lambda_geo),
        lambda_label=float(args.lambda_label),
        lambda_risk=float(args.cumulative_semantic_lambda_risk),
        self_weight=float(args.adapter_graph_self_weight),
        top_k_neighbors=int(args.cumulative_semantic_top_k),
        correction_scale=float(args.cumulative_semantic_correction_scale),
        optimize_joint_mixture=True,
        mixture_kl_strength=float(cli.mixture_kl),
        mixture_clients=clients,
        semantic_anchor_deltas=[adapter.delta() for adapter in local.adapters],
        target_ranks=[target_rank] * n_clients,
    )
    full_endpoints = [full_center_adapter for _ in clients]
    blockwise, scalar_controls, fit_rows = fit_residual_blockwise_action_endpoints(
        training_clients=clients,
        base_weight=base_weight,
        receiver_adapters=local.adapters,
        center_endpoints=local.adapters,
        residual_source_families={"semantic_stream": semantic_endpoints},
        ranks=[target_rank] * n_clients,
    )
    meta_semantic_endpoints, meta_semantic_rows = build_curvature_semantic_candidates(
        training_clients=clients,
        base_weight=base_weight,
        receivers=local.adapters,
        donor_cumulative_deltas=donor_deltas,
        algebraic_residual=algebraic_residual,
        prior_weights=sample_prior,
        graph=geometry.graph,
        d_geo=geometry.d_geo,
        label_distance=d_label,
        tau=float(args.tau),
        lambda_subspace=float(args.cumulative_semantic_lambda_subspace),
        lambda_geo=float(args.lambda_geo),
        lambda_label=float(args.lambda_label),
        lambda_risk=float(args.cumulative_semantic_lambda_risk),
        self_weight=float(args.adapter_graph_self_weight),
        top_k_neighbors=int(args.cumulative_semantic_top_k),
        correction_scale=float(args.cumulative_semantic_correction_scale),
        optimize_joint_mixture=True,
        mixture_kl_strength=float(cli.mixture_kl),
        mixture_clients=selection_clients,
        semantic_anchor_deltas=[adapter.delta() for adapter in local.adapters],
        target_ranks=[target_rank] * n_clients,
        name_prefix="FedAdapterManifold-SplitMetaSemantic",
    )
    meta_blockwise, _, meta_fit_rows = fit_residual_blockwise_action_endpoints(
        training_clients=selection_clients,
        base_weight=base_weight,
        receiver_adapters=local.adapters,
        center_endpoints=local.adapters,
        residual_source_families={"split_meta_semantic": meta_semantic_endpoints},
        ranks=[target_rank] * n_clients,
        name_prefix="FedAdapterManifold-SplitMetaResidual",
    )
    donor_costs = np.zeros((n_clients, n_clients), dtype=np.float64)
    donor_support = np.zeros((n_clients, n_clients), dtype=bool)
    for row in semantic_rows:
        receiver_index = int(row["receiver_index"])
        donor_index = int(row["donor_index"])
        donor_costs[receiver_index, donor_index] = float(row["combined_cost"])
        donor_support[receiver_index, donor_index] = bool(row["selected_by_top_k"])
    bank_sources: dict[str, list[LoRAAdapter]] = {}
    correction_scale = float(args.cumulative_semantic_correction_scale)
    for donor_index, donor_delta in enumerate(donor_deltas):
        family = f"donor_{donor_index}"
        bank_sources[family] = []
        for receiver_index, anchor in enumerate(local.adapters):
            correction = (
                np.asarray(donor_delta, dtype=np.float64) - full_center_delta
                if donor_index != receiver_index and donor_support[receiver_index, donor_index]
                else np.zeros_like(full_center_delta)
            )
            endpoint_delta = anchor.delta() + correction_scale * correction
            bank_sources[family].append(
                LoRAAdapter.from_delta(
                    endpoint_delta,
                    rank=target_rank,
                    alpha=float(target_rank),
                    name=f"prototype_bank_{family}_receiver_{receiver_index}",
                )
            )
    fitted_bank: dict[str, list[LoRAAdapter]] = {}
    bank_fit_rows: list[dict] = []
    for family, endpoints in bank_sources.items():
        fitted_family, _, family_rows = fit_residual_blockwise_action_endpoints(
            training_clients=clients,
            base_weight=base_weight,
            receiver_adapters=local.adapters,
            center_endpoints=local.adapters,
            residual_source_families={family: endpoints},
            ranks=[target_rank] * n_clients,
            name_prefix=f"FedAdapterManifold-PrototypeBank-{family}",
        )
        fitted_bank[family] = fitted_family
        bank_fit_rows.extend(family_rows)
    fixed_full_controls = [
        LoRAAdapter.from_delta(
            full_center_delta,
            rank=target_rank,
            alpha=float(target_rank),
            name=f"rank_matched_full_control_client_{client_index}",
        )
        for client_index in range(n_clients)
    ]
    fixed_intrinsic_admit = select_fixed_intrinsic_candidate_pool(
        selector_clients=selector_clients,
        eval_clients=clients,
        base_weight=base_weight,
        anchor_adapters=local.adapters,
        candidate_families={"fam_receiver_relative": blockwise},
        candidate_priority=("local_anchor", "fam_receiver_relative"),
        tie_tolerance=float(args.candidate_selector_loss_tolerance),
        delta=float(args.decoupled_transport_delta),
        diagnostic_risk_tolerance=float(args.decoupled_transport_risk_tolerance),
        seed=int(args.seed),
        dataset=str(args.dataset),
        heterogeneity_setting=str(args.heterogeneity_setting),
        round_id=int(args.rounds),
        method="FedAdapterManifold-ReceiverRelativeAdmit",
    )
    split_meta_admit = select_fixed_intrinsic_candidate_pool(
        selector_clients=certification_clients,
        eval_clients=clients,
        base_weight=base_weight,
        anchor_adapters=local.adapters,
        candidate_families={"fam_split_meta": meta_blockwise},
        candidate_priority=("local_anchor", "fam_split_meta"),
        tie_tolerance=float(args.candidate_selector_loss_tolerance),
        delta=float(args.decoupled_transport_delta),
        diagnostic_risk_tolerance=float(args.decoupled_transport_risk_tolerance),
        seed=int(args.seed),
        dataset=str(args.dataset),
        heterogeneity_setting=str(args.heterogeneity_setting),
        round_id=int(args.rounds),
        method="FedAdapterManifold-SplitMetaTargetParetoAdmit",
        selection_policy="target_pareto",
    )
    fixed_intrinsic_pool = select_fixed_intrinsic_candidate_pool(
        selector_clients=selector_clients,
        eval_clients=clients,
        base_weight=base_weight,
        anchor_adapters=local.adapters,
        candidate_families={
            "fam_receiver_relative": blockwise,
            "full_control": fixed_full_controls,
        },
        candidate_priority=("local_anchor", "fam_receiver_relative", "full_control"),
        tie_tolerance=float(args.candidate_selector_loss_tolerance),
        delta=float(args.decoupled_transport_delta),
        diagnostic_risk_tolerance=float(args.decoupled_transport_risk_tolerance),
        seed=int(args.seed),
        dataset=str(args.dataset),
        heterogeneity_setting=str(args.heterogeneity_setting),
        round_id=int(args.rounds),
        method="IntrinsicPool-WithUnscreenedFull-Control",
    )
    competitive_tolerance = (
        float(args.decoupled_transport_risk_tolerance)
        if cli.competitive_tolerance is None
        else float(cli.competitive_tolerance)
    )
    method, full_control = select_split_certified_residual_paths(
        selector_clients=selector_clients,
        eval_clients=clients,
        base_weight=base_weight,
        anchor_adapters=local.adapters,
        full_endpoints=full_endpoints,
        residual_endpoints=blockwise,
        ranks=[target_rank] * n_clients,
        path=str(args.decoupled_transport_candidates),
        delta=float(args.decoupled_transport_delta),
        risk_tolerance=float(args.decoupled_transport_risk_tolerance),
        competitive_tolerance=competitive_tolerance,
        selection_fraction=float(cli.selection_fraction),
        selection_clients=selection_clients,
        certification_clients=certification_clients,
        seed=int(args.seed),
        dataset=str(args.dataset),
        heterogeneity_setting=str(args.heterogeneity_setting),
        round_id=int(args.rounds),
        method="FedAdapterManifold-ResidualAdmit",
        control_method="IntrinsicFull-SplitCertifiedControl",
    )
    scalar_control, _ = select_split_certified_residual_paths(
        selector_clients=selector_clients,
        eval_clients=clients,
        base_weight=base_weight,
        anchor_adapters=local.adapters,
        full_endpoints=full_endpoints,
        residual_endpoints=scalar_controls,
        ranks=[target_rank] * n_clients,
        path=str(args.decoupled_transport_candidates),
        delta=float(args.decoupled_transport_delta),
        risk_tolerance=float(args.decoupled_transport_risk_tolerance),
        competitive_tolerance=competitive_tolerance,
        selection_fraction=float(cli.selection_fraction),
        selection_clients=selection_clients,
        certification_clients=certification_clients,
        seed=int(args.seed),
        dataset=str(args.dataset),
        heterogeneity_setting=str(args.heterogeneity_setting),
        round_id=int(args.rounds),
        method="IntrinsicScalarResidual-Control",
        control_method="IntrinsicFull-ScalarReference",
    )
    routed_method = select_disagreement_localized_routes(
        training_clients=selection_clients,
        selector_clients=certification_clients,
        eval_clients=clients,
        base_weight=base_weight,
        anchor_adapters=local.adapters,
        full_endpoints=full_endpoints,
        blockwise_endpoints=blockwise,
        full_control=full_control,
        ranks=[target_rank] * n_clients,
        prototype_maps=geometry.prototypes,
        path=[1.0],
        quantiles=(0.0, 0.25, 0.5, 0.75),
        delta=float(args.decoupled_transport_delta),
        risk_tolerance=float(args.decoupled_transport_risk_tolerance),
        seed=int(args.seed),
        dataset=str(args.dataset),
        heterogeneity_setting=str(args.heterogeneity_setting),
        round_id=int(args.rounds),
        method="FedAdapterManifold-DualCertifiedPrototypeRoute",
        safety_reference="both",
    )
    prototype_bank_method = select_dual_certified_prototype_bank_routes(
        selection_clients=selection_clients,
        certification_clients=certification_clients,
        eval_clients=clients,
        base_weight=base_weight,
        anchor_adapters=local.adapters,
        full_control=full_control,
        bank_families=fitted_bank,
        donor_costs=donor_costs,
        donor_support=donor_support,
        ranks=[target_rank] * n_clients,
        prototype_maps=geometry.prototypes,
        threshold_quantiles=(0.90, 0.95, 0.975),
        delta=float(args.decoupled_transport_delta),
        risk_tolerance=float(args.decoupled_transport_risk_tolerance),
        competitive_tolerance=competitive_tolerance,
        compatibility_cost_weight=0.25,
        seed=int(args.seed),
        dataset=str(args.dataset),
        heterogeneity_setting=str(args.heterogeneity_setting),
        round_id=int(args.rounds),
    )

    per_client = []
    per_client.extend(local.per_client_metrics)
    if stream is not None:
        per_client.extend(stream.per_client_metrics)
    per_client.extend(method.per_client_metrics)
    per_client.extend(fixed_intrinsic_admit.per_client_metrics)
    per_client.extend(split_meta_admit.per_client_metrics)
    per_client.extend(fixed_intrinsic_pool.per_client_metrics)
    per_client.extend(routed_method.per_client_metrics)
    per_client.extend(prototype_bank_method.per_client_metrics)
    per_client.extend(scalar_control.per_client_metrics)
    per_client.extend(full_control.per_client_metrics)
    metrics = summarize_method(per_client)
    for row in metrics:
        row["communication_rank"] = int(args.rank)
        row["deployment_rank"] = int(
            target_rank
            if row["method"] in {
                "FedAdapterManifold-ResidualAdmit",
                "IntrinsicScalarResidual-Control",
                "IntrinsicFull-SplitCertifiedControl",
                "FedAdapterManifold-DualCertifiedPrototypeRoute",
                "FedAdapterManifold-DualCertifiedPrototypeBank",
                "FedAdapterManifold-ReceiverRelativeAdmit",
                "FedAdapterManifold-SplitMetaTargetParetoAdmit",
                "IntrinsicPool-WithUnscreenedFull-Control",
            }
            else row.get("deployment_rank", args.rank)
        )
        row["candidate_pool_fixed_pretest"] = True
        row["test_used_for_selection"] = False

    effective_config = dict(config)
    effective_config.update(
        {
            "effective_num_clients": n_clients,
            "effective_num_classes": int(base_weight.shape[0]),
            "effective_feature_dim": int(base_weight.shape[1]),
            "effective_class_names": class_names,
            "cumulative_exact_rank": exact_rank,
            "cumulative_target_rank": target_rank,
            "candidate_pool_fixed_pretest": True,
            "test_used_for_selection": False,
            "residual_fit_mode": "fixed_center_blockwise",
            "calibration_selection_fraction": float(cli.selection_fraction),
            "competitive_risk_tolerance": competitive_tolerance,
            "joint_mixture_kl_strength": float(cli.mixture_kl),
            "semantic_donor_source": str(cli.donor_source),
        }
    )
    save_yaml_copy(output_dir / "config.yaml", effective_config)
    write_csv(output_dir / "metrics.csv", metrics)
    write_csv(output_dir / "per_client_metrics.csv", per_client)
    write_csv(output_dir / "candidate_selector_calibration.csv", calibration_rows)
    write_csv(output_dir / "calibration_selection_certification_split.csv", certification_split_rows)
    if stream is not None:
        write_csv(output_dir / "intrinsic_cumulative_history.csv", stream.round_history)
    write_csv(output_dir / "curvature_semantic_weights.csv", semantic_rows)
    write_csv(output_dir / "split_meta_semantic_weights.csv", meta_semantic_rows)
    write_csv(output_dir / "blockwise_training_fit.csv", fit_rows)
    write_csv(output_dir / "split_meta_training_fit.csv", meta_fit_rows)
    write_csv(output_dir / "prototype_bank_training_fit.csv", bank_fit_rows)
    write_csv(output_dir / "intrinsic_curvature_admission.csv", method.admission_rows)
    write_csv(
        output_dir / "fixed_intrinsic_admit.csv",
        fixed_intrinsic_admit.admission_rows,
    )
    write_csv(
        output_dir / "split_meta_admit.csv",
        split_meta_admit.admission_rows,
    )
    write_csv(
        output_dir / "fixed_intrinsic_pool_admission.csv",
        fixed_intrinsic_pool.admission_rows,
    )
    write_csv(output_dir / "intrinsic_scalar_residual_control_admission.csv", scalar_control.admission_rows)
    write_csv(output_dir / "prototype_residual_route_admission.csv", routed_method.admission_rows)
    write_csv(output_dir / "prototype_residual_routing.csv", routed_method.routing_rows)
    write_csv(output_dir / "prototype_bank_admission.csv", prototype_bank_method.admission_rows)
    write_csv(output_dir / "prototype_bank_routing.csv", prototype_bank_method.routing_rows)
    write_csv(output_dir / "intrinsic_full_control_admission.csv", full_control.admission_rows)
    if stream is not None:
        np.save(output_dir / "intrinsic_cumulative_delta.npy", stream.cumulative_base_delta)
        np.save(output_dir / "intrinsic_cumulative_client_deltas.npy", np.stack(stream.client_cumulative_deltas))
        np.save(output_dir / "intrinsic_cumulative_projection_residual.npy", stream.cumulative_projection_residual)
    np.save(output_dir / "local_anchor_deltas.npy", np.stack([adapter.delta() for adapter in local.adapters]))
    return 0


def _read_csv_rows(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _read_method_rows(path: Path, method: str) -> list[dict]:
    rows = [row for row in _read_csv_rows(path) if row.get("method") == method]
    for row in rows:
        for key in ("seed", "round", "rank", "effective_rank", "deployment_rank"):
            if row.get(key, "") != "":
                row[key] = int(float(row[key]))
        for key in ("accuracy", "loss"):
            row[key] = float(row[key])
    return rows


if __name__ == "__main__":
    raise SystemExit(main())
