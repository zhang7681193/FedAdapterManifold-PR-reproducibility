from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "run_clip_vit_lora_federated_main.py"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _command(
    python: str,
    *,
    seed: int,
    output_dir: Path,
    geometry_dir: Path,
    data_root: Path,
    class_label_map: Path,
) -> list[str]:
    return [
        python,
        str(RUNNER),
        "--data-root", str(data_root),
        "--output-dir", str(output_dir),
        "--dataset", "OfficeHome-65",
        "--domains", "Art,Clipart,Product,Real_World",
        "--num-classes", "65",
        "--train-per-class", "8",
        "--test-per-class", "8",
        "--calibration-fraction", "0.25",
        "--communication-rounds", "5",
        "--local-epochs", "1",
        "--batch-size", "16",
        "--rank", "4",
        "--lr", "0.0005",
        "--seed", str(seed),
        "--device", "cuda",
        "--model-name", "ViT-B/32",
        "--lora-blocks", "2",
        "--prompt-template", "a photo of a {label}.",
        "--class-label-map", str(class_label_map),
        "--geometry-outputs-dir", str(geometry_dir),
        "--round-id", "4",
        "--graph-k", "2",
        "--subspace-estimator", "final-residual",
        "--subspace-ema-decay", "1.0",
    ]


def _read_methods(path: Path) -> set[tuple[str, str]]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return {(row["method"], row["client_id"]) for row in csv.DictReader(handle)}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Frozen OfficeHome confirmation baselines")
    parser.add_argument("--geometry-root", required=True)
    parser.add_argument("--registry", required=True)
    parser.add_argument("--manifest-root", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--class-label-map", required=True)
    parser.add_argument("--python", default=sys.executable)
    args = parser.parse_args(argv)

    geometry_root = Path(args.geometry_root).resolve()
    registry_path = Path(args.registry).resolve()
    manifest_root = Path(args.manifest_root).resolve()
    output_root = Path(args.output_root)
    data_root = Path(args.data_root).resolve()
    class_label_map = Path(args.class_label_map).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    if registry.get("seeds") != [10, 11, 12, 13, 14]:
        raise ValueError("confirmation registry must contain exactly seeds 10--14")

    snapshots = {int(item["seed"]): item for item in registry["snapshots"]}
    geometry_dirs: dict[int, Path] = {}
    manifest_hashes: dict[int, str] = {}
    geometry_hashes: dict[int, dict[str, str]] = {}
    for seed in range(10, 15):
        snapshot = snapshots[seed]
        geometry_dir = geometry_root / snapshot["relative_geometry_outputs"]
        metadata = json.loads(
            (manifest_root / f"seed_{seed}" / "manifest_metadata.json").read_text(
                encoding="utf-8"
            )
        )
        if snapshot["training_manifest_sha256"] != metadata["fedgeo_training_manifest_sha256"]:
            raise ValueError(f"seed {seed} training-manifest hash mismatch")
        for name, expected in snapshot["output_sha256"].items():
            if _sha256(geometry_dir / name) != expected:
                raise ValueError(f"seed {seed} geometry hash mismatch for {name}")
        geometry_dirs[seed] = geometry_dir
        manifest_hashes[seed] = snapshot["training_manifest_sha256"]
        geometry_hashes[seed] = dict(snapshot["output_sha256"])

    protocol = {
        "protocol": "officehome65_clip_confirmation_baselines_v1",
        "frozen_before_results": True,
        "seeds": list(range(10, 15)),
        "methods": [
            "Local-CLIP-LoRA",
            "FedAvg-CLIP-LoRA",
            "FedAvg-Lift-CLIP-LoRA",
            "FedGeo-Agg-CLIP-LoRA",
            "FedAdapterManifold-CLIP-LoRA",
        ],
        "hyperparameters": {
            "model": "CLIP ViT-B/32 attention LoRA",
            "rounds": 5,
            "local_epochs": 1,
            "rank": 4,
            "train_per_class": 8,
            "test_per_class": 8,
            "calibration_fraction": 0.25,
            "graph_k": 2,
            "round_id": 4,
        },
        "runner_sha256": _sha256(RUNNER),
        "registry_sha256": _sha256(registry_path),
        "class_label_map_sha256": _sha256(class_label_map),
        "training_manifest_sha256": manifest_hashes,
        "geometry_output_sha256": geometry_hashes,
        "test_used_for_selection": False,
    }
    protocol_path = output_root / "frozen_baseline_protocol.json"
    if protocol_path.exists():
        existing = json.loads(protocol_path.read_text(encoding="utf-8"))
        if existing != protocol:
            raise ValueError("existing baseline protocol differs from the frozen protocol")
    else:
        protocol_path.write_text(json.dumps(protocol, indent=2) + "\n", encoding="utf-8")

    for seed in range(10, 15):
        output_dir = output_root / f"seed_{seed}"
        metrics_path = output_dir / "per_client_metrics.csv"
        if not metrics_path.exists():
            subprocess.run(
                _command(
                    args.python,
                    seed=seed,
                    output_dir=output_dir,
                    geometry_dir=geometry_dirs[seed],
                    data_root=data_root,
                    class_label_map=class_label_map,
                ),
                cwd=ROOT,
                check=True,
            )
        methods = _read_methods(metrics_path)
        required = {
            (method, str(client_id))
            for method in protocol["methods"]
            for client_id in range(4)
        }
        if not required.issubset(methods):
            raise ValueError(f"seed {seed} baseline output is incomplete")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
