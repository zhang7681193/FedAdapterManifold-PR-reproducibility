from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path

import numpy as np
import yaml


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "run_clip_vit_lora_federated_main.py"
THEORY = ROOT / "docs" / "function_space_semantic_transport_20260815.md"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _as_bool(value) -> bool:
    return str(value).strip().lower() == "true"


def _command(python: str, config: dict, output_dir: Path) -> list[str]:
    command = [
        python,
        str(RUNNER),
        "--data-root", str(config["data_root"]),
        "--output-dir", str(output_dir),
        "--dataset", str(config["dataset"]),
        "--domains", str(config["domains"]),
        "--num-classes", str(config["num_classes"]),
        "--train-per-class", str(config["train_per_class"]),
        "--test-per-class", str(config["test_per_class"]),
        "--calibration-fraction", str(config["calibration_fraction"]),
        "--communication-rounds", str(config["communication_rounds"]),
        "--local-epochs", str(config["local_epochs"]),
        "--batch-size", str(config["batch_size"]),
        "--rank", str(config["rank"]),
        "--lr", str(config["lr"]),
        "--seed", str(config["seed"]),
        "--device", str(config["device"]),
        "--model-name", str(config["model_name"]),
        "--lora-blocks", str(config["lora_blocks"]),
        "--prompt-template", str(config["prompt_template"]),
        "--geometry-outputs-dir", str(config["geometry_outputs_dir"]),
        "--round-id", str(config["round_id"]),
        "--graph-k", str(config["graph_k"]),
        "--subspace-estimator", str(config["subspace_estimator"]),
        "--subspace-ema-decay", str(config["subspace_ema_decay"]),
        "--source-coverage-audit",
        "--source-coverage-only",
        "--function-transport-admission",
        "--function-transport-kl-strength", "0.01",
        "--function-transport-fold-temperature", "0.05",
        "--function-transport-distill-epochs", "4",
        "--function-transport-distill-lr", "0.0001",
        "--function-transport-distill-weight", "1.0",
        "--function-transport-anchor-weight", "0.25",
        "--function-transport-prototype-temperature", "0.1",
        "--function-transport-certificate-alpha", "0.0125",
    ]
    if str(config.get("class_label_map", "")):
        command.extend(["--class-label-map", str(config["class_label_map"])])
    return command


def _bootstrap_seed_ci(seed_values: dict[int, float], draws: int = 20000) -> tuple[float, float]:
    values = np.asarray([seed_values[key] for key in sorted(seed_values)], dtype=np.float64)
    rng = np.random.default_rng(20260815)
    samples = values[rng.integers(0, values.size, size=(draws, values.size))].mean(axis=1)
    return float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Frozen OfficeHome CLIP function-transport development or confirmation protocol"
    )
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--stage", choices=("development", "confirmation"), default="development")
    parser.add_argument("--geometry-registry", default="")
    args = parser.parse_args(argv)
    source_root = Path(args.source_root)
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    seed_dirs = sorted(
        path for path in source_root.glob("seed_*") if (path / "config.yaml").exists()
    )
    expected_seeds = list(range(5)) if args.stage == "development" else list(range(10, 15))
    actual_seeds = [int(path.name.split("_")[-1]) for path in seed_dirs]
    if actual_seeds != expected_seeds:
        raise ValueError(
            f"{args.stage} protocol requires exactly seeds {expected_seeds}, got {actual_seeds}"
        )

    registry_path = Path(args.geometry_registry).resolve() if args.geometry_registry else None
    registry_sha256 = ""
    if args.stage == "confirmation":
        if registry_path is None or not registry_path.exists():
            raise ValueError("confirmation requires --geometry-registry")
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
        if registry.get("seeds") != expected_seeds:
            raise ValueError("geometry registry seed set does not match confirmation seeds")
        registry_sha256 = _sha256(registry_path)

    protocol = {
        "protocol": (
            "officehome65_clip_crossfit_dual_endpoint_transport_development_v3"
            if args.stage == "development"
            else "officehome65_clip_function_transport_untouched_confirmation_v1"
        ),
        "stage": args.stage,
        "frozen_before_results": True,
        "seeds": actual_seeds,
        "candidate": "nested-crossfit convex function teacher distilled into receiver LoRA",
        "experts": [
            "crossfit Local",
            "gauge-invariant Geo probability mixture",
            "gauge-invariant FAM probability mixture",
            "class-conditional prototype probability route",
        ],
        "relative_objective": (
            "three-fold nested held-out cross-entropy regret versus crossfit Local"
        ),
        "structural_corrections": [
            "receiver anchor is trained without its scored fold",
            "each class routes donor evidence independently",
            "all donor mixtures operate in probability space",
            "centered smooth maximum has zero value at zero regret",
            "direct adapter-bank teacher and distilled student are both audited",
            "class-changing paths require strict paired accuracy superiority",
            "proper-loss paths preserve Local top-1 predictions pointwise",
        ],
        "test_order": "all receiver construction and calibration decisions before any test pass",
        "certificate_alpha_per_receiver": 0.0125,
        "success_criteria": [
            "nested held-out route regret is negative for at least 25% of receiver-seed units",
            "at least one certified non-local deployment",
            "zero harmful certified deployments",
            "at least one deployed proper-loss improvement",
            "non-negative seed-mean deployed gain over Local",
            "positive seed-mean deployed proper-loss improvement",
            "exact Local replay",
        ]
        + (
            []
            if args.stage == "development"
            else [
                "positive mean raw-student accuracy gain over Local",
                "positive lower seed-bootstrap bound for raw-student accuracy gain",
                "positive raw-student seed mean in at least four of five seeds",
                "non-negative lower seed-bootstrap bound for deployed proper-loss gain",
            ]
        ),
        "untouched_confirmation_seeds": (
            [10, 11, 12, 13, 14] if args.stage == "development" else []
        ),
        "confirmation_not_authorized_until_development_passes": args.stage == "development",
        "test_used_for_construction_or_selection": False,
        "runner_sha256": _sha256(RUNNER),
        "theory_sha256": _sha256(THEORY),
        "geometry_registry_sha256": registry_sha256,
        "source_config_sha256": {
            path.name: _sha256(path / "config.yaml") for path in seed_dirs
        },
    }
    protocol_path = output_root / "frozen_protocol.json"
    if protocol_path.exists():
        existing = json.loads(protocol_path.read_text(encoding="utf-8"))
        if existing != protocol:
            raise ValueError("output root contains a different frozen protocol or source hash")
    else:
        protocol_path.write_text(
            json.dumps(protocol, indent=2) + "\n", encoding="utf-8"
        )

    for seed_dir in seed_dirs:
        output_dir = output_root / seed_dir.name
        if (output_dir / "function_transport_admission.csv").exists():
            continue
        config = yaml.safe_load((seed_dir / "config.yaml").read_text(encoding="utf-8"))
        subprocess.run(_command(args.python, config, output_dir), cwd=ROOT, check=True)

    rows: list[dict] = []
    parity_accuracy: list[float] = []
    parity_loss: list[float] = []
    parity_counts: list[int] = []
    geo_lookup: dict[tuple[int, str], float] = {}
    for seed_dir in seed_dirs:
        seed = int(seed_dir.name.split("_")[-1])
        original_rows = _read_csv(seed_dir / "per_client_metrics.csv")
        for row in original_rows:
            if row["method"] == "FedGeo-Agg-CLIP-LoRA":
                geo_lookup[(seed, row["client_id"])] = float(row["accuracy"])
        original_local = {
            row["client_id"]: row
            for row in original_rows
            if row["method"] == "Local-CLIP-LoRA"
        }
        audit_dir = output_root / seed_dir.name
        rows.extend(_read_csv(audit_dir / "function_transport_admission.csv"))
        for replay in _read_csv(audit_dir / "local_replay_metrics.csv"):
            reference = original_local[replay["client_id"]]
            parity_accuracy.append(
                abs(float(replay["accuracy"]) - float(reference["accuracy"]))
            )
            parity_loss.append(abs(float(replay["loss"]) - float(reference["loss"])))
            parity_counts.append(
                abs(int(replay["num_samples"]) - int(reference["num_samples"]))
            )
    for row in rows:
        key = (int(row["seed"]), row["client_id"])
        row["geo_test_accuracy_from_frozen_source"] = geo_lookup[key]
        row["test_gain_vs_geo"] = (
            float(row["deployed_test_accuracy"]) - geo_lookup[key]
        )
    _write_csv(output_root / "function_transport_admission_all_seeds.csv", rows)

    seed_gain_local: dict[int, float] = {}
    seed_gain_geo: dict[int, float] = {}
    seed_loss_gain_local: dict[int, float] = {}
    seed_raw_student_gain_local: dict[int, float] = {}
    seed_raw_direct_gain_local: dict[int, float] = {}
    for seed in sorted({int(row["seed"]) for row in rows}):
        subset = [row for row in rows if int(row["seed"]) == seed]
        seed_gain_local[seed] = float(
            np.mean([float(row["test_gain_vs_local"]) for row in subset])
        )
        seed_gain_geo[seed] = float(
            np.mean([float(row["test_gain_vs_geo"]) for row in subset])
        )
        seed_loss_gain_local[seed] = float(
            np.mean(
                [
                    float(row["local_test_loss"]) - float(row["deployed_test_loss"])
                    for row in subset
                ]
            )
        )
        seed_raw_student_gain_local[seed] = float(
            np.mean(
                [
                    float(row["student_raw_test_accuracy"])
                    - float(row["local_test_accuracy"])
                    for row in subset
                ]
            )
        )
        seed_raw_direct_gain_local[seed] = float(
            np.mean(
                [
                    float(row["direct_raw_test_accuracy"])
                    - float(row["local_test_accuracy"])
                    for row in subset
                ]
            )
        )
    total = len(rows)
    crossfit_positive = sum(_as_bool(row["crossfit_positive"]) for row in rows)
    constructed = sum(_as_bool(row["constructed"]) for row in rows)
    certified = sum(_as_bool(row["certified"]) for row in rows)
    harmful = sum(_as_bool(row["harmful_admission"]) for row in rows)
    raw_positive = sum(
        max(
            float(row["direct_raw_test_accuracy"]),
            float(row["student_raw_test_accuracy"]),
        )
        > float(row["local_test_accuracy"])
        for row in rows
    )
    deployed_loss_positive = sum(
        float(row["deployed_test_loss"]) < float(row["local_test_loss"]) - 1e-12
        for row in rows
    )
    mean_gain_local = float(np.mean(list(seed_gain_local.values())))
    mean_loss_gain_local = float(np.mean(list(seed_loss_gain_local.values())))
    raw_student_mean = float(np.mean(list(seed_raw_student_gain_local.values())))
    raw_student_ci = _bootstrap_seed_ci(seed_raw_student_gain_local)
    raw_student_positive_seeds = sum(
        value > 0.0 for value in seed_raw_student_gain_local.values()
    )
    proper_loss_ci = _bootstrap_seed_ci(seed_loss_gain_local)
    per_seed_rows = [
        {
            "seed": seed,
            "receiver_units": sum(int(row["seed"]) == seed for row in rows),
            "crossfit_positive_units": sum(
                int(row["seed"]) == seed and _as_bool(row["crossfit_positive"])
                for row in rows
            ),
            "certified_nonlocal_units": sum(
                int(row["seed"]) == seed and _as_bool(row["certified"])
                for row in rows
            ),
            "harmful_certified_units": sum(
                int(row["seed"]) == seed and _as_bool(row["harmful_admission"])
                for row in rows
            ),
            "mean_deployed_accuracy_gain_vs_local": seed_gain_local[seed],
            "mean_deployed_accuracy_gain_vs_geo": seed_gain_geo[seed],
            "mean_deployed_proper_loss_gain_vs_local": seed_loss_gain_local[seed],
            "mean_raw_student_accuracy_gain_vs_local": seed_raw_student_gain_local[seed],
            "mean_raw_direct_accuracy_gain_vs_local": seed_raw_direct_gain_local[seed],
        }
        for seed in sorted(seed_gain_local)
    ]
    _write_csv(output_root / "per_seed_mechanism_summary.csv", per_seed_rows)
    per_domain_rows: list[dict] = []
    for domain in sorted({row["domain"] for row in rows}):
        subset = [row for row in rows if row["domain"] == domain]
        per_domain_rows.append(
            {
                "domain": domain,
                "receiver_seed_units": len(subset),
                "crossfit_positive_rate": float(
                    np.mean([_as_bool(row["crossfit_positive"]) for row in subset])
                ),
                "certified_nonlocal_rate": float(
                    np.mean([_as_bool(row["certified"]) for row in subset])
                ),
                "harmful_certified_units": sum(
                    _as_bool(row["harmful_admission"]) for row in subset
                ),
                "mean_deployed_accuracy_gain_vs_local": float(
                    np.mean([float(row["test_gain_vs_local"]) for row in subset])
                ),
                "mean_deployed_proper_loss_gain_vs_local": float(
                    np.mean(
                        [
                            float(row["local_test_loss"])
                            - float(row["deployed_test_loss"])
                            for row in subset
                        ]
                    )
                ),
                "mean_raw_student_accuracy_gain_vs_local": float(
                    np.mean(
                        [
                            float(row["student_raw_test_accuracy"])
                            - float(row["local_test_accuracy"])
                            for row in subset
                        ]
                    )
                ),
                "mean_raw_direct_accuracy_gain_vs_local": float(
                    np.mean(
                        [
                            float(row["direct_raw_test_accuracy"])
                            - float(row["local_test_accuracy"])
                            for row in subset
                        ]
                    )
                ),
                "mean_crossfit_max_heldout_regret": float(
                    np.mean(
                        [float(row["crossfit_max_heldout_regret"]) for row in subset]
                    )
                ),
            }
        )
    _write_csv(output_root / "per_domain_mechanism_summary.csv", per_domain_rows)
    common_gate_passed = bool(
        total > 0
        and crossfit_positive / total >= 0.25
        and constructed / total >= 0.25
        and certified >= 1
        and harmful == 0
        and raw_positive >= 1
        and deployed_loss_positive >= 1
        and mean_gain_local >= -1e-12
        and mean_loss_gain_local > 0.0
        and max(parity_accuracy, default=float("inf")) <= 1e-12
        and max(parity_counts, default=1) == 0
        and max(parity_loss, default=float("inf")) <= 1e-7
    )
    stage_passed = bool(
        common_gate_passed
        and (
            args.stage == "development"
            or (
                raw_student_mean > 0.0
                and raw_student_ci[0] > 0.0
                and raw_student_positive_seeds >= 4
                and proper_loss_ci[0] >= 0.0
            )
        )
    )
    report = {
        "receiver_seed_units": total,
        "nested_crossfit_positive_every_heldout_fold": crossfit_positive,
        "constructed_candidates": constructed,
        "raw_test_positive_candidates": raw_positive,
        "deployed_proper_loss_positive_units": deployed_loss_positive,
        "certified_nonlocal": certified,
        "harmful_certified": harmful,
        "mean_deployed_gain_vs_local": mean_gain_local,
        "seed_bootstrap_ci_vs_local": list(_bootstrap_seed_ci(seed_gain_local)),
        "mean_deployed_gain_vs_geo": float(np.mean(list(seed_gain_geo.values()))),
        "seed_bootstrap_ci_vs_geo": list(_bootstrap_seed_ci(seed_gain_geo)),
        "mean_deployed_proper_loss_gain_vs_local": mean_loss_gain_local,
        "seed_bootstrap_ci_proper_loss_gain_vs_local": list(proper_loss_ci),
        "mean_raw_student_accuracy_gain_vs_local": raw_student_mean,
        "seed_bootstrap_ci_raw_student_accuracy_gain_vs_local": list(raw_student_ci),
        "raw_student_positive_seed_count": raw_student_positive_seeds,
        "raw_student_one_sided_seed_sign_p": float(
            sum(
                math.comb(len(seed_raw_student_gain_local), count)
                for count in range(
                    raw_student_positive_seeds,
                    len(seed_raw_student_gain_local) + 1,
                )
            )
            / (2 ** len(seed_raw_student_gain_local))
        ),
        "mean_raw_direct_accuracy_gain_vs_local": float(
            np.mean(list(seed_raw_direct_gain_local.values()))
        ),
        "seed_bootstrap_ci_raw_direct_accuracy_gain_vs_local": list(
            _bootstrap_seed_ci(seed_raw_direct_gain_local)
        ),
        "max_local_replay_accuracy_difference": max(
            parity_accuracy, default=float("nan")
        ),
        "max_local_replay_loss_difference": max(parity_loss, default=float("nan")),
        "max_local_replay_sample_count_difference": max(parity_counts, default=-1),
        "local_replay_loss_tolerance": 1e-7,
        "local_replay_tolerance_rationale": (
            "accuracy and sample counts are exact; loss differs only because the "
            "audit recomputes log-softmax means in float64 while the frozen source "
            "used torch float32 reductions"
        ),
        "stage": args.stage,
        "common_safety_gate_passed": common_gate_passed,
        "stage_passed": stage_passed,
        "development_passed": stage_passed if args.stage == "development" else None,
        "confirmation_passed": stage_passed if args.stage == "confirmation" else None,
        "next_decision": (
            "authorize_one_shot_seed_10_to_14_confirmation"
            if args.stage == "development" and stage_passed
            else (
                "promote_function_transport_as_confirmed_extension"
                if args.stage == "confirmation" and stage_passed
                else "stop_function_transport_extension_and_report_failed_gate"
            )
        ),
        "test_used_for_construction_or_selection": False,
    }
    report_stem = "development_report" if args.stage == "development" else "confirmation_report"
    (output_root / f"{report_stem}.json").write_text(
        json.dumps(report, indent=2), encoding="utf-8"
    )
    (output_root / f"{report_stem}.md").write_text(
        f"# Function-transport {args.stage}\n\n"
        + "\n".join(f"- {key}: `{value}`" for key, value in report.items())
        + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
