from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import yaml


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "run_clip_vit_lora_federated_main.py"
THEORY = ROOT / "docs" / "signed_span_admission_20260814.md"
COVERAGE_REPORT = (
    ROOT
    / "results"
    / "source_dictionary_coverage_stage_a_20260814"
    / "officehome_clip_e2e"
    / "stage_a_report.json"
)


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _command(python: str, config: dict, output_dir: Path) -> list[str]:
    command = [
        python, str(RUNNER),
        "--data-root", str(config["data_root"]),
        "--output-dir", str(output_dir),
        "--dataset", str(config["dataset"]),
        "--domains", str(config["domains"]),
        "--num-classes", str(config["num_classes"]),
        "--train-per-class", str(config["train_per_class"]),
        "--test-per-class", str(config["test_per_class"]),
        "--calibration-fraction", str(config["calibration_fraction"]),
        "--communication-rounds", str(config["communication_rounds"]),
        "--local-epochs", str(config["local_epochs"]),
        "--batch-size", str(config["batch_size"]),
        "--rank", str(config["rank"]),
        "--lr", str(config["lr"]),
        "--seed", str(config["seed"]),
        "--device", str(config["device"]),
        "--model-name", str(config["model_name"]),
        "--lora-blocks", str(config["lora_blocks"]),
        "--prompt-template", str(config["prompt_template"]),
        "--geometry-outputs-dir", str(config["geometry_outputs_dir"]),
        "--round-id", str(config["round_id"]),
        "--graph-k", str(config["graph_k"]),
        "--subspace-estimator", str(config["subspace_estimator"]),
        "--subspace-ema-decay", str(config["subspace_ema_decay"]),
        "--source-coverage-audit", "--source-coverage-only",
        "--signed-span-admission", "--signed-span-certificate-alpha", "0.0125",
    ]
    if str(config.get("class_label_map", "")):
        command.extend(["--class-label-map", str(config["class_label_map"])])
    return command


def _bootstrap_seed_ci(seed_values: dict[int, float], draws: int = 20000) -> tuple[float, float]:
    values = np.asarray([seed_values[key] for key in sorted(seed_values)], dtype=np.float64)
    rng = np.random.default_rng(20260814)
    samples = values[rng.integers(0, values.size, size=(draws, values.size))].mean(axis=1)
    return float(np.quantile(samples, 0.025)), float(np.quantile(samples, 0.975))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="OfficeHome signed-span development protocol")
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--python", default=sys.executable)
    args = parser.parse_args(argv)
    source_root = Path(args.source_root)
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    seed_dirs = sorted(path for path in source_root.glob("seed_*") if (path / "config.yaml").exists())
    if len(seed_dirs) != 5:
        raise ValueError("development protocol requires exactly five seeds")
    coverage = json.loads(COVERAGE_REPORT.read_text(encoding="utf-8"))
    if coverage.get("decision") != "authorize_signed_span_candidate":
        raise RuntimeError("Stage A did not authorize the signed-span candidate")
    protocol = {
        "protocol": "officehome65_clip_signed_span_development_v1",
        "frozen_before_results": True,
        "seeds": [int(path.name.split("_")[-1]) for path in seed_dirs],
        "certificate_alpha_per_receiver": 0.0125,
        "trust_radius": "RMS raw donor tangent norm",
        "backtracking": "first rank-projected training-loss decrease over factors 1/2^k, k=0..16",
        "development_success": [
            "at least one certified non-local receiver",
            "zero harmful certified receivers",
            "non-negative mean deployed gain over Local",
            "raw candidate constructed for at least 25% of receiver-seed units",
        ],
        "test_used_for_construction_or_selection": False,
        "runner_sha256": _sha256(RUNNER),
        "theory_sha256": _sha256(THEORY),
        "stage_a_report_sha256": _sha256(COVERAGE_REPORT),
        "source_config_sha256": {path.name: _sha256(path / "config.yaml") for path in seed_dirs},
    }
    (output_root / "frozen_protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")

    for seed_dir in seed_dirs:
        output_dir = output_root / seed_dir.name
        if (output_dir / "signed_span_admission.csv").exists():
            continue
        config = yaml.safe_load((seed_dir / "config.yaml").read_text(encoding="utf-8"))
        subprocess.run(_command(args.python, config, output_dir), cwd=ROOT, check=True)

    rows: list[dict] = []
    parity: list[float] = []
    geo_lookup: dict[tuple[int, str], float] = {}
    for seed_dir in seed_dirs:
        seed = int(seed_dir.name.split("_")[-1])
        for original in _read_csv(seed_dir / "per_client_metrics.csv"):
            if original["method"] == "FedGeo-Agg-CLIP-LoRA":
                geo_lookup[(seed, original["client_id"])] = float(original["accuracy"])
        audit_dir = output_root / seed_dir.name
        rows.extend(_read_csv(audit_dir / "signed_span_admission.csv"))
        original_local = {
            row["client_id"]: row
            for row in _read_csv(seed_dir / "per_client_metrics.csv")
            if row["method"] == "Local-CLIP-LoRA"
        }
        for replay in _read_csv(audit_dir / "local_replay_metrics.csv"):
            reference = original_local[replay["client_id"]]
            parity.extend(
                [
                    abs(float(replay["accuracy"]) - float(reference["accuracy"])),
                    abs(float(replay["loss"]) - float(reference["loss"])),
                ]
            )
    for row in rows:
        key = (int(row["seed"]), row["client_id"])
        row["geo_test_accuracy_from_frozen_source"] = geo_lookup[key]
        row["test_gain_vs_geo"] = float(row["deployed_test_accuracy"]) - geo_lookup[key]
    _write_csv(output_root / "signed_span_admission_all_seeds.csv", rows)

    seed_gain_local: dict[int, float] = {}
    seed_gain_geo: dict[int, float] = {}
    for seed in sorted({int(row["seed"]) for row in rows}):
        subset = [row for row in rows if int(row["seed"]) == seed]
        seed_gain_local[seed] = float(np.mean([float(row["test_gain_vs_local"]) for row in subset]))
        seed_gain_geo[seed] = float(np.mean([float(row["test_gain_vs_geo"]) for row in subset]))
    local_ci = _bootstrap_seed_ci(seed_gain_local)
    geo_ci = _bootstrap_seed_ci(seed_gain_geo)
    constructed = sum(str(row["constructed"]).lower() == "true" for row in rows)
    certified = sum(str(row["certified"]).lower() == "true" for row in rows)
    harmful = sum(str(row["harmful_admission"]).lower() == "true" for row in rows)
    mean_gain_local = float(np.mean(list(seed_gain_local.values())))
    mean_gain_geo = float(np.mean(list(seed_gain_geo.values())))
    development_passed = bool(
        certified >= 1
        and harmful == 0
        and mean_gain_local >= -1e-12
        and constructed / len(rows) >= 0.25
        and max(parity, default=float("inf")) <= 1e-12
    )
    report = {
        "receiver_seed_units": len(rows),
        "constructed_candidates": constructed,
        "certified_nonlocal": certified,
        "harmful_certified": harmful,
        "mean_deployed_gain_vs_local": mean_gain_local,
        "seed_bootstrap_ci_vs_local": list(local_ci),
        "mean_deployed_gain_vs_geo": mean_gain_geo,
        "seed_bootstrap_ci_vs_geo": list(geo_ci),
        "max_local_replay_absolute_difference": max(parity, default=float("nan")),
        "development_passed": development_passed,
        "next_decision": (
            "freeze_and_run_untouched_seed_10_to_14_confirmation"
            if development_passed
            else "stop_signed_span_extension_keep_current_manuscript"
        ),
        "test_used_for_construction_or_selection": False,
    }
    (output_root / "development_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    (output_root / "development_report.md").write_text(
        "# Signed-span development\n\n"
        + "\n".join(f"- {key}: `{value}`" for key, value in report.items())
        + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
