from __future__ import annotations

import argparse
import csv
import hashlib
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import yaml


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "run_clip_vit_lora_federated_main.py"
THEORY = ROOT / "docs" / "source_dictionary_coverage_decoupling_20260814.md"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _command(python: str, config: dict, output_dir: Path) -> list[str]:
    command = [
        python,
        str(RUNNER),
        "--data-root",
        str(config["data_root"]),
        "--output-dir",
        str(output_dir),
        "--dataset",
        str(config["dataset"]),
        "--domains",
        str(config["domains"]),
        "--num-classes",
        str(config["num_classes"]),
        "--train-per-class",
        str(config["train_per_class"]),
        "--test-per-class",
        str(config["test_per_class"]),
        "--calibration-fraction",
        str(config["calibration_fraction"]),
        "--communication-rounds",
        str(config["communication_rounds"]),
        "--local-epochs",
        str(config["local_epochs"]),
        "--batch-size",
        str(config["batch_size"]),
        "--rank",
        str(config["rank"]),
        "--lr",
        str(config["lr"]),
        "--seed",
        str(config["seed"]),
        "--device",
        str(config["device"]),
        "--model-name",
        str(config["model_name"]),
        "--lora-blocks",
        str(config["lora_blocks"]),
        "--prompt-template",
        str(config["prompt_template"]),
        "--geometry-outputs-dir",
        str(config["geometry_outputs_dir"]),
        "--round-id",
        str(config["round_id"]),
        "--graph-k",
        str(config["graph_k"]),
        "--subspace-estimator",
        str(config["subspace_estimator"]),
        "--subspace-ema-decay",
        str(config["subspace_ema_decay"]),
        "--source-coverage-audit",
        "--source-coverage-only",
    ]
    if str(config.get("class_label_map", "")):
        command.extend(["--class-label-map", str(config["class_label_map"])])
    elif str(config.get("class_labels", "")):
        command.extend(["--class-labels", str(config["class_labels"])])
    return command


def _float(row: dict, key: str) -> float:
    return float(row[key])


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Frozen OfficeHome CLIP source-coverage Stage A")
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--python", default=sys.executable)
    args = parser.parse_args(argv)
    source_root = Path(args.source_root)
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    seed_dirs = sorted(path for path in source_root.glob("seed_*") if (path / "config.yaml").exists())
    if len(seed_dirs) != 5:
        raise ValueError(f"expected five audited seed directories, found {len(seed_dirs)}")

    protocol = {
        "protocol": "source_dictionary_coverage_stage_a_v1",
        "frozen_before_results": True,
        "seeds": [int(path.name.split("_")[-1]) for path in seed_dirs],
        "material_gap": 0.05,
        "minimum_receiver_prevalence": 0.25,
        "candidate_authorization": (
            "A cone/span branch is authorized only when its training-side gap is at least 0.05 "
            "and the corresponding training-fitted direction has calibration descent cosine at "
            "least 0.05 on at least 25% of receiver-seed units."
        ),
        "test_used_for_coverage_or_authorization": False,
        "runner_sha256": _sha256(RUNNER),
        "theory_sha256": _sha256(THEORY),
        "source_config_sha256": {
            path.name: _sha256(path / "config.yaml") for path in seed_dirs
        },
    }
    (output_root / "frozen_protocol.json").write_text(
        json.dumps(protocol, indent=2), encoding="utf-8"
    )

    for seed_dir in seed_dirs:
        output_dir = output_root / seed_dir.name
        expected = output_dir / "source_coverage.csv"
        if expected.exists():
            continue
        config = yaml.safe_load((seed_dir / "config.yaml").read_text(encoding="utf-8"))
        subprocess.run(_command(args.python, config, output_dir), cwd=ROOT, check=True)

    coverage_rows: list[dict] = []
    donor_rows: list[dict] = []
    replay_differences: list[float] = []
    for seed_dir in seed_dirs:
        audit_dir = output_root / seed_dir.name
        coverage_rows.extend(_read_csv(audit_dir / "source_coverage.csv"))
        donor_rows.extend(_read_csv(audit_dir / "source_coverage_donors.csv"))
        original = {
            (row["client_id"], row["domain"]): row
            for row in _read_csv(seed_dir / "per_client_metrics.csv")
            if row["method"] == "Local-CLIP-LoRA"
        }
        for row in _read_csv(audit_dir / "local_replay_metrics.csv"):
            reference = original[(row["client_id"], row["domain"])]
            replay_differences.extend(
                [
                    abs(float(row["accuracy"]) - float(reference["accuracy"])),
                    abs(float(row["loss"]) - float(reference["loss"])),
                ]
            )
    _write_csv(output_root / "source_coverage_all_seeds.csv", coverage_rows)
    _write_csv(output_root / "source_coverage_donors_all_seeds.csv", donor_rows)

    rows = [row for row in coverage_rows if row["dictionary"] == "all_external"]
    training = [row for row in rows if row["risk_split"] == "adapter_training"]
    calibration = [row for row in rows if row["risk_split"] == "outer_calibration"]
    material = float(protocol["material_gap"])
    prevalence = float(protocol["minimum_receiver_prevalence"])
    cone_gap_fraction = float(np.mean([_float(row, "multi_donor_gap") >= material for row in training]))
    signed_gap_fraction = float(np.mean([_float(row, "signed_span_gap") >= material for row in training]))
    cone_transfer_fraction = float(
        np.mean(
            [
                _float(row, "training_cone_direction_calibration_cosine") >= material
                for row in calibration
            ]
        )
    )
    signed_transfer_fraction = float(
        np.mean(
            [
                _float(row, "training_span_direction_calibration_cosine") >= material
                for row in calibration
            ]
        )
    )
    cone_authorized = cone_gap_fraction >= prevalence and cone_transfer_fraction >= prevalence
    signed_authorized = signed_gap_fraction >= prevalence and signed_transfer_fraction >= prevalence
    decision = (
        "authorize_signed_span_candidate"
        if signed_authorized
        else "authorize_nnls_cone_candidate"
        if cone_authorized
        else "stop_dictionary_extension"
    )
    report = {
        "num_receiver_seed_units": len(training),
        "max_local_replay_absolute_difference": max(replay_differences, default=float("nan")),
        "local_replay_exact": max(replay_differences, default=float("inf")) <= 1e-12,
        "training_median_gamma_atom": float(np.median([_float(row, "gamma_atom") for row in training])),
        "training_median_gamma_cone": float(np.median([_float(row, "gamma_cone") for row in training])),
        "training_median_gamma_span": float(np.median([_float(row, "gamma_span") for row in training])),
        "calibration_median_gamma_atom": float(np.median([_float(row, "gamma_atom") for row in calibration])),
        "calibration_median_gamma_cone": float(np.median([_float(row, "gamma_cone") for row in calibration])),
        "calibration_median_gamma_span": float(np.median([_float(row, "gamma_span") for row in calibration])),
        "training_multi_donor_gap_ge_0_05_fraction": cone_gap_fraction,
        "training_signed_span_gap_ge_0_05_fraction": signed_gap_fraction,
        "training_cone_direction_calibration_cosine_ge_0_05_fraction": cone_transfer_fraction,
        "training_span_direction_calibration_cosine_ge_0_05_fraction": signed_transfer_fraction,
        "nnls_cone_candidate_authorized": bool(cone_authorized),
        "signed_span_candidate_authorized": bool(signed_authorized),
        "decision": decision,
        "test_used_for_coverage_or_authorization": False,
    }
    (output_root / "stage_a_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    lines = ["# Source-dictionary coverage Stage A", ""]
    lines.extend(f"- {key}: `{value}`" for key, value in report.items())
    (output_root / "stage_a_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["local_replay_exact"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
