from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path

import numpy as np
import yaml


ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "scripts" / "run_clip_vit_lora_federated_main.py"
THEORY = ROOT / "docs" / "receiver_conditioned_action_subspace_audit_20260815.md"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _bootstrap_seed_ci(values: dict[int, float], draws: int = 20000) -> list[float]:
    ordered = np.asarray([values[key] for key in sorted(values)], dtype=np.float64)
    rng = np.random.default_rng(20260815)
    samples = ordered[rng.integers(0, ordered.size, size=(draws, ordered.size))]
    means = np.mean(samples, axis=1)
    return [float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))]


def _command(python: str, config: dict, output_dir: Path) -> list[str]:
    command = [
        python,
        str(RUNNER),
        "--data-root", str(config["data_root"]),
        "--output-dir", str(output_dir),
        "--dataset", str(config["dataset"]),
        "--domains", str(config["domains"]),
        "--num-classes", str(config["num_classes"]),
        "--train-per-class", str(config["train_per_class"]),
        "--test-per-class", str(config["test_per_class"]),
        "--calibration-fraction", str(config["calibration_fraction"]),
        "--communication-rounds", str(config["communication_rounds"]),
        "--local-epochs", str(config["local_epochs"]),
        "--batch-size", str(config["batch_size"]),
        "--rank", str(config["rank"]),
        "--lr", str(config["lr"]),
        "--seed", str(config["seed"]),
        "--device", str(config["device"]),
        "--model-name", str(config["model_name"]),
        "--lora-blocks", str(config["lora_blocks"]),
        "--prompt-template", str(config["prompt_template"]),
        "--geometry-outputs-dir", str(config["geometry_outputs_dir"]),
        "--round-id", str(config["round_id"]),
        "--graph-k", str(config["graph_k"]),
        "--subspace-estimator", str(config["subspace_estimator"]),
        "--subspace-ema-decay", str(config["subspace_ema_decay"]),
        "--source-coverage-audit",
        "--source-coverage-only",
        "--function-transport-admission",
        "--function-transport-expert-ablation-only",
        "--function-transport-kl-strength", "0.01",
        "--function-transport-fold-temperature", "0.05",
        "--function-transport-prototype-temperature", "0.1",
    ]
    if str(config.get("class_label_map", "")):
        command.extend(["--class-label-map", str(config["class_label_map"])])
    return command


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Frozen training-only Local/Geo/FAM expert ablation"
    )
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--geometry-registry", required=True)
    parser.add_argument("--python", default=sys.executable)
    args = parser.parse_args(argv)

    source_root = Path(args.source_root).resolve()
    output_root = Path(args.output_root).resolve()
    registry_path = Path(args.geometry_registry).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    seed_dirs = sorted(
        path for path in source_root.glob("seed_*") if (path / "config.yaml").exists()
    )
    seeds = [int(path.name.split("_")[-1]) for path in seed_dirs]
    if seeds != [10, 11, 12, 13, 14]:
        raise ValueError(f"expected untouched confirmation seeds 10--14, got {seeds}")

    protocol = {
        "protocol": "officehome65_training_only_function_expert_ablation_v1",
        "status": "frozen_before_ablation_outputs",
        "seeds": seeds,
        "outer_split_access": "none: no calibration or test forward pass",
        "expert_subsets": [
            "local_geo",
            "local_fam",
            "local_geo_fam",
            "all",
        ],
        "primary_estimand": (
            "mean_heldout_regret(local_geo) - "
            "mean_heldout_regret(local_geo_fam)"
        ),
        "claim_gate": {
            "mean_positive": True,
            "positive_seed_means_at_least": 4,
            "stable_requires_positive_seed_bootstrap_lower_bound": True,
        },
        "runner_sha256": _sha256(RUNNER),
        "theory_sha256": _sha256(THEORY),
        "geometry_registry_sha256": _sha256(registry_path),
        "source_config_sha256": {
            path.name: _sha256(path / "config.yaml") for path in seed_dirs
        },
        "test_used_for_construction_selection_or_evaluation": False,
    }
    protocol_path = output_root / "frozen_protocol.json"
    if protocol_path.exists():
        existing = json.loads(protocol_path.read_text(encoding="utf-8"))
        if existing != protocol:
            raise ValueError("output root contains a different frozen protocol")
    else:
        protocol_path.write_text(
            json.dumps(protocol, indent=2) + "\n", encoding="utf-8"
        )

    for seed_dir in seed_dirs:
        output_dir = output_root / seed_dir.name
        if (output_dir / "function_expert_ablation.csv").exists():
            continue
        config = yaml.safe_load((seed_dir / "config.yaml").read_text(encoding="utf-8"))
        subprocess.run(
            _command(args.python, config, output_dir), cwd=ROOT, check=True
        )

    rows: list[dict] = []
    for seed_dir in seed_dirs:
        rows.extend(
            _read_csv(
                output_root / seed_dir.name / "function_expert_ablation.csv"
            )
        )
    _write_csv(output_root / "function_expert_ablation_all_seeds.csv", rows)

    seed_increment = {}
    seed_endpoint = {}
    per_seed = []
    for seed in seeds:
        subset = [row for row in rows if int(row["seed"]) == seed]
        increment = float(
            np.mean([float(row["fam_increment_given_geo"]) for row in subset])
        )
        endpoint = float(
            np.mean([float(row["fam_endpoint_gain_vs_geo"]) for row in subset])
        )
        seed_increment[seed] = increment
        seed_endpoint[seed] = endpoint
        per_seed.append(
            {
                "seed": seed,
                "receiver_units": len(subset),
                "mean_fam_increment_given_geo": increment,
                "mean_fam_endpoint_gain_vs_geo": endpoint,
                "positive_increment_units": sum(
                    float(row["fam_increment_given_geo"]) > 0.0 for row in subset
                ),
                "test_used": False,
            }
        )
    _write_csv(output_root / "per_seed_expert_ablation.csv", per_seed)

    mean_increment = float(np.mean(list(seed_increment.values())))
    increment_ci = _bootstrap_seed_ci(seed_increment)
    positive_seeds = sum(value > 0.0 for value in seed_increment.values())
    sign_p = float(
        sum(math.comb(5, count) for count in range(positive_seeds, 6)) / 32.0
    )
    report = {
        "receiver_seed_units": len(rows),
        "mean_fam_increment_given_geo": mean_increment,
        "seed_bootstrap_ci_fam_increment_given_geo": increment_ci,
        "positive_seed_means": positive_seeds,
        "one_sided_seed_sign_p": sign_p,
        "mean_fam_endpoint_gain_vs_geo": float(
            np.mean(list(seed_endpoint.values()))
        ),
        "claim_gate_passed": bool(mean_increment > 0.0 and positive_seeds >= 4),
        "stable_claim_gate_passed": bool(
            mean_increment > 0.0 and positive_seeds >= 4 and increment_ci[0] > 0.0
        ),
        "test_used_for_construction_selection_or_evaluation": False,
    }
    (output_root / "expert_ablation_report.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    (output_root / "expert_ablation_report.md").write_text(
        "# Training-only function-expert ablation\n\n"
        + "\n".join(f"- {key}: `{value}`" for key, value in report.items())
        + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
