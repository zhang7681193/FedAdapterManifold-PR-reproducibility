from __future__ import annotations

import argparse
import csv
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fedadaptermanifold.config import load_yaml, save_yaml_copy


DATASETS = {
    "pacs_resnet18": {
        "source": "configs/resolve_stage2_shrinkresidual_20260629/pacs_resnet18/seed_{seed}.yaml",
        "rank": 8,
    },
    "officehome_clip_full": {
        "source": "configs/resolve_stage2_shrinkresidual_20260629/officehome_clip_full/seed_{seed}.yaml",
        "rank": 8,
    },
    "officehome_dinov2_full": {
        "source": "configs/resolve_stage2_shrinkresidual_20260629/officehome_dinov2/seed_{seed}.yaml",
        "rank": 8,
    },
    "domainnetmini_clip_60class": {
        "source": "configs/resolve_stage2_shrinkresidual_20260629/domainnetmini_clip/seed_{seed}.yaml",
        "rank": 6,
    },
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the fixed-rank recent federated-LoRA fairness package.")
    parser.add_argument("--datasets", default=",".join(DATASETS))
    parser.add_argument("--seeds", default="0,1,2,3,4")
    parser.add_argument(
        "--methods",
        default="all",
        help="Comma-separated recent-LoRA methods forwarded to the shared-protocol runner.",
    )
    parser.add_argument("--output-root", default="results/recent_lora_decoupled_fairness_20260810")
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.output_root)
    config_root = root / "configs"
    log_root = root / "logs"
    config_root.mkdir(parents=True, exist_ok=True)
    log_root.mkdir(parents=True, exist_ok=True)
    datasets = [item.strip() for item in args.datasets.split(",") if item.strip()]
    seeds = [int(item.strip()) for item in args.seeds.split(",") if item.strip()]

    for dataset_key in datasets:
        if dataset_key not in DATASETS:
            raise ValueError(f"Unknown dataset key: {dataset_key}")
        spec = DATASETS[dataset_key]
        for seed in seeds:
            source = Path(str(spec["source"]).format(seed=seed))
            if not source.exists():
                raise FileNotFoundError(source)
            config = load_yaml(source)
            output_dir = root / dataset_key / f"seed_{seed}"
            config.update(
                {
                    "output_dir": str(output_dir),
                    "seed": seed,
                    "rank_policy": "fixed",
                    "rank": int(spec["rank"]),
                    "min_rank": int(spec["rank"]),
                    "max_rank": int(spec["rank"]),
                    "run_recent_lora_baselines": True,
                    "recent_lora_methods": str(args.methods),
                    "recent_lora_max_experts": 4,
                    "run_path_admission": True,
                    "path_admission_candidates": "0,0.25,0.50,0.75,1.0",
                    "path_admission_delta": 0.05,
                    "path_admission_risk_tolerance": 0.0,
                    "run_multiround_semantic_admission": True,
                    "semantic_admission_lambda_risk": 1.0,
                    "semantic_admission_graph_mass_temperature": 10.0,
                    "semantic_admission_minimum_tempered_neighbor_mass": 0.1,
                    "fedrot_rotation_strength": 0.4,
                    "skip_heavy_personalized_baselines": True,
                    "heterogeneity_setting": str(config["heterogeneity_setting"])
                    + "-recent-lora-fair-fixed-rank",
                }
            )
            prepared = config_root / dataset_key / f"seed_{seed}.yaml"
            save_yaml_copy(prepared, config)
            if args.prepare_only:
                continue
            complete = output_dir / "metrics.csv"
            if complete.exists() and not args.force:
                print(f"SKIP complete: {dataset_key} seed={seed}", flush=True)
                continue
            print(f"RUN {dataset_key} seed={seed}", flush=True)
            log_path = log_root / f"{dataset_key}_seed_{seed}.log"
            command = [sys.executable, "-m", "fedadaptermanifold.run_experiment", "--config", str(prepared)]
            with log_path.open("w", encoding="utf-8") as log_file:
                completed = subprocess.run(command, stdout=log_file, stderr=subprocess.STDOUT, check=False)
            if completed.returncode != 0:
                raise RuntimeError(f"Run failed ({completed.returncode}); inspect {log_path}")

    _aggregate(root, datasets, seeds)
    return 0


def _aggregate(root: Path, datasets: list[str], seeds: list[int]) -> None:
    metrics: list[dict] = []
    per_client: list[dict] = []
    for dataset_key in datasets:
        for seed in seeds:
            run_dir = root / dataset_key / f"seed_{seed}"
            metrics.extend(_read_csv(run_dir / "metrics.csv", dataset_key))
            per_client.extend(_read_csv(run_dir / "per_client_metrics.csv", dataset_key))
    if metrics:
        _write_csv(root / "all_seed_metrics.csv", metrics)
    if per_client:
        _write_csv(root / "all_seed_per_client_metrics.csv", per_client)


def _read_csv(path: Path, dataset_key: str) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        row["fairness_dataset_key"] = dataset_key
    return rows


def _write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
