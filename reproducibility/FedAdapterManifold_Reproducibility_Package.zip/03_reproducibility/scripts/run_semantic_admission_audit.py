from __future__ import annotations

import argparse
import csv
import glob
import sys
from pathlib import Path
from statistics import NormalDist

import numpy as np


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from fedadaptermanifold.aggregation import (
    receiver_subspace_projected_aggregate,
    semantic_admissible_lift_aggregate,
)
from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.baselines import (
    evaluate_client_adapters,
    run_ditto_lora_baseline,
    run_local_lora,
    run_semantic_admission_lora,
    select_loss_constrained_graph_mix,
)
from fedadaptermanifold.config import merge_defaults
from fedadaptermanifold.diagnostics import run_subspace_failure_diagnostic
from fedadaptermanifold.geometry import FedGeoFileGeometryProvider, LocalPrototypeGeometry, label_distance_matrix
from fedadaptermanifold.reporting import write_csv
from fedadaptermanifold.recent_lora_baselines import run_fedsa_lora_baseline
from fedadaptermanifold.training import evaluate_adapter_error_vector, evaluate_adapter_loss_vector
from fedadaptermanifold.run_experiment import (
    _load_clients,
    _risk_metric_rows,
    _split_clients_for_candidate_selection,
    build_arg_parser,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit risk-corrected exact-update semantic admission.")
    parser.add_argument("--config-glob", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--run-multiround-norisk", action="store_true")
    parser.add_argument("--run-multiround-projection", action="store_true")
    parser.add_argument(
        "--receiver-projection-mode",
        choices=("core", "left", "right", "tangent", "left_gauge", "right_gauge", "axis_gauge", "axis_factor"),
        default="core",
    )
    parser.add_argument(
        "--receiver-projection-policy",
        choices=("fallback", "always"),
        default="fallback",
    )
    parser.add_argument(
        "--projection-round-gate-policy",
        choices=("loss-constrained", "candidate-trajectory"),
        default="loss-constrained",
    )
    parser.add_argument(
        "--projection-final-gate-policy",
        choices=("loss-constrained", "loss-min"),
        default="loss-constrained",
        help="Final held-out projection gate; loss-min is finite-candidate empirical risk minimization.",
    )
    parser.add_argument(
        "--receiver-projection-cost-mode",
        choices=("full", "shared-axis"),
        default="full",
    )
    parser.add_argument(
        "--receiver-projection-support-mode",
        choices=("graph", "soft-dgeo", "shared-axis-all"),
        default="graph",
    )
    parser.add_argument("--receiver-projection-knn", type=int, default=2)
    parser.add_argument(
        "--run-residual-bank",
        action="store_true",
        help="Select among local, full-update admission, and axis-projected admission on held-out calibration data.",
    )
    parser.add_argument(
        "--residual-bank-policy",
        choices=("loss-min", "error-min", "paired-ucb", "risk-route"),
        default="paired-ucb",
    )
    parser.add_argument("--residual-bank-delta", type=float, default=0.05)
    parser.add_argument(
        "--run-risk-stratified-center",
        action="store_true",
        help="Use a Tukey training-risk split to route high-risk receivers through projected transport.",
    )
    parser.add_argument(
        "--dual-transport-personal-anchor",
        choices=("none", "ditto"),
        default="none",
        help=(
            "Optional pre-registered personalized safety anchor. With 'ditto', "
            "transport must pass paired certificates against Local-LoRA and Ditto-LoRA; "
            "failed admission falls back deterministically to Ditto-LoRA."
        ),
    )
    parser.add_argument(
        "--dual-transport-path-personal-weights",
        default="",
        help=(
            "Optional fixed comma-separated personal-anchor weights for the certified path "
            "between a personalized anchor and the raw semantic-admission transport. "
            "Empty disables path candidates; weight 1 is already represented by the anchor."
        ),
    )
    parser.add_argument("--run-risk-self-anchor", action="store_true")
    parser.add_argument("--risk-self-anchor-strength", type=float, default=1.0)
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    paths = sorted(Path(path) for path in glob.glob(args.config_glob))
    if not paths:
        raise FileNotFoundError(args.config_glob)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    all_metrics: list[dict] = []
    all_gates: list[dict] = []
    all_weights: list[dict] = []
    all_risk: list[dict] = []
    for path in paths:
        defaults = merge_defaults(str(path))
        run_args = build_arg_parser(defaults).parse_args(["--config", str(path)])
        seed_metrics = output_dir / f"seed_{run_args.seed}_per_client_metrics.csv"
        seed_gates = output_dir / f"seed_{run_args.seed}_admission_gates.csv"
        seed_weights = output_dir / f"seed_{run_args.seed}_admission_weights.csv"
        seed_risk = output_dir / f"seed_{run_args.seed}_risk_metrics.csv"
        if seed_metrics.exists() and seed_gates.exists() and seed_weights.exists() and seed_risk.exists() and not args.force:
            metrics = read_csv(seed_metrics)
            gates = read_csv(seed_gates)
            weights = read_csv(seed_weights)
            risk = read_csv(seed_risk)
        else:
            metrics, gates, weights, risk = run_one(
                run_args,
                include_multiround_norisk=args.run_multiround_norisk,
                include_multiround_projection=args.run_multiround_projection,
                receiver_projection_mode=args.receiver_projection_mode,
                receiver_projection_policy=args.receiver_projection_policy,
                projection_round_gate_policy=args.projection_round_gate_policy,
                projection_final_gate_policy=args.projection_final_gate_policy,
                receiver_projection_cost_mode=args.receiver_projection_cost_mode,
                receiver_projection_support_mode=args.receiver_projection_support_mode,
                receiver_projection_knn=args.receiver_projection_knn,
                include_residual_bank=args.run_residual_bank,
                residual_bank_policy=args.residual_bank_policy,
                residual_bank_delta=args.residual_bank_delta,
                include_risk_stratified_center=args.run_risk_stratified_center,
                dual_transport_personal_anchor=args.dual_transport_personal_anchor,
                dual_transport_path_personal_weights=args.dual_transport_path_personal_weights,
                include_risk_self_anchor=args.run_risk_self_anchor,
                risk_self_anchor_strength=args.risk_self_anchor_strength,
            )
            write_csv(seed_metrics, metrics)
            write_csv(seed_gates, gates)
            write_csv(seed_weights, weights)
            write_csv(seed_risk, risk)
        all_metrics.extend(metrics)
        all_gates.extend(gates)
        all_weights.extend(weights)
        all_risk.extend(risk)
    write_csv(output_dir / "per_client_metrics.csv", all_metrics)
    write_csv(output_dir / "admission_gates.csv", all_gates)
    write_csv(output_dir / "admission_weights.csv", all_weights)
    write_csv(output_dir / "risk_metrics.csv", all_risk)
    write_csv(output_dir / "semantic_conflict_metrics.csv", summarize_semantic_conflict(all_weights))
    write_csv(output_dir / "metrics.csv", summarize(all_metrics))
    return 0


def run_one(
    args: argparse.Namespace,
    include_multiround_norisk: bool = False,
    include_multiround_projection: bool = False,
    receiver_projection_mode: str = "core",
    receiver_projection_policy: str = "fallback",
    projection_round_gate_policy: str = "loss-constrained",
    projection_final_gate_policy: str = "loss-constrained",
    receiver_projection_cost_mode: str = "full",
    receiver_projection_support_mode: str = "graph",
    receiver_projection_knn: int = 2,
    include_residual_bank: bool = False,
    residual_bank_policy: str = "paired-ucb",
    residual_bank_delta: float = 0.05,
    include_risk_stratified_center: bool = False,
    dual_transport_personal_anchor: str = "none",
    dual_transport_path_personal_weights: str = "",
    include_risk_self_anchor: bool = False,
    risk_self_anchor_strength: float = 1.0,
) -> tuple[list[dict], list[dict], list[dict], list[dict]]:
    clients, base_weight, _ = _load_clients(args)
    clients, selector_clients, _ = _split_clients_for_candidate_selection(
        clients,
        fraction=args.candidate_selector_calibration_fraction,
        strategy=args.candidate_selector_calibration_strategy,
        seed=args.seed,
    )
    geometry_dir = args.geometry_outputs_dir or args.fedgeo_dir
    provider = FedGeoFileGeometryProvider(geometry_dir) if geometry_dir else LocalPrototypeGeometry()
    geometry = provider.build(clients, num_classes=int(base_weight.shape[0]), round_id=int(args.round_id))
    ranks = [int(args.rank) for _ in clients]
    sample_weights = np.asarray([len(client.y_train) for client in clients], dtype=np.float64)
    sample_weights /= np.clip(sample_weights.sum(), 1e-12, None)
    local = run_local_lora(
        clients,
        base_weight,
        ranks=ranks,
        epochs=int(args.rounds) * int(args.local_epochs),
        lr=float(args.lr),
        batch_size=int(args.batch_size),
        seed=int(args.seed),
        dataset=str(args.dataset),
        heterogeneity_setting=str(args.heterogeneity_setting),
        round_id=int(args.rounds),
    )
    diagnostic = run_subspace_failure_diagnostic(
        clients,
        base_weight,
        local.adapters,
        d_geo=geometry.d_geo,
        d_label=label_distance_matrix(clients, int(base_weight.shape[0])),
        lambda_geo=float(args.lambda_geo),
        lambda_label=float(args.lambda_label),
        tau=float(args.tau),
        diagnostic_threshold=float(args.diagnostic_threshold),
    )
    methods: dict[str, list] = {"Local-LoRA": local.adapters}
    method_adapters: dict[str, list] = {"Local-LoRA": local.adapters}
    raw_multiround_candidates: dict[str, list] = {}
    gates: list[dict] = []
    weight_rows: list[dict] = []
    for label, risk_weight in (("FAM-Admit-NoRisk", 0.0), ("FAM-Admit", 1.0)):
        candidates, weights = semantic_admissible_lift_aggregate(
            local.adapters,
            graph=geometry.graph,
            d_sub=diagnostic.d_sub,
            d_geo=geometry.d_geo,
            d_label=diagnostic.d_label,
            d_local_risk=diagnostic.d_local_risk,
            target_ranks=ranks,
            lambda_geo=float(args.lambda_geo),
            lambda_label=float(args.lambda_label),
            lambda_risk=risk_weight,
            tau=float(args.tau),
            self_weight=float(args.adapter_graph_self_weight),
            graph_mass_temperature=float(args.semantic_admission_graph_mass_temperature),
            minimum_tempered_neighbor_mass=float(args.semantic_admission_minimum_tempered_neighbor_mass),
            name_prefix=label.lower().replace("-", "_"),
        )
        selected, selection_rows = select_loss_constrained_graph_mix(
            selector_clients,
            base_weight,
            local.adapters,
            candidates,
            ranks=ranks,
            candidates=args.adapter_graph_mix_candidates,
            tolerance=float(args.adapter_graph_mix_tolerance),
            policy=str(args.adapter_graph_mix_policy),
        )
        methods[f"{label}-Ungated"] = candidates
        methods[label] = selected
        method_adapters[f"{label}-Ungated"] = candidates
        method_adapters[label] = selected
        for row in selection_rows:
            row.update({"method": label, "seed": int(args.seed), "selection_split": "heldout_calibration"})
        gates.extend(selection_rows)
        for i, client_i in enumerate(clients):
            for j, client_j in enumerate(clients):
                weight_rows.append(
                    {
                        "method": label,
                        "seed": int(args.seed),
                        "receiver_client": client_i.client_id,
                        "donor_client": client_j.client_id,
                        "receiver_domain": client_i.domain,
                        "donor_domain": client_j.domain,
                        "round": int(args.rounds),
                        "admission_weight": float(weights[i, j]),
                        "fedavg_sample_weight": float(sample_weights[j]),
                        "d_sub": float(diagnostic.d_sub[i, j]),
                        "d_geo": float(geometry.d_geo[i, j]),
                        "d_label": float(diagnostic.d_label[i, j]),
                        "d_local_risk": float(diagnostic.d_local_risk[i, j]),
                    }
                )
    projection_mode = str(receiver_projection_mode)
    projection_label = f"FAM-Receiver{projection_mode.title()}Projection"
    projected, projected_weights = receiver_subspace_projected_aggregate(
        local.adapters,
        graph=geometry.graph,
        d_sub=diagnostic.d_sub,
        d_geo=geometry.d_geo,
        d_label=diagnostic.d_label,
        d_local_risk=diagnostic.d_local_risk,
        target_ranks=ranks,
        lambda_geo=float(args.lambda_geo),
        lambda_label=float(args.lambda_label),
        lambda_risk=float(args.semantic_admission_lambda_risk),
        tau=float(args.tau),
        self_weight=float(args.adapter_graph_self_weight),
        projection_mode=projection_mode,
    )
    projected_selected, projected_selection_rows = select_loss_constrained_graph_mix(
        selector_clients,
        base_weight,
        local.adapters,
        projected,
        ranks=ranks,
        candidates=args.adapter_graph_mix_candidates,
        tolerance=float(args.adapter_graph_mix_tolerance),
        policy=str(args.adapter_graph_mix_policy),
    )
    methods[f"{projection_label}-Ungated"] = projected
    methods[projection_label] = projected_selected
    method_adapters[f"{projection_label}-Ungated"] = projected
    method_adapters[projection_label] = projected_selected
    for row in projected_selection_rows:
        row.update(
            {
                "method": projection_label,
                "seed": int(args.seed),
                "selection_split": "heldout_calibration",
            }
        )
    gates.extend(projected_selection_rows)
    for i, client_i in enumerate(clients):
        for j, client_j in enumerate(clients):
            weight_rows.append(
                {
                    "method": projection_label,
                    "seed": int(args.seed),
                    "receiver_client": client_i.client_id,
                    "donor_client": client_j.client_id,
                    "receiver_domain": client_i.domain,
                    "donor_domain": client_j.domain,
                    "round": int(args.rounds),
                    "admission_weight": float(projected_weights[i, j]),
                    "fedavg_sample_weight": float(sample_weights[j]),
                    "d_sub": float(diagnostic.d_sub[i, j]),
                    "d_geo": float(geometry.d_geo[i, j]),
                    "d_label": float(diagnostic.d_label[i, j]),
                    "d_local_risk": float(diagnostic.d_local_risk[i, j]),
                }
            )
    risk_prior_candidates = [
        np.asarray(values, dtype=np.float64)
        for values in (geometry.risk_geo_scores, geometry.feature_energy_deficit)
        if values is not None
    ]
    receiver_risk_prior = (
        np.maximum.reduce(risk_prior_candidates) if risk_prior_candidates else np.zeros(len(clients), dtype=np.float64)
    )
    multiround_specs = [
        (
            "FedAdapterManifold-Admit",
            1.0,
            False,
            0.0,
            "loss-constrained",
            str(args.adapter_graph_mix_policy),
        )
    ]
    if include_multiround_norisk:
        multiround_specs.append(
            (
                "FedAdapterManifold-Admit-NoRisk",
                0.0,
                False,
                0.0,
                "loss-constrained",
                str(args.adapter_graph_mix_policy),
            )
        )
    if include_multiround_projection:
        projection_method = (
            "FedAdapterManifold-AxisFactorTrajectory"
            if (
                str(projection_round_gate_policy) == "candidate-trajectory"
                and str(receiver_projection_mode) == "axis_factor"
            )
            else
            "FedAdapterManifold-AxisDecoupledTrajectory"
            if (
                str(projection_round_gate_policy) == "candidate-trajectory"
                and str(receiver_projection_cost_mode) == "shared-axis"
                and str(receiver_projection_support_mode) == "graph"
            )
            else "FedAdapterManifold-AxisSoftGraphTrajectory"
            if (
                str(projection_round_gate_policy) == "candidate-trajectory"
                and str(receiver_projection_cost_mode) == "shared-axis"
                and str(receiver_projection_support_mode) == "soft-dgeo"
            )
            else "FedAdapterManifold-AxisSemanticTrajectory"
            if (
                str(projection_round_gate_policy) == "candidate-trajectory"
                and str(receiver_projection_cost_mode) == "shared-axis"
                and str(receiver_projection_support_mode) == "shared-axis-all"
            )
            else "FedAdapterManifold-AxisTrajectory"
            if str(projection_round_gate_policy) == "candidate-trajectory"
            else "FedAdapterManifold-AdmitProject"
        )
        if str(projection_final_gate_policy) == "loss-min":
            projection_method = f"{projection_method}-ERM"
        multiround_specs.append(
            (
                projection_method,
                1.0,
                True,
                0.0,
                str(projection_round_gate_policy),
                str(projection_final_gate_policy),
            )
        )
    if include_risk_self_anchor:
        multiround_specs.append(
            (
                "FedAdapterManifold-AdmitFair",
                1.0,
                False,
                float(risk_self_anchor_strength),
                "loss-constrained",
                str(args.adapter_graph_mix_policy),
            )
        )
    metrics: list[dict] = []
    selected_candidate_by_method: dict[str, dict[str, str]] = {}
    for (
        multiround_method,
        multiround_risk_weight,
        projection_fallback,
        self_anchor_strength,
        round_gate_policy,
        final_gate_policy,
    ) in multiround_specs:
        multiround = run_semantic_admission_lora(
            clients,
            selector_clients,
            base_weight,
            graph=geometry.graph,
            d_geo=geometry.d_geo,
            d_label=diagnostic.d_label,
            ranks=ranks,
            rounds=int(args.rounds),
            local_epochs=int(args.local_epochs),
            lr=float(args.lr),
            batch_size=int(args.batch_size),
            seed=int(args.seed),
            dataset=str(args.dataset),
            heterogeneity_setting=str(args.heterogeneity_setting),
            lambda_geo=float(args.lambda_geo),
            lambda_label=float(args.lambda_label),
            lambda_risk=multiround_risk_weight,
            tau=float(args.tau),
            self_weight=float(args.adapter_graph_self_weight),
            graph_mass_temperature=float(args.semantic_admission_graph_mass_temperature),
            minimum_tempered_neighbor_mass=float(args.semantic_admission_minimum_tempered_neighbor_mass),
            final_gate_candidates=args.adapter_graph_mix_candidates,
            final_gate_tolerance=float(args.adapter_graph_mix_tolerance),
            final_gate_policy=final_gate_policy,
            round_gate_policy=round_gate_policy,
            method=multiround_method,
            precomputed_local_fallback=local,
            enable_receiver_projection_fallback=projection_fallback,
            receiver_projection_mode=projection_mode,
            receiver_projection_policy=receiver_projection_policy,
            receiver_projection_cost_mode=receiver_projection_cost_mode,
            receiver_projection_support_mode=receiver_projection_support_mode,
            receiver_projection_knn=receiver_projection_knn,
            receiver_risk_prior=receiver_risk_prior,
            risk_self_anchor_strength=self_anchor_strength,
        )
        for row in multiround.final_gate_rows:
            row["seed"] = int(args.seed)
        gates.extend(multiround.final_gate_rows)
        for row in multiround.admission_rows:
            row["seed"] = int(args.seed)
        weight_rows.extend(multiround.admission_rows)
        metrics.extend(multiround.per_client_metrics)
        method_adapters[multiround_method] = multiround.client_adapters
        raw_multiround_candidates[multiround_method] = multiround.candidate_adapters
    if include_residual_bank:
        if not include_multiround_projection:
            raise ValueError("--run-residual-bank requires --run-multiround-projection")
        bank_candidates = {
            "Local-LoRA": local.adapters,
            "FedAdapterManifold-Admit": raw_multiround_candidates["FedAdapterManifold-Admit"],
            projection_method: raw_multiround_candidates[projection_method],
        }
        bank_adapters, bank_rows = select_residual_admission_bank(
            selector_clients,
            base_weight,
            bank_candidates,
            policy="paired-ucb" if residual_bank_policy == "risk-route" else residual_bank_policy,
            delta=residual_bank_delta,
        )
        bank_method = "FedAdapterManifold-ResidualBank"
        for row in bank_rows:
            row.update(
                {
                    "method": bank_method,
                    "seed": int(args.seed),
                    "round": int(args.rounds),
                    "selection_split": "heldout_calibration",
                }
            )
        gates.extend(bank_rows)
        methods[bank_method] = bank_adapters
        method_adapters[bank_method] = bank_adapters
    if include_risk_stratified_center:
        if not include_multiround_projection:
            raise ValueError("--run-risk-stratified-center requires --run-multiround-projection")
        local_training_risk = np.asarray(
            [
                float(evaluate_adapter_loss_vector(client.x_train, client.y_train, base_weight, adapter).mean())
                for client, adapter in zip(clients, local.adapters)
            ],
            dtype=np.float64,
        )
        q1, q3 = np.percentile(local_training_risk, [25.0, 75.0])
        risk_threshold = float(q3 + 1.5 * max(float(q3 - q1), 1e-12))
        high_risk = local_training_risk > risk_threshold
        # Receiver risk controls how a client consumes the shared axis; it does
        # not by itself prove that the same client is an unsafe donor. Retain
        # all donors in the shared-axis center and route only high-risk
        # receivers through the projected transport branch.
        donor_mask = np.ones(len(clients), dtype=bool)
        robust_center_method = "FedAdapterManifold-SharedAxisCenter"
        robust_center = run_fedsa_lora_baseline(
            clients,
            base_weight,
            ranks=ranks,
            rounds=int(args.rounds),
            local_epochs=int(args.local_epochs),
            lr=float(args.lr),
            batch_size=int(args.batch_size),
            seed=int(args.seed),
            dataset=str(args.dataset),
            heterogeneity_setting=str(args.heterogeneity_setting),
            method=robust_center_method,
            weight_decay=1e-4,
            shared_axis_donor_mask=donor_mask,
        )
        raw_axis = raw_multiround_candidates[projection_method]
        stratified_candidate = [
            raw_axis[idx] if bool(high_risk[idx]) else robust_center.personal_adapters[idx]
            for idx in range(len(clients))
        ]
        bank_policy = "paired-ucb" if residual_bank_policy == "risk-route" else residual_bank_policy
        personal_anchor = str(dual_transport_personal_anchor).strip().lower()
        certificate_candidates = {
            "Local-LoRA": local.adapters,
            robust_center_method: robust_center.personal_adapters,
            "FedAdapterManifold-RiskStratifiedCandidate": stratified_candidate,
        }
        certificate_anchors = ("Local-LoRA", robust_center_method)
        fallback_anchor_name = None
        if personal_anchor == "ditto":
            ditto = run_ditto_lora_baseline(
                clients,
                base_weight,
                ranks=ranks,
                rounds=int(args.rounds),
                local_epochs=int(args.local_epochs),
                lr=float(args.lr),
                batch_size=int(args.batch_size),
                seed=int(args.seed),
                dataset=str(args.dataset),
                heterogeneity_setting=str(args.heterogeneity_setting),
                prox_mu=float(args.ditto_mu),
                method="Ditto-LoRA",
            )
            certificate_candidates = {
                "Local-LoRA": local.adapters,
                "Ditto-LoRA": ditto.personal_adapters,
                "FedAdapterManifold-RiskStratifiedCandidate": stratified_candidate,
            }
            path_weights = _parse_transport_path_weights(dual_transport_path_personal_weights)
            semantic_transport = raw_multiround_candidates["FedAdapterManifold-Admit"]
            for personal_weight in path_weights:
                candidate_name = f"FedAdapterManifold-AnchoredPath-p{personal_weight:.2f}"
                certificate_candidates[candidate_name] = _anchored_transport_path(
                    ditto.personal_adapters,
                    semantic_transport,
                    personal_weight=personal_weight,
                    ranks=ranks,
                    name_prefix=candidate_name,
                )
            certificate_anchors = ("Local-LoRA", "Ditto-LoRA")
            fallback_anchor_name = "Ditto-LoRA"
            methods["Ditto-LoRA"] = ditto.personal_adapters
            method_adapters["Ditto-LoRA"] = ditto.personal_adapters
        elif personal_anchor != "none":
            raise ValueError(f"Unsupported dual transport personal anchor: {personal_anchor}")
        certified_adapters, stratified_rows = select_residual_admission_bank(
            selector_clients,
            base_weight,
            certificate_candidates,
            policy=bank_policy,
            delta=residual_bank_delta,
            certificate_anchor_names=certificate_anchors,
            fallback_anchor_name=fallback_anchor_name,
        )
        if residual_bank_policy == "risk-route":
            certified_name_by_client = {
                str(row["client_id"]): str(row["selected_adapter"])
                for row in stratified_rows
                if bool(row["selected"])
            }
            if personal_anchor == "ditto":
                # In a personalization-ceiling protocol, every receiver is
                # protected by the declared personalized anchor. Shared-axis
                # transport remains a candidate rather than an unconditional
                # replacement for low-risk receivers.
                stratified_adapters = certified_adapters
                actual_name_by_client = certified_name_by_client
            else:
                stratified_adapters = [
                    certified_adapters[idx] if bool(high_risk[idx]) else stratified_candidate[idx]
                    for idx in range(len(clients))
                ]
                actual_name_by_client = {
                    client.client_id: (
                        certified_name_by_client[client.client_id]
                        if bool(high_risk[idx])
                        else "FedAdapterManifold-RiskStratifiedCandidate"
                    )
                    for idx, client in enumerate(clients)
                }
            for row in stratified_rows:
                client_id = str(row["client_id"])
                row["paired_ucb_selected_adapter"] = row["selected_adapter"]
                row["selected_adapter"] = actual_name_by_client[client_id]
                row["selected"] = str(row["candidate_adapter"]) == actual_name_by_client[client_id]
                row["adapter_graph_mix_policy"] = "risk-route-low-shared-high-paired-ucb"
        else:
            stratified_adapters = certified_adapters
            actual_name_by_client = {
                str(row["client_id"]): str(row["selected_adapter"])
                for row in stratified_rows
                if bool(row["selected"])
            }
        stratified_method = "FedAdapterManifold-DualTransport"
        selected_candidate_by_method[stratified_method] = actual_name_by_client
        risk_by_client = {
            client.client_id: (float(local_training_risk[idx]), bool(high_risk[idx]))
            for idx, client in enumerate(clients)
        }
        for row in stratified_rows:
            training_risk, is_high_risk = risk_by_client[str(row["client_id"])]
            row.update(
                {
                    "method": stratified_method,
                    "seed": int(args.seed),
                    "round": int(args.rounds),
                    "selection_split": "heldout_calibration",
                    "local_training_risk": training_risk,
                    "risk_outlier_threshold": risk_threshold,
                    "risk_stratum": "projected_receiver" if is_high_risk else "shared_axis_receiver",
                }
            )
        gates.extend(stratified_rows)
        methods[robust_center_method] = robust_center.personal_adapters
        method_adapters[robust_center_method] = robust_center.personal_adapters
        methods[stratified_method] = stratified_adapters
        method_adapters[stratified_method] = stratified_adapters
    for method, adapters in methods.items():
        method_metrics = evaluate_client_adapters(
                method,
                clients,
                base_weight,
                adapters,
                ranks=ranks,
                seed=int(args.seed),
                dataset=str(args.dataset),
                heterogeneity_setting=str(args.heterogeneity_setting),
                round_id=int(args.rounds),
            )
        selected_by_client = selected_candidate_by_method.get(method, {})
        for row in method_metrics:
            if selected_by_client:
                row["selected_candidate"] = selected_by_client[str(row["client_id"])]
        metrics.extend(method_metrics)
    risk = _risk_metric_rows(metrics, method_adapters, local.adapters, geometry.graph)
    return metrics, gates, weight_rows, risk


def _parse_transport_path_weights(raw: str) -> tuple[float, ...]:
    if not str(raw).strip():
        return ()
    values = []
    for token in str(raw).split(","):
        value = float(token.strip())
        if not 0.0 <= value < 1.0:
            raise ValueError("dual transport path weights must satisfy 0 <= weight < 1")
        values.append(value)
    return tuple(sorted(set(values)))


def _anchored_transport_path(
    anchor_adapters: list[LoRAAdapter],
    transport_adapters: list[LoRAAdapter],
    *,
    personal_weight: float,
    ranks: list[int],
    name_prefix: str,
) -> list[LoRAAdapter]:
    if len(anchor_adapters) != len(transport_adapters) or len(anchor_adapters) != len(ranks):
        raise ValueError("anchored transport inputs must have one entry per receiver")
    personal_weight = float(personal_weight)
    if not 0.0 <= personal_weight < 1.0:
        raise ValueError("personal_weight must satisfy 0 <= weight < 1")
    output = []
    for idx, (anchor, transport, rank) in enumerate(zip(anchor_adapters, transport_adapters, ranks)):
        delta = personal_weight * anchor.delta() + (1.0 - personal_weight) * transport.delta()
        output.append(
            LoRAAdapter.from_delta(
                delta,
                rank=int(rank),
                alpha=float(rank),
                name=f"{name_prefix}_client_{idx}",
            )
        )
    return output


def select_residual_admission_bank(
    selector_clients: list,
    base_weight: np.ndarray,
    candidate_adapters: dict[str, list],
    policy: str = "paired-ucb",
    delta: float = 0.05,
    certificate_anchor_names: tuple[str, ...] | None = None,
    fallback_anchor_name: str | None = None,
) -> tuple[list, list[dict]]:
    """Select a receiver residual model from a fixed, pre-test candidate bank.

    Under ``paired-ucb``, a non-anchor candidate is admitted only when its
    paired loss upper bound is negative against every declared anchor. If no
    candidate passes this intersection certificate, the selector uses the
    declared fallback anchor when provided; otherwise calibration ERM chooses
    among the anchors. The default remains the original Local-LoRA certificate
    and calibration fallback so existing callers retain their behavior.
    """

    ordered = list(candidate_adapters.items())
    if not ordered:
        raise ValueError("candidate_adapters must not be empty")
    num_clients = len(selector_clients)
    if any(len(adapters) != num_clients for _, adapters in ordered):
        raise ValueError("Each residual-bank candidate must contain one adapter per client")
    if ordered[0][0] != "Local-LoRA":
        raise ValueError("The first residual-bank candidate must be Local-LoRA")
    names = [name for name, _ in ordered]
    if certificate_anchor_names is None:
        certificate_anchor_names = ("Local-LoRA",)
    certificate_anchor_names = tuple(str(name) for name in certificate_anchor_names)
    if not certificate_anchor_names:
        raise ValueError("certificate_anchor_names must contain at least one anchor")
    missing_anchors = [name for name in certificate_anchor_names if name not in names]
    if missing_anchors:
        raise ValueError(f"Unknown certificate anchors: {missing_anchors}")
    anchor_indices = [names.index(name) for name in certificate_anchor_names]
    if fallback_anchor_name is not None and str(fallback_anchor_name) not in certificate_anchor_names:
        raise ValueError("fallback_anchor_name must be one of certificate_anchor_names")
    fallback_anchor_index = names.index(str(fallback_anchor_name)) if fallback_anchor_name is not None else None
    candidate_indices = [index for index in range(len(ordered)) if index not in anchor_indices]
    policy = str(policy).strip().lower()
    if policy not in {"loss-min", "error-min", "paired-ucb"}:
        raise ValueError("policy must be 'loss-min', 'error-min', or 'paired-ucb'")
    delta = min(max(float(delta), 1e-8), 0.5)
    comparisons = max(1, len(candidate_indices) * len(anchor_indices))
    z_value = float(NormalDist().inv_cdf(1.0 - delta / comparisons))
    selected = []
    rows: list[dict] = []
    for idx, client in enumerate(selector_clients):
        loss_vectors = [
            evaluate_adapter_loss_vector(client.x_train, client.y_train, base_weight, adapters[idx])
            for _, adapters in ordered
        ]
        error_vectors = [
            evaluate_adapter_error_vector(client.x_train, client.y_train, base_weight, adapters[idx])
            for _, adapters in ordered
        ]
        losses = np.asarray([float(values.mean()) for values in loss_vectors], dtype=np.float64)
        errors = np.asarray([float(values.mean()) for values in error_vectors], dtype=np.float64)
        paired_mean = np.zeros(len(ordered), dtype=np.float64)
        paired_se = np.zeros(len(ordered), dtype=np.float64)
        paired_ucb = np.zeros(len(ordered), dtype=np.float64)
        worst_anchor_name = [""] * len(ordered)
        worst_anchor_mean = np.zeros(len(ordered), dtype=np.float64)
        worst_anchor_se = np.zeros(len(ordered), dtype=np.float64)
        all_anchor_certified = np.zeros(len(ordered), dtype=bool)
        local_values = np.asarray(loss_vectors[0], dtype=np.float64)
        for candidate_idx in candidate_indices:
            local_difference = np.asarray(loss_vectors[candidate_idx], dtype=np.float64) - local_values
            paired_mean[candidate_idx] = float(local_difference.mean())
            paired_se[candidate_idx] = (
                float(local_difference.std(ddof=1) / np.sqrt(local_difference.size))
                if local_difference.size > 1
                else float("inf")
            )
            anchor_means = []
            anchor_standard_errors = []
            anchor_ucbs = []
            for anchor_idx in anchor_indices:
                difference = np.asarray(loss_vectors[candidate_idx], dtype=np.float64) - np.asarray(
                    loss_vectors[anchor_idx], dtype=np.float64
                )
                difference_mean = float(difference.mean())
                standard_error = (
                    float(difference.std(ddof=1) / np.sqrt(difference.size))
                    if difference.size > 1
                    else float("inf")
                )
                anchor_means.append(difference_mean)
                anchor_standard_errors.append(standard_error)
                anchor_ucbs.append(difference_mean + z_value * standard_error)
            worst_idx = int(np.argmax(anchor_ucbs))
            paired_ucb[candidate_idx] = float(anchor_ucbs[worst_idx])
            worst_anchor_name[candidate_idx] = certificate_anchor_names[worst_idx]
            worst_anchor_mean[candidate_idx] = float(anchor_means[worst_idx])
            worst_anchor_se[candidate_idx] = float(anchor_standard_errors[worst_idx])
            all_anchor_certified[candidate_idx] = bool(np.all(np.asarray(anchor_ucbs) < 0.0))
        if policy == "loss-min":
            selected_idx = int(np.argmin(losses))
        elif policy == "error-min":
            selected_idx = min(range(len(ordered)), key=lambda candidate_idx: (errors[candidate_idx], losses[candidate_idx]))
        else:
            certified = [candidate_idx for candidate_idx in candidate_indices if all_anchor_certified[candidate_idx]]
            selected_idx = (
                min(certified, key=lambda candidate_idx: losses[candidate_idx])
                if certified
                else (
                    int(fallback_anchor_index)
                    if fallback_anchor_index is not None
                    else min(anchor_indices, key=lambda anchor_idx: losses[anchor_idx])
                )
            )
        selected_name, selected_adapters = ordered[selected_idx]
        selected.append(selected_adapters[idx].copy(name=f"residual_bank_client_{idx}"))
        for candidate_idx, (candidate_name, _) in enumerate(ordered):
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "adapter_graph_mix_policy": f"fixed-residual-bank-{policy}",
                    "candidate_adapter": candidate_name,
                    "selected_adapter": selected_name,
                    "candidate_graph_mix_loss": float(losses[candidate_idx]),
                    "best_graph_mix_loss": float(losses.min()),
                    "candidate_classification_error": float(errors[candidate_idx]),
                    "best_classification_error": float(errors.min()),
                    "adapter_graph_mix_tolerance": 0.0,
                    "paired_loss_difference_vs_local": float(paired_mean[candidate_idx]),
                    "paired_loss_standard_error": float(paired_se[candidate_idx]),
                    "paired_loss_upper_confidence_bound": float(paired_ucb[candidate_idx]),
                    "certificate_anchor_names": ";".join(certificate_anchor_names),
                    "fallback_anchor_name": str(fallback_anchor_name or "calibration-erm"),
                    "worst_certificate_anchor": worst_anchor_name[candidate_idx],
                    "paired_loss_difference_vs_worst_anchor": float(worst_anchor_mean[candidate_idx]),
                    "paired_loss_standard_error_vs_worst_anchor": float(worst_anchor_se[candidate_idx]),
                    "all_anchor_ucb_certified": bool(all_anchor_certified[candidate_idx]),
                    "residual_bank_delta": delta,
                    "residual_bank_z_value": z_value,
                    "selected": candidate_idx == selected_idx,
                }
            )
    return selected, rows


def summarize_semantic_conflict(rows: list[dict]) -> list[dict]:
    grouped: dict[tuple[int, str, int, str], list[dict]] = {}
    required = {"seed", "method", "round", "receiver_client", "admission_weight", "fedavg_sample_weight", "d_sub", "d_local_risk"}
    for row in rows:
        if not required.issubset(row) or any(row.get(key, "") == "" for key in required):
            continue
        key = (
            int(row["seed"]),
            str(row["method"]),
            int(row["round"]),
            str(row["receiver_client"]),
        )
        grouped.setdefault(key, []).append(row)
    output = []
    for (seed, method, round_id, receiver), group in sorted(grouped.items()):
        admitted = np.asarray([float(row["admission_weight"]) for row in group], dtype=np.float64)
        fedavg = np.asarray([float(row["fedavg_sample_weight"]) for row in group], dtype=np.float64)
        d_sub = np.asarray([float(row["d_sub"]) for row in group], dtype=np.float64)
        d_risk = np.asarray([float(row["d_local_risk"]) for row in group], dtype=np.float64)
        admitted /= np.clip(admitted.sum(), 1e-12, None)
        fedavg /= np.clip(fedavg.sum(), 1e-12, None)
        admitted_subspace = float(np.sum(admitted * d_sub))
        fedavg_subspace = float(np.sum(fedavg * d_sub))
        admitted_risk = float(np.sum(admitted * d_risk))
        fedavg_risk = float(np.sum(fedavg * d_risk))
        output.append(
            {
                "seed": seed,
                "method": method,
                "round": round_id,
                "receiver_client": receiver,
                "admitted_subspace_conflict": admitted_subspace,
                "fedavg_subspace_conflict": fedavg_subspace,
                "subspace_conflict_reduction_vs_fedavg": fedavg_subspace - admitted_subspace,
                "admitted_local_risk": admitted_risk,
                "fedavg_local_risk": fedavg_risk,
                "local_risk_reduction_vs_fedavg": fedavg_risk - admitted_risk,
            }
        )
    return output


def summarize(rows: list[dict]) -> list[dict]:
    grouped: dict[str, list[dict]] = {}
    for row in rows:
        grouped.setdefault(str(row["method"]), []).append(row)
    output = []
    for method, group in sorted(grouped.items()):
        by_seed: dict[int, list[dict]] = {}
        for row in group:
            by_seed.setdefault(int(row["seed"]), []).append(row)
        seed_means = [float(np.mean([float(row["accuracy"]) for row in seed_rows])) for seed_rows in by_seed.values()]
        seed_worst = [float(np.min([float(row["accuracy"]) for row in seed_rows])) for seed_rows in by_seed.values()]
        output.append(
            {
                "method": method,
                "seed_count": len(by_seed),
                "mean_accuracy": float(np.mean(seed_means)),
                "seed_sd_accuracy": float(np.std(seed_means, ddof=1)) if len(seed_means) > 1 else 0.0,
                "mean_worst_client_accuracy": float(np.mean(seed_worst)),
                "mean_loss": float(np.mean([float(row["loss"]) for row in group])),
            }
        )
    return output


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


if __name__ == "__main__":
    raise SystemExit(main())
