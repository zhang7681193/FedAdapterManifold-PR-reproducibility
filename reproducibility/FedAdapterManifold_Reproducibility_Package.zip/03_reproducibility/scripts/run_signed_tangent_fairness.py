from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.config import load_yaml, save_yaml_copy


SOURCE_ROOTS = {
    "pacs_resnet18": Path("results/fam_pacs_manifest_fedavg_fedper_fam_5seed_v1"),
    "officecaltech_resnet18": Path("results/fam_officecaltech_neighbor_selector_fedrot_w050_v1"),
    "domainnetmini_clip_60class": Path("results/fam_domainnetmini_manifest_fedavg_fedper_fam_5seed_v1"),
    "bloodmnist_label_skew": Path("results/fam_blood_manifest_fedavg_fedper_fam_5seed_v1"),
    "officehome_dinov2_full": Path("results/fam_dinov2_officehome_full_calib20_noregret_5seed_v1"),
    "officehome_clip_full": Path("results/fam_clip_officehome_full_calib20_noregret_5seed_v2"),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the frozen receiver-signed tangent admission protocol."
    )
    parser.add_argument("--datasets", default=",".join(SOURCE_ROOTS))
    parser.add_argument("--seeds", default="0,1,2,3,4")
    parser.add_argument(
        "--output-root",
        default="results/fam_signed_tangent_fairness_dev_20260813",
    )
    parser.add_argument(
        "--sources",
        default="semantic,subspace",
        help="Training-fixed transport source order. Do not tune this after test evaluation.",
    )
    parser.add_argument("--alpha-max", type=float, default=1.0)
    parser.add_argument("--loss-margin", type=float, default=0.0)
    parser.add_argument(
        "--calibration-fraction",
        type=float,
        default=0.20,
        help="Training-side fraction reserved before adapter fitting for the independent gate.",
    )
    parser.add_argument(
        "--calibration-strategy",
        choices=["random", "stratified"],
        default="stratified",
    )
    parser.add_argument(
        "--protocol-stage",
        choices=["development", "confirmation"],
        default="development",
    )
    parser.add_argument(
        "--pacs-fresh-geometry-pattern",
        default="",
        help=(
            "Optional geometry_outputs directory pattern containing {seed}. "
            "Required for PACS seeds that have no source result config."
        ),
    )
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    datasets = [item.strip() for item in args.datasets.split(",") if item.strip()]
    seeds = [int(item.strip()) for item in args.seeds.split(",") if item.strip()]
    unknown = sorted(set(datasets) - set(SOURCE_ROOTS))
    if unknown:
        raise ValueError("Unknown datasets: " + ", ".join(unknown))
    if not 0.0 < float(args.alpha_max) <= 1.0:
        raise ValueError("--alpha-max must be in (0, 1]")
    if not 0.0 < float(args.calibration_fraction) < 1.0:
        raise ValueError("--calibration-fraction must be in (0, 1)")

    output_root = Path(args.output_root)
    config_root = output_root / "configs"
    log_root = output_root / "logs"
    config_root.mkdir(parents=True, exist_ok=True)
    log_root.mkdir(parents=True, exist_ok=True)
    for dataset in datasets:
        source_root = SOURCE_ROOTS[dataset]
        for seed in seeds:
            source = source_root / f"seed_{seed}" / "config.yaml"
            fresh_geometry = ""
            if not source.exists():
                if dataset != "pacs_resnet18" or not args.pacs_fresh_geometry_pattern:
                    raise FileNotFoundError(f"Missing source config: {source}")
                source = source_root / "seed_0" / "config.yaml"
                fresh_geometry = str(args.pacs_fresh_geometry_pattern).format(seed=seed)
                if not Path(fresh_geometry).exists():
                    raise FileNotFoundError(f"Missing fresh-seed geometry directory: {fresh_geometry}")
            config = load_yaml(source)
            output_dir = output_root / dataset / f"seed_{seed}"
            config.update(
                {
                    "output_dir": str(output_dir),
                    "seed": int(seed),
                    "run_multiround_semantic_admission": True,
                    "run_signed_tangent_admission": True,
                    "signed_tangent_sources": str(args.sources),
                    "signed_tangent_alpha_max": float(args.alpha_max),
                    "signed_tangent_derivative_margin": 0.0,
                    "signed_tangent_loss_margin": float(args.loss_margin),
                    "candidate_selector_calibration_fraction": float(args.calibration_fraction),
                    "candidate_selector_calibration_strategy": str(args.calibration_strategy),
                    "run_recent_lora_baselines": False,
                    "skip_heavy_personalized_baselines": True,
                    # The signed-admission confirmation isolates semantic
                    # compatibility from resource heterogeneity.  A common
                    # rank is also required by the factor-alignment control.
                    # Rank heterogeneity is evaluated in its dedicated audit.
                    "rank_policy": "fixed",
                    "min_rank": int(config.get("rank", config.get("min_rank", 4))),
                    "max_rank": int(config.get("rank", config.get("max_rank", 4))),
                    "continue_on_failed_diagnostic": True,
                    "heterogeneity_setting": (
                        f"{config['heterogeneity_setting']}-signed-tangent-{args.protocol_stage}"
                    ),
                }
            )
            if fresh_geometry:
                config["geometry_outputs_dir"] = fresh_geometry
                config["fedgeo_dir"] = ""
            prepared = config_root / dataset / f"seed_{seed}.yaml"
            prepared.parent.mkdir(parents=True, exist_ok=True)
            save_yaml_copy(prepared, config)
            if args.prepare_only:
                continue
            if (output_dir / "metrics.csv").exists() and not args.force:
                print(f"SKIP {dataset} seed={seed}", flush=True)
                continue
            log_path = log_root / f"{dataset}_seed_{seed}.log"
            print(f"RUN {dataset} seed={seed}", flush=True)
            command = [
                sys.executable,
                "-m",
                "fedadaptermanifold.run_experiment",
                "--config",
                str(prepared),
            ]
            with log_path.open("w", encoding="utf-8") as log_file:
                completed = subprocess.run(
                    command,
                    stdout=log_file,
                    stderr=subprocess.STDOUT,
                    check=False,
                )
            if completed.returncode != 0:
                raise RuntimeError(f"Run failed ({completed.returncode}); inspect {log_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
