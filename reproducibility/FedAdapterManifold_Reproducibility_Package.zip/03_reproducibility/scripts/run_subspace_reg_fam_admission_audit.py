from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.config import load_yaml, save_yaml_copy


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the frozen PACS Subspace-Reg-anchor FAM residual audit."
    )
    parser.add_argument(
        "--source-root",
        type=Path,
        default=Path(
            "results/fam_internal_generator_admission_v5_5seed_20260813/"
            "configs/pacs_resnet18"
        ),
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("results/subspace_reg_fam_admission_pacs_5seed_20260813"),
    )
    parser.add_argument("--seeds", default="0,1,2,3,4")
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    seeds = [int(value) for value in args.seeds.split(",") if value.strip()]
    config_root = args.output_root / "configs"
    log_root = args.output_root / "logs"
    config_root.mkdir(parents=True, exist_ok=True)
    log_root.mkdir(parents=True, exist_ok=True)
    for seed in seeds:
        config = load_yaml(args.source_root / f"seed_{seed}.yaml")
        output = args.output_root / "pacs_resnet18" / f"seed_{seed}"
        config.update(
            {
                "output_dir": str(output),
                "seed": seed,
                "rank_policy": "fixed",
                "run_recent_lora_baselines": True,
                "recent_lora_methods": "fedsmooth,subspace_reg",
                "run_anchor_residual_admission": True,
                "anchor_residual_admission_sources": "geo,subspace,bank",
                "route_candidate_search_mode": "training-fixed",
                "calibration_shift_mode": "marginal",
                "candidate_selector_calibration_fraction": 0.2,
                "candidate_selector_calibration_strategy": "stratified",
                "heterogeneity_setting": (
                    "pacs-domain-split-subspace-reg-anchor-fam-residual-"
                    "training-fixed-cal20-confirmation"
                ),
            }
        )
        prepared = config_root / f"seed_{seed}.yaml"
        save_yaml_copy(prepared, config)
        if (output / "metrics.csv").exists() and not args.force:
            print(f"SKIP seed={seed}", flush=True)
            continue
        print(f"RUN seed={seed}", flush=True)
        with (log_root / f"seed_{seed}.log").open("w", encoding="utf-8") as stream:
            completed = subprocess.run(
                [sys.executable, "-m", "fedadaptermanifold.run_experiment", "--config", str(prepared)],
                stdout=stream,
                stderr=subprocess.STDOUT,
                check=False,
            )
        if completed.returncode != 0:
            raise RuntimeError(f"seed {seed} failed; inspect {log_root / f'seed_{seed}.log'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
