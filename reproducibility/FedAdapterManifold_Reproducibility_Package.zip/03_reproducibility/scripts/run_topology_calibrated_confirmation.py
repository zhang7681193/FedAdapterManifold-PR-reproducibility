from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

import yaml


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _python_source_hashes(root: Path) -> dict[str, str]:
    files = sorted((root / "fedadaptermanifold").glob("**/*.py"))
    files.extend(sorted((root / "scripts").glob("*.py")))
    return {str(path.relative_to(root)).replace("\\", "/"): _sha256(path) for path in files}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run the pre-registered topology-calibrated admission confirmation.")
    parser.add_argument("--workspace", required=True)
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--output-root", required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    workspace = Path(args.workspace).resolve()
    source_root = Path(args.source_root).resolve()
    output_root = Path(args.output_root).resolve()
    output_root.mkdir(parents=True, exist_ok=True)

    source_configs = sorted((source_root / "configs").glob("**/seed_*.yaml"))
    selected = [
        path
        for path in source_configs
        if "officehome" in path.parent.name.lower() or "domainnet" in path.parent.name.lower()
    ]
    if len(selected) != 10:
        raise RuntimeError(f"Expected 10 frozen OfficeHome/DomainNetMini configs, found {len(selected)}")

    manifest = {
        "protocol": "topology-calibrated-semantic-admission-v5",
        "status_at_creation": "pre-registered-before-test-runs",
        "scientific_question": (
            "Does separating graph support topology from edge magnitude restore non-degenerate semantic "
            "candidate generation without weakening the independent exact deployment certificate?"
        ),
        "datasets": ["OfficeHome-CLIP-full", "DomainNetMini-CLIP-60class"],
        "seeds": [0, 1, 2, 3, 4],
        "graph_scale_policy": "topology-calibrated",
        "topology_top_k": 2,
        "topology_neighbor_mass": 1.0,
        "support_constraint": "Only positive edges in the supplied geometry graph may be retained.",
        "selection_constraint": "No test label is used before the exact post-selection audit.",
        "primary_endpoints": [
            "candidate-generation non-degeneracy",
            "selected accuracy gain over immutable Local-LoRA",
            "selected accuracy gain over admitted Geo-only-Agg",
            "harmful admission count",
            "uncertified deployment count",
        ],
        "decision_rule": (
            "Support requires at least one certified non-local deployment, zero harmful and zero uncertified "
            "deployments, and a non-negative dataset-level gain; a positive hierarchical CI is reported only "
            "when observed and is not required to preserve a valid negative/control result."
        ),
        "source_configs": [str(path) for path in selected],
        "source_config_sha256": {str(path): _sha256(path) for path in selected},
        "frozen_implementation_root": str(Path.cwd().resolve()),
        "frozen_implementation_sha256": _python_source_hashes(Path.cwd().resolve()),
        "analysis_script_sha256": {
            "analyze_exact_receiver_admission.py": _sha256(
                workspace / "scripts" / "analyze_exact_receiver_admission.py"
            ),
            "analyze_topology_calibrated_confirmation.py": _sha256(
                workspace / "scripts" / "analyze_topology_calibrated_confirmation.py"
            ),
        },
    }
    manifest_text = json.dumps(manifest, indent=2, sort_keys=True)
    (output_root / "preregistered_protocol.json").write_text(manifest_text + "\n", encoding="utf-8")
    (output_root / "preregistered_protocol.sha256").write_text(
        hashlib.sha256(manifest_text.encode("utf-8")).hexdigest() + "\n",
        encoding="ascii",
    )

    config_root = output_root / "configs"
    for source in selected:
        config = yaml.safe_load(source.read_text(encoding="utf-8"))
        dataset_key = source.parent.name
        seed = int(config["seed"])
        run_dir = output_root / dataset_key / f"seed_{seed}"
        config.update(
            {
                "output_dir": str(run_dir),
                "heterogeneity_setting": f"{config['heterogeneity_setting']}-topology-calibrated-v5",
                "semantic_admission_graph_scale_policy": "topology-calibrated",
                "semantic_admission_topology_top_k": 2,
                "semantic_admission_topology_neighbor_mass": 1.0,
                "run_recent_lora_baselines": False,
                "recent_lora_methods": "",
                "run_signed_tangent_admission": False,
            }
        )
        target = config_root / dataset_key / f"seed_{seed}.yaml"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(yaml.safe_dump(config, sort_keys=True), encoding="utf-8")

    log_path = output_root / "run.log"
    env = os.environ.copy()
    env["PYTHONPATH"] = str(Path.cwd())
    with log_path.open("a", encoding="utf-8") as log:
        for config_path in sorted(config_root.glob("**/seed_*.yaml")):
            output_dir = Path(yaml.safe_load(config_path.read_text(encoding="utf-8"))["output_dir"])
            if (output_dir / "metrics.csv").is_file():
                log.write(f"SKIP complete {config_path}\n")
                log.flush()
                continue
            command = [sys.executable, "-m", "fedadaptermanifold.run_experiment", "--config", str(config_path)]
            log.write("RUN " + " ".join(command) + "\n")
            log.flush()
            completed = subprocess.run(command, cwd=Path.cwd(), env=env, stdout=log, stderr=subprocess.STDOUT)
            if completed.returncode != 0:
                raise RuntimeError(f"Run failed ({completed.returncode}): {config_path}")

    analyzer = workspace / "scripts" / "analyze_exact_receiver_admission.py"
    subprocess.run(
        [
            sys.executable,
            str(analyzer),
            "--result-root",
            str(output_root),
            "--certificate-file",
            "semantic_admission_exact_certificate.csv",
            "--bootstrap-replicates",
            "20000",
            "--seed",
            "20260813",
        ],
        cwd=workspace,
        check=True,
    )
    subprocess.run(
        [
            sys.executable,
            str(workspace / "scripts" / "analyze_topology_calibrated_confirmation.py"),
            "--result-root",
            str(output_root),
            "--bootstrap-replicates",
            "20000",
            "--seed",
            "20260813",
        ],
        cwd=workspace,
        check=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
