from __future__ import annotations

import argparse
import csv
from itertools import product
from pathlib import Path

import numpy as np


METHOD = "FedAdapterManifold-DualCertifiedPrototypeRoute"
CONTROL = "IntrinsicFull-SplitCertifiedControl"
LOCAL = "Local-LoRA"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--bootstrap-samples", type=int, default=50000)
    parser.add_argument("--seed", type=int, default=20260812)
    args = parser.parse_args()

    root = Path(args.root)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    seed_dirs = sorted(root.glob("seed_*"), key=lambda path: int(path.name.split("_")[-1]))
    if not seed_dirs:
        raise FileNotFoundError(f"No seed directories found under {root}")

    seed_rows: list[dict] = []
    paired_rows: list[dict] = []
    for seed_dir in seed_dirs:
        seed = int(seed_dir.name.split("_")[-1])
        metrics = _read_csv(seed_dir / "metrics.csv")
        by_method = {row["method"]: row for row in metrics}
        clients = _read_csv(seed_dir / "per_client_metrics.csv")
        client_lookup = {(row["method"], row["client_id"]): row for row in clients}
        client_ids = sorted({row["client_id"] for row in clients if row["method"] == METHOD})
        route_acc = float(by_method[METHOD]["mean_accuracy"])
        control_acc = float(by_method[CONTROL]["mean_accuracy"])
        local_acc = float(by_method[LOCAL]["mean_accuracy"])
        differences = []
        local_differences = []
        for client_id in client_ids:
            method_row = client_lookup[(METHOD, client_id)]
            control_row = client_lookup[(CONTROL, client_id)]
            local_row = client_lookup[(LOCAL, client_id)]
            difference = float(method_row["accuracy"]) - float(control_row["accuracy"])
            local_difference = float(method_row["accuracy"]) - float(local_row["accuracy"])
            differences.append(difference)
            local_differences.append(local_difference)
            paired_rows.append(
                {
                    "seed": seed,
                    "client_id": client_id,
                    "domain": method_row["domain"],
                    "route_accuracy": float(method_row["accuracy"]),
                    "control_accuracy": float(control_row["accuracy"]),
                    "local_accuracy": float(local_row["accuracy"]),
                    "gain_vs_control": difference,
                    "gain_vs_local": local_difference,
                    "selected_transport_family": method_row.get("selected_transport_family", ""),
                    "route_fraction": float(method_row.get("route_fraction") or 0.0),
                }
            )
        seed_rows.append(
            {
                "seed": seed,
                "route_accuracy": route_acc,
                "control_accuracy": control_acc,
                "local_accuracy": local_acc,
                "gain_vs_control": route_acc - control_acc,
                "gain_vs_local": route_acc - local_acc,
                "worst_client_gain_vs_control": float(min(differences)),
                "worst_client_gain_vs_local": float(min(local_differences)),
            }
        )

    control_values = np.asarray([row["gain_vs_control"] for row in seed_rows], dtype=np.float64)
    local_values = np.asarray([row["gain_vs_local"] for row in seed_rows], dtype=np.float64)
    control_ci = _cluster_bootstrap_ci(control_values, args.bootstrap_samples, args.seed)
    local_ci = _cluster_bootstrap_ci(local_values, args.bootstrap_samples, args.seed + 1)
    client_control = np.asarray([row["gain_vs_control"] for row in paired_rows], dtype=np.float64)
    summary = [
        {
            "comparison": "dual_route_vs_full_control",
            "num_seeds": len(seed_rows),
            "num_client_seed_pairs": len(paired_rows),
            "mean_gain": float(control_values.mean()),
            "ci_low_seed_clustered": float(control_ci[0]),
            "ci_high_seed_clustered": float(control_ci[1]),
            "exact_sign_flip_p_one_sided": _exact_sign_flip_p(control_values),
            "positive_pairs": int(np.sum(client_control > 1e-12)),
            "tied_pairs": int(np.sum(np.abs(client_control) <= 1e-12)),
            "negative_pairs": int(np.sum(client_control < -1e-12)),
            "worst_pair_gain": float(client_control.min()),
        },
        {
            "comparison": "dual_route_vs_local_lora",
            "num_seeds": len(seed_rows),
            "num_client_seed_pairs": len(paired_rows),
            "mean_gain": float(local_values.mean()),
            "ci_low_seed_clustered": float(local_ci[0]),
            "ci_high_seed_clustered": float(local_ci[1]),
            "exact_sign_flip_p_one_sided": _exact_sign_flip_p(local_values),
            "positive_pairs": int(sum(row["gain_vs_local"] > 1e-12 for row in paired_rows)),
            "tied_pairs": int(sum(abs(row["gain_vs_local"]) <= 1e-12 for row in paired_rows)),
            "negative_pairs": int(sum(row["gain_vs_local"] < -1e-12 for row in paired_rows)),
            "worst_pair_gain": float(min(row["gain_vs_local"] for row in paired_rows)),
        },
    ]
    _write_csv(output / "seed_metrics.csv", seed_rows)
    _write_csv(output / "paired_client_seed_metrics.csv", paired_rows)
    _write_csv(output / "summary.csv", summary)
    lines = [
        "# Dual-Certified Prototype Routing Confirmation",
        "",
        f"Seeds: {', '.join(str(row['seed']) for row in seed_rows)}.",
        "",
    ]
    for row in summary:
        lines.extend(
            [
                f"## {row['comparison']}",
                "",
                f"Mean gain: {row['mean_gain']:.6f}.",
                f"Seed-clustered 95% bootstrap CI: [{row['ci_low_seed_clustered']:.6f}, {row['ci_high_seed_clustered']:.6f}].",
                f"Exact one-sided sign-flip p: {row['exact_sign_flip_p_one_sided']:.6f}.",
                f"Client-seed positive/tie/negative: {row['positive_pairs']}/{row['tied_pairs']}/{row['negative_pairs']}.",
                f"Worst paired gain: {row['worst_pair_gain']:.6f}.",
                "",
            ]
        )
    (output / "summary.md").write_text("\n".join(lines), encoding="utf-8")
    return 0


def _cluster_bootstrap_ci(values: np.ndarray, samples: int, seed: int) -> tuple[float, float]:
    rng = np.random.default_rng(int(seed))
    indices = rng.integers(0, values.size, size=(max(int(samples), 1), values.size))
    means = values[indices].mean(axis=1)
    return float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def _exact_sign_flip_p(values: np.ndarray) -> float:
    observed = float(values.mean())
    if values.size == 0:
        return float("nan")
    statistics = []
    for signs in product((-1.0, 1.0), repeat=values.size):
        statistics.append(float(np.mean(values * np.asarray(signs, dtype=np.float64))))
    return float(np.mean(np.asarray(statistics) >= observed - 1e-15))


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
