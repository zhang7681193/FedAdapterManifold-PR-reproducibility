from __future__ import annotations

import argparse
import csv
from itertools import product
from pathlib import Path

import numpy as np


METHOD = "FedAdapterManifold-SplitMetaTargetParetoAdmit"
LOCAL = "Local-LoRA"
UNSCREENED = "IntrinsicPool-WithUnscreenedFull-Control"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--bootstrap-samples", type=int, default=50000)
    parser.add_argument("--bootstrap-seed", type=int, default=20260812)
    parser.add_argument("--method", default=METHOD)
    parser.add_argument("--report-title", default="Split-Meta Pareto Receiver-Relative Audit")
    args = parser.parse_args()

    root = Path(args.root)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    seed_dirs = sorted(root.glob("seed_*"), key=lambda path: int(path.name.split("_")[-1]))
    if not seed_dirs:
        raise FileNotFoundError(f"No seed directories found under {root}")

    seed_rows: list[dict] = []
    paired_rows: list[dict] = []
    for seed_dir in seed_dirs:
        seed = int(seed_dir.name.split("_")[-1])
        metrics = {row["method"]: row for row in _read_csv(seed_dir / "metrics.csv")}
        clients = _read_csv(seed_dir / "per_client_metrics.csv")
        lookup = {(row["method"], row["client_id"]): row for row in clients}
        client_ids = sorted(row["client_id"] for row in clients if row["method"] == args.method)
        method_accuracy = float(metrics[args.method]["mean_accuracy"])
        local_accuracy = float(metrics[LOCAL]["mean_accuracy"])
        unscreened_accuracy = float(metrics[UNSCREENED]["mean_accuracy"])
        seed_pairs: list[dict] = []
        for client_id in client_ids:
            method_row = lookup[(args.method, client_id)]
            local_row = lookup[(LOCAL, client_id)]
            unscreened_row = lookup[(UNSCREENED, client_id)]
            row = {
                "seed": seed,
                "client_id": client_id,
                "domain": method_row["domain"],
                "method_accuracy": float(method_row["accuracy"]),
                "local_accuracy": float(local_row["accuracy"]),
                "unscreened_accuracy": float(unscreened_row["accuracy"]),
                "gain_method_vs_local": float(method_row["accuracy"])
                - float(local_row["accuracy"]),
                "gain_method_vs_unscreened": float(method_row["accuracy"])
                - float(unscreened_row["accuracy"]),
                "gain_unscreened_vs_local": float(unscreened_row["accuracy"])
                - float(local_row["accuracy"]),
                "selected_transport_family": method_row.get("selected_transport_family", ""),
            }
            paired_rows.append(row)
            seed_pairs.append(row)
        seed_rows.append(
            {
                "seed": seed,
                "method_accuracy": method_accuracy,
                "local_accuracy": local_accuracy,
                "unscreened_accuracy": unscreened_accuracy,
                "gain_method_vs_local": method_accuracy - local_accuracy,
                "gain_method_vs_unscreened": method_accuracy - unscreened_accuracy,
                "gain_unscreened_vs_local": unscreened_accuracy - local_accuracy,
                "worst_client_gain_method_vs_local": min(
                    row["gain_method_vs_local"] for row in seed_pairs
                ),
                "fam_admitted_clients": sum(
                    row["selected_transport_family"] == "fam_split_meta"
                    for row in seed_pairs
                ),
            }
        )

    comparisons = (
        ("split_meta_vs_local", "gain_method_vs_local"),
        ("split_meta_vs_unscreened_full_pool", "gain_method_vs_unscreened"),
        ("unscreened_full_pool_vs_local", "gain_unscreened_vs_local"),
    )
    summary_rows: list[dict] = []
    for comparison_index, (name, field) in enumerate(comparisons):
        seed_values = np.asarray([row[field] for row in seed_rows], dtype=np.float64)
        pair_values = np.asarray([row[field] for row in paired_rows], dtype=np.float64)
        ci = _cluster_bootstrap_ci(
            seed_values,
            args.bootstrap_samples,
            args.bootstrap_seed + comparison_index,
        )
        summary_rows.append(
            {
                "comparison": name,
                "num_seeds": len(seed_rows),
                "num_client_seed_pairs": len(paired_rows),
                "mean_gain": float(seed_values.mean()),
                "ci_low_seed_clustered": float(ci[0]),
                "ci_high_seed_clustered": float(ci[1]),
                "exact_sign_flip_p_one_sided": _exact_sign_flip_p(seed_values),
                "positive_seeds": int(np.sum(seed_values > 1e-12)),
                "tied_seeds": int(np.sum(np.abs(seed_values) <= 1e-12)),
                "negative_seeds": int(np.sum(seed_values < -1e-12)),
                "positive_pairs": int(np.sum(pair_values > 1e-12)),
                "tied_pairs": int(np.sum(np.abs(pair_values) <= 1e-12)),
                "negative_pairs": int(np.sum(pair_values < -1e-12)),
                "worst_pair_gain": float(pair_values.min()),
            }
        )

    _write_csv(output / "seed_metrics.csv", seed_rows)
    _write_csv(output / "paired_client_seed_metrics.csv", paired_rows)
    _write_csv(output / "summary.csv", summary_rows)
    admitted = sum(row["selected_transport_family"] == "fam_split_meta" for row in paired_rows)
    lines = [
        f"# {args.report_title}",
        "",
        f"Seeds: {', '.join(str(row['seed']) for row in seed_rows)}.",
        f"FAM admissions: {admitted}/{len(paired_rows)} client-seed units.",
        "",
    ]
    for row in summary_rows:
        lines.extend(
            [
                f"## {row['comparison']}",
                "",
                f"Mean gain: {row['mean_gain']:.6f}.",
                "Seed-clustered 95% bootstrap CI: "
                f"[{row['ci_low_seed_clustered']:.6f}, {row['ci_high_seed_clustered']:.6f}].",
                f"Exact one-sided sign-flip p: {row['exact_sign_flip_p_one_sided']:.6f}.",
                "Seed positive/tie/negative: "
                f"{row['positive_seeds']}/{row['tied_seeds']}/{row['negative_seeds']}.",
                "Client-seed positive/tie/negative: "
                f"{row['positive_pairs']}/{row['tied_pairs']}/{row['negative_pairs']}.",
                f"Worst paired gain: {row['worst_pair_gain']:.6f}.",
                "",
            ]
        )
    (output / "summary.md").write_text("\n".join(lines), encoding="utf-8")
    return 0


def _cluster_bootstrap_ci(values: np.ndarray, samples: int, seed: int) -> tuple[float, float]:
    rng = np.random.default_rng(int(seed))
    indices = rng.integers(0, values.size, size=(max(int(samples), 1), values.size))
    means = values[indices].mean(axis=1)
    return float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def _exact_sign_flip_p(values: np.ndarray) -> float:
    observed = float(values.mean())
    statistics = [
        float(np.mean(values * np.asarray(signs, dtype=np.float64)))
        for signs in product((-1.0, 1.0), repeat=values.size)
    ]
    return float(np.mean(np.asarray(statistics) >= observed - 1e-15))


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
