from __future__ import annotations

from pathlib import Path
import shutil

from docx import Document
from docx.oxml.ns import qn


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "submission" / "pr_upload_items_20260619"
OUTPUT = ROOT / "submission" / "pr_resubmission_upload_items_20260803"

OLD_TITLE = "Federated Visual LoRA Adaptation via Adapter Subspace Manifold Routing"
NEW_TITLE = "FedAdapterManifold: Deciding When Federated Visual LoRA Adapters Are Safe to Share"

HIGHLIGHTS = [
    "LoRA subspace incompatibility predicts receiver-specific FedAvg failure.",
    "Adapter admission routes only compatible visual LoRA action subspaces.",
    "Anchored calibration prevents unsupported transfer without test selection.",
    "Five-seed DINOv2 and CLIP audits verify aggregation repair.",
    "Fidelity and hierarchical audits enforce fair, bounded comparisons.",
]


def iter_paragraphs(document: Document):
    yield from document.paragraphs
    for table in document.tables:
        for row in table.rows:
            for cell in row.cells:
                yield from cell.paragraphs


def replace_text(document: Document, old: str, new: str) -> None:
    for paragraph in iter_paragraphs(document):
        if old not in paragraph.text:
            continue
        text = paragraph.text.replace(old, new)
        if paragraph.runs:
            paragraph.runs[0].text = text
            for run in paragraph.runs[1:]:
                run.text = ""
        else:
            paragraph.add_run(text)


def apply_times_new_roman(document: Document) -> None:
    for style in document.styles:
        if not hasattr(style, "font"):
            continue
        style.font.name = "Times New Roman"
        style.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    for paragraph in iter_paragraphs(document):
        for run in paragraph.runs:
            run.font.name = "Times New Roman"
            run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "Times New Roman")


def prepare_copy(relative_path: str) -> Path:
    src = SOURCE / relative_path
    dst = OUTPUT / relative_path
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return dst


def update_highlights() -> Path:
    relative = "02_Highlights/FedAdapterManifold_Highlights.docx"
    path = prepare_copy(relative)
    document = Document(path)
    replace_text(document, OLD_TITLE, NEW_TITLE)
    paragraphs = document.paragraphs
    start = next(i for i, p in enumerate(paragraphs) if p.text == NEW_TITLE) + 1
    slots = [p for p in paragraphs[start:] if p.text and not p.text.startswith("Note:")]
    if len(slots) < len(HIGHLIGHTS):
        raise RuntimeError("Highlights document does not contain five editable highlight paragraphs")
    for paragraph, value in zip(slots[:5], HIGHLIGHTS):
        paragraph.text = value
    if any(len(value) > 85 for value in HIGHLIGHTS):
        raise RuntimeError("Elsevier highlights must not exceed 85 characters")
    apply_times_new_roman(document)
    document.save(path)
    return path


def update_declaration() -> Path:
    relative = "03_Declaration_of_competing_interests/Declaration_of_Competing_Interests_No_Conflict.docx"
    path = prepare_copy(relative)
    document = Document(path)
    replace_text(document, OLD_TITLE, NEW_TITLE)
    replace_text(document, "19 June 2026", "3 August 2026")
    apply_times_new_roman(document)
    document.save(path)
    return path


def update_title_page() -> Path:
    relative = "05_Title_page_with_author_details/FedAdapterManifold_Title_Page_with_Author_Details.docx"
    path = prepare_copy(relative)
    document = Document(path)
    replace_text(document, OLD_TITLE, NEW_TITLE)
    replace_text(document, "Federated Visual LoRA Adapter Manifold Routing", "Federated Visual LoRA Adapter Admissibility")
    apply_times_new_roman(document)
    document.save(path)
    return path


def main() -> int:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    for path in (update_highlights(), update_declaration(), update_title_page()):
        print(path.relative_to(ROOT))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
