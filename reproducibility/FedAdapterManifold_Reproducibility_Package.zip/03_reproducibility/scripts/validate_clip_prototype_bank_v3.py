#!/usr/bin/env python3
"""Validate protocol, provenance, routing, and fallback for CLIP prototype-bank v3."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import pandas as pd
import yaml


WORKSPACE = Path(__file__).resolve().parents[1]
STAGING = WORKSPACE / "staging_clip_prototype_bank_v3_20260813"
RUNNER = WORKSPACE / "staging_clip_subspace_uncertainty_v2_20260813/run_clip_vit_lora_federated_pooled.py"
FEDGEO = WORKSPACE.parent / "you-are-implementing-the-first-and/results"
SEEDS = tuple(range(5, 10))
LOCAL = "Local-CLIP-LoRA"
RAW = "FedAdapterManifold-PrototypeBank-Raw-CLIP-LoRA"
DEPLOYED = "FedAdapterManifold-PrototypeBank-Certified-CLIP-LoRA"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--result-root",
        type=Path,
        default=WORKSPACE
        / "results/fam_clip_e2e_prototype_bank_route_domainnet60_seed5to9_20260813",
    )
    return parser.parse_args()


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def truth(value: object) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["scope", "check", "passed", "detail"])
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    args = parse_args()
    root = args.result_root.resolve()
    protocol = json.loads((root / "preregistered_protocol.json").read_text(encoding="utf-8"))
    rows: list[dict[str, object]] = []

    def check(scope: str, name: str, passed: bool, detail: object) -> None:
        rows.append({"scope": scope, "check": name, "passed": bool(passed), "detail": str(detail)})

    check("protocol", "confirmation_seeds", tuple(protocol.get("confirmation_seeds", [])) == SEEDS, protocol.get("confirmation_seeds"))
    check("protocol", "fedavg_geometry_only", protocol.get("geometry_source") == "FedAvg geometry outputs for every confirmation seed", protocol.get("geometry_source"))
    check("protocol", "test_label_free", protocol.get("test_labels_used_for_selection") is False, protocol.get("test_labels_used_for_selection"))
    check("source", "runner_hash", sha256(RUNNER) == protocol.get("runner_sha256"), sha256(RUNNER))
    check("source", "queue_hash", sha256(STAGING / "run_prototype_bank_queue.py") == protocol.get("queue_sha256"), sha256(STAGING / "run_prototype_bank_queue.py"))

    total_units = 0
    for seed in SEEDS:
        scope = f"seed_{seed}"
        geometry = FEDGEO / f"domainnetmini_pretrained_active_sparse50_compare_seed{seed}/geometry_outputs"
        config_path = geometry.parent / "config.yaml"
        config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
        check(scope, "geometry_source_method", config.get("methods") == ["fedavg"], config.get("methods"))
        expected_hashes = protocol["geometry_hashes"][scope]
        for name, expected in expected_hashes.items():
            path = geometry / name
            check(scope, f"geometry_hash:{name}", path.exists() and sha256(path) == expected, path)

        seed_root = root / "shot_4" / scope
        required = [
            seed_root / "metrics.csv",
            seed_root / "per_client_metrics.csv",
            seed_root / "prototype_bank_routing.csv",
            seed_root / "config.yaml",
        ]
        check(scope, "required_files", all(path.exists() for path in required), [path.name for path in required])
        if not all(path.exists() for path in required):
            continue
        clients = pd.read_csv(required[1])
        routing = pd.read_csv(required[2])
        receiver_ids = sorted(clients[clients["method"] == LOCAL]["client_id"].unique())
        check(scope, "six_receivers", len(receiver_ids) == 6, receiver_ids)
        total_units += len(receiver_ids)
        for client_id in receiver_ids:
            unit = f"{scope}/client_{client_id}"
            local = clients[(clients["method"] == LOCAL) & (clients["client_id"] == client_id)]
            raw = clients[(clients["method"] == RAW) & (clients["client_id"] == client_id)]
            deployed = clients[(clients["method"] == DEPLOYED) & (clients["client_id"] == client_id)]
            route = routing[routing["receiver_client_id"] == client_id]
            check(unit, "method_rows", len(local) == len(raw) == len(deployed) == 1, (len(local), len(raw), len(deployed)))
            check(unit, "routing_splits", set(route["split"]) == {"calibration", "test"}, set(route["split"]))
            check(unit, "external_nonlocal_route", route["external_route"].map(truth).all(), route["external_route"].unique())
            check(unit, "self_excluded", (route["receiver_client_id"] != route["donor_client_id"]).all(), "receiver != donor")
            certificates = {truth(value) for value in route["certified"]}
            check(unit, "consistent_certificate", len(certificates) == 1, certificates)
            if len(local) == len(deployed) == 1 and len(certificates) == 1:
                certified = next(iter(certificates))
                fallback = (
                    abs(float(local.iloc[0]["accuracy"]) - float(deployed.iloc[0]["accuracy"])) <= 1e-12
                    and abs(float(local.iloc[0]["loss"]) - float(deployed.iloc[0]["loss"])) <= 1e-12
                )
                check(unit, "exact_local_fallback", certified or fallback, f"certified={certified} fallback={fallback}")

    summary = root / "analysis/prototype_bank_summary.csv"
    units = root / "analysis/prototype_bank_units.csv"
    check("analysis", "summary_row", summary.exists() and len(pd.read_csv(summary)) == 1, summary)
    check("analysis", "unit_rows", units.exists() and len(pd.read_csv(units)) == 30, units)
    check("analysis", "receiver_unit_total", total_units == 30, total_units)

    validation = root / "final_validation"
    write_csv(validation / "validation_checks.csv", rows)
    failures = [row for row in rows if not row["passed"]]
    report = [
        "# CLIP Prototype-Bank v3 Validation",
        "",
        f"- Checks: {len(rows)}",
        f"- Passed: {len(rows) - len(failures)}",
        f"- Failed: {len(failures)}",
        f"- Receiver units: {total_units}",
        "",
    ]
    if failures:
        report.extend(["## Failures", ""] + [f"- {row['scope']} / {row['check']}: {row['detail']}" for row in failures])
    else:
        report.append("All frozen source, FedAvg-geometry, routing, and fallback checks pass.")
    (validation / "validation_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
