from __future__ import annotations

import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "results" / "fam_pr_evidence_pack_v15" / "main_accuracy_with_strong_baselines.csv"
STABILITY = ROOT / "results" / "fam_pr_stability_audit_v1" / "key_method_seed_stability.csv"
CLUSTERED = ROOT / "results" / "fam_admit_clustered_stats_v1" / "clustered_subspace_failure_correlation.csv"
HIERARCHICAL = ROOT / "results" / "fam_hierarchical_subspace_effect_20260805" / "hierarchical_effect_summary.csv"
INCREMENTAL = ROOT / "results" / "fam_incremental_subspace_diagnostic_20260805" / "incremental_effect_summary.csv"
OPPORTUNITY = ROOT / "results" / "fam_opportunity_certificates_20260629" / "opportunity_certificate_combined_summary.csv"
CANONICAL = ROOT / "results" / "fam_canonical_admission_gate_20260810" / "canonical_admission_setting_summary.csv"
MANUSCRIPT_CANONICAL = ROOT / "results" / "core_manuscript_tables_20260812" / "canonical_safety_utility.csv"
MANUSCRIPT_E2E = ROOT / "results" / "core_manuscript_tables_20260812" / "end_to_end_clip_admission.csv"
MANUSCRIPT_RECENT = ROOT / "results" / "recent_lora_receiver_admission_overlay_20260812" / "receiver_admission_setting_summary.csv"
OUTPUT = ROOT / "paper_resubmit" / "core_evidence_validation.md"


CORE = {
    "PACS": {
        "source": "canonical",
        "dataset": "PACS",
        "cluster_dataset": "PACS",
        "fedavg": 0.5891,
        "geo": 0.7547,
        "admit_value": 0.7547,
        "r": 0.264,
        "ci": (-0.079, 0.535),
    },
    "Office-Caltech": {
        "source": "canonical",
        "dataset": "Office-Caltech",
        "cluster_dataset": "OfficeCaltech",
        "fedavg": 0.8866,
        "geo": 0.9050,
        "admit_value": 0.9455,
        "r": 0.085,
        "ci": (-0.268, 0.390),
    },
    "DomainNetMini": {
        "source": "canonical",
        "dataset": "DomainNetMini",
        "cluster_dataset": "DomainNetMini",
        "fedavg": 0.7915,
        "geo": 0.8044,
        "admit_value": 0.8068,
        "r": 0.294,
        "ci": (0.046, 0.471),
    },
    "BloodMNIST": {
        "source": "canonical",
        "dataset": "BloodMNIST",
        "cluster_dataset": "BloodMNIST",
        "fedavg": 0.4253,
        "geo": 0.7635,
        "admit_value": 0.7645,
        "r": 0.129,
        "ci": (0.004, 0.257),
    },
    "OfficeHome-DINOv2": {
        "source": "canonical",
        "dataset": "OfficeHome-DINOv2",
        "cluster_dataset": "DINOv2-OfficeHome",
        "fedavg": 0.7276,
        "geo": 0.7506,
        "admit_value": 0.7506,
        "r": 0.656,
        "ci": (0.473, 0.803),
    },
    "OfficeHome-CLIP": {
        "source": "canonical",
        "dataset": "OfficeHome-CLIP",
        "cluster_dataset": "CLIP-OfficeHome",
        "fedavg": 0.7081,
        "geo": 0.7280,
        "admit_value": 0.7280,
        "r": 0.440,
        "ci": (0.227, 0.648),
    },
}


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def close(actual: float, expected: float, digits: int) -> bool:
    return round(float(actual), digits) == round(float(expected), digits)


def main() -> int:
    evidence = {(r["dataset"], r["method"]): r for r in read_rows(EVIDENCE)}
    stability = {(r["dataset"], r["method"]): r for r in read_rows(STABILITY)}
    canonical = {r["setting"]: r for r in read_rows(CANONICAL)}
    clustered = {(r["dataset"], r["measure"]): r for r in read_rows(CLUSTERED)}
    errors: list[str] = []
    checks: list[str] = []

    manuscript_canonical = {r["setting"]: r for r in read_rows(MANUSCRIPT_CANONICAL)}
    for setting, expected in {
        "PACS": (0.5891, 0.7547, 0.7547, 0.0173, 0.0000, 0.0000, 1.00, 0, 0),
        "Office-Caltech": (0.8866, 0.9050, 0.9455, 0.0107, 0.0405, 0.0609, 0.60, 8, 0),
        "DomainNetMini": (0.7915, 0.8044, 0.8068, 0.0035, 0.0024, 0.0000, 1 / 3, 5, 1),
        "BloodMNIST": (0.4253, 0.7635, 0.7645, 0.0345, 0.0011, 0.0144, 0.05, 0, 1),
        "OfficeHome-DINOv2": (0.7276, 0.7506, 0.7506, 0.0026, 0.0000, 0.0000, 0.30, 0, 0),
        "OfficeHome-CLIP": (0.7081, 0.7280, 0.7280, 0.0060, 0.0000, 0.0000, 0.20, 0, 0),
    }.items():
        row = manuscript_canonical.get(setting)
        if row is None:
            errors.append(f"{setting}: missing manuscript canonical table row")
            continue
        actual = (
            float(row["fedavg_accuracy"]), float(row["geo_accuracy"]), float(row["fam_accuracy"]),
            float(row["fam_seed_sd"]), float(row["delta_vs_geo"]), float(row["worst_client_delta_vs_geo"]),
            float(row["share_coverage"]), int(row["admitted_positive"]), int(row["admitted_negative"]),
        )
        ok = all(close(a, e, 4) for a, e in zip(actual[:7], expected[:7])) and actual[7:] == expected[7:]
        checks.append(f"{setting} canonical safety/utility row -> {'pass' if ok else 'FAIL'}")
        if not ok:
            errors.append(f"{setting}: manuscript safety/utility mismatch; expected={expected}, source={actual}")

    manuscript_e2e = {r["setting"]: r for r in read_rows(MANUSCRIPT_E2E)}
    for setting, expected in {
        "PACS-7": (0.9758, 0.9675, 0.9709, 0.9758, 0.9694, 0, 0, 0, 0),
        "OfficeCaltech-10": (0.9766, 0.9732, 0.9769, 0.9763, 0.9786, 5, 0, 4, 1),
        "DomainNetMini-60": (0.7926, 0.7745, 0.7804, 0.7926, 0.7754, 2, 0, 2, 0),
    }.items():
        row = manuscript_e2e.get(setting)
        if row is None:
            errors.append(f"{setting}: missing end-to-end table row")
            continue
        actual = (
            float(row["local_accuracy"]), float(row["fedavg_accuracy"]), float(row["geo_accuracy"]),
            float(row["fam_accuracy"]), float(row["lift_accuracy"]), int(row["nonlocal_selected"]),
            int(row["positive_units_vs_local"]), int(row["neutral_units_vs_local"]),
            int(row["negative_units_vs_local"]),
        )
        ok = all(close(a, e, 4) for a, e in zip(actual[:5], expected[:5])) and actual[5:] == expected[5:]
        checks.append(f"{setting} end-to-end admission row -> {'pass' if ok else 'FAIL'}")
        if not ok:
            errors.append(f"{setting}: end-to-end table mismatch; expected={expected}, source={actual}")

    manuscript_recent = {r["setting"]: r for r in read_rows(MANUSCRIPT_RECENT)}
    for setting, expected in {
        "PACS-R18": (0.6828, 0.6931, 0.0311, 0.0103, 1, 4, 0, True),
        "OfficeHome-CLIP": (0.7310, 0.7752, 0.0067, 0.0442, 5, 0, 0, False),
        "DomainNetMini-CLIP": (0.8114495717626422, 0.8144798747929454, 0.0036785168273910, 0.0030303030303031, 4, 1, 0, True),
    }.items():
        row = manuscript_recent.get(setting)
        if row is None:
            errors.append(f"{setting}: missing recent-method admission row")
            continue
        actual = (
            float(row["reference_accuracy_mean"]), float(row["fam_accuracy_mean"]),
            float(row["fam_accuracy_seed_sd"]), float(row["paired_gain"]), int(row["positive_seeds"]),
            int(row["tie_seeds"]), int(row["negative_seeds"]), row["composition_from_reference"] == "True",
        )
        ok = all(close(a, e, 4) for a, e in zip(actual[:4], expected[:4])) and actual[4:] == expected[4:]
        checks.append(f"{setting} recent-method admission row -> {'pass' if ok else 'FAIL'}")
        if not ok:
            errors.append(f"{setting}: recent-method table mismatch; expected={expected}, source={actual}")

    for display, spec in CORE.items():
        dataset = spec["dataset"]
        if spec["source"] == "canonical":
            row = canonical.get(dataset)
            if row is None:
                errors.append(f"{display}: missing canonical row {dataset}")
            else:
                for value_key, expected, label in [
                    ("fedavg_accuracy", spec["fedavg"], "FedAvg"),
                    ("geo_accuracy", spec["geo"], "Geo-only"),
                    ("canonical_accuracy", spec["admit_value"], "Canonical Admit"),
                ]:
                    actual = float(row[value_key])
                    ok = close(actual, expected, 4)
                    checks.append(f"{display} {label}: {actual:.4f} -> {'pass' if ok else 'FAIL'}")
                    if not ok:
                        errors.append(
                            f"{display} {label}: manuscript {expected:.4f}, source {actual:.4f}"
                        )
        else:
            index = evidence if spec["source"] == "evidence" else stability
            value_key = "mean_accuracy" if spec["source"] == "evidence" else "mean"
            for method, expected, label in [
                ("FedAvg-LoRA", spec["fedavg"], "FedAvg"),
                ("FedGeo-Agg", spec["geo"], "Geo-only"),
                (spec["admit"], spec["admit_value"], "Intrinsic Admit"),
            ]:
                row = index.get((dataset, method))
                if row is None:
                    errors.append(f"{display}: missing {spec['source']} row {dataset}/{method}")
                    continue
                actual = float(row[value_key])
                ok = close(actual, expected, 4)
                checks.append(f"{display} {label}: {actual:.4f} -> {'pass' if ok else 'FAIL'}")
                if not ok:
                    errors.append(
                        f"{display} {label}: manuscript {expected:.4f}, source {actual:.4f}"
                    )

        row = clustered.get((spec["cluster_dataset"], "d_sub"))
        if row is None:
            errors.append(f"{display}: missing clustered d_sub row")
            continue
        actual_r = float(row["pooled_pearson_r"])
        actual_ci = (float(row["hierarchical_ci_low"]), float(row["hierarchical_ci_high"]))
        ok = close(actual_r, spec["r"], 3) and all(
            close(actual, expected, 3) for actual, expected in zip(actual_ci, spec["ci"])
        )
        checks.append(
            f"{display} d_sub: r={actual_r:.3f}, CI=[{actual_ci[0]:.3f},{actual_ci[1]:.3f}] -> "
            f"{'pass' if ok else 'FAIL'}"
        )
        if not ok:
            errors.append(f"{display}: clustered diagnostic mismatch")

    opportunity = {r["dataset"]: r for r in read_rows(OPPORTUNITY)}
    for dataset in ("OfficeHome-DINOv2", "OfficeHome-CLIP"):
        row = opportunity.get(dataset)
        if row is None:
            errors.append(f"{dataset}: missing opportunity certificate")
            continue
        actual = (
            int(row["num_client_seed_units"]),
            int(row["certified_personalization_ceiling"]),
            int(row["positive_transfer_admitted"]),
            float(row["mean_client_gain_vs_anchor"]),
        )
        expected = (20, 20, 0, 0.0)
        ok = actual[:3] == expected[:3] and close(actual[3], expected[3], 8)
        checks.append(
            f"{dataset} expanded pool: units/fallback/admit={actual[0]}/{actual[1]}/{actual[2]}, "
            f"gain vs selected anchor={actual[3]:.4f} -> {'pass' if ok else 'FAIL'}"
        )
        if not ok:
            errors.append(f"{dataset}: expanded-pool attribution mismatch; source={actual}")

    hierarchical_rows = read_rows(HIERARCHICAL)
    if len(hierarchical_rows) != 1:
        errors.append("All-setting hierarchical effect must contain exactly one summary row")
    else:
        row = hierarchical_rows[0]
        actual = (
            float(row["equal_family_fisher_r"]),
            float(row["hierarchical_ci_low"]),
            float(row["hierarchical_ci_high"]),
            int(row["n_dataset_families"]),
            int(row["n_backbone_settings"]),
            int(row["n_federated_seeds"]),
            float(row["family_sign_test_one_sided_p"]),
        )
        expected = (0.215, 0.068, 0.413, 5, 11, 55, 0.03125)
        ok = (
            all(close(a, e, 3) for a, e in zip(actual[:3], expected[:3]))
            and actual[3:6] == expected[3:6]
            and close(actual[6], expected[6], 5)
        )
        checks.append(
            "All-setting d_sub effect: "
            f"r={actual[0]:.3f}, CI=[{actual[1]:.3f},{actual[2]:.3f}], "
            f"families/settings/seeds={actual[3]}/{actual[4]}/{actual[5]}, p={actual[6]:.5f} -> "
            f"{'pass' if ok else 'FAIL'}"
        )
        if not ok:
            errors.append(f"All-setting hierarchical mismatch; manuscript={expected}, source={actual}")

    incremental_rows = read_rows(INCREMENTAL)
    if len(incremental_rows) != 1:
        errors.append("Controlled incremental diagnostic must contain exactly one summary row")
    else:
        row = incremental_rows[0]
        actual = (
            int(row["n_rows"]),
            int(row["n_settings"]),
            int(row["n_families"]),
            float(row["d_sub_standardized_beta"]),
            float(row["hierarchical_ci_low"]),
            float(row["hierarchical_ci_high"]),
            float(row["partial_r"]),
            float(row["incremental_r2"]),
        )
        expected = (730, 7, 5, 0.2228, 0.0873, 0.4600, 0.2163, 0.0457)
        ok = actual[:3] == expected[:3] and all(
            close(a, e, 4) for a, e in zip(actual[3:], expected[3:])
        )
        checks.append(
            "Controlled d_sub effect: "
            f"rows/settings/families={actual[0]}/{actual[1]}/{actual[2]}, beta={actual[3]:.4f}, "
            f"CI=[{actual[4]:.4f},{actual[5]:.4f}], partial-r={actual[6]:.4f}, dR2={actual[7]:.4f} -> "
            f"{'pass' if ok else 'FAIL'}"
        )
        if not ok:
            errors.append(f"Controlled incremental mismatch; manuscript={expected}, source={actual}")

    lines = [
        "# Core Evidence Table Validation",
        "",
        f"- Intrinsic source: `{EVIDENCE.relative_to(ROOT)}`",
        f"- Backbone source: `{STABILITY.relative_to(ROOT)}`",
        f"- Diagnostic source: `{CLUSTERED.relative_to(ROOT)}`",
        f"- Controlled source: `{INCREMENTAL.relative_to(ROOT)}`",
        f"- Opportunity source: `{OPPORTUNITY.relative_to(ROOT)}`",
        f"- Canonical admission source: `{CANONICAL.relative_to(ROOT)}`",
        f"- Main safety/utility table: `{MANUSCRIPT_CANONICAL.relative_to(ROOT)}`",
        f"- Main end-to-end table: `{MANUSCRIPT_E2E.relative_to(ROOT)}`",
        f"- Recent-method admission table: `{MANUSCRIPT_RECENT.relative_to(ROOT)}`",
        f"- Status: {'FAIL' if errors else 'PASS'}",
        "",
        "## Checks",
        "",
    ]
    lines.extend(f"- {item}" for item in checks)
    lines.extend(["", "## Errors", ""])
    lines.extend(f"- {item}" for item in errors)
    if not errors:
        lines.append("- None")
    OUTPUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
