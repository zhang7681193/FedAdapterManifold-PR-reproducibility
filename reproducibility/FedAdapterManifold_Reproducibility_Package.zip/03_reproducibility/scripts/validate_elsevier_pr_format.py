#!/usr/bin/env python3
"""Validate the most important Pattern Recognition resubmission format constraints.

This is a pragmatic pre-submission audit. It checks the source directives that
Elsevier requested and inspects the generated PDF for page count, page size, and
embedded font names.
"""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

from pypdf import PdfReader


LETTER_W = 612.0
LETTER_H = 792.0


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--tex", default="paper_resubmit/fedadaptermanifold_pr_resubmit.tex")
    p.add_argument("--pdf", default="paper_resubmit/fedadaptermanifold_pr_resubmit.pdf")
    p.add_argument("--bbl", default="paper_resubmit/fedadaptermanifold_pr_resubmit.bbl")
    p.add_argument("--out", default="paper_resubmit/format_validation_report.md")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    tex = Path(args.tex)
    pdf = Path(args.pdf)
    bbl = Path(args.bbl)
    errors: list[str] = []
    warnings: list[str] = []

    src = tex.read_text(encoding="utf-8", errors="replace")
    require(src.startswith(r"\documentclass[times, review, 10pt]{elsarticle}"), "Documentclass must be exactly the PR-requested elsarticle review class.", errors)
    require("letterpaper,top=4.3cm,right=4.8cm,bottom=4.3cm,left=4.8cm" in src.replace(" ", ""), "Letter paper and PR margins must be present in geometry package.", errors)
    require(r"\fontsize{14}{16}\selectfont" in src, "Title should be explicitly set near 14 pt.", errors)
    require(r"\usepackage[font=footnotesize,labelfont=bf]{caption}" in src, "Captions should use footnote-size formatting.", errors)
    require(r"\pagestyle{plain}" in src and r"\pagestyle{empty}" not in src, "Review manuscript must use visible consecutive page numbers.", errors)
    require("postcode={DH13LE}" in src.replace(" ", ""), "Affiliation should include the full postal postcode.", errors)

    title = _extract_title(src)
    title_words = len(re.findall(r"[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*", title))
    require(10 <= title_words <= 15, f"Title should contain 10--15 words; found {title_words}.", errors)

    abstract = _extract_environment(src, "abstract")
    abstract_words = len(re.findall(r"\b[A-Za-z0-9]+(?:[-/][A-Za-z0-9]+)*\b", _strip_tex(abstract)))
    require(abstract_words <= 250, f"Abstract should contain no more than 250 words; found {abstract_words}.", errors)

    keywords = [item.strip().rstrip(".") for item in _extract_environment(src, "keyword").split(";") if item.strip()]
    require(1 <= len(keywords) <= 6, f"Elsevier indexing guidance allows at most 6 keywords; found {len(keywords)}.", errors)

    reader = PdfReader(str(pdf))
    n_pages = len(reader.pages)
    require(20 <= n_pages <= 35, f"Main manuscript has {n_pages} pages; PR regular papers should contain 20--35 pages.", errors)

    page_sizes = []
    for idx, page in enumerate(reader.pages, start=1):
        box = page.mediabox
        w = float(box.width)
        h = float(box.height)
        page_sizes.append((w, h))
        if abs(w - LETTER_W) > 1.0 or abs(h - LETTER_H) > 1.0:
            errors.append(f"Page {idx} size is {w:.1f} x {h:.1f} pt, not Letter 612 x 792 pt.")
        text = page.extract_text() or ""
        if not any(line.strip() == str(idx) for line in text.splitlines()):
            errors.append(f"Page {idx} does not expose its consecutive page number in extracted text.")

    fonts = sorted(_extract_font_names(reader))
    bad_fonts = [f for f in fonts if any(s in f.lower() for s in ("cmr", "lmroman", "lmodern"))]
    if bad_fonts:
        errors.append("Computer Modern / Latin Modern body fonts detected: " + ", ".join(bad_fonts[:10]))
    if not any("Times" in f or "NimbusRomNo9L" in f or "TeXGyreTermes" in f for f in fonts):
        warnings.append("Could not confirm a Times-compatible font from PDF resources.")

    bib_count = _count_bib_items(bbl)
    require(35 <= bib_count <= 55, f"Rendered bibliography count should be in [35,55], found {bib_count}.", errors)

    report = [
        "# Elsevier Pattern Recognition Format Validation",
        "",
        f"- Main PDF: `{pdf}`",
        f"- Page count: {n_pages}",
        f"- Page size sample: {page_sizes[0][0]:.1f} x {page_sizes[0][1]:.1f} pt" if page_sizes else "- Page size sample: unavailable",
        f"- Consecutive page numbers: checked on {n_pages}/{n_pages} pages",
        f"- Title word count: {title_words}",
        f"- Abstract word count: {abstract_words}",
        f"- Keyword count: {len(keywords)}",
        f"- Bibliography count: {bib_count}",
        f"- Embedded fonts: {', '.join(fonts) if fonts else 'unavailable'}",
        "",
        "## Errors",
    ]
    report.extend([f"- {e}" for e in errors] if errors else ["- None"])
    report.extend(["", "## Warnings"])
    report.extend([f"- {w}" for w in warnings] if warnings else ["- None"])
    report.append("")
    Path(args.out).write_text("\n".join(report), encoding="utf-8")
    print(Path(args.out))
    if errors:
        for e in errors:
            print(f"ERROR: {e}", file=sys.stderr)
        return 1
    return 0


def require(condition: bool, message: str, errors: list[str]) -> None:
    if not condition:
        errors.append(message)


def _extract_title(src: str) -> str:
    match = re.search(r"\\title\{\\fontsize\{14\}\{16\}\\selectfont\s+([^}]+)\}", src)
    return match.group(1).strip() if match else ""


def _extract_environment(src: str, name: str) -> str:
    match = re.search(rf"\\begin\{{{name}\}}(.*?)\\end\{{{name}\}}", src, flags=re.DOTALL)
    return match.group(1).strip() if match else ""


def _strip_tex(value: str) -> str:
    value = re.sub(r"\\(?:emph|textbf|textit|mathrm)\{([^{}]*)\}", r"\1", value)
    value = re.sub(r"\\[A-Za-z]+\{?", " ", value)
    value = re.sub(r"[$\\{}_^%]", " ", value)
    return value


def _count_bib_items(path: Path) -> int:
    if not path.exists():
        return 0
    return len(re.findall(r"\\bibitem", path.read_text(encoding="utf-8", errors="replace")))


def _extract_font_names(reader: PdfReader) -> set[str]:
    fonts: set[str] = set()
    for page in reader.pages:
        resources = page.get("/Resources") or {}
        font_dict = resources.get("/Font") or {}
        for font_obj in font_dict.values():
            try:
                font = font_obj.get_object()
                base = font.get("/BaseFont")
                if base:
                    fonts.add(str(base).lstrip("/"))
            except Exception:
                continue
    return fonts


if __name__ == "__main__":
    raise SystemExit(main())
