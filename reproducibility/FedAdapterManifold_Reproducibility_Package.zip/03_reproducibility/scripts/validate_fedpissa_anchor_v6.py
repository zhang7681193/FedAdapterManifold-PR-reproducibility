from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path


WORKSPACE = Path(__file__).resolve().parents[1]
DEFAULT_ROOT = WORKSPACE / "results/fam_fedpissa_anchor_admission_v6_seed5to9_20260813"
STAGING = WORKSPACE / "staging_fedpissa_anchor_admission_v6_20260813"
RUN_LABELS = ("pacs_resnet18", "domainnetmini_clip_60class")
ANCHOR = "FedPissa-EquationPort"
DEPLOYED = "FedAdapterManifold-FedPissaAnchorAdmit"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate the frozen FedPissa-anchor v6 confirmation.")
    parser.add_argument("--result-root", type=Path, default=DEFAULT_ROOT)
    return parser.parse_args()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    digest.update(path.read_bytes())
    return digest.hexdigest()


def manifest_package_hash(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted((root / "fedadaptermanifold").rglob("*.py")):
        digest.update(path.relative_to(root).as_posix().encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def provenance_package_hash(root: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*.py")):
        relative = path.relative_to(root).as_posix().encode("utf-8")
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        digest.update(bytes.fromhex(sha256_file(path)))
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["scope", "check", "passed", "detail"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def truth(value) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def main() -> int:
    args = parse_args()
    root = args.result_root.resolve()
    manifest = json.loads((root / "preregistered_protocol.json").read_text(encoding="utf-8"))
    amendment_path = root / "analysis_amendment.json"
    amendment = (
        json.loads(amendment_path.read_text(encoding="utf-8"))
        if amendment_path.exists()
        else None
    )
    rows: list[dict] = []

    def check(scope: str, name: str, passed: bool, detail: str) -> None:
        rows.append({"scope": scope, "check": name, "passed": bool(passed), "detail": detail})

    manifest_hash = manifest_package_hash(STAGING)
    runtime_hash = provenance_package_hash(STAGING / "fedadaptermanifold")
    check(
        "source",
        "manifest_package_hash",
        manifest_hash == manifest["source_package_sha256"],
        f"expected={manifest['source_package_sha256']} observed={manifest_hash}",
    )
    for name, expected in manifest["source_files"].items():
        path = STAGING / name if name.endswith(".py") and "/" not in name else None
        if name in {"run_experiment.py", "signed_admissibility.py"}:
            path = STAGING / "fedadaptermanifold" / name
        elif name in {"run_confirmation.py", "analyze_confirmation.py"}:
            path = STAGING / name
        observed = sha256_file(path) if path is not None and path.exists() else "missing"
        post_analysis_amendment = bool(
            name == "analyze_confirmation.py"
            and amendment is not None
            and amendment.get("scope") == "post-hoc analysis code only"
            and amendment.get("original_preregistered_sha256") == expected
            and amendment.get("amended_sha256") == observed
            and amendment.get("experiment_outputs_changed") is False
            and amendment.get("candidate_pool_changed") is False
            and amendment.get("selection_rule_changed") is False
            and amendment.get("statistical_threshold_changed") is False
        )
        check(
            "source",
            f"file_hash:{name}",
            observed == expected or post_analysis_amendment,
            f"expected={expected} observed={observed} declared_post_analysis_amendment={post_analysis_amendment}",
        )

    total_units = 0
    for run_label in RUN_LABELS:
        for seed in range(5, 10):
            scope = f"{run_label}/seed_{seed}"
            seed_dir = root / run_label / f"seed_{seed}"
            required = [
                seed_dir / "metrics.csv",
                seed_dir / "per_client_metrics.csv",
                seed_dir / "semantic_admission_exact_certificate.csv",
                seed_dir / "run_provenance.json",
            ]
            check(scope, "required_files", all(path.exists() for path in required), ",".join(path.name for path in required))
            if not all(path.exists() for path in required):
                continue
            provenance = json.loads((seed_dir / "run_provenance.json").read_text(encoding="utf-8"))
            check(
                scope,
                "runtime_package_hash",
                provenance["package_source_sha256"] == runtime_hash,
                f"expected={runtime_hash} observed={provenance['package_source_sha256']}",
            )
            config = root / "configs" / run_label / f"seed_{seed}.yaml"
            check(scope, "config_hash", sha256_file(config) == provenance["source_config_sha256"], str(config))
            certificate = read_csv(seed_dir / "semantic_admission_exact_certificate.csv")
            per_client = read_csv(seed_dir / "per_client_metrics.csv")
            anchor_clients = {row["client_id"] for row in per_client if row["method"] == ANCHOR}
            deployed_clients = {row["client_id"] for row in per_client if row["method"] == DEPLOYED}
            candidate_rows = [row for row in certificate if row["candidate_method"] != ANCHOR]
            candidate_clients = {row["client_id"] for row in candidate_rows}
            check(
                scope,
                "aligned_receiver_units",
                bool(anchor_clients) and anchor_clients == deployed_clients == candidate_clients,
                f"anchor={len(anchor_clients)} deploy={len(deployed_clients)} candidate={len(candidate_clients)}",
            )
            total_units += len(candidate_clients)
            for row in candidate_rows:
                unit = f"{scope}/{row['client_id']}"
                selected = truth(row["selected"])
                certified = truth(row["fam_vs_anchor_certified"])
                check(unit, "test_free_selection", not truth(row["test_used_for_selection"]), "test_used_for_selection")
                check(unit, "training_fixed_candidate", truth(row["candidate_training_fixed"]), "candidate_training_fixed")
                check(unit, "single_edge_alpha", abs(float(row["per_edge_alpha"]) - 0.05) <= 1e-12, row["per_edge_alpha"])
                check(unit, "no_uncertified_admission", (not selected) or certified, f"selected={selected} certified={certified}")
                check(
                    unit,
                    "anchor_fallback_identity",
                    selected or (row["selected_method"] == ANCHOR and truth(row["fell_back_to_external_anchor"])),
                    f"selected_method={row['selected_method']}",
                )

    summary_path = root / "analysis/external_anchor_summary.csv"
    units_path = root / "analysis/external_anchor_units.csv"
    check("analysis", "summary_rows", summary_path.exists() and len(read_csv(summary_path)) == 2, str(summary_path))
    check("analysis", "unit_rows", units_path.exists() and len(read_csv(units_path)) == 50, str(units_path))
    check("analysis", "receiver_unit_total", total_units == 50, f"observed={total_units}")

    validation = root / "final_validation"
    write_csv(validation / "validation_checks.csv", rows)
    failures = [row for row in rows if not row["passed"]]
    report = [
        "# FedPissa-anchor v6 validation",
        "",
        f"- Checks: {len(rows)}",
        f"- Passed: {len(rows) - len(failures)}",
        f"- Failed: {len(failures)}",
        f"- Receiver units: {total_units}",
        "",
    ]
    if failures:
        report.extend(["## Failures", ""] + [f"- {row['scope']} / {row['check']}: {row['detail']}" for row in failures])
    else:
        report.append("All frozen protocol, provenance, selection, and unit-coverage checks pass.")
    (validation / "validation_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
