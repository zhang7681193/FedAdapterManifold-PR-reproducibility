from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.config import load_yaml


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate final current-code evidence roots.")
    parser.add_argument("--result-root", action="append", required=True)
    parser.add_argument("--expected-seeds", default="0,1,2,3,4")
    parser.add_argument("--require-heldout-calibration", action="store_true")
    parser.add_argument("--output-dir", default="results/final_currentcode_evidence_validation")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    expected_seeds = {int(value) for value in args.expected_seeds.split(",") if value.strip()}
    checks: list[dict] = []
    all_hashes: set[str] = set()
    for raw_root in args.result_root:
        root = Path(raw_root)
        seed_dirs = sorted(root.glob("*/seed_*"))
        if not seed_dirs:
            seed_dirs = sorted(root.glob("seed_*"))
        datasets: dict[str, list[Path]] = {}
        for seed_dir in seed_dirs:
            dataset = seed_dir.parent.name if seed_dir.parent != root else root.name
            datasets.setdefault(dataset, []).append(seed_dir)
        _record(checks, str(root), "root_has_seed_directories", bool(seed_dirs), len(seed_dirs))
        for dataset, current_dirs in sorted(datasets.items()):
            found_seeds = {_seed_from_dir(path) for path in current_dirs}
            _record(
                checks,
                f"{root}:{dataset}",
                "expected_seed_set",
                found_seeds == expected_seeds,
                f"found={sorted(found_seeds)} expected={sorted(expected_seeds)}",
            )
            dataset_hashes: set[str] = set()
            for seed_dir in current_dirs:
                seed = _seed_from_dir(seed_dir)
                scope = f"{root}:{dataset}:seed_{seed}"
                required = [
                    seed_dir / "config.yaml",
                    seed_dir / "metrics.csv",
                    seed_dir / "per_client_metrics.csv",
                    seed_dir / "run_provenance.json",
                ]
                for path in required:
                    _record(checks, scope, f"exists:{path.name}", path.is_file(), str(path))
                if not all(path.is_file() for path in required):
                    continue
                config = load_yaml(seed_dir / "config.yaml")
                provenance = json.loads(
                    (seed_dir / "run_provenance.json").read_text(encoding="utf-8")
                )
                code_hash = str(provenance.get("package_source_sha256", ""))
                _record(checks, scope, "source_hash_present", len(code_hash) == 64, code_hash)
                if code_hash:
                    dataset_hashes.add(code_hash)
                    all_hashes.add(code_hash)
                _record(
                    checks,
                    scope,
                    "config_seed_matches_directory",
                    int(config.get("seed", -1)) == seed,
                    config.get("seed"),
                )
                if args.require_heldout_calibration:
                    fraction = float(config.get("candidate_selector_calibration_fraction", 0.0))
                    _record(checks, scope, "heldout_calibration", fraction > 0.0, fraction)
                _validate_metric_files(seed_dir, seed, scope, checks)
                admission = seed_dir / "signed_tangent_admission.csv"
                if admission.is_file():
                    rows = _read_csv(admission)
                    test_free = all(
                        not _as_bool(row.get("test_used_for_selection", False)) for row in rows
                    )
                    _record(checks, scope, "signed_selection_test_free", test_free, len(rows))
            _record(
                checks,
                f"{root}:{dataset}",
                "one_source_hash_within_dataset",
                len(dataset_hashes) == 1,
                sorted(dataset_hashes),
            )
    _record(
        checks,
        "all_roots",
        "one_source_hash_across_final_evidence",
        len(all_hashes) == 1,
        sorted(all_hashes),
    )
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    _write_csv(output / "evidence_validation_checks.csv", checks)
    failed = [row for row in checks if not bool(row["passed"])]
    lines = [
        "# Final Current-Code Evidence Validation",
        "",
        f"Checks: {len(checks)}; passed: {len(checks) - len(failed)}; failed: {len(failed)}.",
        "",
    ]
    if failed:
        lines.extend(["## Blocking Failures", ""])
        lines.extend(
            f"- `{row['scope']}` / `{row['check']}`: {row['detail']}" for row in failed
        )
    else:
        lines.append("All evidence-integrity checks passed.")
    (output / "evidence_validation_report.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    print(lines[2])
    return 1 if failed else 0


def _validate_metric_files(seed_dir: Path, seed: int, scope: str, checks: list[dict]) -> None:
    metrics = _read_csv(seed_dir / "metrics.csv")
    clients = _read_csv(seed_dir / "per_client_metrics.csv")
    metric_methods = [str(row.get("method", "")) for row in metrics]
    _record(
        checks,
        scope,
        "unique_metric_method_rows",
        len(metric_methods) == len(set(metric_methods)),
        len(metric_methods),
    )
    client_keys = [(str(row.get("method", "")), str(row.get("client_id", ""))) for row in clients]
    _record(
        checks,
        scope,
        "unique_method_client_rows",
        len(client_keys) == len(set(client_keys)),
        len(client_keys),
    )
    finite_and_bounded = True
    seed_consistent = True
    for row in metrics + clients:
        if str(row.get("seed", seed)) not in {str(seed), f"{float(seed):.1f}"}:
            seed_consistent = False
        for field in ("accuracy", "mean_accuracy", "test_accuracy"):
            if row.get(field, "") != "":
                value = float(row[field])
                finite_and_bounded &= bool(np.isfinite(value) and 0.0 <= value <= 1.0)
        for field in ("loss", "mean_loss", "test_loss"):
            if row.get(field, "") != "":
                finite_and_bounded &= bool(np.isfinite(float(row[field])))
    _record(checks, scope, "metric_seed_consistency", seed_consistent, seed)
    _record(checks, scope, "finite_bounded_metrics", finite_and_bounded, "accuracy in [0,1]")

    by_method: dict[str, list[dict]] = {}
    for row in clients:
        by_method.setdefault(str(row["method"]), []).append(row)
    mismatches: list[str] = []
    for row in metrics:
        method = str(row["method"])
        current = by_method.get(method, [])
        if not current:
            mismatches.append(f"{method}:missing per-client rows")
            continue
        accuracy = np.asarray([float(item["accuracy"]) for item in current], dtype=np.float64)
        loss = np.asarray([float(item["loss"]) for item in current], dtype=np.float64)
        if not np.isclose(float(row["mean_accuracy"]), float(accuracy.mean()), atol=1e-12):
            mismatches.append(f"{method}:mean_accuracy")
        if not np.isclose(float(row["mean_loss"]), float(loss.mean()), atol=1e-12):
            mismatches.append(f"{method}:mean_loss")
        if int(float(row["num_clients"])) != len(current):
            mismatches.append(f"{method}:num_clients")
    _record(checks, scope, "aggregate_recomputes_from_clients", not mismatches, mismatches)


def _seed_from_dir(path: Path) -> int:
    return int(path.name.split("_")[-1])


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _as_bool(value) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def _record(checks: list[dict], scope: str, check: str, passed: bool, detail) -> None:
    checks.append({"scope": scope, "check": check, "passed": bool(passed), "detail": detail})


def _write_csv(path: Path, rows: list[dict]) -> None:
    fields = ["scope", "check", "passed", "detail"]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())

