from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
import yaml


REQUIRED_METHODS = {
    "Local-LoRA",
    "FedAvg-LoRA",
    "FedGeo-Agg",
    "FedAdapterManifold-Admit",
    "FedAdapterManifold-TemporalSemanticAdmit",
    "FedSmoothLoRA",
    "Subspace-Reg-LoRA-Visual-Port",
    "Dysco-FrozenFeature-Visual-Port",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate the final exact risk-closure evidence root.")
    parser.add_argument("--result-root", required=True)
    parser.add_argument(
        "--datasets",
        default="pacs_resnet18,officehome_clip_full,domainnetmini_clip_60class",
    )
    parser.add_argument("--allow-partial", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.result_root)
    datasets = [value.strip() for value in args.datasets.split(",") if value.strip()]
    checks: list[dict] = []
    for dataset in datasets:
        hashes = set()
        complete_seeds = []
        for seed in range(5):
            run = root / dataset / f"seed_{seed}"
            if not (run / "metrics.csv").is_file():
                _add(checks, dataset, seed, "run_complete", False, str(run), "metrics.csv present")
                continue
            complete_seeds.append(seed)
            _validate_run(checks, dataset, seed, run, hashes)
        expected = set(range(5))
        seed_ok = set(complete_seeds) == expected if not args.allow_partial else bool(complete_seeds)
        _add(checks, dataset, "all", "seed_coverage", seed_ok, complete_seeds, sorted(expected))
        hash_ok = len(hashes) == 1 if complete_seeds else False
        _add(checks, dataset, "all", "one_package_source_hash", hash_ok, sorted(hashes), "one nonempty hash")

    output = root / "final_validation"
    output.mkdir(parents=True, exist_ok=True)
    _write_csv(output / "validation_checks.csv", checks)
    failures = [row for row in checks if not row["passed"]]
    report = [
        "# Final Risk-Closure Validation",
        "",
        f"- Checks: {len(checks)}",
        f"- Passed: {len(checks) - len(failures)}",
        f"- Failed: {len(failures)}",
        "",
    ]
    if failures:
        report.extend(["## Failures", ""])
        for row in failures:
            report.append(
                f"- `{row['dataset']}` seed `{row['seed']}` `{row['check']}`: "
                f"observed `{row['observed']}`, expected `{row['expected']}`"
            )
    else:
        report.append("All evidence-contract checks pass.")
    (output / "validation_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    return 1 if failures else 0


def _validate_run(checks, dataset, seed, run, hashes):
    required_files = [
        "config.yaml",
        "metrics.csv",
        "per_client_metrics.csv",
        "run_provenance.json",
        "semantic_admission_exact_certificate.csv",
        "signed_tangent_admission.csv",
        "signed_tangent_screen.csv",
        "subspace_reg_lora_history.csv",
        "dysco_visual_port_history.csv",
        "fedsmooth_lora_history.csv",
    ]
    for filename in required_files:
        _add(checks, dataset, seed, f"file:{filename}", (run / filename).is_file(), filename, "present")
    if any(not (run / filename).is_file() for filename in required_files):
        return

    config = yaml.safe_load((run / "config.yaml").read_text(encoding="utf-8"))
    expected_config = {
        "seed": seed,
        "rank_policy": "fixed",
        "candidate_selector_calibration_fraction": 0.2,
        "candidate_selector_calibration_strategy": "stratified",
        "adapter_graph_mix_policy": "fixed",
        "run_multiround_semantic_admission": True,
        "semantic_admission_exact_certificate": True,
        "run_signed_tangent_admission": True,
        "signed_tangent_exact_certificate": True,
        "signed_tangent_sources": "fedsmooth",
        "run_recent_lora_baselines": True,
        "recent_lora_methods": "fedsmooth,subspace_reg,dysco",
    }
    for key, expected in expected_config.items():
        observed = config.get(key)
        equal = bool(np.isclose(float(observed), float(expected))) if isinstance(expected, float) else observed == expected
        _add(checks, dataset, seed, f"config:{key}", equal, observed, expected)

    provenance = json.loads((run / "run_provenance.json").read_text(encoding="utf-8"))
    source_hash = str(provenance.get("package_source_sha256", ""))
    if source_hash:
        hashes.add(source_hash)
    _add(checks, dataset, seed, "package_hash_present", bool(source_hash), source_hash, "nonempty")
    geometry_hash = str(provenance.get("geometry_inputs_sha256", ""))
    _add(checks, dataset, seed, "geometry_hash_present", bool(geometry_hash), geometry_hash, "nonempty")

    metrics = _read_csv(run / "metrics.csv")
    per_client = _read_csv(run / "per_client_metrics.csv")
    methods = {str(row["method"]) for row in metrics}
    _add(
        checks,
        dataset,
        seed,
        "required_methods",
        REQUIRED_METHODS.issubset(methods),
        sorted(methods & REQUIRED_METHODS),
        sorted(REQUIRED_METHODS),
    )
    keys = [(row.get("method", ""), row.get("client_id", "")) for row in per_client]
    _add(checks, dataset, seed, "unique_method_client_rows", len(keys) == len(set(keys)), len(keys), len(set(keys)))
    for row in metrics:
        current = [item for item in per_client if item.get("method") == row.get("method")]
        if not current:
            continue
        values = [_metric_value(item, "accuracy", "test_accuracy") for item in current]
        recomputed = float(np.mean(values))
        reported = float(row["mean_accuracy"])
        _add(
            checks,
            dataset,
            seed,
            f"metric_recompute:{row['method']}",
            abs(recomputed - reported) <= 1e-12,
            recomputed,
            reported,
        )

    for filename in ["semantic_admission_exact_certificate.csv", "signed_tangent_admission.csv"]:
        _validate_certificate(checks, dataset, seed, filename, _read_csv(run / filename))

    history = _read_csv(run / "subspace_reg_lora_history.csv")
    expected_history = int(config["rounds"]) * int(config.get("effective_num_clients", config["num_clients"]))
    _add(checks, dataset, seed, "subspace_reg_history_size", len(history) == expected_history, len(history), expected_history)
    orthogonal = [_metric_value(row, "server_b_orthogonality_error") for row in history]
    projection = [_metric_value(row, "server_projection_error") for row in history]
    _add(
        checks,
        dataset,
        seed,
        "subspace_reg_orthogonal_b",
        bool(orthogonal and np.isfinite(orthogonal).all() and max(orthogonal) <= 1e-8),
        max(orthogonal) if orthogonal else "missing",
        "<=1e-8",
    )
    _add(
        checks,
        dataset,
        seed,
        "subspace_reg_projection_finite",
        bool(projection and np.isfinite(projection).all()),
        max(projection) if projection else "missing",
        "finite",
    )

    dysco = _read_csv(run / "dysco_visual_port_history.csv")
    _add(checks, dataset, seed, "dysco_history_size", len(dysco) == expected_history, len(dysco), expected_history)
    dysco_orthogonal = [_metric_value(row, "merged_basis_orthogonality_error") for row in dysco]
    _add(
        checks,
        dataset,
        seed,
        "dysco_merged_basis_orthogonal",
        bool(dysco_orthogonal and np.isfinite(dysco_orthogonal).all() and max(dysco_orthogonal) <= 1e-8),
        max(dysco_orthogonal) if dysco_orthogonal else "missing",
        "<=1e-8",
    )
    expected_deployment_rank = int(config["rounds"]) * int(config["rank"])
    observed_deployment_ranks = {
        int(float(row["logical_deployment_rank"])) for row in dysco
        if str(row.get("logical_deployment_rank", "")).strip()
        and int(float(row["round"])) == int(config["rounds"])
    }
    _add(
        checks,
        dataset,
        seed,
        "dysco_logical_deployment_rank",
        observed_deployment_ranks == {expected_deployment_rank},
        sorted(observed_deployment_ranks),
        [expected_deployment_rank],
    )


def _validate_certificate(checks, dataset, seed, filename, rows):
    expected_fam_name = (
        "FAM-SemanticEndpoint"
        if filename == "semantic_admission_exact_certificate.csv"
        else "FAM-ReceiverTangent"
    )
    by_client = _group(rows, "client_id")
    harmful = 0
    uncertified = 0
    malformed = 0
    for client_rows in by_client.values():
        selected = [row for row in client_rows if _as_bool(row.get("selected", False))]
        local = [row for row in client_rows if row.get("candidate_method") == "Local-LoRA"]
        if len(selected) != 1 or len(local) != 1:
            malformed += 1
            continue
        selected = selected[0]
        local = local[0]
        name = selected["candidate_method"]
        certified = bool(
            name == "Local-LoRA"
            or (name == "Geo-only-Agg" and _as_bool(selected.get("geo_deployable", False)))
            or (name == expected_fam_name and _as_bool(selected.get("fam_deployable", False)))
        )
        uncertified += int(not certified)
        selected_acc = float(selected["test_accuracy_post_selection_audit"])
        local_acc = float(local["test_accuracy_post_selection_audit"])
        harmful += int(name != "Local-LoRA" and selected_acc < local_acc - 1e-12)
        if _as_bool(selected.get("test_used_for_selection", False)):
            malformed += 1
        if not _as_bool(selected.get("candidate_training_fixed", False)):
            malformed += 1
    _add(checks, dataset, seed, f"{filename}:well_formed", malformed == 0, malformed, 0)
    _add(checks, dataset, seed, f"{filename}:uncertified", uncertified == 0, uncertified, 0)
    _add(checks, dataset, seed, f"{filename}:harmful", harmful == 0, harmful, 0)


def _metric_value(row, *names):
    for name in names:
        value = row.get(name, "")
        if str(value).strip() != "":
            return float(value)
    raise KeyError(names)


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def _group(rows, field):
    grouped = {}
    for row in rows:
        grouped.setdefault(row[field], []).append(row)
    return grouped


def _as_bool(value):
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes"}


def _add(rows, dataset, seed, check, passed, observed, expected):
    rows.append(
        {
            "dataset": dataset,
            "seed": seed,
            "check": check,
            "passed": bool(passed),
            "observed": str(observed),
            "expected": str(expected),
        }
    )


def _write_csv(path: Path, rows: list[dict]) -> None:
    fields = list(rows[0]) if rows else []
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
