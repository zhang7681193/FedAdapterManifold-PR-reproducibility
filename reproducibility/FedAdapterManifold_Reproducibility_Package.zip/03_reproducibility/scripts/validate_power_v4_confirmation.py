from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path


DATASETS = {
    "officehome_clip_full": 4,
    "domainnetmini_clip_60class": 6,
}
SEEDS = range(5)
EXPECTED_PACKAGE_HASH = "917bae8aa1088a6c47ba496685be0c7c4814767fc3efb3fc6fe34979cf630656"
REQUIRED_FILES = (
    "config.yaml",
    "metrics.csv",
    "per_client_metrics.csv",
    "run_provenance.json",
    "semantic_admission_exact_certificate.csv",
    "semantic_generator_training_screen.csv",
    "semantic_admission_weights.csv",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate the frozen generator-admission power-v4 confirmation.")
    parser.add_argument("--result-root", required=True, type=Path)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def as_bool(value: object) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    args = parse_args()
    root = args.result_root.resolve()
    checks: list[dict[str, object]] = []

    def check(dataset: str, seed: object, name: str, passed: bool, observed: object, expected: object) -> None:
        checks.append(
            {
                "dataset": dataset,
                "seed": seed,
                "check": name,
                "passed": bool(passed),
                "observed": observed,
                "expected": expected,
            }
        )

    expected_aggregate_rows = {name: 0 for name in ("metrics.csv", "per_client_metrics.csv", "semantic_admission_exact_certificate.csv")}
    selected_units: list[dict[str, object]] = []
    package_hashes: set[str] = set()

    for dataset, client_count in DATASETS.items():
        for seed in SEEDS:
            run_dir = root / dataset / f"seed_{seed}"
            check(dataset, seed, "run_directory", run_dir.is_dir(), run_dir, "present")
            for filename in REQUIRED_FILES:
                path = run_dir / filename
                check(dataset, seed, f"file:{filename}", path.is_file(), filename if path.is_file() else "missing", "present")
            if not all((run_dir / name).is_file() for name in REQUIRED_FILES):
                continue

            provenance = json.loads((run_dir / "run_provenance.json").read_text(encoding="utf-8"))
            package_hash = str(provenance.get("package_source_sha256", ""))
            package_hashes.add(package_hash)
            check(dataset, seed, "package_source_hash", package_hash == EXPECTED_PACKAGE_HASH, package_hash, EXPECTED_PACKAGE_HASH)
            source_config = Path(str(provenance.get("source_config_path", "")))
            source_hash = str(provenance.get("source_config_sha256", ""))
            check(dataset, seed, "source_config_exists", source_config.is_file(), source_config, "present")
            if source_config.is_file():
                check(dataset, seed, "source_config_hash", sha256(source_config) == source_hash, sha256(source_config), source_hash)
            check(dataset, seed, "geometry_hash_nonempty", bool(provenance.get("geometry_inputs_sha256")), provenance.get("geometry_inputs_sha256", ""), "nonempty")

            certificates = read_csv(run_dir / "semantic_admission_exact_certificate.csv")
            screens = read_csv(run_dir / "semantic_generator_training_screen.csv")
            clients = sorted({row["client_id"] for row in certificates})
            check(dataset, seed, "receiver_count", len(clients) == client_count, len(clients), client_count)

            for client_id in clients:
                cert_rows = [row for row in certificates if row["client_id"] == client_id]
                selected = [row for row in cert_rows if as_bool(row.get("selected", False))]
                methods = {row["candidate_method"] for row in cert_rows}
                check(dataset, seed, f"{client_id}:three_endpoints", len(cert_rows) == 3 and len(methods) == 3, sorted(methods), "three distinct endpoints")
                check(dataset, seed, f"{client_id}:one_selected", len(selected) == 1, len(selected), 1)
                check(dataset, seed, f"{client_id}:candidate_fixed", all(as_bool(row.get("candidate_training_fixed", False)) for row in cert_rows), "all fixed", True)
                check(dataset, seed, f"{client_id}:test_free_selection", all(not as_bool(row.get("test_used_for_selection", False)) for row in cert_rows), "test unused", True)
                if len(selected) == 1:
                    row = selected[0]
                    name = row["candidate_method"]
                    certified = bool(
                        name == "Local-LoRA"
                        or (name == "Geo-only-Agg" and as_bool(row.get("geo_deployable", False)))
                        or (name not in {"Local-LoRA", "Geo-only-Agg"} and as_bool(row.get("fam_deployable", False)))
                    )
                    check(dataset, seed, f"{client_id}:selected_certified", certified, name, "certified or immutable Local")
                    selected_units.append(
                        {
                            "dataset": dataset,
                            "seed": seed,
                            "client_id": client_id,
                            "selected_method": name,
                            "fell_back_to_local": as_bool(row.get("fell_back_to_local", False)),
                        }
                    )

                screen_rows = [row for row in screens if row["client_id"] == client_id]
                screen_selected = [row for row in screen_rows if as_bool(row.get("selected", False))]
                check(dataset, seed, f"{client_id}:two_generators", len(screen_rows) == 2, len(screen_rows), 2)
                check(dataset, seed, f"{client_id}:one_generator_selected", len(screen_selected) == 1, len(screen_selected), 1)
                check(dataset, seed, f"{client_id}:training_only_screen", all(row.get("selection_split") == "adapter_training" and not as_bool(row.get("calibration_used", False)) and not as_bool(row.get("test_used", False)) for row in screen_rows), "adapter_training only", True)

            expected_aggregate_rows["metrics.csv"] += len(read_csv(run_dir / "metrics.csv"))
            expected_aggregate_rows["per_client_metrics.csv"] += len(read_csv(run_dir / "per_client_metrics.csv"))
            expected_aggregate_rows["semantic_admission_exact_certificate.csv"] += len(certificates)

    check("all", "all", "one_package_source_hash", package_hashes == {EXPECTED_PACKAGE_HASH}, sorted(package_hashes), [EXPECTED_PACKAGE_HASH])
    for filename, expected_rows in expected_aggregate_rows.items():
        aggregate = root / f"all_seed_{filename}"
        observed_rows = len(read_csv(aggregate)) if aggregate.is_file() else -1
        check("all", "all", f"aggregate_rows:{filename}", observed_rows == expected_rows, observed_rows, expected_rows)

    output = root / "final_validation"
    output.mkdir(parents=True, exist_ok=True)
    with (output / "validation_checks.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(checks[0]))
        writer.writeheader()
        writer.writerows(checks)
    with (output / "selected_units.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(selected_units[0]))
        writer.writeheader()
        writer.writerows(selected_units)

    failures = [row for row in checks if not row["passed"]]
    selected_nonlocal = sum(row["selected_method"] != "Local-LoRA" for row in selected_units)
    report = [
        "# Generator-admission power-v4 validation",
        "",
        f"- Checks: {len(checks)}",
        f"- Passed: {len(checks) - len(failures)}",
        f"- Failed: {len(failures)}",
        f"- Frozen receiver--seed units: {len(selected_units)}",
        f"- Certified non-local deployments: {selected_nonlocal}",
        "",
        "## Failures",
        "",
    ]
    report.extend(
        [f"- `{row['dataset']}` seed `{row['seed']}` `{row['check']}`: observed `{row['observed']}`, expected `{row['expected']}`" for row in failures]
        or ["- None."]
    )
    report.extend(
        [
            "",
            "## Interpretation",
            "",
            "This validator checks the frozen power-v4 protocol, whose generator screen is training-only and whose deployment certificate sees exactly three fixed endpoints. It does not reuse the signed-tangent files required by the distinct exact-v3 protocol.",
        ]
    )
    (output / "validation_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit(f"Power-v4 validation failed with {len(failures)} checks")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
