from __future__ import annotations

import hashlib
from datetime import date
from pathlib import Path
import zipfile

from pypdf import PdfReader


ROOT = Path(__file__).resolve().parents[1]
SUBMISSION = ROOT / "submission"
READY = SUBMISSION / "FedAdapterManifold_PR_D_26_08222_resubmission_ready_20260810"
SOURCE = SUBMISSION / "FedAdapterManifold_PR_D_26_08222_latex_source_20260810"
REPRO = SUBMISSION / "FedAdapterManifold_PR_reproducibility_20260810"
REPORT = SUBMISSION / "FedAdapterManifold_PR_D_26_08222_package_validation_20260810.md"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def deliverable_files(root: Path) -> list[Path]:
    excluded_dirs = {"__pycache__", ".pytest_cache"}
    return sorted(
        path
        for path in root.rglob("*")
        if path.is_file()
        and path.name != "SHA256SUMS.txt"
        and path.suffix != ".pyc"
        and not excluded_dirs.intersection(path.relative_to(root).parts)
    )


def write_checksums(root: Path) -> int:
    checksum_path = root / "SHA256SUMS.txt"
    files = deliverable_files(root)
    lines = [f"{sha256(path)}  {path.relative_to(root).as_posix()}" for path in files]
    checksum_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return len(lines)


def verify_checksums(root: Path) -> tuple[int, list[str]]:
    errors: list[str] = []
    checksum_path = root / "SHA256SUMS.txt"
    rows = checksum_path.read_text(encoding="utf-8").splitlines()
    for row in rows:
        expected, relative = row.split("  ", 1)
        path = root / Path(relative)
        if not path.is_file():
            errors.append(f"missing checksum target: {path}")
        elif sha256(path) != expected:
            errors.append(f"checksum mismatch: {path}")
    return len(rows), errors


def create_zip(root: Path) -> Path:
    output = SUBMISSION / f"{root.name}_final.zip"
    if output.exists():
        output.unlink()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in deliverable_files(root) + [root / "SHA256SUMS.txt"]:
            archive.write(path, (Path(root.name) / path.relative_to(root)).as_posix())
    return output


def check_zip(path: Path, root_name: str, required: list[str]) -> list[str]:
    errors: list[str] = []
    with zipfile.ZipFile(path) as archive:
        bad = archive.testzip()
        if bad:
            errors.append(f"corrupt ZIP member: {bad}")
        names = set(archive.namelist())
        for relative in required:
            member = f"{root_name}/{relative}"
            if member not in names:
                errors.append(f"missing ZIP member: {member}")
    return errors


def main() -> int:
    errors: list[str] = []
    checks: list[str] = []

    required = {
        READY: [
            "pdf/Manuscript.pdf",
            "pdf/Supplementary_Material.pdf",
            "pdf/Cover_Letter.pdf",
            "source/fedadaptermanifold_pr_resubmit.tex",
            "source/fedadaptermanifold_pr_resubmit_supplement.tex",
            "source/fedadaptermanifold_upgrade_refs.bib",
            "candidate_pools.yaml",
            "audits/validation_report.md",
            "audits/risk_elimination_matrix.md",
            "upload_items/FedAdapterManifold_Title_Page_with_Author_Details.docx",
            "upload_items/FedAdapterManifold_Highlights.docx",
            "upload_items/Declaration_of_Competing_Interests_No_Conflict.docx",
            "upload_items/fam_pr_main_flow.pdf",
            "upload_items/fam_pr_main_flow.svg",
        ],
        SOURCE: [
            "fedadaptermanifold_pr_resubmit.tex",
            "fedadaptermanifold_pr_resubmit.pdf",
            "fedadaptermanifold_pr_resubmit_supplement.tex",
            "fedadaptermanifold_pr_resubmit_supplement.pdf",
            "fedadaptermanifold_upgrade_refs.bib",
            "PR_D_26_08222_resubmission_cover_letter.tex",
            "PR_D_26_08222_resubmission_cover_letter.pdf",
            "candidate_pools.yaml",
        ],
        REPRO: [
            "fedadaptermanifold/__init__.py",
            "scripts/check_no_test_oracle.py",
            "scripts/analyze_canonical_admission_gate.py",
            "scripts/analyze_calibration_robustness.py",
            "tests/test_canonical_admission_gate.py",
            "tests/test_calibration_robustness.py",
            "tests/test_recent_lora_baselines.py",
            "configs/formal_experiment_plan.yaml",
            "candidate_pools.yaml",
            "fedadaptermanifold_pr_main.pdf",
            "fedadaptermanifold_pr_supplement.pdf",
            "README_PR_REPRODUCIBILITY.md",
            "results/fam_hierarchical_subspace_effect_20260805/hierarchical_effect_report.md",
            "results/fam_canonical_admission_gate_20260810/canonical_admission_report.md",
            "results/fam_canonical_admission_gate_20260810/raw_subspace_confusion.csv",
            "results/fam_canonical_admission_gate_20260810/manifold_proposal_confusion.csv",
            "results/fam_canonical_admission_gate_20260810/gate_ablation_summary.csv",
            "results/fam_canonical_admission_gate_20260810/risk_coverage_curve.csv",
            "results/fam_canonical_admission_gate_20260810/protocol_audit.csv",
            "results/fam_calibration_robustness_20260810/calibration_robustness_report.md",
            "results/fam_calibration_robustness_20260810/calibration_score_perturbation.csv",
            "results/fam_calibration_robustness_20260810/confidence_margin_score_perturbation.csv",
            "results/fam_calibration_robustness_20260810/decision_margin_summary.csv",
            "results/fam_calibration_robustness_20260810/bloodmnist_imbalance_summary.csv",
            "results/fam_calibration_robustness_20260810/symmetric_label_noise_bound.csv",
            "results/domainnetmini_dual_transport_combined_10seed/dual_transport_report.md",
        ],
    }

    for root, paths in required.items():
        if not root.is_dir():
            errors.append(f"missing package root: {root}")
            continue
        for relative in paths:
            path = root / relative
            if not path.exists():
                errors.append(f"missing required item: {path}")
        checks.append(f"{root.name}: {len(deliverable_files(root))} deliverable files")

    source_pairs = [
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.pdf", READY / "pdf/Manuscript.pdf"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.pdf", SOURCE / "fedadaptermanifold_pr_resubmit.pdf"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.pdf", REPRO / "fedadaptermanifold_pr_main.pdf"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.pdf", READY / "pdf/Supplementary_Material.pdf"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.pdf", SOURCE / "fedadaptermanifold_pr_resubmit_supplement.pdf"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.pdf", REPRO / "fedadaptermanifold_pr_supplement.pdf"),
        (ROOT / "paper_resubmit/PR_D_26_08222_resubmission_cover_letter.pdf", READY / "pdf/Cover_Letter.pdf"),
        (ROOT / "paper_resubmit/PR_D_26_08222_resubmission_cover_letter.pdf", SOURCE / "PR_D_26_08222_resubmission_cover_letter.pdf"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.tex", READY / "source/fedadaptermanifold_pr_resubmit.tex"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.tex", SOURCE / "fedadaptermanifold_pr_resubmit.tex"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.tex", REPRO / "fedadaptermanifold_pr_main.tex"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.tex", READY / "source/fedadaptermanifold_pr_resubmit_supplement.tex"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.tex", SOURCE / "fedadaptermanifold_pr_resubmit_supplement.tex"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.tex", REPRO / "fedadaptermanifold_pr_supplement.tex"),
        (ROOT / "paper_resubmit/fedadaptermanifold_upgrade_refs.bib", READY / "source/fedadaptermanifold_upgrade_refs.bib"),
        (ROOT / "paper_resubmit/fedadaptermanifold_upgrade_refs.bib", SOURCE / "fedadaptermanifold_upgrade_refs.bib"),
        (ROOT / "paper_resubmit/fedadaptermanifold_upgrade_refs.bib", REPRO / "fedadaptermanifold_refs.bib"),
        (ROOT / "paper_resubmit/PR_D_26_08222_resubmission_cover_letter.tex", READY / "source/PR_D_26_08222_resubmission_cover_letter.tex"),
        (ROOT / "paper_resubmit/PR_D_26_08222_resubmission_cover_letter.tex", SOURCE / "PR_D_26_08222_resubmission_cover_letter.tex"),
        (ROOT / "paper_resubmit/candidate_pools.yaml", READY / "candidate_pools.yaml"),
        (ROOT / "paper_resubmit/candidate_pools.yaml", SOURCE / "candidate_pools.yaml"),
        (ROOT / "paper_resubmit/candidate_pools.yaml", REPRO / "candidate_pools.yaml"),
    ]
    for canonical, packaged in source_pairs:
        if canonical.is_file() and packaged.is_file() and sha256(canonical) == sha256(packaged):
            checks.append(f"hash match: {packaged.relative_to(ROOT)}")
        else:
            errors.append(f"canonical/package mismatch: {canonical} != {packaged}")

    pdf_pages = {
        ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.pdf": 35,
        ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.pdf": 36,
        ROOT / "paper_resubmit/PR_D_26_08222_resubmission_cover_letter.pdf": 2,
    }
    for path, expected in pdf_pages.items():
        pages = len(PdfReader(path).pages)
        checks.append(f"{path.name}: {pages} pages")
        if pages != expected:
            errors.append(f"unexpected page count: {path} has {pages}, expected {expected}")

    archives: list[Path] = []
    for root in (READY, SOURCE, REPRO):
        count = write_checksums(root)
        _, checksum_errors = verify_checksums(root)
        errors.extend(checksum_errors)
        checks.append(f"{root.name}: {count} checksums verified")
        archive = create_zip(root)
        archives.append(archive)
        errors.extend(check_zip(archive, root.name, required[root] + ["SHA256SUMS.txt"]))
        checks.append(
            f"{archive.name}: ZIP CRC passed, SHA-256 `{sha256(archive)}`, "
            f"{archive.stat().st_size / (1024 * 1024):.2f} MiB"
        )

    lines = [
        "# FedAdapterManifold PR Resubmission Package Validation",
        "",
        f"- Status: {'FAIL' if errors else 'PASS'}",
        f"- Validation date: {date.today().isoformat()}",
        "",
        "## Checks",
        "",
        *(f"- {item}" for item in checks),
        "",
        "## Errors",
        "",
        *(f"- {item}" for item in errors),
    ]
    if not errors:
        lines.append("- None")
    REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(REPORT)
    for archive in archives:
        print(archive)
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
