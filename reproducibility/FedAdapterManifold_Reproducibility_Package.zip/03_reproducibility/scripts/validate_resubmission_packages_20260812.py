from __future__ import annotations

import hashlib
from pathlib import Path
import zipfile

from pypdf import PdfReader


ROOT = Path(__file__).resolve().parents[1]
SUBMISSION = ROOT / "submission"
READY = SUBMISSION / "FAM_PR_resubmit_20260812"
SOURCE = SUBMISSION / "FAM_PR_source_20260812"
REPRO = SUBMISSION / "FAM_PR_repro_20260812"
REPORT = SUBMISSION / "FAM_PR_package_validation_20260812.md"

EXCLUDED_DIRS = {"__pycache__", ".pytest_cache"}
EXCLUDED_PREFIXES = {
    # A long-path Copy-Item attempt created an incomplete duplicate. The complete
    # copy is the shorter `tp_rule` directory and is the only one archived.
    ("evidence", "target_pareto_20260812", "target_pareto_rule_audit"),
    ("results", "target_pareto_20260812", "target_pareto_rule_audit"),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def is_excluded(relative: Path) -> bool:
    if EXCLUDED_DIRS.intersection(relative.parts):
        return True
    if any(part.startswith("_compile_") for part in relative.parts):
        return True
    return any(relative.parts[: len(prefix)] == prefix for prefix in EXCLUDED_PREFIXES)


def deliverable_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.name == "SHA256SUMS.txt" or path.suffix == ".pyc":
            continue
        if is_excluded(path.relative_to(root)):
            continue
        files.append(path)
    return sorted(files)


def write_and_verify_checksums(root: Path) -> tuple[int, list[str]]:
    files = deliverable_files(root)
    rows = [f"{sha256(path)}  {path.relative_to(root).as_posix()}" for path in files]
    checksum_path = root / "SHA256SUMS.txt"
    checksum_path.write_text("\n".join(rows) + "\n", encoding="utf-8")

    errors: list[str] = []
    for row in checksum_path.read_text(encoding="utf-8").splitlines():
        expected, relative = row.split("  ", 1)
        target = root / relative
        if not target.is_file():
            errors.append(f"missing checksum target: {target}")
        elif sha256(target) != expected:
            errors.append(f"checksum mismatch: {target}")
    return len(rows), errors


def create_and_check_zip(root: Path) -> tuple[Path, list[str]]:
    output = SUBMISSION / f"{root.name}.zip"
    if output.exists():
        output.unlink()
    files = deliverable_files(root) + [root / "SHA256SUMS.txt"]
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            archive.write(path, (Path(root.name) / path.relative_to(root)).as_posix())

    errors: list[str] = []
    with zipfile.ZipFile(output) as archive:
        bad_member = archive.testzip()
        if bad_member:
            errors.append(f"corrupt ZIP member: {bad_member}")
    return output, errors


def check_required(root: Path, relatives: list[str]) -> list[str]:
    return [f"missing required item: {root / rel}" for rel in relatives if not (root / rel).is_file()]


def main() -> int:
    errors: list[str] = []
    checks: list[str] = []

    required = {
        READY: [
            "pdf/Manuscript.pdf",
            "pdf/Supplementary_Material.pdf",
            "pdf/Cover_Letter.pdf",
            "source/fedadaptermanifold_pr_resubmit.tex",
            "source/fedadaptermanifold_pr_resubmit_supplement.tex",
            "source/fedadaptermanifold_upgrade_refs.bib",
            "theory/receiver_relative_target_pareto_theory_20260812.md",
            "evidence/target_pareto_20260812/tp_rule/development/pacs_dinov2/summary.md",
            "evidence/target_pareto_20260812/target_pareto_officehome_independent_summary/summary.md",
            "evidence/target_pareto_20260812/target_pareto_officehome_independent_quality/quality_report.md",
            "evidence/exact_update_subspace_confirmation_20260812/confirmation_report.md",
            "evidence/target_constrained_utility_audit/target_constrained_utility_summary.csv",
            "evidence/fedtree_fam_admission_evidence_20260812/summary.csv",
            "evidence/fedtree_fam_admission_evidence_20260812/input_sha256.csv",
            "evidence/officehome_prior_shift_admission_20260812/target_constrained_utility_summary.csv",
            "evidence/core_manuscript_tables_20260812/canonical_safety_utility.csv",
            "evidence/core_manuscript_tables_20260812/end_to_end_clip_admission.csv",
            "evidence/recent_lora_receiver_admission_overlay_20260812/receiver_admission_setting_summary.csv",
            "evidence/recent_lora_canonical_replay_20260812/canonical_replay_setting_summary.csv",
            "audits/core_evidence_validation.md",
            "audits/official_source_audit.md",
            "audits/five_risk_closure.md",
            "audits/five_risk_reassessment_20260812.md",
        ],
        SOURCE: [
            "fedadaptermanifold_pr_resubmit.pdf",
            "fedadaptermanifold_pr_resubmit.tex",
            "fedadaptermanifold_pr_resubmit_supplement.pdf",
            "fedadaptermanifold_pr_resubmit_supplement.tex",
            "fedadaptermanifold_pr_resubmit.bbl",
            "fedadaptermanifold_upgrade_refs.bib",
            "PR_D_26_08222_resubmission_cover_letter.pdf",
            "PR_D_26_08222_resubmission_cover_letter.tex",
        ],
        REPRO: [
            "fedadaptermanifold/adapters.py",
            "fedadaptermanifold/decoupled_transport.py",
            "scripts/run_intrinsic_admit_v2.py",
            "scripts/summarize_split_meta_confirmation.py",
            "scripts/audit_target_pareto_from_candidate_logs.py",
            "scripts/audit_split_meta_evidence_quality.py",
            "scripts/analyze_exact_update_subspace_confirmation.py",
            "scripts/audit_target_constrained_direct_route.py",
            "scripts/audit_official_baseline_sources.py",
            "scripts/build_five_risk_closure_audit.py",
            "scripts/run_fedtree_fam_admission_audit.py",
            "scripts/build_fedtree_fam_evidence.py",
            "scripts/run_direct_anchor_shift_audit.py",
            "scripts/build_core_manuscript_tables.py",
            "scripts/build_recent_lora_receiver_admission_table.py",
            "scripts/analyze_recent_lora_canonical_replay.py",
            "scripts/validate_core_evidence_tables.py",
            "tests/test_decoupled_transport.py",
            "tests/test_training.py",
            "configs/target_pareto_cross_dataset_confirmation_20260812.yaml",
            "configs/split_meta_pareto_independent_confirmation_20260812.yaml",
            "docs/receiver_relative_target_pareto_theory_20260812.md",
            "results/target_pareto_20260812/tp_rule/development/pacs_dinov2/summary.md",
            "results/target_pareto_20260812/target_pareto_officehome_independent_summary/summary.md",
            "results/target_pareto_20260812/target_pareto_officehome_independent_quality/quality_report.md",
            "results/exact_update_subspace_confirmation_20260812/confirmation_report.md",
            "results/target_constrained_utility_audit/target_constrained_utility_summary.csv",
            "results/fedtree_fam_admission_evidence_20260812/summary.csv",
            "results/fedtree_fam_admission_evidence_20260812/input_sha256.csv",
            "results/officehome_prior_shift_admission_20260812/target_constrained_utility_summary.csv",
            "results/core_manuscript_tables_20260812/canonical_safety_utility.csv",
            "results/core_manuscript_tables_20260812/end_to_end_clip_admission.csv",
            "results/recent_lora_receiver_admission_overlay_20260812/receiver_admission_setting_summary.csv",
            "results/recent_lora_canonical_replay_20260812/canonical_replay_setting_summary.csv",
            "results/baseline_official_code_audit_20260812/official_source_audit.md",
            "results/five_risk_closure_audit_20260812/five_risk_closure.md",
            "reports/five_risk_reassessment_20260812.md",
            "fedadaptermanifold_pr_main.pdf",
            "fedadaptermanifold_pr_supplement.pdf",
            "README_PR_REPRODUCIBILITY.md",
        ],
    }

    for root, relatives in required.items():
        if not root.is_dir():
            errors.append(f"missing package root: {root}")
            continue
        errors.extend(check_required(root, relatives))
        checks.append(f"{root.name}: {len(deliverable_files(root))} deliverable files")

    canonical_pairs = [
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.pdf", READY / "pdf/Manuscript.pdf"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.pdf", SOURCE / "fedadaptermanifold_pr_resubmit.pdf"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.pdf", REPRO / "fedadaptermanifold_pr_main.pdf"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.pdf", READY / "pdf/Supplementary_Material.pdf"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.pdf", SOURCE / "fedadaptermanifold_pr_resubmit_supplement.pdf"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.pdf", REPRO / "fedadaptermanifold_pr_supplement.pdf"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.tex", READY / "source/fedadaptermanifold_pr_resubmit.tex"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.tex", SOURCE / "fedadaptermanifold_pr_resubmit.tex"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.tex", REPRO / "fedadaptermanifold_pr_main.tex"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.tex", READY / "source/fedadaptermanifold_pr_resubmit_supplement.tex"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.tex", SOURCE / "fedadaptermanifold_pr_resubmit_supplement.tex"),
        (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.tex", REPRO / "fedadaptermanifold_pr_supplement.tex"),
    ]
    for canonical, packaged in canonical_pairs:
        if not canonical.is_file() or not packaged.is_file():
            errors.append(f"missing canonical/package file: {canonical} or {packaged}")
        elif sha256(canonical) != sha256(packaged):
            errors.append(f"canonical/package mismatch: {canonical} != {packaged}")

    pdf_expectations = {
        ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.pdf": 35,
        ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.pdf": 50,
        ROOT / "paper_resubmit/PR_D_26_08222_resubmission_cover_letter.pdf": 2,
    }
    for path, expected_pages in pdf_expectations.items():
        reader = PdfReader(path)
        pages = len(reader.pages)
        box = reader.pages[0].mediabox
        width, height = float(box.width), float(box.height)
        checks.append(f"{path.name}: {pages} pages, {width:.1f} x {height:.1f} pt")
        if pages != expected_pages:
            errors.append(f"unexpected page count: {path} has {pages}, expected {expected_pages}")
        if abs(width - 612.0) > 0.5 or abs(height - 792.0) > 0.5:
            errors.append(f"non-Letter page size: {path} is {width:.1f} x {height:.1f} pt")

    bbl = ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.bbl"
    reference_count = bbl.read_text(encoding="utf-8").count("\\bibitem")
    checks.append(f"generated bibliography: {reference_count} cited items")
    if not 35 <= reference_count <= 55:
        errors.append(f"bibliography count outside PR range: {reference_count}")

    for root in (READY, SOURCE, REPRO):
        count, checksum_errors = write_and_verify_checksums(root)
        errors.extend(checksum_errors)
        archive, zip_errors = create_and_check_zip(root)
        errors.extend(zip_errors)
        checks.append(
            f"{root.name}: {count} checksums; ZIP {archive.stat().st_size / (1024 * 1024):.2f} MiB; "
            f"SHA-256 {sha256(archive)}"
        )

    status = "PASS" if not errors else "FAIL"
    lines = [
        "# FedAdapterManifold PR Package Validation",
        "",
        f"Status: **{status}**",
        "",
        "## Checks",
        "",
        *[f"- {item}" for item in checks],
        "",
        "## Errors",
        "",
        *([f"- {item}" for item in errors] if errors else ["- None."]),
        "",
        "## Claim boundary",
        "",
        "The Target-Pareto OfficeHome safety result validates harmful-candidate rejection and exact local fallback. "
        "A separate target-constrained OfficeHome utility audit admits 18/20 non-local routes and yields 17 positive, "
        "3 tied, and 0 negative held-out units versus Local-LoRA. The PACS FedTree-anchor residual audit separately "
        "records positive receiver-specific composition under a declared additional calibration budget. The "
        "gauge-invariant exact-update mechanism confirmation and the failed, archived opportunity-threshold audit are "
        "both included so the evidence trail is complete.",
    ]
    REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"{status}: {REPORT}")
    for error in errors:
        print(f"ERROR: {error}")
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
