#!/usr/bin/env python3
"""Validate that result-audit artifacts exist and contain no unexplained failures."""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path


CORE_FILES = [
    "mechanism_decomposition.csv",
    "mechanism_signal_reliability.csv",
    "residual_budget_summary.csv",
    "per_dataset_failure_taxonomy.md",
    "fam_resolve_selection_log.csv",
]


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input-dir", default="results/fam_resolve_stage1_20260629")
    ap.add_argument("--out", default="paper_resubmit/results_artifact_audit.md")
    return ap.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.input_dir)
    errors: list[str] = []
    warnings: list[str] = []
    for name in CORE_FILES:
        if not (root / name).exists():
            errors.append(f"Missing required result artifact: {root / name}")

    residual_path = root / "residual_budget_summary.csv"
    failed_rows = 0
    if residual_path.exists():
        with residual_path.open(newline="", encoding="utf-8", errors="replace") as f:
            reader = csv.DictReader(f)
            for row in reader:
                status = (row.get("certified_status") or row.get("mechanism_status") or "").strip()
                if status == "failed_unexplained":
                    failed_rows += 1
        if failed_rows:
            errors.append(f"residual_budget_summary.csv contains {failed_rows} failed_unexplained rows.")

    report = ["# Results Artifact Audit", "", f"- Input directory: `{root}`", "", "## Errors"]
    report.extend([f"- {e}" for e in errors] if errors else ["- None"])
    report.extend(["", "## Warnings"])
    report.extend([f"- {w}" for w in warnings] if warnings else ["- None"])
    Path(args.out).write_text("\n".join(report) + "\n", encoding="utf-8")
    print(args.out)
    if errors:
        for e in errors:
            print("ERROR:", e, file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
