from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import yaml


EXPECTED_HIERARCHY = "deduplicate;holm_local_safety;serial_fam_vs_geo"
DATASETS = ("domainnetmini_clip_60class", "officehome_clip_full")
SEEDS = tuple(range(5))


def _rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _protocol_payload_sha256(path: Path) -> str:
    # The preregistration runner hashes json.dumps(...) and then writes that
    # payload followed by one conventional terminal newline.
    text = path.read_text(encoding="utf-8")
    if text.endswith("\n"):
        text = text[:-1]
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Validate the topology-calibrated canonical serial-Holm replay."
    )
    parser.add_argument("--result-root", type=Path, required=True)
    parser.add_argument("--legacy-root", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = args.result_root.resolve()
    legacy = args.legacy_root.resolve()
    checks: list[dict[str, object]] = []

    def record(name: str, passed: bool, detail: str) -> None:
        checks.append({"check": name, "passed": bool(passed), "detail": detail})

    manifest_path = root / "preregistered_protocol.json"
    digest_path = root / "preregistered_protocol.sha256"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    digest = digest_path.read_text(encoding="ascii").strip()
    record("manifest_hash", digest == _protocol_payload_sha256(manifest_path), digest)
    record("manifest_file_sha256", True, _sha256(manifest_path))
    record(
        "canonical_mode_preregistered",
        manifest.get("semantic_admission_exact_mode") == "hierarchical-holm-deduplicated",
        str(manifest.get("semantic_admission_exact_mode")),
    )

    comparable_columns = None
    max_weight_error = 0.0
    total_units = 0
    nonlocal_count = 0
    harmful_count = 0
    uncertified_count = 0
    for dataset in DATASETS:
        for seed in SEEDS:
            run = root / dataset / f"seed_{seed}"
            old = legacy / dataset / f"seed_{seed}"
            for filename in (
                "metrics.csv",
                "per_client_metrics.csv",
                "run_provenance.json",
                "semantic_admission_weights.csv",
                "semantic_admission_exact_certificate.csv",
            ):
                record(
                    f"exists:{dataset}:seed{seed}:{filename}",
                    (run / filename).is_file(),
                    str(run / filename),
                )

            provenance = json.loads(
                (run / "run_provenance.json").read_text(encoding="utf-8")
            )
            config_path = Path(provenance["source_config_path"])
            if not config_path.is_absolute():
                config_path = (run / config_path).resolve()
            effective = yaml.safe_load(config_path.read_text(encoding="utf-8"))
            record(
                f"config_hash:{dataset}:seed{seed}",
                provenance.get("source_config_sha256") == _sha256(config_path),
                str(config_path),
            )
            record(
                f"effective_mode:{dataset}:seed{seed}",
                effective.get("semantic_admission_exact_mode")
                == "hierarchical-holm-deduplicated",
                str(effective.get("semantic_admission_exact_mode")),
            )

            certificates = _rows(run / "semantic_admission_exact_certificate.csv")
            record(
                f"hierarchy:{dataset}:seed{seed}",
                bool(certificates)
                and all(row.get("certificate_hierarchy") == EXPECTED_HIERARCHY for row in certificates),
                f"rows={len(certificates)}",
            )
            record(
                f"test_free:{dataset}:seed{seed}",
                all(row.get("test_used_for_selection", "").lower() == "false" for row in certificates),
                f"rows={len(certificates)}",
            )
            selected = [row for row in certificates if row.get("selected", "").lower() == "true"]
            total_units += len(selected)
            for row in selected:
                if row.get("candidate_method") != "Local-LoRA":
                    nonlocal_count += 1
                    if row.get("candidate_method") == "Geo-only-Agg":
                        certified = row.get("geo_only_agg_certified", "").lower() == "true"
                    else:
                        certified = (
                            row.get("fam_vs_local_certified", "").lower() == "true"
                            and row.get("fam_vs_geo_certified", "").lower() == "true"
                        )
                    if not certified:
                        uncertified_count += 1

            new_weights = _rows(run / "semantic_admission_weights.csv")
            old_weights = _rows(old / "semantic_admission_weights.csv")
            key_columns = ("round", "receiver_client", "donor_client")
            record(
                f"weight_rows:{dataset}:seed{seed}",
                len(new_weights) == len(old_weights),
                f"new={len(new_weights)},old={len(old_weights)}",
            )
            if len(new_weights) != len(old_weights):
                continue
            new_weights.sort(key=lambda row: tuple(row[column] for column in key_columns))
            old_weights.sort(key=lambda row: tuple(row[column] for column in key_columns))
            keys_match = all(
                tuple(new[column] for column in key_columns)
                == tuple(old_row[column] for column in key_columns)
                for new, old_row in zip(new_weights, old_weights)
            )
            record(f"weight_keys:{dataset}:seed{seed}", keys_match, f"rows={len(new_weights)}")
            if comparable_columns is None:
                comparable_columns = [
                    column
                    for column in new_weights[0]
                    if column not in {"method", "receiver_domain", "donor_domain"}
                    and column not in key_columns
                    and all(_is_float(row.get(column, "")) for row in new_weights + old_weights)
                ]
            for new, old_row in zip(new_weights, old_weights):
                for column in comparable_columns:
                    max_weight_error = max(
                        max_weight_error,
                        abs(float(new[column]) - float(old_row[column])),
                    )

    record("endpoint_weight_parity", max_weight_error <= 1e-10, f"max_abs_error={max_weight_error:.3e}")
    record("unit_count", total_units == 50, f"selected_units={total_units}")
    record("no_uncertified_deployment", uncertified_count == 0, f"count={uncertified_count}")

    analysis = root / "analysis" / "topology_support_summary.csv"
    if analysis.is_file():
        rows = _rows(analysis)
        harmful_count = sum(int(float(row["harmful_admission_count"])) for row in rows)
        record("analysis_rows", len(rows) == 2, f"rows={len(rows)}")
        record("zero_invented_edges", all(int(float(row["positive_weight_on_absent_edge_count"])) == 0 for row in rows), f"rows={len(rows)}")
        record("generator_decoupling", all(row["passes_generator_decoupling"].lower() == "true" for row in rows), f"rows={len(rows)}")
    else:
        record("analysis_rows", False, str(analysis))
    record("zero_harmful_admission", harmful_count == 0, f"count={harmful_count}")

    output = root / "final_validation"
    output.mkdir(parents=True, exist_ok=True)
    with (output / "validation_checks.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["check", "passed", "detail"])
        writer.writeheader()
        writer.writerows(checks)
    failures = [row for row in checks if not row["passed"]]
    report = [
        "# Topology Holm Replay Validation",
        "",
        f"- Checks: {len(checks)}",
        f"- Failures: {len(failures)}",
        f"- Endpoint-weight maximum absolute error vs legacy topology replay: {max_weight_error:.3e}",
        f"- Selected units / non-local / harmful / uncertified: {total_units} / {nonlocal_count} / {harmful_count} / {uncertified_count}",
        "",
    ]
    if failures:
        report.extend(["## Failures", ""] + [f"- {row['check']}: {row['detail']}" for row in failures])
    else:
        report.extend(["## Status", "", "PASS"])
    (output / "validation_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 1 if failures else 0


def _is_float(value: str) -> bool:
    try:
        float(value)
    except (TypeError, ValueError):
        return False
    return True


if __name__ == "__main__":
    raise SystemExit(main())
