from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd


SEEDS = [5, 6, 7, 8, 9]
RNG_SEED = 20260813


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Analyze the frozen DomainNetMini-60 pooled-subspace confirmation."
    )
    parser.add_argument(
        "--result-root",
        type=Path,
        default=Path(__file__).resolve().parent.parent
        / "results"
        / "fam_clip_e2e_pooled_ucb_domainnet60_seed5to9_20260813",
    )
    parser.add_argument("--bootstrap-replicates", type=int, default=30000)
    return parser.parse_args()


def _pearson(x: np.ndarray, y: np.ndarray) -> float:
    if len(x) < 2 or np.std(x) < 1e-12 or np.std(y) < 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def _bootstrap_seed_mean(
    values: np.ndarray, n_boot: int, rng: np.random.Generator
) -> tuple[float, float]:
    draws = rng.choice(values, size=(n_boot, len(values)), replace=True).mean(axis=1)
    return tuple(float(value) for value in np.quantile(draws, [0.025, 0.975]))


def _hierarchical_correlation_bootstrap(
    rows: pd.DataFrame,
    distance: str,
    n_boot: int,
    rng: np.random.Generator,
) -> tuple[float, float]:
    seeds = np.asarray(sorted(rows["seed"].unique()), dtype=np.int64)
    draws = []
    for _ in range(n_boot):
        sampled_parts = []
        for sampled_seed_index, seed in enumerate(
            rng.choice(seeds, size=len(seeds), replace=True)
        ):
            seed_rows = rows[rows["seed"] == int(seed)]
            receivers = np.asarray(sorted(seed_rows["receiver_client_id"].unique()))
            for receiver_copy, receiver in enumerate(
                rng.choice(receivers, size=len(receivers), replace=True)
            ):
                block = seed_rows[seed_rows["receiver_client_id"] == receiver].copy()
                block["bootstrap_seed"] = sampled_seed_index
                block["bootstrap_receiver"] = receiver_copy
                sampled_parts.append(block)
        sampled = pd.concat(sampled_parts, ignore_index=True)
        value = _pearson(
            sampled[distance].to_numpy(dtype=np.float64),
            sampled["aggregation_failure"].to_numpy(dtype=np.float64),
        )
        if np.isfinite(value):
            draws.append(value)
    return tuple(float(value) for value in np.quantile(draws, [0.025, 0.975]))


def _seed_regression(rows: pd.DataFrame, distance: str) -> tuple[float, float]:
    y = rows["aggregation_failure"].to_numpy(dtype=np.float64)
    geo = rows["d_geo"].to_numpy(dtype=np.float64)
    sub = rows[distance].to_numpy(dtype=np.float64)

    def standardize(value: np.ndarray) -> np.ndarray:
        std = float(np.std(value))
        return (value - float(np.mean(value))) / std if std > 1e-12 else np.zeros_like(value)

    y = standardize(y)
    geo = standardize(geo)
    sub = standardize(sub)
    reduced = np.column_stack([np.ones(len(y)), geo])
    full = np.column_stack([np.ones(len(y)), geo, sub])
    reduced_fit = reduced @ np.linalg.lstsq(reduced, y, rcond=None)[0]
    full_beta = np.linalg.lstsq(full, y, rcond=None)[0]
    full_fit = full @ full_beta
    denominator = max(float(np.sum((y - y.mean()) ** 2)), 1e-12)
    reduced_r2 = 1.0 - float(np.sum((y - reduced_fit) ** 2)) / denominator
    full_r2 = 1.0 - float(np.sum((y - full_fit) ** 2)) / denominator
    return float(full_beta[-1]), float(full_r2 - reduced_r2)


def _exact_sign_flip_p(values: np.ndarray) -> float:
    observed = float(values.mean())
    null = [
        float(np.mean(values * np.asarray(signs, dtype=np.float64)))
        for signs in itertools.product((-1.0, 1.0), repeat=len(values))
    ]
    return float(np.mean(np.asarray(null) >= observed - 1e-15))


def _summarize_empirical_penalty(uncertainty: pd.DataFrame) -> dict[str, object]:
    """Summarize like-for-like receiver penalties without treating T=1 as a bound."""

    trajectory = uncertainty[
        uncertainty.get("final_estimator_audit", False).astype(str).str.lower()
        != "true"
    ].copy()
    receiver_penalty = (
        trajectory.groupby(["seed", "rounds_pooled", "client_id"], as_index=False)[
            "uncertainty_radius"
        ]
        .sum()
        .rename(columns={"uncertainty_radius": "empirical_receiver_penalty"})
    )
    by_round = {
        round_id: receiver_penalty[receiver_penalty["rounds_pooled"] == round_id][
            "empirical_receiver_penalty"
        ].to_numpy(float)
        for round_id in (1, 2, 5)
    }
    if any(not len(values) for values in by_round.values()):
        raise RuntimeError("Incomplete empirical-penalty trajectory for rounds 1, 2, and 5")
    round1_identifiable = bool(np.max(np.abs(by_round[1])) > 1e-6)
    return {
        "round1": by_round[1],
        "round2": by_round[2],
        "round5": by_round[5],
        "round1_identifiable": round1_identifiable,
        "predeclared_reduction_supported": bool(
            round1_identifiable
            and np.median(by_round[5]) < np.median(by_round[1])
        ),
        "descriptive_round2_to5_decrease": bool(
            np.median(by_round[5]) < np.median(by_round[2])
        ),
    }


def main() -> int:
    args = parse_args()
    root = args.result_root.resolve()
    metric_parts = []
    client_parts = []
    subspace_parts = []
    uncertainty_parts = []
    selection_parts = []
    for seed in SEEDS:
        seed_root = root / "shot_4" / f"seed_{seed}"
        required = [
            seed_root / "metrics.csv",
            seed_root / "per_client_metrics.csv",
            seed_root / "subspace_metrics.csv",
            seed_root / "subspace_uncertainty.csv",
            seed_root / "subspace_distance_estimators.npz",
            seed_root / "candidate_selection.csv",
        ]
        missing = [str(path) for path in required if not path.exists()]
        if missing:
            raise RuntimeError(f"Frozen confirmation incomplete for seed {seed}: {missing}")
        for path, parts in [
            (required[0], metric_parts),
            (required[1], client_parts),
            (required[2], subspace_parts),
            (required[3], uncertainty_parts),
        ]:
            frame = pd.read_csv(path)
            frame["seed"] = seed
            parts.append(frame)
        selection = pd.read_csv(required[5])
        selection = selection[
            (selection["selection_protocol"] == "receiver_tangent_exact_certificate_v1")
            & (selection["screen_selected"].astype(str).str.lower() == "true")
        ].copy()
        if len(selection) != 6 or selection["client_id"].nunique() != 6:
            raise RuntimeError(
                f"Expected one frozen certified selection per receiver for seed {seed}, "
                f"found {len(selection)} rows/{selection['client_id'].nunique()} receivers"
            )
        selection["seed"] = seed
        selection_parts.append(selection)

    metrics = pd.concat(metric_parts, ignore_index=True)
    clients = pd.concat(client_parts, ignore_index=True)
    subspace = pd.concat(subspace_parts, ignore_index=True)
    uncertainty = pd.concat(uncertainty_parts, ignore_index=True)
    selections = pd.concat(selection_parts, ignore_index=True)
    rng = np.random.default_rng(RNG_SEED)

    methods = [
        "Local-CLIP-LoRA",
        "FedAvg-CLIP-LoRA",
        "FedAvg-Lift-CLIP-LoRA",
        "FedGeo-Agg-CLIP-LoRA",
        "FedAdapterManifold-CLIP-LoRA",
        "FedAdapterManifold-Selective-CLIP-LoRA",
        "FedAdapterManifold-Tangent-Certified-CLIP-LoRA",
    ]
    performance_rows = []
    for method in methods:
        frame = metrics[metrics["method"] == method].sort_values("seed")
        if len(frame) != len(SEEDS):
            raise RuntimeError(f"Expected five metric rows for {method}, found {len(frame)}")
        values = frame["mean_accuracy"].to_numpy(dtype=np.float64)
        low, high = _bootstrap_seed_mean(values, args.bootstrap_replicates, rng)
        performance_rows.append(
            {
                "method": method,
                "mean_accuracy": float(values.mean()),
                "seed_ci_low": low,
                "seed_ci_high": high,
            }
        )
    performance = pd.DataFrame(performance_rows)
    method_means = performance.set_index("method")["mean_accuracy"]
    fam = "FedAdapterManifold-CLIP-LoRA"
    gain_rows = []
    for baseline in ["FedAvg-CLIP-LoRA", "FedGeo-Agg-CLIP-LoRA", "Local-CLIP-LoRA"]:
        fam_values = metrics[metrics["method"] == fam].sort_values("seed")["mean_accuracy"].to_numpy(float)
        base_values = metrics[metrics["method"] == baseline].sort_values("seed")["mean_accuracy"].to_numpy(float)
        effects = fam_values - base_values
        low, high = _bootstrap_seed_mean(effects, args.bootstrap_replicates, rng)
        gain_rows.append(
            {
                "comparison": f"{fam} minus {baseline}",
                "mean_gain": float(effects.mean()),
                "seed_ci_low": low,
                "seed_ci_high": high,
                "sign_flip_p_one_sided": _exact_sign_flip_p(effects),
                "positive_seeds": int((effects > 0).sum()),
                "ties": int(np.isclose(effects, 0.0).sum()),
                "negative_seeds": int((effects < 0).sum()),
            }
        )
    gains = pd.DataFrame(gain_rows)

    distance_columns = [
        "d_sub_final_state",
        "d_sub_final_update",
        "d_sub_pooled",
        "d_sub_ucb",
    ]
    diagnostic_rows = []
    for distance in distance_columns:
        correlation = _pearson(
            subspace[distance].to_numpy(float),
            subspace["aggregation_failure"].to_numpy(float),
        )
        low, high = _hierarchical_correlation_bootstrap(
            subspace, distance, args.bootstrap_replicates, rng
        )
        seed_coefficients = []
        seed_incremental_r2 = []
        for seed, frame in subspace.groupby("seed"):
            coefficient, incremental_r2 = _seed_regression(frame, distance)
            seed_coefficients.append(coefficient)
            seed_incremental_r2.append(incremental_r2)
        coefficient_low, coefficient_high = _bootstrap_seed_mean(
            np.asarray(seed_coefficients), args.bootstrap_replicates, rng
        )
        r2_low, r2_high = _bootstrap_seed_mean(
            np.asarray(seed_incremental_r2), args.bootstrap_replicates, rng
        )
        diagnostic_rows.append(
            {
                "distance_estimator": distance,
                "pooled_pair_correlation": correlation,
                "hierarchical_ci_low": low,
                "hierarchical_ci_high": high,
                "controlled_subspace_coefficient": float(np.mean(seed_coefficients)),
                "controlled_coefficient_ci_low": coefficient_low,
                "controlled_coefficient_ci_high": coefficient_high,
                "incremental_r2": float(np.mean(seed_incremental_r2)),
                "incremental_r2_ci_low": r2_low,
                "incremental_r2_ci_high": r2_high,
            }
        )
    diagnostics = pd.DataFrame(diagnostic_rows)

    # The implementation logs an empirical dispersion/eigengap penalty, not the
    # Matrix-Bernstein confidence radius from the conditional theorem. With a
    # single projector the empirical dispersion is identically zero, so a T=1
    # versus T=5 decrease is not an identifiable uncertainty-reduction test.
    # Preserve that predeclared test as unresolved instead of turning the
    # algebraic zero into positive evidence. A like-for-like T=2 versus T=5
    # receiver-level trend is reported as descriptive information only.
    penalty_summary = _summarize_empirical_penalty(uncertainty)
    round1 = penalty_summary["round1"]
    round2 = penalty_summary["round2"]
    round5 = penalty_summary["round5"]
    round1_identifiable = bool(penalty_summary["round1_identifiable"])
    empirical_penalty_decreased_round2_to5 = bool(
        penalty_summary["descriptive_round2_to5_decrease"]
    )

    local = clients[clients["method"] == "Local-CLIP-LoRA"][
        ["seed", "client_id", "accuracy"]
    ].rename(columns={"accuracy": "local_accuracy"})
    certified = clients[
        clients["method"] == "FedAdapterManifold-Tangent-Certified-CLIP-LoRA"
    ][["seed", "client_id", "accuracy"]].rename(columns={"accuracy": "certified_accuracy"})
    safety = certified.merge(local, on=["seed", "client_id"], validate="one_to_one")
    selection_status = selections[["seed", "client_id", "deployed_method"]].copy()
    selection_status["selected_nonlocal"] = (
        selection_status["deployed_method"] != "Local-CLIP-LoRA"
    )
    safety = safety.merge(selection_status, on=["seed", "client_id"], validate="one_to_one")
    safety["gain_vs_local"] = safety["certified_accuracy"] - safety["local_accuracy"]
    harmful = int((safety["gain_vs_local"] < -1e-12).sum())
    admitted = safety[safety["selected_nonlocal"]].copy()
    nonlocal_count = int(len(admitted))
    positive_nonlocal = int((admitted["gain_vs_local"] > 1e-12).sum())
    tied_nonlocal = int(np.isclose(admitted["gain_vs_local"], 0.0).sum())
    harmful_nonlocal = int((admitted["gain_vs_local"] < -1e-12).sum())

    pooled_diag = diagnostics.set_index("distance_estimator").loc["d_sub_pooled"]
    raw_diag = diagnostics.set_index("distance_estimator").loc["d_sub_final_update"]
    diagnostic_supported = bool(
        pooled_diag["hierarchical_ci_low"] > 0.0
        and pooled_diag["pooled_pair_correlation"] > raw_diag["pooled_pair_correlation"]
    )
    uncertainty_reduced = bool(penalty_summary["predeclared_reduction_supported"])
    safe = harmful == 0
    nonlocal_utility_supported = bool(
        nonlocal_count > 0 and positive_nonlocal > 0 and harmful_nonlocal == 0
    )
    fedavg_gain = gains[gains["comparison"].str.endswith("FedAvg-CLIP-LoRA")].iloc[0]
    stable_fedavg_gain = bool(fedavg_gain["seed_ci_low"] > 0.0)

    summary = pd.DataFrame(
        [
            {
                "dataset": "DomainNetMini-60",
                "seeds": 5,
                "shot": 4,
                "rounds": 5,
                "pooled_diagnostic_supported": diagnostic_supported,
                "uncertainty_reduced": uncertainty_reduced,
                "formal_confidence_radius_implemented": False,
                "round1_empirical_penalty_identifiable": round1_identifiable,
                "median_radius_round1": float(np.median(round1)),
                "median_radius_round5": float(np.median(round5)),
                "median_empirical_receiver_penalty_round2": float(np.median(round2)),
                "median_empirical_receiver_penalty_round5": float(np.median(round5)),
                "descriptive_penalty_decreased_round2_to5": (
                    empirical_penalty_decreased_round2_to5
                ),
                "radius_interpretation": (
                    "empirical_dispersion_gap_penalty_not_formal_confidence_radius"
                ),
                "certified_harmful_units_vs_local": harmful,
                "certified_safe": safe,
                "certified_nonlocal_units": nonlocal_count,
                "nonlocal_positive_units": positive_nonlocal,
                "nonlocal_tied_units": tied_nonlocal,
                "nonlocal_harmful_units": harmful_nonlocal,
                "nonlocal_utility_supported": nonlocal_utility_supported,
                "stable_gain_vs_fedavg": stable_fedavg_gain,
                "fam_mean_accuracy": float(method_means[fam]),
            }
        ]
    )

    output = root / "analysis"
    output.mkdir(parents=True, exist_ok=True)
    performance.to_csv(output / "performance_summary.csv", index=False)
    gains.to_csv(output / "paired_seed_gains.csv", index=False)
    diagnostics.to_csv(output / "subspace_estimator_diagnostics.csv", index=False)
    safety.to_csv(output / "certified_safety_units.csv", index=False)
    summary.to_csv(output / "pooled_confirmation_summary.csv", index=False)

    result_phrases = []
    result_phrases.append(
        "supports the pooled-projector diagnostic"
        if diagnostic_supported
        else "does not establish a positive pooled-projector diagnostic"
    )
    result_phrases.append(
        "retains zero-harm certified fallback" if safe else "violates certified fallback safety"
    )
    result_phrases.append(
        "establishes positive non-local routing utility"
        if nonlocal_utility_supported
        else "does not establish non-local routing utility"
    )
    result_phrases.append(
        "stably repairs FedAvg" if stable_fedavg_gain else "does not show a stable FedAvg gain"
    )
    report = [
        "# DomainNetMini-60 end-to-end pooled-projector confirmation",
        "",
        "Seeds 5--9, round weights, uncertainty scale, geometry sources, and success criteria were frozen before the confirmation outputs were inspected.",
        "",
        f"**Conclusion:** The confirmation {', '.join(result_phrases)}.",
        "",
        "- The routing implementation uses an empirical dispersion/eigengap "
        "penalty; it does not instantiate the theorem's formal Matrix-Bernstein "
        "confidence radius.",
        f"- Round-1 empirical penalty identifiable: {round1_identifiable}. "
        "Its one-projector dispersion is algebraically zero, so the predeclared "
        "round-1-to-round-5 radius-reduction criterion is unresolved rather "
        "than positive.",
        f"- Descriptive receiver-level empirical penalty: round 2 = {np.median(round2):.4f}; "
        f"round 5 = {np.median(round5):.4f}; decreased = "
        f"{empirical_penalty_decreased_round2_to5} (not a confirmatory claim).",
        f"- Pooled subspace/failure r = {pooled_diag['pooled_pair_correlation']:+.4f}, hierarchical CI [{pooled_diag['hierarchical_ci_low']:+.4f}, {pooled_diag['hierarchical_ci_high']:+.4f}].",
        f"- Final-update subspace/failure r = {raw_diag['pooled_pair_correlation']:+.4f}.",
        f"- Certified harmful client-seed units versus Local: {harmful}/{len(safety)}.",
        f"- Certified non-local client-seed units: {nonlocal_count}/{len(safety)}; retrospective +/0/- = {positive_nonlocal}/{tied_nonlocal}/{harmful_nonlocal}.",
        f"- FAM mean accuracy: {method_means[fam]:.4f}.",
        "",
        "A safe fallback is not counted as a positive routing gain. The diagnostic is called positive only when its seed/receiver hierarchical lower bound is above zero and it exceeds the raw final-update correlation. The empirical penalty is kept separate from the theorem's conditional confidence radius.",
    ]
    (output / "pooled_confirmation_report.md").write_text(
        "\n".join(report) + "\n", encoding="utf-8"
    )
    print(summary.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
