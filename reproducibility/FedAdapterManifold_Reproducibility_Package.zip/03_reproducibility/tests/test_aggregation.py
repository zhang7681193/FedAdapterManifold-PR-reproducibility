import unittest

import numpy as np

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.aggregation import (
    compatibility_matrix,
    fedavg_lift,
    geo_weighted_aggregate,
    graph_weight_matrix,
    normalize_rows,
    receiver_subspace_projected_aggregate,
    select_adapter_bank_k,
    semantic_admissible_lift_aggregate,
)


class AggregationTests(unittest.TestCase):
    def test_receiver_projected_sharing_removes_orthogonal_donor_components(self):
        adapters = [
            LoRAAdapter.from_delta(np.array([[2.0, 0.0], [0.0, 0.0]]), rank=1, alpha=1.0),
            LoRAAdapter.from_delta(np.array([[0.0, 0.0], [0.0, 3.0]]), rank=1, alpha=1.0),
        ]
        zeros = np.zeros((2, 2), dtype=np.float64)
        graph = np.array([[1.0, 1e-12], [1e-12, 1.0]], dtype=np.float64)
        projected, weights = receiver_subspace_projected_aggregate(
            adapters,
            graph=graph,
            d_sub=zeros,
            d_geo=zeros,
            d_label=zeros,
            d_local_risk=zeros,
            target_ranks=[1, 1],
        )

        self.assertAlmostEqual(weights[0, 1], 0.5)
        np.testing.assert_allclose(projected[0].delta(), 0.5 * adapters[0].delta(), atol=1e-10)
        np.testing.assert_allclose(projected[1].delta(), 0.5 * adapters[1].delta(), atol=1e-10)

    def test_receiver_tangent_projection_keeps_one_sided_shared_directions(self):
        adapters = [
            LoRAAdapter.from_delta(np.array([[2.0, 0.0], [0.0, 0.0]]), rank=1, alpha=1.0),
            LoRAAdapter.from_delta(np.array([[0.0, 3.0], [0.0, 0.0]]), rank=1, alpha=1.0),
        ]
        zeros = np.zeros((2, 2), dtype=np.float64)
        graph = np.array([[1.0, 1e-12], [1e-12, 1.0]], dtype=np.float64)
        core, _ = receiver_subspace_projected_aggregate(
            adapters, graph, zeros, zeros, zeros, zeros, target_ranks=[1, 1], projection_mode="core"
        )
        tangent, _ = receiver_subspace_projected_aggregate(
            adapters, graph, zeros, zeros, zeros, zeros, target_ranks=[1, 1], projection_mode="tangent"
        )
        left, _ = receiver_subspace_projected_aggregate(
            adapters, graph, zeros, zeros, zeros, zeros, target_ranks=[1, 1], projection_mode="left"
        )
        right, _ = receiver_subspace_projected_aggregate(
            adapters, graph, zeros, zeros, zeros, zeros, target_ranks=[1, 1], projection_mode="right"
        )

        self.assertLess(np.linalg.norm(core[0].delta() - adapters[0].delta() * 0.5), 1e-10)
        self.assertGreater(np.linalg.norm(tangent[0].delta() - core[0].delta()), 0.5)
        self.assertGreater(np.linalg.norm(left[0].delta() - core[0].delta()), 0.5)
        np.testing.assert_allclose(right[0].delta(), core[0].delta(), atol=1e-10)

    def test_axis_gauge_preserves_the_more_conflicted_receiver_factor(self):
        adapters = [
            LoRAAdapter.from_delta(np.array([[2.0, 0.0], [0.0, 0.0]]), rank=1, alpha=1.0),
            LoRAAdapter.from_delta(np.array([[0.0, 0.0], [3.0, 0.0]]), rank=1, alpha=1.0),
        ]
        zeros = np.zeros((2, 2), dtype=np.float64)
        graph = np.ones((2, 2), dtype=np.float64)
        left, _ = receiver_subspace_projected_aggregate(
            adapters, graph, zeros, zeros, zeros, zeros, target_ranks=[1, 1], projection_mode="left"
        )
        adaptive, _ = receiver_subspace_projected_aggregate(
            adapters, graph, zeros, zeros, zeros, zeros, target_ranks=[1, 1], projection_mode="axis_gauge"
        )
        factor_adaptive, _ = receiver_subspace_projected_aggregate(
            adapters, graph, zeros, zeros, zeros, zeros, target_ranks=[1, 1], projection_mode="axis_factor"
        )
        shared_axis, _ = receiver_subspace_projected_aggregate(
            adapters,
            graph,
            zeros,
            zeros,
            zeros,
            zeros,
            target_ranks=[1, 1],
            projection_mode="axis_gauge",
            projection_cost_mode="shared-axis",
        )
        _, soft_weights = receiver_subspace_projected_aggregate(
            adapters,
            np.eye(2),
            zeros,
            np.array([[0.0, 2.0], [2.0, 0.0]]),
            zeros,
            zeros,
            target_ranks=[1, 1],
            projection_mode="axis_gauge",
            projection_cost_mode="shared-axis",
            projection_support_mode="soft-dgeo",
            projection_knn=1,
            client_weights=np.array([0.25, 0.75]),
        )
        _, all_weights = receiver_subspace_projected_aggregate(
            adapters,
            np.eye(2),
            zeros,
            np.array([[0.0, 2.0], [2.0, 0.0]]),
            zeros,
            zeros,
            target_ranks=[1, 1],
            projection_mode="axis_gauge",
            projection_cost_mode="shared-axis",
            projection_support_mode="shared-axis-all",
            client_weights=np.array([0.25, 0.75]),
        )

        np.testing.assert_allclose(adaptive[0].delta(), left[0].delta(), atol=1e-10)
        np.testing.assert_allclose(adaptive[0].B, adapters[0].B, atol=0.0, rtol=0.0)
        np.testing.assert_allclose(factor_adaptive[0].B, adapters[0].B, atol=0.0, rtol=0.0)
        np.testing.assert_allclose(shared_axis[0].B, adapters[0].B, atol=0.0, rtol=0.0)
        self.assertGreater(soft_weights[0, 1], 0.0)
        self.assertGreater(all_weights[0, 1], 0.0)
        self.assertGreater(all_weights[1, 0], 0.0)

    def test_semantic_admission_uses_exact_update_before_projection(self):
        adapters = [
            LoRAAdapter.from_delta(np.array([[1.0, 0.0], [0.0, 0.0]]), rank=2, alpha=2.0),
            LoRAAdapter.from_delta(np.array([[0.0, 0.0], [0.0, 1.0]]), rank=2, alpha=2.0),
        ]
        zeros = np.zeros((2, 2), dtype=np.float64)
        graph = np.ones((2, 2), dtype=np.float64)
        aggregated, weights = semantic_admissible_lift_aggregate(
            adapters,
            graph=graph,
            d_sub=zeros,
            d_geo=zeros,
            d_label=zeros,
            d_local_risk=zeros,
            target_ranks=[2, 2],
        )
        expected = 0.5 * (adapters[0].delta() + adapters[1].delta())
        self.assertTrue(np.allclose(weights, 0.5))
        self.assertTrue(np.allclose(aggregated[0].delta(), expected, atol=1e-10))
        self.assertTrue(np.allclose(aggregated[1].delta(), expected, atol=1e-10))

    def test_semantic_admission_preserves_tempered_absolute_graph_confidence(self):
        adapters = [
            LoRAAdapter.from_delta(np.eye(2), rank=2, alpha=2.0),
            LoRAAdapter.from_delta(np.fliplr(np.eye(2)), rank=2, alpha=2.0),
        ]
        zeros = np.zeros((2, 2), dtype=np.float64)
        graph_stronger = np.array([[1.0, 1e-6], [1e-6, 1.0]])
        graph_weaker = np.array([[1.0, 1e-12], [1e-12, 1.0]])
        _, stronger_weights = semantic_admissible_lift_aggregate(
            adapters, graph_stronger, zeros, zeros, zeros, zeros, target_ranks=[2, 2]
        )
        _, weaker_weights = semantic_admissible_lift_aggregate(
            adapters, graph_weaker, zeros, zeros, zeros, zeros, target_ranks=[2, 2]
        )
        self.assertGreater(stronger_weights[0, 1], weaker_weights[0, 1])
        self.assertEqual(weaker_weights[0, 1], 0.0)

    def test_receiver_specific_self_prior_reduces_high_risk_neighbor_weight(self):
        adapters = [
            LoRAAdapter.from_delta(np.eye(2), rank=2, alpha=2.0),
            LoRAAdapter.from_delta(np.fliplr(np.eye(2)), rank=2, alpha=2.0),
        ]
        zeros = np.zeros((2, 2), dtype=np.float64)
        graph = np.ones((2, 2), dtype=np.float64)
        _, baseline_weights = semantic_admissible_lift_aggregate(
            adapters, graph, zeros, zeros, zeros, zeros, target_ranks=[2, 2]
        )
        _, risk_weights = semantic_admissible_lift_aggregate(
            adapters,
            graph,
            zeros,
            zeros,
            zeros,
            zeros,
            target_ranks=[2, 2],
            receiver_self_weights=np.array([np.e, 1.0]),
        )

        self.assertLess(risk_weights[0, 1], baseline_weights[0, 1])
        self.assertAlmostEqual(risk_weights[1, 0], baseline_weights[1, 0])

    def test_fedavg_lift_matches_weighted_delta_shape(self):
        rng = np.random.default_rng(1)
        a1 = LoRAAdapter.random(5, 4, 2, rng, zero_b=False)
        a2 = LoRAAdapter.random(5, 4, 2, rng, zero_b=False)
        avg = fedavg_lift([a1, a2], weights=np.array([0.25, 0.75]), target_rank=2)
        self.assertEqual(avg.delta().shape, (4, 5))

    def test_compatibility_rows_can_normalize(self):
        d = np.array([[0.0, 1.0], [1.0, 0.0]])
        compat = compatibility_matrix(d, d, d, lambda_geo=0.5, lambda_label=0.5, tau=1.0)
        beta = normalize_rows(compat)
        np.testing.assert_allclose(beta.sum(axis=1), np.ones(2))
        self.assertGreater(beta[0, 0], beta[0, 1])

    def test_select_adapter_bank_k_prefers_two_clear_clusters(self):
        distance = np.array(
            [
                [0.0, 0.1, 3.0, 3.1],
                [0.1, 0.0, 3.2, 3.0],
                [3.0, 3.2, 0.0, 0.2],
                [3.1, 3.0, 0.2, 0.0],
            ]
        )
        selected, rows = select_adapter_bank_k(distance, max_k=4)
        self.assertEqual(selected, 2)
        self.assertTrue(any(row["selected"] for row in rows))

    def test_graph_weight_matrix_respects_adjacency(self):
        graph = np.array([[0.0, 1.0, 0.0], [1.0, 0.0, 1.0], [0.0, 1.0, 0.0]])
        distance = np.array([[0.0, 0.1, 9.0], [0.1, 0.0, 2.0], [9.0, 2.0, 0.0]])
        weights = graph_weight_matrix(graph, distance=distance, tau=1.0, self_weight=1.0)
        np.testing.assert_allclose(weights.sum(axis=1), np.ones(3))
        self.assertEqual(weights[0, 2], 0.0)
        self.assertGreater(weights[0, 0], weights[0, 1])

    def test_graph_weight_self_weight_controls_neighbor_sharing(self):
        graph = np.array([[0.0, 1.0], [1.0, 0.0]])
        distance = np.array([[0.0, 0.1], [0.1, 0.0]])
        conservative = graph_weight_matrix(graph, distance=distance, tau=1.0, self_weight=1.0)
        graph_active = graph_weight_matrix(graph, distance=distance, tau=1.0, self_weight=0.1)
        self.assertGreater(conservative[0, 0], graph_active[0, 0])
        self.assertGreater(graph_active[0, 1], conservative[0, 1])

    def test_geo_weighted_aggregate_returns_client_specific_adapters(self):
        rng = np.random.default_rng(2)
        adapters = [LoRAAdapter.random(5, 4, 2, rng, zero_b=False) for _ in range(3)]
        d_geo = np.array([[0.0, 0.2, 3.0], [0.2, 0.0, 1.0], [3.0, 1.0, 0.0]])
        graph = np.array([[0.0, 1.0, 0.0], [1.0, 0.0, 1.0], [0.0, 1.0, 0.0]])
        mixed = geo_weighted_aggregate(adapters, d_geo=d_geo, graph=graph, target_ranks=[2, 2, 2], tau=1.0)
        self.assertEqual(len(mixed), 3)
        self.assertEqual(mixed[0].delta().shape, adapters[0].delta().shape)


if __name__ == "__main__":
    unittest.main()
