import numpy as np
import pandas as pd

from scripts.analyze_clip_e2e_officehome_temporal_confirmation import (
    exact_sign_flip_p,
    paired_summary,
)


def test_exact_sign_flip_five_positive_seeds() -> None:
    assert exact_sign_flip_p(np.ones(5)) == 1.0 / 32.0


def test_exact_sign_flip_removes_ties() -> None:
    assert exact_sign_flip_p(np.asarray([1.0, 1.0, 0.0])) == 1.0 / 4.0


def test_paired_summary_uses_seed_as_independent_unit() -> None:
    rows = pd.DataFrame(
        {
            "seed": np.repeat(np.arange(5), 4),
            "left": np.repeat(np.arange(1, 6, dtype=float), 4),
            "right": np.zeros(20),
        }
    )
    summary = paired_summary(
        rows,
        "left",
        "right",
        replicates=200,
        rng=np.random.default_rng(7),
    )
    assert summary["mean_gain"] == 3.0
    assert summary["positive_seeds"] == 5
    assert summary["exact_sign_flip_p_one_sided"] == 1.0 / 32.0
