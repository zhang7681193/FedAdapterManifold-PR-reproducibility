import numpy as np

from scripts.analyze_dual_transport import analyze, exact_sign_flip_p, reconstruct_certificates


def test_exact_sign_flip_ignores_ties():
    assert exact_sign_flip_p(np.asarray([1.0, 1.0, 1.0, 1.0, 0.0])) == 0.0625


def test_analyze_reports_paired_seed_and_receiver_effects():
    rows = []
    for seed, method_values, anchor_values in (
        (0, (0.8, 0.6), (0.7, 0.5)),
        (1, (0.9, 0.4), (0.8, 0.4)),
    ):
        for client_idx, (method_accuracy, anchor_accuracy) in enumerate(zip(method_values, anchor_values)):
            common = {"seed": seed, "client_id": f"client_{client_idx}", "domain": f"domain_{client_idx}"}
            rows.append({**common, "method": "Dual", "accuracy": method_accuracy, "loss": 1.0 - method_accuracy})
            rows.append({**common, "method": "Anchor", "accuracy": anchor_accuracy, "loss": 1.0 - anchor_accuracy})

    seed_rows, paired_rows, receiver_rows = analyze(
        rows,
        method="Dual",
        anchor="Anchor",
        replicates=100,
        bootstrap_seed=0,
    )

    assert len(seed_rows) == 2
    assert len(receiver_rows) == 4
    accuracy = next(row for row in paired_rows if row["metric"] == "accuracy_gain")
    assert np.isclose(accuracy["estimate"], 0.075)
    assert accuracy["positive_seed_count"] == 2
    assert accuracy["negative_seed_count"] == 0


def test_reconstruct_certificates_recovers_worst_anchor_pair():
    common = {
        "seed": 0,
        "client_id": "client_0",
        "domain": "domain_0",
        "method": "Dual",
        "certificate_anchor_names": "Local;Shared",
        "residual_bank_z_value": 2.0,
        "selected_adapter": "Projected",
    }
    rows = [
        {**common, "candidate_adapter": "Local", "candidate_graph_mix_loss": 1.0},
        {**common, "candidate_adapter": "Shared", "candidate_graph_mix_loss": 0.8},
        {
            **common,
            "candidate_adapter": "Projected",
            "candidate_graph_mix_loss": 0.5,
            "worst_certificate_anchor": "Shared",
            "paired_loss_upper_confidence_bound": -0.1,
            "all_anchor_ucb_certified": "True",
        },
    ]

    certificates = reconstruct_certificates(rows, method="Dual")

    assert len(certificates) == 1
    assert np.isclose(certificates[0]["paired_loss_difference_vs_worst_anchor"], -0.3)
    assert np.isclose(certificates[0]["paired_loss_standard_error_vs_worst_anchor"], 0.1)
    assert certificates[0]["all_anchor_ucb_certified"] is True
