from scripts.analyze_exact_receiver_admission import _training_screen_isolated


def test_nested_training_validation_is_isolated() -> None:
    rows = [
        {
            "selection_split": "nested_training_validation",
            "calibration_used": "False",
            "test_used": "False",
        }
    ]

    assert _training_screen_isolated(rows)


def test_calibration_or_test_screen_is_not_isolated() -> None:
    assert not _training_screen_isolated(
        [
            {
                "selection_split": "nested_training_validation",
                "calibration_used": "True",
                "test_used": "False",
            }
        ]
    )
    assert not _training_screen_isolated(
        [
            {
                "selection_split": "adapter_training",
                "calibration_used": "False",
                "test_used": "True",
            }
        ]
    )
    assert not _training_screen_isolated(
        [
            {
                "selection_split": "outer_calibration",
                "calibration_used": "False",
                "test_used": "False",
            }
        ]
    )
