from __future__ import annotations

import numpy as np

from scripts.analyze_frozen_method_comparisons import _exact_sign_flip, _hierarchical_bootstrap, _pair


def test_pair_matches_client_seed_units_and_orients_gain():
    rows = [
        {"seed": 0, "client_id": "a", "domain": "x", "method": "M", "accuracy": 0.8, "loss": 0.4},
        {"seed": 0, "client_id": "a", "domain": "x", "method": "B", "accuracy": 0.6, "loss": 0.7},
        {"seed": 1, "client_id": "a", "domain": "x", "method": "M", "accuracy": 0.7, "loss": 0.5},
        {"seed": 1, "client_id": "a", "domain": "x", "method": "B", "accuracy": 0.7, "loss": 0.5},
    ]
    pairs = _pair(rows, "M", "B")
    assert len(pairs) == 2
    assert np.isclose(pairs[0]["accuracy_gain"], 0.2)
    assert np.isclose(pairs[0]["loss_reduction"], 0.3)


def test_hierarchical_bootstrap_and_sign_flip_are_deterministic():
    grouped = {
        0: [{"accuracy_gain": 0.1}, {"accuracy_gain": 0.2}],
        1: [{"accuracy_gain": 0.0}, {"accuracy_gain": 0.1}],
    }
    left = _hierarchical_bootstrap(grouped, "accuracy_gain", 100, np.random.default_rng(7))
    right = _hierarchical_bootstrap(grouped, "accuracy_gain", 100, np.random.default_rng(7))
    assert np.array_equal(left, right)
    assert _exact_sign_flip([0.1, 0.2, 0.3, 0.4]) == 0.0625
    assert _exact_sign_flip([0.0, 0.0]) == 1.0
