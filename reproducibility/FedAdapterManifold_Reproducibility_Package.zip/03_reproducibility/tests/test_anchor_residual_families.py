from types import SimpleNamespace

from fedadaptermanifold.run_experiment import _build_anchor_residual_families


def test_anchor_residual_families_keep_external_generators_separate():
    fedper = SimpleNamespace(
        client_adapters=["per-0", "per-1"],
        per_client_metrics=[{"method": "FedPer-LoRA"}],
    )
    ditto = SimpleNamespace(
        personal_adapters=["ditto-0", "ditto-1"],
        per_client_metrics=[{"method": "Ditto-LoRA"}],
    )
    fedtree = SimpleNamespace(
        client_adapters=["tree-0", "tree-1"],
        per_client_metrics=[{"method": "FedTreeLoRA-Visual-Port"}],
    )
    subspace_reg = SimpleNamespace(
        global_adapter="subspace-global",
        per_client_metrics=[{"method": "Subspace-Reg-LoRA-Visual-Port"}],
    )

    families = _build_anchor_residual_families(
        fedper_result=fedper,
        ditto_result=ditto,
        fedtree_result=fedtree,
        subspace_reg_result=subspace_reg,
        num_clients=2,
    )

    assert set(families) == {"FedPer", "Ditto", "FedTree", "SubspaceReg"}
    assert families["FedTree"][0] == "FedTreeLoRA-Visual-Port"
    assert families["SubspaceReg"][0] == "Subspace-Reg-LoRA-Visual-Port"
    assert families["SubspaceReg"][1] == ["subspace-global", "subspace-global"]


def test_anchor_residual_families_omit_unavailable_external_anchors():
    fedper = SimpleNamespace(client_adapters=["per"], per_client_metrics=[])
    ditto = SimpleNamespace(personal_adapters=["ditto"], per_client_metrics=[])

    families = _build_anchor_residual_families(
        fedper_result=fedper,
        ditto_result=ditto,
        fedtree_result=None,
        subspace_reg_result=None,
        num_clients=1,
    )

    assert set(families) == {"FedPer", "Ditto"}
