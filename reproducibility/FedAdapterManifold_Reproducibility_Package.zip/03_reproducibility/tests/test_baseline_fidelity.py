import unittest

from fedadaptermanifold.baseline_fidelity import BASELINE_FIDELITY, fidelity_by_run_key


class BaselineFidelityTests(unittest.TestCase):
    def test_named_external_claims_are_restricted_to_faithful_adaptations(self):
        manifest = fidelity_by_run_key()
        for key in [
            "Local-LoRA",
            "FedAvg-LoRA",
            "FedProx-LoRA",
            "Ditto-LoRA",
            "FedEx-LoRA",
            "FedSA-LoRA",
            "FedRot-LoRA",
            "LoRA-FAIR",
            "FedLEASE-OfficialPort",
        ]:
            self.assertTrue(manifest[key].external_method_claim_allowed)
        for key in [
            "FedAvg-Lift",
            "SCAFFOLD-LoRA",
            "pFedMe-LoRA",
            "FedPer-LoRA",
            "FedAMP-LoRA",
            "FedProto-LoRA",
            "Clustered-LoRA",
            "FedGeo-Agg",
            "Te-LoRA-Eq6-Audit",
        ]:
            self.assertFalse(manifest[key].external_method_claim_allowed)

    def test_all_run_keys_are_unique(self):
        manifest = fidelity_by_run_key()
        self.assertEqual(len(manifest), len(BASELINE_FIDELITY))

    def test_recent_direct_baselines_pin_source_revisions(self):
        manifest = fidelity_by_run_key()
        for key in ["FedEx-LoRA", "FedSA-LoRA", "FedRot-LoRA", "LoRA-FAIR", "FedLEASE-OfficialPort"]:
            self.assertTrue(manifest[key].source_url.startswith("https://github.com/"))
            self.assertEqual(len(manifest[key].source_revision), 40)


if __name__ == "__main__":
    unittest.main()
