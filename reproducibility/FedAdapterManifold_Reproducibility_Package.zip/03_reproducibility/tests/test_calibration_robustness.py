from __future__ import annotations

import importlib.util
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "calibration_robustness",
    ROOT / "scripts" / "analyze_calibration_robustness.py",
)
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_anchor_first_tie_break() -> None:
    scores = {name: 1.0 for name in MODULE.CANDIDATES}
    assert MODULE.select(scores) == MODULE.LOCAL


def test_symmetric_noise_ordering_boundary() -> None:
    rows = MODULE.symmetric_noise_bounds()
    below = [row for row in rows if row["symmetric_noise_rate"] == 0.60]
    assert below and all(row["ranking_preserved_in_expectation"] == 1 for row in below)
    assert all(row["risk_gap_contraction"] > 0 for row in below)


def test_margin_certificate_is_nonnegative() -> None:
    rows = [
        {
            "setting": "toy",
            "seed": "0",
            "client_id": "client_0",
            "selector_score_Local-LoRA": "0.5",
            "selector_score_FedGeo-Agg": "0.6",
            "selector_score_Subspace-Compatible": "0.7",
            "selector_score_FedAdapterManifold": "0.8",
        }
    ]
    result = MODULE.deterministic_margin_audit(rows)
    assert len(result) == 1
    assert result[0]["selected"] == MODULE.LOCAL
    assert result[0]["certified_relative_radius"] > 0
