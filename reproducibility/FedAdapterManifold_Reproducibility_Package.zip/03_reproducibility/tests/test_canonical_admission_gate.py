from scripts.analyze_canonical_admission_gate import (
    FAM,
    GEO,
    LOCAL,
    SUBSPACE,
    argmin,
    collect_units,
    confusion_rows,
    raw_subspace_units,
)


def test_anchor_first_tie_break() -> None:
    values = {LOCAL: 1.0, GEO: 1.0, SUBSPACE: 1.0, FAM: 1.0}
    assert argmin([LOCAL, GEO, SUBSPACE, FAM], values) == LOCAL


def test_canonical_replay_expected_counts() -> None:
    units, protocol = collect_units()
    assert len(units) == 150
    assert protocol["legacy_client_route_selected"] == 0

    raw = confusion_rows(
        raw_subspace_units(units),
        truth_field="raw_subspace_test_outcome",
        accepted_field="raw_subspace_accepted",
        audit="raw_subspace_candidate",
    )
    by_outcome = {row["actual_test_outcome"]: row for row in raw}
    assert (by_outcome["harmful"]["accepted"], by_outcome["harmful"]["rejected"]) == (
        1,
        124,
    )
    assert (
        by_outcome["beneficial"]["accepted"],
        by_outcome["beneficial"]["rejected"],
    ) == (13, 5)
