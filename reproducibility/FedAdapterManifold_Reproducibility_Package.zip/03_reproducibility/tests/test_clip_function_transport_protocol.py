from __future__ import annotations

import importlib.util
import inspect
import json
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
RUNNER_PATH = ROOT / "scripts" / "run_clip_vit_lora_federated_main.py"
SPEC = importlib.util.spec_from_file_location("clip_function_transport_runner", RUNNER_PATH)
assert SPEC is not None and SPEC.loader is not None
RUNNER = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = RUNNER
SPEC.loader.exec_module(RUNNER)


def test_function_transport_is_disabled_by_default():
    action = next(
        action
        for action in RUNNER.build_arg_parser()._actions
        if action.dest == "function_transport_admission"
    )
    assert action.default is False


def test_training_only_expert_ablation_is_disabled_by_default():
    action = next(
        action
        for action in RUNNER.build_arg_parser()._actions
        if action.dest == "function_transport_expert_ablation_only"
    )
    assert action.default is False


def test_run_provenance_persists_the_hashed_split_manifest(tmp_path):
    data_root = tmp_path / "data"
    sample_path = data_root / "Art" / "class_a" / "sample.png"
    sample_path.parent.mkdir(parents=True)
    sample_path.write_bytes(b"image")
    output = tmp_path / "run_provenance.json"
    config = RUNNER.Config(
        **vars(
            RUNNER.build_arg_parser().parse_args(
                ["--data-root", str(data_root), "--output-dir", str(tmp_path)]
            )
        )
    )
    clients = [
        {
            "client_id": 0,
            "train": [{"path": str(sample_path), "label": "class_a"}],
            "calibration": [],
            "test": [],
        }
    ]
    RUNNER._write_run_provenance(
        output,
        config=config,
        clients=clients,
        data_root=data_root,
        geometry_provider="FedGeo",
        torch=SimpleNamespace(__version__="test"),
    )
    record = json.loads(output.read_text(encoding="utf-8"))
    manifest = output.with_name(record["split_manifest_file"])
    assert manifest.exists()
    assert RUNNER.hashlib.sha256(manifest.read_bytes()).hexdigest() == record["split_manifest_sha256"]
    rows = json.loads(manifest.read_text(encoding="utf-8"))
    assert rows == [
        {"client_id": 0, "label": "class_a", "path": "Art/class_a/sample.png", "split": "train"}
    ]


def test_candidate_builder_accepts_training_data_only():
    signature = inspect.signature(RUNNER._build_function_transport_candidate)
    assert "calibration" not in signature.parameters
    assert "test" not in signature.parameters
    source = inspect.getsource(RUNNER._build_function_transport_candidate)
    assert 'client["train"]' in source
    assert 'client["calibration"]' not in source
    assert 'client["test"]' not in source
    assert "crossfit_convex_expert_screen" in source
    assert "crossfit_positive" in source


def test_crossfit_expert_builder_uses_three_unseen_folds():
    source = inspect.getsource(RUNNER._collect_crossfitted_function_experts)
    assert "num_folds=3" in source
    assert "fold_ids != heldout_fold" in source
    assert "fold_ids == heldout_fold" in source
    assert 'client["calibration"]' not in source
    assert 'client["test"]' not in source


def test_training_only_expert_ablation_isolates_fam_beyond_geo():
    labels = np.asarray([index % 2 for index in range(60)], dtype=np.int64)
    folds = np.asarray([index % 3 for index in range(60)], dtype=np.int64)

    def logits(margin):
        values = np.empty((labels.size, 2), dtype=np.float64)
        values[:, 0] = np.where(labels == 0, margin, -margin)
        values[:, 1] = -values[:, 0]
        return values

    local = logits(0.1)
    geo = logits(-0.1)
    fam = logits(2.0)
    prototype = logits(0.05)
    experts = np.stack([local, geo, fam, prototype], axis=1)
    prior = np.asarray([0.5, 1.0 / 6.0, 1.0 / 6.0, 1.0 / 6.0])
    full = RUNNER.crossfit_convex_expert_screen(
        experts,
        labels,
        folds,
        local,
        expert_prior=prior,
        kl_strength=0.01,
        fold_temperature=0.05,
    )

    audit = RUNNER._training_only_function_expert_ablation(
        experts,
        labels,
        folds,
        local,
        prior,
        kl_strength=0.01,
        fold_temperature=0.05,
        full_audit=full,
    )

    assert audit["fam_endpoint_gain_vs_geo"] > 0.0
    assert audit["fam_increment_given_geo"] > 0.0
    assert set(audit) == {
        "local_geo",
        "local_fam",
        "local_geo_fam",
        "all",
        "fam_endpoint_gain_vs_geo",
        "fam_increment_given_geo",
    }


def test_training_only_ablation_runner_cannot_receive_outer_splits():
    signature = inspect.signature(RUNNER._run_training_only_function_expert_ablation)
    assert "calibration" not in signature.parameters
    assert "test" not in signature.parameters
    source = inspect.getsource(RUNNER._run_training_only_function_expert_ablation)
    assert '["calibration"]' not in source
    assert '["test"]' not in source


def test_distillation_api_cannot_receive_outer_splits():
    signature = inspect.signature(RUNNER._train_function_distilled_client)
    assert "samples" in signature.parameters
    assert "teacher_logits" in signature.parameters
    assert "calibration" not in signature.parameters
    assert "test" not in signature.parameters


def test_all_receiver_decisions_are_frozen_before_test_phase():
    source = inspect.getsource(RUNNER._run_function_transport_replay)
    phase_boundary = source.index("for item in frozen")
    assert 'client["test"]' not in source[:phase_boundary]
    assert 'client["test"]' in source[phase_boundary:]
    assert "frozen.append" in source[:phase_boundary]


def test_stratified_fold_ids_are_deterministic_and_nonempty():
    samples = [
        {"path": f"sample_{index}.png", "label": "a" if index < 3 else "b"}
        for index in range(8)
    ]
    first = RUNNER._deterministic_stratified_fold_ids(samples, ["a", "b"], seed=17)
    second = RUNNER._deterministic_stratified_fold_ids(samples, ["a", "b"], seed=17)
    assert np.array_equal(first, second)
    assert set(first.tolist()) == {0, 1}


def test_prototype_routes_exclude_receiver_and_preserve_probability_mass():
    features = np.asarray([[1.0, 0.0], [0.0, 1.0]])
    prototypes = np.asarray(
        [
            [[1.0, 0.0], [0.0, 1.0]],
            [[1.0, 0.0], [0.0, 1.0]],
            [[-1.0, 0.0], [0.0, -1.0]],
        ]
    )
    mask = np.ones((3, 2), dtype=bool)
    routes, available = RUNNER._prototype_function_routes(
        features,
        prototypes,
        mask,
        compatibility=np.asarray([0.5, 0.4, 0.1]),
        receiver_idx=0,
        temperature=0.1,
    )
    assert available
    assert np.all(routes[:, 0] == 0.0)
    assert np.allclose(np.sum(routes, axis=1), 1.0)
    assert np.all(routes[:, 1] > routes[:, 2])


def test_argmax_preserving_projection_has_pointwise_top1_identity():
    anchor = np.asarray([[3.0, 1.0], [0.0, 2.0], [4.0, -1.0]])
    candidate = np.asarray([[1.0, 3.0], [0.5, 2.5], [5.0, -2.0]])

    projected = RUNNER._argmax_preserving_logits(anchor, candidate)

    assert np.array_equal(np.argmax(projected, axis=1), np.argmax(anchor, axis=1))
    assert np.array_equal(projected[0], anchor[0])
    assert np.array_equal(projected[1], candidate[1])


def test_endpoint_selector_does_not_call_accuracy_tie_noninferiority():
    anchor = {
        "accuracy": 0.5,
        "loss": 1.0,
        "correctness": [1, 0] * 8,
        "sample_losses": [1.0] * 16,
    }
    lower_loss_tie = {
        "accuracy": 0.5,
        "loss": 0.8,
        "correctness": [1, 0] * 8,
        "sample_losses": [0.8] * 16,
    }
    selected, audits = RUNNER._select_function_transport_endpoint(
        anchor,
        {
            "raw": ("class_changing", lower_loss_tie),
            "safe": ("argmax_preserving", lower_loss_tie),
        },
        certificate_alpha=0.05,
    )

    assert not audits["raw"]["certified"]
    assert audits["safe"]["certified"]
    assert audits["safe"]["accuracy_pointwise_preserved"]
    assert selected == "safe"


def test_endpoint_selector_can_certify_strict_accuracy_superiority():
    anchor = {
        "accuracy": 0.0,
        "loss": 1.0,
        "correctness": [0] * 10,
        "sample_losses": [1.0] * 10,
    }
    candidate = {
        "accuracy": 1.0,
        "loss": 0.5,
        "correctness": [1] * 10,
        "sample_losses": [0.5] * 10,
    }
    selected, audits = RUNNER._select_function_transport_endpoint(
        anchor,
        {"raw": ("class_changing", candidate)},
        certificate_alpha=0.05,
    )

    assert selected == "raw"
    assert audits["raw"]["certified"]
    assert audits["raw"]["certificate_basis"] == "strict_accuracy_superiority"
