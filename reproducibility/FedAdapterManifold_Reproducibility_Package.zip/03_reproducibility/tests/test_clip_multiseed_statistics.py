from __future__ import annotations

from scripts.aggregate_clip_vit_lora_multiseed import (
    certificate_safety_audit,
    certificate_safety_summary,
    one_sided_sign_flip_p_value,
    seed_clustered_paired_significance,
)


def test_seed_clustered_inference_uses_seed_means():
    rows = []
    for seed, gains in {0: [0.1, 0.3], 1: [0.2, 0.4]}.items():
        for client, gain in enumerate(gains):
            rows.extend(
                [
                    {"source_seed": seed, "client_id": client, "method": "M", "accuracy": 0.5 + gain},
                    {"source_seed": seed, "client_id": client, "method": "FedAvg-CLIP-LoRA", "accuracy": 0.5},
                ]
            )
    result = next(
        row
        for row in seed_clustered_paired_significance(rows)
        if row["method"] == "M" and row["baseline"] == "FedAvg-CLIP-LoRA"
    )
    assert result["independent_seed_clusters"] == 2
    assert result["client_seed_rows"] == 4
    assert abs(result["mean_accuracy_diff"] - 0.25) < 1e-12


def test_one_sided_seed_sign_flip_has_five_seed_resolution():
    assert one_sided_sign_flip_p_value([1.0] * 5) == 1.0 / 32.0


def test_certificate_audit_rejects_uncertified_nonlocal_deployment():
    per_client = [
        {"source_seed": 0, "client_id": 0, "method": "Local-CLIP-LoRA", "accuracy": 0.8},
        {
            "source_seed": 0,
            "client_id": 0,
            "method": "FedAdapterManifold-Tangent-Certified-CLIP-LoRA",
            "accuracy": 0.7,
        },
    ]
    selection = [
        {
            "source_seed": 0,
            "client_id": 0,
            "selection_protocol": "receiver_tangent_exact_certificate_v1",
            "screen_selected": True,
            "deployed_method": "FedGeo-Agg-CLIP-LoRA",
            "geo_certified_vs_local": False,
            "fam_certified_vs_local": False,
            "fam_certified_vs_geo": False,
        }
    ]
    rows = certificate_safety_audit(per_client, selection)
    summary = certificate_safety_summary(rows)[0]
    assert rows[0]["harmful_nonlocal_test_unit"]
    assert not rows[0]["required_edges_certified"]
    assert not summary["zero_harm_gate_passed"]
    assert not summary["certificate_integrity_passed"]


def test_certificate_audit_accepts_exact_local_fallback():
    per_client = [
        {"source_seed": 0, "client_id": 0, "method": "Local-CLIP-LoRA", "accuracy": 0.8},
        {
            "source_seed": 0,
            "client_id": 0,
            "method": "FedAdapterManifold-Tangent-Certified-CLIP-LoRA",
            "accuracy": 0.8,
        },
    ]
    selection = [
        {
            "source_seed": 0,
            "client_id": 0,
            "selection_protocol": "receiver_tangent_exact_certificate_v1",
            "screen_selected": True,
            "deployed_method": "Local-CLIP-LoRA",
        }
    ]
    rows = certificate_safety_audit(per_client, selection)
    summary = certificate_safety_summary(rows)[0]
    assert not rows[0]["nonlocal_deployed"]
    assert rows[0]["required_edges_certified"]
    assert summary["zero_harm_gate_passed"]
    assert summary["certificate_integrity_passed"]
