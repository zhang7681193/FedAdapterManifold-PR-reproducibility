from __future__ import annotations

import numpy as np
import pytest

from scripts.run_clip_vit_lora_federated_main import (
    _copy_lora_state,
    _crossfit_class_prototypes,
    _deterministic_semantic_modes,
    _fit_mode_utility_rule,
    _build_tangent_candidate_states,
    _class_label_map_sha256,
    _choose_tangent_candidate,
    _exact_one_sided_discordance_p,
    _paired_discordance_counts,
    _paired_dual_risk_certificate,
    _select_hierarchically_certified_deployment,
    _parse_tangent_alphas,
    _parse_utility_tangent_alphas,
    _prompt_labels,
    _prototype_route_assignments,
    _receiver_tangent_projection,
    _receiver_mode_tangent_states,
    _residual_lora_state,
    _select_loss_first_mode_tangent,
    _semantic_mode_assignments,
    _state_delta,
    _subspace_distance_matrix,
    _temporal_subspace_distance_matrix,
    _top_compatible_bank_source,
    _utility_state_routes,
    build_arg_parser,
)


def _rank_one_state(vector_left, vector_right):
    return [
        {
            "b": np.asarray(vector_left, dtype=np.float32).reshape(-1, 1),
            "a": np.asarray(vector_right, dtype=np.float32).reshape(1, -1),
            "scale": np.array(1.0, dtype=np.float64),
        }
    ]


def test_multiround_cli_is_explicit_and_defaults_to_one_round():
    parser = build_arg_parser()
    default = parser.parse_args(["--data-root", "data"])
    multi = parser.parse_args(
        ["--data-root", "data", "--communication-rounds", "5"]
    )
    assert default.communication_rounds == 1
    assert multi.communication_rounds == 5


def test_server_state_copies_do_not_alias_between_clients():
    original = _rank_one_state([1.0, 0.0], [1.0, 0.0])
    receiver_a = _copy_lora_state(original)
    receiver_b = _copy_lora_state(original)
    receiver_a[0]["a"][0, 0] = 99.0
    assert original[0]["a"][0, 0] == 1.0
    assert receiver_b[0]["a"][0, 0] == 1.0


def test_multiround_subspace_uses_received_to_trained_residual():
    received = _rank_one_state([1.0, 0.0], [1.0, 0.0])
    trained = _rank_one_state([1.0, 1.0], [1.0, 0.0])
    residual = _residual_lora_state(trained, received, rank=1)
    expected = np.asarray([[0.0, 0.0], [1.0, 0.0]])
    assert np.allclose(_state_delta(residual[0]), expected, atol=1e-6)


def test_temporal_projector_matches_single_round_subspace_geometry():
    states = [
        _rank_one_state([1.0, 0.0], [1.0, 0.0]),
        _rank_one_state([0.0, 1.0], [1.0, 0.0]),
    ]
    direct = _subspace_distance_matrix(states)
    temporal = _temporal_subspace_distance_matrix([states], decay=1.0)
    assert np.allclose(temporal, direct, atol=1e-8)


def test_temporal_projector_is_gauge_invariant_and_reduces_round_outlier():
    stable_a = _rank_one_state([1.0, 0.0], [1.0, 0.0])
    stable_b = _rank_one_state([-3.0, 0.0], [-2.0, 0.0])
    outlier = _rank_one_state([0.0, 1.0], [1.0, 0.0])
    reference = _rank_one_state([1.0, 0.0], [1.0, 0.0])
    history = [
        [stable_a, reference],
        [stable_b, reference],
        [outlier, reference],
    ]
    final_distance = _subspace_distance_matrix(history[-1])[0, 1]
    temporal_distance = _temporal_subspace_distance_matrix(history, decay=1.0)[0, 1]
    assert temporal_distance < final_distance


def test_temporal_projector_rejects_invalid_decay():
    states = [[_rank_one_state([1.0, 0.0], [1.0, 0.0])]]
    with pytest.raises(ValueError, match="decay"):
        _temporal_subspace_distance_matrix(states, decay=0.0)


def _certificate_details(local_correct, geo_correct, fam_correct, losses=(0.8, 0.7, 0.6)):
    def row(correctness, loss):
        return {
            "correctness": correctness,
            "accuracy": float(np.mean(correctness)),
            "loss": float(loss),
        }
    return {
        "Local-CLIP-LoRA": row(local_correct, losses[0]),
        "FedGeo-Agg-CLIP-LoRA": row(geo_correct, losses[1]),
        "FAM-screened": row(fam_correct, losses[2]),
    }


def test_exact_gate_does_not_replace_local_with_uncertified_geo():
    details = {
        "Local-CLIP-LoRA": {"accuracy": 0.70, "loss": 0.80, "correctness": [1, 0, 1, 0]},
        "FedGeo-Agg-CLIP-LoRA": {"accuracy": 0.75, "loss": 0.70, "correctness": [1, 1, 1, 0]},
        "FAM-screened": {"accuracy": 0.70, "loss": 0.60, "correctness": [1, 0, 1, 0]},
    }
    deployed, certificates = _select_hierarchically_certified_deployment(
        details, screened_method="FAM-screened", certificate_alpha=0.05 / 3.0
    )
    assert deployed == "Local-CLIP-LoRA"
    assert not certificates["geo_deployable"]


def test_exact_gate_admits_geo_after_six_clean_beneficial_flips():
    details = _certificate_details(
        [0] * 6 + [1] * 4,
        [1] * 10,
        [0] * 6 + [1] * 4,
        losses=(0.8, 0.7, 0.6),
    )
    deployed, certificates = _select_hierarchically_certified_deployment(
        details, screened_method="FAM-screened", certificate_alpha=0.05 / 3.0
    )
    assert deployed == "FedGeo-Agg-CLIP-LoRA"
    assert certificates["geo_deployable"]


def test_fam_must_beat_certified_geo_as_well_as_local():
    details = _certificate_details(
        [0] * 12 + [1] * 8,
        [1] * 6 + [0] * 6 + [1] * 8,
        [1] * 6 + [0] * 5 + [1] * 9,
        losses=(0.9, 0.8, 0.7),
    )
    deployed, certificates = _select_hierarchically_certified_deployment(
        details, screened_method="FAM-screened", certificate_alpha=0.05 / 3.0
    )
    assert certificates["geo_deployable"]
    assert certificates["fam_vs_local"]["certified"]
    assert not certificates["fam_vs_geo"]["certified"]
    assert not certificates["fam_deployable"]
    assert deployed == "FedGeo-Agg-CLIP-LoRA"


def test_receiver_tangent_projection_rejects_normal_component():
    receiver = _rank_one_state([1.0, 0.0], [1.0, 0.0])[0]
    normal = np.array([[0.0, 0.0], [0.0, 3.0]])
    tangent = np.array([[0.0, 2.0], [4.0, 0.0]])

    assert np.allclose(_receiver_tangent_projection(normal, receiver), 0.0)
    assert np.allclose(_receiver_tangent_projection(tangent, receiver), tangent)


def test_tangent_candidate_is_fixed_rank_and_drops_incompatible_energy():
    receiver = _rank_one_state([1.0, 0.0], [1.0, 0.0])
    anchor = _rank_one_state([1.0, 0.0], [1.0, 0.0])
    source = _rank_one_state([1.0, 1.0], [1.0, 1.0])

    candidates, manifest = _build_tangent_candidate_states(
        receiver_states=[receiver],
        anchor_states={"Local": [anchor]},
        source_states={"FAM": [source]},
        alphas=[0.5],
        rank=1,
    )

    method = "FAM-Tangent-Local-from-FAM-a0.5"
    delta = _state_delta(candidates[method][0][0])
    assert np.linalg.matrix_rank(delta, tol=1e-6) <= 1
    assert 0.0 < manifest[0]["tangent_energy_ratio"] < 1.0
    assert manifest[0]["admitted_residual_norm"] < manifest[0]["residual_norm"]


def test_mode_tangent_bank_keeps_self_anchor_and_projects_external_donor():
    receiver = _rank_one_state([1.0, 0.0], [1.0, 0.0])
    donor = _rank_one_state([1.0, 1.0], [1.0, 1.0])
    states, diagnostics = _receiver_mode_tangent_states(
        local_states=[receiver, donor], receiver_idx=0, alpha=0.5, rank=1
    )

    assert np.allclose(_state_delta(states[0][0]), _state_delta(receiver[0]))
    assert np.linalg.matrix_rank(_state_delta(states[1][0]), tol=1e-6) <= 1
    assert 0.0 < diagnostics[1]["tangent_energy_ratio"] < 1.0
    assert diagnostics[1]["admitted_residual_norm"] < diagnostics[1]["residual_norm"]


def test_mode_tangent_screen_is_loss_first_under_accuracy_guardrail():
    candidates = [
        {
            "alpha": 0.25,
            "screen_loss": 0.50,
            "screen_accuracy": 0.90,
            "screen_external_fraction": 0.25,
            "screen_eligible": True,
        },
        {
            "alpha": 0.5,
            "screen_loss": 0.42,
            "screen_accuracy": 0.895,
            "screen_external_fraction": 0.25,
            "screen_eligible": True,
        },
        {
            "alpha": 1.0,
            "screen_loss": 0.38,
            "screen_accuracy": 0.80,
            "screen_external_fraction": 0.25,
            "screen_eligible": False,
        },
    ]
    selected = _select_loss_first_mode_tangent(candidates)
    assert selected["alpha"] == 0.5


def test_mode_tangent_screen_still_fixes_one_candidate_when_none_is_eligible():
    candidates = [
        {
            "alpha": 0.25,
            "screen_loss": 0.55,
            "screen_accuracy": 0.90,
            "screen_external_fraction": 0.1,
            "screen_eligible": False,
        },
        {
            "alpha": 0.5,
            "screen_loss": 0.50,
            "screen_accuracy": 0.89,
            "screen_external_fraction": 0.1,
            "screen_eligible": False,
        },
    ]
    selected = _select_loss_first_mode_tangent(candidates)
    assert selected["alpha"] == 0.5


def test_crossfit_prototype_excludes_each_samples_own_fold():
    features = np.asarray([[1.0, 0.0], [0.0, 1.0], [1.0, 0.0], [0.0, 1.0]])
    prototypes, masks, folds = _crossfit_class_prototypes(
        features, labels=[0, 0, 1, 1], num_classes=2
    )
    assert folds.tolist() == [0, 1, 0, 1]
    assert masks.all()
    assert np.allclose(prototypes[0, 0], [0.0, 1.0])
    assert np.allclose(prototypes[1, 0], [1.0, 0.0])


def test_semantic_modes_and_assignments_are_deterministic():
    prototypes = np.asarray([[1.0, 0.0], [0.9, 0.1], [0.0, 1.0], [0.1, 0.9]])
    mapping, centroids = _deterministic_semantic_modes(
        prototypes, np.ones(4, dtype=bool), num_modes=2
    )
    modes, classes, _ = _semantic_mode_assignments(
        np.asarray([[1.0, 0.0], [0.0, 1.0]]),
        prototypes,
        np.ones(4, dtype=bool),
        mapping,
    )
    assert centroids.shape == (2, 2)
    assert modes[0] != modes[1]
    assert classes == [0, 2]


def test_mode_utility_rule_separates_safe_direction_from_positive_utility():
    local = {
        "correctness": [0, 0, 1, 1],
        "sample_losses": [2.0, 1.5, 0.2, 0.3],
        "true_margins": [-2.0, -1.0, 1.0, 2.0],
    }
    candidates = {
        (1, 1.0): {
            "correctness": [1, 1, 1, 1],
            "sample_losses": [0.4, 0.5, 0.1, 0.2],
            "true_margins": [1.0, 0.5, 1.5, 2.5],
        },
        (2, 1.0): {
            "correctness": [0, 0, 0, 1],
            "sample_losses": [2.1, 1.6, 1.0, 0.2],
            "true_margins": [-2.2, -1.2, -0.5, 2.1],
        },
    }
    rule, rows = _fit_mode_utility_rule(
        [0, 0, 1, 1], local, candidates, min_mode_samples=2, accuracy_tolerance=0.0
    )
    assert rule[0]["donor_client_id"] == 1
    assert rule[1]["donor_client_id"] == 1
    assert sum(bool(row["selected"]) for row in rows) == 2
    routes = _utility_state_routes(
        [0, 1, 2], rule, state_index={(1, 1.0): 1, (2, 1.0): 2}
    )
    assert routes == [1, 1, 0]


def test_tangent_alpha_protocol_is_validated_and_sorted():
    assert _parse_tangent_alphas("1,0.25,0.5,0.25") == [0.25, 0.5, 1.0]
    with pytest.raises(ValueError):
        _parse_tangent_alphas("0,0.5")
    with pytest.raises(ValueError):
        _parse_tangent_alphas("1.5")
    assert _parse_utility_tangent_alphas("4,0.5,2") == [0.5, 2.0, 4.0]


def test_target_first_admission_keeps_local_on_anchor_tie():
    rows = [
        {"candidate_method": "Local-CLIP-LoRA", "is_anchor": True, "calibration_accuracy": 0.9, "calibration_loss": 0.3},
        {"candidate_method": "FedGeo-Agg-CLIP-LoRA", "is_anchor": True, "calibration_accuracy": 0.9, "calibration_loss": 0.2},
        {"candidate_method": "FAM-Tangent-Local-from-FAM-a1", "is_anchor": False, "calibration_accuracy": 0.9, "calibration_loss": 0.1},
    ]
    selected, eligible = _choose_tangent_candidate(rows, min_loss_gain=0.0, accuracy_tolerance=0.0)
    assert selected["candidate_method"] == "Local-CLIP-LoRA"
    assert eligible == []


def test_target_first_admission_accepts_strict_accuracy_gain():
    rows = [
        {"candidate_method": "Local-CLIP-LoRA", "is_anchor": True, "calibration_accuracy": 0.9, "calibration_loss": 0.3},
        {"candidate_method": "FedGeo-Agg-CLIP-LoRA", "is_anchor": True, "calibration_accuracy": 0.85, "calibration_loss": 0.2},
        {"candidate_method": "FAM-Tangent-Local-from-FAM-a0.5", "is_anchor": False, "calibration_accuracy": 0.925, "calibration_loss": 0.25},
    ]
    selected, eligible = _choose_tangent_candidate(rows, min_loss_gain=0.01, accuracy_tolerance=0.0)
    assert selected["candidate_method"] == "FAM-Tangent-Local-from-FAM-a0.5"
    assert len(eligible) == 1


def test_top_compatible_bank_source_excludes_self():
    states = [
        _rank_one_state([1.0, 0.0], [1.0, 0.0]),
        _rank_one_state([0.0, 1.0], [1.0, 0.0]),
        _rank_one_state([1.0, 0.0], [0.0, 1.0]),
    ]
    weights = np.array([[0.8, 0.1, 0.1], [0.2, 0.7, 0.1], [0.1, 0.6, 0.3]])
    sources, donors = _top_compatible_bank_source(states, weights)
    assert donors == [1, 0, 1]
    assert sources[0] is states[1]


def test_exact_paired_certificate_counts_directional_flips():
    anchor = [1, 0, 0, 0, 0, 0]
    candidate = [1, 1, 1, 1, 1, 1]
    beneficial, harmful = _paired_discordance_counts(anchor, candidate)
    assert (beneficial, harmful) == (5, 0)
    assert _exact_one_sided_discordance_p(beneficial, harmful) == 1.0 / 32.0
    assert _exact_one_sided_discordance_p(3, 2) > 0.05
    assert _exact_one_sided_discordance_p(0, 0) == 1.0
    assert _exact_one_sided_discordance_p(5, 0) > 0.025
    assert _exact_one_sided_discordance_p(6, 0) <= 0.025


def test_dual_risk_certificate_admits_consistent_loss_progress_on_accuracy_tie():
    anchor = {
        "accuracy": 0.5,
        "loss": 1.0,
        "correctness": [1, 0] * 8,
        "sample_losses": [1.0] * 16,
    }
    candidate = {
        "accuracy": 0.5,
        "loss": 0.8,
        "correctness": [1, 0] * 8,
        "sample_losses": [0.8] * 16,
    }
    result = _paired_dual_risk_certificate(anchor, candidate, certificate_alpha=0.05)
    assert result["certified"]
    assert result["loss_certified"]
    assert not result["accuracy_certified"]
    assert result["certificate_basis"] == "proper_loss_with_accuracy_noninferiority"


def test_dual_risk_certificate_rejects_loss_gain_when_accuracy_falls():
    anchor = {
        "accuracy": 1.0,
        "loss": 1.0,
        "correctness": [1] * 16,
        "sample_losses": [1.0] * 16,
    }
    candidate = {
        "accuracy": 0.5,
        "loss": 0.8,
        "correctness": [1, 0] * 8,
        "sample_losses": [0.8] * 16,
    }
    result = _paired_dual_risk_certificate(anchor, candidate, certificate_alpha=0.05)
    assert not result["certified"]


def test_prototype_router_uses_class_anchor_and_compatibility_support():
    features = np.array([[1.0, 0.0], [0.0, 1.0]])
    prototypes = np.array(
        [
            [[0.8, 0.2], [0.2, 0.8]],
            [[1.0, 0.0], [0.0, 1.0]],
            [[1.0, 0.0], [0.0, 1.0]],
        ]
    )
    mask = np.ones((3, 2), dtype=bool)
    compatibility = np.array(
        [
            [0.4, 0.6, 0.0],
            [0.5, 0.5, 0.0],
            [0.0, 0.0, 1.0],
        ]
    )
    routes, classes, similarities, _ = _prototype_route_assignments(
        features=features,
        prototypes=prototypes,
        prototype_mask=mask,
        receiver_idx=0,
        compatibility_weights=compatibility,
        prior_weight=0.0,
    )
    assert routes == [1, 1]
    assert classes == [0, 1]
    assert similarities == [1.0, 1.0]


def test_prototype_router_can_construct_explicit_external_proposal():
    features = np.array([[1.0, 0.0]])
    prototypes = np.array([[[1.0, 0.0]], [[0.8, 0.2]]])
    mask = np.ones((2, 1), dtype=bool)
    compatibility = np.array([[0.9, 0.1], [0.1, 0.9]])
    routes, _, _, _ = _prototype_route_assignments(
        features=features,
        prototypes=prototypes,
        prototype_mask=mask,
        receiver_idx=0,
        compatibility_weights=compatibility,
        prior_weight=0.0,
        exclude_self=True,
    )
    assert routes == [1]


def test_prompt_label_map_decouples_folder_ids_from_semantic_prompts(tmp_path):
    path = tmp_path / "labels.json"
    path.write_text('{"0": "Alarm Clock", "10": "Chair"}', encoding="utf-8")
    assert _prompt_labels(["0", "10"], "", str(path)) == ["Alarm Clock", "Chair"]


def test_prompt_label_map_rejects_missing_classes(tmp_path):
    path = tmp_path / "labels.json"
    path.write_text('{"0": "Alarm Clock"}', encoding="utf-8")
    with pytest.raises(ValueError, match="missing"):
        _prompt_labels(["0", "10"], "", str(path))


def test_numeric_class_folders_require_explicit_semantic_prompts():
    with pytest.raises(ValueError, match="semantic object prompts"):
        _prompt_labels(["0", "1", "10"], "")


def test_class_label_map_digest_is_content_addressed(tmp_path):
    path = tmp_path / "labels.json"
    path.write_text('{"0": "Alarm Clock"}', encoding="utf-8")
    digest = _class_label_map_sha256(str(path))
    assert len(digest) == 64
    assert digest == _class_label_map_sha256(str(path))
