from __future__ import annotations

from types import SimpleNamespace

import numpy as np

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.decoupled_transport import (
    build_anchored_receiver_action_path_candidates,
    build_curvature_semantic_candidates,
    build_cumulative_semantic_candidates,
    build_receiver_action_candidates,
    fit_blockwise_action_endpoints,
    fit_residual_blockwise_action_endpoints,
    joint_path_comparison_count,
    receiver_action_blocks,
    receiver_action_energy_summary,
    screen_action_family_on_training_data,
    paired_discordance_upper_bound,
    stratified_paired_risk_upper_bound,
    select_fixed_intrinsic_candidate_pool,
    select_competitive_safe_blockwise_paths,
    select_disagreement_localized_routes,
    select_joint_empirical_bernstein_paths,
    select_split_certified_residual_paths,
    zero_discordance_required_sample_size,
)
from fedadaptermanifold.training import evaluate_adapter


def _adapter(delta: np.ndarray, rank: int = 2, name: str = "adapter") -> LoRAAdapter:
    return LoRAAdapter.from_delta(delta, rank=rank, alpha=float(rank), name=name)


def test_receiver_action_blocks_reconstruct_and_are_orthogonal():
    receiver = _adapter(np.diag([3.0, 2.0, 0.0, 0.0]), rank=2, name="receiver")
    donor = np.arange(16, dtype=np.float64).reshape(4, 4)
    blocks = receiver_action_blocks(receiver, donor)
    assert np.allclose(blocks.reconstructed, donor)
    values = [blocks.core, blocks.column_only, blocks.row_only, blocks.normal]
    for i, left in enumerate(values):
        for right in values[i + 1 :]:
            assert abs(float(np.vdot(left, right))) < 1e-9


def test_tangent_projection_removes_only_normal_component():
    receiver = _adapter(np.diag([2.0, 1.0, 0.0, 0.0]), rank=2, name="receiver")
    donor = np.ones((4, 4), dtype=np.float64)
    blocks = receiver_action_blocks(receiver, donor)
    assert np.allclose(donor - blocks.tangent, blocks.normal)
    candidates = build_receiver_action_candidates(
        [receiver],
        [_adapter(donor, rank=2, name="donor")],
        donor_weights=np.ones((1, 1), dtype=np.float64),
        target_ranks=[4],
    )
    assert np.allclose(candidates["core"][0].delta(), blocks.core)
    assert np.allclose(candidates["column"][0].delta(), blocks.column_anchored)
    assert np.allclose(candidates["row"][0].delta(), blocks.row_anchored)
    assert np.allclose(candidates["tangent"][0].delta(), blocks.tangent)
    assert np.allclose(candidates["full"][0].delta(), donor)


def test_anchored_action_path_transports_residual_from_local_endpoint():
    receiver_delta = np.diag([2.0, 1.0, 0.0, 0.0])
    donor_delta = np.asarray(
        [
            [3.0, 0.5, 0.0, 0.0],
            [0.0, 2.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0],
        ],
        dtype=np.float64,
    )
    receiver = _adapter(receiver_delta, rank=2, name="receiver")
    donor = _adapter(donor_delta, rank=4, name="donor")
    residual = donor_delta - receiver_delta
    blocks = receiver_action_blocks(receiver, residual)
    candidates = build_anchored_receiver_action_path_candidates(
        [receiver],
        [donor],
        donor_weights=np.ones((1, 1), dtype=np.float64),
        target_ranks=[4],
        modes=("core", "tangent", "full"),
        steps=(0.25, 1.0),
    )
    assert np.allclose(
        candidates["anchored-core-step-0.25"][0].delta(),
        receiver_delta + 0.25 * blocks.core,
    )
    assert np.allclose(
        candidates["anchored-tangent-step-1.00"][0].delta(),
        receiver_delta + blocks.tangent,
    )
    assert np.allclose(candidates["anchored-full-step-1.00"][0].delta(), donor_delta)


def test_anchored_action_path_rejects_zero_step_because_local_is_separate_anchor():
    receiver = _adapter(np.eye(2), rank=2, name="receiver")
    with np.testing.assert_raises_regex(ValueError, "steps"):
        build_anchored_receiver_action_path_candidates(
            [receiver],
            [receiver],
            donor_weights=np.ones((1, 1), dtype=np.float64),
            target_ranks=[2],
            steps=(0.0, 0.5),
        )


def test_receiver_action_energy_summary_is_additive_and_normalized():
    receiver = _adapter(np.diag([2.0, 1.0, 0.0, 0.0]), rank=2, name="receiver")
    donor = np.arange(16, dtype=np.float64).reshape(4, 4)
    summary = receiver_action_energy_summary(receiver, donor)
    block_sum = sum(
        summary[key]
        for key in ("core_energy", "column_only_energy", "row_only_energy", "normal_energy")
    )
    assert np.isclose(block_sum, summary["total_energy"])
    assert np.isclose(summary["tangent_energy"] + summary["normal_energy"], summary["total_energy"])
    assert np.isclose(summary["tangent_energy_ratio"] + summary["normal_energy_ratio"], 1.0)
    assert summary["receiver_rank"] == 2
    assert summary["donor_matrix_rank"] == np.linalg.matrix_rank(donor)


def test_cumulative_semantic_candidate_downweights_receiver_normal_stream():
    receiver = _adapter(np.diag([2.0, 1.0, 0.0, 0.0]), rank=2, name="receiver")
    compatible = np.diag([1.0, 1.0, 0.0, 0.0])
    normal = np.diag([0.0, 0.0, 1.0, 1.0])
    adapters, rows = build_cumulative_semantic_candidates(
        [receiver, receiver],
        [compatible, normal],
        algebraic_residual=np.zeros((4, 4), dtype=np.float64),
        prior_weights=np.ones(2),
        tau=0.1,
    )
    receiver_zero = [row for row in rows if row["receiver_index"] == 0]
    assert receiver_zero[0]["semantic_weight"] > receiver_zero[1]["semantic_weight"]
    assert np.isclose(sum(row["semantic_weight"] for row in receiver_zero), 1.0)
    assert adapters[0].rank == 4


def test_receiver_relative_semantic_candidate_reduces_to_local_on_self_only_graph():
    base = np.zeros((2, 2), dtype=np.float64)
    local_deltas = [
        np.asarray([[2.0, 0.0], [0.0, 0.0]]),
        np.asarray([[0.0, 0.0], [0.0, 3.0]]),
    ]
    receivers = [_adapter(delta, rank=1, name=f"receiver-{index}") for index, delta in enumerate(local_deltas)]
    clients = [
        SimpleNamespace(
            x_train=np.eye(2, dtype=np.float64),
            y_train=np.asarray([0, 1], dtype=np.int64),
            client_id=index,
            domain=f"d{index}",
        )
        for index in range(2)
    ]
    adapters, rows = build_curvature_semantic_candidates(
        training_clients=clients,
        base_weight=base,
        receivers=receivers,
        donor_cumulative_deltas=local_deltas,
        algebraic_residual=np.zeros_like(base),
        prior_weights=np.ones(2),
        graph=np.eye(2, dtype=np.float64),
        d_geo=np.zeros((2, 2), dtype=np.float64),
        label_distance=np.zeros((2, 2), dtype=np.float64),
        semantic_anchor_deltas=local_deltas,
        correction_scale=1.0,
        optimize_joint_mixture=False,
        target_ranks=[1, 1],
    )
    assert np.allclose(adapters[0].delta(), local_deltas[0])
    assert np.allclose(adapters[1].delta(), local_deltas[1])
    assert all(row["action_reference"] == "receiver_local" for row in rows)


def test_receiver_relative_semantic_candidate_matches_weighted_donor_action():
    base = np.zeros((2, 2), dtype=np.float64)
    local_deltas = [
        np.asarray([[2.0, 0.0], [0.0, 0.0]]),
        np.asarray([[0.0, 0.0], [0.0, 2.0]]),
    ]
    receivers = [_adapter(delta, rank=1, name=f"receiver-{index}") for index, delta in enumerate(local_deltas)]
    clients = [
        SimpleNamespace(
            x_train=np.eye(2, dtype=np.float64),
            y_train=np.asarray([0, 1], dtype=np.int64),
            client_id=index,
            domain=f"d{index}",
        )
        for index in range(2)
    ]
    scale = 0.25
    adapters, rows = build_curvature_semantic_candidates(
        training_clients=clients,
        base_weight=base,
        receivers=receivers,
        donor_cumulative_deltas=local_deltas,
        algebraic_residual=np.zeros_like(base),
        prior_weights=np.ones(2),
        graph=np.ones((2, 2), dtype=np.float64),
        d_geo=np.zeros((2, 2), dtype=np.float64),
        label_distance=np.zeros((2, 2), dtype=np.float64),
        lambda_subspace=0.0,
        lambda_geo=0.0,
        lambda_label=0.0,
        lambda_risk=0.0,
        semantic_anchor_deltas=local_deltas,
        correction_scale=scale,
        optimize_joint_mixture=False,
        target_ranks=[2, 2],
    )
    receiver_zero_rows = [row for row in rows if row["receiver_index"] == 0]
    weights = np.asarray([row["semantic_weight"] for row in receiver_zero_rows])
    expected = local_deltas[0] + scale * sum(
        float(weight) * (donor - local_deltas[0])
        for weight, donor in zip(weights, local_deltas)
    )
    assert np.allclose(adapters[0].delta(), expected)


def test_joint_path_comparison_count_covers_all_families_and_strengths():
    assert joint_path_comparison_count("0,0.25,0.5,0.75,1", 4) == 16


def test_zero_discordance_power_audit_exposes_small_sample_limit():
    required = zero_discordance_required_sample_size(0.02, 0.05, num_comparisons=2)
    assert required > 200


def test_zero_tolerance_power_audit_is_infinite_not_a_runtime_error():
    required = zero_discordance_required_sample_size(0.0, 0.05, num_comparisons=2)
    assert np.isinf(required)


def test_fixed_intrinsic_pool_selects_training_fixed_semantic_candidate():
    base = np.zeros((2, 1), dtype=np.float64)
    x = np.ones((40, 1), dtype=np.float64)
    y = np.zeros(40, dtype=np.int64)
    client = SimpleNamespace(x_train=x, y_train=y, x_test=x, y_test=y, client_id=0, domain="d0")
    anchor = _adapter(np.zeros((2, 1)), rank=1, name="anchor")
    full = _adapter(np.asarray([[-1.0], [1.0]]), rank=1, name="full")
    semantic = _adapter(np.asarray([[2.0], [-2.0]]), rank=1, name="semantic")
    result = select_fixed_intrinsic_candidate_pool(
        [client],
        [client],
        base,
        [anchor],
        {"fam_receiver_relative": [semantic], "full_control": [full]},
        candidate_priority=("local_anchor", "fam_receiver_relative", "full_control"),
    )
    assert result.per_client_metrics[0]["selected_transport_family"] == "fam_receiver_relative"
    assert result.per_client_metrics[0]["accuracy"] == 1.0
    selected = next(row for row in result.admission_rows if row["selected"])
    assert not selected["zero_discordance_power_sufficient"]
    assert not selected["test_used_for_selection"]


def test_fixed_intrinsic_pool_prefers_anchor_inside_declared_tie():
    base = np.zeros((2, 1), dtype=np.float64)
    x = np.ones((40, 1), dtype=np.float64)
    y = np.zeros(40, dtype=np.int64)
    client = SimpleNamespace(x_train=x, y_train=y, x_test=x, y_test=y, client_id=0, domain="d0")
    anchor = _adapter(np.asarray([[1.0], [-1.0]]), rank=1, name="anchor")
    near_tie = _adapter(np.asarray([[1.0001], [-1.0001]]), rank=1, name="near-tie")
    result = select_fixed_intrinsic_candidate_pool(
        [client],
        [client],
        base,
        [anchor],
        {"fam_receiver_relative": [near_tie]},
        tie_tolerance=1e-3,
    )
    assert result.per_client_metrics[0]["selected_transport_family"] == "local_anchor"


def test_pareto_intrinsic_pool_rejects_brier_harm_despite_better_log_loss():
    base = np.zeros((3, 1), dtype=np.float64)
    x = np.ones((40, 1), dtype=np.float64)
    y = np.zeros(40, dtype=np.int64)
    client = SimpleNamespace(x_train=x, y_train=y, x_test=x, y_test=y, client_id=0, domain="d0")
    anchor = _adapter(np.log(np.asarray([[0.60], [0.20], [0.20]])), rank=1, name="anchor")
    candidate = _adapter(np.log(np.asarray([[0.61], [0.39], [1e-8]])), rank=1, name="candidate")
    result = select_fixed_intrinsic_candidate_pool(
        [client],
        [client],
        base,
        [anchor],
        {"fam_receiver_relative": [candidate]},
        selection_policy="pareto",
    )
    assert result.per_client_metrics[0]["selected_transport_family"] == "local_anchor"
    candidate_row = next(
        row for row in result.admission_rows if row["candidate_family"] == "fam_receiver_relative"
    )
    assert candidate_row["log_loss_gain_vs_anchor"] > 0.0
    assert candidate_row["brier_difference_vs_anchor"] > 0.0
    assert not candidate_row["pareto_admissible"]


def test_pareto_intrinsic_pool_admits_candidate_improving_all_risks():
    base = np.zeros((3, 1), dtype=np.float64)
    x = np.ones((40, 1), dtype=np.float64)
    y = np.zeros(40, dtype=np.int64)
    client = SimpleNamespace(x_train=x, y_train=y, x_test=x, y_test=y, client_id=0, domain="d0")
    anchor = _adapter(np.log(np.asarray([[0.60], [0.20], [0.20]])), rank=1, name="anchor")
    candidate = _adapter(np.log(np.asarray([[0.80], [0.10], [0.10]])), rank=1, name="candidate")
    result = select_fixed_intrinsic_candidate_pool(
        [client],
        [client],
        base,
        [anchor],
        {"fam_receiver_relative": [candidate]},
        selection_policy="pareto",
    )
    assert result.per_client_metrics[0]["selected_transport_family"] == "fam_receiver_relative"
    selected = next(row for row in result.admission_rows if row["selected"])
    assert selected["pareto_admissible"]
    assert selected["log_loss_gain_vs_anchor"] > 0.0
    assert selected["brier_difference_vs_anchor"] < 0.0


def test_target_pareto_requires_strict_primary_error_improvement():
    base = np.zeros((3, 1), dtype=np.float64)
    x = np.ones((40, 1), dtype=np.float64)
    y = np.zeros(40, dtype=np.int64)
    client = SimpleNamespace(x_train=x, y_train=y, x_test=x, y_test=y, client_id=0, domain="d0")
    anchor = _adapter(np.log(np.asarray([[0.60], [0.20], [0.20]])), rank=1, name="anchor")
    calibrated = _adapter(np.log(np.asarray([[0.80], [0.10], [0.10]])), rank=1, name="calibrated")
    result = select_fixed_intrinsic_candidate_pool(
        [client],
        [client],
        base,
        [anchor],
        {"fam_receiver_relative": [calibrated]},
        selection_policy="target_pareto",
    )
    assert result.per_client_metrics[0]["selected_transport_family"] == "local_anchor"


def test_target_pareto_admits_strict_classification_improvement():
    base = np.zeros((2, 1), dtype=np.float64)
    x = np.tile(np.asarray([[1.0], [-1.0]]), (20, 1))
    y = np.tile(np.asarray([0, 1], dtype=np.int64), 20)
    client = SimpleNamespace(x_train=x, y_train=y, x_test=x, y_test=y, client_id=0, domain="d0")
    anchor = _adapter(np.zeros((2, 1)), rank=1, name="anchor")
    candidate = _adapter(np.asarray([[1.0], [-1.0]]), rank=1, name="candidate")
    result = select_fixed_intrinsic_candidate_pool(
        [client],
        [client],
        base,
        [anchor],
        {"fam_receiver_relative": [candidate]},
        selection_policy="target_pareto",
    )
    assert result.per_client_metrics[0]["selected_transport_family"] == "fam_receiver_relative"
    selected = next(row for row in result.admission_rows if row["selected"])
    assert selected["target_pareto_admissible"]
    assert selected["error_difference_vs_anchor"] < 0.0


def test_training_screen_selects_family_without_calibration_data():
    base = np.zeros((2, 2), dtype=np.float64)
    x = np.eye(2, dtype=np.float64)
    y = np.asarray([0, 1], dtype=np.int64)
    client = SimpleNamespace(x_train=x, y_train=y, client_id="c0", domain="d0")
    anchor = _adapter(np.eye(2), rank=2, name="anchor")
    helpful = _adapter(3.0 * np.eye(2), rank=2, name="helpful")
    harmful = _adapter(-np.eye(2), rank=2, name="harmful")
    endpoints, rows = screen_action_family_on_training_data(
        [client],
        base,
        [anchor],
        {"helpful": [helpful], "harmful": [harmful]},
        ranks=[2],
        path=[0.0, 0.5, 1.0],
    )
    selected = [row for row in rows if row["selected_family"]]
    assert len(selected) == 1
    assert selected[0]["transport_family"] == "helpful"
    assert np.allclose(endpoints[0].delta(), helpful.delta())


def test_blockwise_fit_removes_harmful_cross_axis_blocks():
    base = np.zeros((2, 2), dtype=np.float64)
    x = np.eye(2, dtype=np.float64)
    y = np.asarray([0, 1], dtype=np.int64)
    client = SimpleNamespace(x_train=x, y_train=y, client_id="c0", domain="d0")
    receiver = _adapter(np.asarray([[1.0, 0.0], [0.0, 0.0]]), rank=1, name="receiver")
    source = _adapter(np.asarray([[2.0, 4.0], [4.0, 2.0]]), rank=2, name="source")

    fitted, controls, rows = fit_blockwise_action_endpoints(
        [client],
        base,
        [receiver],
        {"full": [source]},
        ranks=[2],
    )

    selected = next(row for row in rows if row["selected_source"])
    assert selected["column_only_coefficient"] < 1e-5
    assert selected["row_only_coefficient"] < 1e-5
    assert selected["core_coefficient"] > 1.0 - 1e-5
    assert selected["normal_coefficient"] > 1.0 - 1e-5
    assert evaluate_adapter(x, y, base, fitted[0])["loss"] < evaluate_adapter(x, y, base, source)["loss"]
    np.testing.assert_allclose(controls[0].delta(), source.delta(), atol=1e-12)


def test_residual_blockwise_fit_keeps_center_and_beats_scalar_control():
    base = np.zeros((2, 2), dtype=np.float64)
    x = np.eye(2, dtype=np.float64)
    y = np.asarray([0, 1], dtype=np.int64)
    client = SimpleNamespace(x_train=x, y_train=y, client_id="c0", domain="d0")
    receiver = _adapter(np.asarray([[1.0, 0.0], [0.0, 0.0]]), rank=1, name="receiver")
    center = _adapter(np.asarray([[1.0, 0.0], [0.0, 1.0]]), rank=2, name="center")
    # The diagonal residual is useful, while the off-diagonal residual is
    # harmful. A scalar gate cannot separate them; receiver blocks can.
    source = _adapter(np.asarray([[3.0, 4.0], [4.0, 3.0]]), rank=2, name="semantic")

    fitted, scalar, rows = fit_residual_blockwise_action_endpoints(
        [client],
        base,
        [receiver],
        [center],
        {"semantic": [source]},
        ranks=[2],
    )

    row = rows[0]
    assert row["training_gain_vs_center"] > 0.0
    assert row["blockwise_gain_vs_scalar"] > 0.0
    assert evaluate_adapter(x, y, base, fitted[0])["loss"] < evaluate_adapter(x, y, base, scalar[0])["loss"]
    assert np.linalg.norm(fitted[0].delta() - center.delta()) > 0.0


def test_split_certified_selector_uses_disjoint_calibration_and_admits_residual():
    base = np.zeros((2, 2), dtype=np.float64)
    x = np.tile(np.eye(2, dtype=np.float64), (100, 1))
    y = np.tile(np.asarray([0, 1], dtype=np.int64), 100)
    client = SimpleNamespace(
        x_train=x,
        y_train=y,
        x_test=x,
        y_test=y,
        client_id="c0",
        domain="d0",
    )
    anchor = _adapter(np.zeros((2, 2), dtype=np.float64), rank=2, name="anchor")
    full = _adapter(np.eye(2, dtype=np.float64), rank=2, name="full")
    residual = _adapter(2.0 * np.eye(2, dtype=np.float64), rank=2, name="residual")

    result, control = select_split_certified_residual_paths(
        [client],
        [client],
        base,
        [anchor],
        [full],
        [residual],
        ranks=[2],
        path=[0.0, 0.5, 1.0],
        risk_tolerance=0.2,
        competitive_tolerance=0.2,
        selection_fraction=0.5,
    )

    assert result.per_client_metrics[0]["selected_transport_family"] == "residual_blockwise"
    assert control.per_client_metrics[0]["selected_transport_family"] == "full"
    row = result.admission_rows[0]
    assert row["selection_calibration_size"] == 100
    assert row["certification_calibration_size"] == 100
    assert row["selector_num_comparisons"] == 3


def test_joint_path_counts_all_endpoint_comparisons_and_falls_back_safely():
    base = np.zeros((2, 2), dtype=np.float64)
    x = np.eye(2, dtype=np.float64)
    y = np.asarray([0, 1], dtype=np.int64)
    client = SimpleNamespace(x_train=x, y_train=y, x_test=x, y_test=y, client_id=0, domain="d0")
    anchor = _adapter(np.eye(2), rank=2, name="anchor")
    harmful = _adapter(-np.eye(2), rank=2, name="harmful")
    result = select_joint_empirical_bernstein_paths(
        [client],
        [client],
        base,
        [anchor],
        {"core": [harmful], "tangent": [harmful]},
        ranks=[2],
        path=[0.0, 0.5, 1.0],
        delta=0.05,
    )
    selected = [row for row in result.admission_rows if row["selected"]]
    assert len(selected) == 1
    assert selected[0]["transport_family"] == "anchor"
    assert selected[0]["selector_num_comparisons"] == 4
    assert np.allclose(result.client_adapters[0].delta(), anchor.delta())


def test_paired_discordance_bound_certifies_clear_benefit():
    anchor = np.asarray([1.0] * 30 + [0.0] * 70)
    candidate = np.asarray([0.0] * 30 + [0.0] * 70)
    mean, _, upper, details = paired_discordance_upper_bound(candidate, anchor, delta=0.05)
    assert mean == -0.3
    assert upper < 0.0
    assert details["benefit_discordances"] == 30
    assert details["harm_discordances"] == 0


def test_paired_discordance_bound_does_not_certify_empirical_tie():
    anchor = np.zeros(100, dtype=np.float64)
    candidate = np.zeros(100, dtype=np.float64)
    _, _, upper, details = paired_discordance_upper_bound(candidate, anchor, delta=0.05)
    assert upper > 0.0
    assert details["total_discordances"] == 0


def test_stratified_bound_without_strata_matches_marginal_bound():
    anchor = np.asarray([1.0] * 30 + [0.0] * 70)
    candidate = np.zeros(100, dtype=np.float64)
    marginal = paired_discordance_upper_bound(
        candidate,
        anchor,
        delta=0.05,
        num_comparisons=3,
    )
    stratified = stratified_paired_risk_upper_bound(
        candidate,
        anchor,
        strata=None,
        delta=0.05,
        num_comparisons=3,
    )
    assert np.allclose(stratified[:3], marginal[:3])
    assert not stratified[3]["stratified"]


def test_stratified_bound_is_worst_simultaneous_conditional_bound():
    anchor = np.asarray([1.0] * 80 + [0.0] * 120)
    candidate = np.asarray([0.0] * 80 + [0.0] * 80 + [1.0] * 40)
    strata = np.asarray([0] * 100 + [1] * 100)
    result = stratified_paired_risk_upper_bound(
        candidate,
        anchor,
        strata=strata,
        delta=0.05,
        num_comparisons=2,
        min_stratum_size=16,
    )
    expected = []
    for group in (0, 1):
        mask = strata == group
        expected.append(
            paired_discordance_upper_bound(
                candidate[mask],
                anchor[mask],
                delta=0.05,
                num_comparisons=4,
            )[2]
        )
    assert np.isclose(result[2], max(expected))
    assert result[3]["stratum_count"] == 2


def test_stratified_bound_forces_fallback_for_undersampled_stratum():
    anchor = np.asarray([1.0] * 40 + [0.0] * 10)
    candidate = np.zeros(50, dtype=np.float64)
    strata = np.asarray([0] * 40 + [1] * 10)
    _, _, upper, details = stratified_paired_risk_upper_bound(
        candidate,
        anchor,
        strata=strata,
        delta=0.05,
        min_stratum_size=16,
    )
    assert np.isinf(upper)
    assert details["undersampled_strata"] == 1


def test_stratified_bound_forces_fallback_for_absent_expected_stratum():
    anchor = np.ones(40, dtype=np.float64)
    candidate = np.zeros(40, dtype=np.float64)
    strata = np.zeros(40, dtype=np.int64)
    _, _, upper, details = stratified_paired_risk_upper_bound(
        candidate,
        anchor,
        strata=strata,
        expected_strata=np.asarray([0, 1]),
        delta=0.05,
        min_stratum_size=1,
    )
    assert np.isinf(upper)
    assert details["undersampled_strata"] == 1


def test_stratified_bound_blocks_marginal_gain_with_harmed_subpopulation():
    anchor = np.concatenate([np.ones(500), np.zeros(500), np.zeros(100)])
    candidate = np.concatenate([np.zeros(500), np.zeros(500), np.ones(100)])
    strata = np.asarray([0] * 1000 + [1] * 100)
    marginal_upper = paired_discordance_upper_bound(
        candidate,
        anchor,
        delta=0.05,
    )[2]
    robust_upper = stratified_paired_risk_upper_bound(
        candidate,
        anchor,
        strata=strata,
        delta=0.05,
        min_stratum_size=16,
    )[2]
    assert marginal_upper < 0.0
    assert robust_upper > 0.0


def test_competitive_safe_selector_admits_clear_blockwise_dominance():
    base = np.zeros((2, 2), dtype=np.float64)
    x_first = np.repeat(np.asarray([[1.0, 0.0]]), 100, axis=0)
    x_second = np.repeat(np.asarray([[0.0, 1.0]]), 100, axis=0)
    x = np.vstack([x_first, x_second])
    y = np.ones(200, dtype=np.int64)
    client = SimpleNamespace(x_train=x, y_train=y, x_test=x, y_test=y, client_id=0, domain="d0")

    def from_binary_score(score, name):
        score = np.asarray(score, dtype=np.float64)
        return _adapter(np.vstack([score / 2.0, -score / 2.0]), rank=2, name=name)

    anchor = from_binary_score([1.0, 1.0], "anchor")
    full = from_binary_score([-1.0, 1.0], "full")
    blockwise = from_binary_score([-1.0, -1.0], "blockwise")
    result, control = select_competitive_safe_blockwise_paths(
        [client],
        [client],
        base,
        [anchor],
        [full],
        [blockwise],
        ranks=[2],
        path=[0.0, 1.0],
    )
    assert control.per_client_metrics[0]["accuracy"] == 0.5
    assert result.per_client_metrics[0]["accuracy"] == 1.0
    assert result.per_client_metrics[0]["selected_transport_family"] == "blockwise"
    selected = next(row for row in result.admission_rows if row["selected"])
    assert selected["certified_competitive"]
    assert selected["selector_num_comparisons"] == 3


def test_competitive_safe_selector_rejects_one_example_advantage(monkeypatch):
    base = np.zeros((2, 2), dtype=np.float64)
    x = np.ones((100, 1), dtype=np.float64)
    y = np.zeros(100, dtype=np.int64)
    client = SimpleNamespace(x_train=x, y_train=y, x_test=x, y_test=y, client_id=0, domain="d0")
    anchor = _adapter(np.zeros((2, 1)), rank=1, name="anchor")
    full = _adapter(np.ones((2, 1)), rank=1, name="full")
    blockwise = _adapter(2.0 * np.ones((2, 1)), rank=1, name="blockwise")
    anchor_errors = np.r_[np.ones(20), np.zeros(80)]
    full_errors = np.r_[np.zeros(10), np.ones(10), np.zeros(80)]
    blockwise_errors = np.r_[np.zeros(11), np.ones(9), np.zeros(80)]

    def errors(_x, _y, _base, adapter):
        if "blockwise" in adapter.name:
            return blockwise_errors.copy()
        if "full" in adapter.name:
            return full_errors.copy()
        return anchor_errors.copy()

    def losses(_x, _y, _base, adapter):
        return errors(_x, _y, _base, adapter)

    def metrics(_x, _y, _base, adapter):
        vector = errors(_x, _y, _base, adapter)
        return {"accuracy": float(1.0 - vector.mean()), "loss": float(vector.mean())}

    monkeypatch.setattr("fedadaptermanifold.decoupled_transport.evaluate_adapter_error_vector", errors)
    monkeypatch.setattr("fedadaptermanifold.decoupled_transport.evaluate_adapter_loss_vector", losses)
    monkeypatch.setattr("fedadaptermanifold.decoupled_transport.evaluate_adapter", metrics)
    result, control = select_competitive_safe_blockwise_paths(
        [client],
        [client],
        base,
        [anchor],
        [full],
        [blockwise],
        ranks=[1],
        path=[0.0, 1.0],
    )
    assert control.per_client_metrics[0]["accuracy"] == 0.9
    assert result.per_client_metrics[0]["accuracy"] == 0.9
    assert result.per_client_metrics[0]["selected_transport_family"] == "full_control"
    block_record = next(
        row for row in result.admission_rows if row["transport_family"] == "blockwise"
    )
    assert block_record["benefit_discordances_vs_full"] == 1
    assert not block_record["certified_competitive"]


def test_disagreement_router_admits_large_localized_benefit():
    base = np.zeros((2, 2), dtype=np.float64)
    x_class_one = np.repeat(np.asarray([[1.0, 0.0]]), 150, axis=0)
    x_class_zero = np.repeat(np.asarray([[0.0, 1.0]]), 50, axis=0)
    x = np.vstack([x_class_one, x_class_zero])
    y = np.r_[np.ones(150, dtype=np.int64), np.zeros(50, dtype=np.int64)]
    client = SimpleNamespace(x_train=x, y_train=y, x_test=x, y_test=y, client_id=0, domain="d0")

    def from_binary_score(score, name):
        score = np.asarray(score, dtype=np.float64)
        return _adapter(np.vstack([score / 2.0, -score / 2.0]), rank=2, name=name)

    anchor = from_binary_score([1.0, 1.0], "anchor")
    full = from_binary_score([-1.0, -1.0], "full")
    blockwise = from_binary_score([-1.0, 1.0], "blockwise")
    _, control = select_competitive_safe_blockwise_paths(
        [client], [client], base, [anchor], [full], [blockwise], ranks=[2], path=[0.0, 1.0]
    )
    routed = select_disagreement_localized_routes(
        [client],
        [client],
        [client],
        base,
        [anchor],
        [full],
        [blockwise],
        control,
        ranks=[2],
        path=[0.0, 1.0],
    )
    assert control.per_client_metrics[0]["accuracy"] == 0.75
    assert routed.per_client_metrics[0]["accuracy"] == 1.0
    assert routed.per_client_metrics[0]["selected_transport_family"] == "disagreement_blockwise"
    assert routed.per_client_metrics[0]["route_fraction"] == 0.25
    selected = next(row for row in routed.admission_rows if row["selected"])
    assert selected["benefit_discordances_vs_full"] == 50
    assert selected["harm_discordances_vs_full"] == 0
    assert selected["selector_num_comparisons"] == 4

    training_fixed = select_disagreement_localized_routes(
        [client],
        [client],
        [client],
        base,
        [anchor],
        [full],
        [blockwise],
        control,
        ranks=[2],
        path=[0.0, 1.0],
        candidate_search_mode="training-fixed",
    )
    assert training_fixed.per_client_metrics[0]["accuracy"] == 1.0
    assert training_fixed.per_client_metrics[0]["candidate_search_mode"] == "training-fixed"
    training_selected = next(row for row in training_fixed.admission_rows if row["selected"])
    assert training_selected["selector_num_comparisons"] == 1
    assert training_selected["candidate_search_mode"] == "training-fixed"


def test_disagreement_router_rejects_single_localized_benefit():
    base = np.zeros((2, 2), dtype=np.float64)
    x_class_one = np.repeat(np.asarray([[1.0, 0.0]]), 99, axis=0)
    x_class_zero = np.asarray([[0.0, 1.0]])
    x = np.vstack([x_class_one, x_class_zero])
    y = np.r_[np.ones(99, dtype=np.int64), np.zeros(1, dtype=np.int64)]
    client = SimpleNamespace(x_train=x, y_train=y, x_test=x, y_test=y, client_id=0, domain="d0")

    def from_binary_score(score, name):
        score = np.asarray(score, dtype=np.float64)
        return _adapter(np.vstack([score / 2.0, -score / 2.0]), rank=2, name=name)

    anchor = from_binary_score([1.0, 1.0], "anchor")
    full = from_binary_score([-1.0, -1.0], "full")
    blockwise = from_binary_score([-1.0, 1.0], "blockwise")
    _, control = select_competitive_safe_blockwise_paths(
        [client], [client], base, [anchor], [full], [blockwise], ranks=[2], path=[0.0, 1.0]
    )
    routed = select_disagreement_localized_routes(
        [client],
        [client],
        [client],
        base,
        [anchor],
        [full],
        [blockwise],
        control,
        ranks=[2],
        path=[0.0, 1.0],
    )
    assert control.per_client_metrics[0]["accuracy"] == 0.99
    assert routed.per_client_metrics[0]["accuracy"] == 0.99
    assert routed.per_client_metrics[0]["selected_transport_family"] == "full_control"
    best_route = min(
        (
            row
            for row in routed.admission_rows
            if row["transport_family"] == "disagreement_blockwise"
        ),
        key=lambda row: row["paired_error_difference_vs_full"],
    )
    assert best_route["benefit_discordances_vs_full"] == 1
    assert not best_route["certified_competitive"]


def test_direct_anchor_router_spends_full_control_safety_budget():
    base = np.zeros((2, 2), dtype=np.float64)
    x_primary = np.repeat(np.asarray([[1.0, 0.0]]), 150, axis=0)
    x_disagreement = np.repeat(np.asarray([[0.0, 1.0]]), 18, axis=0)
    x = np.vstack([x_primary, x_disagreement])
    y = np.r_[
        np.ones(150, dtype=np.int64),
        np.ones(3, dtype=np.int64),
        np.zeros(15, dtype=np.int64),
    ]
    client = SimpleNamespace(x_train=x, y_train=y, x_test=x, y_test=y, client_id=0, domain="d0")

    def from_binary_score(score, name):
        score = np.asarray(score, dtype=np.float64)
        return _adapter(np.vstack([score / 2.0, -score / 2.0]), rank=2, name=name)

    anchor = from_binary_score([1.0, 1.0], "anchor")
    full = from_binary_score([-1.0, -1.0], "full")
    blockwise = from_binary_score([-1.0, 1.0], "blockwise")
    _, control = select_competitive_safe_blockwise_paths(
        [client], [client], base, [anchor], [full], [blockwise], ranks=[2], path=[0.0, 1.0]
    )
    quantiles = tuple(np.linspace(0.0, 1.0, 64))
    competitive = select_disagreement_localized_routes(
        [client],
        [client],
        [client],
        base,
        [anchor],
        [full],
        [blockwise],
        control,
        ranks=[2],
        path=[0.0, 1.0],
        quantiles=quantiles,
    )
    direct = select_disagreement_localized_routes(
        [client],
        [client],
        [client],
        base,
        [anchor],
        [full],
        [blockwise],
        control,
        ranks=[2],
        path=[0.0, 1.0],
        quantiles=quantiles,
        safety_reference="anchor",
        method="FedAdapterManifold-DirectAnchorRoute",
    )
    dual = select_disagreement_localized_routes(
        [client],
        [client],
        [client],
        base,
        [anchor],
        [full],
        [blockwise],
        control,
        ranks=[2],
        path=[0.0, 1.0],
        quantiles=quantiles,
        safety_reference="both",
        method="FedAdapterManifold-DualCertifiedRoute",
    )

    assert competitive.per_client_metrics[0]["selected_transport_family"] == "full_control"
    assert direct.per_client_metrics[0]["selected_transport_family"] == "disagreement_blockwise"
    assert direct.per_client_metrics[0]["accuracy"] > competitive.per_client_metrics[0]["accuracy"]
    assert direct.per_client_metrics[0]["accuracy_gain_vs_full"] > 0.0
    assert dual.per_client_metrics[0]["selected_transport_family"] == "full_control"
    selected = next(row for row in direct.admission_rows if row["selected"])
    assert selected["selector_num_comparisons"] == 65
    assert selected["certified_anchor_safe"]
    assert not selected["certified_competitive"]
    assert selected["anchor_risk_upper_bound"] < 0.0
    assert selected["competitive_risk_upper_bound"] > 0.0
