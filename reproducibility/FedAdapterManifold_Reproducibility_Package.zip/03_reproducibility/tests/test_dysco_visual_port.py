from types import SimpleNamespace

import numpy as np

from fedadaptermanifold.recent_lora_baselines import (
    dysco_insensitive_basis,
    dysco_merge_insensitive_bases,
    run_dysco_visual_port,
)


def test_insensitive_basis_selects_smallest_activation_eigenspace():
    features = np.diag([1.0, 2.0, 3.0, 4.0])
    basis = dysco_insensitive_basis(features, rank=2)
    projector = basis.T @ basis
    expected = np.diag([1.0, 1.0, 0.0, 0.0])
    assert np.allclose(projector, expected, atol=1e-12)
    assert np.allclose(basis @ basis.T, np.eye(2), atol=1e-12)


def test_merge_basis_maximizes_other_client_projector_overlap():
    e = np.eye(4, dtype=np.float64)
    bases = [e[[0]], e[[1]], e[[1]]]
    merged = dysco_merge_insensitive_bases(bases, receiver_index=0, rank=1)
    assert np.allclose(merged.T @ merged, np.diag([0.0, 1.0, 0.0, 0.0]), atol=1e-12)


def test_dysco_visual_port_runs_cumulative_roundwise_protocol():
    rng = np.random.default_rng(7)
    clients = []
    teacher = rng.normal(size=(3, 6))
    for index in range(4):
        x_train = rng.normal(loc=0.15 * index, size=(24, 6))
        x_test = rng.normal(loc=0.15 * index, size=(12, 6))
        clients.append(
            SimpleNamespace(
                x_train=x_train,
                y_train=np.argmax(x_train @ teacher.T, axis=1),
                x_test=x_test,
                y_test=np.argmax(x_test @ teacher.T, axis=1),
                client_id=f"client_{index}",
                domain=f"domain_{index}",
            )
        )
    result = run_dysco_visual_port(
        clients,
        np.zeros((3, 6), dtype=np.float64),
        ranks=2,
        rounds=2,
        local_epochs=1,
        lr=0.1,
        batch_size=8,
        seed=0,
        dataset="synthetic",
        heterogeneity_setting="domain",
    )
    assert len(result.client_adapters) == 4
    assert len(result.per_client_metrics) == 4
    assert len(result.round_history) == 8
    assert {row["logical_deployment_rank"] for row in result.per_client_metrics} == {4}
    assert max(row["merged_basis_orthogonality_error"] for row in result.round_history) < 1e-10
    assert all(np.isfinite(float(row["accuracy"])) for row in result.per_client_metrics)
