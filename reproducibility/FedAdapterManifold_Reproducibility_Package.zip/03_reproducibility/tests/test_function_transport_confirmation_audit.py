from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "scripts" / "audit_function_transport_confirmation.py"


def _load_module():
    spec = importlib.util.spec_from_file_location("confirmation_audit", SCRIPT)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_seed_bootstrap_is_deterministic_and_seed_clustered() -> None:
    module = _load_module()
    values = {10: 0.1, 11: 0.2, 12: 0.3, 13: 0.4, 14: 0.5}
    first = module._seed_bootstrap(values, draws=2000)
    second = module._seed_bootstrap(values, draws=2000)
    assert first == second
    assert first[0] < np.mean(list(values.values())) < first[1]


def test_confirmation_audit_declares_exact_untouched_grain() -> None:
    module = _load_module()
    assert module.EXPECTED_SEEDS == [10, 11, 12, 13, 14]
    assert module.EXPECTED_CLIENTS == {
        "0": "Art",
        "1": "Clipart",
        "2": "Product",
        "3": "Real_World",
    }
