from __future__ import annotations

import math

import numpy as np

from scripts.build_geometry_contract_and_provider_audit import (
    deterministic_symmetric_noise,
    route_weights,
)


def test_fixed_support_softmax_drift_obeys_theoretical_bound() -> None:
    distance = np.array(
        [
            [0.0, 0.4, 1.2],
            [0.4, 0.0, 0.7],
            [1.2, 0.7, 0.0],
        ]
    )
    graph = np.ones_like(distance)
    noise = deterministic_symmetric_noise(3, 17)
    perturbation = 0.1 * noise
    perturbed = np.maximum(distance + perturbation, 0.0)
    np.fill_diagonal(perturbed, 0.0)

    baseline = route_weights(distance, graph)
    candidate = route_weights(perturbed, graph)
    epsilon = 0.5 * float(np.max(np.abs(perturbed - distance)))
    bound = 2.0 * math.tanh(epsilon)

    assert np.max(np.sum(np.abs(candidate - baseline), axis=1)) <= bound + 1e-12


def test_graph_magnitude_does_not_change_support_only_route() -> None:
    distance = np.array([[0.0, 0.5], [0.5, 0.0]])
    graph = np.array([[1.0, 1e-12], [2e-12, 1.0]])

    baseline = route_weights(distance, graph)
    scaled = route_weights(distance, graph * 1e9)

    np.testing.assert_allclose(baseline, scaled, atol=0.0, rtol=0.0)


def test_zero_graph_edge_remains_unavailable() -> None:
    distance = np.array(
        [
            [0.0, 0.1, 0.2],
            [0.1, 0.0, 0.3],
            [0.2, 0.3, 0.0],
        ]
    )
    graph = np.array(
        [
            [1.0, 1.0, 0.0],
            [1.0, 1.0, 1.0],
            [0.0, 1.0, 1.0],
        ]
    )

    weights = route_weights(distance, graph)

    assert weights[0, 2] == 0.0
    assert weights[2, 0] == 0.0
