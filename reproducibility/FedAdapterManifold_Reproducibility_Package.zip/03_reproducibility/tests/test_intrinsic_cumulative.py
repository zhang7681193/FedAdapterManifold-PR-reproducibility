import numpy as np

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.decoupled_transport import (
    build_curvature_semantic_candidates,
    local_quadratic_action_risk,
)
from fedadaptermanifold.intrinsic_cumulative import run_intrinsic_cumulative_lift


def test_intrinsic_cumulative_stream_reconstructs_without_external_state():
    clients, base_weight = make_synthetic_manifold_clients(
        num_clients=4,
        num_classes=4,
        feature_dim=16,
        train_per_client=24,
        test_per_client=12,
        rank=2,
        seed=3,
    )
    result = run_intrinsic_cumulative_lift(
        clients,
        base_weight,
        ranks=2,
        rounds=2,
        local_epochs=1,
        lr=0.05,
        batch_size=12,
        seed=7,
        dataset="synthetic",
        heterogeneity_setting="unit-test",
    )
    weights = np.asarray([len(client.y_train) for client in clients], dtype=np.float64)
    weights /= weights.sum()
    reconstructed = result.cumulative_projection_residual + sum(
        float(weight) * stream for weight, stream in zip(weights, result.client_cumulative_deltas)
    )

    assert np.linalg.norm(result.cumulative_base_delta) > 0.0
    assert np.linalg.norm(result.cumulative_base_delta - reconstructed) < 1e-10
    assert result.effective_adapter.rank == min(base_weight.shape)
    assert result.rank_matched_adapter.rank == 2
    assert len(result.round_history) == 8
    assert all(row["upload_rank"] == 2 for row in result.round_history)
    assert all(row["server_risk_after"] <= row["server_risk_before"] + 1e-12 for row in result.round_history)
    assert not any(row["subspace_warm_start"] for row in result.round_history[:4])
    assert all(row["subspace_warm_start"] for row in result.round_history[4:])
    assert all(row["deployment_rank"] == min(base_weight.shape) for row in result.per_client_metrics)


def test_intrinsic_cumulative_requires_common_rank():
    clients, base_weight = make_synthetic_manifold_clients(
        num_clients=4,
        num_classes=4,
        feature_dim=12,
        train_per_client=12,
        test_per_client=8,
        rank=2,
        seed=11,
    )
    try:
        run_intrinsic_cumulative_lift(
            clients,
            base_weight,
            ranks=[2, 3, 2, 3],
            rounds=1,
            local_epochs=1,
            lr=0.05,
            batch_size=8,
            seed=0,
            dataset="synthetic",
            heterogeneity_setting="unit-test",
        )
    except ValueError as exc:
        assert "common communication rank" in str(exc)
    else:
        raise AssertionError("Expected heterogeneous communication ranks to be rejected")


def test_local_quadratic_action_risk_identifies_descent_direction():
    x = np.asarray([[1.0, 0.0], [1.0, 0.0]], dtype=np.float64)
    y = np.asarray([0, 0], dtype=np.int64)
    anchor = np.zeros((2, 2), dtype=np.float64)
    beneficial_action = np.asarray([[0.1, 0.0], [-0.1, 0.0]], dtype=np.float64)

    risk = local_quadratic_action_risk(x, y, anchor, beneficial_action)

    assert risk["first_order"] < 0.0
    assert risk["curvature"] > 0.0
    assert risk["quadratic_risk"] < 0.0
    assert risk["cubic_remainder_proxy"] >= 0.0


def test_curvature_semantic_candidates_keep_signals_separate_and_normalized():
    clients, base_weight = make_synthetic_manifold_clients(
        num_clients=4,
        num_classes=4,
        feature_dim=12,
        train_per_client=16,
        test_per_client=8,
        rank=2,
        seed=17,
    )
    receivers = []
    streams = []
    for index in range(4):
        rng = np.random.default_rng(100 + index)
        adapter = LoRAAdapter.random(12, 4, 2, rng=rng, alpha=2.0, zero_b=False)
        receivers.append(adapter)
        streams.append(adapter.delta() * (1.0 + 0.1 * index))
    graph = np.ones((4, 4), dtype=np.float64) - np.eye(4, dtype=np.float64)
    d_geo = np.abs(np.subtract.outer(np.arange(4), np.arange(4))).astype(np.float64)
    d_label = d_geo / 3.0

    adapters, rows = build_curvature_semantic_candidates(
        training_clients=clients,
        base_weight=base_weight,
        receivers=receivers,
        donor_cumulative_deltas=streams,
        algebraic_residual=np.zeros_like(base_weight),
        prior_weights=np.ones(4, dtype=np.float64),
        graph=graph,
        d_geo=d_geo,
        label_distance=d_label,
        tau=0.5,
        top_k_neighbors=1,
        target_ranks=4,
    )

    assert len(adapters) == 4
    assert len(rows) == 16
    for receiver_index in range(4):
        receiver_rows = [row for row in rows if row["receiver_index"] == receiver_index]
        assert abs(sum(row["semantic_weight"] for row in receiver_rows) - 1.0) < 1e-10
        assert abs(sum(row["gibbs_prior_weight"] for row in receiver_rows) - 1.0) < 1e-10
        assert sum(bool(row["selected_by_top_k"]) for row in receiver_rows) <= 2
        assert all("quadratic_risk" in row and "normal_energy_ratio" in row for row in receiver_rows)
        assert all(row["mixture_final_objective"] <= row["mixture_initial_objective"] + 1e-10 for row in receiver_rows)
