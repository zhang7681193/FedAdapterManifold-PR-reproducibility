from __future__ import annotations

import inspect
from pathlib import Path

from scripts import run_officehome_confirmation_baselines as baselines
from scripts import run_officehome_function_transport_development as aggregate


def test_confirmation_baseline_command_uses_fixed_protocol(tmp_path: Path) -> None:
    command = baselines._command(
        "python",
        seed=10,
        output_dir=tmp_path / "out",
        geometry_dir=tmp_path / "geometry",
        data_root=tmp_path / "data",
        class_label_map=tmp_path / "labels.json",
    )
    joined = " ".join(command)
    assert "--communication-rounds 5" in joined
    assert "--rank 4" in joined
    assert "--model-name ViT-B/32" in joined
    assert "--round-id 4" in joined
    assert "--function-transport-admission" not in command
    assert "--source-coverage-only" not in command


def test_confirmation_criteria_are_frozen_in_aggregator_source() -> None:
    source = inspect.getsource(aggregate.main)
    assert 'choices=("development", "confirmation")' in source
    assert "raw_student_ci[0] > 0.0" in source
    assert "raw_student_positive_seeds >= 4" in source
    assert "proper_loss_ci[0] >= 0.0" in source
    assert "harmful == 0" in source
    assert 'existing != protocol' in source
