import unittest

import numpy as np

from fedadaptermanifold.baselines import (
    run_clustered_lora_baseline,
    run_ditto_lora_baseline,
    run_fedamp_lora_baseline,
    run_fedavg_lora_baseline,
    run_fedavg_lift_baseline,
    run_fedper_lora_baseline,
    run_fedproto_lora_baseline,
    run_fedprox_lora_baseline,
    run_local_lora,
    run_pfedme_lora_baseline,
    run_scaffold_lora_baseline,
    run_semantic_admission_lora,
    summarize_method,
    topology_calibrated_graph,
)
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.diagnostics import run_subspace_failure_diagnostic


class PersonalizedLoRABaselineTests(unittest.TestCase):
    def test_topology_calibration_is_scale_invariant_and_preserves_zero_edges(self):
        graph = np.asarray(
            [
                [1.0, 1e-12, 3e-12, 0.0],
                [2e-12, 1.0, 0.0, 4e-12],
                [0.0, 5e-12, 1.0, 1e-12],
                [0.0, 0.0, 0.0, 1.0],
            ],
            dtype=float,
        )
        calibrated = topology_calibrated_graph(graph, top_k=2, neighbor_mass=0.8)
        scaled = topology_calibrated_graph(1e9 * graph, top_k=2, neighbor_mass=0.8)

        np.testing.assert_allclose(calibrated, scaled, atol=0.0, rtol=0.0)
        self.assertEqual(float(calibrated[0, 3]), 0.0)
        self.assertEqual(float(calibrated[1, 2]), 0.0)
        self.assertEqual(float(calibrated[3, :3].sum()), 0.0)
        np.testing.assert_allclose(calibrated[:3].sum(axis=1) - np.diag(calibrated)[:3], 0.8)

    def test_topology_calibration_decouples_tiny_edge_scale_from_candidate_generation(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=12,
            train_per_client=24,
            test_per_client=12,
            rank=2,
            seed=35,
        )
        graph = np.eye(3, dtype=float)
        graph[graph == 0.0] = 1e-12
        zeros = np.zeros((3, 3), dtype=float)
        admitted = run_semantic_admission_lora(
            clients,
            clients,
            base_weight,
            graph=graph,
            d_geo=zeros,
            d_label=zeros,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.1,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            graph_scale_policy="topology-calibrated",
            topology_top_k=2,
            topology_neighbor_mass=1.0,
            final_gate_policy="fixed",
        )

        self.assertFalse(any(row["graph_confidence_rejected"] for row in admitted.admission_rows))
        self.assertTrue(
            any(
                row["receiver_client"] != row["donor_client"] and float(row["admission_weight"]) > 0.0
                for row in admitted.admission_rows
            )
        )
        self.assertTrue(all(row["graph_scale_policy"] == "topology-calibrated" for row in admitted.admission_rows))
        self.assertTrue(all(float(row["raw_graph_neighbor_mass"]) < 1e-10 for row in admitted.admission_rows))
        self.assertTrue(all(float(row["effective_graph_neighbor_mass"]) == 1.0 for row in admitted.admission_rows))

    def test_semantic_admission_reduces_exactly_to_local_when_graph_confidence_is_low(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=12,
            train_per_client=24,
            test_per_client=12,
            rank=2,
            seed=36,
        )
        graph = np.eye(3, dtype=float)
        graph[graph == 0.0] = 1e-12
        zeros = np.zeros((3, 3), dtype=float)
        local = run_local_lora(
            clients,
            base_weight,
            ranks=2,
            epochs=2,
            lr=0.1,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=2,
        )
        admitted = run_semantic_admission_lora(
            clients,
            clients,
            base_weight,
            graph=graph,
            d_geo=zeros,
            d_label=zeros,
            ranks=2,
            rounds=2,
            local_epochs=1,
            lr=0.1,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
        )
        precomputed_admitted = run_semantic_admission_lora(
            clients,
            clients,
            base_weight,
            graph=graph,
            d_geo=zeros,
            d_label=zeros,
            ranks=2,
            rounds=2,
            local_epochs=1,
            lr=0.1,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            precomputed_local_fallback=local,
        )
        projected_admitted = run_semantic_admission_lora(
            clients,
            clients,
            base_weight,
            graph=graph,
            d_geo=zeros,
            d_label=zeros,
            ranks=2,
            rounds=2,
            local_epochs=1,
            lr=0.1,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            precomputed_local_fallback=local,
            enable_receiver_projection_fallback=True,
        )

        for local_adapter, admitted_adapter in zip(local.adapters, admitted.client_adapters):
            np.testing.assert_allclose(admitted_adapter.delta(), local_adapter.delta(), atol=0.0, rtol=0.0)
        np.testing.assert_allclose(
            [row["test_accuracy"] for row in admitted.per_client_metrics],
            [row["test_accuracy"] for row in local.per_client_metrics],
            atol=0.0,
            rtol=0.0,
        )
        self.assertEqual(
            {row["selection_split"] for row in admitted.final_gate_rows},
            {"geometry_graph_pretest"},
        )
        self.assertTrue(all(row["graph_confidence_rejected"] for row in admitted.admission_rows))
        for local_adapter, admitted_adapter in zip(local.adapters, precomputed_admitted.client_adapters):
            np.testing.assert_allclose(admitted_adapter.delta(), local_adapter.delta(), atol=0.0, rtol=0.0)
        self.assertTrue(
            all(row["method"] == "FedAdapterManifold-Admit" for row in precomputed_admitted.per_client_metrics)
        )
        self.assertEqual(len(projected_admitted.client_adapters), len(clients))
        self.assertEqual(
            {row["admission_mode"] for row in projected_admitted.admission_rows},
            {"receiver_core_projection"},
        )
        self.assertIn("heldout_calibration", {row["selection_split"] for row in projected_admitted.final_gate_rows})

    def test_multiround_semantic_admission_is_receiver_specific_and_test_free(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=12,
            train_per_client=24,
            test_per_client=12,
            rank=2,
            seed=37,
        )
        graph = np.ones((3, 3), dtype=float)
        zeros = np.zeros((3, 3), dtype=float)
        result = run_semantic_admission_lora(
            clients,
            clients,
            base_weight,
            graph=graph,
            d_geo=zeros,
            d_label=zeros,
            ranks=2,
            rounds=2,
            local_epochs=1,
            lr=0.1,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            final_gate_candidates="0,0.5,1",
        )
        projected = run_semantic_admission_lora(
            clients,
            clients,
            base_weight,
            graph=graph,
            d_geo=zeros,
            d_label=zeros,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.1,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            enable_receiver_projection_fallback=True,
            receiver_projection_mode="left",
            receiver_projection_policy="always",
        )
        trajectory = run_semantic_admission_lora(
            clients,
            clients,
            base_weight,
            graph=graph,
            d_geo=zeros,
            d_label=zeros,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.1,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            enable_receiver_projection_fallback=True,
            receiver_projection_mode="axis_gauge",
            receiver_projection_policy="always",
            round_gate_policy="candidate-trajectory",
        )
        self.assertEqual(len(result.client_adapters), 3)
        self.assertEqual(len(result.per_client_metrics), 3)
        self.assertEqual(len(result.round_history), 6)
        self.assertEqual(len(result.admission_rows), 18)
        self.assertEqual(result.per_client_metrics[0]["method"], "FedAdapterManifold-Admit")
        splits = {row["selection_split"] for row in result.final_gate_rows}
        self.assertEqual(splits, {"round_training_trust_region", "heldout_calibration"})
        self.assertEqual(
            {row["admission_mode"] for row in projected.admission_rows},
            {"receiver_left_projection"},
        )
        selected_trajectory_rows = [
            row
            for row in trajectory.final_gate_rows
            if row["selection_split"] == "round_training_trust_region" and row["selected"]
        ]
        self.assertTrue(selected_trajectory_rows)
        self.assertTrue(all(float(row["selected_graph_mix_weight"]) == 1.0 for row in selected_trajectory_rows))

    def test_fixed_semantic_gate_preserves_a_defined_local_anchor(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=12,
            train_per_client=24,
            test_per_client=12,
            rank=2,
            seed=38,
        )
        graph = np.ones((3, 3), dtype=float)
        zeros = np.zeros((3, 3), dtype=float)
        result = run_semantic_admission_lora(
            clients,
            clients,
            base_weight,
            graph=graph,
            d_geo=zeros,
            d_label=zeros,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.1,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            final_gate_policy="fixed",
        )
        self.assertEqual(len(result.anchor_adapters), len(clients))
        self.assertEqual(len(result.client_adapters), len(clients))
        self.assertTrue(all(row["adapter_graph_mix_policy"] == "fixed" for row in result.final_gate_rows[-3:]))

    def test_fedprox_lora_returns_protocol_metrics(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=16,
            train_per_client=30,
            test_per_client=18,
            rank=2,
            seed=31,
        )
        result = run_fedprox_lora_baseline(
            clients,
            base_weight,
            ranks=[1, 2, 2],
            rounds=2,
            local_epochs=2,
            lr=0.2,
            batch_size=10,
            seed=0,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            prox_mu=0.02,
        )

        self.assertEqual(result.global_adapter.rank, 2)
        self.assertEqual(len(result.per_client_metrics), 3)
        self.assertEqual(len(result.round_history), 6)
        self.assertEqual(result.per_client_metrics[0]["method"], "FedProx-LoRA")
        self.assertEqual(result.round_history[0]["fedprox_mu"], 0.02)

    def test_fedprox_mu_zero_matches_fedavg_lora(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=2,
            num_classes=3,
            feature_dim=12,
            train_per_client=24,
            test_per_client=12,
            rank=1,
            seed=33,
        )
        fedavg = run_fedavg_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=2,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=4,
            dataset="cifar10-debug",
            heterogeneity_setting="unit-test",
        )
        fedprox = run_fedprox_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=2,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=4,
            dataset="cifar10-debug",
            heterogeneity_setting="unit-test",
            prox_mu=0.0,
        )

        self.assertLess(abs(fedavg.global_adapter.delta() - fedprox.global_adapter.delta()).max(), 1e-12)
        self.assertEqual(
            [row["accuracy"] for row in fedavg.per_client_metrics],
            [row["accuracy"] for row in fedprox.per_client_metrics],
        )

    def test_ditto_lora_returns_personal_adapters_and_summary(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=2,
            num_classes=3,
            feature_dim=12,
            train_per_client=24,
            test_per_client=12,
            rank=1,
            seed=32,
        )
        result = run_ditto_lora_baseline(
            clients,
            base_weight,
            ranks=[1, 2],
            rounds=2,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=2,
            dataset="cifar10-debug",
            heterogeneity_setting="unit-test",
            prox_mu=0.03,
        )

        self.assertEqual(result.global_adapter.rank, 2)
        self.assertEqual([adapter.rank for adapter in result.personal_adapters], [1, 2])
        self.assertEqual(len(result.per_client_metrics), 2)
        self.assertEqual(len(result.round_history), 8)
        self.assertEqual(result.per_client_metrics[0]["method"], "Ditto-LoRA")
        self.assertEqual(result.round_history[-1]["ditto_mu"], 0.03)
        summary = summarize_method(result.per_client_metrics)
        self.assertEqual(summary[0]["method"], "Ditto-LoRA")

    def test_clustered_and_fedamp_lora_return_client_adapters(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=16,
            train_per_client=24,
            test_per_client=12,
            rank=2,
            seed=34,
        )
        local = run_ditto_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=3,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            prox_mu=0.0,
        )
        diagnostic = run_subspace_failure_diagnostic(clients, base_weight, local.personal_adapters)
        clustered = run_clustered_lora_baseline(
            clients,
            base_weight,
            local.personal_adapters,
            distance=diagnostic.d_sub,
            ranks=2,
            k=2,
            seed=3,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        fedamp = run_fedamp_lora_baseline(
            clients,
            base_weight,
            local.personal_adapters,
            distance=diagnostic.d_sub,
            ranks=2,
            tau=1.0,
            seed=3,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )

        self.assertEqual(len(clustered.client_adapters), 3)
        self.assertEqual(len(fedamp.client_adapters), 3)
        self.assertEqual(clustered.per_client_metrics[0]["method"], "Clustered-LoRA")
        self.assertEqual(fedamp.per_client_metrics[0]["method"], "FedAMP-LoRA")

    def test_additional_personalized_and_proto_baselines_return_protocol_metrics(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=16,
            train_per_client=24,
            test_per_client=12,
            rank=2,
            seed=35,
        )
        local = run_ditto_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            prox_mu=0.0,
        )
        lift = run_fedavg_lift_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
        )
        diagnostic = run_subspace_failure_diagnostic(clients, base_weight, local.personal_adapters)
        scaffold = run_scaffold_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
        )
        pfedme = run_pfedme_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            prox_mu=0.02,
        )
        fedproto = run_fedproto_lora_baseline(
            clients,
            base_weight,
            local.personal_adapters,
            d_geo=diagnostic.d_sub,
            ranks=2,
            tau=1.0,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        fedper = run_fedper_lora_baseline(
            clients,
            base_weight,
            local.personal_adapters,
            shared_adapter=lift.global_adapter,
            ranks=2,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )

        self.assertEqual(scaffold.per_client_metrics[0]["method"], "SCAFFOLD-LoRA")
        self.assertEqual(len(scaffold.round_history), 3)
        self.assertEqual(pfedme.per_client_metrics[0]["method"], "pFedMe-LoRA")
        self.assertEqual(fedproto.per_client_metrics[0]["method"], "FedProto-LoRA")
        self.assertEqual(fedper.per_client_metrics[0]["method"], "FedPer-LoRA")
        self.assertIn("selected_personal_weight", fedper.per_client_metrics[0])


if __name__ == "__main__":
    unittest.main()
