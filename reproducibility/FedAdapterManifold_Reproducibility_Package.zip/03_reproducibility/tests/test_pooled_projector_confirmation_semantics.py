from __future__ import annotations

import importlib.util
from pathlib import Path

import pandas as pd


MODULE_PATH = (
    Path(__file__).resolve().parents[1]
    / "staging_clip_subspace_uncertainty_v2_20260813"
    / "analyze_pooled_confirmation.py"
)
SPEC = importlib.util.spec_from_file_location("pooled_confirmation_analysis", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def test_one_projector_zero_is_unresolved_not_uncertainty_reduction() -> None:
    rows = []
    for seed in (5, 6):
        for client_id in (0, 1):
            for round_id, radius in ((1, 0.0), (2, 0.8), (5, 0.4)):
                for action in ("row", "column"):
                    rows.append(
                        {
                            "seed": seed,
                            "client_id": client_id,
                            "rounds_pooled": round_id,
                            "action_subspace": action,
                            "uncertainty_radius": radius,
                            "final_estimator_audit": None,
                        }
                    )
    summary = MODULE._summarize_empirical_penalty(pd.DataFrame(rows))
    assert summary["round1_identifiable"] is False
    assert summary["predeclared_reduction_supported"] is False
    assert summary["descriptive_round2_to5_decrease"] is True


def test_identifiable_round1_can_support_predeclared_reduction() -> None:
    rows = []
    for round_id, radius in ((1, 0.7), (2, 0.5), (5, 0.2)):
        rows.append(
            {
                "seed": 5,
                "client_id": 0,
                "rounds_pooled": round_id,
                "uncertainty_radius": radius,
                "final_estimator_audit": None,
            }
        )
    summary = MODULE._summarize_empirical_penalty(pd.DataFrame(rows))
    assert summary["round1_identifiable"] is True
    assert summary["predeclared_reduction_supported"] is True
