from __future__ import annotations

import json
from pathlib import Path

from scripts.prepare_officehome_confirmation_manifests import main


def test_confirmation_manifest_freezes_training_rows_for_fedgeo(tmp_path: Path) -> None:
    data_root = tmp_path / "OfficeHome"
    for domain in ("Art", "Clipart"):
        for split in ("train", "test"):
            for label in ("0", "1"):
                folder = data_root / domain / split / label
                folder.mkdir(parents=True)
                for index in range(3):
                    (folder / f"{index}.png").write_bytes(b"image")

    output = tmp_path / "manifests"
    result = main(
        [
            "--data-root",
            str(data_root),
            "--output-dir",
            str(output),
            "--domains",
            "Art,Clipart",
            "--num-classes",
            "2",
            "--train-per-class",
            "3",
            "--test-per-class",
            "2",
            "--calibration-fraction",
            "0.33",
            "--seeds",
            "10",
        ]
    )
    assert result == 0
    seed_dir = output / "seed_10"
    full_rows = json.loads((seed_dir / "split_manifest.json").read_text(encoding="utf-8"))
    training_rows = json.loads(
        (seed_dir / "fedgeo_training_manifest.json").read_text(encoding="utf-8")
    )
    metadata = json.loads((seed_dir / "manifest_metadata.json").read_text(encoding="utf-8"))
    assert {row["split"] for row in full_rows} == {"train", "calibration", "test"}
    assert {row["split"] for row in training_rows} == {"train"}
    assert len(training_rows) == metadata["fedgeo_training_rows"]
    assert metadata["client_ids"] == [0, 1]
    assert metadata["domains"] == ["Art", "Clipart"]
