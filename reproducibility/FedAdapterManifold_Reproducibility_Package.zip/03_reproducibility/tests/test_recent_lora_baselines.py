import unittest
import importlib.util
from pathlib import Path

import numpy as np

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.aggregation import fedrot_align_to_reference
from fedadaptermanifold.baselines import run_fedrot_lora_baseline
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.recent_lora_baselines import (
    _fedalt_routed_logits,
    _fedlease_adaptive_route_weights,
    _fedlease_server_aggregate,
    fedalt_rest_of_world_aggregate,
    _lorafair_objective_and_gradient,
    fedex_exact_aggregate,
    fedpissa_decorrelated_aggregate,
    lorafair_refine_aggregate,
    run_fedex_lora_baseline,
    run_fedalt_visual_baseline,
    run_fedpissa_visual_baseline,
    run_fedlease_visual_baseline,
    run_fedsa_lora_baseline,
    run_fedsmooth_lora_baseline,
    run_fedtree_lora_visual_baseline,
    run_hilora_visual_baseline,
    run_lorafair_baseline,
    run_telora_baseline,
    telora_paa_align,
    telora_t2m2,
)
from fedadaptermanifold.training import train_lora_adapter


class RecentLoRABaselineTests(unittest.TestCase):
    def test_fedalt_rest_of_world_recurrence_matches_official_server(self):
        try:
            import torch
        except ImportError:
            self.skipTest("torch is unavailable")
        source = Path(__file__).resolve().parents[1] / "external" / "FedALT" / "server.py"
        if not source.exists():
            self.skipTest("pinned FedALT source is unavailable")
        spec = importlib.util.spec_from_file_location("fedalt_official_server", source)
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)

        rng = np.random.default_rng(712)
        adapters = [LoRAAdapter.random(7, 4, 3, rng, zero_b=False) for _ in range(4)]
        visual = fedalt_rest_of_world_aggregate(adapters, round_id=1)
        params = []
        for adapter in adapters:
            params.append(
                {
                    "layer.lora_A1.weight": torch.tensor(adapter.A, dtype=torch.float64),
                    "layer.lora_B1.weight": torch.tensor(adapter.B, dtype=torch.float64),
                    "layer.lora_route.weight": torch.zeros((2, 7), dtype=torch.float64),
                }
            )
        official = module.Server(clients_num=4, device="cpu").aggregation(False, params)
        for client_idx in range(4):
            np.testing.assert_allclose(
                official[client_idx]["layer.lora_A0.weight"].numpy(),
                visual[client_idx].A,
                atol=1e-12,
            )
            np.testing.assert_allclose(
                official[client_idx]["layer.lora_B0.weight"].numpy(),
                visual[client_idx].B,
                atol=1e-12,
            )

    def test_fedalt_visual_router_matches_two_expert_softmax(self):
        rng = np.random.default_rng(713)
        row = LoRAAdapter.random(5, 3, 2, rng, zero_b=False)
        local = LoRAAdapter.random(5, 3, 2, rng, zero_b=False)
        x = rng.normal(size=(6, 5))
        base = rng.normal(size=(3, 5))
        route = rng.normal(size=(2, 5))
        logits, weights, outputs = _fedalt_routed_logits(x, base, row, local, route)
        expected_weights = np.exp(x @ route.T - np.max(x @ route.T, axis=1, keepdims=True))
        expected_weights /= expected_weights.sum(axis=1, keepdims=True)
        expected = x @ base.T + np.einsum("nk,nkc->nc", expected_weights, outputs)
        np.testing.assert_allclose(weights, expected_weights, atol=1e-12)
        np.testing.assert_allclose(logits, expected, atol=1e-12)

    def test_fedalt_visual_run_is_test_free_and_budget_logged(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3, num_classes=4, feature_dim=12, train_per_client=24, test_per_client=12, seed=714
        )
        result = run_fedalt_visual_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=2,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=0,
            dataset="debug",
            heterogeneity_setting="unit-test",
        )
        self.assertEqual(len(result.per_client_metrics), 3)
        self.assertEqual(len(result.round_history), 6)
        self.assertTrue(all(not row["test_used_for_routing_or_training"] for row in result.per_client_metrics))
        self.assertTrue(all(row["implementation_fidelity"] == "official-source-visual-task-port" for row in result.per_client_metrics))
        self.assertTrue(all(row["router_parameters"] == 24 for row in result.per_client_metrics))

    def test_fedex_aggregation_is_exact_without_rank_projection(self):
        rng = np.random.default_rng(7)
        adapters = [LoRAAdapter.random(9, 5, 3, rng, zero_b=False) for _ in range(4)]
        residual = rng.normal(size=(5, 9)) * 0.01
        weights = np.asarray([1.0, 2.0, 3.0, 4.0])
        weights /= weights.sum()

        factor, new_residual, error = fedex_exact_aggregate(adapters, residual, weights)
        target = residual + sum(float(weight) * adapter.delta() for weight, adapter in zip(weights, adapters))

        self.assertLess(error, 1e-12)
        self.assertLess(np.max(np.abs(new_residual + factor.delta() - target)), 1e-12)

    def test_fedex_run_logs_exactness_and_protocol_fields(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3, num_classes=4, feature_dim=14, train_per_client=24, test_per_client=12, seed=41
        )
        result = run_fedex_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=3,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=0,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
        )

        self.assertEqual(len(result.per_client_metrics), 3)
        self.assertEqual(len(result.round_history), 9)
        self.assertLess(max(row["exact_aggregation_error"] for row in result.round_history), 1e-10)
        self.assertEqual(result.per_client_metrics[0]["method"], "FedEx-LoRA")

    def test_fedsa_shares_a_and_keeps_b_personal(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3, num_classes=4, feature_dim=14, train_per_client=24, test_per_client=12, seed=42
        )
        result = run_fedsa_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=3,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=1,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
        )

        for adapter in result.personal_adapters:
            self.assertLess(np.max(np.abs(adapter.A - result.shared_a)), 1e-12)
        b_distances = [
            np.linalg.norm(result.personal_adapters[i].B - result.personal_adapters[j].B)
            for i in range(3)
            for j in range(i + 1, 3)
        ]
        self.assertGreater(max(b_distances), 1e-8)
        self.assertEqual(result.per_client_metrics[0]["retained_local_factor"], "B")

        masked = run_fedsa_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=1,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            method="RobustAxisCenter",
            shared_axis_donor_mask=np.array([True, True, False]),
        )
        donor_flags = [row["shared_axis_donor"] for row in masked.round_history]
        self.assertEqual(donor_flags, [True, True, False])

    def test_fedpissa_equation_port_matches_paper_recurrence(self):
        rng = np.random.default_rng(421)
        adapters = [LoRAAdapter.random(10, 6, 4, rng, zero_b=False) for _ in range(3)]
        weights = np.asarray([0.2, 0.3, 0.5], dtype=np.float64)
        strength = 0.05
        aggregated_b, projections, diagnostics = fedpissa_decorrelated_aggregate(
            adapters,
            weights=weights,
            decorrelation_strength=strength,
            tail_start=3,
        )
        b_average = sum(float(weight) * adapter.B for weight, adapter in zip(weights, adapters))
        expected = b_average + strength * sum(
            float(weight) * (adapter.B - b_average) @ projection
            for weight, adapter, projection in zip(weights, adapters, projections)
        )
        np.testing.assert_allclose(aggregated_b, expected, atol=1e-12)
        for weight, projection, row in zip(weights, projections, diagnostics):
            np.testing.assert_allclose(projection, projection.T, atol=1e-12)
            np.testing.assert_allclose(projection @ projection, projection, atol=1e-12)
            self.assertEqual(np.linalg.matrix_rank(projection, tol=1e-10), 2)
            self.assertEqual(row["tail_dimension"], 2)
            self.assertAlmostEqual(row["aggregation_weight"], float(weight), places=12)

    def test_fedpissa_shares_b_and_keeps_a_personal(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3, num_classes=4, feature_dim=14, train_per_client=24, test_per_client=12, seed=422
        )
        result = run_fedpissa_visual_baseline(
            clients,
            base_weight,
            ranks=4,
            rounds=2,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=1,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
        )
        for adapter in result.personal_adapters:
            np.testing.assert_allclose(adapter.B, result.shared_b, atol=1e-12)
        a_distances = [
            np.linalg.norm(result.personal_adapters[i].A - result.personal_adapters[j].A)
            for i in range(3)
            for j in range(i + 1, 3)
        ]
        self.assertGreater(max(a_distances), 1e-8)
        self.assertTrue(
            all(row["implementation_fidelity"] == "paper-equation-port-no-public-code" for row in result.per_client_metrics)
        )
        self.assertTrue(all(row["uploaded_factors"] == "A,B" for row in result.round_history))
        self.assertTrue(all(row["aggregated_factor"] == "B" for row in result.round_history))
        self.assertTrue(all(row["broadcast_factor"] == "B" for row in result.round_history))

    def test_fedrot_soft_rotation_preserves_semantic_update(self):
        rng = np.random.default_rng(9)
        adapter = LoRAAdapter.random(10, 6, 3, rng, zero_b=False)
        reference = LoRAAdapter.random(10, 6, 3, rng, zero_b=False)
        for factor in ["A", "B"]:
            aligned = fedrot_align_to_reference(adapter, reference, factor, strength=0.4)
            self.assertLess(np.max(np.abs(aligned.delta() - adapter.delta())), 1e-12)

    def test_fedrot_uses_previous_global_reference_and_alternates_factors(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=2, num_classes=3, feature_dim=12, train_per_client=20, test_per_client=10, seed=43
        )
        result = run_fedrot_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=3,
            local_epochs=1,
            lr=0.2,
            batch_size=10,
            seed=2,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            rotation_strength=0.4,
        )

        by_round = {
            round_id: {row["alignment_factor"] for row in result.round_history if row["round"] == round_id}
            for round_id in [1, 2, 3]
        }
        self.assertEqual(by_round, {1: {"none"}, 2: {"A"}, 3: {"B"}})
        self.assertLess(
            max(row["semantic_update_preservation_error"] for row in result.round_history),
            1e-10,
        )

    def test_fixed_rank_requirement_is_explicit(self):
        clients, base_weight = make_synthetic_manifold_clients(num_clients=2, seed=44)
        with self.assertRaises(ValueError):
            run_fedsa_lora_baseline(
                clients,
                base_weight,
                ranks=[1, 2],
                rounds=1,
                local_epochs=1,
                lr=0.1,
                batch_size=8,
                seed=0,
                dataset="debug",
                heterogeneity_setting="unit-test",
            )

    def test_fedlease_allocates_fixed_experts_without_test_routing(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=4, num_classes=4, feature_dim=14, train_per_client=40, test_per_client=12, seed=45
        )
        result = run_fedlease_visual_baseline(
            clients,
            base_weight,
            ranks=4,
            rounds=2,
            local_epochs=1,
            lr=0.2,
            batch_size=10,
            seed=0,
            dataset="debug",
            heterogeneity_setting="unit-test",
        )
        self.assertEqual(len(result.client_adapters), 4)
        self.assertEqual(result.assignments.shape, (4,))
        self.assertTrue(all("expert_id" in row for row in result.round_history))
        self.assertTrue(all(row["method"] == "FedLEASE-OfficialPort" for row in result.per_client_metrics))
        self.assertTrue(all(row["router_parameters"] > 0 for row in result.per_client_metrics))

    def test_fedlease_adaptive_router_maps_extra_slots_to_own_expert(self):
        x = np.asarray([[1.0, 0.0]], dtype=np.float64)
        route = np.asarray(
            [
                [3.0, 0.0],
                [0.0, 0.0],
                [1.0, 0.0],
                [4.0, 0.0],
                [2.0, 0.0],
            ],
            dtype=np.float64,
        )
        weights, selected_dims, _ = _fedlease_adaptive_route_weights(
            x, route, own_expert=1, num_experts=3
        )
        self.assertEqual(selected_dims.tolist(), [[3, 0, 4]])
        self.assertAlmostEqual(float(weights.sum()), 1.0)
        self.assertGreater(weights[0, 1], weights[0, 0])
        self.assertEqual(weights[0, 2], 0.0)

    def test_fedlease_server_recurrence_matches_official_source(self):
        try:
            import torch
        except ImportError:
            self.skipTest("torch is unavailable")
        source = Path(__file__).resolve().parents[1] / "third_party" / "FedLEASE" / "server.py"
        if not source.exists():
            self.skipTest("pinned FedLEASE source is unavailable")
        spec = importlib.util.spec_from_file_location("fedlease_official_server", source)
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)

        rng = np.random.default_rng(451)
        assignments = np.asarray([0, 0, 1, 1], dtype=np.int64)
        trained = [LoRAAdapter.random(3, 2, 2, rng, zero_b=False) for _ in range(4)]
        routes = [rng.normal(size=(3, 3)) for _ in range(4)]
        visual_experts, visual_routes = _fedlease_server_aggregate(
            trained, routes, assignments, rank=2, round_id=1
        )

        client_params = []
        for client_idx in range(4):
            params = {"layer.lora_route.weight": torch.tensor(routes[client_idx], dtype=torch.float64)}
            for expert_idx in range(2):
                state = trained[client_idx] if expert_idx == assignments[client_idx] else trained[expert_idx * 2]
                params[f"layer.lora_A{expert_idx}.weight"] = torch.tensor(state.A, dtype=torch.float64)
                params[f"layer.lora_B{expert_idx}.weight"] = torch.tensor(state.B, dtype=torch.float64)
            client_params.append(params)
        official = module.Server(clients_num=4, device="cpu").aggregation(
            route_aggregation=True,
            params=client_params,
            lora_client_map={0: [0, 1], 1: [2, 3]},
        )
        for client_idx in range(4):
            np.testing.assert_allclose(
                official[client_idx]["layer.lora_route.weight"].numpy(),
                visual_routes[client_idx],
                atol=1e-12,
            )
            for expert_idx in range(2):
                np.testing.assert_allclose(
                    official[client_idx][f"layer.lora_A{expert_idx}.weight"].numpy(),
                    visual_experts[expert_idx].A,
                    atol=1e-12,
                )
                np.testing.assert_allclose(
                    official[client_idx][f"layer.lora_B{expert_idx}.weight"].numpy(),
                    visual_experts[expert_idx].B,
                    atol=1e-12,
                )

    def test_hilora_is_total_rank_budget_matched(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=4, num_classes=8, feature_dim=14, train_per_client=40, test_per_client=12, seed=46
        )
        result = run_hilora_visual_baseline(
            clients,
            base_weight,
            ranks=6,
            rounds=2,
            local_epochs=1,
            lr=0.2,
            batch_size=10,
            seed=1,
            dataset="debug",
            heterogeneity_setting="unit-test",
        )
        self.assertTrue(all(adapter.rank == 6 for adapter in result.client_adapters))
        last = result.round_history[-1]
        self.assertEqual(last["root_rank"] + last["cluster_rank"] + last["leaf_rank"], 6)

    def test_fedsmooth_merges_full_updates_across_rounds(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3, num_classes=4, feature_dim=14, train_per_client=40, test_per_client=12, seed=47
        )
        result = run_fedsmooth_lora_baseline(
            clients,
            base_weight,
            ranks=4,
            rounds=3,
            local_epochs=1,
            lr=0.2,
            batch_size=10,
            seed=2,
            dataset="debug",
            heterogeneity_setting="unit-test",
            gradient_sample_size=16,
        )
        self.assertEqual(len(result.round_history), 9)
        self.assertGreater(np.linalg.norm(result.cumulative_base_delta), 0.0)
        self.assertTrue(all("round_matching_norm" in row for row in result.round_history))
        self.assertEqual(result.rank_matched_adapter.rank, 4)
        self.assertEqual(len(result.rank_matched_per_client_metrics), 3)
        sample_weights = np.asarray([len(client.x_train) for client in clients], dtype=np.float64)
        sample_weights /= sample_weights.sum()
        reconstructed = result.cumulative_projection_residual + sum(
            float(weight) * stream for weight, stream in zip(sample_weights, result.client_cumulative_deltas)
        )
        self.assertLess(np.linalg.norm(reconstructed - result.cumulative_base_delta), 1e-10)

    def test_lorafair_refinement_reduces_released_objective(self):
        rng = np.random.default_rng(48)
        adapters = [LoRAAdapter.random(9, 5, 3, rng, zero_b=False) for _ in range(4)]
        refined, stats = lorafair_refine_aggregate(
            adapters,
            num_iterations=100,
            learning_rate=0.01,
            lambda_reg=1.0,
            seed=3,
        )
        self.assertEqual(refined.rank, 3)
        self.assertLess(stats["final_refinement_loss"], stats["initial_refinement_loss"])
        self.assertTrue(np.isfinite(stats["final_reconstruction_cosine"]))

    def test_fedtree_visual_port_runs_two_expert_recurrence(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=4,
            num_classes=4,
            feature_dim=12,
            train_per_client=32,
            test_per_client=12,
            seed=481,
        )
        result = run_fedtree_lora_visual_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=3,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=2,
            dataset="debug",
            heterogeneity_setting="unit-test",
            warmup_rounds=1,
            max_clusters=3,
            search_range_k=3,
        )
        self.assertEqual(len(result.client_adapters), 4)
        self.assertEqual(len(result.per_client_metrics), 4)
        self.assertEqual(len(result.round_history), 12)
        self.assertEqual({row["phase"] for row in result.round_history[:4]}, {"warmup"})
        self.assertEqual({row["phase"] for row in result.round_history[4:]}, {"two_expert"})
        self.assertTrue(
            all(0.0 <= row["own_cluster_routing_weight"] <= 1.0 for row in result.round_history)
        )

    def test_lorafair_numpy_gradient_matches_finite_difference(self):
        rng = np.random.default_rng(480)
        target = rng.normal(size=(4, 6))
        a_bar = rng.normal(size=(2, 6))
        b_bar = rng.normal(size=(4, 2))
        residual = rng.normal(size=(4, 2)) * 0.1
        _, _, gradient = _lorafair_objective_and_gradient(target, a_bar, b_bar, residual, 0.3)
        epsilon = 1e-6
        for row, column in [(0, 0), (2, 1), (3, 0)]:
            plus = residual.copy()
            minus = residual.copy()
            plus[row, column] += epsilon
            minus[row, column] -= epsilon
            loss_plus = _lorafair_objective_and_gradient(target, a_bar, b_bar, plus, 0.3)[0]
            loss_minus = _lorafair_objective_and_gradient(target, a_bar, b_bar, minus, 0.3)[0]
            numerical = (loss_plus - loss_minus) / (2.0 * epsilon)
            self.assertAlmostEqual(gradient[row, column], numerical, places=6)

    def test_lorafair_runs_in_matched_visual_protocol(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3, num_classes=4, feature_dim=12, train_per_client=24, test_per_client=10, seed=49
        )
        result = run_lorafair_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=2,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=0,
            dataset="debug",
            heterogeneity_setting="unit-test",
            refinement_iterations=20,
        )
        self.assertEqual(len(result.per_client_metrics), 3)
        self.assertEqual(len(result.round_history), 6)
        self.assertTrue(all(row["method"] == "LoRA-FAIR" for row in result.round_history))

    def test_telora_paa_satisfies_uniform_marginals(self):
        rng = np.random.default_rng(50)
        source = rng.normal(size=(7, 2))
        target = rng.normal(size=(7, 3))
        aligned, transport = telora_paa_align(source, target, eta=1.0, sinkhorn_iterations=200)
        self.assertEqual(aligned.shape, target.shape)
        np.testing.assert_allclose(transport.sum(axis=1), np.full(2, 0.5), atol=1e-8)
        np.testing.assert_allclose(transport.sum(axis=0), np.full(3, 1.0 / 3.0), atol=1e-8)
        np.testing.assert_allclose(transport, np.full((2, 3), 1.0 / 6.0), atol=1e-8)

    def test_telora_t2m2_is_rank_one_client_mode_core(self):
        matrix = np.arange(12, dtype=np.float64).reshape(3, 4) / 10.0
        core = telora_t2m2([matrix, matrix, matrix])
        np.testing.assert_allclose(core, np.sqrt(3.0) * matrix, atol=1e-10)

    def test_telora_alternates_frozen_factors(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=2, num_classes=3, feature_dim=10, train_per_client=20, test_per_client=10, seed=51
        )
        result = run_telora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=3,
            local_epochs=1,
            lr=0.1,
            batch_size=8,
            seed=1,
            dataset="debug",
            heterogeneity_setting="unit-test",
            sinkhorn_iterations=20,
        )
        factors = {
            round_id: {row["trained_factor"] for row in result.round_history if row["round"] == round_id}
            for round_id in (1, 2, 3)
        }
        self.assertEqual(factors, {1: {"B"}, 2: {"A"}, 3: {"B"}})
        self.assertEqual(len(result.per_client_metrics), 2)

    def test_factor_freezing_keeps_the_other_factor_exact(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=1, num_classes=3, feature_dim=10, train_per_client=20, test_per_client=10, seed=52
        )
        initial = LoRAAdapter.random(10, 3, 2, np.random.default_rng(5), zero_b=False)
        trained, _ = train_lora_adapter(
            clients[0].x_train,
            clients[0].y_train,
            base_weight,
            rank=2,
            init_adapter=initial,
            epochs=1,
            lr=0.1,
            batch_size=8,
            train_a=False,
            train_b=True,
            seed=0,
        )
        np.testing.assert_allclose(trained.A, initial.A, atol=0.0, rtol=0.0)
        self.assertGreater(np.linalg.norm(trained.B - initial.B), 0.0)


if __name__ == "__main__":
    unittest.main()
