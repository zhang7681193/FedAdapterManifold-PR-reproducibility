from scripts.audit_recent_lora_data_quality import selection_split_is_allowed


def test_pretest_protocol_label_is_not_misclassified_as_test_leakage() -> None:
    assert selection_split_is_allowed("geometry_graph_pretest")


def test_actual_test_splits_and_unknown_labels_are_rejected() -> None:
    assert not selection_split_is_allowed("test")
    assert not selection_split_is_allowed("heldout_test")
    assert not selection_split_is_allowed("unknown")
