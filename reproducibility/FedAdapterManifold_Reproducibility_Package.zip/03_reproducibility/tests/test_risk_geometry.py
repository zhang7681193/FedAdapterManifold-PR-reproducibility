import unittest

import numpy as np

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.baselines import run_local_lora
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.risk_geometry import (
    directed_receiver_risk_subspace_distance_matrix,
    receiver_risk_subspace_metrics,
)


class ReceiverRiskGeometryTests(unittest.TestCase):
    def test_identity_metric_recovers_effective_action_subspace_mismatch(self):
        receiver = np.array([[1.0, 0.0], [0.0, 0.0]])
        donor = np.array([[0.0, 0.0], [0.0, 1.0]])
        metrics = receiver_risk_subspace_metrics(
            receiver,
            donor,
            np.eye(2),
            np.eye(2),
            receiver_rank=1,
            donor_rank=1,
        )
        self.assertAlmostEqual(metrics.column_distance, 1.0)
        self.assertAlmostEqual(metrics.row_distance, 1.0)
        self.assertAlmostEqual(metrics.distance, 2.0)
        self.assertGreater(metrics.normal_energy_ratio, 0.0)

    def test_one_sided_action_change_is_tangent_not_normal(self):
        receiver = np.array([[1.0, 0.0], [0.0, 0.0]])
        donor = np.array([[0.0, 0.0], [1.0, 0.0]])
        metrics = receiver_risk_subspace_metrics(
            receiver,
            donor,
            np.eye(2),
            np.eye(2),
            receiver_rank=1,
            donor_rank=1,
        )
        self.assertAlmostEqual(metrics.column_distance, 1.0)
        self.assertAlmostEqual(metrics.row_distance, 0.0)
        self.assertAlmostEqual(metrics.normal_energy, 0.0)
        self.assertAlmostEqual(metrics.normal_energy_ratio, 0.0)

    def test_metric_is_invariant_to_lora_factor_gauge(self):
        rng = np.random.default_rng(4)
        b = rng.normal(size=(3, 2))
        a = rng.normal(size=(2, 4))
        q = np.array([[1.5, 0.2], [0.1, 0.9]])
        original = b @ a
        reparameterized = (b @ q) @ (np.linalg.inv(q) @ a)
        receiver = rng.normal(size=(3, 4))
        output_factor = np.diag([0.5, 2.0, 1.0])
        input_factor = np.diag([1.0, 0.25, 3.0, 0.75])
        first = receiver_risk_subspace_metrics(
            receiver, original, output_factor, input_factor, receiver_rank=2, donor_rank=2
        )
        second = receiver_risk_subspace_metrics(
            receiver, reparameterized, output_factor, input_factor, receiver_rank=2, donor_rank=2
        )
        self.assertAlmostEqual(first.distance, second.distance, places=12)
        self.assertAlmostEqual(first.normal_energy_ratio, second.normal_energy_ratio, places=12)

    def test_directed_training_only_metric_has_expected_shape(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=4,
            num_classes=5,
            feature_dim=12,
            train_per_client=32,
            test_per_client=16,
            rank=2,
            seed=23,
        )
        local = run_local_lora(
            clients,
            base_weight,
            ranks=2,
            epochs=2,
            lr=0.2,
            batch_size=16,
            seed=9,
            dataset="synthetic",
            heterogeneity_setting="risk-geometry-test",
            round_id=0,
        )
        distance, normal_ratio = directed_receiver_risk_subspace_distance_matrix(
            clients, base_weight, local.adapters
        )
        self.assertEqual(distance.shape, (4, 4))
        self.assertEqual(normal_ratio.shape, (4, 4))
        self.assertTrue(np.allclose(np.diag(distance), 0.0))
        self.assertTrue(np.allclose(np.diag(normal_ratio), 0.0))
        self.assertTrue(np.all(np.isfinite(distance)))
        self.assertTrue(np.all((normal_ratio >= 0.0) & (normal_ratio <= 1.0 + 1e-12)))


if __name__ == "__main__":
    unittest.main()
