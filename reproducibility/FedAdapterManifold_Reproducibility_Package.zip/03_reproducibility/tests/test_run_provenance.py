from __future__ import annotations

import json

from fedadaptermanifold.run_experiment import (
    _geometry_input_hash,
    _sha256_source_tree,
    _write_run_provenance,
)


def test_source_tree_hash_changes_with_source(tmp_path) -> None:
    source = tmp_path / "pkg"
    source.mkdir()
    module = source / "module.py"
    module.write_text("VALUE = 1\n", encoding="utf-8")
    first = _sha256_source_tree(source)
    module.write_text("VALUE = 2\n", encoding="utf-8")
    second = _sha256_source_tree(source)
    assert first != second


def test_geometry_hash_is_order_independent_and_content_sensitive(tmp_path) -> None:
    geometry = tmp_path / "geometry"
    geometry.mkdir()
    (geometry / "b.npy").write_bytes(b"b")
    (geometry / "a.npy").write_bytes(b"a")
    first, names = _geometry_input_hash(str(geometry))
    assert names == ["a.npy", "b.npy"]
    (geometry / "b.npy").write_bytes(b"changed")
    second, _ = _geometry_input_hash(str(geometry))
    assert first != second


def test_run_provenance_records_replay_critical_hashes(tmp_path) -> None:
    config = tmp_path / "input.yaml"
    config.write_text("seed: 3\n", encoding="utf-8")
    geometry = tmp_path / "geometry"
    geometry.mkdir()
    (geometry / "d_geo_round_0.npy").write_bytes(b"distance")
    output = tmp_path / "run_provenance.json"
    _write_run_provenance(
        output,
        raw_argv=["--config", str(config)],
        source_config=str(config),
        effective_config={"seed": 3},
        geometry_outputs_dir=str(geometry),
    )
    record = json.loads(output.read_text(encoding="utf-8"))
    assert record["schema_version"] == 1
    assert len(record["package_source_sha256"]) == 64
    assert len(record["source_config_sha256"]) == 64
    assert len(record["effective_config_sha256"]) == 64
    assert len(record["geometry_inputs_sha256"]) == 64
    assert record["geometry_input_files"] == ["d_geo_round_0.npy"]
