import unittest

import numpy as np

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.safe_admission import (
    empirical_bernstein_upper_bound,
    select_empirical_bernstein_path,
)


class SafeAdmissionTests(unittest.TestCase):
    def test_empirical_bernstein_bound_is_finite_and_comparison_aware(self):
        differences = np.asarray([-1.0] * 80 + [0.0] * 20)
        _, margin_one, upper_one = empirical_bernstein_upper_bound(differences, 0.05, 1)
        _, margin_many, upper_many = empirical_bernstein_upper_bound(differences, 0.05, 5)
        self.assertTrue(np.isfinite(upper_one))
        self.assertGreaterEqual(margin_many, margin_one)
        self.assertGreaterEqual(upper_many, upper_one)

    def test_path_selector_uses_only_calibration_before_test_evaluation(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=2,
            num_classes=3,
            feature_dim=8,
            train_per_client=320,
            test_per_client=40,
            seed=91,
        )
        zero = [LoRAAdapter.zeros(8, 3, 2, alpha=2.0) for _ in clients]
        beneficial = []
        for client in clients:
            # A rank-2 approximation of the empirical class-separating update
            # is enough to create a clearly beneficial endpoint.
            class_means = np.vstack(
                [client.x_train[client.y_train == cls].mean(axis=0) for cls in range(3)]
            )
            beneficial.append(LoRAAdapter.from_delta(class_means - base_weight, rank=2, alpha=2.0))

        original_test_labels = [client.y_test.copy() for client in clients]
        result = select_empirical_bernstein_path(
            clients,
            clients,
            base_weight,
            zero,
            beneficial,
            ranks=2,
            path="0,0.5,1",
            delta=0.1,
            risk_tolerance=0.05,
            seed=0,
            dataset="debug",
            heterogeneity_setting="unit-test",
        )
        self.assertEqual(len(result.client_adapters), 2)
        self.assertEqual(len(result.admission_rows), 6)
        self.assertTrue(all(np.array_equal(client.y_test, labels) for client, labels in zip(clients, original_test_labels)))
        self.assertTrue(all(row["selection_split"] == "heldout_calibration" for row in result.admission_rows))

    def test_anchor_is_always_a_certified_fallback(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=1,
            num_classes=3,
            feature_dim=8,
            train_per_client=40,
            test_per_client=20,
            seed=92,
        )
        anchor = [LoRAAdapter.zeros(8, 3, 2, alpha=2.0)]
        harmful = [LoRAAdapter.from_delta(np.full((3, 8), 50.0), rank=2, alpha=2.0)]
        result = select_empirical_bernstein_path(
            clients,
            clients,
            base_weight,
            anchor,
            harmful,
            ranks=2,
            path="0,0.5,1",
            delta=0.05,
            risk_tolerance=0.0,
        )
        selected = [row for row in result.admission_rows if row["selected"]]
        self.assertEqual(len(selected), 1)
        self.assertEqual(selected[0]["admission_strength"], 0.0)


if __name__ == "__main__":
    unittest.main()
