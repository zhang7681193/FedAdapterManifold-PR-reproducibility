from fedadaptermanifold.baselines import run_local_lora
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.run_experiment import _train_anchor_residual_adapters


def test_residual_branch_separates_run_seed_from_method_rng_seed():
    clients, base_weight = make_synthetic_manifold_clients(
        num_clients=2,
        num_classes=3,
        feature_dim=6,
        train_per_client=16,
        test_per_client=8,
        rank=1,
        seed=1,
    )
    local = run_local_lora(
        clients,
        base_weight,
        ranks=1,
        epochs=1,
        lr=0.1,
        batch_size=8,
        seed=2,
        dataset="debug",
        heterogeneity_setting="unit-test",
        round_id=1,
    )
    _, metrics, training_rows = _train_anchor_residual_adapters(
        train_clients=clients,
        eval_clients=clients,
        base_weight=base_weight,
        anchor_adapters=local.adapters,
        fam_adapters=local.adapters,
        ranks=1,
        epochs=1,
        lr=0.1,
        lr_scale=0.5,
        batch_size=8,
        residual_rank=1,
        validation_fraction=0.25,
        validation_strategy="random",
        shrinkage_candidates="1.0",
        seed=2,
        trainer_seed_offset=70000,
        dataset="debug",
        heterogeneity_setting="unit-test",
        round_id=1,
        method="Ditto-ResidualFAM",
        anchor_source_method="Ditto-LoRA",
    )

    assert {(row["seed"], row["method_seed"]) for row in metrics} == {(2, 70002)}
    assert {(row["seed"], row["method_seed"]) for row in training_rows} == {(2, 70002)}
