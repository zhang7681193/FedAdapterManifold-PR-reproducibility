from types import SimpleNamespace

import numpy as np

from fedadaptermanifold.adapters import LoRAAdapter
from scripts.run_semantic_admission_audit import (
    _anchored_transport_path,
    _parse_transport_path_weights,
    select_residual_admission_bank,
)


def test_paired_ucb_residual_bank_requires_certified_gain_over_local():
    client = SimpleNamespace(
        client_id="client_0",
        domain="domain_0",
        x_train=np.ones((16, 1), dtype=np.float64),
        y_train=np.zeros(16, dtype=np.int64),
    )
    base_weight = np.zeros((2, 1), dtype=np.float64)
    local = LoRAAdapter.from_delta(np.zeros((2, 1), dtype=np.float64), rank=1, alpha=1.0)
    better = LoRAAdapter.from_delta(np.array([[2.0], [-2.0]]), rank=1, alpha=1.0)
    worse = LoRAAdapter.from_delta(np.array([[-2.0], [2.0]]), rank=1, alpha=1.0)

    selected, rows = select_residual_admission_bank(
        [client],
        base_weight,
        {
            "Local-LoRA": [local],
            "FedAdapterManifold-Admit": [worse],
            "FedAdapterManifold-Axis": [better],
        },
        policy="paired-ucb",
        delta=0.05,
    )

    np.testing.assert_allclose(selected[0].delta(), better.delta())
    chosen = [row for row in rows if row["selected"]]
    assert len(chosen) == 1
    assert chosen[0]["selected_adapter"] == "FedAdapterManifold-Axis"
    assert chosen[0]["paired_loss_upper_confidence_bound"] < 0.0


def test_paired_ucb_residual_bank_requires_gain_over_every_anchor():
    client = SimpleNamespace(
        client_id="client_0",
        domain="domain_0",
        x_train=np.ones((32, 1), dtype=np.float64),
        y_train=np.zeros(32, dtype=np.int64),
    )
    base_weight = np.zeros((2, 1), dtype=np.float64)
    local = LoRAAdapter.from_delta(np.zeros((2, 1), dtype=np.float64), rank=1, alpha=1.0)
    shared = LoRAAdapter.from_delta(np.array([[3.0], [-3.0]]), rank=1, alpha=1.0)
    candidate = LoRAAdapter.from_delta(np.array([[2.0], [-2.0]]), rank=1, alpha=1.0)

    selected, rows = select_residual_admission_bank(
        [client],
        base_weight,
        {
            "Local-LoRA": [local],
            "SharedAxis": [shared],
            "ProjectedCandidate": [candidate],
        },
        policy="paired-ucb",
        delta=0.05,
        certificate_anchor_names=("Local-LoRA", "SharedAxis"),
    )

    np.testing.assert_allclose(selected[0].delta(), shared.delta())
    candidate_row = next(row for row in rows if row["candidate_adapter"] == "ProjectedCandidate")
    assert candidate_row["all_anchor_ucb_certified"] is False
    assert candidate_row["worst_certificate_anchor"] == "SharedAxis"
    chosen = [row for row in rows if row["selected"]]
    assert len(chosen) == 1
    assert chosen[0]["selected_adapter"] == "SharedAxis"


def test_paired_ucb_residual_bank_admits_candidate_better_than_both_anchors():
    client = SimpleNamespace(
        client_id="client_0",
        domain="domain_0",
        x_train=np.ones((32, 1), dtype=np.float64),
        y_train=np.zeros(32, dtype=np.int64),
    )
    base_weight = np.zeros((2, 1), dtype=np.float64)
    local = LoRAAdapter.from_delta(np.zeros((2, 1), dtype=np.float64), rank=1, alpha=1.0)
    shared = LoRAAdapter.from_delta(np.array([[1.0], [-1.0]]), rank=1, alpha=1.0)
    candidate = LoRAAdapter.from_delta(np.array([[3.0], [-3.0]]), rank=1, alpha=1.0)

    selected, rows = select_residual_admission_bank(
        [client],
        base_weight,
        {
            "Local-LoRA": [local],
            "SharedAxis": [shared],
            "ProjectedCandidate": [candidate],
        },
        policy="paired-ucb",
        delta=0.05,
        certificate_anchor_names=("Local-LoRA", "SharedAxis"),
    )

    np.testing.assert_allclose(selected[0].delta(), candidate.delta())
    candidate_row = next(row for row in rows if row["candidate_adapter"] == "ProjectedCandidate")
    assert candidate_row["all_anchor_ucb_certified"] is True
    assert candidate_row["paired_loss_upper_confidence_bound"] < 0.0


def test_paired_ucb_residual_bank_uses_declared_fallback_anchor():
    client = SimpleNamespace(
        client_id="client_0",
        domain="domain_0",
        x_train=np.ones((32, 1), dtype=np.float64),
        y_train=np.zeros(32, dtype=np.int64),
    )
    base_weight = np.zeros((2, 1), dtype=np.float64)
    local = LoRAAdapter.from_delta(np.zeros((2, 1), dtype=np.float64), rank=1, alpha=1.0)
    ditto = LoRAAdapter.from_delta(np.array([[-2.0], [2.0]]), rank=1, alpha=1.0)
    uncertified = LoRAAdapter.from_delta(np.zeros((2, 1), dtype=np.float64), rank=1, alpha=1.0)

    selected, rows = select_residual_admission_bank(
        [client],
        base_weight,
        {
            "Local-LoRA": [local],
            "Ditto-LoRA": [ditto],
            "ProjectedCandidate": [uncertified],
        },
        policy="paired-ucb",
        delta=0.05,
        certificate_anchor_names=("Local-LoRA", "Ditto-LoRA"),
        fallback_anchor_name="Ditto-LoRA",
    )

    np.testing.assert_allclose(selected[0].delta(), ditto.delta())
    chosen = [row for row in rows if row["selected"]]
    assert len(chosen) == 1
    assert chosen[0]["selected_adapter"] == "Ditto-LoRA"
    assert chosen[0]["fallback_anchor_name"] == "Ditto-LoRA"


def test_anchored_transport_path_constructs_fixed_convex_candidate():
    anchor = LoRAAdapter.from_delta(np.array([[2.0], [-2.0]]), rank=1, alpha=1.0)
    transport = LoRAAdapter.from_delta(np.array([[4.0], [-4.0]]), rank=1, alpha=1.0)

    candidate = _anchored_transport_path(
        [anchor],
        [transport],
        personal_weight=0.25,
        ranks=[1],
        name_prefix="path",
    )

    np.testing.assert_allclose(candidate[0].delta(), np.array([[3.5], [-3.5]]))
    assert _parse_transport_path_weights("0.75,0.25,0.75") == (0.25, 0.75)
