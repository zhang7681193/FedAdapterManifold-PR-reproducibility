from __future__ import annotations

from types import SimpleNamespace

import numpy as np

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.signed_admissibility import (
    build_fisher_signed_tangent_candidate,
    receiver_tangent_projection,
    receiver_risk_gradient,
    exact_one_sided_discordance_p,
    select_crossfitted_semantic_endpoint,
    select_hierarchical_exact_certified_endpoint,
    select_exact_certified_signed_tangent,
    select_training_fixed_semantic_endpoint,
    select_target_pareto_signed_tangent,
    softmax_directional_curvature_bound,
)
from fedadaptermanifold.training import evaluate_adapter


def _adapter(delta: np.ndarray, rank: int = 1, name: str = "") -> LoRAAdapter:
    return LoRAAdapter.from_delta(delta, rank=rank, alpha=float(rank), name=name)


def test_receiver_tangent_projection_rejects_two_sided_normal_block():
    receiver = _adapter(np.asarray([[1.0, 0.0], [0.0, 0.0]]))
    residual = np.asarray([[0.0, 1.0], [1.0, 2.0]])
    projected = receiver_tangent_projection(residual, receiver)
    assert np.allclose(projected, np.asarray([[0.0, 1.0], [1.0, 0.0]]))


def test_softmax_directional_curvature_bound_is_nonnegative_and_scales_quadratically():
    x = np.asarray([[1.0, 2.0], [-1.0, 0.5]])
    direction = np.asarray([[0.5, -0.25], [-0.5, 0.25]])
    base = softmax_directional_curvature_bound(x, direction)
    scaled = softmax_directional_curvature_bound(x, 3.0 * direction)
    assert base > 0.0
    assert np.isclose(scaled, 9.0 * base)


def test_softmax_directional_curvature_upper_bounds_cross_entropy_path():
    rng = np.random.default_rng(17)
    x = rng.normal(size=(32, 3))
    y = rng.integers(0, 3, size=32)
    base_weight = rng.normal(scale=0.2, size=(3, 3))
    direction = np.outer(rng.normal(size=3), rng.normal(size=3))
    alpha = 0.35
    anchor = LoRAAdapter.zeros(3, 3, 1, alpha=1.0, name="anchor")
    endpoint = _adapter(alpha * direction, name="endpoint")
    base_loss = evaluate_adapter(x, y, base_weight, anchor)["loss"]
    endpoint_loss = evaluate_adapter(x, y, base_weight, endpoint)["loss"]
    gradient = receiver_risk_gradient(x, y, base_weight)
    derivative = float(np.sum(gradient * direction))
    curvature = softmax_directional_curvature_bound(x, direction)
    upper = base_loss + alpha * derivative + 0.5 * alpha * alpha * curvature
    assert endpoint_loss <= upper + 1e-12


def test_signed_tangent_step_improves_screen_risk_for_descent_direction():
    x = np.asarray([[1.0], [-1.0]])
    y = np.asarray([0, 1])
    base_weight = np.zeros((2, 1), dtype=np.float64)
    receiver = _adapter(np.asarray([[0.01], [-0.01]]))
    anchor = LoRAAdapter.zeros(1, 2, 1, alpha=1.0, name="anchor")
    source = _adapter(np.asarray([[0.5], [-0.5]]), name="source")
    candidate, diagnostics = build_fisher_signed_tangent_candidate(
        x_screen=x,
        y_screen=y,
        base_weight=base_weight,
        receiver=receiver,
        anchor=anchor,
        source=source,
        target_rank=1,
    )
    assert diagnostics.descent_direction
    assert diagnostics.selected_step > 0.0
    assert diagnostics.candidate_screen_loss < diagnostics.anchor_screen_loss
    assert np.linalg.norm(candidate.delta()) > 0.0


def test_signed_tangent_returns_exact_anchor_for_ascending_direction():
    x = np.asarray([[1.0], [-1.0]])
    y = np.asarray([0, 1])
    base_weight = np.zeros((2, 1), dtype=np.float64)
    receiver = _adapter(np.asarray([[0.01], [-0.01]]))
    anchor = LoRAAdapter.zeros(1, 2, 1, alpha=1.0, name="anchor")
    source = _adapter(np.asarray([[-0.5], [0.5]]), name="source")
    candidate, diagnostics = build_fisher_signed_tangent_candidate(
        x_screen=x,
        y_screen=y,
        base_weight=base_weight,
        receiver=receiver,
        anchor=anchor,
        source=source,
        target_rank=1,
    )
    assert not diagnostics.descent_direction
    assert diagnostics.selected_step == 0.0
    assert np.array_equal(candidate.delta(), anchor.delta())


def test_target_pareto_selector_admits_only_joint_calibration_improvement():
    x = np.asarray([[1.0], [-1.0]])
    y = np.asarray([0, 1])
    client = SimpleNamespace(
        x_train=x,
        y_train=y,
        x_test=x,
        y_test=y,
        client_id=0,
        domain="d0",
    )
    base_weight = np.zeros((2, 1), dtype=np.float64)
    local = LoRAAdapter.zeros(1, 2, 1, alpha=1.0, name="local")
    geo = _adapter(np.asarray([[-0.1], [0.1]]), name="geo")
    signed = _adapter(np.asarray([[0.5], [-0.5]]), name="signed")

    result = select_target_pareto_signed_tangent(
        selector_clients=[client],
        eval_clients=[client],
        base_weight=base_weight,
        local_adapters=[local],
        geo_adapters=[geo],
        signed_adapters=[signed],
    )

    assert result.per_client_metrics[0]["admitted_signed_tangent"]
    assert result.per_client_metrics[0]["selected_transport_family"] == "FAM-SignedTangent"
    assert result.per_client_metrics[0]["accuracy"] == 1.0
    assert all(not row["test_used_for_selection"] for row in result.admission_rows)


def test_target_pareto_selector_falls_back_exactly_for_harmful_candidate():
    x = np.asarray([[1.0], [-1.0]])
    y = np.asarray([0, 1])
    client = SimpleNamespace(
        x_train=x,
        y_train=y,
        x_test=x,
        y_test=y,
        client_id=0,
        domain="d0",
    )
    base_weight = np.zeros((2, 1), dtype=np.float64)
    local = _adapter(np.asarray([[0.5], [-0.5]]), name="local")
    geo = LoRAAdapter.zeros(1, 2, 1, alpha=1.0, name="geo")
    signed = _adapter(np.asarray([[-0.5], [0.5]]), name="signed")

    result = select_target_pareto_signed_tangent(
        selector_clients=[client],
        eval_clients=[client],
        base_weight=base_weight,
        local_adapters=[local],
        geo_adapters=[geo],
        signed_adapters=[signed],
    )

    assert not result.per_client_metrics[0]["admitted_signed_tangent"]
    assert result.per_client_metrics[0]["selected_transport_family"] == "Local-LoRA"
    assert np.array_equal(result.client_adapters[0].delta(), local.delta())


def _certificate_client(local_delta, geo_delta, fam_delta):
    x = np.eye(8, dtype=np.float64)
    y = np.zeros(8, dtype=np.int64)
    client = SimpleNamespace(
        x_train=x,
        y_train=y,
        x_test=x,
        y_test=y,
        client_id=0,
        domain="d0",
    )
    base_weight = np.zeros((2, 8), dtype=np.float64)
    return (
        client,
        base_weight,
        _adapter(local_delta, rank=2, name="local"),
        _adapter(geo_delta, rank=2, name="geo"),
        _adapter(fam_delta, rank=2, name="fam"),
    )


def test_exact_certificate_requires_six_clean_beneficial_flips_after_three_edges():
    assert exact_one_sided_discordance_p(5, 0) == 1.0 / 32.0
    assert exact_one_sided_discordance_p(6, 0) == 1.0 / 64.0
    local_delta = np.zeros((2, 8), dtype=np.float64)
    local_delta[1, :6] = 1.0
    local_delta[0, 6:] = 1.0
    fam_delta = np.zeros((2, 8), dtype=np.float64)
    fam_delta[0, :] = 1.0
    client, base_weight, local, geo, fam = _certificate_client(
        local_delta, local_delta, fam_delta
    )
    result = select_exact_certified_signed_tangent(
        selector_clients=[client],
        eval_clients=[client],
        base_weight=base_weight,
        local_adapters=[local],
        geo_adapters=[geo],
        signed_adapters=[fam],
    )
    assert result.per_client_metrics[0]["selected_transport_family"] == "FAM-ReceiverTangent"
    assert result.per_client_metrics[0]["accuracy"] == 1.0


def test_exact_certificate_records_a_training_fixed_semantic_endpoint():
    local_delta = np.zeros((2, 8), dtype=np.float64)
    local_delta[1, :6] = 1.0
    local_delta[0, 6:] = 1.0
    fam_delta = np.zeros((2, 8), dtype=np.float64)
    fam_delta[0, :] = 1.0
    client, base_weight, local, geo, fam = _certificate_client(
        local_delta, local_delta, fam_delta
    )
    result = select_exact_certified_signed_tangent(
        selector_clients=[client],
        eval_clients=[client],
        base_weight=base_weight,
        local_adapters=[local],
        geo_adapters=[geo],
        signed_adapters=[fam],
        candidate_name="FAM-SemanticEndpoint",
        candidate_training_fixed=True,
    )
    assert result.per_client_metrics[0]["selected_transport_family"] == "FAM-SemanticEndpoint"
    fam_row = next(
        row for row in result.admission_rows
        if row["candidate_method"] == "FAM-SemanticEndpoint"
    )
    assert fam_row["candidate_training_fixed"]


def test_exact_certificate_rejects_a_calibration_selected_endpoint():
    local_delta = np.zeros((2, 8), dtype=np.float64)
    client, base_weight, local, geo, fam = _certificate_client(
        local_delta, local_delta, local_delta
    )
    with np.testing.assert_raises_regex(ValueError, "training-fixed"):
        select_exact_certified_signed_tangent(
            selector_clients=[client],
            eval_clients=[client],
            base_weight=base_weight,
            local_adapters=[local],
            geo_adapters=[geo],
            signed_adapters=[fam],
            candidate_training_fixed=False,
        )


def test_exact_certificate_never_uses_uncertified_geo_as_fallback():
    local_delta = np.zeros((2, 8), dtype=np.float64)
    local_delta[0, :] = 1.0
    geo_delta = local_delta.copy()
    geo_delta[:, 0] = [0.0, 1.0]
    fam_delta = geo_delta.copy()
    client, base_weight, local, geo, fam = _certificate_client(
        local_delta, geo_delta, fam_delta
    )
    result = select_exact_certified_signed_tangent(
        selector_clients=[client],
        eval_clients=[client],
        base_weight=base_weight,
        local_adapters=[local],
        geo_adapters=[geo],
        signed_adapters=[fam],
    )
    assert result.per_client_metrics[0]["fell_back_to_local"]
    assert np.array_equal(result.client_adapters[0].A, local.A)
    assert np.array_equal(result.client_adapters[0].B, local.B)


def test_fam_must_beat_an_admitted_geo_endpoint():
    local_delta = np.zeros((2, 8), dtype=np.float64)
    local_delta[1, :7] = 1.0
    local_delta[0, 7:] = 1.0
    geo_delta = np.zeros((2, 8), dtype=np.float64)
    geo_delta[0, :6] = 1.0
    geo_delta[1, 6] = 1.0
    geo_delta[0, 7] = 1.0
    fam_delta = np.zeros((2, 8), dtype=np.float64)
    fam_delta[0, :] = 1.0
    client, base_weight, local, geo, fam = _certificate_client(
        local_delta, geo_delta, fam_delta
    )
    result = select_exact_certified_signed_tangent(
        selector_clients=[client],
        eval_clients=[client],
        base_weight=base_weight,
        local_adapters=[local],
        geo_adapters=[geo],
        signed_adapters=[fam],
    )
    assert result.per_client_metrics[0]["selected_transport_family"] == "Geo-only-Agg"
    fam_row = next(row for row in result.admission_rows if row["candidate_method"] == "FAM-ReceiverTangent")
    assert fam_row["fam_vs_local_certified"]
    assert not fam_row["fam_vs_geo_certified"]


def test_training_screen_fixes_one_generator_without_calibration_or_test_use():
    x = np.asarray([[1.0], [-1.0]])
    y = np.asarray([0, 1])
    client = SimpleNamespace(
        x_train=x,
        y_train=y,
        x_test=-x,
        y_test=y,
        client_id=0,
        domain="d0",
    )
    base_weight = np.zeros((2, 1), dtype=np.float64)
    internal = LoRAAdapter.zeros(1, 2, 1, alpha=1.0, name="internal")
    subspace_reg = _adapter(np.asarray([[0.5], [-0.5]]), name="subspace_reg")
    selected, rows = select_training_fixed_semantic_endpoint(
        training_clients=[client],
        base_weight=base_weight,
        candidate_families={
            "FAM-InternalSemanticGenerator": [internal],
            "Subspace-Reg-LoRA-Visual-Port": [subspace_reg],
        },
    )
    assert np.array_equal(selected[0].delta(), subspace_reg.delta())
    assert all(row["selection_split"] == "adapter_training" for row in rows)
    assert all(not row["calibration_used"] and not row["test_used"] for row in rows)
    assert all(len(row["candidate_sha256"]) == 64 for row in rows)


def test_crossfit_screen_maps_inner_validation_choice_to_full_training_rebuild():
    x = np.asarray([[1.0], [-1.0]])
    y = np.asarray([0, 1])
    client = SimpleNamespace(
        x_train=x,
        y_train=y,
        x_test=-x,
        y_test=y,
        client_id="c0",
        domain="d0",
    )
    base_weight = np.zeros((2, 1), dtype=np.float64)
    provisional_bad = LoRAAdapter.zeros(1, 2, 1, alpha=1.0, name="bad")
    provisional_good = _adapter(np.asarray([[0.5], [-0.5]]), name="good")
    rebuilt_bad = _adapter(np.asarray([[0.1], [-0.1]]), name="rebuilt_bad")
    rebuilt_good = _adapter(np.asarray([[0.7], [-0.7]]), name="rebuilt_good")
    selected, rows = select_crossfitted_semantic_endpoint(
        validation_clients=[client],
        base_weight=base_weight,
        provisional_candidate_families={"bad": [provisional_bad], "good": [provisional_good]},
        rebuilt_candidate_families={"bad": [rebuilt_bad], "good": [rebuilt_good]},
    )
    assert np.allclose(selected[0].delta(), rebuilt_good.delta())
    assert all(row["selection_split"] == "nested_training_validation" for row in rows)
    assert all(not row["calibration_used"] and not row["test_used"] for row in rows)
    assert all(len(row["provisional_candidate_sha256"]) == 64 for row in rows)
    assert all(len(row["rebuilt_candidate_sha256"]) == 64 for row in rows)


def test_crossfit_screen_requires_identical_generator_manifests():
    client = SimpleNamespace(
        x_train=np.asarray([[1.0]]),
        y_train=np.asarray([0]),
        x_test=np.asarray([[1.0]]),
        y_test=np.asarray([0]),
        client_id="c0",
        domain="d0",
    )
    adapter = LoRAAdapter.zeros(1, 2, 1, alpha=1.0, name="a")
    with np.testing.assert_raises_regex(ValueError, "identical names"):
        select_crossfitted_semantic_endpoint(
            validation_clients=[client],
            base_weight=np.zeros((2, 1), dtype=np.float64),
            provisional_candidate_families={"a": [adapter]},
            rebuilt_candidate_families={"b": [adapter]},
        )


def test_deduplication_recovers_single_edge_exact_power():
    local_delta = np.zeros((2, 8), dtype=np.float64)
    local_delta[1, :5] = 1.0
    local_delta[0, 5:] = 1.0
    fam_delta = np.zeros((2, 8), dtype=np.float64)
    fam_delta[0, :] = 1.0
    client, base_weight, local, geo, fam = _certificate_client(
        local_delta, local_delta, fam_delta
    )
    result = select_hierarchical_exact_certified_endpoint(
        selector_clients=[client],
        eval_clients=[client],
        base_weight=base_weight,
        local_adapters=[local],
        geo_adapters=[geo],
        semantic_adapters=[fam],
    )
    assert result.per_client_metrics[0]["selected_transport_family"] == (
        "FAM-TrainingScreenedSemanticEndpoint"
    )
    row = next(
        row for row in result.admission_rows
        if row["candidate_method"] == "FAM-TrainingScreenedSemanticEndpoint"
    )
    assert row["geo_duplicate_local"]
    assert row["primary_family_size"] == 1
    assert np.isclose(row["fam_primary_holm_threshold"], 0.05)
    assert np.isclose(row["fam_vs_local_p_value"], 1.0 / 32.0)


def test_hierarchical_exact_unresolved_candidate_returns_local_bytewise():
    local_delta = np.zeros((2, 8), dtype=np.float64)
    local_delta[0, :] = 1.0
    harmful = np.zeros((2, 8), dtype=np.float64)
    harmful[1, :] = 1.0
    client, base_weight, local, geo, fam = _certificate_client(
        local_delta, local_delta, harmful
    )
    result = select_hierarchical_exact_certified_endpoint(
        selector_clients=[client],
        eval_clients=[client],
        base_weight=base_weight,
        local_adapters=[local],
        geo_adapters=[geo],
        semantic_adapters=[fam],
    )
    assert result.per_client_metrics[0]["fell_back_to_local"]
    assert np.array_equal(result.client_adapters[0].A, local.A)
    assert np.array_equal(result.client_adapters[0].B, local.B)
