from __future__ import annotations

import numpy as np

from fedadaptermanifold.source_coverage import (
    common_descent_in_span,
    quadratic_cone_decrease_bound,
    source_coverage,
)


def test_exact_atom_coverage() -> None:
    gradient = np.array([1.0, 0.0])
    directions = np.array([[-2.0, 0.0], [0.0, 1.0]])
    result = source_coverage(gradient, directions)
    assert result.best_source == 0
    assert np.isclose(result.atom_coverage, 1.0)
    assert np.isclose(result.cone_coverage, 1.0)
    assert np.isclose(result.span_coverage, 1.0)
    assert result.positive_sources == 1


def test_cone_combines_complementary_sources() -> None:
    gradient = -np.array([1.0, 1.0])
    directions = np.eye(2)
    result = source_coverage(gradient, directions)
    assert np.isclose(result.atom_coverage, 1.0 / np.sqrt(2.0))
    assert np.isclose(result.cone_coverage, 1.0)
    assert result.active_cone_sources == 2


def test_signed_span_exposes_nonnegative_constraint_gap() -> None:
    gradient = np.array([1.0, 0.0])
    directions = np.array([[1.0, 0.0], [0.0, 1.0]])
    result = source_coverage(gradient, directions)
    assert result.best_source == -1
    assert np.isclose(result.atom_coverage, 0.0)
    assert np.isclose(result.cone_coverage, 0.0)
    assert np.isclose(result.span_coverage, 1.0)


def test_zero_gradient_has_zero_coverage() -> None:
    result = source_coverage(np.zeros(3), np.eye(3))
    assert result.gradient_norm == 0.0
    assert result.best_source == -1
    assert result.cone_coverage == 0.0


def test_quadratic_decrease_bound() -> None:
    result = source_coverage(np.array([-2.0, 0.0]), np.array([[1.0, 0.0]]))
    assert np.isclose(quadratic_cone_decrease_bound(result, smoothness=2.0), 1.0)


def test_common_descent_for_aligned_fold_gradients() -> None:
    result = common_descent_in_span(
        np.array([[1.0, 0.0], [2.0, 0.0]]),
        np.array([[1.0, 0.0]]),
    )
    assert result.feasible
    assert np.allclose(result.direction, [-1.0, 0.0])
    assert np.isclose(result.margin, 1.0)
    assert np.all(result.directional_derivatives < 0.0)


def test_common_descent_rejects_opposing_fold_gradients() -> None:
    result = common_descent_in_span(
        np.array([[1.0, 0.0], [-1.0, 0.0]]),
        np.array([[1.0, 0.0]]),
    )
    assert not result.feasible
    assert result.margin == 0.0
    assert np.allclose(result.direction, 0.0)


def test_common_descent_balances_orthogonal_fold_gradients() -> None:
    result = common_descent_in_span(np.eye(2), np.eye(2))
    assert result.feasible
    assert np.allclose(result.convex_weights, [0.5, 0.5], atol=1e-7)
    assert np.allclose(result.direction, [-1.0, -1.0] / np.sqrt(2.0), atol=1e-7)
    assert np.isclose(result.margin, 1.0 / np.sqrt(2.0), atol=1e-7)


def test_common_descent_rejects_gradient_outside_donor_span() -> None:
    result = common_descent_in_span(
        np.array([[0.0, 1.0], [0.0, 2.0]]),
        np.array([[1.0, 0.0]]),
    )
    assert not result.feasible
    assert result.span_rank == 1
