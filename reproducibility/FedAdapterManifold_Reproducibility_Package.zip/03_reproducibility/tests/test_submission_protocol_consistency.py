from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_machine_readable_protocol_matches_serial_holm_runtime() -> None:
    manifests = [
        ROOT / "paper_resubmit/candidate_pools.yaml",
        ROOT / "paper_resubmit/final_evidence_acceptance_contract.yaml",
    ]
    required = {
        "control_scope: receiver_wise",
        "procedure: Holm_step_down",
        "opened_only_if: both_distinct_primary_edges_reject",
        "example: Bonferroni_alpha_over_number_of_receivers",
    }
    for path in manifests:
        text = path.read_text(encoding="utf-8")
        assert "per_edge_alpha:" not in text
        assert required.issubset(set(line.strip() for line in text.splitlines()))

    runtime = (ROOT / "fedadaptermanifold/signed_admissibility.py").read_text(
        encoding="utf-8"
    )
    assert "deduplicate;holm_local_safety;serial_fam_vs_geo" in runtime
    assert "_holm_pareto_rejections" in runtime
    assert "secondary_opened" in runtime


def test_manuscript_states_receiverwise_not_undeclared_global_control() -> None:
    main = (ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit.tex").read_text(
        encoding="utf-8"
    )
    supplement = (
        ROOT / "paper_resubmit/fedadaptermanifold_pr_resubmit_supplement.tex"
    ).read_text(encoding="utf-8")
    assert "for each receiver, strong familywise error is at most" in main
    assert "Simultaneous control over $N$ receivers" in main
    assert "receiver-wise strong familywise control" in supplement
    assert "Bonferroni levels $\\alpha/N$" in supplement
