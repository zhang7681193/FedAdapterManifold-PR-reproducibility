from __future__ import annotations

import importlib.util
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.recent_lora_baselines import (
    orthogonal_b_full_update_aggregate,
    run_subspace_reg_lora_baseline,
    subspace_regularizer_and_grad,
    train_subspace_regularized_adapter,
)
from fedadaptermanifold.training import train_lora_adapter


def _adapter(seed: int, *, rank: int = 2) -> LoRAAdapter:
    rng = np.random.default_rng(seed)
    return LoRAAdapter(
        input_dim=4,
        output_dim=3,
        rank=rank,
        A=rng.normal(size=(rank, 4)),
        B=rng.normal(size=(3, rank)),
        alpha=float(rank),
    )


def test_regularizer_gradient_matches_finite_differences() -> None:
    adapter = _adapter(1)
    reference = _adapter(2)
    result = subspace_regularizer_and_grad(
        adapter,
        reference,
        mu=0.05,
        basis_alpha=0.01,
        lambda_reg=1e-5,
    )
    epsilon = 1e-6
    for factor_name, analytic in [("A", result.grad_a), ("B", result.grad_b)]:
        factor = getattr(adapter, factor_name)
        for index in np.ndindex(factor.shape):
            plus = adapter.copy()
            minus = adapter.copy()
            getattr(plus, factor_name)[index] += epsilon
            getattr(minus, factor_name)[index] -= epsilon
            plus_value = subspace_regularizer_and_grad(
                plus, reference, mu=0.05, basis_alpha=0.01, lambda_reg=1e-5
            ).value
            minus_value = subspace_regularizer_and_grad(
                minus, reference, mu=0.05, basis_alpha=0.01, lambda_reg=1e-5
            ).value
            numerical = (plus_value - minus_value) / (2.0 * epsilon)
            assert np.isclose(numerical, analytic[index], rtol=1e-5, atol=1e-7)


def test_server_step_matches_weighted_full_update_and_orthogonalizes_b() -> None:
    adapters = [_adapter(3), _adapter(4), _adapter(5)]
    weights = np.asarray([0.2, 0.3, 0.5])
    expected = sum(float(weight) * adapter.delta() for weight, adapter in zip(weights, adapters))
    aggregated = orthogonal_b_full_update_aggregate(adapters, weights=weights, target_rank=2)
    u, singular_values, vt = np.linalg.svd(expected, full_matrices=False)
    expected_rank_two = (u[:, :2] * singular_values[:2]) @ vt[:2, :]
    assert np.allclose(aggregated.delta(), expected_rank_two, rtol=1e-10, atol=1e-10)
    assert np.allclose(aggregated.B.T @ aggregated.B, np.eye(2), rtol=1e-10, atol=1e-10)


def test_orthogonal_b_refactorization_matches_pinned_official_source() -> None:
    import torch

    source = (
        Path(__file__).resolve().parents[1]
        / "third_party"
        / "Subspace-Constrained-Federated-learning-with-Lora"
        / "src"
        / "lora_utils.py"
    )
    if not source.is_file():
        pytest.skip(
            "pinned official source checkout is optional and is not redistributed"
        )
    spec = importlib.util.spec_from_file_location("official_subspace_lora_utils", source)
    assert spec is not None and spec.loader is not None
    official = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(official)

    adapters = [_adapter(7), _adapter(8)]
    weights = np.asarray([0.4, 0.6])
    mean_delta = sum(float(weight) * adapter.delta() for weight, adapter in zip(weights, adapters))
    ours = orthogonal_b_full_update_aggregate(adapters, weights=weights, target_rank=2)
    official_a, official_b = official.factorize_delta_orthogonal_b(
        torch.as_tensor(mean_delta, dtype=torch.float64), rank=2
    )
    official_delta = (official_b @ official_a).cpu().numpy()
    assert np.allclose(ours.delta(), official_delta, rtol=1e-6, atol=1e-7)
    assert np.allclose(
        ours.B @ ours.B.T,
        official_b.cpu().numpy() @ official_b.cpu().numpy().T,
        rtol=1e-6,
        atol=1e-7,
    )


def test_zero_specific_regularization_reduces_to_shared_visual_trainer() -> None:
    rng = np.random.default_rng(11)
    x = rng.normal(size=(18, 4))
    y = rng.integers(0, 3, size=18)
    base_weight = rng.normal(scale=0.1, size=(3, 4))
    initial = _adapter(12)
    expected, _ = train_lora_adapter(
        x,
        y,
        base_weight,
        rank=2,
        init_adapter=initial,
        epochs=3,
        lr=0.03,
        batch_size=5,
        weight_decay=1e-4,
        seed=13,
    )
    actual, _ = train_subspace_regularized_adapter(
        x,
        y,
        base_weight,
        rank=2,
        init_adapter=initial,
        global_adapter=initial,
        mu=0.0,
        basis_alpha=0.0,
        lambda_reg=0.0,
        epochs=3,
        lr=0.03,
        batch_size=5,
        weight_decay=1e-4,
        seed=13,
    )
    assert np.array_equal(actual.A, expected.A)
    assert np.array_equal(actual.B, expected.B)


def test_subspace_reg_visual_baseline_smoke() -> None:
    rng = np.random.default_rng(21)
    base_weight = rng.normal(scale=0.1, size=(3, 4))
    clients = []
    for client_id in range(3):
        x = rng.normal(loc=0.2 * client_id, size=(24, 4))
        y = rng.integers(0, 3, size=24)
        clients.append(
            SimpleNamespace(
                client_id=client_id,
                domain=f"domain_{client_id}",
                x_train=x[:16],
                y_train=y[:16],
                x_test=x[16:],
                y_test=y[16:],
            )
        )
    result = run_subspace_reg_lora_baseline(
        clients,
        base_weight,
        ranks=2,
        rounds=2,
        local_epochs=1,
        lr=0.01,
        batch_size=8,
        seed=0,
        dataset="synthetic",
        heterogeneity_setting="test",
    )
    assert len(result.per_client_metrics) == 3
    assert len(result.round_history) == 6
    assert all(row["method"] == "Subspace-Reg-LoRA-Visual-Port" for row in result.per_client_metrics)
    assert np.isfinite(result.global_adapter.delta()).all()
