import unittest
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.training import TrainStats, evaluate_weight, train_federated_global, train_lora_adapter


class LoRATrainingTests(unittest.TestCase):
    def test_lora_training_improves_separable_client(self):
        rng = np.random.default_rng(3)
        input_dim = 12
        output_dim = 3
        true_weight = rng.normal(size=(output_dim, input_dim))
        x = rng.normal(size=(180, input_dim))
        y = (x @ true_weight.T).argmax(axis=1).astype(np.int64)
        base_weight = np.zeros_like(true_weight)

        adapter, stats = train_lora_adapter(
            x,
            y,
            base_weight,
            rank=3,
            epochs=25,
            lr=0.35,
            batch_size=30,
            seed=11,
            weight_decay=0.0,
        )

        self.assertLess(stats.loss, stats.initial_loss)
        self.assertGreater(stats.accuracy, stats.initial_accuracy)
        self.assertEqual(adapter.delta().shape, base_weight.shape)
        self.assertEqual(len(stats.loss_history), 26)

    def test_base_weight_is_not_mutated(self):
        rng = np.random.default_rng(4)
        x = rng.normal(size=(40, 5))
        y = rng.integers(0, 2, size=40)
        base_weight = rng.normal(size=(2, 5))
        before = base_weight.copy()

        train_lora_adapter(x, y, base_weight, rank=2, epochs=2, seed=1)

        np.testing.assert_allclose(base_weight, before)

    def test_invalid_label_range_is_rejected(self):
        x = np.ones((4, 3))
        y = np.array([0, 1, 2, 3])
        base_weight = np.zeros((2, 3))
        with self.assertRaises(ValueError):
            train_lora_adapter(x, y, base_weight, rank=1)

    def test_evaluate_weight_reports_accuracy(self):
        x = np.eye(2)
        y = np.array([0, 1])
        weight = np.eye(2)
        metrics = evaluate_weight(x, y, weight)
        self.assertEqual(metrics["accuracy"], 1.0)

    def test_lora_training_keeps_large_feature_run_finite(self):
        rng = np.random.default_rng(12)
        x = rng.normal(scale=20.0, size=(80, 24))
        true_weight = rng.normal(size=(4, 24))
        y = (x @ true_weight.T).argmax(axis=1).astype(np.int64)
        base_weight = np.zeros_like(true_weight)

        adapter, stats = train_lora_adapter(
            x,
            y,
            base_weight,
            rank=4,
            epochs=5,
            lr=5.0,
            batch_size=16,
            seed=7,
        )

        self.assertTrue(np.isfinite(adapter.A).all())
        self.assertTrue(np.isfinite(adapter.B).all())
        self.assertTrue(np.isfinite(adapter.delta()).all())
        self.assertTrue(np.isfinite(stats.loss))

    def test_from_delta_sanitizes_nonfinite_values(self):
        delta = np.array([[np.nan, np.inf, -np.inf], [1.0, 2.0, 3.0]], dtype=np.float64)
        adapter = LoRAAdapter.from_delta(delta, rank=1)
        self.assertTrue(np.isfinite(adapter.A).all())
        self.assertTrue(np.isfinite(adapter.B).all())
        self.assertTrue(np.isfinite(adapter.delta()).all())

    def test_from_delta_preserves_scale_when_requested_rank_is_clamped(self):
        rng = np.random.default_rng(19)
        delta = rng.normal(size=(7, 12))
        adapter = LoRAAdapter.from_delta(delta, rank=8, alpha=8.0)
        self.assertEqual(adapter.rank, 7)
        np.testing.assert_allclose(adapter.delta(), delta, atol=1e-10, rtol=1e-10)

    def test_federated_clients_share_the_same_first_round_server_initialization(self):
        clients = [
            SimpleNamespace(
                x_train=np.zeros((4, 5)),
                y_train=np.zeros(4, dtype=np.int64),
                client_id=f"client_{index}",
                domain=f"domain_{index}",
            )
            for index in range(3)
        ]
        captured_a: list[np.ndarray] = []
        captured_b: list[np.ndarray] = []

        def fake_train(*args, init_adapter=None, **kwargs):
            self.assertIsNotNone(init_adapter)
            captured_a.append(init_adapter.A.copy())
            captured_b.append(init_adapter.B.copy())
            return init_adapter.copy(), TrainStats(loss=1.0, accuracy=0.0, epochs=1)

        def first_adapter(adapters, **kwargs):
            return adapters[0].copy()

        with patch("fedadaptermanifold.training.train_lora_adapter", side_effect=fake_train):
            train_federated_global(
                clients=clients,
                base_weight=np.zeros((2, 5)),
                ranks=[2, 2, 2],
                aggregate_fn=first_adapter,
                rounds=1,
                local_epochs=1,
                lr=0.1,
                batch_size=4,
                seed=13,
                name="shared_init_test",
            )

        for matrix in captured_a[1:]:
            np.testing.assert_array_equal(matrix, captured_a[0])
        for matrix in captured_b:
            np.testing.assert_array_equal(matrix, np.zeros_like(matrix))


if __name__ == "__main__":
    unittest.main()
