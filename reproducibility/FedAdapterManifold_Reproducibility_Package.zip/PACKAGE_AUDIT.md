# Pattern Recognition resubmission package audit

- Build mode: **FINAL**.
- Static validation: **PASS**.
- Final evidence status: **READY**.
- Registry SHA-256: `f7fdb34e2030c451ed437cc536ea0cb4c7371a7440211da1222886282f59cee3`.
- Frozen evidence files copied: 385.
- Machine-specific paths sanitized in: 355 text files.
- Frozen geometry snapshots: 45.
- Reproducibility tests: **299 passed, 4 skipped** (optional PyTorch parity and undistributed archived raw roots only).
- Portable frozen-evidence registry recheck: **FINAL READY**.

## Document checks

- fedadaptermanifold_pr_resubmit.pdf: 35 pages, 612.0 x 792.0 pt
- fedadaptermanifold_pr_resubmit_supplement.pdf: 73 pages, 612.0 x 792.0 pt
- PR_D_26_08222_resubmission_cover_letter.pdf: 2 pages, 612.0 x 792.0 pt
- title words: 11 (FedAdapterManifold: Deciding When Federated Visual LoRA Adapters Are Safe to Share)
- references: 51
- keywords: 6
- highlights: 5
- frozen geometry: 45 snapshots, 365 files

## Required active entries

- None.

## Errors

- None.

## Evidence policy

Only submission-eligible frozen registry entries that pass every declared file/count check are copied. Active, development, and explicitly ineligible roots cannot populate manuscript tables or the final package.
