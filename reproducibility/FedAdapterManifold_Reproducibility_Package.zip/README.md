# FedAdapterManifold

Minimal implementation of **Federated Visual Adapter Manifold Learning** for testing whether heterogeneous visual clients occupy multiple semantic adapter manifolds.

This is not a simple FedLoRA plus prototype baseline. The first diagnostic is whether adapter subspace distance correlates with FedAvg-LoRA aggregation failure. If that fails, the experiment should stop before expanding the AdapterBank story.

## What is implemented

- Frozen feature interface with:
  - NumPy image descriptor fallback.
  - Lazy `torchvision` ResNet18 extractor when `torch/torchvision` are installed.
- Feature-level synthetic PACS-style debug benchmark with four domain clients.
- LoRA classifier adapter training on frozen features.
- Local-LoRA, FedAvg-LoRA, FedAvg-Lift, Subspace-Compatible Aggregation.
- FedGeo-Diag and FedGeo-Agg baselines for separating geometry diagnostics from geometry-only aggregation.
- AdapterBank with shared adapter, domain adapters, and prototype/FedGeo-conditioned routing. This is present but the first milestone is the subspace-vs-failure diagnostic.
- Rank heterogeneity policies: fixed, random, novelty-aware, conflict-aware.
- FedGeo-compatible geometry provider:
  - Prefers `from fedgeo.interop import load_fedadaptermanifold_inputs`.
  - Falls back to the shared `geometry_outputs/*_round_{t}` files when FedGeo is not importable in local debug mode.
  - Falls back to local class-prototype geometry.
- Shared protocol outputs: `config.yaml`, `metrics.csv`, `per_client_metrics.csv`, plots, CSVs, and `geometry_outputs/*_round_{t}`.

## Minimal debug run

Use a Python 3.10+ environment with the project dependencies installed:

```powershell
python -m fedadaptermanifold.run_experiment
```

or:

```powershell
python scripts/run_minimal_debug.py
```

Step-specific debug scripts:

```powershell
python scripts/run_lora_training_debug.py
python scripts/run_local_lora_debug.py
python scripts/run_fedavg_lora_debug.py
python scripts/run_subspace_diagnostic_debug.py
python scripts/run_aggregation_methods_debug.py
python scripts/run_adapter_bank_debug.py
python scripts/run_rank_heterogeneity_debug.py
python scripts/run_rank_multiseed_debug.py
```

Expected outputs:

- `results/fedadaptermanifold/metrics.csv`
- `results/fedadaptermanifold/per_client_metrics.csv`
- `results/fedadaptermanifold/subspace_metrics.csv`
- `results/fedadaptermanifold/adapter_conflict.csv`
- `results/fedadaptermanifold/adapter_bank_weights.csv`
- `results/fedadaptermanifold/risk_metrics.csv`
- `results/fedadaptermanifold/claim_report.csv`
- `results/fedadaptermanifold/local_lora_vs_fedavg_lora_drop.csv`
- `results/fedadaptermanifold/local_lora_training_trace.csv`
- `results/fedadaptermanifold/figures/subspace_angle_heatmap.png`
- `results/fedadaptermanifold/figures/subspace_distance_vs_aggregation_failure.png`
- `results/fedadaptermanifold/figures/prototype_distance_vs_subspace_distance.png`
- `results/fedadaptermanifold/figures/adapter_bank_routing.png`
- `results/fedadaptermanifold/config.yaml`
- `results/fedadaptermanifold/geometry_outputs/client_signatures_round_0.pkl`
- `results/fedadaptermanifold/geometry_outputs/d_geo_round_0.npy`
- `results/fedadaptermanifold/geometry_outputs/geometry_graph_round_0.npy`
- `results/fedadaptermanifold/geometry_outputs/novelty_scores_round_0.csv`
- `results/fedadaptermanifold/geometry_outputs/coverage_deficit_round_0.csv`
- `results/fedadaptermanifold/geometry_outputs/prototypes_round_0.pkl`

## Receiver-decoupled dual transport

The recent-LoRA stress test separates two roles that ordinary adapter aggregation
conflates. Every client remains a donor to the shared LoRA axis, while each
receiver independently decides whether the transported update is admissible.
High training-risk receivers use a receiver-axis projection; the final candidate
is accepted only when a held-out paired upper-confidence bound is negative
against both `Local-LoRA` and `FedAdapterManifold-SharedAxisCenter`. Otherwise the
client falls back to the better calibration anchor. Test labels are never used by
the gate.

The pre-test protocol is recorded in
`configs/semantic_admission_dual_transport.yaml`. Reproduce the five-seed
DomainNetMini-60 run with the PyTorch environment:

```powershell
python scripts\run_semantic_admission_audit.py `
  --config-glob 'results\recent_lora_fairness_20260804\configs\domainnetmini_clip_60class\seed_*.yaml' `
  --output-dir 'results\recent_lora_fairness_20260804\domainnetmini_dual_transport_dualanchor_5seed' `
  --run-multiround-norisk --run-multiround-projection `
  --receiver-projection-mode axis_gauge `
  --projection-round-gate-policy candidate-trajectory `
  --projection-final-gate-policy loss-min `
  --receiver-projection-cost-mode shared-axis `
  --receiver-projection-support-mode soft-dgeo `
  --receiver-projection-knn 2 `
  --run-residual-bank --residual-bank-policy risk-route `
  --run-risk-stratified-center --force

python scripts\analyze_dual_transport.py `
  --input-dir 'results\recent_lora_fairness_20260804\domainnetmini_dual_transport_dualanchor_5seed' `
  --bootstrap-replicates 200000 --bootstrap-seed 20260804
```

The audit writes seed-level metrics, paired statistics, receiver-level deltas,
and every reconstructed dual-anchor certificate. The independent statistical
unit is the federated seed; client-seed rows are retained only for transparent
receiver-level auditing.

## YAML config

```yaml
dataset: pacs-debug
seed: 0
rounds: 3
rank: 4
train_per_client: 240
test_per_client: 160
geometry_outputs_dir: ""
round_id: 0
cpu_debug: true
heterogeneity_setting: domain-adapter-manifold-debug
```

Run:

```powershell
python -m fedadaptermanifold.run_experiment --config configs/debug.yaml --seed 1
```

## FedGeo handoff

Point the experiment at FedGeo outputs:

```powershell
python -m fedadaptermanifold.run_experiment --config configs\pacs_debug.yaml --geometry-outputs-dir path\to\geometry_outputs --round-id 0
```

Published results never follow an evolving provider directory implicitly. The
submission artifact freezes the exact geometry snapshot, round, client order,
and per-file SHA-256. An exact hash match may reuse a result; a changed distance
or prototype snapshot must replay the receiver certificate, and a changed client
order or graph support must regenerate the endpoint before certificate replay.
Build and audit that contract with:

```powershell
python scripts\build_geometry_contract_and_provider_audit.py --provider-results-root path\to\fedgeo\results
```

The command writes `geometry_snapshot_manifest.csv`,
`geometry_file_manifest.csv`, controlled perturbation checks, and actual
multi-provider comparisons under `results/geometry_contract_20260813`.

For local debug without external FedGeo, leave `geometry_outputs_dir` empty so the run builds fresh temporary geometry and writes a new `results/.../geometry_outputs` copy. Do not point `--geometry-outputs-dir` at the same output directory you are writing, because that can reuse stale geometry from an earlier run.

For seed-specific FedGeo outputs:

```powershell
python scripts\run_fedgeo_multiseed.py --config configs\pacs_debug.yaml --geometry-outputs-template path\to\fedgeo\seed_{seed}\geometry_outputs --round-id 0 --seeds 0,1,2
```

For real image-folder datasets with FedGeo outputs:

```powershell
python scripts\run_real_fedgeo_suite.py --configs 'configs\pacs_image_folder.yaml,configs\office_home_image_folder.yaml' --data-root-template 'data\{dataset}' --geometry-outputs-template 'results\fedgeo\{dataset}\seed_{seed}\geometry_outputs' --seeds 0,1,2 --round-id 0
```

Use `--dry-run` first to write `real_fedgeo_suite_plan.csv` without training. In PowerShell, quote template arguments containing `{dataset}` or `{seed}`.

Validate a FedGeo output directory before training:

```powershell
python scripts\validate_fedgeo_geometry.py --geometry-outputs-dir path\to\geometry_outputs --round-id 0
```

The multiseed runner automatically runs this validation for every non-empty `geometry_outputs_dir` / template before training.

For the local debug benchmark suite:

```powershell
python scripts\run_debug_benchmark_suite.py --seeds 0,1,2,3,4,5 --continue-on-failed-diagnostic
```

This writes:

- `suite_summary.csv`: all pooled tests.
- `suite_claim_matrix.csv`: one row per scientific claim and dataset.
- `suite_claim_report.csv`: core/supporting/caveat claim tiers with proceed/stop narrative actions.
- `suite_runs.csv`: per-dataset run status.

For component ablations:

```powershell
python scripts\run_component_ablation_suite.py --config configs\pacs_debug.yaml --seeds 0,1,2,3,4,5
```

This writes:

- `component_ablation_summary.csv`: full, client-routing, pure-feature-routing, single-bank, no-personal, no-shared, adaptive-shared, and no-geo-term comparisons.
- `component_ablation_claims.csv`: the same core/supporting/caveat claim report per ablation.
- `component_ablation_runs.csv`: per-ablation run status.

The required shared contract is:

- `client_signatures_round_{t}.pkl`
- `d_geo_round_{t}.npy`
- `geometry_graph_round_{t}.npy`
- `novelty_scores_round_{t}.csv`
- `coverage_deficit_round_{t}.csv`
- `prototypes_round_{t}.pkl`

`geometry_graph` is used as the client manifold adjacency for adapter sharing. `prototypes` are used as class-conditional adapter routing anchors. The experiment reports accuracy plus `risk_metrics.csv` for update conflict, client drift, and worst-client risk.

Current debug presets:

- Balanced default: `shared_weight: 0.35`, `personal_weight: 0.15`. This preserves accuracy gains and lowers worst-client risk/client drift.
- Real PACS image-folder preset: `configs/pacs_image_folder.yaml` uses `adapter_bank_k: 4`, `adapter_bank_routing: feature-prior-dynamic`, `shared_weight: 0.0`, and smoothing candidates up to `1.0`. The dynamic route keeps prototype-conditioned routing by default and switches to the client prior only when train loss improves by a margin. On the local PACS + FedGeo handoff run this beat FedGeo-Agg in mean accuracy, update conflict, client drift, and worst-client risk.
- Shared gate policy: `shared_weight_policy: fixed` by default. `loss-constrained` is available for ablations via `--shared-weight-policy loss-constrained --shared-weight-candidates 0,0.05,0.10,0.20,0.35`; in current debug results it strengthens PACS-style domain conflict but is not a universal replacement for fixed sharing in CIFAR-style label/domain heterogeneity.
- Default smoothing gate: `manifold_smoothing_policy: cluster-loss-constrained`. Clients in the same adapter-bank cluster share a smoothing gate selected by local train-loss tolerance, which improves update-conflict reduction without using test labels.
- Label-heavy debug preset: `configs/cifar10_debug.yaml` uses `shared_weight: 0.20`, `personal_weight: 0.20`, `manifold_smoothing_policy: fixed`. In the CIFAR-style label/domain setting, this is stronger than the PACS-balanced smoothing gate.
- Conflict-smooth sweep: `--shared-weight 0.425 --personal-weight 0.075`. This lowers graph-neighbor update conflict more strongly, but the current debug benchmark no longer gives a stable accuracy gain over FedGeo-Agg.

The graph-conflict result should be read as a Pareto tradeoff in the current PACS debug setting: strong graph smoothing reduces neighbor update distance, while personal/domain routing preserves accuracy and worst-client risk.

Important diagnostic caveat from real image-folder runs: raw Grassmannian `d_sub` and standalone FedGeo `d_geo` correlations can be dataset-dependent. Treat this as evidence that neither raw subspace angle nor visual geometry alone is the sufficient failure mechanism; the current method reports them as caveats/supporting diagnostics and uses dynamically calibrated `d_adapter_incompatibility` plus FedGeo-conditioned routing for the killer diagnostic.

The default real-data configs use `personal_weight_policy: heterogeneity-aware` instead of dataset-specific manual gates. The policy computes label entropy, label support breadth, and samples per class, then imposes a data-driven lower bound before selecting the personal adapter gate from `personal_weight_candidates` by train-loss constraint. This prevents over-sharing in sparse or label-skew settings such as DomainNetMini and CIFAR-10 without hard-coding a dataset-specific `personal_weight`.

For real CIFAR-10 batch files, use `configs/cifar10_numpy.yaml` with `--data-root` pointing at a directory containing `cifar-10-batches-py`.

Rank/resource heterogeneity is evaluated with `scripts/run_rank_policy_fedgeo_sweep.py`. Current FedGeo-backed sweeps support fixed-rank and conflict-aware rank allocation as robust proposed settings across PACS, DomainNetMini, and CIFAR-10 medium. Random and novelty-aware rank allocation are useful baselines; novelty-aware can help on CIFAR/PACS but is less stable on sparse 60-class DomainNetMini, so it should not be framed as the primary method.

## Image-folder data

For PACS/Office-Home style layouts:

```text
data_root/
  art_painting/
    class_a/*.jpg
  cartoon/
    class_a/*.jpg
```

Split folders are also detected automatically:

```text
data_root/
  art_painting/
    train/class_a/*.jpg
    test/class_a/*.jpg
  cartoon/
    train/class_a/*.jpg
    test/class_a/*.jpg
```

Run:

```powershell
python -m fedadaptermanifold.run_experiment --dataset image-folder --data-root path\to\PACS --feature-backbone numpy
```

Use `--feature-backbone resnet18` only after installing `torch` and `torchvision`.
