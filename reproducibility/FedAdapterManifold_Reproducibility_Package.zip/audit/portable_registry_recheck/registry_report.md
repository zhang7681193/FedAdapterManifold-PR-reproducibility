# Final evidence registry audit

- Frozen evidence invalid: False.
- Required experiments still active: False.
- Final submission tables ready: True.

| Entry | Status | Required | Eligible | Failures |
|---|---|---:|---:|---|
| exact_update_subspace_confirmation | frozen | True | True | -- |
| incremental_subspace_controlled | frozen | True | True | -- |
| pacs_canonical_exact_v7 | frozen | True | True | -- |
| pacs_subspace_reg_endpoint_confirmation | frozen | True | True | -- |
| official_runtime_parity | frozen | True | True | -- |
| crossdataset_exact_v3 | frozen | True | True | -- |
| crossdataset_power_v4 | frozen | True | True | -- |
| end_to_end_clip_shot4 | frozen | True | True | -- |
| end_to_end_clip_pooled_seed5to9 | frozen | True | True | -- |
| fedpissa_equation_port_crossdataset | frozen | True | True | -- |
| topology_calibrated_admission_v5 | frozen | True | True | -- |
| fedpissa_external_anchor_admission_v6 | frozen | True | True | -- |
| clip_prototype_bank_confirmation_v3 | frozen | True | True | -- |
| clip_receiver_tangent_prototype_bank_v4_development | frozen | False | False | missing:preregistered_protocol.json|missing:preregistered_protocol.sha256|missing:analysis/prototype_tangent_bank_report.md|missing:analysis/prototype_tangent_bank_summary.csv|glob_count:shot_4/seed_*/metrics.csv:0!=5|glob_count:shot_4/seed_*/per_client_metrics.csv:0!=5|glob_count:shot_4/seed_*/run_provenance.json:0!=5|glob_count:shot_4/seed_*/prototype_bank_routing.csv:0!=5|missing_csv:analysis/prototype_tangent_bank_summary.csv |
| fedalt_official_visual_port_pacs | frozen | True | True | -- |
| geometry_provider_contract | frozen | True | True | -- |
| fedpall_official_native | active | False | False | -- |
