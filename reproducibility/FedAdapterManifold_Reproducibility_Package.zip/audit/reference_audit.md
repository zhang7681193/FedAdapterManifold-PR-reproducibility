# Reference Audit

- BibTeX entries: 51
- Citation keys used: 51
- Pattern Recognition / PRL entries: 9
- Pinned preprints checked: 1

## Errors
- None

## Warnings
- None
