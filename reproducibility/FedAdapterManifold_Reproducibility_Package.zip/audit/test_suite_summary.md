# Reproducibility test summary

- Command: `python -m pytest -q -rs`
- Result: **299 passed, 4 skipped**.
- Python used for the final package audit: Python 3.10+ environment with NumPy and pytest.

The four skips are deliberate optional checks:

- one archived canonical replay whose full historical raw result roots are not redistributed in the compact artifact;
- two recent-LoRA tests that require the optional PyTorch dependency;
- one official-source parity test that requires both PyTorch and the optional pinned upstream checkout.

All portable protocol, numerical, manifest, geometry-interface, selector, statistics, and manuscript-consistency tests passed. The frozen evidence registry was also revalidated from package-relative evidence paths with `final_ready: true`.
