# FedAdapterManifold PR Reproducibility Package

This package accompanies the Pattern Recognition submission version of:

**Federated Visual LoRA Adaptation via Adapter Subspace Manifold Routing**

The package is organized around the PR positioning of the work: federated visual LoRA adaptation, adapter subspace incompatibility diagnostics, compatibility-aware adapter routing, and anchored safe composition under visual heterogeneity.

## Contents

- `fedadaptermanifold_pr_main.tex` / `fedadaptermanifold_pr_main.pdf`: PR-oriented main manuscript.
- `fedadaptermanifold_pr_supplement.tex` / `fedadaptermanifold_pr_supplement.pdf`: supplementary material.
- `fedadaptermanifold_refs.bib`: bibliography used by the manuscript.
- `configs/`: YAML configurations for audited runs and diagnostic experiments.
- `fedadaptermanifold/`: implementation code for adapter training, aggregation, diagnostics, routing, and reporting.
- `scripts/`: experiment launchers, aggregation scripts, plotting utilities, and package checks.
- `results/`: audited result roots, per-seed CSV files, summary tables, and diagnostic outputs.
- `results/fam_pr_stability_audit_v1/`: seed-stability and training-volatility audit used to constrain the final claim boundaries.
- `paper_figures/`: figure assets used in the manuscript.
- `tests/`: smoke tests and format/interface checks.

## Reproducibility Notes

The reported comparisons use fixed client splits, seeds, feature/backbone choices, geometry-output protocol, and evaluation sets within each dataset. Candidate pools for routing and anchored audits are fixed before held-out test evaluation. Calibration data, when used, is drawn from the training side or from the declared held-out client calibration fraction; test labels are used only after candidate selection.

The key distinction in the paper is adapter-level: visual geometry is used as a conditioning signal, while the core diagnostic is LoRA adapter subspace incompatibility and its relationship to FedAvg-LoRA aggregation failure.

## Environment

The implementation is CPU-debug compatible and can also use a single GPU when available. Optional pretrained visual-model runs require the dependencies listed in `requirements_optional_vfm.txt`.
