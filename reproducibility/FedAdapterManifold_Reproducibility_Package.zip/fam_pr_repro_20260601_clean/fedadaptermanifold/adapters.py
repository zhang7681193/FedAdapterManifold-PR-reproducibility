from __future__ import annotations

from dataclasses import dataclass

import numpy as np


Array = np.ndarray


@dataclass
class LoRAAdapter:
    """Low-rank update Delta W = scale * B @ A for a frozen linear head.

    Shapes follow the classifier convention:
    - A: rank x input_dim
    - B: output_dim x rank
    - Delta W: output_dim x input_dim
    """

    input_dim: int
    output_dim: int
    rank: int
    A: Array
    B: Array
    alpha: float | None = None
    name: str = ""

    def __post_init__(self) -> None:
        self.A = np.asarray(self.A, dtype=np.float64)
        self.B = np.asarray(self.B, dtype=np.float64)
        if self.A.shape != (self.rank, self.input_dim):
            raise ValueError(f"A shape {self.A.shape} != {(self.rank, self.input_dim)}")
        if self.B.shape != (self.output_dim, self.rank):
            raise ValueError(f"B shape {self.B.shape} != {(self.output_dim, self.rank)}")
        if self.alpha is None:
            self.alpha = float(max(self.rank, 1))

    @property
    def scale(self) -> float:
        return float(self.alpha) / float(max(self.rank, 1))

    @classmethod
    def zeros(
        cls,
        input_dim: int,
        output_dim: int,
        rank: int,
        alpha: float | None = None,
        name: str = "",
    ) -> "LoRAAdapter":
        return cls(
            input_dim=input_dim,
            output_dim=output_dim,
            rank=rank,
            A=np.zeros((rank, input_dim), dtype=np.float64),
            B=np.zeros((output_dim, rank), dtype=np.float64),
            alpha=alpha,
            name=name,
        )

    @classmethod
    def random(
        cls,
        input_dim: int,
        output_dim: int,
        rank: int,
        rng: np.random.Generator,
        init_scale: float = 0.02,
        alpha: float | None = None,
        name: str = "",
        zero_b: bool = True,
    ) -> "LoRAAdapter":
        a = rng.normal(0.0, init_scale, size=(rank, input_dim))
        if zero_b:
            b = np.zeros((output_dim, rank), dtype=np.float64)
        else:
            b = rng.normal(0.0, init_scale, size=(output_dim, rank))
        return cls(input_dim, output_dim, rank, a, b, alpha=alpha, name=name)

    @classmethod
    def from_delta(
        cls,
        delta: Array,
        rank: int,
        alpha: float | None = None,
        name: str = "",
    ) -> "LoRAAdapter":
        """Project a full update to a LoRA factorization by truncated SVD."""

        delta = np.asarray(delta, dtype=np.float64)
        output_dim, input_dim = delta.shape
        rank = int(max(1, min(rank, min(output_dim, input_dim))))
        delta = _finite_matrix(delta)
        try:
            u, s, vt = np.linalg.svd(delta, full_matrices=False)
        except np.linalg.LinAlgError:
            u, s, vt = _fallback_svd(delta)
        u = u[:, :rank]
        s = s[:rank]
        vt = vt[:rank, :]
        # Put singular values in B. With alpha=rank, scale is one.
        b = u * s[np.newaxis, :]
        a = vt
        return cls(input_dim, output_dim, rank, a, b, alpha=alpha, name=name)

    def copy(self, name: str | None = None) -> "LoRAAdapter":
        return LoRAAdapter(
            input_dim=self.input_dim,
            output_dim=self.output_dim,
            rank=self.rank,
            A=self.A.copy(),
            B=self.B.copy(),
            alpha=self.alpha,
            name=self.name if name is None else name,
        )

    def delta(self) -> Array:
        with np.errstate(over="ignore", invalid="ignore"):
            delta = self.scale * (self.B @ self.A)
        return _finite_matrix(delta)

    def weight(self, base_weight: Array) -> Array:
        return np.asarray(base_weight, dtype=np.float64) + self.delta()

    def projected(self, rank: int, name: str | None = None) -> "LoRAAdapter":
        return LoRAAdapter.from_delta(self.delta(), rank=rank, alpha=float(rank), name=name or self.name)

    def factor_vector(self) -> Array:
        return np.concatenate([self.A.ravel(), self.B.ravel()])


def project_delta(delta: Array, rank: int, name: str = "") -> LoRAAdapter:
    return LoRAAdapter.from_delta(delta, rank=rank, alpha=float(rank), name=name)


def pad_factors(adapter: LoRAAdapter, target_rank: int) -> tuple[Array, Array]:
    """Pad factors to a common rank for direct FedAvg-LoRA baseline."""

    if adapter.rank > target_rank:
        projected = adapter.projected(target_rank, name=adapter.name)
        return projected.A, projected.B
    a = np.zeros((target_rank, adapter.input_dim), dtype=np.float64)
    b = np.zeros((adapter.output_dim, target_rank), dtype=np.float64)
    a[: adapter.rank, :] = adapter.A * adapter.scale
    b[:, : adapter.rank] = adapter.B
    return a, b


def _finite_matrix(matrix: Array, max_abs: float = 1e6) -> Array:
    out = np.nan_to_num(np.asarray(matrix, dtype=np.float64), nan=0.0, posinf=max_abs, neginf=-max_abs)
    return np.clip(out, -max_abs, max_abs)


def _fallback_svd(delta: Array) -> tuple[Array, Array, Array]:
    """Small-output eigendecomposition fallback for ill-conditioned updates."""

    gram = _finite_matrix(delta @ delta.T)
    try:
        eigvals, u = np.linalg.eigh(gram)
    except np.linalg.LinAlgError:
        rows, cols = delta.shape
        k = min(rows, cols)
        return np.eye(rows, k, dtype=np.float64), np.zeros(k, dtype=np.float64), np.eye(k, cols, dtype=np.float64)
    order = np.argsort(np.maximum(eigvals, 0.0))[::-1]
    eigvals = np.maximum(eigvals[order], 0.0)
    u = u[:, order]
    s = np.sqrt(eigvals)
    vt = np.zeros((u.shape[1], delta.shape[1]), dtype=np.float64)
    nonzero = s > 1e-12
    vt[nonzero] = (u[:, nonzero].T @ delta) / s[nonzero, None]
    return u, s, _finite_matrix(vt)
