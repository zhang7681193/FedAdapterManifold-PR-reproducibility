from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .adapters import LoRAAdapter, pad_factors


Array = np.ndarray


def _normalized_weights(weights: Array | None, n: int) -> Array:
    if weights is None:
        out = np.ones(n, dtype=np.float64) / float(n)
    else:
        out = np.asarray(weights, dtype=np.float64)
        out = out / np.clip(out.sum(), 1e-12, None)
    return out


def fedavg_lora(
    adapters: list[LoRAAdapter],
    weights: Array | None = None,
    target_rank: int | None = None,
    name: str = "fedavg_lora",
) -> LoRAAdapter:
    """Directly average LoRA factors, preserving the known baseline flaw."""

    if not adapters:
        raise ValueError("fedavg_lora requires at least one adapter")
    n = len(adapters)
    weights = _normalized_weights(weights, n)
    target_rank = int(target_rank or max(a.rank for a in adapters))
    input_dim = adapters[0].input_dim
    output_dim = adapters[0].output_dim
    avg_a = np.zeros((target_rank, input_dim), dtype=np.float64)
    avg_b = np.zeros((output_dim, target_rank), dtype=np.float64)
    for adapter, weight in zip(adapters, weights):
        a, b = pad_factors(adapter, target_rank)
        avg_a += weight * a
        avg_b += weight * b
    return LoRAAdapter(input_dim, output_dim, target_rank, avg_a, avg_b, alpha=float(target_rank), name=name)


def fedavg_lift(
    adapters: list[LoRAAdapter],
    weights: Array | None = None,
    target_rank: int | None = None,
    name: str = "fedavg_lift",
) -> LoRAAdapter:
    """Average merged Delta W updates, then project back with SVD."""

    if not adapters:
        raise ValueError("fedavg_lift requires at least one adapter")
    n = len(adapters)
    weights = _normalized_weights(weights, n)
    target_rank = int(target_rank or max(a.rank for a in adapters))
    delta = np.zeros_like(adapters[0].delta())
    for adapter, weight in zip(adapters, weights):
        delta += weight * adapter.delta()
    return LoRAAdapter.from_delta(delta, rank=target_rank, alpha=float(target_rank), name=name)


def fedrot_lora(
    adapters: list[LoRAAdapter],
    weights: Array | None = None,
    target_rank: int | None = None,
    name: str = "fedrot_lora",
) -> LoRAAdapter:
    """FedRot-style factor averaging after orthogonal gauge alignment.

    LoRA factors are rotation/gauge ambiguous: ``B @ A == (B Q) @ (Q.T A)``
    for any orthogonal ``Q``.  This lightweight control aligns each client's
    padded factorization to the first nonzero adapter's gauge before averaging
    factors.  It tests whether rotational misalignment alone explains the
    negative transfer that FedAdapterManifold targets.
    """

    if not adapters:
        raise ValueError("fedrot_lora requires at least one adapter")
    n = len(adapters)
    weights = _normalized_weights(weights, n)
    target_rank = int(target_rank or max(a.rank for a in adapters))
    input_dim = adapters[0].input_dim
    output_dim = adapters[0].output_dim
    padded = [pad_factors(adapter, target_rank) for adapter in adapters]
    ref_idx = _reference_factor_index(padded)
    ref_a, _ = padded[ref_idx]
    avg_a = np.zeros((target_rank, input_dim), dtype=np.float64)
    avg_b = np.zeros((output_dim, target_rank), dtype=np.float64)
    for (a, b), weight in zip(padded, weights):
        q = _orthogonal_gauge_alignment(a, ref_a)
        avg_a += weight * (q.T @ a)
        avg_b += weight * (b @ q)
    return LoRAAdapter(input_dim, output_dim, target_rank, avg_a, avg_b, alpha=float(target_rank), name=name)


def _reference_factor_index(factors: list[tuple[Array, Array]]) -> int:
    norms = [float(np.linalg.norm(a) + np.linalg.norm(b)) for a, b in factors]
    return int(np.argmax(norms)) if norms else 0


def _orthogonal_gauge_alignment(source_a: Array, reference_a: Array) -> Array:
    """Return Q so that Q.T @ source_a is close to reference_a."""

    rank = int(source_a.shape[0])
    if rank == 0:
        return np.zeros((0, 0), dtype=np.float64)
    cross = np.nan_to_num(source_a @ reference_a.T, nan=0.0, posinf=0.0, neginf=0.0)
    try:
        u, _, vt = np.linalg.svd(cross, full_matrices=False)
        q = u @ vt
    except np.linalg.LinAlgError:
        q = np.eye(rank, dtype=np.float64)
    if q.shape != (rank, rank) or not np.all(np.isfinite(q)):
        q = np.eye(rank, dtype=np.float64)
    return q


def compatibility_matrix(
    d_sub: Array,
    d_geo: Array,
    d_label: Array,
    lambda_geo: float = 0.5,
    lambda_label: float = 0.25,
    tau: float = 1.0,
) -> Array:
    score = np.asarray(d_sub) + lambda_geo * np.asarray(d_geo) + lambda_label * np.asarray(d_label)
    tau = max(float(tau), 1e-8)
    compat = np.exp(-score / tau)
    np.fill_diagonal(compat, 1.0)
    return compat


def normalize_rows(matrix: Array) -> Array:
    matrix = np.asarray(matrix, dtype=np.float64)
    return matrix / np.clip(matrix.sum(axis=1, keepdims=True), 1e-12, None)


def subspace_compatible_aggregate(
    adapters: list[LoRAAdapter],
    compatibility: Array,
    target_ranks: list[int] | None = None,
) -> list[LoRAAdapter]:
    """Client-specific compatibility weighted aggregation."""

    beta = normalize_rows(compatibility)
    if target_ranks is None:
        target_ranks = [a.rank for a in adapters]
    out = []
    for i in range(len(adapters)):
        out.append(
            fedavg_lift(
                adapters,
                weights=beta[i],
                target_rank=target_ranks[i],
                name=f"subspace_compatible_client_{i}",
            )
        )
    return out


def graph_weight_matrix(
    graph: Array,
    distance: Array | None = None,
    tau: float = 1.0,
    self_weight: float = 1.0,
) -> Array:
    """Normalize FedGeo graph adjacency into client-specific sharing weights."""

    graph = np.asarray(graph, dtype=np.float64)
    if graph.ndim != 2 or graph.shape[0] != graph.shape[1]:
        raise ValueError(f"graph must be square, got {graph.shape}")
    n = graph.shape[0]
    weights = np.maximum(graph, 0.0).copy()
    np.fill_diagonal(weights, 0.0)
    if distance is not None:
        dist = np.asarray(distance, dtype=np.float64)
        if dist.shape != graph.shape:
            raise ValueError(f"distance shape {dist.shape} does not match graph {graph.shape}")
        tau = max(float(tau), 1e-8)
        weights *= np.exp(-dist / tau)
    for i in range(n):
        weights[i, i] = max(float(self_weight), weights[i, i])
        if weights[i].sum() <= 1e-12:
            weights[i, i] = 1.0
    return normalize_rows(weights)


def graph_compatible_aggregate(
    adapters: list[LoRAAdapter],
    graph: Array,
    compatibility: Array | None = None,
    distance: Array | None = None,
    target_ranks: list[int] | None = None,
    tau: float = 1.0,
    self_weight: float = 1.0,
    name_prefix: str = "graph_compatible",
) -> list[LoRAAdapter]:
    """Aggregate adapters only along the FedGeo client manifold graph."""

    weights = graph_weight_matrix(graph, distance=distance, tau=tau, self_weight=self_weight)
    if compatibility is not None:
        compat = np.asarray(compatibility, dtype=np.float64)
        if compat.shape != weights.shape:
            raise ValueError(f"compatibility shape {compat.shape} does not match graph weights {weights.shape}")
        weights = normalize_rows(weights * np.maximum(compat, 0.0))
    if target_ranks is None:
        target_ranks = [a.rank for a in adapters]
    out = []
    for i in range(len(adapters)):
        out.append(
            fedavg_lift(
                adapters,
                weights=weights[i],
                target_rank=target_ranks[i],
                name=f"{name_prefix}_client_{i}",
            )
        )
    return out


def geo_weighted_aggregate(
    adapters: list[LoRAAdapter],
    d_geo: Array,
    graph: Array | None = None,
    target_ranks: list[int] | None = None,
    tau: float = 1.0,
    self_weight: float = 1.0,
) -> list[LoRAAdapter]:
    """FedGeo-Agg: visual-geometry weighted sharing over the FedGeo graph."""

    d_geo = np.asarray(d_geo, dtype=np.float64)
    if graph is None:
        graph = np.ones_like(d_geo) - np.eye(d_geo.shape[0])
    return graph_compatible_aggregate(
        adapters,
        graph=graph,
        distance=d_geo,
        target_ranks=target_ranks,
        tau=tau,
        self_weight=self_weight,
        name_prefix="fedgeo_agg",
    )


@dataclass
class AdapterBank:
    shared_adapter: LoRAAdapter
    domain_adapters: list[LoRAAdapter]
    routing_weights: Array
    cluster_assignments: Array
    medoids: list[int]
    personal_adapters: list[LoRAAdapter] | None = None
    smoothing_adapters: list[LoRAAdapter] | None = None
    cluster_prototypes: Array | None = None
    shared_weight: float = 0.25
    personal_weight: float = 0.0
    smoothing_weight: float = 0.0
    smoothing_weights: Array | None = None
    route_tau: float = 1.0
    routing_prior_weight: float = 0.5

    def smoothing_weight_for_client(self, client_index: int) -> float:
        if self.smoothing_weights is not None:
            return float(np.clip(self.smoothing_weights[client_index], 0.0, 1.0))
        return float(np.clip(self.smoothing_weight, 0.0, 1.0))

    def delta_for_client(self, client_index: int) -> Array:
        domain_delta = np.zeros_like(self.shared_adapter.delta())
        for k, adapter in enumerate(self.domain_adapters):
            domain_delta += self.routing_weights[client_index, k] * adapter.delta()
        personal_delta = np.zeros_like(domain_delta)
        if self.personal_adapters is not None and self.personal_weight > 0.0:
            personal_delta = self.personal_adapters[client_index].delta()
        domain_weight = max(0.0, 1.0 - self.shared_weight - self.personal_weight)
        delta = (
            self.shared_weight * self.shared_adapter.delta()
            + domain_weight * domain_delta
            + self.personal_weight * personal_delta
        )
        weight = self.smoothing_weight_for_client(client_index)
        if self.smoothing_adapters is not None and weight > 0.0:
            delta = (1.0 - weight) * delta + weight * self.smoothing_adapters[client_index].delta()
        return delta

    def adapter_for_client(self, client_index: int, rank: int | None = None) -> LoRAAdapter:
        rank = int(rank or self.shared_adapter.rank)
        return LoRAAdapter.from_delta(
            self.delta_for_client(client_index),
            rank=rank,
            alpha=float(rank),
            name=f"fedadaptermanifold_client_{client_index}",
        )

    def routing_for_samples(self, x: Array, client_index: int, mode: str = "client") -> Array:
        x = np.asarray(x, dtype=np.float64)
        if mode in {"feature", "feature-prior"} and self.cluster_prototypes is not None:
            feature_route = feature_routing_weights(x, self.cluster_prototypes, tau=self.route_tau)
            if mode == "feature-prior":
                return blend_routing_with_client_prior(
                    feature_route,
                    self.routing_weights[client_index],
                    prior_weight=self.routing_prior_weight,
                )
            return feature_route
        if mode not in {"client", "feature", "feature-prior"}:
            raise ValueError(f"Unknown adapter-bank routing mode: {mode}")
        return np.repeat(self.routing_weights[client_index : client_index + 1], x.shape[0], axis=0)

    def logits_for_client(self, x: Array, base_weight: Array, client_index: int, mode: str = "client") -> Array:
        x = np.asarray(x, dtype=np.float64)
        logits = x @ np.asarray(base_weight, dtype=np.float64).T
        adapter_logits = self.shared_weight * (x @ self.shared_adapter.delta().T)
        route = self.routing_for_samples(x, client_index, mode=mode)
        domain_weight = max(0.0, 1.0 - self.shared_weight - self.personal_weight)
        for k, adapter in enumerate(self.domain_adapters):
            adapter_logits += domain_weight * route[:, k : k + 1] * (x @ adapter.delta().T)
        if self.personal_adapters is not None and self.personal_weight > 0.0:
            adapter_logits += self.personal_weight * (x @ self.personal_adapters[client_index].delta().T)
        weight = self.smoothing_weight_for_client(client_index)
        if self.smoothing_adapters is not None and weight > 0.0:
            smooth_logits = x @ self.smoothing_adapters[client_index].delta().T
            adapter_logits = (1.0 - weight) * adapter_logits + weight * smooth_logits
        return logits + adapter_logits


def build_adapter_bank(
    adapters: list[LoRAAdapter],
    d_geo: Array,
    combined_distance: Array,
    k: int,
    target_rank: int,
    route_tau: float = 1.0,
    shared_weight: float = 0.25,
    personal_weight: float = 0.0,
    cluster_prototypes: Array | None = None,
    routing_prior_weight: float = 0.5,
    personal_adapters: list[LoRAAdapter] | None = None,
    smoothing_adapters: list[LoRAAdapter] | None = None,
    smoothing_weight: float = 0.0,
    smoothing_weights: Array | None = None,
) -> AdapterBank:
    n = len(adapters)
    k = int(max(1, min(k, n)))
    medoids, assignments = k_medoids(combined_distance, k)
    sample_weights = np.ones(n, dtype=np.float64) / float(n)
    shared = fedavg_lift(adapters, weights=sample_weights, target_rank=target_rank, name="adapter_bank_shared")
    domain_adapters = []
    for cluster_id in range(k):
        members = np.flatnonzero(assignments == cluster_id)
        if members.size == 0:
            members = np.array([medoids[cluster_id]])
        weights = np.ones(members.size, dtype=np.float64) / float(members.size)
        domain_adapters.append(
            fedavg_lift(
                [adapters[int(i)] for i in members],
                weights=weights,
                target_rank=target_rank,
                name=f"adapter_bank_domain_{cluster_id}",
            )
        )
    route_dist = np.zeros((n, k), dtype=np.float64)
    for cluster_id, medoid in enumerate(medoids):
        route_dist[:, cluster_id] = combined_distance[:, medoid]
    routing = _softmax_negative(route_dist, tau=route_tau)
    personal_source = adapters if personal_adapters is None else personal_adapters
    smoothing_source = None if smoothing_adapters is None else [
        adapter.copy(name=f"adapter_bank_smoothing_{idx}") for idx, adapter in enumerate(smoothing_adapters)
    ]
    return AdapterBank(
        shared_adapter=shared,
        domain_adapters=domain_adapters,
        routing_weights=routing,
        cluster_assignments=assignments,
        medoids=medoids,
        personal_adapters=[adapter.copy(name=f"adapter_bank_personal_{idx}") for idx, adapter in enumerate(personal_source)],
        smoothing_adapters=smoothing_source,
        cluster_prototypes=cluster_prototypes,
        shared_weight=shared_weight,
        personal_weight=personal_weight,
        smoothing_weight=smoothing_weight,
        smoothing_weights=None if smoothing_weights is None else np.asarray(smoothing_weights, dtype=np.float64),
        route_tau=route_tau,
        routing_prior_weight=routing_prior_weight,
    )


def select_adapter_bank_k(
    distance: Array,
    max_k: int = 4,
    min_silhouette: float = 0.05,
) -> tuple[int, list[dict]]:
    """Select the number of adapter-bank clusters from a distance matrix.

    K=1 is the null hypothesis: one semantic adapter manifold is enough.
    For K>1 we use k-medoids plus a small-sample silhouette score and pick
    the smallest K within 95% of the best score.
    """

    distance = np.asarray(distance, dtype=np.float64)
    if distance.ndim != 2 or distance.shape[0] != distance.shape[1]:
        raise ValueError(f"distance must be square, got {distance.shape}")
    n = distance.shape[0]
    max_k = int(max(1, min(max_k, n)))
    rows = []
    null_cost = _medoid_cost(distance, np.zeros(n, dtype=np.int64), [int(np.argmin(distance.sum(axis=1)))])
    rows.append(
        {
            "candidate_k": 1,
            "silhouette": 0.0,
            "within_cluster_cost": null_cost,
            "relative_cost": 1.0,
            "selected": False,
        }
    )
    if n <= 2 or max_k <= 1:
        rows[0]["selected"] = True
        return 1, rows

    best_score = -np.inf
    candidate_rows: list[tuple[int, dict]] = []
    for k in range(2, max_k + 1):
        medoids, assignments = k_medoids(distance, k)
        silhouette = _silhouette_score(distance, assignments)
        cost = _medoid_cost(distance, assignments, medoids)
        row = {
            "candidate_k": k,
            "silhouette": silhouette,
            "within_cluster_cost": cost,
            "relative_cost": cost / max(null_cost, 1e-12),
            "selected": False,
        }
        rows.append(row)
        candidate_rows.append((k, row))
        best_score = max(best_score, silhouette)

    if not np.isfinite(best_score) or best_score < min_silhouette:
        selected = 1
    else:
        selected = min(k for k, row in candidate_rows if float(row["silhouette"]) >= 0.95 * best_score)
    for row in rows:
        row["selected"] = int(row["candidate_k"]) == selected
    return selected, rows


def k_medoids(distance: Array, k: int, iterations: int = 10) -> tuple[list[int], Array]:
    distance = np.asarray(distance, dtype=np.float64)
    n = distance.shape[0]
    if k >= n:
        return list(range(n)), np.arange(n, dtype=np.int64)
    medoids = [int(np.argmin(distance.sum(axis=1)))]
    while len(medoids) < k:
        nearest = np.min(distance[:, medoids], axis=1)
        nearest[medoids] = -1.0
        medoids.append(int(np.argmax(nearest)))
    assignments = np.zeros(n, dtype=np.int64)
    for _ in range(iterations):
        assignments = np.argmin(distance[:, medoids], axis=1).astype(np.int64)
        changed = False
        for cluster_id in range(k):
            members = np.flatnonzero(assignments == cluster_id)
            if members.size == 0:
                continue
            candidate_costs = distance[np.ix_(members, members)].sum(axis=1)
            best = int(members[np.argmin(candidate_costs)])
            if best != medoids[cluster_id]:
                medoids[cluster_id] = best
                changed = True
        if not changed:
            break
    assignments = np.argmin(distance[:, medoids], axis=1).astype(np.int64)
    return medoids, assignments


def _medoid_cost(distance: Array, assignments: Array, medoids: list[int]) -> float:
    cost = 0.0
    for i, cluster_id in enumerate(assignments):
        cost += float(distance[i, medoids[int(cluster_id)]])
    return cost / max(1, len(assignments))


def _silhouette_score(distance: Array, assignments: Array) -> float:
    distance = np.asarray(distance, dtype=np.float64)
    assignments = np.asarray(assignments, dtype=np.int64)
    n = distance.shape[0]
    if n <= 2 or np.unique(assignments).size <= 1:
        return 0.0
    scores = []
    for i in range(n):
        same = np.flatnonzero(assignments == assignments[i])
        same = same[same != i]
        if same.size == 0:
            scores.append(0.0)
            continue
        a = float(distance[i, same].mean())
        b = float("inf")
        for cluster_id in np.unique(assignments):
            if cluster_id == assignments[i]:
                continue
            other = np.flatnonzero(assignments == cluster_id)
            if other.size:
                b = min(b, float(distance[i, other].mean()))
        if not np.isfinite(b):
            scores.append(0.0)
        else:
            scores.append((b - a) / max(a, b, 1e-12))
    return float(np.mean(scores))


def _softmax_negative(distance: Array, tau: float) -> Array:
    tau = max(float(tau), 1e-8)
    logits = -np.asarray(distance, dtype=np.float64) / tau
    logits = logits - logits.max(axis=1, keepdims=True)
    exp = np.exp(logits)
    return exp / np.clip(exp.sum(axis=1, keepdims=True), 1e-12, None)


def feature_routing_weights(x: Array, cluster_prototypes: Array, tau: float = 1.0) -> Array:
    """Route each feature to the nearest semantic prototype bank."""

    x = np.asarray(x, dtype=np.float64)
    prototypes = np.asarray(cluster_prototypes, dtype=np.float64)
    if prototypes.ndim != 3:
        raise ValueError(f"cluster_prototypes must have shape K x C x D, got {prototypes.shape}")
    if x.ndim != 2 or x.shape[1] != prototypes.shape[2]:
        raise ValueError(f"x shape {x.shape} is incompatible with prototypes {prototypes.shape}")
    diff = x[:, None, None, :] - prototypes[None, :, :, :]
    class_distances = np.sqrt(np.sum(diff * diff, axis=-1))
    cluster_distances = class_distances.min(axis=2)
    return _softmax_negative(cluster_distances, tau=tau)


def blend_routing_with_client_prior(feature_route: Array, client_prior: Array, prior_weight: float = 0.5) -> Array:
    """Blend input-conditioned routing with the client geometry prior."""

    feature_route = np.asarray(feature_route, dtype=np.float64)
    prior = np.asarray(client_prior, dtype=np.float64)
    if feature_route.ndim != 2:
        raise ValueError(f"feature_route must be a 2D matrix, got {feature_route.shape}")
    if prior.shape != (feature_route.shape[1],):
        raise ValueError(f"client_prior shape {prior.shape} does not match routing width {feature_route.shape[1]}")
    weight = max(0.0, float(prior_weight))
    log_route = np.log(np.clip(feature_route, 1e-12, None)) + weight * np.log(np.clip(prior, 1e-12, None))[None, :]
    log_route = log_route - log_route.max(axis=1, keepdims=True)
    blended = np.exp(log_route)
    return blended / np.clip(blended.sum(axis=1, keepdims=True), 1e-12, None)
