from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .adapters import LoRAAdapter
from .aggregation import (
    AdapterBank,
    build_adapter_bank,
    fedavg_lift,
    fedavg_lora,
    fedrot_lora,
    geo_weighted_aggregate,
    k_medoids,
    subspace_compatible_aggregate,
)
from .training import cross_entropy_and_grad, evaluate_adapter, train_federated_global, train_lora_adapter


Array = np.ndarray


@dataclass
class LocalLoRAResult:
    adapters: list[LoRAAdapter]
    per_client_metrics: list[dict]
    training_summary: list[dict]
    training_trace: list[dict]


@dataclass
class FedAvgLoRAResult:
    global_adapter: LoRAAdapter
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class FedAvgLiftResult:
    global_adapter: LoRAAdapter
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class FedRotLoRAResult:
    global_adapter: LoRAAdapter
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class FedProxLoRAResult:
    global_adapter: LoRAAdapter
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class ScaffoldLoRAResult:
    global_adapter: LoRAAdapter
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class DittoLoRAResult:
    global_adapter: LoRAAdapter
    personal_adapters: list[LoRAAdapter]
    per_client_metrics: list[dict]
    round_history: list[dict]


@dataclass
class SubspaceCompatibleResult:
    client_adapters: list[LoRAAdapter]
    per_client_metrics: list[dict]


@dataclass
class AdapterBankResult:
    bank: AdapterBank
    client_adapters: list[LoRAAdapter]
    per_client_metrics: list[dict]
    routing_rows: list[dict]
    sample_routing_rows: list[dict]


def normalize_rank_list(ranks: list[int] | int, num_clients: int) -> list[int]:
    if isinstance(ranks, int):
        rank_list = [int(ranks) for _ in range(num_clients)]
    else:
        rank_list = [int(rank) for rank in ranks]
    if len(rank_list) != num_clients:
        raise ValueError(f"Expected {num_clients} ranks, got {len(rank_list)}")
    return rank_list


def select_loss_constrained_graph_mix(
    clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    graph_adapters: list[LoRAAdapter],
    ranks: list[int] | int,
    candidates: list[float] | str | None = None,
    tolerance: float = 0.005,
    policy: str = "loss-constrained",
) -> tuple[list[LoRAAdapter], list[dict]]:
    """Choose a per-client gate between local and graph-mixed adapters.

    The graph prior is useful only when it does not reintroduce negative transfer.
    This selector gives each client a chance to reject unsafe neighbor sharing.
    """

    rank_list = normalize_rank_list(ranks, len(clients))
    candidate_values = _parse_graph_mix_candidates(candidates)
    rows: list[dict] = []
    mixed: list[LoRAAdapter] = []
    for idx, client in enumerate(clients):
        losses = []
        adapters = []
        for candidate in candidate_values:
            adapter = _blend_adapters(
                local_adapters[idx],
                graph_adapters[idx],
                weight=float(candidate),
                rank=rank_list[idx],
                name=f"graphmix_client_{idx}_w_{float(candidate):.2f}",
            )
            metrics = evaluate_adapter(client.x_train, client.y_train, base_weight, adapter)
            losses.append(float(metrics["loss"]))
            adapters.append(adapter)
        loss_array = np.asarray(losses, dtype=np.float64)
        if policy == "loss-min":
            selected_idx = int(np.argmin(loss_array))
        elif policy == "loss-constrained":
            best = float(loss_array.min())
            allowed = best + max(0.0, float(tolerance))
            selected_idx = 0
            for candidate_idx, loss in enumerate(loss_array):
                if float(loss) <= allowed + 1e-12:
                    selected_idx = candidate_idx
        else:
            raise ValueError(f"Unknown adapter_graph_mix_policy: {policy}")
        selected_weight = float(candidate_values[selected_idx])
        mixed.append(adapters[selected_idx])
        for candidate_idx, candidate in enumerate(candidate_values):
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "adapter_graph_mix_policy": policy,
                    "candidate_graph_mix_weight": float(candidate),
                    "selected_graph_mix_weight": selected_weight,
                    "candidate_graph_mix_loss": float(loss_array[candidate_idx]),
                    "best_graph_mix_loss": float(loss_array.min()),
                    "adapter_graph_mix_tolerance": float(tolerance),
                    "selected": candidate_idx == selected_idx,
                }
            )
    return mixed, rows


def run_local_lora(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    method: str = "Local-LoRA",
    weight_decay: float = 1e-4,
) -> LocalLoRAResult:
    """Train an independent LoRA adapter per client and evaluate locally."""

    rank_list = normalize_rank_list(ranks, len(clients))

    adapters: list[LoRAAdapter] = []
    per_client_metrics: list[dict] = []
    training_summary: list[dict] = []
    training_trace: list[dict] = []

    for client_idx, client in enumerate(clients):
        adapter, stats = train_lora_adapter(
            client.x_train,
            client.y_train,
            base_weight,
            rank=rank_list[client_idx],
            epochs=epochs,
            lr=lr,
            batch_size=batch_size,
            weight_decay=weight_decay,
            seed=seed,
            name=f"local_lora_{client.client_id}",
        )
        adapters.append(adapter)
        train_metrics = evaluate_adapter(client.x_train, client.y_train, base_weight, adapter)
        test_metrics = evaluate_adapter(client.x_test, client.y_test, base_weight, adapter)
        common = {
            "method": method,
            "seed": seed,
            "dataset": dataset,
            "heterogeneity_setting": heterogeneity_setting,
            "round": round_id,
            "client_id": client.client_id,
            "domain": client.domain,
            "rank": adapter.rank,
        }
        per_client_metrics.append(
            {
                **common,
                "train_loss": train_metrics["loss"],
                "train_accuracy": train_metrics["accuracy"],
                "test_loss": test_metrics["loss"],
                "test_accuracy": test_metrics["accuracy"],
                "accuracy": test_metrics["accuracy"],
                "loss": test_metrics["loss"],
            }
        )
        training_summary.append(
            {
                **common,
                "initial_loss": stats.initial_loss,
                "final_loss": stats.loss,
                "initial_accuracy": stats.initial_accuracy,
                "final_accuracy": stats.accuracy,
                "delta_fro_norm": float(np.linalg.norm(adapter.delta())),
            }
        )
        for epoch, (loss, accuracy) in enumerate(zip(stats.loss_history or [], stats.accuracy_history or [])):
            training_trace.append(
                {
                    **common,
                    "epoch": epoch,
                    "loss": loss,
                    "accuracy": accuracy,
                }
            )

    return LocalLoRAResult(
        adapters=adapters,
        per_client_metrics=per_client_metrics,
        training_summary=training_summary,
        training_trace=training_trace,
    )


def run_fedavg_lora_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "FedAvg-LoRA",
    trainer_seed_offset: int = 300,
) -> FedAvgLoRAResult:
    """Run synchronous FedAvg-LoRA with direct factor averaging."""

    rank_list = normalize_rank_list(ranks, len(clients))

    global_adapter, raw_history = train_federated_global(
        clients,
        base_weight,
        rank_list,
        aggregate_fn=fedavg_lora,
        rounds=rounds,
        local_epochs=local_epochs,
        lr=lr,
        batch_size=batch_size,
        seed=seed + trainer_seed_offset,
        name="fedavg_lora",
    )

    per_client_metrics = evaluate_global_adapter(
        method,
        clients,
        base_weight,
        global_adapter,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=rounds,
    )

    round_history = []
    for row in raw_history:
        round_history.append(
            {
                "method": method,
                "seed": seed,
                "trainer_seed": seed + trainer_seed_offset,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                **row,
            }
        )

    return FedAvgLoRAResult(
        global_adapter=global_adapter,
        per_client_metrics=per_client_metrics,
        round_history=round_history,
    )


def run_fedavg_lift_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "FedAvg-Lift",
    trainer_seed_offset: int = 600,
) -> FedAvgLiftResult:
    """Run FedAvg-Lift: average merged Delta W updates, then SVD-project."""

    rank_list = normalize_rank_list(ranks, len(clients))
    global_adapter, raw_history = train_federated_global(
        clients,
        base_weight,
        rank_list,
        aggregate_fn=fedavg_lift,
        rounds=rounds,
        local_epochs=local_epochs,
        lr=lr,
        batch_size=batch_size,
        seed=seed + trainer_seed_offset,
        name="fedavg_lift",
    )
    per_client_metrics = evaluate_global_adapter(
        method,
        clients,
        base_weight,
        global_adapter,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=rounds,
    )
    round_history = [
        {
            "method": method,
            "seed": seed,
            "trainer_seed": seed + trainer_seed_offset,
            "dataset": dataset,
            "heterogeneity_setting": heterogeneity_setting,
            **row,
        }
        for row in raw_history
    ]
    return FedAvgLiftResult(
        global_adapter=global_adapter,
        per_client_metrics=per_client_metrics,
        round_history=round_history,
    )


def run_fedrot_lora_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    method: str = "FedRot-LoRA",
    trainer_seed_offset: int = 650,
) -> FedRotLoRAResult:
    """Run a FedRot-style rotationally aligned factor-averaging baseline."""

    rank_list = normalize_rank_list(ranks, len(clients))
    global_adapter, raw_history = train_federated_global(
        clients,
        base_weight,
        rank_list,
        aggregate_fn=fedrot_lora,
        rounds=rounds,
        local_epochs=local_epochs,
        lr=lr,
        batch_size=batch_size,
        seed=seed + trainer_seed_offset,
        name="fedrot_lora",
    )
    per_client_metrics = evaluate_global_adapter(
        method,
        clients,
        base_weight,
        global_adapter,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=rounds,
    )
    round_history = [
        {
            "method": method,
            "seed": seed,
            "trainer_seed": seed + trainer_seed_offset,
            "dataset": dataset,
            "heterogeneity_setting": heterogeneity_setting,
            **row,
        }
        for row in raw_history
    ]
    return FedRotLoRAResult(
        global_adapter=global_adapter,
        per_client_metrics=per_client_metrics,
        round_history=round_history,
    )


def run_fedprox_lora_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    prox_mu: float = 0.01,
    method: str = "FedProx-LoRA",
    trainer_seed_offset: int = 300,
) -> FedProxLoRAResult:
    """Run FedProx-LoRA with a proximal penalty to the current global adapter."""

    rank_list = normalize_rank_list(ranks, len(clients))
    global_adapter, raw_history = train_federated_global(
        clients,
        base_weight,
        rank_list,
        aggregate_fn=fedavg_lora,
        rounds=rounds,
        local_epochs=local_epochs,
        lr=lr,
        batch_size=batch_size,
        seed=seed + trainer_seed_offset,
        name="fedprox_lora",
        prox_mu=prox_mu,
    )
    per_client_metrics = evaluate_global_adapter(
        method,
        clients,
        base_weight,
        global_adapter,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=rounds,
    )
    round_history = [
        {
            "method": method,
            "seed": seed,
            "trainer_seed": seed + trainer_seed_offset,
            "dataset": dataset,
            "heterogeneity_setting": heterogeneity_setting,
            "fedprox_mu": float(prox_mu),
            **row,
        }
        for row in raw_history
    ]
    return FedProxLoRAResult(
        global_adapter=global_adapter,
        per_client_metrics=per_client_metrics,
        round_history=round_history,
    )


def run_scaffold_lora_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    control_lr: float = 1.0,
    method: str = "SCAFFOLD-LoRA",
    trainer_seed_offset: int = 1800,
) -> ScaffoldLoRAResult:
    """Run a lightweight control-variate LoRA baseline.

    The implementation keeps the same optimizer and data budget as FedAvg-LoRA,
    but corrects locally trained full updates by a server control delta before
    SVD projection.  It is intentionally conservative: it tests whether a
    drift-control FL baseline removes the need for geometry-conditioned adapter
    sharing without adding visual geometry or prototype routing.
    """

    rank_list = normalize_rank_list(ranks, len(clients))
    target_rank = int(max(rank_list))
    global_adapter = LoRAAdapter.zeros(
        input_dim=base_weight.shape[1],
        output_dim=base_weight.shape[0],
        rank=target_rank,
        alpha=float(target_rank),
        name="scaffold_global_init",
    )
    control_delta = np.zeros_like(base_weight, dtype=np.float64)
    sample_weights = np.array([len(c.y_train) for c in clients], dtype=np.float64)
    sample_weights /= np.clip(sample_weights.sum(), 1e-12, None)
    history: list[dict] = []
    control_lr = float(max(0.0, control_lr))
    for round_idx in range(int(rounds)):
        local_adapters: list[LoRAAdapter] = []
        corrected_adapters: list[LoRAAdapter] = []
        local_changes: list[Array] = []
        global_delta = global_adapter.delta()
        for client_idx, client in enumerate(clients):
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                base_weight,
                rank=rank_list[client_idx],
                init_adapter=None if round_idx == 0 else global_adapter,
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                seed=seed + trainer_seed_offset + 1000 * round_idx + client_idx,
                name=f"scaffold_lora_{client.client_id}_r{round_idx}",
            )
            local_adapters.append(adapter)
            local_delta = adapter.delta()
            local_changes.append(local_delta - global_delta)
            corrected_delta = local_delta - control_lr * control_delta
            corrected_adapters.append(
                LoRAAdapter.from_delta(
                    corrected_delta,
                    rank=rank_list[client_idx],
                    alpha=float(rank_list[client_idx]),
                    name=f"scaffold_corrected_{client.client_id}_r{round_idx}",
                )
            )
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "trainer_seed": seed + trainer_seed_offset,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": adapter.rank,
                    "control_lr": control_lr,
                    "control_delta_norm": float(np.linalg.norm(control_delta)),
                }
            )
        global_adapter = fedavg_lift(
            corrected_adapters,
            weights=sample_weights,
            target_rank=target_rank,
            name=f"scaffold_global_r{round_idx + 1}",
        )
        mean_change = np.zeros_like(control_delta)
        for weight, change in zip(sample_weights, local_changes):
            mean_change += float(weight) * change
        control_delta = 0.5 * control_delta + 0.5 * mean_change
    per_client_metrics = evaluate_global_adapter(
        method,
        clients,
        base_weight,
        global_adapter,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=rounds,
    )
    return ScaffoldLoRAResult(
        global_adapter=global_adapter,
        per_client_metrics=per_client_metrics,
        round_history=history,
    )


def run_ditto_lora_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    prox_mu: float = 0.01,
    method: str = "Ditto-LoRA",
    trainer_seed_offset: int = 1200,
) -> DittoLoRAResult:
    """Run a personalized Ditto-style LoRA baseline.

    The global branch follows FedAvg-LoRA.  Each client also maintains a
    personalized adapter trained against its local objective with a proximal
    penalty to the current global adapter.
    """

    rank_list = normalize_rank_list(ranks, len(clients))
    target_rank = int(max(rank_list))
    global_adapter = LoRAAdapter.zeros(
        input_dim=base_weight.shape[1],
        output_dim=base_weight.shape[0],
        rank=target_rank,
        alpha=float(target_rank),
        name="ditto_global_init",
    )
    personal_adapters: list[LoRAAdapter | None] = [None for _ in clients]
    sample_weights = np.array([len(c.y_train) for c in clients], dtype=np.float64)
    sample_weights /= np.clip(sample_weights.sum(), 1e-12, None)
    history: list[dict] = []
    for round_idx in range(int(rounds)):
        local_global_adapters: list[LoRAAdapter] = []
        for client_idx, client in enumerate(clients):
            global_init = None if round_idx == 0 else global_adapter
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                base_weight,
                rank=rank_list[client_idx],
                init_adapter=global_init,
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                seed=seed + trainer_seed_offset + 1000 * round_idx + client_idx,
                name=f"ditto_global_{client.client_id}_r{round_idx}",
            )
            local_global_adapters.append(adapter)
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "trainer_seed": seed + trainer_seed_offset,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "branch": "global",
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": adapter.rank,
                    "ditto_mu": float(prox_mu),
                }
            )
        global_adapter = fedavg_lora(
            local_global_adapters,
            weights=sample_weights,
            target_rank=target_rank,
            name=f"ditto_global_r{round_idx + 1}",
        )
        for client_idx, client in enumerate(clients):
            adapter, stats = train_lora_adapter(
                client.x_train,
                client.y_train,
                base_weight,
                rank=rank_list[client_idx],
                init_adapter=personal_adapters[client_idx],
                prox_adapter=global_adapter,
                prox_mu=prox_mu,
                epochs=local_epochs,
                lr=lr,
                batch_size=batch_size,
                seed=seed + trainer_seed_offset + 50000 + 1000 * round_idx + client_idx,
                name=f"ditto_personal_{client.client_id}_r{round_idx}",
            )
            personal_adapters[client_idx] = adapter
            history.append(
                {
                    "method": method,
                    "seed": seed,
                    "trainer_seed": seed + trainer_seed_offset,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_idx + 1,
                    "branch": "personal",
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "train_loss": stats.loss,
                    "train_accuracy": stats.accuracy,
                    "rank": adapter.rank,
                    "ditto_mu": float(prox_mu),
                }
            )
    final_personal_adapters = [adapter for adapter in personal_adapters if adapter is not None]
    per_client_metrics = evaluate_client_adapters(
        method,
        clients,
        base_weight,
        final_personal_adapters,
        ranks=rank_list,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=rounds,
    )
    return DittoLoRAResult(
        global_adapter=global_adapter,
        personal_adapters=final_personal_adapters,
        per_client_metrics=per_client_metrics,
        round_history=history,
    )


def run_pfedme_lora_baseline(
    clients: list,
    base_weight: Array,
    ranks: list[int] | int,
    rounds: int,
    local_epochs: int,
    lr: float,
    batch_size: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    prox_mu: float = 0.01,
    method: str = "pFedMe-LoRA",
) -> DittoLoRAResult:
    """Run a pFedMe-style proximal personalized LoRA baseline.

    In this frozen-feature adapter setting, pFedMe and Ditto both reduce to a
    personalized adapter branch regularized toward a global LoRA model.  We keep
    a separate method name and seed stream so the comparison table contains
    the expected personalized FL comparator without changing the training budget
    of the main method.
    """

    return run_ditto_lora_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=rounds,
        local_epochs=local_epochs,
        lr=lr,
        batch_size=batch_size,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        prox_mu=prox_mu,
        method=method,
        trainer_seed_offset=2200,
    )


def run_clustered_lora_baseline(
    clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    distance: Array,
    ranks: list[int] | int,
    k: int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    method: str = "Clustered-LoRA",
) -> SubspaceCompatibleResult:
    """Cluster clients in adapter-distance space and average adapters per cluster."""

    rank_list = normalize_rank_list(ranks, len(clients))
    k = int(max(1, min(k, len(clients))))
    _, assignments = k_medoids(np.asarray(distance, dtype=np.float64), k)
    cluster_adapters: dict[int, LoRAAdapter] = {}
    for cluster_id in range(k):
        member_indices = [idx for idx, value in enumerate(assignments) if int(value) == cluster_id]
        if not member_indices:
            continue
        weights = np.asarray([len(clients[idx].y_train) for idx in member_indices], dtype=np.float64)
        weights /= np.clip(weights.sum(), 1e-12, None)
        target_rank = int(max(rank_list[idx] for idx in member_indices))
        cluster_adapters[cluster_id] = fedavg_lift(
            [local_adapters[idx] for idx in member_indices],
            weights=weights,
            target_rank=target_rank,
            name=f"clustered_lora_cluster_{cluster_id}",
        )
    client_adapters = [
        cluster_adapters[int(assignments[idx])].projected(rank_list[idx], name=f"clustered_lora_client_{idx}")
        for idx in range(len(clients))
    ]
    per_client_metrics = evaluate_client_adapters(
        method,
        clients,
        base_weight,
        client_adapters,
        ranks=rank_list,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=round_id,
    )
    for row, assignment in zip(per_client_metrics, assignments):
        row["cluster_id"] = int(assignment)
        row["cluster_k"] = k
    return SubspaceCompatibleResult(client_adapters=client_adapters, per_client_metrics=per_client_metrics)


def run_fedamp_lora_baseline(
    clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    distance: Array,
    ranks: list[int] | int,
    tau: float,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    self_weight: float = 1.0,
    method: str = "FedAMP-LoRA",
) -> SubspaceCompatibleResult:
    """Adapter-similarity personalized sharing in the spirit of FedAMP."""

    rank_list = normalize_rank_list(ranks, len(clients))
    distance = np.asarray(distance, dtype=np.float64)
    tau = max(float(tau), 1e-8)
    weights = np.exp(-distance / tau)
    np.fill_diagonal(weights, max(float(self_weight), 0.0))
    weights = weights / np.clip(weights.sum(axis=1, keepdims=True), 1e-12, None)
    client_adapters = [
        fedavg_lift(
            local_adapters,
            weights=weights[idx],
            target_rank=rank_list[idx],
            name=f"fedamp_lora_client_{idx}",
        )
        for idx in range(len(clients))
    ]
    per_client_metrics = evaluate_client_adapters(
        method,
        clients,
        base_weight,
        client_adapters,
        ranks=rank_list,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=round_id,
    )
    return SubspaceCompatibleResult(client_adapters=client_adapters, per_client_metrics=per_client_metrics)


def run_fedproto_lora_baseline(
    clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    d_geo: Array,
    ranks: list[int] | int,
    tau: float,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    self_weight: float = 1.0,
    method: str = "FedProto-LoRA",
) -> SubspaceCompatibleResult:
    """Prototype-geometry adapter aggregation without adapter subspace terms.

    This is the strongest prototype-only comparator for the current protocol:
    all clients share through a visual-prototype kernel, but it does not use
    Grassmannian adapter compatibility, graph-safe gating, or adapter-bank
    routing.
    """

    rank_list = normalize_rank_list(ranks, len(clients))
    d_geo = np.asarray(d_geo, dtype=np.float64)
    tau = max(float(tau), 1e-8)
    weights = np.exp(-d_geo / tau)
    np.fill_diagonal(weights, max(float(self_weight), 0.0))
    weights = weights / np.clip(weights.sum(axis=1, keepdims=True), 1e-12, None)
    client_adapters = [
        fedavg_lift(
            local_adapters,
            weights=weights[idx],
            target_rank=rank_list[idx],
            name=f"fedproto_lora_client_{idx}",
        )
        for idx in range(len(clients))
    ]
    per_client_metrics = evaluate_client_adapters(
        method,
        clients,
        base_weight,
        client_adapters,
        ranks=rank_list,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=round_id,
    )
    return SubspaceCompatibleResult(client_adapters=client_adapters, per_client_metrics=per_client_metrics)


def run_fedper_lora_baseline(
    clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    shared_adapter: LoRAAdapter,
    ranks: list[int] | int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    candidates: list[float] | str | None = None,
    tolerance: float = 0.005,
    policy: str = "loss-constrained",
    method: str = "FedPer-LoRA",
) -> SubspaceCompatibleResult:
    """FedPer/FedRep-style shared adapter plus local personalized residual.

    The shared branch is a non-geometry global adapter.  Each client selects how
    much of its local adapter to retain using only local training loss, which
    makes this a strong personalization baseline but not a manifold method.
    """

    rank_list = normalize_rank_list(ranks, len(clients))
    candidate_values = _parse_personal_share_candidates(candidates)
    client_adapters: list[LoRAAdapter] = []
    selected_weights: list[float] = []
    for idx, client in enumerate(clients):
        losses: list[float] = []
        adapters: list[LoRAAdapter] = []
        for candidate in candidate_values:
            adapter = _blend_adapters(
                shared_adapter,
                local_adapters[idx],
                weight=float(candidate),
                rank=rank_list[idx],
                name=f"fedper_lora_client_{idx}_p_{float(candidate):.2f}",
            )
            metrics = evaluate_adapter(client.x_train, client.y_train, base_weight, adapter)
            losses.append(float(metrics["loss"]))
            adapters.append(adapter)
        loss_array = np.asarray(losses, dtype=np.float64)
        best_idx = int(np.argmin(loss_array))
        if policy == "loss-min":
            selected_idx = best_idx
        elif policy == "loss-constrained":
            allowed = float(loss_array[best_idx]) + max(0.0, float(tolerance))
            selected_idx = 0
            for candidate_idx, loss in enumerate(loss_array):
                if float(loss) <= allowed + 1e-12:
                    selected_idx = candidate_idx
        else:
            raise ValueError(f"Unknown FedPer-LoRA policy: {policy}")
        client_adapters.append(adapters[selected_idx])
        selected_weights.append(float(candidate_values[selected_idx]))
    per_client_metrics = evaluate_client_adapters(
        method,
        clients,
        base_weight,
        client_adapters,
        ranks=rank_list,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=round_id,
    )
    for row, selected_weight in zip(per_client_metrics, selected_weights):
        row["selected_personal_weight"] = selected_weight
        row["personalization_policy"] = policy
    return SubspaceCompatibleResult(client_adapters=client_adapters, per_client_metrics=per_client_metrics)


def run_subspace_compatible_baseline(
    clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    compatibility: Array,
    ranks: list[int] | int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    method: str = "Subspace-Compatible",
) -> SubspaceCompatibleResult:
    """Evaluate client-specific compatibility-weighted adapter aggregation."""

    rank_list = normalize_rank_list(ranks, len(clients))
    client_adapters = subspace_compatible_aggregate(local_adapters, compatibility, target_ranks=rank_list)
    per_client_metrics = evaluate_client_adapters(
        method,
        clients,
        base_weight,
        client_adapters,
        ranks=rank_list,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=round_id,
    )
    return SubspaceCompatibleResult(client_adapters=client_adapters, per_client_metrics=per_client_metrics)


def run_fedgeo_diag_baseline(
    clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    ranks: list[int] | int,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    method: str = "FedGeo-Diag",
) -> SubspaceCompatibleResult:
    """FedGeo diagnostic baseline: consume geometry but do not mix adapters."""

    rank_list = normalize_rank_list(ranks, len(clients))
    client_adapters = [adapter.copy(name=f"fedgeo_diag_client_{idx}") for idx, adapter in enumerate(local_adapters)]
    per_client_metrics = evaluate_client_adapters(
        method,
        clients,
        base_weight,
        client_adapters,
        ranks=rank_list,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=round_id,
    )
    return SubspaceCompatibleResult(client_adapters=client_adapters, per_client_metrics=per_client_metrics)


def run_fedgeo_agg_baseline(
    clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    d_geo: Array,
    graph: Array,
    ranks: list[int] | int,
    tau: float,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    method: str = "FedGeo-Agg",
) -> SubspaceCompatibleResult:
    """FedGeo-Agg baseline: graph-neighbor aggregation using visual geometry only."""

    rank_list = normalize_rank_list(ranks, len(clients))
    client_adapters = geo_weighted_aggregate(
        local_adapters,
        d_geo=d_geo,
        graph=graph,
        target_ranks=rank_list,
        tau=tau,
        self_weight=1.0,
    )
    per_client_metrics = evaluate_client_adapters(
        method,
        clients,
        base_weight,
        client_adapters,
        ranks=rank_list,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=round_id,
    )
    return SubspaceCompatibleResult(client_adapters=client_adapters, per_client_metrics=per_client_metrics)


def run_adapter_bank_baseline(
    clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    d_geo: Array,
    combined_distance: Array,
    ranks: list[int] | int,
    k: int,
    route_tau: float,
    shared_weight: float,
    personal_weight: float,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    personal_weight_policy: str = "fixed",
    personal_weight_tolerance: float = 0.005,
    personal_weight_candidates: list[float] | str | None = None,
    shared_weight_policy: str = "fixed",
    shared_weight_tolerance: float = 0.005,
    shared_weight_candidates: list[float] | str | None = None,
    cluster_prototypes: Array | None = None,
    routing_mode: str = "client",
    routing_prior_weight: float = 0.5,
    personal_adapters: list[LoRAAdapter] | None = None,
    smoothing_adapters: list[LoRAAdapter] | None = None,
    smoothing_weight: float = 0.0,
    smoothing_policy: str = "fixed",
    smoothing_tolerance: float = 0.005,
    smoothing_candidates: list[float] | str | None = None,
    method: str = "FedAdapterManifold",
) -> AdapterBankResult:
    """Build and evaluate the geometry-conditioned adapter bank."""

    rank_list = normalize_rank_list(ranks, len(clients))
    target_rank = int(max(rank_list))
    adaptive_smoothing = smoothing_policy in {
        "loss-constrained",
        "cluster-loss-constrained",
        "safe-loss-constrained",
        "safe-cluster-loss-constrained",
    }
    loss_routing_mode = _base_routing_mode(routing_mode)
    bank = build_adapter_bank(
        local_adapters,
        d_geo=d_geo,
        combined_distance=combined_distance,
        k=k,
        target_rank=target_rank,
        route_tau=route_tau,
        shared_weight=shared_weight,
        personal_weight=personal_weight,
        cluster_prototypes=cluster_prototypes,
        routing_prior_weight=routing_prior_weight,
        personal_adapters=personal_adapters,
        smoothing_adapters=smoothing_adapters,
        smoothing_weight=0.0 if adaptive_smoothing else smoothing_weight,
    )
    smoothing_rows: list[dict] = []
    shared_weight_rows: list[dict] = []
    personal_weight_rows: list[dict] = []
    routing_selection_rows: list[dict] = []
    if personal_weight_policy != "fixed":
        selected_personal_weight, personal_weight_rows = select_loss_constrained_personal_weight(
            clients,
            base_weight,
            bank,
            routing_mode=loss_routing_mode,
            candidates=personal_weight_candidates,
            tolerance=personal_weight_tolerance,
            policy=personal_weight_policy,
        )
        bank.personal_weight = selected_personal_weight
    if shared_weight_policy != "fixed":
        selected_shared_weight, shared_weight_rows = select_loss_constrained_shared_weight(
            clients,
            base_weight,
            bank,
            routing_mode=loss_routing_mode,
            candidates=shared_weight_candidates,
            tolerance=shared_weight_tolerance,
            policy=shared_weight_policy,
        )
        bank.shared_weight = selected_shared_weight
    if adaptive_smoothing and smoothing_adapters is not None:
        smoothing_weights, smoothing_rows = select_loss_constrained_smoothing_weights(
            clients,
            base_weight,
            bank,
            routing_mode=loss_routing_mode,
            candidates=smoothing_candidates,
            tolerance=smoothing_tolerance,
            by_cluster=smoothing_policy == "cluster-loss-constrained",
            policy=smoothing_policy,
        )
        bank.smoothing_weights = smoothing_weights
        bank.smoothing_weight = float(np.mean(smoothing_weights))
    client_adapters = [bank.adapter_for_client(i, rank=rank_list[i]) for i in range(len(clients))]
    selected_routing_modes = None
    if routing_mode == "feature-prior-dynamic":
        selected_routing_modes, routing_selection_rows = select_train_loss_routing_modes(
            clients,
            base_weight,
            bank,
            tolerance=smoothing_tolerance,
        )
    if selected_routing_modes is not None:
        per_client_metrics = evaluate_adapter_bank_dynamic_routing(
            method,
            clients,
            base_weight,
            bank,
            ranks=rank_list,
            seed=seed,
            dataset=dataset,
            heterogeneity_setting=heterogeneity_setting,
            round_id=round_id,
            selected_modes=selected_routing_modes,
        )
    elif routing_mode == "client":
        per_client_metrics = evaluate_client_adapters(
            method,
            clients,
            base_weight,
            client_adapters,
            ranks=rank_list,
            seed=seed,
            dataset=dataset,
            heterogeneity_setting=heterogeneity_setting,
            round_id=round_id,
        )
    else:
        per_client_metrics = evaluate_adapter_bank_feature_routing(
            method,
            clients,
            base_weight,
            bank,
            ranks=rank_list,
            seed=seed,
            dataset=dataset,
            heterogeneity_setting=heterogeneity_setting,
            round_id=round_id,
            routing_mode=loss_routing_mode,
        )
    routing_rows = adapter_bank_routing_rows(clients, bank)
    for row in routing_rows:
        row["smoothing_policy"] = smoothing_policy
        row["shared_weight_policy"] = shared_weight_policy
        row["personal_weight_policy"] = personal_weight_policy
        if selected_routing_modes is not None:
            row["selected_routing_mode"] = selected_routing_modes[_client_index(clients, row["client_id"])]
    sample_routing_mode = loss_routing_mode if selected_routing_modes is None else "feature-prior"
    sample_routing_rows = adapter_bank_sample_routing_rows(clients, bank, routing_mode=sample_routing_mode)
    if shared_weight_rows:
        sample_routing_rows.extend(shared_weight_rows)
    if personal_weight_rows:
        sample_routing_rows.extend(personal_weight_rows)
    if smoothing_rows:
        sample_routing_rows.extend(smoothing_rows)
    if routing_selection_rows:
        sample_routing_rows.extend(routing_selection_rows)
    return AdapterBankResult(
        bank=bank,
        client_adapters=client_adapters,
        per_client_metrics=per_client_metrics,
        routing_rows=routing_rows,
        sample_routing_rows=sample_routing_rows,
    )


def adapter_bank_routing_rows(clients: list, bank: AdapterBank | None) -> list[dict]:
    rows: list[dict] = []
    if bank is None:
        return rows
    for i, client in enumerate(clients):
        for k in range(bank.routing_weights.shape[1]):
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "bank_id": k,
                    "routing_weight": float(bank.routing_weights[i, k]),
                    "assigned_cluster": int(bank.cluster_assignments[i]),
                    "medoid_client": clients[bank.medoids[k]].client_id,
                    "shared_weight": float(bank.shared_weight),
                    "personal_weight": float(bank.personal_weight),
                    "personal_weight_policy": "",
                    "smoothing_weight": float(bank.smoothing_weight),
                    "client_smoothing_weight": float(bank.smoothing_weight_for_client(i)),
                    "routing_scope": "client",
                    "routing_prior_weight": float(bank.routing_prior_weight),
                }
            )
    return rows


def select_loss_constrained_personal_weight(
    clients: list,
    base_weight: Array,
    bank: AdapterBank,
    routing_mode: str,
    candidates: list[float] | str | None = None,
    tolerance: float = 0.005,
    policy: str = "loss-constrained",
) -> tuple[float, list[dict]]:
    """Select a personal-adapter gate from local train loss.

    This turns the personal adapter strength into an adaptive anti-over-sharing
    gate: sparse or label-skew clients choose a higher personal component only
    when it is needed to stay close to the best local training loss.
    """

    candidate_values = _parse_personal_weight_candidates(candidates, bank.personal_weight, bank.shared_weight)
    if policy == "heterogeneity-aware":
        policy_floor, policy_stats = _heterogeneity_personal_floor(clients, base_weight, bank.shared_weight, bank.personal_weight)
    else:
        policy_floor, policy_stats = 0.0, {}
    losses = []
    previous = bank.personal_weight
    try:
        for candidate in candidate_values:
            bank.personal_weight = candidate
            per_client_losses = []
            for idx, client in enumerate(clients):
                logits = bank.logits_for_client(client.x_train, base_weight, idx, mode=routing_mode)
                loss, _ = cross_entropy_and_grad(logits.copy(), client.y_train.astype(np.int64))
                per_client_losses.append(float(loss))
            losses.append(per_client_losses)
    finally:
        bank.personal_weight = previous

    loss_matrix = np.asarray(losses, dtype=np.float64)
    mean_losses = loss_matrix.mean(axis=1)
    eligible = [idx for idx, value in enumerate(candidate_values) if float(value) + 1e-12 >= policy_floor]
    if not eligible:
        eligible = [int(np.argmax(candidate_values))]
    eligible_losses = mean_losses[np.asarray(eligible, dtype=np.int64)]
    best_idx = int(eligible[int(np.argmin(eligible_losses))])
    if policy == "loss-min":
        selected_idx = best_idx
    elif policy in {"loss-constrained", "heterogeneity-aware"}:
        allowed = float(mean_losses[best_idx]) + max(0.0, float(tolerance))
        selected_idx = best_idx
        for idx in eligible:
            mean_loss = mean_losses[idx]
            if float(mean_loss) <= allowed + 1e-12:
                selected_idx = idx
                break
    elif policy == "uncertainty-constrained":
        uncertainty_penalty = _personal_weight_uncertainty_penalty(loss_matrix)
        scores = mean_losses + uncertainty_penalty * np.square(np.asarray(candidate_values, dtype=np.float64))
        eligible_scores = scores[np.asarray(eligible, dtype=np.int64)]
        best_score_idx = int(eligible[int(np.argmin(eligible_scores))])
        allowed = float(scores[best_score_idx]) + max(0.0, float(tolerance))
        selected_idx = best_score_idx
        for idx in eligible:
            if float(scores[idx]) <= allowed + 1e-12:
                selected_idx = idx
                break
    else:
        raise ValueError(f"Unknown personal_weight_policy: {policy}")
    selected = float(candidate_values[selected_idx])

    rows = []
    for candidate_idx, candidate in enumerate(candidate_values):
        for client_idx, client in enumerate(clients):
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "split": "train",
                    "bank_id": "",
                    "routing_mode": routing_mode,
                    "mean_routing_weight": "",
                    "std_routing_weight": "",
                    "assigned_cluster": int(bank.cluster_assignments[client_idx]),
                    "medoid_client": clients[bank.medoids[int(bank.cluster_assignments[client_idx])]].client_id,
                    "routing_prior_weight": float(bank.routing_prior_weight),
                    "personal_weight_policy": policy,
                    "heterogeneity_personal_floor": float(policy_floor),
                    **policy_stats,
                    "candidate_personal_weight": float(candidate),
                    "selected_personal_weight": selected,
                    "candidate_personal_loss": float(loss_matrix[candidate_idx, client_idx]),
                    "mean_candidate_personal_loss": float(mean_losses[candidate_idx]),
                    "personal_weight_uncertainty_penalty": float(
                        _personal_weight_uncertainty_penalty(loss_matrix)
                        if policy == "uncertainty-constrained"
                        else 0.0
                    ),
                    "personal_weight_tolerance": float(tolerance),
                    "selected": candidate_idx == selected_idx,
                }
            )
    return selected, rows


def _personal_weight_uncertainty_penalty(loss_matrix: Array) -> float:
    """Estimate how much loss improvement is needed to justify personalization.

    Candidate personal weights can reduce local training loss by tiny amounts
    while hurting cross-domain generalization.  We use the cross-client standard
    error as a conservative capacity penalty, so personalization is increased
    only when its mean loss gain is larger than client-level uncertainty.
    """

    losses = np.asarray(loss_matrix, dtype=np.float64)
    if losses.ndim != 2 or losses.shape[1] < 2:
        return 0.0
    per_candidate_se = losses.std(axis=1, ddof=1) / np.sqrt(float(losses.shape[1]))
    finite = per_candidate_se[np.isfinite(per_candidate_se)]
    if finite.size == 0:
        return 0.0
    return float(max(0.0, np.median(finite)))


def _heterogeneity_personal_floor(clients: list, base_weight: Array, shared_weight: float, base_personal: float) -> tuple[float, dict]:
    num_classes = int(np.asarray(base_weight).shape[0])
    entropy_values = []
    support_values = []
    samples_per_class = []
    for client in clients:
        labels = client.y_train.astype(np.int64)
        hist = np.bincount(labels, minlength=num_classes).astype(np.float64)
        total = float(hist.sum())
        probs = hist / max(total, 1.0)
        observed = probs > 0
        if observed.any() and num_classes > 1:
            entropy = -float(np.sum(probs[observed] * np.log(probs[observed]))) / float(np.log(num_classes))
        else:
            entropy = 0.0
        entropy_values.append(entropy)
        support_values.append(float(np.mean(hist > 0)))
        samples_per_class.append(total / max(float(num_classes), 1.0))

    mean_entropy = float(np.mean(entropy_values)) if entropy_values else 1.0
    mean_support = float(np.mean(support_values)) if support_values else 1.0
    mean_samples_per_class = float(np.mean(samples_per_class)) if samples_per_class else 0.0
    label_narrowness = max(0.0, 1.0 - mean_entropy)
    support_narrowness = max(0.0, 1.0 - mean_support)
    class_sparsity = max(0.0, (8.0 - mean_samples_per_class) / 8.0)
    heterogeneity_score = float(np.clip(max(label_narrowness / 0.35, support_narrowness / 0.35, class_sparsity / 0.35), 0.0, 1.0))
    max_personal = max(0.0, 1.0 - float(shared_weight))
    floor = float(np.clip(max(float(base_personal), 0.15 + 0.75 * heterogeneity_score), 0.0, max_personal))
    stats = {
        "label_entropy_mean": mean_entropy,
        "label_support_mean": mean_support,
        "samples_per_class_mean": mean_samples_per_class,
        "personal_heterogeneity_score": heterogeneity_score,
    }
    return floor, stats


def select_loss_constrained_shared_weight(
    clients: list,
    base_weight: Array,
    bank: AdapterBank,
    routing_mode: str,
    candidates: list[float] | str | None = None,
    tolerance: float = 0.005,
    policy: str = "loss-constrained",
) -> tuple[float, list[dict]]:
    """Select a global shared-adapter gate from train loss.

    The constrained policy favors the smallest shared component that stays
    close to the best local training loss, which avoids reintroducing global
    averaging conflict when multiple adapter manifolds are present.
    """

    candidate_values = _parse_shared_weight_candidates(candidates, bank.personal_weight)
    losses = []
    previous = bank.shared_weight
    try:
        for candidate in candidate_values:
            bank.shared_weight = candidate
            per_client_losses = []
            for idx, client in enumerate(clients):
                logits = bank.logits_for_client(client.x_train, base_weight, idx, mode=routing_mode)
                loss, _ = cross_entropy_and_grad(logits.copy(), client.y_train.astype(np.int64))
                per_client_losses.append(float(loss))
            losses.append(per_client_losses)
    finally:
        bank.shared_weight = previous

    loss_matrix = np.asarray(losses, dtype=np.float64)
    mean_losses = loss_matrix.mean(axis=1)
    best_idx = int(np.argmin(mean_losses))
    if policy == "loss-min":
        selected_idx = best_idx
    elif policy == "loss-constrained":
        allowed = float(mean_losses[best_idx]) + max(0.0, float(tolerance))
        selected_idx = 0
        for idx, mean_loss in enumerate(mean_losses):
            if float(mean_loss) <= allowed + 1e-12:
                selected_idx = idx
                break
    else:
        raise ValueError(f"Unknown shared_weight_policy: {policy}")
    selected = float(candidate_values[selected_idx])

    rows = []
    for candidate_idx, candidate in enumerate(candidate_values):
        for client_idx, client in enumerate(clients):
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "split": "train",
                    "bank_id": "",
                    "routing_mode": routing_mode,
                    "mean_routing_weight": "",
                    "std_routing_weight": "",
                    "assigned_cluster": int(bank.cluster_assignments[client_idx]),
                    "medoid_client": clients[bank.medoids[int(bank.cluster_assignments[client_idx])]].client_id,
                    "routing_prior_weight": float(bank.routing_prior_weight),
                    "shared_weight_policy": policy,
                    "candidate_shared_weight": float(candidate),
                    "selected_shared_weight": selected,
                    "candidate_shared_loss": float(loss_matrix[candidate_idx, client_idx]),
                    "mean_candidate_shared_loss": float(mean_losses[candidate_idx]),
                    "shared_weight_tolerance": float(tolerance),
                    "selected": candidate_idx == selected_idx,
                }
            )
    return selected, rows


def select_loss_constrained_smoothing_weights(
    clients: list,
    base_weight: Array,
    bank: AdapterBank,
    routing_mode: str,
    candidates: list[float] | str | None = None,
    tolerance: float = 0.005,
    by_cluster: bool = False,
    policy: str = "loss-constrained",
) -> tuple[Array, list[dict]]:
    """Choose a smoothing gate allowed by local train loss.

    The global safe variant asks whether the FedGeo-Agg endpoint is
    statistically indistinguishable from the best train-loss candidate. The
    cluster-safe variant makes that fallback decision per adapter manifold, so
    one saturated cluster does not suppress useful graph sharing elsewhere.
    """

    if bank.smoothing_adapters is None:
        return np.zeros(len(clients), dtype=np.float64), []
    candidate_values = _parse_smoothing_candidates(candidates)
    if policy in {"safe-loss-constrained", "safe-cluster-loss-constrained"} and 1.0 not in candidate_values:
        candidate_values.append(1.0)
        candidate_values = sorted(candidate_values)
    n = len(clients)
    chosen = np.zeros(n, dtype=np.float64)
    loss_matrix = np.zeros((n, len(candidate_values)), dtype=np.float64)
    rows: list[dict] = []
    previous = bank.smoothing_weights
    bank.smoothing_weights = np.zeros(n, dtype=np.float64)
    try:
        for idx, client in enumerate(clients):
            for candidate_idx, candidate in enumerate(candidate_values):
                bank.smoothing_weights[idx] = candidate
                logits = bank.logits_for_client(client.x_train, base_weight, idx, mode=routing_mode)
                loss, _ = cross_entropy_and_grad(logits.copy(), client.y_train.astype(np.int64))
                loss_matrix[idx, candidate_idx] = float(loss)
            bank.smoothing_weights[idx] = 0.0

        safe_idx = int(np.argmax(candidate_values))
        safe_fallback_mask = np.zeros(n, dtype=bool)
        if policy == "safe-loss-constrained":
            best_idx = int(np.argmin(loss_matrix.mean(axis=0)))
            best_losses = loss_matrix[:, best_idx]
            safe_losses = loss_matrix[:, safe_idx]
            delta = safe_losses - best_losses
            delta_se = float(delta.std(ddof=1) / np.sqrt(float(n))) if n > 1 else 0.0
            allowed_delta = max(0.0, float(tolerance)) + max(0.0, delta_se)
            if float(delta.mean()) <= allowed_delta + 1e-12:
                chosen[:] = candidate_values[safe_idx]
                safe_fallback_mask[:] = True

        fallback_by_cluster = by_cluster or policy == "safe-cluster-loss-constrained"
        if policy == "safe-cluster-loss-constrained":
            for cluster_id in np.unique(bank.cluster_assignments):
                members = np.flatnonzero(bank.cluster_assignments == cluster_id)
                cluster_losses = loss_matrix[members]
                best_idx = int(np.argmin(cluster_losses.mean(axis=0)))
                best_losses = cluster_losses[:, best_idx]
                safe_losses = cluster_losses[:, safe_idx]
                delta = safe_losses - best_losses
                delta_se = float(delta.std(ddof=1) / np.sqrt(float(members.size))) if members.size > 1 else 0.0
                allowed_delta = max(0.0, float(tolerance)) + max(0.0, delta_se)
                if float(delta.mean()) <= allowed_delta + 1e-12:
                    chosen[members] = candidate_values[safe_idx]
                    safe_fallback_mask[members] = True
                    continue

                base_losses = loss_matrix[members, 0]
                selected_idx = 0
                for candidate_idx in range(len(candidate_values)):
                    losses = loss_matrix[members, candidate_idx]
                    mean_ok = float(losses.mean()) <= float(base_losses.mean()) + max(0.0, float(tolerance)) + 1e-12
                    max_ok = float(np.max(losses - base_losses)) <= 2.0 * max(0.0, float(tolerance)) + 1e-12
                    if mean_ok and max_ok:
                        selected_idx = candidate_idx
                chosen[members] = candidate_values[selected_idx]
        elif np.all(safe_fallback_mask):
            pass
        elif fallback_by_cluster:
            for cluster_id in np.unique(bank.cluster_assignments):
                members = np.flatnonzero(bank.cluster_assignments == cluster_id)
                base_losses = loss_matrix[members, 0]
                selected_idx = 0
                for candidate_idx in range(len(candidate_values)):
                    losses = loss_matrix[members, candidate_idx]
                    mean_ok = float(losses.mean()) <= float(base_losses.mean()) + max(0.0, float(tolerance)) + 1e-12
                    max_ok = float(np.max(losses - base_losses)) <= 2.0 * max(0.0, float(tolerance)) + 1e-12
                    if mean_ok and max_ok:
                        selected_idx = candidate_idx
                chosen[members] = candidate_values[selected_idx]
        else:
            for idx in range(n):
                base_loss = loss_matrix[idx, 0]
                allowed = base_loss + max(0.0, float(tolerance))
                selected_idx = 0
                for candidate_idx, loss in enumerate(loss_matrix[idx]):
                    if loss <= allowed + 1e-12:
                        selected_idx = candidate_idx
                chosen[idx] = candidate_values[selected_idx]

        bank.smoothing_weights = chosen.copy()
        for idx, client in enumerate(clients):
            selected = float(chosen[idx])
            selected_idx = candidate_values.index(selected)
            base_loss = float(loss_matrix[idx, 0])
            selected_loss = float(loss_matrix[idx, selected_idx])
            cluster_id = int(bank.cluster_assignments[idx])
            medoid_client = clients[bank.medoids[cluster_id]].client_id
            for candidate_idx, candidate in enumerate(candidate_values):
                rows.append(
                    {
                        "client_id": client.client_id,
                        "domain": client.domain,
                        "split": "train",
                        "bank_id": "",
                        "routing_mode": routing_mode,
                        "mean_routing_weight": "",
                        "std_routing_weight": "",
                        "assigned_cluster": cluster_id,
                        "medoid_client": medoid_client,
                        "routing_prior_weight": float(bank.routing_prior_weight),
                        "smoothing_policy": policy,
                        "candidate_smoothing_weight": float(candidate),
                        "candidate_smoothing_loss": float(loss_matrix[idx, candidate_idx]),
                        "selected_smoothing_weight": float(selected),
                        "base_smoothing_loss": base_loss,
                        "selected_smoothing_loss": selected_loss,
                        "safe_smoothing_fallback": bool(safe_fallback_mask[idx]),
                        "smoothing_tolerance": float(tolerance),
                        "selected": candidate_idx == selected_idx,
                    }
                )
    finally:
        bank.smoothing_weights = previous
    return chosen, rows


def _parse_smoothing_candidates(candidates: list[float] | str | None) -> list[float]:
    if candidates is None:
        values = [0.0, 0.05, 0.10, 0.15, 0.20, 0.30, 0.40]
    elif isinstance(candidates, str):
        values = [float(part.strip()) for part in candidates.split(",") if part.strip()]
    else:
        values = [float(value) for value in candidates]
    values = sorted({float(np.clip(value, 0.0, 1.0)) for value in values})
    if not values or values[0] != 0.0:
        values.insert(0, 0.0)
    return values


def _parse_graph_mix_candidates(candidates: list[float] | str | None) -> list[float]:
    if candidates is None:
        values = [0.0, 0.25, 0.50, 0.75, 1.0]
    elif isinstance(candidates, str):
        values = [float(part.strip()) for part in candidates.split(",") if part.strip()]
    else:
        values = [float(value) for value in candidates]
    values = sorted({float(np.clip(value, 0.0, 1.0)) for value in values})
    if not values or values[0] != 0.0:
        values.insert(0, 0.0)
    return values


def _parse_personal_share_candidates(candidates: list[float] | str | None) -> list[float]:
    if candidates is None or candidates == "":
        values = [0.0, 0.25, 0.50, 0.75, 1.0]
    elif isinstance(candidates, str):
        values = [float(part.strip()) for part in candidates.split(",") if part.strip()]
    else:
        values = [float(value) for value in candidates]
    values = sorted({float(np.clip(value, 0.0, 1.0)) for value in values})
    if not values or values[0] != 0.0:
        values.insert(0, 0.0)
    if values[-1] != 1.0:
        values.append(1.0)
    return values


def _blend_adapters(
    local_adapter: LoRAAdapter,
    graph_adapter: LoRAAdapter,
    weight: float,
    rank: int,
    name: str,
) -> LoRAAdapter:
    weight = float(np.clip(weight, 0.0, 1.0))
    delta = (1.0 - weight) * local_adapter.delta() + weight * graph_adapter.delta()
    return LoRAAdapter.from_delta(delta, rank=int(rank), alpha=float(rank), name=name)


def _parse_personal_weight_candidates(
    candidates: list[float] | str | None,
    personal_weight: float,
    shared_weight: float,
) -> list[float]:
    max_personal = max(0.0, 1.0 - float(shared_weight))
    if candidates is None or candidates == "":
        values = [float(personal_weight), 0.30, 0.50, 0.70, 0.90, max_personal]
    elif isinstance(candidates, str):
        values = [float(part.strip()) for part in candidates.split(",") if part.strip()]
    else:
        values = [float(value) for value in candidates]
    values = sorted({float(np.clip(value, 0.0, max_personal)) for value in values})
    if not values:
        values = [float(np.clip(personal_weight, 0.0, max_personal))]
    return values


def _parse_shared_weight_candidates(candidates: list[float] | str | None, personal_weight: float) -> list[float]:
    max_shared = max(0.0, 1.0 - float(personal_weight))
    if candidates is None or candidates == "":
        values = [0.0, 0.05, 0.10, 0.15, 0.20, 0.30, min(0.35, max_shared)]
    elif isinstance(candidates, str):
        values = [float(part.strip()) for part in candidates.split(",") if part.strip()]
    else:
        values = [float(value) for value in candidates]
    values = sorted({float(np.clip(value, 0.0, max_shared)) for value in values})
    if not values or values[0] != 0.0:
        values.insert(0, 0.0)
    return values


def select_train_loss_routing_modes(
    clients: list,
    base_weight: Array,
    bank: AdapterBank,
    tolerance: float = 0.005,
    confidence_threshold: float = 0.75,
) -> tuple[list[str], list[dict]]:
    """Select feature-prior or client-prior routing per client from train loss.

    The dynamic gate keeps prototype-conditioned routing when it clearly helps,
    but falls back to the safer client prior when the train loss is comparable.
    """

    selected_modes: list[str] = []
    rows: list[dict] = []
    margin = max(0.0, float(tolerance))
    for idx, client in enumerate(clients):
        losses: dict[str, float] = {}
        for mode in ["feature-prior", "client"]:
            logits = bank.logits_for_client(client.x_train, base_weight, idx, mode=mode)
            loss, _ = cross_entropy_and_grad(logits.copy(), client.y_train.astype(np.int64))
            losses[mode] = float(loss)
        feature_route = bank.routing_for_samples(client.x_train, idx, mode="feature")
        feature_confidence = float(np.mean(np.max(feature_route, axis=1))) if feature_route.size else 0.0
        if losses["feature-prior"] + margin < losses["client"]:
            selected = "feature-prior"
        else:
            selected = "client"
        selected_modes.append(selected)
        for mode in ["feature-prior", "client"]:
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "split": "train",
                    "bank_id": "",
                    "routing_mode": "feature-prior-dynamic",
                    "candidate_routing_mode": mode,
                    "selected_routing_mode": selected,
                    "candidate_routing_loss": losses[mode],
                    "feature_routing_confidence": feature_confidence,
                    "routing_confidence_threshold": float(confidence_threshold),
                    "routing_dynamic_tolerance": float(tolerance),
                    "routing_dynamic_margin": float(margin),
                    "selected": mode == selected,
                    "assigned_cluster": int(bank.cluster_assignments[idx]),
                    "medoid_client": clients[bank.medoids[int(bank.cluster_assignments[idx])]].client_id,
                    "routing_prior_weight": float(bank.routing_prior_weight),
                }
            )
    return selected_modes, rows


def _base_routing_mode(mode: str) -> str:
    return "feature-prior" if mode == "feature-prior-dynamic" else mode


def _client_index(clients: list, client_id: str) -> int:
    for idx, client in enumerate(clients):
        if client.client_id == client_id:
            return idx
    raise KeyError(client_id)


def adapter_bank_sample_routing_rows(clients: list, bank: AdapterBank | None, routing_mode: str) -> list[dict]:
    rows: list[dict] = []
    if bank is None:
        return rows
    for split_name in ["train", "test"]:
        for i, client in enumerate(clients):
            x = client.x_train if split_name == "train" else client.x_test
            routing = bank.routing_for_samples(x, i, mode=routing_mode)
            for k in range(routing.shape[1]):
                rows.append(
                    {
                        "client_id": client.client_id,
                        "domain": client.domain,
                        "split": split_name,
                        "bank_id": k,
                        "routing_mode": routing_mode,
                        "mean_routing_weight": float(routing[:, k].mean()),
                        "std_routing_weight": float(routing[:, k].std()),
                        "assigned_cluster": int(bank.cluster_assignments[i]),
                        "medoid_client": clients[bank.medoids[k]].client_id,
                        "routing_prior_weight": float(bank.routing_prior_weight),
                        "smoothing_weight": float(bank.smoothing_weight),
                    }
                )
    return rows


def evaluate_adapter_bank_feature_routing(
    method: str,
    clients: list,
    base_weight: Array,
    bank: AdapterBank,
    ranks: list[int],
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    routing_mode: str,
) -> list[dict]:
    rows: list[dict] = []
    for idx, client in enumerate(clients):
        logits = bank.logits_for_client(client.x_test, base_weight, idx, mode=routing_mode)
        loss, _ = cross_entropy_and_grad(logits.copy(), client.y_test.astype(np.int64))
        pred = logits.argmax(axis=1)
        rows.append(
            {
                "method": method,
                "seed": seed,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": round_id,
                "client_id": client.client_id,
                "domain": client.domain,
                "accuracy": float((pred == client.y_test).mean()),
                "loss": loss,
                "rank": ranks[idx],
                "routing_mode": routing_mode,
            }
        )
    return rows


def evaluate_adapter_bank_dynamic_routing(
    method: str,
    clients: list,
    base_weight: Array,
    bank: AdapterBank,
    ranks: list[int],
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    selected_modes: list[str],
) -> list[dict]:
    rows: list[dict] = []
    if len(selected_modes) != len(clients):
        raise ValueError(f"Expected {len(clients)} selected routing modes, got {len(selected_modes)}")
    for idx, client in enumerate(clients):
        mode = selected_modes[idx]
        if mode == "client":
            metrics = evaluate_adapter(
                client.x_test,
                client.y_test,
                base_weight,
                bank.adapter_for_client(idx, rank=ranks[idx]),
            )
            accuracy = metrics["accuracy"]
            loss = metrics["loss"]
        else:
            logits = bank.logits_for_client(client.x_test, base_weight, idx, mode=mode)
            loss, _ = cross_entropy_and_grad(logits.copy(), client.y_test.astype(np.int64))
            pred = logits.argmax(axis=1)
            accuracy = float((pred == client.y_test).mean())
        rows.append(
            {
                "method": method,
                "seed": seed,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": round_id,
                "client_id": client.client_id,
                "domain": client.domain,
                "accuracy": accuracy,
                "loss": loss,
                "rank": ranks[idx],
                "routing_mode": "feature-prior-dynamic",
                "selected_routing_mode": mode,
            }
        )
    return rows


def evaluate_global_adapter(
    method: str,
    clients: list,
    base_weight: Array,
    adapter: LoRAAdapter,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
) -> list[dict]:
    rows: list[dict] = []
    for client in clients:
        metrics = evaluate_adapter(client.x_test, client.y_test, base_weight, adapter)
        rows.append(
            {
                "method": method,
                "seed": seed,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": round_id,
                "client_id": client.client_id,
                "domain": client.domain,
                "accuracy": metrics["accuracy"],
                "loss": metrics["loss"],
                "rank": adapter.rank,
            }
        )
    return rows


def evaluate_client_adapters(
    method: str,
    clients: list,
    base_weight: Array,
    adapters: list[LoRAAdapter],
    ranks: list[int],
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
) -> list[dict]:
    rows: list[dict] = []
    for idx, (client, adapter) in enumerate(zip(clients, adapters)):
        metrics = evaluate_adapter(client.x_test, client.y_test, base_weight, adapter)
        rows.append(
            {
                "method": method,
                "seed": seed,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": round_id,
                "client_id": client.client_id,
                "domain": client.domain,
                "accuracy": metrics["accuracy"],
                "loss": metrics["loss"],
                "rank": ranks[idx],
            }
        )
    return rows


def summarize_method(per_client_metrics: list[dict], diagnostic_r: float | None = None) -> list[dict]:
    grouped: dict[tuple, dict[str, list[float]]] = {}
    for row in per_client_metrics:
        key = (
            row["method"],
            row["seed"],
            row["dataset"],
            row["heterogeneity_setting"],
            row["round"],
        )
        grouped.setdefault(key, {"accuracy": [], "loss": []})
        grouped[key]["accuracy"].append(float(row["accuracy"]))
        grouped[key]["loss"].append(float(row["loss"]))

    rows: list[dict] = []
    for key, values in grouped.items():
        method, seed, dataset, heterogeneity, round_value = key
        accuracy = np.asarray(values["accuracy"], dtype=np.float64)
        loss = np.asarray(values["loss"], dtype=np.float64)
        row = {
            "method": method,
            "seed": seed,
            "dataset": dataset,
            "heterogeneity_setting": heterogeneity,
            "heterogeneity": heterogeneity,
            "round": round_value,
            "mean_accuracy": float(accuracy.mean()),
            "std_accuracy": float(accuracy.std()),
            "mean_loss": float(loss.mean()),
            "num_clients": int(accuracy.size),
        }
        if diagnostic_r is not None:
            row["subspace_failure_pearson_r"] = diagnostic_r
        rows.append(row)
    return rows
