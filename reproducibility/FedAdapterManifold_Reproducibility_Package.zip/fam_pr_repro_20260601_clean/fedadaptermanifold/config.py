from __future__ import annotations

from pathlib import Path
from typing import Any


DEFAULT_CONFIG: dict[str, Any] = {
    "dataset": "pacs-debug",
    "data_root": "",
    "domains": "",
    "test_fraction": 0.25,
    "output_dir": "results/fedadaptermanifold",
    "feature_backbone": "numpy",
    "feature_cache_dir": "",
    "base_head_init": "zero",
    "base_head_scale": 1.0,
    "class_prompt_template": "a photo of a {label}.",
    "heterogeneity_setting": "domain-adapter-manifold-debug",
    "num_clients": 4,
    "num_classes": 7,
    "feature_dim": 48,
    "dirichlet_alpha": 0.3,
    "min_train_size": 32,
    "align_test_with_train": True,
    "train_per_client": 240,
    "test_per_client": 160,
    "rounds": 3,
    "local_epochs": 18,
    "lr": 0.45,
    "batch_size": 32,
    "fedprox_mu": 0.001,
    "ditto_mu": 0.001,
    "pfedme_mu": 0.001,
    "scaffold_control_lr": 1.0,
    "skip_heavy_personalized_baselines": False,
    "fedper_personal_weight_candidates": "0,0.25,0.50,0.75,1.00",
    "fedper_personal_weight_tolerance": 0.005,
    "fedper_fam_personal_weight_candidates": "0,0.25,0.50,0.75,1.00",
    "fedper_fam_loss_tolerance": 0.005,
    "fedper_fam_policy": "loss-min",
    "ditto_fam_personal_weight_candidates": "0,0.25,0.50,0.75,1.00",
    "ditto_fam_loss_tolerance": 0.005,
    "ditto_fam_policy": "personal-fallback",
    "rank": 4,
    "rank_policy": "fixed",
    "min_rank": 2,
    "max_rank": 8,
    "adapter_bank_k": 0,
    "adapter_graph_mode": "fedgeo",
    "adapter_graph_self_weight": 1.0,
    "adapter_graph_mix_weight": 1.0,
    "adapter_graph_mix_policy": "fixed",
    "adapter_graph_mix_tolerance": 0.005,
    "adapter_graph_mix_candidates": "0,0.25,0.50,0.75,1.00",
    "adapter_graph_distance": "combined",
    "adapter_graph_compatibility": "method",
    "adapter_bank_routing": "feature-prior",
    "adapter_bank_prior_weight": 0.10,
    "lambda_geo": 0.5,
    "lambda_label": 0.25,
    "manifold_distance_components": "all",
    "tau": 1.0,
    "route_tau": 0.05,
    "shared_weight": 0.35,
    "shared_weight_policy": "fixed",
    "shared_weight_tolerance": 0.005,
    "shared_weight_candidates": "0,0.05,0.10,0.15,0.20,0.30,0.35",
    "personal_weight": 0.15,
    "personal_weight_policy": "fixed",
    "personal_weight_tolerance": 0.005,
    "personal_weight_candidates": "0.15,0.30,0.50,0.70,0.90",
    "manifold_smoothing_weight": 0.0,
    "manifold_smoothing_policy": "cluster-loss-constrained",
    "manifold_smoothing_tolerance": 0.005,
    "manifold_smoothing_candidates": "0,0.05,0.10,0.15,0.20,0.30,0.40",
    "candidate_selector_policy": "diagnostic-gated",
    "strong_candidate_selector_policy": "loss-min",
    "candidate_selector_scope": "all",
    "candidate_selector_loss_tolerance": 0.005,
    "candidate_selector_loss_tolerance_ratio": 0.20,
    "candidate_selector_neighbor_weight": 0.0,
    "candidate_selector_calibration_fraction": 0.0,
    "candidate_selector_softmax_tau": 0.05,
    "candidate_selector_lcb_delta": 0.05,
    "geometry_outputs_dir": "",
    "round_id": 0,
    "fedgeo_dir": "",
    "geometry_round": 0,
    "diagnostic_threshold": 0.05,
    "continue_on_failed_diagnostic": False,
    "seed": 0,
    "device": "cpu",
    "cpu_debug": True,
}


def load_yaml(path: str | Path) -> dict[str, Any]:
    """Load a small YAML config, using PyYAML when present and a fallback otherwise."""

    path = Path(path)
    text = path.read_text(encoding="utf-8")
    try:
        import yaml  # type: ignore

        data = yaml.safe_load(text) or {}
        if not isinstance(data, dict):
            raise ValueError(f"Config root must be a mapping: {path}")
        return data
    except ImportError:
        return _parse_simple_yaml(text)


def dump_yaml(data: dict[str, Any]) -> str:
    try:
        import yaml  # type: ignore

        return yaml.safe_dump(data, sort_keys=True)
    except ImportError:
        return _dump_simple_yaml(data)


def save_yaml_copy(path: str | Path, data: dict[str, Any]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(dump_yaml(data), encoding="utf-8")


def flatten_config(data: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in data.items():
        normalized = key.replace("-", "_")
        if isinstance(value, dict):
            out.update(flatten_config(value))
        else:
            out[normalized] = value
    return out


def merge_defaults(config_path: str | None = None) -> dict[str, Any]:
    merged = dict(DEFAULT_CONFIG)
    if config_path:
        merged.update(flatten_config(load_yaml(config_path)))
    return merged


def _parse_simple_yaml(text: str) -> dict[str, Any]:
    root: dict[str, Any] = {}
    stack: list[tuple[int, dict[str, Any]]] = [(-1, root)]
    for raw_line in text.splitlines():
        line = raw_line.split("#", 1)[0].rstrip()
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip(" "))
        stripped = line.strip()
        if ":" not in stripped:
            continue
        key, value = stripped.split(":", 1)
        key = key.strip().replace("-", "_")
        value = value.strip()
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1]
        if value == "":
            child: dict[str, Any] = {}
            parent[key] = child
            stack.append((indent, child))
        else:
            parent[key] = _parse_scalar(value)
    return root


def _parse_scalar(value: str) -> Any:
    value = value.strip()
    if value in {"true", "True"}:
        return True
    if value in {"false", "False"}:
        return False
    if value in {"null", "None", "~"}:
        return None
    if value.startswith("[") and value.endswith("]"):
        inner = value[1:-1].strip()
        if not inner:
            return []
        return [_parse_scalar(part.strip()) for part in inner.split(",")]
    if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
        return value[1:-1]
    try:
        return int(value)
    except ValueError:
        pass
    try:
        return float(value)
    except ValueError:
        return value


def _dump_simple_yaml(data: dict[str, Any], indent: int = 0) -> str:
    lines: list[str] = []
    pad = " " * indent
    for key in sorted(data.keys()):
        value = data[key]
        if isinstance(value, dict):
            lines.append(f"{pad}{key}:")
            lines.append(_dump_simple_yaml(value, indent + 2).rstrip())
        else:
            lines.append(f"{pad}{key}: {_format_scalar(value)}")
    return "\n".join(lines) + "\n"


def _format_scalar(value: Any) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if value is None:
        return "null"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        return "[" + ", ".join(_format_scalar(v) for v in value) + "]"
    text = str(value)
    if text == "" or any(ch in text for ch in ":#[]{}"):
        return repr(text)
    return text
