from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import hashlib
import pickle

import numpy as np

from .features import (
    ClipImageFeatureExtractor,
    DinoV2ImageFeatureExtractor,
    NumpyImageFeatureExtractor,
    TorchvisionResNet18FeatureExtractor,
)


Array = np.ndarray


PACS_DOMAINS = ["art_painting", "cartoon", "photo", "sketch"]


@dataclass
class ClientDataset:
    client_id: str
    domain: str
    x_train: Array
    y_train: Array
    x_test: Array
    y_test: Array


def make_synthetic_manifold_clients(
    num_clients: int = 4,
    num_classes: int = 5,
    feature_dim: int = 48,
    train_per_client: int = 120,
    test_per_client: int = 96,
    rank: int = 4,
    seed: int = 7,
) -> tuple[list[ClientDataset], Array]:
    """Generate a controlled feature-level visual heterogeneity benchmark.

    Clients are sampled from multiple latent adapter manifolds. Their true
    classifiers differ by low-rank semantic updates, making direct global
    LoRA averaging measurably fragile under subspace conflict.
    """

    rng = np.random.default_rng(seed)
    num_clients = int(num_clients)
    num_classes = int(num_classes)
    feature_dim = int(feature_dim)
    rank = int(max(1, min(rank, num_classes, feature_dim)))
    base_centers = rng.normal(0.0, 1.0, size=(num_classes, feature_dim))
    base_centers /= np.clip(np.linalg.norm(base_centers, axis=1, keepdims=True), 1e-12, None)
    base_weight = 0.35 * base_centers

    groups = 2 if num_clients >= 4 else max(1, num_clients)
    group_a = np.zeros((groups, rank, feature_dim), dtype=np.float64)
    group_b = rng.normal(0.0, 1.0, size=(groups, num_classes, rank))
    feature_blocks = np.array_split(np.arange(feature_dim), groups)
    for g in range(groups):
        block = feature_blocks[g]
        block_matrix = rng.normal(0.0, 1.0, size=(len(block), rank))
        q, _ = np.linalg.qr(block_matrix)
        group_a[g][:, block] = q[:, :rank].T
        group_b[g] /= np.clip(np.linalg.norm(group_b[g], axis=0, keepdims=True), 1e-12, None)

    clients: list[ClientDataset] = []
    for client_idx in range(num_clients):
        domain = PACS_DOMAINS[client_idx] if client_idx < len(PACS_DOMAINS) else f"domain_{client_idx}"
        group = client_idx % groups
        local_a = group_a[group] + 0.04 * rng.normal(size=(rank, feature_dim))
        local_b = group_b[group] + 0.05 * rng.normal(size=(num_classes, rank))
        true_delta = 2.1 * (local_b @ local_a) / np.sqrt(float(rank))
        true_weight = base_weight + true_delta
        style = rng.normal(0.0, 0.25, size=feature_dim)
        label_probs = rng.dirichlet(np.ones(num_classes) * (3.0 + 0.4 * client_idx))
        label_probs = 0.95 * np.ones(num_classes) / num_classes + 0.05 * label_probs
        x_train, y_train = _sample_from_teacher(
            true_weight,
            style,
            label_probs,
            train_per_client,
            rng,
            noise=0.55,
        )
        x_test, y_test = _sample_from_teacher(
            true_weight,
            style,
            label_probs,
            test_per_client,
            rng,
            noise=0.60,
        )
        clients.append(
            ClientDataset(
                client_id=f"client_{client_idx}",
                domain=domain,
                x_train=x_train,
                y_train=y_train,
                x_test=x_test,
                y_test=y_test,
            )
        )
    return clients, base_weight


def _sample_from_teacher(
    true_weight: Array,
    style: Array,
    label_probs: Array,
    n: int,
    rng: np.random.Generator,
    noise: float,
) -> tuple[Array, Array]:
    num_classes, feature_dim = true_weight.shape
    y = rng.choice(num_classes, size=int(n), p=label_probs / label_probs.sum())
    x = np.zeros((int(n), feature_dim), dtype=np.float64)
    class_dirs = true_weight / np.clip(np.linalg.norm(true_weight, axis=1, keepdims=True), 1e-12, None)
    for idx, cls in enumerate(y):
        x[idx] = class_dirs[cls] + style + rng.normal(0.0, noise, size=feature_dim)
    x = _standardize_rows(x)
    return x, y.astype(np.int64)


def _standardize_rows(x: Array) -> Array:
    x = x - x.mean(axis=1, keepdims=True)
    return x / np.clip(np.linalg.norm(x, axis=1, keepdims=True), 1e-12, None)


def load_image_folder_clients(
    data_root: str | Path,
    domains: list[str] | None = None,
    feature_backbone: str = "numpy",
    device: str = "cpu",
    test_fraction: float = 0.25,
    seed: int = 0,
    feature_cache_dir: str | Path = "",
    base_head_init: str = "zero",
    base_head_scale: float = 1.0,
    class_prompt_template: str = "a photo of a {label}.",
    train_per_client: int = 0,
    test_per_client: int = 0,
) -> tuple[list[ClientDataset], Array, list[str]]:
    """Load domain-folder datasets.

    Supported layouts are:
    - ``root/domain/class/image``
    - ``root/domain/train/class/image`` and ``root/domain/test/class/image``
    """

    root = Path(data_root)
    if not root.exists():
        raise FileNotFoundError(root)
    if domains is None:
        domains = sorted([p.name for p in root.iterdir() if p.is_dir()])
    missing_domains = [domain for domain in domains if not (root / domain).is_dir()]
    if missing_domains:
        raise ValueError(f"Missing domain directories under {root}: {', '.join(missing_domains)}")
    split_layout = _has_domain_split_layout(root, domains)
    classes = _discover_image_folder_classes(root, domains, split_layout=split_layout)
    if not classes:
        raise ValueError(f"No class directories found under selected domains in {root}")
    class_to_idx = {name: idx for idx, name in enumerate(classes)}
    extractor = None

    def get_extractor():
        nonlocal extractor
        if extractor is None:
            extractor = _make_extractor(feature_backbone, device=device)
        return extractor

    cache_root = Path(feature_cache_dir) if str(feature_cache_dir or "").strip() else None
    rng = np.random.default_rng(seed)
    clients: list[ClientDataset] = []
    for domain_idx, domain in enumerate(domains):
        if split_layout:
            train_paths, train_labels = _collect_image_split_paths(root / domain / "train", classes, class_to_idx)
            test_paths, test_labels = _collect_image_split_paths(root / domain / "test", classes, class_to_idx)
            if not train_paths:
                raise ValueError(f"No train images found for domain {domain} under {root}")
            if not test_paths:
                train_paths, train_labels, test_paths, test_labels = _deterministic_train_test_split(
                    train_paths,
                    train_labels,
                    rng,
                    test_fraction=test_fraction,
                )
            x_train, y_train = _extract_or_load_features(
                train_paths,
                train_labels,
                get_extractor,
                cache_root=cache_root,
                root=root,
                domain=domain,
                split="train",
                feature_backbone=feature_backbone,
                seed=seed,
                test_fraction=test_fraction,
            )
            x_test, y_test = _extract_or_load_features(
                test_paths,
                test_labels,
                get_extractor,
                cache_root=cache_root,
                root=root,
                domain=domain,
                split="test",
                feature_backbone=feature_backbone,
                seed=seed,
                test_fraction=test_fraction,
            )
        else:
            paths, labels = _collect_image_split_paths(root / domain, classes, class_to_idx)
            if not paths:
                raise ValueError(f"No images found for domain {domain} under {root}")
            paths, labels, test_paths, test_labels = _deterministic_train_test_split(
                paths,
                labels,
                rng,
                test_fraction=test_fraction,
            )
            x_train, y_train = _extract_or_load_features(
                paths,
                labels,
                get_extractor,
                cache_root=cache_root,
                root=root,
                domain=domain,
                split="train",
                feature_backbone=feature_backbone,
                seed=seed,
                test_fraction=test_fraction,
            )
            x_test, y_test = _extract_or_load_features(
                test_paths,
                test_labels,
                get_extractor,
                cache_root=cache_root,
                root=root,
                domain=domain,
                split="test",
                feature_backbone=feature_backbone,
                seed=seed,
                test_fraction=test_fraction,
            )
        if y_train.size == 0 or y_test.size == 0:
            raise ValueError(f"No images found for domain {domain} under {root}")
        x_train, y_train = _limit_feature_arrays(
            x_train,
            y_train,
            int(train_per_client),
            seed=int(seed) + 1009 * (domain_idx + 1),
        )
        x_test, y_test = _limit_feature_arrays(
            x_test,
            y_test,
            int(test_per_client),
            seed=int(seed) + 2003 * (domain_idx + 1),
        )
        clients.append(
            ClientDataset(
                client_id=f"client_{domain_idx}",
                domain=domain,
                x_train=x_train,
                y_train=y_train,
                x_test=x_test,
                y_test=y_test,
            )
        )
    base_weight = _make_base_head(
        classes,
        feature_dim=clients[0].x_train.shape[1],
        feature_backbone=feature_backbone,
        extractor_factory=get_extractor,
        init=base_head_init,
        scale=base_head_scale,
        prompt_template=class_prompt_template,
    )
    return clients, base_weight, classes


def load_cifar10_clients(
    data_root: str | Path,
    num_clients: int = 10,
    dirichlet_alpha: float = 0.3,
    min_train_size: int = 32,
    train_per_client: int = 512,
    test_per_client: int = 256,
    align_test_with_train: bool = True,
    seed: int = 0,
) -> tuple[list[ClientDataset], Array, list[str]]:
    """Load CIFAR-10 from local Python batch files without torch.

    This mirrors FedGeo's label-skew Dirichlet client construction closely
    enough for interop: same seed, alpha, client count, min-size retry, and
    train/test alignment by class-client proportions.
    """

    batch_dir = _find_cifar10_batch_dir(data_root)
    train_images, train_labels, class_names = _read_cifar10_batches(batch_dir, train=True)
    test_images, test_labels, _ = _read_cifar10_batches(batch_dir, train=False)
    train_splits, proportions = _partition_label_skew_dirichlet_with_proportions(
        train_labels,
        num_clients=int(num_clients),
        alpha=float(dirichlet_alpha),
        min_size=int(min_train_size),
        seed=int(seed),
    )
    if align_test_with_train:
        test_splits = _partition_label_skew_by_proportions(
            test_labels,
            proportions_by_class=proportions,
            num_clients=int(num_clients),
            seed=int(seed) + 17,
        )
    else:
        test_splits, _ = _partition_label_skew_dirichlet_with_proportions(
            test_labels,
            num_clients=int(num_clients),
            alpha=float(dirichlet_alpha),
            min_size=max(1, int(min_train_size) // 5),
            seed=int(seed) + 17,
        )
    train_splits = _limit_partition_sizes(train_splits, int(train_per_client), int(seed) + 101, train_labels)
    test_splits = _limit_partition_sizes(test_splits, int(test_per_client), int(seed) + 202, test_labels)

    clients: list[ClientDataset] = []
    for client_idx, (train_idx, test_idx) in enumerate(zip(train_splits, test_splits)):
        if not train_idx or not test_idx:
            raise ValueError(f"CIFAR-10 client {client_idx} has an empty split")
        x_train = _cifar10_numpy_features(train_images[np.asarray(train_idx, dtype=np.int64)])
        y_train = train_labels[np.asarray(train_idx, dtype=np.int64)].astype(np.int64)
        x_test = _cifar10_numpy_features(test_images[np.asarray(test_idx, dtype=np.int64)])
        y_test = test_labels[np.asarray(test_idx, dtype=np.int64)].astype(np.int64)
        clients.append(
            ClientDataset(
                client_id=f"client_{client_idx}",
                domain=f"client_{client_idx}",
                x_train=x_train,
                y_train=y_train,
                x_test=x_test,
                y_test=y_test,
            )
        )
    base_weight = np.zeros((len(class_names), clients[0].x_train.shape[1]), dtype=np.float64)
    return clients, base_weight, class_names


def load_medmnist_npz_clients(
    data_root: str | Path,
    num_clients: int = 8,
    dirichlet_alpha: float = 0.3,
    min_train_size: int = 32,
    train_per_client: int = 512,
    test_per_client: int = 256,
    align_test_with_train: bool = True,
    seed: int = 0,
    feature_cache_dir: str | Path = "",
    feature_backbone: str = "numpy",
) -> tuple[list[ClientDataset], Array, list[str]]:
    """Load MedMNIST-style ``.npz`` files using label-skew client splits.

    The expected archive keys follow MedMNIST conventions:
    ``train_images``, ``train_labels``, optional ``val_images`` /
    ``val_labels``, and ``test_images`` / ``test_labels``.
    """

    path = _find_medmnist_npz(data_root)
    if feature_backbone != "numpy":
        raise ValueError("dataset=medmnist-npz currently supports feature_backbone=numpy")
    data = np.load(path, allow_pickle=False)
    train_images = np.asarray(data["train_images"])
    train_labels = np.asarray(data["train_labels"], dtype=np.int64).reshape(-1)
    if "val_images" in data.files and "val_labels" in data.files:
        train_images = np.concatenate([train_images, np.asarray(data["val_images"])], axis=0)
        train_labels = np.concatenate([train_labels, np.asarray(data["val_labels"], dtype=np.int64).reshape(-1)], axis=0)
    test_images = np.asarray(data["test_images"])
    test_labels = np.asarray(data["test_labels"], dtype=np.int64).reshape(-1)
    class_names = [f"class_{idx}" for idx in range(int(max(train_labels.max(), test_labels.max())) + 1)]

    train_splits, proportions = _partition_label_skew_dirichlet_with_proportions(
        train_labels,
        num_clients=int(num_clients),
        alpha=float(dirichlet_alpha),
        min_size=int(min_train_size),
        seed=int(seed),
    )
    if align_test_with_train:
        test_splits = _partition_label_skew_by_proportions(
            test_labels,
            proportions_by_class=proportions,
            num_clients=int(num_clients),
            seed=int(seed) + 17,
        )
    else:
        test_splits, _ = _partition_label_skew_dirichlet_with_proportions(
            test_labels,
            num_clients=int(num_clients),
            alpha=float(dirichlet_alpha),
            min_size=max(1, int(min_train_size) // 5),
            seed=int(seed) + 17,
        )
    train_splits = _limit_partition_sizes(train_splits, int(train_per_client), int(seed) + 101, train_labels)
    test_splits = _limit_partition_sizes(test_splits, int(test_per_client), int(seed) + 202, test_labels)

    cache_root = Path(feature_cache_dir) if str(feature_cache_dir or "").strip() else None
    extractor = NumpyImageFeatureExtractor()
    clients: list[ClientDataset] = []
    for client_idx, (train_idx, test_idx) in enumerate(zip(train_splits, test_splits)):
        if not train_idx or not test_idx:
            raise ValueError(f"MedMNIST client {client_idx} has an empty split")
        x_train, y_train = _extract_or_load_array_features(
            train_images[np.asarray(train_idx, dtype=np.int64)],
            train_labels[np.asarray(train_idx, dtype=np.int64)],
            extractor,
            cache_root=cache_root,
            root=path,
            domain=f"client_{client_idx}",
            split="train",
            feature_backbone=feature_backbone,
            seed=seed,
        )
        x_test, y_test = _extract_or_load_array_features(
            test_images[np.asarray(test_idx, dtype=np.int64)],
            test_labels[np.asarray(test_idx, dtype=np.int64)],
            extractor,
            cache_root=cache_root,
            root=path,
            domain=f"client_{client_idx}",
            split="test",
            feature_backbone=feature_backbone,
            seed=seed,
        )
        clients.append(
            ClientDataset(
                client_id=f"client_{client_idx}",
                domain=f"client_{client_idx}",
                x_train=x_train,
                y_train=y_train,
                x_test=x_test,
                y_test=y_test,
            )
        )
    base_weight = np.zeros((len(class_names), clients[0].x_train.shape[1]), dtype=np.float64)
    return clients, base_weight, class_names


def _has_domain_split_layout(root: Path, domains: list[str]) -> bool:
    return any((root / domain / "train").is_dir() or (root / domain / "test").is_dir() for domain in domains)


def _discover_image_folder_classes(root: Path, domains: list[str], split_layout: bool) -> list[str]:
    class_names: set[str] = set()
    for domain in domains:
        domain_root = root / domain
        if split_layout:
            for split_name in ["train", "test"]:
                split_root = domain_root / split_name
                if split_root.is_dir():
                    class_names.update(p.name for p in split_root.iterdir() if p.is_dir())
        else:
            class_names.update(p.name for p in domain_root.iterdir() if p.is_dir())
    return sorted(class_names, key=_class_sort_key)


def _class_sort_key(name: str) -> tuple[int, int | str]:
    return (0, int(name)) if name.isdigit() else (1, name.lower())


def _collect_image_split_paths(root: Path, classes: list[str], class_to_idx: dict[str, int]) -> tuple[list[Path], list[int]]:
    paths: list[Path] = []
    labels: list[int] = []
    for class_name in classes:
        class_dir = root / class_name
        if not class_dir.exists():
            continue
        for path in sorted(class_dir.rglob("*")):
            if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".webp"}:
                paths.append(path)
                labels.append(class_to_idx[class_name])
    return paths, labels


def _deterministic_train_test_split(
    paths: list[Path],
    labels: list[int],
    rng: np.random.Generator,
    test_fraction: float,
) -> tuple[list[Path], list[int], list[Path], list[int]]:
    labels_arr = np.asarray(labels, dtype=np.int64)
    order = rng.permutation(len(labels_arr))
    split = int(round((1.0 - test_fraction) * len(labels_arr)))
    split = min(max(split, 1), len(labels_arr))
    train_idx = order[:split]
    test_idx = order[split:]
    if test_idx.size == 0:
        test_idx = train_idx
    train_paths = [paths[int(idx)] for idx in train_idx]
    train_labels = [int(labels_arr[int(idx)]) for idx in train_idx]
    test_paths = [paths[int(idx)] for idx in test_idx]
    test_labels = [int(labels_arr[int(idx)]) for idx in test_idx]
    return train_paths, train_labels, test_paths, test_labels


def _make_extractor(feature_backbone: str, device: str = "cpu"):
    if feature_backbone == "numpy":
        return NumpyImageFeatureExtractor()
    if feature_backbone == "resnet18":
        return TorchvisionResNet18FeatureExtractor(pretrained=False, device=device)
    if feature_backbone == "resnet18-pretrained":
        return TorchvisionResNet18FeatureExtractor(pretrained=True, device=device)
    if feature_backbone in {"clip-rn50", "clip-vit-b32", "clip-vit-b16", "clip-vit-l14"}:
        return ClipImageFeatureExtractor(model_name=feature_backbone, device=device)
    if feature_backbone in {
        "dinov2-vits14",
        "dinov2-vitb14",
        "dinov2-vitl14",
        "dinov2-small",
        "dinov2-base",
        "dinov2-large",
    }:
        return DinoV2ImageFeatureExtractor(model_name=feature_backbone, device=device)
    raise ValueError(f"Unknown feature backbone: {feature_backbone}")


def _make_base_head(
    class_names: list[str],
    feature_dim: int,
    feature_backbone: str,
    extractor_factory,
    init: str,
    scale: float,
    prompt_template: str,
) -> Array:
    init = str(init or "zero").strip().lower()
    if init == "zero":
        return np.zeros((len(class_names), int(feature_dim)), dtype=np.float64)
    if init != "clip-text":
        raise ValueError(f"Unknown base_head_init: {init}")
    if feature_backbone not in {"clip-rn50", "clip-vit-b32", "clip-vit-b16", "clip-vit-l14"}:
        raise ValueError("base_head_init=clip-text requires a CLIP feature_backbone")
    extractor = extractor_factory()
    if not hasattr(extractor, "encode_text_labels"):
        raise ValueError("Selected feature extractor does not provide text label embeddings")
    head = np.asarray(extractor.encode_text_labels(class_names, prompt_template=prompt_template), dtype=np.float64)
    if head.shape != (len(class_names), int(feature_dim)):
        raise ValueError(f"CLIP text head shape {head.shape} does not match ({len(class_names)}, {int(feature_dim)})")
    return float(scale) * head


def _extract_or_load_features(
    paths: list[Path],
    labels: list[int],
    extractor_factory,
    cache_root: Path | None,
    root: Path,
    domain: str,
    split: str,
    feature_backbone: str,
    seed: int,
    test_fraction: float,
) -> tuple[Array, Array]:
    if cache_root is None:
        return _extract_paths(extractor_factory(), paths), np.asarray(labels, dtype=np.int64)
    cache_root.mkdir(parents=True, exist_ok=True)
    cache_path = _feature_cache_path(
        cache_root,
        root=root,
        domain=domain,
        split=split,
        feature_backbone=feature_backbone,
        seed=seed,
        test_fraction=test_fraction,
        paths=paths,
        labels=labels,
    )
    if cache_path.exists():
        data = np.load(cache_path, allow_pickle=False)
        return np.asarray(data["x"], dtype=np.float64), np.asarray(data["y"], dtype=np.int64)
    cached_x = _load_paths_from_image_cache(paths, cache_root=cache_root, feature_backbone=feature_backbone)
    if cached_x is not None:
        y = np.asarray(labels, dtype=np.int64)
        np.savez_compressed(cache_path, x=cached_x, y=y)
        return cached_x, y
    x = _extract_paths_with_cache(paths, extractor_factory(), cache_root=cache_root, feature_backbone=feature_backbone)
    y = np.asarray(labels, dtype=np.int64)
    np.savez_compressed(cache_path, x=x, y=y)
    return x, y


def _extract_paths(extractor, paths: list[Path]) -> Array:
    if hasattr(extractor, "extract_paths"):
        return np.asarray(extractor.extract_paths(paths), dtype=np.float64)
    return np.vstack([extractor.extract_path(path) for path in paths])


def _extract_or_load_array_features(
    images: Array,
    labels: Array,
    extractor,
    cache_root: Path | None,
    root: Path,
    domain: str,
    split: str,
    feature_backbone: str,
    seed: int,
) -> tuple[Array, Array]:
    y = np.asarray(labels, dtype=np.int64)
    if cache_root is None:
        return _extract_arrays(extractor, images), y
    cache_root.mkdir(parents=True, exist_ok=True)
    cache_path = _array_feature_cache_path(
        cache_root,
        root=root,
        domain=domain,
        split=split,
        feature_backbone=feature_backbone,
        seed=seed,
        images=images,
        labels=y,
    )
    if cache_path.exists():
        data = np.load(cache_path, allow_pickle=False)
        return np.asarray(data["x"], dtype=np.float64), np.asarray(data["y"], dtype=np.int64)
    x = _extract_arrays(extractor, images)
    np.savez_compressed(cache_path, x=x, y=y)
    return x, y


def _extract_arrays(extractor, images: Array) -> Array:
    if hasattr(extractor, "extract_arrays"):
        return np.asarray(extractor.extract_arrays(images), dtype=np.float64)
    return np.vstack([extractor.extract_array(image) for image in np.asarray(images)])


def _extract_paths_with_cache(paths: list[Path], extractor, cache_root: Path, feature_backbone: str) -> Array:
    image_cache = cache_root / "image_features"
    image_cache.mkdir(parents=True, exist_ok=True)
    features: list[Array | None] = [None for _ in paths]
    missing_indices = []
    missing_paths = []
    missing_cache_paths = []
    for idx, path in enumerate(paths):
        cache_path = _image_feature_cache_path(image_cache, path, feature_backbone)
        if cache_path.exists():
            data = np.load(cache_path, allow_pickle=False)
            features[idx] = np.asarray(data["x"], dtype=np.float64)
        else:
            missing_indices.append(idx)
            missing_paths.append(path)
            missing_cache_paths.append(cache_path)
    if missing_paths:
        extracted = _extract_paths(extractor, missing_paths)
        for idx, feature, cache_path in zip(missing_indices, extracted, missing_cache_paths):
            feature = np.asarray(feature, dtype=np.float64)
            np.savez_compressed(cache_path, x=feature)
            features[idx] = feature
    return np.vstack([feature for feature in features if feature is not None])


def _load_paths_from_image_cache(paths: list[Path], cache_root: Path, feature_backbone: str) -> Array | None:
    image_cache = cache_root / "image_features"
    if not image_cache.exists():
        return None
    features = []
    for path in paths:
        cache_path = _image_feature_cache_path(image_cache, path, feature_backbone)
        if not cache_path.exists():
            return None
        data = np.load(cache_path, allow_pickle=False)
        features.append(np.asarray(data["x"], dtype=np.float64))
    if not features:
        return np.zeros((0, 0), dtype=np.float64)
    return np.vstack(features)


def _extract_path_with_cache(path: Path, extractor, cache_root: Path, feature_backbone: str) -> Array:
    image_cache = cache_root / "image_features"
    image_cache.mkdir(parents=True, exist_ok=True)
    cache_path = _image_feature_cache_path(image_cache, path, feature_backbone)
    if cache_path.exists():
        data = np.load(cache_path, allow_pickle=False)
        return np.asarray(data["x"], dtype=np.float64)
    feature = extractor.extract_path(path)
    np.savez_compressed(cache_path, x=feature)
    return feature


def _feature_cache_path(
    cache_root: Path,
    root: Path,
    domain: str,
    split: str,
    feature_backbone: str,
    seed: int,
    test_fraction: float,
    paths: list[Path],
    labels: list[int],
) -> Path:
    digest = hashlib.sha256()
    digest.update(str(root.resolve()).encode("utf-8", errors="ignore"))
    digest.update(str(feature_backbone).encode("utf-8"))
    digest.update(str(seed).encode("utf-8"))
    digest.update(f"{float(test_fraction):.8f}".encode("utf-8"))
    for path, label in zip(paths, labels):
        resolved = path.resolve()
        stat = resolved.stat()
        digest.update(str(resolved).encode("utf-8", errors="ignore"))
        digest.update(str(int(label)).encode("utf-8"))
        digest.update(str(stat.st_size).encode("utf-8"))
        digest.update(str(stat.st_mtime_ns).encode("utf-8"))
    safe_domain = "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in str(domain))
    key = digest.hexdigest()[:16]
    return cache_root / f"{safe_domain}_{split}_{feature_backbone}_seed{int(seed)}_{key}.npz"


def _image_feature_cache_path(cache_root: Path, path: Path, feature_backbone: str) -> Path:
    resolved = path.resolve()
    stat = resolved.stat()
    digest = hashlib.sha256()
    digest.update(str(resolved).encode("utf-8", errors="ignore"))
    digest.update(str(feature_backbone).encode("utf-8"))
    digest.update(str(stat.st_size).encode("utf-8"))
    digest.update(str(stat.st_mtime_ns).encode("utf-8"))
    return cache_root / f"{feature_backbone}_{digest.hexdigest()[:24]}.npz"


def _array_feature_cache_path(
    cache_root: Path,
    root: Path,
    domain: str,
    split: str,
    feature_backbone: str,
    seed: int,
    images: Array,
    labels: Array,
) -> Path:
    resolved = root.resolve()
    stat = resolved.stat()
    digest = hashlib.sha256()
    digest.update(str(resolved).encode("utf-8", errors="ignore"))
    digest.update(str(stat.st_size).encode("utf-8"))
    digest.update(str(stat.st_mtime_ns).encode("utf-8"))
    digest.update(str(feature_backbone).encode("utf-8"))
    digest.update(str(seed).encode("utf-8"))
    digest.update(str(np.asarray(images).shape).encode("utf-8"))
    digest.update(np.asarray(labels, dtype=np.int64).tobytes())
    safe_domain = "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in str(domain))
    return cache_root / f"{safe_domain}_{split}_{feature_backbone}_seed{int(seed)}_{digest.hexdigest()[:16]}.npz"


def _find_medmnist_npz(data_root: str | Path) -> Path:
    root = Path(data_root)
    if not str(data_root):
        raise ValueError("data_root is required for dataset=medmnist-npz")
    if root.is_file() and root.suffix.lower() == ".npz":
        return root
    if root.is_dir():
        npz_files = sorted(root.glob("*.npz"))
        if len(npz_files) == 1:
            return npz_files[0]
        if len(npz_files) > 1:
            for path in npz_files:
                if "bloodmnist" in path.name.lower():
                    return path
            raise ValueError(f"Multiple MedMNIST npz files under {root}; pass the desired file path.")
    raise FileNotFoundError(f"Could not find a MedMNIST .npz file at or under {root}")


def _find_cifar10_batch_dir(data_root: str | Path) -> Path:
    root = Path(data_root)
    if not str(data_root):
        raise ValueError("data_root is required for dataset=cifar10")
    candidates = [root, root / "cifar-10-batches-py", root / "data" / "cifar-10-batches-py"]
    for candidate in candidates:
        if _is_cifar10_batch_dir(candidate):
            return candidate
    for candidate in root.rglob("cifar-10-batches-py"):
        if _is_cifar10_batch_dir(candidate):
            return candidate
    raise FileNotFoundError(f"Could not find cifar-10-batches-py under {root}")


def _is_cifar10_batch_dir(path: Path) -> bool:
    required = ["batches.meta", "data_batch_1", "data_batch_2", "data_batch_3", "data_batch_4", "data_batch_5", "test_batch"]
    return path.is_dir() and all((path / name).exists() for name in required)


def _read_cifar10_batches(batch_dir: Path, train: bool) -> tuple[Array, Array, list[str]]:
    meta = _read_pickle(batch_dir / "batches.meta")
    label_names = meta.get("label_names") or meta.get(b"label_names")
    if label_names is None:
        label_names = [f"class_{idx}" for idx in range(10)]
    class_names = [name.decode("utf-8") if isinstance(name, bytes) else str(name) for name in label_names]
    names = [f"data_batch_{idx}" for idx in range(1, 6)] if train else ["test_batch"]
    arrays = []
    labels = []
    for name in names:
        payload = _read_pickle(batch_dir / name)
        data = payload.get("data") if "data" in payload else payload.get(b"data")
        batch_labels = payload.get("labels") if "labels" in payload else payload.get(b"labels")
        if data is None or batch_labels is None:
            raise ValueError(f"Invalid CIFAR-10 batch file: {batch_dir / name}")
        arrays.append(np.asarray(data, dtype=np.uint8))
        labels.extend(int(label) for label in batch_labels)
    return np.vstack(arrays), np.asarray(labels, dtype=np.int64), class_names


def _read_pickle(path: Path):
    with path.open("rb") as handle:
        return pickle.load(handle, encoding="latin1")


def _cifar10_numpy_features(raw: Array) -> Array:
    images = np.asarray(raw, dtype=np.float64).reshape(-1, 3, 32, 32) / 255.0
    mean = np.asarray([0.4914, 0.4822, 0.4465], dtype=np.float64)[None, :, None, None]
    std = np.asarray([0.2470, 0.2435, 0.2616], dtype=np.float64)[None, :, None, None]
    images = (images - mean) / std
    pooled = images.reshape(images.shape[0], 3, 8, 4, 8, 4).mean(axis=(3, 5))
    features = pooled.reshape(images.shape[0], -1)
    features = features - features.mean(axis=1, keepdims=True)
    return features / np.clip(np.linalg.norm(features, axis=1, keepdims=True), 1e-12, None)


def _partition_label_skew_dirichlet_with_proportions(
    labels: Array,
    num_clients: int,
    alpha: float,
    min_size: int,
    seed: int,
    max_retries: int = 100,
) -> tuple[list[list[int]], dict[int, Array]]:
    y = np.asarray(labels, dtype=np.int64)
    rng = np.random.default_rng(seed)
    classes = np.unique(y)
    best: list[list[int]] | None = None
    best_proportions: dict[int, Array] | None = None
    best_min_size = -1
    for _ in range(max_retries):
        client_indices: list[list[int]] = [[] for _ in range(num_clients)]
        proportions_by_class: dict[int, Array] = {}
        for cls in classes:
            cls_indices = np.flatnonzero(y == cls)
            rng.shuffle(cls_indices)
            proportions = rng.dirichlet(np.full(num_clients, float(alpha)))
            proportions_by_class[int(cls)] = proportions.copy()
            split_points = (np.cumsum(proportions)[:-1] * len(cls_indices)).astype(int)
            splits = np.split(cls_indices, split_points)
            for client_id, split in enumerate(splits):
                client_indices[client_id].extend(split.tolist())
        sizes = [len(indices) for indices in client_indices]
        current_min = min(sizes) if sizes else 0
        if current_min > best_min_size:
            best = [indices.copy() for indices in client_indices]
            best_proportions = {cls: values.copy() for cls, values in proportions_by_class.items()}
            best_min_size = current_min
        if current_min >= min_size:
            break
    if best is None or best_proportions is None:
        raise RuntimeError("Dirichlet partition failed")
    for indices in best:
        rng.shuffle(indices)
    return best, best_proportions


def _partition_label_skew_by_proportions(
    labels: Array,
    proportions_by_class: dict[int, Array],
    num_clients: int,
    seed: int,
) -> list[list[int]]:
    y = np.asarray(labels, dtype=np.int64)
    rng = np.random.default_rng(seed)
    client_indices: list[list[int]] = [[] for _ in range(num_clients)]
    for cls in np.unique(y):
        cls_indices = np.flatnonzero(y == cls)
        rng.shuffle(cls_indices)
        proportions = np.asarray(proportions_by_class.get(int(cls), np.full(num_clients, 1.0 / num_clients)), dtype=np.float64)
        proportions = proportions / max(float(np.sum(proportions)), 1e-12)
        split_points = (np.cumsum(proportions)[:-1] * len(cls_indices)).astype(int)
        for client_id, split in enumerate(np.split(cls_indices, split_points)):
            client_indices[client_id].extend(split.tolist())
    for indices in client_indices:
        rng.shuffle(indices)
    return client_indices


def _limit_partition_sizes(splits: list[list[int]], max_size: int, seed: int, labels: Array) -> list[list[int]]:
    if max_size <= 0:
        return splits
    rng = np.random.default_rng(seed)
    y = np.asarray(labels, dtype=np.int64)
    out = []
    for split in splits:
        if len(split) <= max_size:
            out.append(list(split))
        else:
            out.append(_stratified_cap(split, y, max_size, rng))
    return out


def _limit_feature_arrays(x: Array, y: Array, max_size: int, seed: int) -> tuple[Array, Array]:
    if max_size <= 0 or int(y.shape[0]) <= max_size:
        return x, y
    rng = np.random.default_rng(seed)
    capped = _stratified_cap(list(range(int(y.shape[0]))), np.asarray(y, dtype=np.int64), int(max_size), rng)
    capped_idx = np.asarray(capped, dtype=np.int64)
    return x[capped_idx], y[capped_idx]


def _stratified_cap(split: list[int], labels: Array, max_size: int, rng: np.random.Generator) -> list[int]:
    indices = np.asarray(split, dtype=np.int64)
    split_labels = labels[indices]
    classes, counts = np.unique(split_labels, return_counts=True)
    proportions = counts / max(float(np.sum(counts)), 1.0)
    quotas = np.floor(proportions * max_size).astype(int)
    quotas[(counts > 0) & (quotas == 0)] = 1
    while int(np.sum(quotas)) > max_size:
        reducible = np.flatnonzero(quotas > 1)
        if reducible.size == 0:
            break
        quotas[reducible[np.argmax(quotas[reducible])]] -= 1
    while int(np.sum(quotas)) < max_size:
        remaining = counts - quotas
        candidates = np.flatnonzero(remaining > 0)
        if candidates.size == 0:
            break
        quotas[candidates[np.argmax(remaining[candidates])]] += 1
    capped: list[int] = []
    for cls, quota in zip(classes, quotas):
        cls_indices = indices[split_labels == cls].copy()
        rng.shuffle(cls_indices)
        capped.extend(cls_indices[: int(quota)].tolist())
    rng.shuffle(capped)
    return capped
