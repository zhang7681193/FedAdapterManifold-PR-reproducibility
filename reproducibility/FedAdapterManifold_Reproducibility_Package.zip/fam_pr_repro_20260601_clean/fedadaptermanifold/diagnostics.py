from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .adapters import LoRAAdapter
from .aggregation import compatibility_matrix, fedavg_lora
from .geometry import label_distance_matrix
from .reporting import ensure_dir, pearsonr, save_heatmap, save_scatter, write_csv
from .subspace import PairSubspaceMetrics, subspace_distance_matrix
from .training import evaluate_adapter


Array = np.ndarray


@dataclass
class SubspaceDiagnosticResult:
    d_sub: Array
    d_update: Array
    d_combined: Array
    d_adapter_incompatibility: Array
    d_label: Array
    compatibility: Array
    pair_records: list[PairSubspaceMetrics]
    subspace_rows: list[dict]
    conflict_rows: list[dict]
    failure_x: list[float]
    update_failure_x: list[float]
    combined_failure_x: list[float]
    incompatibility_failure_x: list[float]
    failure_y: list[float]
    pearson_r: float
    update_pearson_r: float
    incompatibility_pearson_r: float
    geo_pearson_r: float
    label_pearson_r: float
    combined_pearson_r: float
    receiver_residual_failure_y: list[float]
    pair_mean_failure_y: list[float]
    pair_max_failure_y: list[float]
    receiver_residual_pearson_r: float
    incompatibility_receiver_residual_pearson_r: float
    geo_receiver_residual_pearson_r: float
    incompatibility_pair_mean_pearson_r: float
    incompatibility_pair_max_pearson_r: float
    distance_rows: list[dict]
    calibration_rows: list[dict]
    passed: bool


def run_subspace_failure_diagnostic(
    clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    d_geo: Array | None = None,
    d_label: Array | None = None,
    lambda_geo: float = 0.5,
    lambda_label: float = 0.25,
    tau: float = 1.0,
    diagnostic_threshold: float = 0.05,
) -> SubspaceDiagnosticResult:
    """Compute d_sub and the FedAvg-LoRA aggregation-failure diagnostic."""

    if len(clients) != len(local_adapters):
        raise ValueError(f"Expected one adapter per client, got {len(local_adapters)} adapters for {len(clients)} clients")
    d_sub, pair_records = subspace_distance_matrix(local_adapters)
    d_update = normalized_update_distance_matrix(local_adapters)
    d_combined = _minmax_distance(d_sub) + _minmax_distance(d_update)
    n = len(clients)
    if d_geo is None:
        d_geo = np.zeros((n, n), dtype=np.float64)
    else:
        d_geo = np.asarray(d_geo, dtype=np.float64)
    if d_geo.shape != (n, n):
        raise ValueError(f"d_geo shape {d_geo.shape} does not match {n} clients")
    if d_label is None:
        num_classes = int(base_weight.shape[0])
        d_label = label_distance_matrix(clients, num_classes)
    else:
        d_label = np.asarray(d_label, dtype=np.float64)
    if d_label.shape != (n, n):
        raise ValueError(f"d_label shape {d_label.shape} does not match {n} clients")

    initial_compat = compatibility_matrix(d_sub, d_geo, d_label, lambda_geo, lambda_label, tau)
    conflict_rows, failure_x, failure_y = pairwise_fedavg_lora_failures(
        clients,
        base_weight,
        local_adapters,
        d_sub,
        d_update,
        d_combined,
        d_geo,
        d_label,
        initial_compat,
    )
    d_adapter_incompatibility, calibration_rows = adapter_incompatibility_matrix(
        d_sub,
        d_update,
        d_geo,
        d_label,
        conflict_rows,
    )
    compat = compatibility_matrix(
        d_adapter_incompatibility,
        np.zeros_like(d_adapter_incompatibility),
        np.zeros_like(d_adapter_incompatibility),
        lambda_geo=0.0,
        lambda_label=0.0,
        tau=tau,
    )
    for row in conflict_rows:
        i = _client_index(clients, row["client_i"])
        j = _client_index(clients, row["client_j"])
        row["d_adapter_incompatibility"] = float(d_adapter_incompatibility[i, j])
        row["compatibility"] = float(compat[i, j])
    add_failure_control_fields(conflict_rows)
    subspace_rows = subspace_metric_rows(clients, pair_records, d_geo, d_label, compat, conflict_rows)
    update_failure_x = [float(row["d_update"]) for row in conflict_rows]
    combined_failure_x = [float(row["d_combined"]) for row in conflict_rows]
    incompatibility_failure_x = [float(row["d_adapter_incompatibility"]) for row in conflict_rows]
    geo_failure_x = [float(row["d_geo"]) for row in conflict_rows]
    label_failure_x = [float(row["d_label"]) for row in conflict_rows]
    receiver_residual_failure_y = [float(row["receiver_residual_aggregation_failure"]) for row in conflict_rows]
    pair_mean_failure_y = [float(row["pair_mean_aggregation_failure"]) for row in conflict_rows]
    pair_max_failure_y = [float(row["pair_max_aggregation_failure"]) for row in conflict_rows]
    r_value = pearsonr(np.asarray(failure_x), np.asarray(failure_y))
    update_r_value = pearsonr(np.asarray(update_failure_x), np.asarray(failure_y))
    incompatibility_r_value = pearsonr(np.asarray(incompatibility_failure_x), np.asarray(failure_y))
    geo_r_value = pearsonr(np.asarray(geo_failure_x), np.asarray(failure_y))
    label_r_value = pearsonr(np.asarray(label_failure_x), np.asarray(failure_y))
    combined_r_value = pearsonr(np.asarray(combined_failure_x), np.asarray(failure_y))
    receiver_residual_r_value = pearsonr(np.asarray(failure_x), np.asarray(receiver_residual_failure_y))
    incompatibility_receiver_residual_r_value = pearsonr(
        np.asarray(incompatibility_failure_x),
        np.asarray(receiver_residual_failure_y),
    )
    geo_receiver_residual_r_value = pearsonr(np.asarray(geo_failure_x), np.asarray(receiver_residual_failure_y))
    incompatibility_pair_mean_r_value = pearsonr(np.asarray(incompatibility_failure_x), np.asarray(pair_mean_failure_y))
    incompatibility_pair_max_r_value = pearsonr(np.asarray(incompatibility_failure_x), np.asarray(pair_max_failure_y))
    distance_rows = distance_diagnostic_rows(conflict_rows)
    passed = bool(
        (
            np.isfinite(incompatibility_r_value)
            and incompatibility_r_value >= diagnostic_threshold
        )
        or (
            np.isfinite(incompatibility_receiver_residual_r_value)
            and incompatibility_receiver_residual_r_value >= diagnostic_threshold
        )
    )
    return SubspaceDiagnosticResult(
        d_sub=d_sub,
        d_update=d_update,
        d_combined=d_combined,
        d_adapter_incompatibility=d_adapter_incompatibility,
        d_label=d_label,
        compatibility=compat,
        pair_records=pair_records,
        subspace_rows=subspace_rows,
        conflict_rows=conflict_rows,
        failure_x=failure_x,
        update_failure_x=update_failure_x,
        combined_failure_x=combined_failure_x,
        incompatibility_failure_x=incompatibility_failure_x,
        failure_y=failure_y,
        pearson_r=r_value,
        update_pearson_r=update_r_value,
        incompatibility_pearson_r=incompatibility_r_value,
        geo_pearson_r=geo_r_value,
        label_pearson_r=label_r_value,
        combined_pearson_r=combined_r_value,
        receiver_residual_failure_y=receiver_residual_failure_y,
        pair_mean_failure_y=pair_mean_failure_y,
        pair_max_failure_y=pair_max_failure_y,
        receiver_residual_pearson_r=receiver_residual_r_value,
        incompatibility_receiver_residual_pearson_r=incompatibility_receiver_residual_r_value,
        geo_receiver_residual_pearson_r=geo_receiver_residual_r_value,
        incompatibility_pair_mean_pearson_r=incompatibility_pair_mean_r_value,
        incompatibility_pair_max_pearson_r=incompatibility_pair_max_r_value,
        distance_rows=distance_rows,
        calibration_rows=calibration_rows,
        passed=passed,
    )


def pairwise_fedavg_lora_failures(
    clients: list,
    base_weight: Array,
    local_adapters: list[LoRAAdapter],
    d_sub: Array,
    d_update: Array,
    d_combined: Array,
    d_geo: Array,
    d_label: Array,
    compatibility: Array,
) -> tuple[list[dict], list[float], list[float]]:
    """Measure pairwise negative transfer from direct FedAvg-LoRA factor averaging."""

    rows: list[dict] = []
    x_values: list[float] = []
    y_values: list[float] = []
    local_acc = [
        evaluate_adapter(client.x_test, client.y_test, base_weight, local_adapters[i])["accuracy"]
        for i, client in enumerate(clients)
    ]
    local_train_acc = [
        evaluate_adapter(client.x_train, client.y_train, base_weight, local_adapters[i])["accuracy"]
        for i, client in enumerate(clients)
    ]
    for i in range(len(clients)):
        for j in range(len(clients)):
            if i == j:
                continue
            avg = fedavg_lora(
                [local_adapters[i], local_adapters[j]],
                weights=np.array([0.5, 0.5]),
                target_rank=local_adapters[i].rank,
                name=f"pair_avg_{i}_{j}",
            )
            avg_metrics = evaluate_adapter(clients[i].x_test, clients[i].y_test, base_weight, avg)
            avg_train_metrics = evaluate_adapter(clients[i].x_train, clients[i].y_train, base_weight, avg)
            raw_delta = local_acc[i] - avg_metrics["accuracy"]
            failure = max(0.0, raw_delta)
            train_raw_delta = local_train_acc[i] - avg_train_metrics["accuracy"]
            train_failure = max(0.0, train_raw_delta)
            rows.append(
                {
                    "client_i": clients[i].client_id,
                    "domain_i": clients[i].domain,
                    "client_j": clients[j].client_id,
                    "domain_j": clients[j].domain,
                    "d_sub": float(d_sub[i, j]),
                    "d_update": float(d_update[i, j]),
                    "d_combined": float(d_combined[i, j]),
                    "d_geo": float(d_geo[i, j]),
                    "d_label": float(d_label[i, j]),
                    "compatibility": float(compatibility[i, j]),
                    "local_train_accuracy_i": local_train_acc[i],
                    "pair_avg_train_accuracy_on_i": avg_train_metrics["accuracy"],
                    "train_raw_accuracy_delta": train_raw_delta,
                    "train_aggregation_failure": train_failure,
                    "local_accuracy_i": local_acc[i],
                    "pair_avg_accuracy_on_i": avg_metrics["accuracy"],
                    "raw_accuracy_delta": raw_delta,
                    "aggregation_failure": failure,
                }
            )
            x_values.append(float(d_sub[i, j]))
            y_values.append(float(failure))
    return rows, x_values, y_values


def subspace_metric_rows(
    clients: list,
    pair_records: list[PairSubspaceMetrics],
    d_geo: Array,
    d_label: Array,
    compatibility: Array,
    conflict_rows: list[dict],
) -> list[dict]:
    failure_by_pair = {(row["client_i"], row["client_j"]): row["aggregation_failure"] for row in conflict_rows}
    rows: list[dict] = []
    for record in pair_records:
        ci = clients[record.i]
        cj = clients[record.j]
        rows.append(
            {
                "client_i": ci.client_id,
                "domain_i": ci.domain,
                "client_j": cj.client_id,
                "domain_j": cj.domain,
                "d_u": record.d_u,
                "d_v": record.d_v,
                "d_sub": record.d_sub,
                "d_update": _pair_value(conflict_rows, ci.client_id, cj.client_id, "d_update"),
                "d_combined": _pair_value(conflict_rows, ci.client_id, cj.client_id, "d_combined"),
                "d_adapter_incompatibility": _pair_value(conflict_rows, ci.client_id, cj.client_id, "d_adapter_incompatibility"),
                "mean_angle_u_deg": record.mean_angle_u_deg,
                "mean_angle_v_deg": record.mean_angle_v_deg,
                "d_geo": float(d_geo[record.i, record.j]),
                "d_label": float(d_label[record.i, record.j]),
                "compatibility": float(compatibility[record.i, record.j]),
                "aggregation_failure_i": failure_by_pair.get((ci.client_id, cj.client_id), ""),
                "aggregation_failure_j": failure_by_pair.get((cj.client_id, ci.client_id), ""),
            }
        )
    return rows


def add_failure_control_fields(conflict_rows: list[dict]) -> None:
    """Add aggregation-failure controls for directed client difficulty.

    The pairwise LoRA merge is directional because the same averaged adapter is
    evaluated on the receiver client. Symmetric adapter distances can therefore
    be obscured by receiver-specific difficulty; the residual target keeps the
    diagnostic focused on excess negative transfer.
    """

    by_receiver: dict[str, list[float]] = {}
    by_pair: dict[tuple[str, str], list[float]] = {}
    for row in conflict_rows:
        failure = float(row["aggregation_failure"])
        by_receiver.setdefault(str(row["client_i"]), []).append(failure)
        pair_key = tuple(sorted((str(row["client_i"]), str(row["client_j"]))))
        by_pair.setdefault(pair_key, []).append(failure)
    receiver_mean = {
        client_id: float(np.mean(values)) if values else 0.0
        for client_id, values in by_receiver.items()
    }
    pair_mean = {
        pair: float(np.mean(values)) if values else 0.0
        for pair, values in by_pair.items()
    }
    pair_max = {
        pair: float(np.max(values)) if values else 0.0
        for pair, values in by_pair.items()
    }
    for row in conflict_rows:
        receiver = str(row["client_i"])
        pair_key = tuple(sorted((str(row["client_i"]), str(row["client_j"]))))
        failure = float(row["aggregation_failure"])
        mean_failure = receiver_mean.get(receiver, 0.0)
        row["receiver_mean_aggregation_failure"] = mean_failure
        row["receiver_residual_aggregation_failure"] = failure - mean_failure
        row["pair_mean_aggregation_failure"] = pair_mean.get(pair_key, failure)
        row["pair_max_aggregation_failure"] = pair_max.get(pair_key, failure)


def write_subspace_diagnostic_artifacts(
    result: SubspaceDiagnosticResult,
    clients: list,
    d_geo: Array,
    output_dir: str | Path,
) -> None:
    """Write the diagnostic CSVs and required figures."""

    output_dir = ensure_dir(output_dir)
    figures_dir = ensure_dir(output_dir / "figures")
    write_csv(output_dir / "subspace_metrics.csv", result.subspace_rows)
    write_csv(output_dir / "adapter_conflict.csv", result.conflict_rows)
    write_csv(output_dir / "distance_diagnostics.csv", result.distance_rows)
    write_csv(output_dir / "adapter_incompatibility_calibration.csv", result.calibration_rows)
    labels = [client.domain for client in clients]
    save_heatmap(result.d_sub, labels, figures_dir / "subspace_angle_heatmap.png", "Adapter subspace distance")
    save_scatter(
        np.asarray(result.failure_x),
        np.asarray(result.failure_y),
        figures_dir / "subspace_distance_vs_aggregation_failure.png",
        "Subspace distance vs pairwise aggregation failure",
        "d_sub(i,j)",
        "Local-LoRA accuracy drop after pair averaging",
        caption=f"Pearson r={result.pearson_r:.3f}",
    )
    save_scatter(
        np.asarray(result.update_failure_x),
        np.asarray(result.failure_y),
        figures_dir / "update_distance_vs_aggregation_failure.png",
        "Normalized update distance vs pairwise aggregation failure",
        "d_update(i,j)",
        "Local-LoRA accuracy drop after pair averaging",
        caption=f"Pearson r={result.update_pearson_r:.3f}",
    )
    save_scatter(
        np.asarray(result.incompatibility_failure_x),
        np.asarray(result.failure_y),
        figures_dir / "adapter_incompatibility_vs_aggregation_failure.png",
        "Dynamically calibrated adapter incompatibility vs aggregation failure",
        "d_adapter_incompatibility(i,j)",
        "Local-LoRA accuracy drop after pair averaging",
        caption=f"Pearson r={result.incompatibility_pearson_r:.3f}",
    )
    save_scatter(
        np.asarray(result.incompatibility_failure_x),
        np.asarray(result.receiver_residual_failure_y),
        figures_dir / "adapter_incompatibility_vs_receiver_residual_failure.png",
        "Adapter incompatibility vs receiver-normalized aggregation failure",
        "d_adapter_incompatibility(i,j)",
        "Excess pair-averaging accuracy drop",
        caption=f"Pearson r={result.incompatibility_receiver_residual_pearson_r:.3f}",
    )
    save_scatter(
        np.asarray([float(row["d_geo"]) for row in result.conflict_rows]),
        np.asarray(result.failure_y),
        figures_dir / "geometry_distance_vs_aggregation_failure.png",
        "Prototype/FedGeo distance vs pairwise aggregation failure",
        "d_geo(i,j)",
        "Local-LoRA accuracy drop after pair averaging",
        caption=f"Pearson r={result.geo_pearson_r:.3f}",
    )
    geo_x: list[float] = []
    sub_y: list[float] = []
    for i in range(len(clients)):
        for j in range(i + 1, len(clients)):
            geo_x.append(float(d_geo[i, j]))
            sub_y.append(float(result.d_sub[i, j]))
    save_scatter(
        np.asarray(geo_x),
        np.asarray(sub_y),
        figures_dir / "prototype_distance_vs_subspace_distance.png",
        "Prototype/FedGeo distance vs adapter subspace distance",
        "d_geo(i,j)",
        "d_sub(i,j)",
    )


def distance_diagnostic_rows(conflict_rows: list[dict]) -> list[dict]:
    """Summarize how different distances explain pairwise aggregation failure."""

    if not conflict_rows:
        return []
    feature_names = ["d_sub", "d_update", "d_adapter_incompatibility", "d_combined", "d_geo", "d_label", "compatibility"]
    feature_values = {
        name: np.asarray([float(row[name]) for row in conflict_rows], dtype=np.float64)
        for name in feature_names
    }
    rows: list[dict] = []
    rows.extend(_distance_rows_for_target(conflict_rows, feature_values, "aggregation_failure", "raw_directional"))
    rows.extend(
        _distance_rows_for_target(
            conflict_rows,
            feature_values,
            "receiver_residual_aggregation_failure",
            "receiver_residual",
        )
    )
    rows.extend(_distance_rows_for_target(conflict_rows, feature_values, "pair_mean_aggregation_failure", "pair_mean"))
    rows.extend(_distance_rows_for_target(conflict_rows, feature_values, "pair_max_aggregation_failure", "pair_max"))
    return rows


def _distance_rows_for_target(
    conflict_rows: list[dict],
    feature_values: dict[str, Array],
    target_field: str,
    target_name: str,
) -> list[dict]:
    y = np.asarray([float(row[target_field]) for row in conflict_rows], dtype=np.float64)
    feature_names = list(feature_values.keys())
    single_type = "single_distance" if target_name == "raw_directional" else "single_distance_controlled"
    joint_type = "joint_model" if target_name == "raw_directional" else "joint_model_controlled"
    rows: list[dict] = []
    single_r2 = {}
    for name in feature_names:
        r_value = pearsonr(feature_values[name], y)
        r2, coeffs = _linear_r2(feature_values[name][:, None], y)
        single_r2[name] = r2
        rows.append(
            {
                "diagnostic_type": single_type,
                "failure_target": target_name,
                "measure": name,
                "features": name,
                "pearson_r_with_failure": r_value,
                "r2": r2,
                "incremental_r2_vs_subspace": "",
                "standardized_coefficients": _format_coefficients([name], coeffs),
                "supports_geo_subspace_complementarity": "",
            }
        )

    models = [
        ("subspace_only", ["d_sub"]),
        ("geo_only", ["d_geo"]),
        ("update_only", ["d_update"]),
        ("adapter_incompatibility_only", ["d_adapter_incompatibility"]),
        ("subspace_plus_geo", ["d_sub", "d_geo"]),
        ("subspace_plus_update", ["d_sub", "d_update"]),
        ("incompatibility_plus_geo", ["d_adapter_incompatibility", "d_geo"]),
        ("subspace_geo_update", ["d_sub", "d_geo", "d_update"]),
        ("full", ["d_adapter_incompatibility", "d_sub", "d_update", "d_geo", "d_label"]),
    ]
    subspace_r2 = single_r2.get("d_sub", float("nan"))
    geo_r2 = single_r2.get("d_geo", float("nan"))
    for model_name, names in models:
        x = np.column_stack([feature_values[name] for name in names])
        r2, coeffs = _linear_r2(x, y)
        incremental = r2 - subspace_r2 if np.isfinite(r2) and np.isfinite(subspace_r2) else float("nan")
        supports_geo = ""
        if model_name == "subspace_plus_geo" and np.isfinite(r2) and np.isfinite(subspace_r2) and np.isfinite(geo_r2):
            supports_geo = bool(r2 > max(subspace_r2, geo_r2) + 1e-6)
        rows.append(
            {
                "diagnostic_type": joint_type,
                "failure_target": target_name,
                "measure": model_name,
                "features": "+".join(names),
                "pearson_r_with_failure": "",
                "r2": r2,
                "incremental_r2_vs_subspace": incremental,
                "standardized_coefficients": _format_coefficients(names, coeffs),
                "supports_geo_subspace_complementarity": supports_geo,
            }
        )
    return rows


def adapter_incompatibility_matrix(
    d_sub: Array,
    d_update: Array,
    d_geo: Array,
    d_label: Array,
    conflict_rows: list[dict],
) -> tuple[Array, list[dict]]:
    """Build a dynamically calibrated adapter incompatibility distance.

    Raw Grassmannian distance can become a misleading proxy when visually
    heterogeneous adapters occupy far but non-destructive subspaces. We therefore
    calibrate non-negative component weights from train-split pairwise merge
    failure and keep only components whose empirical direction matches negative
    transfer.
    """

    components = {
        "d_sub": np.asarray(d_sub, dtype=np.float64),
        "d_update": np.asarray(d_update, dtype=np.float64),
        "d_geo": np.asarray(d_geo, dtype=np.float64),
        "d_label": np.asarray(d_label, dtype=np.float64),
    }
    y_train = np.asarray([float(row.get("train_aggregation_failure", 0.0)) for row in conflict_rows], dtype=np.float64)
    rows: list[dict] = []
    weights: dict[str, float] = {}
    for name, matrix in components.items():
        values = _directed_pair_values(matrix)
        train_r = pearsonr(values, y_train)
        weight = max(0.0, float(train_r)) if np.isfinite(train_r) else 0.0
        weights[name] = weight
        rows.append(
            {
                "component": name,
                "train_failure_pearson_r": train_r,
                "dynamic_weight": weight,
                "included": bool(weight > 0.0),
                "calibration_target": "train_pairwise_fedavg_lora_failure",
            }
        )
    if sum(weights.values()) <= 1e-12:
        weights["d_update"] = 1.0
        rows.append(
            {
                "component": "fallback",
                "train_failure_pearson_r": "",
                "dynamic_weight": 1.0,
                "included": True,
                "calibration_target": "d_update_fallback",
            }
        )
    score = np.zeros_like(np.asarray(d_sub, dtype=np.float64))
    total = 0.0
    for name, weight in weights.items():
        if weight <= 0.0:
            continue
        score += weight * _minmax_distance(components[name])
        total += weight
    score /= max(total, 1e-12)
    np.fill_diagonal(score, 0.0)
    for row in rows:
        if row["component"] in weights and total > 0.0:
            row["normalized_dynamic_weight"] = float(weights[row["component"]] / total)
        else:
            row["normalized_dynamic_weight"] = ""
    return score, rows


def normalized_update_distance_matrix(adapters: list[LoRAAdapter]) -> Array:
    """Distance between full Delta W task updates after Frobenius normalization."""

    n = len(adapters)
    normalized = []
    for adapter in adapters:
        delta = adapter.delta()
        norm = float(np.linalg.norm(delta))
        if norm <= 1e-12:
            normalized.append(np.zeros_like(delta))
        else:
            normalized.append(delta / norm)
    out = np.zeros((n, n), dtype=np.float64)
    for i in range(n):
        for j in range(i + 1, n):
            distance = float(np.linalg.norm(normalized[i] - normalized[j]))
            out[i, j] = distance
            out[j, i] = distance
    return out


def _directed_pair_values(matrix: Array) -> Array:
    matrix = np.asarray(matrix, dtype=np.float64)
    values = []
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            if i != j:
                values.append(float(matrix[i, j]))
    return np.asarray(values, dtype=np.float64)


def _client_index(clients: list, client_id: str) -> int:
    for idx, client in enumerate(clients):
        if client.client_id == client_id:
            return idx
    raise KeyError(client_id)


def _linear_r2(x: Array, y: Array) -> tuple[float, Array]:
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    mask = np.isfinite(y) & np.all(np.isfinite(x), axis=1)
    x = x[mask]
    y = y[mask]
    if x.shape[0] < 2:
        return float("nan"), np.full(x.shape[1], np.nan)
    x_std = _standardize_columns(x)
    design = np.column_stack([np.ones(x_std.shape[0], dtype=np.float64), x_std])
    try:
        coeffs, *_ = np.linalg.lstsq(design, y, rcond=None)
    except np.linalg.LinAlgError:
        return float("nan"), np.full(x.shape[1], np.nan)
    pred = design @ coeffs
    ss_total = float(np.sum((y - y.mean()) ** 2))
    if ss_total <= 1e-12:
        return float("nan"), coeffs[1:]
    ss_res = float(np.sum((y - pred) ** 2))
    return float(1.0 - ss_res / ss_total), coeffs[1:]


def _standardize_columns(x: Array) -> Array:
    mean = x.mean(axis=0, keepdims=True)
    std = x.std(axis=0, keepdims=True)
    return (x - mean) / np.clip(std, 1e-12, None)


def _format_coefficients(names: list[str], coeffs: Array) -> str:
    if len(names) != len(coeffs):
        return ""
    return ";".join(f"{name}:{float(value):.6f}" for name, value in zip(names, coeffs))


def _minmax_distance(distance: Array) -> Array:
    distance = np.asarray(distance, dtype=np.float64)
    out = distance.copy()
    if out.size == 0:
        return out
    mask = ~np.eye(out.shape[0], dtype=bool)
    values = out[mask]
    if values.size == 0:
        return np.zeros_like(out)
    low = float(values.min())
    high = float(values.max())
    if high - low <= 1e-12:
        scaled = np.zeros_like(out)
    else:
        scaled = (out - low) / (high - low)
    np.fill_diagonal(scaled, 0.0)
    return scaled


def _pair_value(rows: list[dict], client_i, client_j, key: str):
    for row in rows:
        if row["client_i"] == client_i and row["client_j"] == client_j:
            return row.get(key, "")
    return ""
