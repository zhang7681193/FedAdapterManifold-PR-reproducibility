from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image


Array = np.ndarray


class NumpyImageFeatureExtractor:
    """Small frozen image descriptor for environments without torch.

    This is not meant to replace CLIP/ResNet18 in the full study. It keeps
    the data path operational until a visual foundation backend is installed.
    """

    def __init__(self, image_size: int = 32, hist_bins: int = 8) -> None:
        self.image_size = int(image_size)
        self.hist_bins = int(hist_bins)

    @property
    def output_dim(self) -> int:
        return 6 + 3 * self.hist_bins + 16 * 16 + 8

    def extract_path(self, path: str | Path) -> Array:
        image = Image.open(path).convert("RGB").resize((self.image_size, self.image_size))
        return self.extract_array(np.asarray(image, dtype=np.uint8))

    def extract_array(self, image: Array) -> Array:
        arr_uint8 = np.asarray(image)
        if arr_uint8.ndim == 2:
            arr_uint8 = np.repeat(arr_uint8[:, :, None], 3, axis=2)
        if arr_uint8.ndim == 3 and arr_uint8.shape[2] == 1:
            arr_uint8 = np.repeat(arr_uint8, 3, axis=2)
        if arr_uint8.ndim != 3 or arr_uint8.shape[2] < 3:
            raise ValueError(f"Expected an HxWxC image array, got shape {arr_uint8.shape}")
        if arr_uint8.shape[:2] != (self.image_size, self.image_size):
            pil = Image.fromarray(np.uint8(arr_uint8[:, :, :3])).resize((self.image_size, self.image_size))
            arr_uint8 = np.asarray(pil, dtype=np.uint8)
        arr = np.asarray(arr_uint8[:, :, :3], dtype=np.float64) / 255.0
        means = arr.mean(axis=(0, 1))
        stds = arr.std(axis=(0, 1))
        hists = []
        for channel in range(3):
            hist, _ = np.histogram(arr[:, :, channel], bins=self.hist_bins, range=(0.0, 1.0), density=True)
            hists.append(hist / np.clip(hist.sum(), 1e-12, None))
        gray = arr.mean(axis=2)
        small = Image.fromarray(np.uint8(gray * 255.0)).resize((16, 16))
        patch = np.asarray(small, dtype=np.float64).reshape(-1) / 255.0
        gx = np.diff(gray, axis=1, append=gray[:, -1:])
        gy = np.diff(gray, axis=0, append=gray[-1:, :])
        mag = np.sqrt(gx * gx + gy * gy)
        edge_hist, _ = np.histogram(mag, bins=8, range=(0.0, max(float(mag.max()), 1e-6)), density=True)
        edge_hist = edge_hist / np.clip(edge_hist.sum(), 1e-12, None)
        feat = np.concatenate([means, stds, *hists, patch, edge_hist])
        feat = feat - feat.mean()
        norm = np.linalg.norm(feat)
        return feat / max(norm, 1e-12)

    def extract_paths(self, paths: list[str | Path]) -> Array:
        return np.vstack([self.extract_path(path) for path in paths])

    def extract_arrays(self, images: Array) -> Array:
        return np.vstack([self.extract_array(image) for image in np.asarray(images)])


class TorchvisionResNet18FeatureExtractor:
    """Lazy ResNet18 extractor. Requires torch and torchvision."""

    def __init__(self, pretrained: bool = False, device: str = "cpu", batch_size: int = 64) -> None:
        try:
            import torch
            import torchvision.models as models
            import torchvision.transforms as transforms
        except ImportError as exc:
            raise ImportError(
                "TorchvisionResNet18FeatureExtractor requires torch and torchvision. "
                "Use --feature-backbone numpy for the built-in fallback."
            ) from exc
        self.torch = torch
        self.device = device
        self.batch_size = int(max(1, batch_size))
        weights = models.ResNet18_Weights.DEFAULT if pretrained else None
        model = models.resnet18(weights=weights)
        model.fc = torch.nn.Identity()
        model.eval().to(device)
        for param in model.parameters():
            param.requires_grad_(False)
        self.model = model
        self.transforms = transforms.Compose(
            [
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ]
        )

    @property
    def output_dim(self) -> int:
        return 512

    def extract_path(self, path: str | Path) -> Array:
        return self.extract_paths([path])[0]

    def extract_paths(self, paths: list[str | Path]) -> Array:
        features = []
        with self.torch.no_grad():
            for start in range(0, len(paths), self.batch_size):
                batch_paths = paths[start : start + self.batch_size]
                tensors = []
                for path in batch_paths:
                    image = Image.open(path).convert("RGB")
                    tensors.append(self.transforms(image))
                tensor = self.torch.stack(tensors, dim=0).to(self.device)
                feat = self.model(tensor).cpu().numpy().astype(np.float64)
                norms = np.linalg.norm(feat, axis=1, keepdims=True)
                features.append(feat / np.clip(norms, 1e-12, None))
        return np.vstack(features)

def _clean_label_for_prompt(label: str) -> str:
    return str(label).replace("_", " ").replace("-", " ").strip().lower()


class ClipImageFeatureExtractor:
    """OpenAI CLIP image encoder wrapper.

    This uses the local ``clip`` package when installed. Model weights must be
    available in CLIP's cache, or ``clip.load`` will try to download them.
    """

    MODEL_ALIASES = {
        "clip-rn50": "RN50",
        "clip-vit-b32": "ViT-B/32",
        "clip-vit-b16": "ViT-B/16",
        "clip-vit-l14": "ViT-L/14",
    }

    def __init__(self, model_name: str = "ViT-B/32", device: str = "cpu", batch_size: int = 64) -> None:
        try:
            import clip
            import torch
        except ImportError as exc:
            raise ImportError(
                "ClipImageFeatureExtractor requires the OpenAI clip package. "
                "Use --feature-backbone resnet18-pretrained or numpy if CLIP is unavailable."
            ) from exc
        self.clip = clip
        self.torch = torch
        self.device = device
        self.batch_size = int(max(1, batch_size))
        resolved = self.MODEL_ALIASES.get(str(model_name).lower(), str(model_name))
        self.model_name = resolved
        self.model, self.preprocess = clip.load(resolved, device=device)
        self.model.eval()
        for param in self.model.parameters():
            param.requires_grad_(False)

    @property
    def output_dim(self) -> int:
        return int(getattr(self.model.visual, "output_dim", 512))

    def extract_path(self, path: str | Path) -> Array:
        return self.extract_paths([path])[0]

    def extract_paths(self, paths: list[str | Path]) -> Array:
        features = []
        with self.torch.no_grad():
            for start in range(0, len(paths), self.batch_size):
                batch_paths = paths[start : start + self.batch_size]
                tensors = []
                for path in batch_paths:
                    image = Image.open(path).convert("RGB")
                    tensors.append(self.preprocess(image))
                tensor = self.torch.stack(tensors, dim=0).to(self.device)
                feat = self.model.encode_image(tensor).float().cpu().numpy().astype(np.float64)
                norms = np.linalg.norm(feat, axis=1, keepdims=True)
                features.append(feat / np.clip(norms, 1e-12, None))
        return np.vstack(features)

    def encode_text_labels(self, labels: list[str], prompt_template: str = "a photo of a {label}.") -> Array:
        prompts = [prompt_template.format(label=_clean_label_for_prompt(label)) for label in labels]
        with self.torch.no_grad():
            tokens = self.clip.tokenize(prompts, truncate=True).to(self.device)
            feat = self.model.encode_text(tokens).float().cpu().numpy().astype(np.float64)
        norms = np.linalg.norm(feat, axis=1, keepdims=True)
        return feat / np.clip(norms, 1e-12, None)


class DinoV2ImageFeatureExtractor:
    """DINOv2 image encoder wrapper using Hugging Face Transformers.

    The model weights must be available in the local Hugging Face cache, or
    ``from_pretrained`` will try to download them. We use the CLS token (or
    pooler output when exposed) as a frozen visual feature.
    """

    MODEL_ALIASES = {
        "dinov2-vits14": "facebook/dinov2-small",
        "dinov2-vitb14": "facebook/dinov2-base",
        "dinov2-vitl14": "facebook/dinov2-large",
        "dinov2-small": "facebook/dinov2-small",
        "dinov2-base": "facebook/dinov2-base",
        "dinov2-large": "facebook/dinov2-large",
    }

    def __init__(self, model_name: str = "dinov2-vits14", device: str = "cpu", batch_size: int = 64) -> None:
        try:
            import torch
            from transformers import AutoImageProcessor, AutoModel
        except ImportError as exc:
            raise ImportError(
                "DinoV2ImageFeatureExtractor requires torch and transformers. "
                "Use --feature-backbone resnet18-pretrained or numpy if DINOv2 is unavailable."
            ) from exc
        self.torch = torch
        self.device = device
        self.batch_size = int(max(1, batch_size))
        resolved = self.MODEL_ALIASES.get(str(model_name).lower(), str(model_name))
        self.model_name = resolved
        try:
            self.processor = AutoImageProcessor.from_pretrained(resolved, local_files_only=True)
            self.model = AutoModel.from_pretrained(resolved, local_files_only=True).eval().to(device)
        except Exception:
            self.processor = AutoImageProcessor.from_pretrained(resolved)
            self.model = AutoModel.from_pretrained(resolved).eval().to(device)
        for param in self.model.parameters():
            param.requires_grad_(False)
        self._output_dim = int(getattr(self.model.config, "hidden_size", 384))

    @property
    def output_dim(self) -> int:
        return self._output_dim

    def extract_path(self, path: str | Path) -> Array:
        return self.extract_paths([path])[0]

    def extract_paths(self, paths: list[str | Path]) -> Array:
        features = []
        with self.torch.no_grad():
            for start in range(0, len(paths), self.batch_size):
                batch_paths = paths[start : start + self.batch_size]
                images = [Image.open(path).convert("RGB") for path in batch_paths]
                inputs = self.processor(images=images, return_tensors="pt")
                inputs = {key: value.to(self.device) for key, value in inputs.items()}
                outputs = self.model(**inputs)
                feat = getattr(outputs, "pooler_output", None)
                if feat is None:
                    feat = outputs.last_hidden_state[:, 0]
                feat = feat.float().cpu().numpy().astype(np.float64)
                norms = np.linalg.norm(feat, axis=1, keepdims=True)
                features.append(feat / np.clip(norms, 1e-12, None))
        return np.vstack(features)
