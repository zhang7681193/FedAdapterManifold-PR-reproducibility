from __future__ import annotations

from pathlib import Path
import csv
import pickle
from typing import Any

import numpy as np


REQUIRED_ROUND_FILES = [
    "client_signatures_round_{round_id}.pkl",
    "d_geo_round_{round_id}.npy",
    "geometry_graph_round_{round_id}.npy",
    "novelty_scores_round_{round_id}.csv",
    "coverage_deficit_round_{round_id}.csv",
    "prototypes_round_{round_id}.pkl",
]


def validate_geometry_outputs(path: str | Path, round_id: int = 0) -> tuple[list[dict], list[dict]]:
    """Validate the shared FedGeo output contract used by FedAdapterManifold."""

    root = Path(path)
    rows: list[dict] = []
    issues: list[dict] = []
    _check_required_files(root, round_id, rows, issues)

    d_geo = _load_npy(root / f"d_geo_round_{round_id}.npy", "d_geo", rows, issues)
    graph = _load_npy(root / f"geometry_graph_round_{round_id}.npy", "geometry_graph", rows, issues)
    signatures = _load_pickle(root / f"client_signatures_round_{round_id}.pkl", "client_signatures", rows, issues)
    prototypes = _load_pickle(root / f"prototypes_round_{round_id}.pkl", "prototypes", rows, issues)
    novelty = _load_score_csv(root / f"novelty_scores_round_{round_id}.csv", "novelty", rows, issues, aliases=["novelty_score"])
    coverage = _load_score_csv(root / f"coverage_deficit_round_{round_id}.csv", "coverage_deficit", rows, issues)

    n = _infer_num_clients(d_geo, graph, signatures, prototypes, novelty, coverage)
    rows.append({"check": "num_clients", "status": "info", "value": n, "details": ""})

    _validate_square_matrix(d_geo, "d_geo", n, rows, issues, require_zero_diag=True)
    _validate_square_matrix(graph, "geometry_graph", n, rows, issues, require_zero_diag=False)
    _validate_graph(graph, n, rows, issues)
    _validate_signatures(signatures, n, round_id, rows, issues)
    _validate_prototypes(prototypes, n, rows, issues)
    _validate_scores(novelty, "novelty_scores", n, rows, issues)
    _validate_scores(coverage, "coverage_deficit", n, rows, issues)
    return rows, issues


def _check_required_files(root: Path, round_id: int, rows: list[dict], issues: list[dict]) -> None:
    for pattern in REQUIRED_ROUND_FILES:
        name = pattern.format(round_id=round_id)
        path = root / name
        ok = path.exists()
        rows.append({"check": "required_file", "status": "pass" if ok else "fail", "value": name, "details": str(path)})
        if not ok:
            issues.append({"severity": "error", "check": "required_file", "message": f"Missing {path}"})


def _load_npy(path: Path, name: str, rows: list[dict], issues: list[dict]) -> np.ndarray | None:
    if not path.exists():
        return None
    try:
        value = np.load(path)
    except (ImportError, ModuleNotFoundError) as exc:
        issues.append({"severity": "warning", "check": name, "message": f"Could not load {path}: {exc}"})
        return None
    except Exception as exc:
        issues.append({"severity": "error", "check": name, "message": f"Could not load {path}: {exc}"})
        return None
    rows.append({"check": f"{name}_shape", "status": "info", "value": "x".join(map(str, value.shape)), "details": str(path)})
    return np.asarray(value, dtype=np.float64)


def _load_pickle(path: Path, name: str, rows: list[dict], issues: list[dict]) -> Any | None:
    if not path.exists():
        return None
    try:
        with path.open("rb") as handle:
            value = pickle.load(handle)
    except Exception as exc:
        severity = "warning" if _is_optional_pickle_dependency_error(exc) else "error"
        issues.append({"severity": severity, "check": name, "message": f"Could not load {path}: {exc}"})
        return None
    size = len(value) if hasattr(value, "__len__") else ""
    rows.append({"check": f"{name}_entries", "status": "info", "value": size, "details": str(type(value).__name__)})
    return value


def _is_optional_pickle_dependency_error(exc: Exception) -> bool:
    text = str(exc)
    return isinstance(exc, (ImportError, ModuleNotFoundError, AttributeError)) or "No module named" in text


def _load_score_csv(
    path: Path,
    column: str,
    rows: list[dict],
    issues: list[dict],
    aliases: list[str] | None = None,
) -> list[dict] | None:
    if not path.exists():
        return None
    try:
        with path.open("r", newline="", encoding="utf-8") as handle:
            records = list(csv.DictReader(handle))
    except Exception as exc:
        issues.append({"severity": "error", "check": column, "message": f"Could not load {path}: {exc}"})
        return None
    rows.append({"check": f"{column}_entries", "status": "info", "value": len(records), "details": str(path)})
    columns = [column, *(aliases or [])]
    if records and not any(name in records[0] for name in columns):
        issues.append({"severity": "error", "check": column, "message": f"{path} missing column {column}"})
    if records and "client_id" not in records[0]:
        issues.append({"severity": "error", "check": column, "message": f"{path} missing column client_id"})
    return records


def _infer_num_clients(*values: Any) -> int:
    for value in values:
        if value is None:
            continue
        if isinstance(value, np.ndarray) and value.ndim >= 1:
            return int(value.shape[0])
        if hasattr(value, "__len__"):
            return int(len(value))
    return 0


def _validate_square_matrix(
    matrix: np.ndarray | None,
    name: str,
    n: int,
    rows: list[dict],
    issues: list[dict],
    require_zero_diag: bool,
) -> None:
    if matrix is None:
        return
    ok_shape = matrix.shape == (n, n) and n > 0
    rows.append({"check": f"{name}_square", "status": "pass" if ok_shape else "fail", "value": matrix.shape, "details": ""})
    if not ok_shape:
        issues.append({"severity": "error", "check": f"{name}_square", "message": f"{name} shape {matrix.shape} is not {n}x{n}"})
        return
    finite = bool(np.isfinite(matrix).all())
    symmetric_error = float(np.max(np.abs(matrix - matrix.T))) if matrix.size else 0.0
    diag_error = float(np.max(np.abs(np.diag(matrix)))) if matrix.size else 0.0
    rows.append({"check": f"{name}_finite", "status": "pass" if finite else "fail", "value": finite, "details": ""})
    rows.append({"check": f"{name}_symmetry_max_abs", "status": "pass" if symmetric_error <= 1e-6 else "warn", "value": symmetric_error, "details": ""})
    if require_zero_diag:
        rows.append({"check": f"{name}_zero_diag", "status": "pass" if diag_error <= 1e-6 else "warn", "value": diag_error, "details": ""})
    if not finite:
        issues.append({"severity": "error", "check": f"{name}_finite", "message": f"{name} contains non-finite values"})


def _validate_graph(graph: np.ndarray | None, n: int, rows: list[dict], issues: list[dict]) -> None:
    if graph is None or graph.shape != (n, n):
        return
    nonnegative = bool((graph >= -1e-12).all())
    degree = np.sum(np.maximum(graph, 0.0), axis=1)
    isolated = int(np.sum(degree <= 1e-12))
    rows.append({"check": "geometry_graph_nonnegative", "status": "pass" if nonnegative else "fail", "value": nonnegative, "details": ""})
    rows.append({"check": "geometry_graph_isolated_clients", "status": "pass" if isolated == 0 else "warn", "value": isolated, "details": ""})
    if not nonnegative:
        issues.append({"severity": "error", "check": "geometry_graph_nonnegative", "message": "geometry_graph has negative weights"})
    if isolated:
        issues.append({"severity": "warning", "check": "geometry_graph_isolated_clients", "message": f"{isolated} clients have no graph edges"})


def _validate_signatures(signatures: Any, n: int, round_id: int, rows: list[dict], issues: list[dict]) -> None:
    if signatures is None:
        return
    values = list(signatures.values()) if isinstance(signatures, dict) else list(signatures)
    ok_len = len(values) == n
    rows.append({"check": "client_signatures_count", "status": "pass" if ok_len else "fail", "value": len(values), "details": ""})
    if not ok_len:
        issues.append({"severity": "error", "check": "client_signatures_count", "message": f"Expected {n} signatures, got {len(values)}"})
    required = ["client_id", "round_id", "prototypes", "variances", "radii", "uncertainties", "counts", "label_histogram"]
    missing = 0
    round_mismatch = 0
    for signature in values:
        if not isinstance(signature, dict):
            missing += 1
            continue
        missing += sum(1 for key in required if key not in signature)
        if "round_id" in signature and int(signature["round_id"]) != int(round_id):
            round_mismatch += 1
    rows.append({"check": "client_signature_missing_fields", "status": "pass" if missing == 0 else "fail", "value": missing, "details": ""})
    rows.append({"check": "client_signature_round_mismatch", "status": "pass" if round_mismatch == 0 else "warn", "value": round_mismatch, "details": ""})
    if missing:
        issues.append({"severity": "error", "check": "client_signature_missing_fields", "message": f"{missing} required signature fields missing"})


def _validate_prototypes(prototypes: Any, n: int, rows: list[dict], issues: list[dict]) -> None:
    if prototypes is None:
        return
    if isinstance(prototypes, dict):
        values = list(prototypes.values())
    else:
        values = list(prototypes)
    ok_len = len(values) == n
    rows.append({"check": "prototypes_client_count", "status": "pass" if ok_len else "warn", "value": len(values), "details": ""})
    empty_clients = 0
    total_classes = 0
    for proto_map in values:
        if not proto_map:
            empty_clients += 1
        elif isinstance(proto_map, dict):
            total_classes += len(proto_map)
        else:
            arr = _as_float_array(proto_map)
            total_classes += int(arr.shape[0]) if arr.ndim >= 2 else 0
    rows.append({"check": "prototypes_empty_clients", "status": "pass" if empty_clients == 0 else "warn", "value": empty_clients, "details": ""})
    rows.append({"check": "prototypes_total_class_entries", "status": "info", "value": total_classes, "details": ""})
    if empty_clients:
        issues.append({"severity": "warning", "check": "prototypes_empty_clients", "message": f"{empty_clients} clients have no prototypes"})


def _validate_scores(records: list[dict] | None, name: str, n: int, rows: list[dict], issues: list[dict]) -> None:
    if records is None:
        return
    ok_len = len(records) == n
    rows.append({"check": f"{name}_count", "status": "pass" if ok_len else "warn", "value": len(records), "details": ""})
    if not ok_len:
        issues.append({"severity": "warning", "check": f"{name}_count", "message": f"Expected {n} {name} rows, got {len(records)}"})


def _as_float_array(value: Any) -> np.ndarray:
    obj = value
    if hasattr(obj, "detach"):
        obj = obj.detach()
    if hasattr(obj, "cpu"):
        obj = obj.cpu()
    if hasattr(obj, "numpy"):
        try:
            obj = obj.numpy()
        except TypeError:
            pass
    return np.asarray(obj, dtype=np.float64)
