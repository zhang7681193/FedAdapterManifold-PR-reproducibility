from __future__ import annotations

import numpy as np


def allocate_ranks(
    policy: str,
    num_clients: int,
    base_rank: int,
    min_rank: int = 2,
    max_rank: int | None = None,
    novelty: np.ndarray | None = None,
    conflict: np.ndarray | None = None,
    risk: np.ndarray | None = None,
    feature_energy_deficit: np.ndarray | None = None,
    seed: int = 0,
) -> list[int]:
    max_rank = int(max_rank or max(base_rank, min_rank))
    base_rank = int(base_rank)
    min_rank = int(min_rank)
    rng = np.random.default_rng(seed)
    if policy == "fixed":
        return [base_rank for _ in range(num_clients)]
    if policy == "random":
        span = _centered_rank_span(base_rank, min_rank, max_rank)
        low = max(min_rank, base_rank - span)
        high = min(max_rank, base_rank + span)
        return [int(rng.integers(low, high + 1)) for _ in range(num_clients)]
    if policy == "novelty-aware":
        if _raw_score_spread(novelty, num_clients) < 0.05:
            return [base_rank for _ in range(num_clients)]
        scores = _normalize_scores(novelty, num_clients)
        return _scores_to_ranks(scores, min_rank, max_rank)
    if policy == "conflict-aware":
        conflict_scores = _normalize_scores(conflict, num_clients)
        if novelty is not None:
            novelty_scores = _normalize_scores(novelty, num_clients)
            scores = 0.65 * conflict_scores + 0.35 * novelty_scores
        else:
            scores = conflict_scores
        return _scores_to_centered_ranks(scores, base_rank, min_rank, max_rank)
    if policy == "risk-aware":
        scores = auxiliary_risk_capacity_scores(risk, feature_energy_deficit, novelty, num_clients)
        if _raw_score_spread(scores, num_clients) < 0.05:
            return [base_rank for _ in range(num_clients)]
        return _scores_to_centered_ranks(scores, base_rank, min_rank, max_rank)
    raise ValueError(f"Unknown rank policy: {policy}")


def conflict_scores_from_distance(d_sub: np.ndarray) -> np.ndarray:
    d_sub = np.asarray(d_sub, dtype=np.float64)
    if d_sub.ndim != 2 or d_sub.shape[0] != d_sub.shape[1]:
        raise ValueError(f"d_sub must be a square matrix, got {d_sub.shape}")
    if d_sub.shape[0] <= 1:
        return np.zeros(d_sub.shape[0], dtype=np.float64)
    masked = d_sub.copy()
    np.fill_diagonal(masked, np.nan)
    return np.nanmean(masked, axis=1)


def auxiliary_risk_capacity_scores(
    risk: np.ndarray | None,
    feature_energy_deficit: np.ndarray | None,
    novelty: np.ndarray | None,
    num_clients: int,
) -> np.ndarray:
    """Auxiliary rare-mode score for rank capacity, separate from manifold geometry.

    FedAdapterManifold still builds adapter neighborhoods from d_geo and the
    geometry graph.  This score is only a capacity prior for ablations where
    FedGeo exposes risk/reliability signals.
    """

    parts = []
    weights = []
    if risk is not None and np.isfinite(np.asarray(risk, dtype=np.float64)).any():
        parts.append(_normalize_scores(np.asarray(risk, dtype=np.float64), num_clients))
        weights.append(0.55)
    if feature_energy_deficit is not None and np.isfinite(np.asarray(feature_energy_deficit, dtype=np.float64)).any():
        parts.append(_normalize_scores(np.asarray(feature_energy_deficit, dtype=np.float64), num_clients))
        weights.append(0.30)
    if novelty is not None and np.isfinite(np.asarray(novelty, dtype=np.float64)).any():
        parts.append(_normalize_scores(np.asarray(novelty, dtype=np.float64), num_clients))
        weights.append(0.15)
    if not parts:
        return np.ones(num_clients, dtype=np.float64)
    weights_arr = np.asarray(weights, dtype=np.float64)
    weights_arr = weights_arr / np.clip(weights_arr.sum(), 1e-12, None)
    stacked = np.vstack(parts)
    return weights_arr @ stacked


def _normalize_scores(values: np.ndarray | None, n: int) -> np.ndarray:
    if values is None:
        return np.ones(n, dtype=np.float64)
    values = np.asarray(values, dtype=np.float64)
    if values.size != n:
        raise ValueError(f"Expected {n} scores, got {values.size}")
    values = np.where(np.isfinite(values), values, np.nan)
    if not np.isfinite(values).any():
        return np.ones(n, dtype=np.float64)
    fill = float(np.nanmedian(values))
    values = np.where(np.isfinite(values), values, fill)
    values = values - values.min()
    denom = values.max()
    if denom <= 1e-12:
        return np.ones(n, dtype=np.float64)
    return values / denom


def _scores_to_ranks(scores: np.ndarray, min_rank: int, max_rank: int) -> list[int]:
    ranks = min_rank + np.rint(scores * (max_rank - min_rank)).astype(np.int64)
    return [int(max(min_rank, min(max_rank, r))) for r in ranks]


def _scores_to_centered_ranks(scores: np.ndarray, base_rank: int, min_rank: int, max_rank: int) -> list[int]:
    span = max(1, (max_rank - min_rank) // 3)
    ranks = base_rank + np.rint((np.asarray(scores) - 0.5) * 2.0 * span).astype(np.int64)
    return [int(max(min_rank, min(max_rank, r))) for r in ranks]


def _centered_rank_span(base_rank: int, min_rank: int, max_rank: int) -> int:
    available = max(1, max_rank - min_rank)
    return max(1, min(base_rank - min_rank, max_rank - base_rank, available // 4))


def _raw_score_spread(values: np.ndarray | None, n: int) -> float:
    if values is None:
        return 0.0
    values = np.asarray(values, dtype=np.float64)
    if values.size != n:
        raise ValueError(f"Expected {n} scores, got {values.size}")
    values = values[np.isfinite(values)]
    if values.size == 0:
        return 0.0
    return float(values.max() - values.min())
