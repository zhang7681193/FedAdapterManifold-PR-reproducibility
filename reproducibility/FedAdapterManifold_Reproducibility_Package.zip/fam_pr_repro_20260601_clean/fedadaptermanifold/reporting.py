from __future__ import annotations

from pathlib import Path
import csv
import math

import numpy as np
from PIL import Image, ImageDraw, ImageFont


Array = np.ndarray


def ensure_dir(path: str | Path) -> Path:
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_csv(path: str | Path, rows: list[dict], fieldnames: list[str] | None = None) -> None:
    path = Path(path)
    ensure_dir(path.parent)
    if fieldnames is None:
        keys = []
        for row in rows:
            for key in row.keys():
                if key not in keys:
                    keys.append(key)
        fieldnames = keys
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})


def pearsonr(x: Array, y: Array) -> float:
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    if x.size < 2:
        return float("nan")
    x = x - x.mean()
    y = y - y.mean()
    denom = np.sqrt(np.sum(x * x) * np.sum(y * y))
    if denom <= 1e-12:
        return float("nan")
    return float(np.sum(x * y) / denom)


def save_heatmap(matrix: Array, labels: list[str], path: str | Path, title: str) -> None:
    path = Path(path)
    matrix = np.asarray(matrix, dtype=np.float64)
    n = matrix.shape[0]
    cell = 48
    left = 126
    top = 72
    width = left + n * cell + 30
    height = top + n * cell + 70
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    font = _font(13)
    title_font = _font(17)
    draw.text((left, 24), title, fill=(20, 25, 30), font=title_font)
    finite = matrix[np.isfinite(matrix)]
    min_v = float(finite.min()) if finite.size else 0.0
    max_v = float(finite.max()) if finite.size else 1.0
    if abs(max_v - min_v) < 1e-12:
        max_v = min_v + 1.0
    for i in range(n):
        draw.text((12, top + i * cell + 16), labels[i][:16], fill=(30, 35, 40), font=font)
        draw.text((left + i * cell + 6, top - 24), labels[i][:7], fill=(30, 35, 40), font=font)
        for j in range(n):
            value = float(matrix[i, j])
            color = _heat_color((value - min_v) / (max_v - min_v))
            x0 = left + j * cell
            y0 = top + i * cell
            draw.rectangle([x0, y0, x0 + cell - 2, y0 + cell - 2], fill=color)
            text = f"{value:.2f}"
            draw.text((x0 + 8, y0 + 16), text, fill=(15, 15, 15), font=font)
    _save_image(image, path)


def save_scatter(
    x: Array,
    y: Array,
    path: str | Path,
    title: str,
    x_label: str,
    y_label: str,
    caption: str = "",
) -> None:
    path = Path(path)
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    width, height = 900, 620
    left, right, top, bottom = 92, 32, 66, 82
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    font = _font(15)
    title_font = _font(20)
    draw.text((left, 24), title, fill=(20, 25, 30), font=title_font)
    plot = (left, top, width - right, height - bottom)
    draw.rectangle(plot, outline=(35, 40, 45), width=2)
    x_min, x_max = _limits(x)
    y_min, y_max = _limits(y)
    for tick in range(6):
        tx = plot[0] + tick * (plot[2] - plot[0]) / 5.0
        ty = plot[3] - tick * (plot[3] - plot[1]) / 5.0
        draw.line([(tx, plot[3]), (tx, plot[3] + 5)], fill=(35, 40, 45))
        draw.line([(plot[0] - 5, ty), (plot[0], ty)], fill=(35, 40, 45))
        xv = x_min + tick * (x_max - x_min) / 5.0
        yv = y_min + tick * (y_max - y_min) / 5.0
        draw.text((tx - 18, plot[3] + 10), f"{xv:.2f}", fill=(45, 50, 55), font=font)
        draw.text((12, ty - 9), f"{yv:.2f}", fill=(45, 50, 55), font=font)
    for xi, yi in zip(x, y):
        px = _map(float(xi), x_min, x_max, plot[0], plot[2])
        py = _map(float(yi), y_min, y_max, plot[3], plot[1])
        draw.ellipse([px - 5, py - 5, px + 5, py + 5], fill=(41, 128, 185), outline=(20, 70, 110))
    if x.size >= 2 and np.std(x) > 1e-12:
        slope, intercept = np.polyfit(x, y, 1)
        x0, x1 = x_min, x_max
        y0, y1 = slope * x0 + intercept, slope * x1 + intercept
        draw.line(
            [
                (_map(x0, x_min, x_max, plot[0], plot[2]), _map(y0, y_min, y_max, plot[3], plot[1])),
                (_map(x1, x_min, x_max, plot[0], plot[2]), _map(y1, y_min, y_max, plot[3], plot[1])),
            ],
            fill=(192, 57, 43),
            width=3,
        )
    draw.text((plot[0] + 260, height - 36), x_label, fill=(25, 30, 35), font=font)
    draw.text((12, 30), y_label, fill=(25, 30, 35), font=font)
    if caption:
        draw.text((left, height - 60), caption, fill=(40, 45, 50), font=font)
    _save_image(image, path)


def save_routing_heatmap(routing: Array, client_labels: list[str], path: str | Path) -> None:
    path = Path(path)
    labels = [f"bank_{i}" for i in range(routing.shape[1])]
    matrix = np.asarray(routing, dtype=np.float64)
    cell_w, cell_h = 72, 42
    left, top = 132, 72
    width = left + matrix.shape[1] * cell_w + 40
    height = top + matrix.shape[0] * cell_h + 60
    image = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(image)
    font = _font(14)
    draw.text((left, 24), "Adapter bank routing weights", fill=(20, 25, 30), font=_font(18))
    for k, label in enumerate(labels):
        draw.text((left + k * cell_w + 6, top - 24), label, fill=(30, 35, 40), font=font)
    for i, client in enumerate(client_labels):
        draw.text((10, top + i * cell_h + 12), client[:18], fill=(30, 35, 40), font=font)
        for k in range(matrix.shape[1]):
            value = float(matrix[i, k])
            x0 = left + k * cell_w
            y0 = top + i * cell_h
            draw.rectangle([x0, y0, x0 + cell_w - 2, y0 + cell_h - 2], fill=_heat_color(value))
            draw.text((x0 + 16, y0 + 12), f"{value:.2f}", fill=(15, 15, 15), font=font)
    _save_image(image, path)


def _limits(values: Array) -> tuple[float, float]:
    finite = values[np.isfinite(values)]
    if finite.size == 0:
        return 0.0, 1.0
    lo = float(finite.min())
    hi = float(finite.max())
    if math.isclose(lo, hi):
        lo -= 0.5
        hi += 0.5
    pad = 0.06 * (hi - lo)
    return lo - pad, hi + pad


def _save_image(image: Image.Image, path: Path) -> None:
    ensure_dir(path.parent)
    try:
        image.save(str(path))
    except FileNotFoundError:
        ensure_dir(path.parent)
        try:
            image.save(str(path))
        except FileNotFoundError:
            # CSV metrics are the source of truth; plot export should not fail a long run.
            return


def _map(value: float, lo: float, hi: float, out_lo: float, out_hi: float) -> float:
    return out_lo + (value - lo) * (out_hi - out_lo) / max(hi - lo, 1e-12)


def _heat_color(t: float) -> tuple[int, int, int]:
    t = float(np.clip(t, 0.0, 1.0))
    # Blue -> ivory -> red, readable on white reports.
    if t < 0.5:
        p = t / 0.5
        return (
            int(54 + p * (245 - 54)),
            int(115 + p * (244 - 115)),
            int(178 + p * (230 - 178)),
        )
    p = (t - 0.5) / 0.5
    return (
        int(245 + p * (192 - 245)),
        int(244 + p * (80 - 244)),
        int(230 + p * (77 - 230)),
    )


def _font(size: int):
    try:
        return ImageFont.truetype("arial.ttf", size)
    except OSError:
        return ImageFont.load_default()
