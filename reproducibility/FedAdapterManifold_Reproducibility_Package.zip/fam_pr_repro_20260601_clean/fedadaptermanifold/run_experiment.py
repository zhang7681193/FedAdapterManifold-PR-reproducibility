from __future__ import annotations

from pathlib import Path
import argparse
import sys

import numpy as np

from .adapters import LoRAAdapter
from .baselines import (
    run_adapter_bank_baseline,
    evaluate_client_adapters,
    run_clustered_lora_baseline,
    run_fedgeo_agg_baseline,
    run_fedgeo_diag_baseline,
    run_ditto_lora_baseline,
    run_fedavg_lift_baseline,
    run_fedavg_lora_baseline,
    run_fedamp_lora_baseline,
    run_fedper_lora_baseline,
    run_fedproto_lora_baseline,
    run_fedprox_lora_baseline,
    run_fedrot_lora_baseline,
    run_local_lora,
    run_pfedme_lora_baseline,
    run_scaffold_lora_baseline,
    run_subspace_compatible_baseline,
    select_loss_constrained_graph_mix,
    summarize_method,
)
from .aggregation import compatibility_matrix, graph_compatible_aggregate, select_adapter_bank_k
from .claims import build_single_run_claim_report
from .config import DEFAULT_CONFIG, merge_defaults, save_yaml_copy
from .data import load_cifar10_clients, load_image_folder_clients, load_medmnist_npz_clients, make_synthetic_manifold_clients
from .diagnostics import run_subspace_failure_diagnostic
from .geometry import (
    FedGeoFileGeometryProvider,
    LocalPrototypeGeometry,
    cluster_prototypes_from_geometry,
    label_distance_matrix,
    write_geometry_outputs,
)
from .rank import allocate_ranks
from .rank import conflict_scores_from_distance
from .reporting import (
    ensure_dir,
    save_heatmap,
    save_routing_heatmap,
    save_scatter,
    write_csv,
)
from .training import evaluate_adapter


def build_arg_parser(defaults: dict | None = None) -> argparse.ArgumentParser:
    defaults = defaults or DEFAULT_CONFIG
    parser = argparse.ArgumentParser(description="Run FedAdapterManifold minimal diagnostics.")
    parser.add_argument("--config", type=str, default="")
    parser.add_argument(
        "--dataset",
        choices=["synthetic", "cifar10-debug", "cifar10", "pacs-debug", "image-folder", "medmnist-npz"],
        default=defaults["dataset"],
    )
    parser.add_argument("--data-root", type=str, default=defaults["data_root"])
    parser.add_argument("--domains", type=str, default=defaults.get("domains", ""))
    parser.add_argument("--test-fraction", type=float, default=defaults.get("test_fraction", 0.25))
    parser.add_argument("--output-dir", type=str, default=defaults["output_dir"])
    parser.add_argument(
        "--feature-backbone",
        choices=[
            "numpy",
            "resnet18",
            "resnet18-pretrained",
            "clip-rn50",
            "clip-vit-b32",
            "clip-vit-b16",
            "clip-vit-l14",
            "dinov2-vits14",
            "dinov2-vitb14",
            "dinov2-vitl14",
            "dinov2-small",
            "dinov2-base",
            "dinov2-large",
        ],
        default=defaults["feature_backbone"],
    )
    parser.add_argument("--feature-cache-dir", type=str, default=defaults.get("feature_cache_dir", ""))
    parser.add_argument(
        "--base-head-init",
        choices=["zero", "clip-text"],
        default=defaults.get("base_head_init", "zero"),
    )
    parser.add_argument("--base-head-scale", type=float, default=defaults.get("base_head_scale", 1.0))
    parser.add_argument(
        "--class-prompt-template",
        type=str,
        default=defaults.get("class_prompt_template", "a photo of a {label}."),
    )
    parser.add_argument("--heterogeneity-setting", type=str, default=defaults["heterogeneity_setting"])
    parser.add_argument("--num-clients", type=int, default=defaults["num_clients"])
    parser.add_argument("--num-classes", type=int, default=defaults["num_classes"])
    parser.add_argument("--feature-dim", type=int, default=defaults["feature_dim"])
    parser.add_argument("--dirichlet-alpha", type=float, default=defaults.get("dirichlet_alpha", 0.3))
    parser.add_argument("--min-train-size", type=int, default=defaults.get("min_train_size", 32))
    parser.add_argument("--align-test-with-train", action="store_true", default=defaults.get("align_test_with_train", True))
    parser.add_argument("--no-align-test-with-train", action="store_false", dest="align_test_with_train")
    parser.add_argument("--train-per-client", type=int, default=defaults["train_per_client"])
    parser.add_argument("--test-per-client", type=int, default=defaults["test_per_client"])
    parser.add_argument("--rounds", type=int, default=defaults["rounds"])
    parser.add_argument("--local-epochs", type=int, default=defaults["local_epochs"])
    parser.add_argument("--lr", type=float, default=defaults["lr"])
    parser.add_argument("--batch-size", type=int, default=defaults["batch_size"])
    parser.add_argument("--fedprox-mu", type=float, default=defaults.get("fedprox_mu", 0.01))
    parser.add_argument("--ditto-mu", type=float, default=defaults.get("ditto_mu", 0.01))
    parser.add_argument("--pfedme-mu", type=float, default=defaults.get("pfedme_mu", defaults.get("ditto_mu", 0.01)))
    parser.add_argument("--scaffold-control-lr", type=float, default=defaults.get("scaffold_control_lr", 1.0))
    parser.add_argument(
        "--skip-heavy-personalized-baselines",
        action="store_true",
        default=defaults.get("skip_heavy_personalized_baselines", False),
    )
    parser.add_argument(
        "--fedper-personal-weight-candidates",
        type=str,
        default=defaults.get("fedper_personal_weight_candidates", "0,0.25,0.50,0.75,1.00"),
    )
    parser.add_argument(
        "--fedper-personal-weight-tolerance",
        type=float,
        default=defaults.get("fedper_personal_weight_tolerance", 0.005),
    )
    parser.add_argument(
        "--fedper-fam-personal-weight-candidates",
        type=str,
        default=defaults.get("fedper_fam_personal_weight_candidates", "0,0.25,0.50,0.75,1.00"),
    )
    parser.add_argument(
        "--fedper-fam-loss-tolerance",
        type=float,
        default=defaults.get("fedper_fam_loss_tolerance", 0.005),
    )
    parser.add_argument(
        "--fedper-fam-policy",
        choices=["loss-min", "loss-constrained", "personal-fallback"],
        default=defaults.get("fedper_fam_policy", "loss-min"),
    )
    parser.add_argument(
        "--ditto-fam-personal-weight-candidates",
        type=str,
        default=defaults.get("ditto_fam_personal_weight_candidates", "0,0.25,0.50,0.75,1.00"),
    )
    parser.add_argument(
        "--ditto-fam-loss-tolerance",
        type=float,
        default=defaults.get("ditto_fam_loss_tolerance", 0.005),
    )
    parser.add_argument(
        "--ditto-fam-policy",
        choices=["loss-min", "loss-constrained", "personal-fallback"],
        default=defaults.get("ditto_fam_policy", "personal-fallback"),
    )
    parser.add_argument("--rank", type=int, default=defaults["rank"])
    parser.add_argument(
        "--rank-policy",
        choices=["fixed", "random", "novelty-aware", "conflict-aware", "risk-aware"],
        default=defaults["rank_policy"],
    )
    parser.add_argument("--min-rank", type=int, default=defaults["min_rank"])
    parser.add_argument("--max-rank", type=int, default=defaults["max_rank"])
    parser.add_argument("--adapter-bank-k", type=int, default=defaults["adapter_bank_k"])
    parser.add_argument(
        "--adapter-graph-mode",
        choices=["fedgeo", "complete", "self", "random"],
        default=defaults.get("adapter_graph_mode", "fedgeo"),
    )
    parser.add_argument("--adapter-graph-self-weight", type=float, default=defaults.get("adapter_graph_self_weight", 1.0))
    parser.add_argument("--adapter-graph-mix-weight", type=float, default=defaults.get("adapter_graph_mix_weight", 1.0))
    parser.add_argument(
        "--adapter-graph-mix-policy",
        choices=["fixed", "loss-min", "loss-constrained"],
        default=defaults.get("adapter_graph_mix_policy", "fixed"),
    )
    parser.add_argument("--adapter-graph-mix-tolerance", type=float, default=defaults.get("adapter_graph_mix_tolerance", 0.005))
    parser.add_argument("--adapter-graph-mix-candidates", type=str, default=defaults.get("adapter_graph_mix_candidates", ""))
    parser.add_argument(
        "--adapter-graph-distance",
        choices=["combined", "none"],
        default=defaults.get("adapter_graph_distance", "combined"),
    )
    parser.add_argument(
        "--adapter-graph-compatibility",
        choices=["method", "none"],
        default=defaults.get("adapter_graph_compatibility", "method"),
    )
    parser.add_argument(
        "--adapter-bank-routing",
        choices=["client", "feature", "feature-prior", "feature-prior-dynamic"],
        default=defaults["adapter_bank_routing"],
    )
    parser.add_argument("--adapter-bank-prior-weight", type=float, default=defaults["adapter_bank_prior_weight"])
    parser.add_argument("--lambda-geo", type=float, default=defaults["lambda_geo"])
    parser.add_argument("--lambda-label", type=float, default=defaults["lambda_label"])
    parser.add_argument(
        "--manifold-distance-components",
        choices=["all", "d_sub", "d_geo", "d_label", "d_sub_d_geo", "d_sub_d_label", "d_geo_d_label"],
        default=defaults.get("manifold_distance_components", "all"),
    )
    parser.add_argument("--tau", type=float, default=defaults["tau"])
    parser.add_argument("--route-tau", type=float, default=defaults["route_tau"])
    parser.add_argument("--shared-weight", type=float, default=defaults["shared_weight"])
    parser.add_argument(
        "--shared-weight-policy",
        choices=["fixed", "loss-min", "loss-constrained"],
        default=defaults.get("shared_weight_policy", "fixed"),
    )
    parser.add_argument("--shared-weight-tolerance", type=float, default=defaults.get("shared_weight_tolerance", 0.005))
    parser.add_argument("--shared-weight-candidates", type=str, default=defaults.get("shared_weight_candidates", ""))
    parser.add_argument("--personal-weight", type=float, default=defaults["personal_weight"])
    parser.add_argument(
        "--personal-weight-policy",
        choices=["fixed", "loss-min", "loss-constrained", "heterogeneity-aware", "uncertainty-constrained"],
        default=defaults.get("personal_weight_policy", "fixed"),
    )
    parser.add_argument("--personal-weight-tolerance", type=float, default=defaults.get("personal_weight_tolerance", 0.005))
    parser.add_argument("--personal-weight-candidates", type=str, default=defaults.get("personal_weight_candidates", ""))
    parser.add_argument("--manifold-smoothing-weight", type=float, default=defaults.get("manifold_smoothing_weight", 0.0))
    parser.add_argument(
        "--manifold-smoothing-policy",
        choices=[
            "fixed",
            "loss-constrained",
            "cluster-loss-constrained",
            "safe-loss-constrained",
            "safe-cluster-loss-constrained",
        ],
        default=defaults.get("manifold_smoothing_policy", "fixed"),
    )
    parser.add_argument("--manifold-smoothing-tolerance", type=float, default=defaults.get("manifold_smoothing_tolerance", 0.005))
    parser.add_argument("--manifold-smoothing-candidates", type=str, default=defaults.get("manifold_smoothing_candidates", ""))
    parser.add_argument(
        "--candidate-selector-policy",
        choices=[
            "loss-min",
            "diagnostic-gated",
            "anchored-no-regret",
            "loss-softmax",
            "gibbs",
            "gibbs-lcb",
            "safe-gibbs",
            "safe-gibbs-lcb",
        ],
        default=defaults.get("candidate_selector_policy", "diagnostic-gated"),
    )
    parser.add_argument(
        "--strong-candidate-selector-policy",
        choices=[
            "loss-min",
            "diagnostic-gated",
            "anchored-no-regret",
            "loss-softmax",
            "gibbs",
            "gibbs-lcb",
            "safe-gibbs",
            "safe-gibbs-lcb",
        ],
        default=defaults.get("strong_candidate_selector_policy", "loss-min"),
    )
    parser.add_argument(
        "--candidate-selector-scope",
        choices=["all", "adapter-only"],
        default=defaults.get("candidate_selector_scope", "all"),
    )
    parser.add_argument(
        "--candidate-selector-loss-tolerance",
        type=float,
        default=defaults.get("candidate_selector_loss_tolerance", 0.005),
    )
    parser.add_argument(
        "--candidate-selector-loss-tolerance-ratio",
        type=float,
        default=defaults.get("candidate_selector_loss_tolerance_ratio", 0.20),
    )
    parser.add_argument(
        "--candidate-selector-neighbor-weight",
        type=float,
        default=defaults.get("candidate_selector_neighbor_weight", 0.0),
    )
    parser.add_argument(
        "--candidate-selector-calibration-fraction",
        type=float,
        default=defaults.get("candidate_selector_calibration_fraction", 0.0),
    )
    parser.add_argument(
        "--candidate-selector-softmax-tau",
        type=float,
        default=defaults.get("candidate_selector_softmax_tau", 0.05),
    )
    parser.add_argument(
        "--candidate-selector-lcb-delta",
        type=float,
        default=defaults.get("candidate_selector_lcb_delta", 0.05),
    )
    parser.add_argument("--geometry-outputs-dir", type=str, default=defaults.get("geometry_outputs_dir", ""))
    parser.add_argument("--round-id", type=int, default=defaults.get("round_id", defaults.get("geometry_round", 0)))
    parser.add_argument("--fedgeo-dir", type=str, default=defaults["fedgeo_dir"])
    parser.add_argument("--geometry-round", type=int, default=defaults["geometry_round"])
    parser.add_argument("--diagnostic-threshold", type=float, default=defaults["diagnostic_threshold"])
    parser.add_argument("--continue-on-failed-diagnostic", action="store_true", default=defaults["continue_on_failed_diagnostic"])
    parser.add_argument("--seed", type=int, default=defaults["seed"])
    parser.add_argument("--device", choices=["cpu", "cuda"], default=defaults["device"])
    parser.add_argument("--cpu-debug", action="store_true", default=defaults["cpu_debug"])
    parser.add_argument("--no-cpu-debug", action="store_false", dest="cpu_debug")
    return parser


def main(argv: list[str] | None = None) -> int:
    raw_argv = list(sys.argv[1:] if argv is None else argv)
    pre_parser = argparse.ArgumentParser(add_help=False)
    pre_parser.add_argument("--config", type=str, default="")
    pre_args, _ = pre_parser.parse_known_args(raw_argv)
    defaults = merge_defaults(pre_args.config or None)
    args = build_arg_parser(defaults).parse_args(raw_argv)
    output_dir = ensure_dir(args.output_dir)
    figures_dir = ensure_dir(output_dir / "figures")
    geometry_outputs_dir = args.geometry_outputs_dir or args.fedgeo_dir
    geometry_round_id = int(args.round_id)
    round_id_was_cli = "--round-id" in raw_argv or any(arg.startswith("--round-id=") for arg in raw_argv)
    if (
        not round_id_was_cli
        and args.round_id == DEFAULT_CONFIG.get("round_id", 0)
        and args.geometry_round != DEFAULT_CONFIG.get("geometry_round", 0)
    ):
        geometry_round_id = int(args.geometry_round)
    effective_config = vars(args).copy()
    effective_config.pop("config", None)
    effective_config["geometry_outputs_dir"] = geometry_outputs_dir
    effective_config["round_id"] = geometry_round_id
    effective_config["geometry_round"] = geometry_round_id

    clients, base_weight, class_names = _load_clients(args)
    clients, selector_clients, calibration_rows = _split_clients_for_candidate_selection(
        clients,
        fraction=args.candidate_selector_calibration_fraction,
        seed=args.seed,
    )
    num_classes = base_weight.shape[0]
    effective_config.update(_effective_data_config(clients, base_weight, class_names))
    save_yaml_copy(output_dir / "config.yaml", effective_config)

    geometry_provider = FedGeoFileGeometryProvider(geometry_outputs_dir) if geometry_outputs_dir else LocalPrototypeGeometry()
    geometry = geometry_provider.build(clients, num_classes=num_classes, round_id=geometry_round_id)
    write_geometry_outputs(output_dir / "geometry_outputs", geometry, round_id=geometry_round_id)
    conflict_probe = None
    conflict_probe_r = None
    conflict_probe_passed = None
    effective_rank_policy = args.rank_policy
    rank_allocation_policy = args.rank_policy
    rank_fallback_reason = ""
    if args.rank_policy == "conflict-aware":
        probe_result = run_local_lora(
            clients,
            base_weight,
            ranks=args.min_rank,
            epochs=max(1, args.local_epochs),
            lr=args.lr,
            batch_size=args.batch_size,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=0,
            method="Conflict-Probe-LoRA",
        )
        probe_diagnostic = run_subspace_failure_diagnostic(
            clients,
            base_weight,
            probe_result.adapters,
            d_geo=geometry.d_geo,
            lambda_geo=args.lambda_geo,
            lambda_label=args.lambda_label,
            tau=args.tau,
            diagnostic_threshold=args.diagnostic_threshold,
        )
        conflict_probe = conflict_scores_from_distance(probe_diagnostic.d_adapter_incompatibility)
        conflict_probe_r = probe_diagnostic.incompatibility_pearson_r
        conflict_probe_passed = probe_diagnostic.passed
        if not probe_diagnostic.passed:
            rank_fallback_reason = "conflict_probe_failed"
            effective_rank_policy = "fixed-fallback"
            rank_allocation_policy = "fixed"
    ranks = allocate_ranks(
        rank_allocation_policy,
        len(clients),
        args.rank,
        min_rank=args.min_rank,
        max_rank=args.max_rank,
        novelty=geometry.novelty,
        conflict=conflict_probe,
        risk=geometry.risk_geo_scores,
        feature_energy_deficit=geometry.feature_energy_deficit,
        seed=args.seed,
    )

    total_local_epochs = args.rounds * args.local_epochs
    base_adapters = [
        LoRAAdapter.zeros(
            input_dim=base_weight.shape[1],
            output_dim=base_weight.shape[0],
            rank=int(rank),
            alpha=float(rank),
            name=f"base_head_{client.client_id}",
        )
        for client, rank in zip(clients, ranks)
    ]
    base_head_metrics = evaluate_client_adapters(
        "Base-Head",
        clients,
        base_weight,
        base_adapters,
        ranks=ranks,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    local_result = run_local_lora(
        clients,
        base_weight,
        ranks=ranks,
        epochs=total_local_epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    local_adapters = local_result.adapters
    local_train_rows = local_result.training_summary

    d_label = label_distance_matrix(clients, num_classes)
    diagnostic = run_subspace_failure_diagnostic(
        clients,
        base_weight,
        local_adapters,
        d_geo=geometry.d_geo,
        d_label=d_label,
        lambda_geo=args.lambda_geo,
        lambda_label=args.lambda_label,
        tau=args.tau,
        diagnostic_threshold=args.diagnostic_threshold,
    )
    if args.rank_policy == "conflict-aware" and effective_rank_policy == "conflict-aware" and not diagnostic.passed:
        rank_fallback_reason = "final_diagnostic_failed"
        effective_rank_policy = "fixed-fallback"
        ranks = allocate_ranks(
            "fixed",
            len(clients),
            args.rank,
            min_rank=args.min_rank,
            max_rank=args.max_rank,
            risk=geometry.risk_geo_scores,
            feature_energy_deficit=geometry.feature_energy_deficit,
            seed=args.seed,
        )
        local_result = run_local_lora(
            clients,
            base_weight,
            ranks=ranks,
            epochs=total_local_epochs,
            lr=args.lr,
            batch_size=args.batch_size,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
        )
        local_adapters = local_result.adapters
        local_train_rows = local_result.training_summary
        diagnostic = run_subspace_failure_diagnostic(
            clients,
            base_weight,
            local_adapters,
            d_geo=geometry.d_geo,
            d_label=d_label,
            lambda_geo=args.lambda_geo,
            lambda_label=args.lambda_label,
            tau=args.tau,
            diagnostic_threshold=args.diagnostic_threshold,
        )
    rank_rows = _rank_rows(
        clients,
        ranks,
        args.rank_policy,
        effective_rank_policy,
        geometry,
        conflict_probe,
        conflict_probe_r,
        conflict_probe_passed,
        rank_fallback_reason,
    )
    d_sub = diagnostic.d_sub
    compat = diagnostic.compatibility
    rank_heterogeneous = len(set(int(rank) for rank in ranks)) > 1
    adapter_distance = diagnostic.d_combined if rank_heterogeneous else d_sub
    manifold_distance = _manifold_distance_matrix(
        args.manifold_distance_components,
        adapter_distance,
        geometry.d_geo,
        d_label,
        lambda_geo=args.lambda_geo,
        lambda_label=args.lambda_label,
    )
    method_compat = _compatibility_from_distance(manifold_distance, args.tau)

    fedavg_lora_result = run_fedavg_lora_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=args.rounds,
        local_epochs=args.local_epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
    )
    fedavg_lora_adapter = fedavg_lora_result.global_adapter
    fedavg_lift_result = run_fedavg_lift_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=args.rounds,
        local_epochs=args.local_epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
    )
    fedprox_result = run_fedprox_lora_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=args.rounds,
        local_epochs=args.local_epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        prox_mu=args.fedprox_mu,
    )
    fedrot_result = run_fedrot_lora_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=args.rounds,
        local_epochs=args.local_epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
    )
    scaffold_result = None
    if not args.skip_heavy_personalized_baselines:
        scaffold_result = run_scaffold_lora_baseline(
            clients,
            base_weight,
            ranks=ranks,
            rounds=args.rounds,
            local_epochs=args.local_epochs,
            lr=args.lr,
            batch_size=args.batch_size,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            control_lr=args.scaffold_control_lr,
        )
    ditto_result = run_ditto_lora_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=args.rounds,
        local_epochs=args.local_epochs,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        prox_mu=args.ditto_mu,
    )
    pfedme_result = None
    if not args.skip_heavy_personalized_baselines:
        pfedme_result = run_pfedme_lora_baseline(
            clients,
            base_weight,
            ranks=ranks,
            rounds=args.rounds,
            local_epochs=args.local_epochs,
            lr=args.lr,
            batch_size=args.batch_size,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            prox_mu=args.pfedme_mu,
        )
    fedgeo_diag_result = run_fedgeo_diag_baseline(
        clients,
        base_weight,
        local_adapters,
        ranks=ranks,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    fedgeo_agg_result = run_fedgeo_agg_baseline(
        clients,
        base_weight,
        local_adapters,
        d_geo=geometry.d_geo,
        graph=geometry.graph,
        ranks=ranks,
        tau=args.tau,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    fedproto_result = run_fedproto_lora_baseline(
        clients,
        base_weight,
        local_adapters,
        d_geo=geometry.d_geo,
        ranks=ranks,
        tau=args.tau,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )

    sca_result = run_subspace_compatible_baseline(
        clients,
        base_weight,
        local_adapters,
        compat,
        ranks=ranks,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    pair_rows = diagnostic.conflict_rows
    failure_x = diagnostic.failure_x
    update_failure_x = diagnostic.update_failure_x
    failure_y = diagnostic.failure_y
    diagnostic_r = diagnostic.incompatibility_pearson_r
    diagnostic_passed = diagnostic.passed

    combined_distance = manifold_distance
    baseline_cluster_k = int(max(1, min(args.adapter_bank_k if args.adapter_bank_k > 0 else 2, len(clients))))
    clustered_result = run_clustered_lora_baseline(
        clients,
        base_weight,
        local_adapters,
        distance=combined_distance,
        ranks=ranks,
        k=baseline_cluster_k,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    fedamp_result = run_fedamp_lora_baseline(
        clients,
        base_weight,
        local_adapters,
        distance=adapter_distance,
        ranks=ranks,
        tau=args.tau,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
    )
    fedper_result = run_fedper_lora_baseline(
        clients,
        base_weight,
        local_adapters,
        shared_adapter=fedavg_lift_result.global_adapter,
        ranks=ranks,
        seed=args.seed,
        dataset=args.dataset,
        heterogeneity_setting=args.heterogeneity_setting,
        round_id=args.rounds,
        candidates=args.fedper_personal_weight_candidates,
        tolerance=args.fedper_personal_weight_tolerance,
    )
    adapter_graph = _select_adapter_graph(geometry.graph, args.adapter_graph_mode, seed=args.seed)
    graph_mixed_adapters = graph_compatible_aggregate(
        local_adapters,
        graph=adapter_graph,
        compatibility=method_compat if args.adapter_graph_compatibility == "method" else None,
        distance=combined_distance if args.adapter_graph_distance == "combined" else None,
        target_ranks=ranks,
        tau=args.tau,
        self_weight=args.adapter_graph_self_weight,
        name_prefix="fedadaptermanifold_graphmix",
    )
    if args.adapter_graph_mix_policy == "fixed":
        manifold_adapters = _blend_fixed_graph_mix(
            local_adapters,
            graph_mixed_adapters,
            weight=args.adapter_graph_mix_weight,
            ranks=ranks,
        )
        graph_mix_rows = _fixed_graph_mix_rows(
            clients,
            weight=args.adapter_graph_mix_weight,
            policy=args.adapter_graph_mix_policy,
        )
    else:
        manifold_adapters, graph_mix_rows = select_loss_constrained_graph_mix(
            clients,
            base_weight,
            local_adapters,
            graph_mixed_adapters,
            ranks=ranks,
            candidates=args.adapter_graph_mix_candidates,
            tolerance=args.adapter_graph_mix_tolerance,
            policy=args.adapter_graph_mix_policy,
        )
    bank_result = None
    client_route_bank_result = None
    fedper_fam_adapters = None
    fedper_fam_metrics = []
    fedper_fam_rows = []
    fedper_fam_selective_adapters = None
    fedper_fam_selective_metrics = []
    ditto_fam_adapters = None
    ditto_fam_metrics = []
    ditto_fam_rows = []
    ditto_fam_selective_adapters = None
    ditto_fam_selective_metrics = []
    selective_adapters = None
    selective_metrics = []
    strong_selective_adapters = None
    strong_selective_metrics = []
    selective_rows = []
    bank_selection_rows = []
    if diagnostic_passed or args.continue_on_failed_diagnostic:
        effective_bank_k = args.adapter_bank_k
        if effective_bank_k <= 0:
            effective_bank_k, bank_selection_rows = select_adapter_bank_k(
                combined_distance,
                max_k=min(4, len(clients)),
            )
        else:
            effective_bank_k = int(max(1, min(args.adapter_bank_k, len(clients))))
            bank_selection_rows = _fixed_bank_selection_rows(combined_distance, effective_bank_k)
        provisional_medoids, provisional_assignments = _bank_assignments(combined_distance, effective_bank_k)
        cluster_prototypes = cluster_prototypes_from_geometry(
            geometry.prototypes,
            geometry.client_ids,
            provisional_assignments,
            num_classes,
            fallback_clients=clients,
        )
        bank_result = run_adapter_bank_baseline(
            clients,
            base_weight,
            manifold_adapters,
            d_geo=geometry.d_geo,
            combined_distance=combined_distance,
            ranks=ranks,
            k=effective_bank_k,
            route_tau=args.route_tau,
            shared_weight=args.shared_weight,
            shared_weight_policy=args.shared_weight_policy,
            shared_weight_tolerance=args.shared_weight_tolerance,
            shared_weight_candidates=args.shared_weight_candidates,
            personal_weight=args.personal_weight,
            personal_weight_policy=args.personal_weight_policy,
            personal_weight_tolerance=args.personal_weight_tolerance,
            personal_weight_candidates=args.personal_weight_candidates,
            cluster_prototypes=cluster_prototypes,
            routing_mode=args.adapter_bank_routing,
            routing_prior_weight=args.adapter_bank_prior_weight,
            personal_adapters=local_adapters,
            smoothing_adapters=fedgeo_agg_result.client_adapters,
            smoothing_weight=args.manifold_smoothing_weight,
            smoothing_policy=args.manifold_smoothing_policy,
            smoothing_tolerance=args.manifold_smoothing_tolerance,
            smoothing_candidates=args.manifold_smoothing_candidates,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
        )
        if args.adapter_bank_routing != "client":
            client_route_bank_result = run_adapter_bank_baseline(
                clients,
                base_weight,
                manifold_adapters,
                d_geo=geometry.d_geo,
                combined_distance=combined_distance,
                ranks=ranks,
                k=effective_bank_k,
                route_tau=args.route_tau,
                shared_weight=args.shared_weight,
                shared_weight_policy=args.shared_weight_policy,
                shared_weight_tolerance=args.shared_weight_tolerance,
                shared_weight_candidates=args.shared_weight_candidates,
                personal_weight=args.personal_weight,
                personal_weight_policy=args.personal_weight_policy,
                personal_weight_tolerance=args.personal_weight_tolerance,
                personal_weight_candidates=args.personal_weight_candidates,
                cluster_prototypes=cluster_prototypes,
                routing_mode="client",
                routing_prior_weight=args.adapter_bank_prior_weight,
                personal_adapters=local_adapters,
                smoothing_adapters=fedgeo_agg_result.client_adapters,
                smoothing_weight=args.manifold_smoothing_weight,
                smoothing_policy=args.manifold_smoothing_policy,
                smoothing_tolerance=args.manifold_smoothing_tolerance,
                smoothing_candidates=args.manifold_smoothing_candidates,
                seed=args.seed,
                dataset=args.dataset,
                heterogeneity_setting=args.heterogeneity_setting,
                round_id=args.rounds,
                method="FedAdapterManifold-ClientRoute",
            )
        selector_candidates = _selector_candidate_pool(
            scope=args.candidate_selector_scope,
            local_adapters=local_adapters,
            fedgeo_agg_adapters=fedgeo_agg_result.client_adapters,
            subspace_adapters=sca_result.client_adapters,
            bank_adapters=bank_result.client_adapters,
        )
        if client_route_bank_result is not None:
            selector_candidates["FedAdapterManifold-ClientRoute"] = client_route_bank_result.client_adapters
        fedper_fam_adapters, fedper_fam_metrics, fedper_fam_rows = _select_fedper_fam_hybrid(
            selector_clients=selector_clients,
            eval_clients=clients,
            base_weight=base_weight,
            personal_adapters=fedper_result.client_adapters,
            fam_adapters=bank_result.client_adapters,
            ranks=ranks,
            candidates=args.fedper_fam_personal_weight_candidates,
            tolerance=args.fedper_fam_loss_tolerance,
            policy=args.fedper_fam_policy,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
            method="FedPer-FAM",
            personal_source_method="FedPer-LoRA",
        )
        ditto_fam_adapters, ditto_fam_metrics, ditto_fam_rows = _select_fedper_fam_hybrid(
            selector_clients=selector_clients,
            eval_clients=clients,
            base_weight=base_weight,
            personal_adapters=ditto_result.personal_adapters,
            fam_adapters=bank_result.client_adapters,
            ranks=ranks,
            candidates=args.ditto_fam_personal_weight_candidates,
            tolerance=args.ditto_fam_loss_tolerance,
            policy=args.ditto_fam_policy,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
            method="Ditto-FAM",
            personal_source_method="Ditto-LoRA",
        )
        high_conflict_prior = _high_conflict_prior(
            local_result.per_client_metrics,
            fedavg_lora_result.per_client_metrics,
            diagnostic.incompatibility_pearson_r,
            args.diagnostic_threshold,
        )
        selector_metrics = _selector_metric_pool(
            scope=args.candidate_selector_scope,
            local_metrics=local_result.per_client_metrics,
            fedgeo_agg_metrics=fedgeo_agg_result.per_client_metrics,
            subspace_metrics=sca_result.per_client_metrics,
            bank_metrics=bank_result.per_client_metrics,
        )
        if client_route_bank_result is not None:
            selector_metrics["FedAdapterManifold-ClientRoute"] = client_route_bank_result.per_client_metrics
        selective_adapters, selective_metrics, selective_rows = _select_client_candidate_adapters(
            selector_clients,
            base_weight,
            selector_candidates,
            candidate_metrics=selector_metrics,
            ranks=ranks,
            graph=geometry.graph,
            policy=args.candidate_selector_policy,
            manifold_prior=high_conflict_prior,
            loss_tolerance=args.candidate_selector_loss_tolerance,
            loss_tolerance_ratio=args.candidate_selector_loss_tolerance_ratio,
            neighbor_weight=args.candidate_selector_neighbor_weight,
            softmax_tau=args.candidate_selector_softmax_tau,
            lcb_delta=args.candidate_selector_lcb_delta,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
            method="FedAdapterManifold-Selective",
        )
        fedper_fam_selective_rows = []
        fedper_fam_selective_adapters, fedper_fam_selective_metrics, fedper_fam_selective_rows = _select_client_candidate_adapters(
            selector_clients,
            base_weight,
            {
                "FedPer-LoRA": fedper_result.client_adapters,
                "FedAdapterManifold": bank_result.client_adapters,
                "FedPer-FAM": fedper_fam_adapters,
            },
            candidate_metrics={
                "FedPer-LoRA": fedper_result.per_client_metrics,
                "FedAdapterManifold": bank_result.per_client_metrics,
                "FedPer-FAM": fedper_fam_metrics,
            },
            ranks=ranks,
            graph=geometry.graph,
            policy="diagnostic-gated",
            manifold_prior=high_conflict_prior,
            loss_tolerance=args.candidate_selector_loss_tolerance,
            loss_tolerance_ratio=args.candidate_selector_loss_tolerance_ratio,
            neighbor_weight=args.candidate_selector_neighbor_weight,
            softmax_tau=args.candidate_selector_softmax_tau,
            lcb_delta=args.candidate_selector_lcb_delta,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
            method="FedPer-FAM-Selective",
        )
        selective_rows.extend(fedper_fam_selective_rows)
        ditto_fam_selective_rows = []
        ditto_fam_selective_adapters, ditto_fam_selective_metrics, ditto_fam_selective_rows = _select_client_candidate_adapters(
            selector_clients,
            base_weight,
            {
                "Ditto-LoRA": ditto_result.personal_adapters,
                "FedAdapterManifold": bank_result.client_adapters,
                "Ditto-FAM": ditto_fam_adapters,
            },
            candidate_metrics={
                "Ditto-LoRA": ditto_result.per_client_metrics,
                "FedAdapterManifold": bank_result.per_client_metrics,
                "Ditto-FAM": ditto_fam_metrics,
            },
            ranks=ranks,
            graph=geometry.graph,
            policy="diagnostic-gated",
            manifold_prior=high_conflict_prior,
            loss_tolerance=args.candidate_selector_loss_tolerance,
            loss_tolerance_ratio=args.candidate_selector_loss_tolerance_ratio,
            neighbor_weight=args.candidate_selector_neighbor_weight,
            softmax_tau=args.candidate_selector_softmax_tau,
            lcb_delta=args.candidate_selector_lcb_delta,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
            method="Ditto-FAM-Selective",
        )
        selective_rows.extend(ditto_fam_selective_rows)
        strong_selector_candidates = dict(selector_candidates)
        strong_selector_candidates.update(
            {
                "FedAvg-Lift": [fedavg_lift_result.global_adapter for _ in clients],
                "FedRot-LoRA": [fedrot_result.global_adapter for _ in clients],
                "FedProx-LoRA": [fedprox_result.global_adapter for _ in clients],
                "Ditto-LoRA": ditto_result.personal_adapters,
                "Ditto-FAM": ditto_fam_adapters,
                "Ditto-FAM-Selective": ditto_fam_selective_adapters,
                "FedProto-LoRA": fedproto_result.client_adapters,
                "FedPer-LoRA": fedper_result.client_adapters,
                "FedPer-FAM": fedper_fam_adapters,
                "FedPer-FAM-Selective": fedper_fam_selective_adapters,
                "Clustered-LoRA": clustered_result.client_adapters,
                "FedAMP-LoRA": fedamp_result.client_adapters,
            }
        )
        if scaffold_result is not None:
            strong_selector_candidates["SCAFFOLD-LoRA"] = [scaffold_result.global_adapter for _ in clients]
        if pfedme_result is not None:
            strong_selector_candidates["pFedMe-LoRA"] = pfedme_result.personal_adapters
        strong_selector_metrics = dict(selector_metrics)
        strong_selector_metrics.update(
            {
                "FedAvg-Lift": fedavg_lift_result.per_client_metrics,
                "FedRot-LoRA": fedrot_result.per_client_metrics,
                "FedProx-LoRA": fedprox_result.per_client_metrics,
                "Ditto-LoRA": ditto_result.per_client_metrics,
                "Ditto-FAM": ditto_fam_metrics,
                "Ditto-FAM-Selective": ditto_fam_selective_metrics,
                "FedProto-LoRA": fedproto_result.per_client_metrics,
                "FedPer-LoRA": fedper_result.per_client_metrics,
                "FedPer-FAM": fedper_fam_metrics,
                "FedPer-FAM-Selective": fedper_fam_selective_metrics,
                "Clustered-LoRA": clustered_result.per_client_metrics,
                "FedAMP-LoRA": fedamp_result.per_client_metrics,
            }
        )
        if scaffold_result is not None:
            strong_selector_metrics["SCAFFOLD-LoRA"] = scaffold_result.per_client_metrics
        if pfedme_result is not None:
            strong_selector_metrics["pFedMe-LoRA"] = pfedme_result.per_client_metrics
        strong_rows = []
        strong_selective_adapters, strong_selective_metrics, strong_rows = _select_client_candidate_adapters(
            selector_clients,
            base_weight,
            strong_selector_candidates,
            candidate_metrics=strong_selector_metrics,
            ranks=ranks,
            graph=geometry.graph,
            policy=args.strong_candidate_selector_policy,
            manifold_prior=False,
            loss_tolerance=args.candidate_selector_loss_tolerance,
            loss_tolerance_ratio=args.candidate_selector_loss_tolerance_ratio,
            neighbor_weight=args.candidate_selector_neighbor_weight,
            softmax_tau=args.candidate_selector_softmax_tau,
            lcb_delta=args.candidate_selector_lcb_delta,
            seed=args.seed,
            dataset=args.dataset,
            heterogeneity_setting=args.heterogeneity_setting,
            round_id=args.rounds,
            method="FedAdapterManifold-StrongSelective",
        )
        selective_rows.extend(strong_rows)

    per_client_rows = []
    per_client_rows.extend(base_head_metrics)
    per_client_rows.extend(local_result.per_client_metrics)
    per_client_rows.extend(fedavg_lora_result.per_client_metrics)
    per_client_rows.extend(fedavg_lift_result.per_client_metrics)
    per_client_rows.extend(fedrot_result.per_client_metrics)
    per_client_rows.extend(fedprox_result.per_client_metrics)
    if scaffold_result is not None:
        per_client_rows.extend(scaffold_result.per_client_metrics)
    per_client_rows.extend(ditto_result.per_client_metrics)
    if pfedme_result is not None:
        per_client_rows.extend(pfedme_result.per_client_metrics)
    per_client_rows.extend(fedgeo_diag_result.per_client_metrics)
    per_client_rows.extend(fedgeo_agg_result.per_client_metrics)
    per_client_rows.extend(fedproto_result.per_client_metrics)
    per_client_rows.extend(fedper_result.per_client_metrics)
    if fedper_fam_metrics:
        per_client_rows.extend(fedper_fam_metrics)
    if fedper_fam_selective_metrics:
        per_client_rows.extend(fedper_fam_selective_metrics)
    if ditto_fam_metrics:
        per_client_rows.extend(ditto_fam_metrics)
    if ditto_fam_selective_metrics:
        per_client_rows.extend(ditto_fam_selective_metrics)
    per_client_rows.extend(clustered_result.per_client_metrics)
    per_client_rows.extend(fedamp_result.per_client_metrics)
    per_client_rows.extend(sca_result.per_client_metrics)
    if bank_result is not None:
        per_client_rows.extend(bank_result.per_client_metrics)
    if client_route_bank_result is not None:
        per_client_rows.extend(client_route_bank_result.per_client_metrics)
    if selective_metrics:
        per_client_rows.extend(selective_metrics)
    if strong_selective_metrics:
        per_client_rows.extend(strong_selective_metrics)
    _add_heterogeneity_alias(per_client_rows)
    _add_geometry_auxiliary_scores(per_client_rows, clients, geometry)
    metrics_rows = summarize_method(per_client_rows, diagnostic_r)
    for row in metrics_rows:
        row["raw_subspace_failure_pearson_r"] = diagnostic.pearson_r
        row["adapter_incompatibility_failure_pearson_r"] = diagnostic.incompatibility_pearson_r
        row["raw_adapter_incompatibility_failure_pearson_r"] = diagnostic.incompatibility_pearson_r
        row["receiver_residual_subspace_failure_pearson_r"] = diagnostic.receiver_residual_pearson_r
        row["receiver_residual_adapter_incompatibility_failure_pearson_r"] = (
            diagnostic.incompatibility_receiver_residual_pearson_r
        )
        row["receiver_residual_geo_failure_pearson_r"] = diagnostic.geo_receiver_residual_pearson_r
        row["pair_mean_adapter_incompatibility_failure_pearson_r"] = diagnostic.incompatibility_pair_mean_pearson_r
        row["pair_max_adapter_incompatibility_failure_pearson_r"] = diagnostic.incompatibility_pair_max_pearson_r
        row["update_failure_pearson_r"] = diagnostic.update_pearson_r
        row["geo_failure_pearson_r"] = diagnostic.geo_pearson_r
        row["label_failure_pearson_r"] = diagnostic.label_pearson_r
        row["combined_failure_pearson_r"] = diagnostic.combined_pearson_r
        row["diagnostic_passed"] = diagnostic_passed
    idea_support_rows = _idea_support_rows(metrics_rows, args.diagnostic_threshold)
    statistical_rows = _statistical_support_rows(per_client_rows, pair_rows, args.seed)

    subspace_rows = diagnostic.subspace_rows
    drop_rows = _drop_rows(clients, base_weight, local_adapters, fedavg_lora_adapter)
    generalization_rows = _local_generalization_rows(local_result.per_client_metrics)
    bank_rows = bank_result.routing_rows if bank_result is not None else []
    sample_bank_rows = bank_result.sample_routing_rows if bank_result is not None else []
    negative_transfer_rows, negative_transfer_summary_rows = _negative_transfer_rows(per_client_rows)
    method_adapters = {
        "Base-Head": base_adapters,
        "Local-LoRA": local_adapters,
        "FedAvg-LoRA": [fedavg_lora_result.global_adapter for _ in clients],
        "FedAvg-Lift": [fedavg_lift_result.global_adapter for _ in clients],
        "FedRot-LoRA": [fedrot_result.global_adapter for _ in clients],
        "FedProx-LoRA": [fedprox_result.global_adapter for _ in clients],
        "Ditto-LoRA": ditto_result.personal_adapters,
        "FedGeo-Diag": fedgeo_diag_result.client_adapters,
        "FedGeo-Agg": fedgeo_agg_result.client_adapters,
        "FedProto-LoRA": fedproto_result.client_adapters,
        "FedPer-LoRA": fedper_result.client_adapters,
        "Clustered-LoRA": clustered_result.client_adapters,
        "FedAMP-LoRA": fedamp_result.client_adapters,
        "Subspace-Compatible": sca_result.client_adapters,
    }
    if scaffold_result is not None:
        method_adapters["SCAFFOLD-LoRA"] = [scaffold_result.global_adapter for _ in clients]
    if pfedme_result is not None:
        method_adapters["pFedMe-LoRA"] = pfedme_result.personal_adapters
    if bank_result is not None:
        method_adapters["FedAdapterManifold"] = bank_result.client_adapters
    if fedper_fam_adapters is not None:
        method_adapters["FedPer-FAM"] = fedper_fam_adapters
    if fedper_fam_selective_adapters is not None:
        method_adapters["FedPer-FAM-Selective"] = fedper_fam_selective_adapters
    if ditto_fam_adapters is not None:
        method_adapters["Ditto-FAM"] = ditto_fam_adapters
    if ditto_fam_selective_adapters is not None:
        method_adapters["Ditto-FAM-Selective"] = ditto_fam_selective_adapters
    if client_route_bank_result is not None:
        method_adapters["FedAdapterManifold-ClientRoute"] = client_route_bank_result.client_adapters
    if selective_adapters is not None:
        method_adapters["FedAdapterManifold-Selective"] = selective_adapters
    if strong_selective_adapters is not None:
        method_adapters["FedAdapterManifold-StrongSelective"] = strong_selective_adapters
    risk_rows = _risk_metric_rows(per_client_rows, method_adapters, local_adapters, geometry.graph)
    claim_rows = build_single_run_claim_report(metrics_rows, risk_rows, idea_support_rows, statistical_rows)

    write_csv(output_dir / "metrics.csv", metrics_rows)
    write_csv(output_dir / "idea_support.csv", idea_support_rows)
    write_csv(output_dir / "claim_report.csv", claim_rows)
    write_csv(output_dir / "statistical_support.csv", statistical_rows)
    write_csv(output_dir / "per_client_metrics.csv", per_client_rows)
    write_csv(output_dir / "negative_transfer.csv", negative_transfer_rows)
    write_csv(output_dir / "negative_transfer_summary.csv", negative_transfer_summary_rows)
    write_csv(output_dir / "risk_metrics.csv", risk_rows)
    write_csv(output_dir / "subspace_metrics.csv", subspace_rows)
    write_csv(output_dir / "distance_diagnostics.csv", diagnostic.distance_rows)
    write_csv(output_dir / "adapter_incompatibility_calibration.csv", diagnostic.calibration_rows)
    write_csv(output_dir / "adapter_conflict.csv", pair_rows)
    write_csv(output_dir / "local_lora_vs_fedavg_lora_drop.csv", drop_rows)
    write_csv(output_dir / "local_generalization_gap.csv", generalization_rows)
    write_csv(output_dir / "adapter_bank_weights.csv", bank_rows)
    write_csv(output_dir / "adapter_bank_sample_routing.csv", sample_bank_rows)
    write_csv(output_dir / "fedper_fam_hybrid_selection.csv", fedper_fam_rows)
    write_csv(output_dir / "ditto_fam_hybrid_selection.csv", ditto_fam_rows)
    write_csv(output_dir / "adapter_candidate_selection.csv", selective_rows)
    write_csv(output_dir / "candidate_selector_calibration.csv", calibration_rows)
    write_csv(output_dir / "adapter_bank_k_selection.csv", bank_selection_rows)
    write_csv(output_dir / "adapter_graph_mixing.csv", graph_mix_rows)
    write_csv(output_dir / "geometry_signal_roles.csv", _geometry_signal_role_rows(geometry))
    write_csv(output_dir / "local_training.csv", local_train_rows)
    write_csv(output_dir / "rank_allocation.csv", rank_rows)
    write_csv(output_dir / "local_lora_training_trace.csv", local_result.training_trace)
    write_csv(output_dir / "fedavg_lora_history.csv", fedavg_lora_result.round_history)
    write_csv(output_dir / "fedavg_lift_history.csv", fedavg_lift_result.round_history)
    write_csv(output_dir / "fedrot_lora_history.csv", fedrot_result.round_history)
    write_csv(output_dir / "fedprox_lora_history.csv", fedprox_result.round_history)
    if scaffold_result is not None:
        write_csv(output_dir / "scaffold_lora_history.csv", scaffold_result.round_history)
    write_csv(output_dir / "ditto_lora_history.csv", ditto_result.round_history)
    if pfedme_result is not None:
        write_csv(output_dir / "pfedme_lora_history.csv", pfedme_result.round_history)

    labels = [c.domain for c in clients]
    save_heatmap(d_sub, labels, figures_dir / "subspace_angle_heatmap.png", "Adapter subspace distance")
    save_scatter(
        np.asarray(failure_x),
        np.asarray(failure_y),
        figures_dir / "subspace_distance_vs_aggregation_failure.png",
        "Subspace distance vs pairwise aggregation failure",
        "d_sub(i,j)",
        "Local-LoRA accuracy drop after pair averaging",
        caption=f"Pearson r={diagnostic.pearson_r:.3f}",
    )
    save_scatter(
        np.asarray(diagnostic.incompatibility_failure_x),
        np.asarray(failure_y),
        figures_dir / "adapter_incompatibility_vs_aggregation_failure.png",
        "Dynamically calibrated adapter incompatibility vs aggregation failure",
        "d_adapter_incompatibility(i,j)",
        "Local-LoRA accuracy drop after pair averaging",
        caption=f"Pearson r={diagnostic.incompatibility_pearson_r:.3f}; threshold={args.diagnostic_threshold:.3f}",
    )
    save_scatter(
        np.asarray(diagnostic.incompatibility_failure_x),
        np.asarray(diagnostic.receiver_residual_failure_y),
        figures_dir / "adapter_incompatibility_vs_receiver_residual_failure.png",
        "Adapter incompatibility vs receiver-normalized aggregation failure",
        "d_adapter_incompatibility(i,j)",
        "Excess pair-averaging accuracy drop",
        caption=f"Pearson r={diagnostic.incompatibility_receiver_residual_pearson_r:.3f}",
    )
    save_scatter(
        np.asarray(update_failure_x),
        np.asarray(failure_y),
        figures_dir / "update_distance_vs_aggregation_failure.png",
        "Normalized update distance vs pairwise aggregation failure",
        "d_update(i,j)",
        "Local-LoRA accuracy drop after pair averaging",
        caption=f"Pearson r={diagnostic.update_pearson_r:.3f}",
    )
    save_scatter(
        np.asarray([float(row["d_geo"]) for row in pair_rows]),
        np.asarray(failure_y),
        figures_dir / "geometry_distance_vs_aggregation_failure.png",
        "Prototype/FedGeo distance vs pairwise aggregation failure",
        "d_geo(i,j)",
        "Local-LoRA accuracy drop after pair averaging",
        caption=f"Pearson r={diagnostic.geo_pearson_r:.3f}",
    )
    geo_x = []
    sub_y = []
    for i in range(len(clients)):
        for j in range(i + 1, len(clients)):
            geo_x.append(float(geometry.d_geo[i, j]))
            sub_y.append(float(d_sub[i, j]))
    save_scatter(
        np.asarray(geo_x),
        np.asarray(sub_y),
        figures_dir / "prototype_distance_vs_subspace_distance.png",
        "Prototype/FedGeo distance vs adapter subspace distance",
        "d_geo(i,j)",
        "d_sub(i,j)",
        caption=f"Geometry provider: {geometry.provider}",
    )
    if bank_result is not None:
        save_routing_heatmap(bank_result.bank.routing_weights, labels, figures_dir / "adapter_bank_routing.png")
    else:
        save_routing_heatmap(np.zeros((len(clients), 1)), labels, figures_dir / "adapter_bank_routing.png")

    _write_report(
        output_dir,
        args,
        diagnostic_r,
        diagnostic.pearson_r,
        diagnostic.update_pearson_r,
        diagnostic.geo_pearson_r,
        diagnostic.label_pearson_r,
        diagnostic.combined_pearson_r,
        diagnostic.distance_rows,
        diagnostic_passed,
        geometry.provider,
        bank_result is not None,
        class_names,
    )
    return 0 if diagnostic_passed or args.continue_on_failed_diagnostic else 2


def _load_clients(args):
    if args.dataset in {"synthetic", "pacs-debug", "cifar10-debug"}:
        num_classes = 10 if args.dataset == "cifar10-debug" else args.num_classes
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=args.num_clients,
            num_classes=num_classes,
            feature_dim=args.feature_dim,
            train_per_client=args.train_per_client,
            test_per_client=args.test_per_client,
            rank=args.rank,
            seed=args.seed,
        )
        class_names = [f"class_{i}" for i in range(num_classes)]
        return clients, base_weight, class_names
    if args.dataset == "cifar10":
        return load_cifar10_clients(
            args.data_root,
            num_clients=args.num_clients,
            dirichlet_alpha=args.dirichlet_alpha,
            min_train_size=args.min_train_size,
            train_per_client=args.train_per_client,
            test_per_client=args.test_per_client,
            align_test_with_train=args.align_test_with_train,
            seed=args.seed,
        )
    if args.dataset == "medmnist-npz":
        return load_medmnist_npz_clients(
            args.data_root,
            num_clients=args.num_clients,
            dirichlet_alpha=args.dirichlet_alpha,
            min_train_size=args.min_train_size,
            train_per_client=args.train_per_client,
            test_per_client=args.test_per_client,
            align_test_with_train=args.align_test_with_train,
            seed=args.seed,
            feature_cache_dir=args.feature_cache_dir,
            feature_backbone=args.feature_backbone,
        )
    clients, base_weight, class_names = load_image_folder_clients(
        args.data_root,
        domains=_parse_domains(args.domains),
        feature_backbone=args.feature_backbone,
        feature_cache_dir=args.feature_cache_dir,
        base_head_init=args.base_head_init,
        base_head_scale=args.base_head_scale,
        class_prompt_template=args.class_prompt_template,
        device="cpu" if args.cpu_debug else args.device,
        test_fraction=args.test_fraction,
        seed=args.seed,
        train_per_client=args.train_per_client,
        test_per_client=args.test_per_client,
    )
    return clients, base_weight, class_names


def _split_clients_for_candidate_selection(clients, fraction: float, seed: int):
    """Reserve a local calibration subset for candidate selection.

    Training and diagnostics use the returned training clients.  The final
    selector uses the calibration clients through the same x_train/y_train
    fields, so downstream selector code stays protocol-compatible while avoiding
    test-set model selection.
    """

    fraction = float(np.clip(fraction, 0.0, 0.95))
    rows = []
    if fraction <= 0.0:
        for client in clients:
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "candidate_selector_calibration_fraction": 0.0,
                    "train_samples_for_adapter_training": int(client.y_train.shape[0]),
                    "calibration_samples_for_selector": int(client.y_train.shape[0]),
                    "selector_split": "train",
                }
            )
        return clients, clients, rows
    rng = np.random.default_rng(int(seed) + 4242)
    train_clients = []
    selector_clients = []
    for client_idx, client in enumerate(clients):
        n = int(client.y_train.shape[0])
        if n < 2:
            train_clients.append(client)
            selector_clients.append(client)
            cal_size = n
            train_size = n
        else:
            order = rng.permutation(n)
            cal_size = int(round(n * fraction))
            cal_size = int(min(n - 1, max(1, cal_size)))
            cal_idx = np.sort(order[:cal_size])
            train_idx = np.sort(order[cal_size:])
            train_size = int(train_idx.size)
            train_clients.append(
                client.__class__(
                    client_id=client.client_id,
                    domain=client.domain,
                    x_train=client.x_train[train_idx],
                    y_train=client.y_train[train_idx],
                    x_test=client.x_test,
                    y_test=client.y_test,
                )
            )
            selector_clients.append(
                client.__class__(
                    client_id=client.client_id,
                    domain=client.domain,
                    x_train=client.x_train[cal_idx],
                    y_train=client.y_train[cal_idx],
                    x_test=client.x_test,
                    y_test=client.y_test,
                )
            )
        rows.append(
            {
                "client_id": client.client_id,
                "domain": client.domain,
                "candidate_selector_calibration_fraction": fraction,
                "train_samples_for_adapter_training": train_size,
                "calibration_samples_for_selector": cal_size,
                "selector_split": "heldout_calibration",
                "calibration_seed": int(seed) + 4242 + client_idx,
            }
        )
    return train_clients, selector_clients, rows


def _manifold_distance_matrix(
    components: str,
    d_sub,
    d_geo,
    d_label,
    lambda_geo: float,
    lambda_label: float,
):
    d_sub = np.asarray(d_sub, dtype=np.float64)
    d_geo = np.asarray(d_geo, dtype=np.float64)
    d_label = np.asarray(d_label, dtype=np.float64)
    if d_sub.shape != d_geo.shape or d_sub.shape != d_label.shape:
        raise ValueError(f"Distance shapes must match: d_sub={d_sub.shape}, d_geo={d_geo.shape}, d_label={d_label.shape}")
    zeros = np.zeros_like(d_sub, dtype=np.float64)
    geo = float(lambda_geo) * d_geo
    label = float(lambda_label) * d_label
    mapping = {
        "all": d_sub + geo + label,
        "d_sub": d_sub,
        "d_geo": geo,
        "d_label": label,
        "d_sub_d_geo": d_sub + geo,
        "d_sub_d_label": d_sub + label,
        "d_geo_d_label": geo + label,
    }
    if components not in mapping:
        raise ValueError(f"Unknown manifold_distance_components: {components}")
    out = np.asarray(mapping.get(components, zeros), dtype=np.float64).copy()
    np.fill_diagonal(out, 0.0)
    return out


def _compatibility_from_distance(distance, tau: float):
    distance = np.asarray(distance, dtype=np.float64)
    tau = max(float(tau), 1e-8)
    compat = np.exp(-distance / tau)
    np.fill_diagonal(compat, 1.0)
    return compat


def _effective_data_config(clients, base_weight, class_names):
    domains = [str(client.domain) for client in clients]
    train_sizes = [int(client.x_train.shape[0]) for client in clients]
    test_sizes = [int(client.x_test.shape[0]) for client in clients]
    return {
        "effective_num_clients": len(clients),
        "effective_num_classes": int(base_weight.shape[0]),
        "effective_feature_dim": int(base_weight.shape[1]),
        "effective_base_head_norm": float(np.linalg.norm(base_weight)),
        "effective_client_domains": ",".join(domains),
        "effective_class_names": ",".join(str(name) for name in class_names),
        "effective_train_samples_per_client": ",".join(str(size) for size in train_sizes),
        "effective_test_samples_per_client": ",".join(str(size) for size in test_sizes),
    }


def _parse_domains(value):
    if value in {"", None}:
        return None
    if isinstance(value, (list, tuple)):
        return [str(part).strip() for part in value if str(part).strip()]
    return [part.strip() for part in str(value).split(",") if part.strip()]


def _drop_rows(clients, base_weight, local_adapters, fedavg_adapter):
    rows = []
    for idx, client in enumerate(clients):
        local = evaluate_adapter(client.x_test, client.y_test, base_weight, local_adapters[idx])
        fedavg = evaluate_adapter(client.x_test, client.y_test, base_weight, fedavg_adapter)
        rows.append(
            {
                "client_id": client.client_id,
                "domain": client.domain,
                "local_lora_accuracy": local["accuracy"],
                "fedavg_lora_accuracy": fedavg["accuracy"],
                "drop": local["accuracy"] - fedavg["accuracy"],
            }
        )
    return rows


def _add_heterogeneity_alias(rows):
    for row in rows:
        if "heterogeneity" not in row and "heterogeneity_setting" in row:
            row["heterogeneity"] = row["heterogeneity_setting"]


def _bank_assignments(combined_distance, k):
    from .aggregation import k_medoids

    return k_medoids(combined_distance, k)


def _fixed_bank_selection_rows(combined_distance, selected_k):
    _, rows = select_adapter_bank_k(
        combined_distance,
        max_k=min(4, np.asarray(combined_distance).shape[0]),
    )
    for row in rows:
        row["selected"] = int(row["candidate_k"]) == int(selected_k)
        row["selection_mode"] = "fixed"
    return rows


def _select_adapter_graph(graph, mode: str, seed: int = 0):
    graph = np.asarray(graph, dtype=np.float64)
    if mode == "fedgeo":
        return graph
    if mode == "complete":
        return np.ones_like(graph, dtype=np.float64) - np.eye(graph.shape[0], dtype=np.float64)
    if mode == "self":
        return np.zeros_like(graph, dtype=np.float64)
    if mode == "random":
        return _random_graph_control(graph, seed=seed)
    raise ValueError(f"Unknown adapter_graph_mode: {mode}")


def _random_graph_control(graph: np.ndarray, seed: int = 0) -> np.ndarray:
    """Build a deterministic random graph preserving edge count and weights."""

    graph = np.asarray(graph, dtype=np.float64)
    n = int(graph.shape[0])
    if n <= 1:
        return np.zeros_like(graph, dtype=np.float64)
    upper = np.triu_indices(n, k=1)
    upper_weights = np.maximum(graph[upper], graph.T[upper])
    positive_weights = upper_weights[upper_weights > 0.0]
    if positive_weights.size == 0:
        return np.zeros_like(graph, dtype=np.float64)
    rng = np.random.default_rng(int(seed) + 7919)
    edge_count = int(min(positive_weights.size, len(upper[0])))
    chosen = rng.choice(len(upper[0]), size=edge_count, replace=False)
    shuffled_weights = np.asarray(positive_weights, dtype=np.float64).copy()
    rng.shuffle(shuffled_weights)
    out = np.zeros_like(graph, dtype=np.float64)
    for idx, weight in zip(chosen, shuffled_weights[:edge_count]):
        i = int(upper[0][idx])
        j = int(upper[1][idx])
        out[i, j] = float(weight)
        out[j, i] = float(weight)
    return out


def _blend_fixed_graph_mix(local_adapters, graph_adapters, weight: float, ranks) -> list[LoRAAdapter]:
    rank_list = [int(rank) for rank in ranks]
    weight = float(np.clip(weight, 0.0, 1.0))
    adapters = []
    for idx, (local_adapter, graph_adapter) in enumerate(zip(local_adapters, graph_adapters)):
        delta = (1.0 - weight) * local_adapter.delta() + weight * graph_adapter.delta()
        adapters.append(
            LoRAAdapter.from_delta(
                delta,
                rank=rank_list[idx],
                alpha=float(rank_list[idx]),
                name=f"fixed_graphmix_client_{idx}",
            )
        )
    return adapters


def _select_fedper_fam_hybrid(
    *,
    selector_clients,
    eval_clients,
    base_weight,
    personal_adapters,
    fam_adapters,
    ranks,
    candidates: str,
    tolerance: float,
    policy: str,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    method: str,
    personal_source_method: str = "FedPer-LoRA",
):
    """Blend a personalized adapter branch with the learned adapter manifold.

    A personal weight of 1.0 recovers the named personalized baseline and
    0.0 recovers Base FAM.
    Selection uses only the local train/calibration split carried by
    ``selector_clients``; final metrics are then evaluated on ``eval_clients``.
    """

    if isinstance(ranks, int):
        rank_list = [int(ranks) for _ in eval_clients]
    else:
        rank_list = [int(rank) for rank in ranks]
    candidate_values = _parse_unit_interval_candidates(candidates, default=[0.0, 0.25, 0.50, 0.75, 1.0])
    selected_adapters = []
    rows = []
    for idx, (selector_client, personal_adapter, fam_adapter) in enumerate(
        zip(selector_clients, personal_adapters, fam_adapters)
    ):
        losses = []
        adapters = []
        for candidate in candidate_values:
            personal_weight = float(candidate)
            delta = personal_weight * personal_adapter.delta() + (1.0 - personal_weight) * fam_adapter.delta()
            adapter = LoRAAdapter.from_delta(
                delta,
                rank=rank_list[idx],
                alpha=float(rank_list[idx]),
                name=f"fedper_fam_client_{idx}_p_{personal_weight:.2f}",
            )
            metrics = evaluate_adapter(selector_client.x_train, selector_client.y_train, base_weight, adapter)
            losses.append(float(metrics["loss"]))
            adapters.append(adapter)
        loss_array = np.asarray(losses, dtype=np.float64)
        best_idx = int(np.argmin(loss_array))
        if policy == "loss-constrained":
            allowed = float(loss_array[best_idx]) + max(0.0, float(tolerance))
            selected_idx = 0
            for candidate_idx, loss in enumerate(loss_array):
                if float(loss) <= allowed + 1e-12:
                    selected_idx = candidate_idx
        elif policy == "loss-min":
            selected_idx = best_idx
        elif policy == "personal-fallback":
            personal_idx = int(np.argmax(candidate_values))
            personal_loss = float(loss_array[personal_idx])
            if float(loss_array[best_idx]) <= personal_loss - max(0.0, float(tolerance)):
                selected_idx = best_idx
            else:
                selected_idx = personal_idx
        else:
            raise ValueError(f"Unknown FedPer-FAM policy: {policy}")
        selected_weight = float(candidate_values[selected_idx])
        selected_adapters.append(adapters[selected_idx])
        for candidate_idx, candidate in enumerate(candidate_values):
            rows.append(
                {
                    "client_id": selector_client.client_id,
                    "domain": selector_client.domain,
                    "method": method,
                    "selection_policy": policy,
                    "candidate_personal_weight": float(candidate),
                    "selected_personal_weight": selected_weight,
                    "candidate_selector_loss": float(loss_array[candidate_idx]),
                    "best_selector_loss": float(loss_array[best_idx]),
                    "fedper_fam_loss_tolerance": float(tolerance),
                    "selected": candidate_idx == selected_idx,
                    "interpretation": f"0=BaseFAM,1={personal_source_method}",
                }
            )
    per_client_metrics = evaluate_client_adapters(
        method,
        eval_clients,
        base_weight,
        selected_adapters,
        ranks=rank_list,
        seed=seed,
        dataset=dataset,
        heterogeneity_setting=heterogeneity_setting,
        round_id=round_id,
    )
    selected_by_client = {
        (row["client_id"], row["domain"]): row["selected_personal_weight"] for row in rows if row["selected"]
    }
    for row in per_client_metrics:
        row["source_method"] = f"{personal_source_method}+FedAdapterManifold"
        row["selected_personal_weight"] = selected_by_client.get((row["client_id"], row["domain"]), "")
        row["personalization_policy"] = policy
    return selected_adapters, per_client_metrics, rows


def _parse_unit_interval_candidates(value: str | None, default: list[float]) -> list[float]:
    if value is None or value == "":
        values = list(default)
    else:
        values = [float(part.strip()) for part in str(value).split(",") if part.strip()]
    values = sorted({float(np.clip(candidate, 0.0, 1.0)) for candidate in values})
    if not values or values[0] != 0.0:
        values.insert(0, 0.0)
    if values[-1] != 1.0:
        values.append(1.0)
    return values


def _selector_candidate_pool(
    *,
    scope: str,
    local_adapters,
    fedgeo_agg_adapters,
    subspace_adapters,
    bank_adapters,
):
    if scope == "adapter-only":
        return {"FedAdapterManifold": bank_adapters}
    return {
        "Local-LoRA": local_adapters,
        "FedGeo-Agg": fedgeo_agg_adapters,
        "Subspace-Compatible": subspace_adapters,
        "FedAdapterManifold": bank_adapters,
    }


def _selector_metric_pool(
    *,
    scope: str,
    local_metrics,
    fedgeo_agg_metrics,
    subspace_metrics,
    bank_metrics,
):
    if scope == "adapter-only":
        return {"FedAdapterManifold": bank_metrics}
    return {
        "Local-LoRA": local_metrics,
        "FedGeo-Agg": fedgeo_agg_metrics,
        "Subspace-Compatible": subspace_metrics,
        "FedAdapterManifold": bank_metrics,
    }


def _fixed_graph_mix_rows(clients, weight: float, policy: str) -> list[dict]:
    weight = float(np.clip(weight, 0.0, 1.0))
    return [
        {
            "client_id": client.client_id,
            "domain": client.domain,
            "adapter_graph_mix_policy": policy,
            "candidate_graph_mix_weight": weight,
            "selected_graph_mix_weight": weight,
            "candidate_graph_mix_loss": "",
            "best_graph_mix_loss": "",
            "adapter_graph_mix_tolerance": "",
            "selected": True,
        }
        for client in clients
    ]


def _select_client_candidate_adapters(
    clients,
    base_weight,
    candidates: dict[str, list],
    candidate_metrics: dict[str, list[dict]],
    ranks,
    graph,
    policy: str,
    manifold_prior: bool,
    loss_tolerance: float,
    loss_tolerance_ratio: float,
    neighbor_weight: float,
    softmax_tau: float,
    lcb_delta: float,
    seed: int,
    dataset: str,
    heterogeneity_setting: str,
    round_id: int,
    method: str,
):
    """Select a safe positive-transfer adapter candidate without test leakage.

    When the adapter-conflict diagnostic is active, a small local-loss advantage
    should not automatically collapse the method back to Local-LoRA.  The
    diagnostic-gated policy therefore prefers the manifold adapter among
    candidates whose train/neighbor score is close to the best candidate.  In
    benign settings it falls back to loss-min selection, which can still accept
    positive-transfer candidates such as Subspace-Compatible.
    """

    if not candidates:
        return None, [], []
    if isinstance(ranks, int):
        rank_list = [int(ranks) for _ in clients]
    else:
        rank_list = [int(rank) for rank in ranks]
    selected_adapters = []
    selected_metrics = []
    rows = []
    ordered_candidates = list(candidates.items())
    metric_lookup = _candidate_metric_lookup(candidate_metrics)
    priority = [
        "Ditto-FAM-Selective",
        "Ditto-FAM",
        "FedPer-FAM-Selective",
        "FedPer-FAM",
        "FedAdapterManifold",
        "FedAdapterManifold-ClientRoute",
        "Subspace-Compatible",
        "FedPer-LoRA",
        "FedGeo-Agg",
        "Local-LoRA",
    ]
    priority_index = {name: idx for idx, name in enumerate(priority)}
    graph = np.asarray(graph, dtype=np.float64)
    neighbor_weight = float(np.clip(neighbor_weight, 0.0, 1.0))
    for idx, client in enumerate(clients):
        local_losses = []
        neighbor_losses = []
        scores = []
        neighbor_weights = _selector_neighbor_weights(graph, idx)
        for candidate_name, adapters in ordered_candidates:
            local_metrics = evaluate_adapter(client.x_train, client.y_train, base_weight, adapters[idx])
            local_loss = float(local_metrics["loss"])
            neighbor_loss = _selector_neighbor_loss(
                clients,
                base_weight,
                adapters[idx],
                neighbor_weights,
                fallback_loss=local_loss,
            )
            score = (1.0 - neighbor_weight) * local_loss + neighbor_weight * neighbor_loss
            local_losses.append(local_loss)
            neighbor_losses.append(neighbor_loss)
            scores.append(score)
        local_loss_array = np.asarray(local_losses, dtype=np.float64)
        neighbor_loss_array = np.asarray(neighbor_losses, dtype=np.float64)
        score_array = np.asarray(scores, dtype=np.float64)
        best_score = float(score_array.min())
        allowed_score = best_score + max(0.0, float(loss_tolerance)) + max(0.0, float(loss_tolerance_ratio)) * max(
            abs(best_score),
            1e-12,
        )
        if policy == "anchored-no-regret":
            anchor_indices = [
                candidate_idx
                for candidate_idx, (candidate_name, _) in enumerate(ordered_candidates)
                if _selector_anchor_candidate(candidate_name)
            ]
            if not anchor_indices:
                anchor_indices = list(range(len(ordered_candidates)))
            manifold_indices = [
                candidate_idx
                for candidate_idx, (candidate_name, _) in enumerate(ordered_candidates)
                if not _selector_anchor_candidate(candidate_name)
            ]
            anchor_idx = min(anchor_indices, key=lambda candidate_idx: float(score_array[candidate_idx]))
            anchor_score = float(score_array[anchor_idx])
            penalty = _selector_lcb_penalty(len(client.y_train), len(ordered_candidates), lcb_delta)
            statistical_margin = penalty * max(abs(anchor_score), 1e-12)
            accept_margin = (
                max(0.0, float(loss_tolerance))
                + max(0.0, float(loss_tolerance_ratio)) * max(abs(anchor_score), 1e-12)
                + statistical_margin
            )
            if manifold_indices:
                best_manifold_idx = min(manifold_indices, key=lambda candidate_idx: float(score_array[candidate_idx]))
                best_manifold_score = float(score_array[best_manifold_idx])
                selected_idx = (
                    best_manifold_idx
                    if best_manifold_score <= anchor_score - accept_margin + 1e-12
                    else anchor_idx
                )
            else:
                best_manifold_idx = anchor_idx
                best_manifold_score = anchor_score
                selected_idx = anchor_idx
            selected_name, selected_source = ordered_candidates[selected_idx]
            selected_adapters.append(
                selected_source[idx].copy(name=f"{method.lower()}_{idx}_{selected_name.lower().replace('-', '_')}")
            )
            selected_metric = dict(metric_lookup.get((selected_name, str(client.client_id)), {}))
            if selected_metric:
                selected_metric["source_method"] = selected_name
                selected_metric["method"] = method
            else:
                metrics = evaluate_adapter(client.x_test, client.y_test, base_weight, selected_adapters[-1])
                selected_metric = {
                    "method": method,
                    "seed": seed,
                    "dataset": dataset,
                    "heterogeneity_setting": heterogeneity_setting,
                    "round": round_id,
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "accuracy": metrics["accuracy"],
                    "loss": metrics["loss"],
                    "rank": rank_list[idx],
                    "source_method": selected_name,
                }
            selected_metrics.append(selected_metric)
            for candidate_idx, (candidate_name, _) in enumerate(ordered_candidates):
                rows.append(
                    {
                        "client_id": client.client_id,
                        "domain": client.domain,
                        "method": method,
                        "selector_policy": policy,
                        "manifold_prior_active": bool(manifold_prior),
                        "candidate_method": candidate_name,
                        "candidate_train_loss": float(local_loss_array[candidate_idx]),
                        "candidate_neighbor_loss": float(neighbor_loss_array[candidate_idx]),
                        "candidate_selector_score": float(score_array[candidate_idx]),
                        "best_selector_score": best_score,
                        "allowed_selector_score": float(anchor_score - accept_margin),
                        "anchor_method": ordered_candidates[anchor_idx][0],
                        "anchor_selector_score": anchor_score,
                        "best_manifold_method": ordered_candidates[best_manifold_idx][0],
                        "best_manifold_selector_score": best_manifold_score,
                        "selector_statistical_margin": float(statistical_margin),
                        "selector_accept_margin": float(accept_margin),
                        "best_train_loss": float(local_loss_array[selected_idx]),
                        "selector_loss_tolerance": float(loss_tolerance),
                        "selector_loss_tolerance_ratio": float(loss_tolerance_ratio),
                        "selector_neighbor_weight": float(neighbor_weight),
                        "selector_lcb_delta": float(lcb_delta),
                        "selector_lcb_penalty": float(penalty),
                        "selected_method": selected_name,
                        "selected": candidate_idx == selected_idx,
                    }
                )
            continue
        if policy in {"loss-softmax", "gibbs", "gibbs-lcb", "safe-gibbs", "safe-gibbs-lcb"}:
            penalty = _selector_lcb_penalty(len(client.y_train), len(ordered_candidates), lcb_delta)
            use_lcb = policy in {"gibbs-lcb", "safe-gibbs-lcb"}
            lcb_scores = score_array + (penalty if use_lcb else 0.0)
            if policy in {"safe-gibbs", "safe-gibbs-lcb"}:
                allowed_mask = score_array <= allowed_score + 1e-12
                if not bool(np.any(allowed_mask)):
                    allowed_mask[int(np.argmin(score_array))] = True
                masked_scores = np.where(allowed_mask, lcb_scores, np.inf)
                weights = _softmax_weights(-masked_scores, temperature=max(float(softmax_tau), 1e-12))
            else:
                allowed_mask = np.ones_like(score_array, dtype=bool)
                weights = _softmax_weights(-lcb_scores, temperature=max(float(softmax_tau), 1e-12))
            delta = np.zeros_like(ordered_candidates[0][1][idx].delta(), dtype=np.float64)
            for candidate_weight, (_, source) in zip(weights, ordered_candidates):
                delta += float(candidate_weight) * source[idx].delta()
            selected_adapter = LoRAAdapter.from_delta(
                delta,
                rank=rank_list[idx],
                alpha=float(rank_list[idx]),
                name=f"{method.lower()}_{idx}_gibbs_selector",
            )
            selected_idx = int(np.argmax(weights))
            selected_name = "GibbsMixture"
            selected_adapters.append(selected_adapter)
            metrics = evaluate_adapter(client.x_test, client.y_test, base_weight, selected_adapter)
            selected_metric = {
                "method": method,
                "seed": seed,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": round_id,
                "client_id": client.client_id,
                "domain": client.domain,
                "accuracy": metrics["accuracy"],
                "loss": metrics["loss"],
                "rank": rank_list[idx],
                "source_method": selected_name,
                "selector_softmax_tau": float(softmax_tau),
                "selector_lcb_penalty": float(penalty),
            }
            selected_metrics.append(selected_metric)
            for candidate_idx, (candidate_name, _) in enumerate(ordered_candidates):
                rows.append(
                    {
                        "client_id": client.client_id,
                        "domain": client.domain,
                        "method": method,
                        "selector_policy": policy,
                        "manifold_prior_active": bool(manifold_prior),
                        "candidate_method": candidate_name,
                        "candidate_train_loss": float(local_loss_array[candidate_idx]),
                        "candidate_neighbor_loss": float(neighbor_loss_array[candidate_idx]),
                        "candidate_selector_score": float(score_array[candidate_idx]),
                        "candidate_gibbs_weight": float(weights[candidate_idx]),
                        "candidate_in_safe_set": bool(allowed_mask[candidate_idx]),
                        "best_selector_score": best_score,
                        "allowed_selector_score": allowed_score,
                        "best_train_loss": float(local_loss_array[selected_idx]),
                        "selector_loss_tolerance": float(loss_tolerance),
                        "selector_loss_tolerance_ratio": float(loss_tolerance_ratio),
                        "selector_neighbor_weight": float(neighbor_weight),
                        "selector_softmax_tau": float(softmax_tau),
                        "selector_lcb_delta": float(lcb_delta),
                        "selector_lcb_penalty": float(penalty),
                        "selected_method": selected_name,
                        "selected": candidate_idx == selected_idx,
                    }
                )
            continue
        if policy == "diagnostic-gated" and manifold_prior:
            allowed = [
                candidate_idx
                for candidate_idx, score in enumerate(score_array)
                if float(score) <= allowed_score + 1e-12
            ]
            selected_idx = min(
                allowed,
                key=lambda candidate_idx: priority_index.get(ordered_candidates[candidate_idx][0], len(priority)),
            )
        elif policy == "loss-min":
            selected_idx = int(np.argmin(score_array))
        else:
            selected_idx = int(np.argmin(score_array))
        selected_name, selected_source = ordered_candidates[selected_idx]
        selected_adapters.append(
            selected_source[idx].copy(name=f"{method.lower()}_{idx}_{selected_name.lower().replace('-', '_')}")
        )
        selected_metric = dict(metric_lookup.get((selected_name, str(client.client_id)), {}))
        if selected_metric:
            selected_metric["source_method"] = selected_name
            selected_metric["method"] = method
        else:
            metrics = evaluate_adapter(client.x_test, client.y_test, base_weight, selected_adapters[-1])
            selected_metric = {
                "method": method,
                "seed": seed,
                "dataset": dataset,
                "heterogeneity_setting": heterogeneity_setting,
                "round": round_id,
                "client_id": client.client_id,
                "domain": client.domain,
                "accuracy": metrics["accuracy"],
                "loss": metrics["loss"],
                "rank": rank_list[idx],
                "source_method": selected_name,
            }
        selected_metrics.append(selected_metric)
        for candidate_idx, (candidate_name, _) in enumerate(ordered_candidates):
            rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "method": method,
                    "selector_policy": policy,
                    "manifold_prior_active": bool(manifold_prior),
                    "candidate_method": candidate_name,
                    "candidate_train_loss": float(local_loss_array[candidate_idx]),
                    "candidate_neighbor_loss": float(neighbor_loss_array[candidate_idx]),
                    "candidate_selector_score": float(score_array[candidate_idx]),
                    "best_selector_score": best_score,
                    "allowed_selector_score": allowed_score,
                    "best_train_loss": float(local_loss_array[selected_idx]),
                    "selector_loss_tolerance": float(loss_tolerance),
                    "selector_loss_tolerance_ratio": float(loss_tolerance_ratio),
                    "selector_neighbor_weight": float(neighbor_weight),
                    "selected_method": selected_name,
                    "selected": candidate_idx == selected_idx,
                }
            )
    return selected_adapters, selected_metrics, rows


def _selector_lcb_penalty(num_samples: int, num_candidates: int, delta: float) -> float:
    num_samples = max(int(num_samples), 1)
    num_candidates = max(int(num_candidates), 1)
    delta = float(np.clip(delta, 1e-12, 1.0))
    return float(np.sqrt(np.log(2.0 * num_candidates / delta) / (2.0 * num_samples)))


def _selector_anchor_candidate(candidate_name: str) -> bool:
    """Return whether a candidate is a conservative no-regret anchor.

    The anchor branch represents the strongest non-manifold option available
    before test evaluation.  A manifold candidate must beat this branch by a
    calibration margin before it is selected by the anchored no-regret policy.
    """

    name = str(candidate_name).lower()
    manifold_tokens = [
        "fedadaptermanifold",
        "fam",
        "subspace-compatible",
    ]
    return not any(token in name for token in manifold_tokens)


def _softmax_weights(values: np.ndarray, temperature: float) -> np.ndarray:
    temperature = max(float(temperature), 1e-12)
    scaled = np.asarray(values, dtype=np.float64) / temperature
    scaled = scaled - float(np.max(scaled))
    weights = np.exp(scaled)
    total = float(weights.sum())
    if not np.isfinite(total) or total <= 0.0:
        return np.full_like(weights, 1.0 / max(weights.size, 1), dtype=np.float64)
    return weights / total


def _candidate_metric_lookup(candidate_metrics: dict[str, list[dict]]) -> dict[tuple[str, str], dict]:
    lookup = {}
    for method, rows in candidate_metrics.items():
        for row in rows:
            lookup[(method, str(row.get("client_id")))] = row
    return lookup


def _high_conflict_prior(local_rows, fedavg_rows, adapter_r: float, threshold: float) -> bool:
    local_acc = _mean_accuracy_from_rows(local_rows)
    fedavg_acc = _mean_accuracy_from_rows(fedavg_rows)
    return bool(np.isfinite(adapter_r) and adapter_r >= float(threshold) and local_acc > fedavg_acc)


def _mean_accuracy_from_rows(rows) -> float:
    values = [float(row["accuracy"]) for row in rows if "accuracy" in row]
    if not values:
        return float("nan")
    return float(np.mean(np.asarray(values, dtype=np.float64)))


def _selector_neighbor_weights(graph, idx: int):
    graph = np.asarray(graph, dtype=np.float64)
    if graph.ndim != 2 or idx >= graph.shape[0]:
        return np.zeros(0, dtype=np.float64)
    weights = graph[idx].astype(np.float64).copy()
    if idx < weights.size:
        weights[idx] = 0.0
    weights = np.maximum(weights, 0.0)
    total = float(weights.sum())
    if total <= 1e-12:
        return np.zeros_like(weights)
    return weights / total


def _selector_neighbor_loss(clients, base_weight, adapter, neighbor_weights, fallback_loss: float) -> float:
    if neighbor_weights.size == 0 or float(np.sum(neighbor_weights)) <= 1e-12:
        return float(fallback_loss)
    losses = []
    weights = []
    for neighbor_idx, weight in enumerate(neighbor_weights):
        if float(weight) <= 0.0 or neighbor_idx >= len(clients):
            continue
        client = clients[neighbor_idx]
        metrics = evaluate_adapter(client.x_train, client.y_train, base_weight, adapter)
        losses.append(float(metrics["loss"]))
        weights.append(float(weight))
    if not losses:
        return float(fallback_loss)
    return float(np.average(np.asarray(losses, dtype=np.float64), weights=np.asarray(weights, dtype=np.float64)))


def _idea_support_rows(metrics_rows, diagnostic_threshold):
    by_method = {row["method"]: row for row in metrics_rows}
    local = by_method.get("Local-LoRA")
    fedavg = by_method.get("FedAvg-LoRA")
    subspace = by_method.get("Subspace-Compatible")
    fedgeo_agg = by_method.get("FedGeo-Agg")
    bank = by_method.get("FedAdapterManifold-Selective") or by_method.get("FedAdapterManifold")
    client_route = by_method.get("FedAdapterManifold-ClientRoute")
    if local is None or fedavg is None or subspace is None or bank is None:
        return []
    raw_adapter_r = float(
        fedavg.get(
            "raw_adapter_incompatibility_failure_pearson_r",
            fedavg.get("adapter_incompatibility_failure_pearson_r", float("nan")),
        )
    )
    controlled_adapter_r = float(
        fedavg.get(
            "receiver_residual_adapter_incompatibility_failure_pearson_r",
            raw_adapter_r,
        )
    )
    r_candidates = [
        ("raw_directional", raw_adapter_r),
        ("receiver_residual", controlled_adapter_r),
    ]
    finite_r_candidates = [(name, value) for name, value in r_candidates if np.isfinite(value)]
    if finite_r_candidates:
        primary_r_name, r_value = max(finite_r_candidates, key=lambda item: item[1])
    else:
        primary_r_name, r_value = "none", float("nan")
    raw_subspace_r = float(fedavg.get("raw_subspace_failure_pearson_r", fedavg.get("subspace_failure_pearson_r", float("nan"))))
    local_minus = float(local["mean_accuracy"]) - float(fedavg["mean_accuracy"])
    subspace_minus = float(subspace["mean_accuracy"]) - float(fedavg["mean_accuracy"])
    fedgeo_agg_minus = "" if fedgeo_agg is None else float(fedgeo_agg["mean_accuracy"]) - float(fedavg["mean_accuracy"])
    bank_minus = float(bank["mean_accuracy"]) - float(fedavg["mean_accuracy"])
    bank_minus_fedgeo_agg = "" if fedgeo_agg is None else float(bank["mean_accuracy"]) - float(fedgeo_agg["mean_accuracy"])
    client_route_minus = "" if client_route is None else float(client_route["mean_accuracy"]) - float(fedavg["mean_accuracy"])
    supports_vs_fedgeo_agg = (
        fedgeo_agg is not None
        and bank_minus_fedgeo_agg != ""
        and float(bank_minus_fedgeo_agg) > 0
    )
    fedgeo_gate = fedgeo_agg is None or bool(supports_vs_fedgeo_agg)
    supports = (
        np.isfinite(r_value)
        and r_value >= float(diagnostic_threshold)
        and local_minus > 0
        and bank_minus > 0
        and fedgeo_gate
    )
    return [
        {
            "supports_idea": bool(supports),
            "supports_vs_fedgeo_agg": bool(supports_vs_fedgeo_agg),
            "support_rule": "best_adapter_incompatibility_r>=threshold;local>fedavg;adapter_bank>fedavg;adapter_bank>fedgeo_agg_when_available",
            "subspace_compatible_is_gate": False,
            "primary_adapter_method": bank["method"],
            "primary_adapter_incompatibility_signal": primary_r_name,
            "adapter_incompatibility_failure_pearson_r": r_value,
            "raw_adapter_incompatibility_failure_pearson_r": raw_adapter_r,
            "receiver_residual_adapter_incompatibility_failure_pearson_r": controlled_adapter_r,
            "raw_subspace_failure_pearson_r": raw_subspace_r,
            "subspace_failure_pearson_r": r_value,
            "diagnostic_threshold": float(diagnostic_threshold),
            "local_minus_fedavg_lora": local_minus,
            "subspace_minus_fedavg_lora": subspace_minus,
            "fedgeo_agg_minus_fedavg_lora": fedgeo_agg_minus,
            "adapter_bank_minus_fedavg_lora": bank_minus,
            "adapter_bank_minus_fedgeo_agg": bank_minus_fedgeo_agg,
            "client_route_minus_fedavg_lora": client_route_minus,
        }
    ]


def _statistical_support_rows(per_client_rows, pair_rows, seed):
    rows = []
    rng = np.random.default_rng(int(seed) + 1701)
    pair_rows = _ensure_failure_control_fields(pair_rows)
    for distance_name in ["d_sub", "d_update", "d_adapter_incompatibility", "d_geo", "d_combined", "d_label"]:
        distance = np.asarray([float(row[distance_name]) for row in pair_rows], dtype=np.float64)
        for test_name, target_field in [
            ("distance_failure_correlation", "aggregation_failure"),
            ("distance_receiver_residual_failure_correlation", "receiver_residual_aggregation_failure"),
            ("distance_pair_mean_failure_correlation", "pair_mean_aggregation_failure"),
            ("distance_pair_max_failure_correlation", "pair_max_aggregation_failure"),
        ]:
            failure = np.asarray([float(row[target_field]) for row in pair_rows], dtype=np.float64)
            estimate = _pearson_no_import(distance, failure)
            low, high = _bootstrap_stat(distance, failure, _pearson_no_import, rng)
            p_value = _permutation_corr_pvalue(distance, failure, estimate, rng)
            rows.append(
                {
                    "test": test_name,
                    "measure": distance_name,
                    "comparison": f"{distance_name}_vs_{target_field}",
                    "estimate": estimate,
                    "ci_low": low,
                    "ci_high": high,
                    "p_value": p_value,
                    "supports": bool(np.isfinite(estimate) and estimate > 0 and np.isfinite(low) and low > 0),
                }
            )

    by_method_client = {}
    for row in per_client_rows:
        by_method_client[(row["method"], row["client_id"])] = float(row["accuracy"])
    clients = sorted({row["client_id"] for row in per_client_rows})
    for method in [
        "Local-LoRA",
        "FedGeo-Diag",
        "FedGeo-Agg",
        "Subspace-Compatible",
        "FedAdapterManifold",
        "FedAdapterManifold-ClientRoute",
        "FedAdapterManifold-Selective",
        "Ditto-FAM",
        "Ditto-FAM-Selective",
        "FedPer-FAM",
        "FedPer-FAM-Selective",
        "FedAdapterManifold-StrongSelective",
    ]:
        diffs = []
        for client_id in clients:
            key = (method, client_id)
            base = ("FedAvg-LoRA", client_id)
            if key in by_method_client and base in by_method_client:
                diffs.append(by_method_client[key] - by_method_client[base])
        if not diffs:
            continue
        diff_arr = np.asarray(diffs, dtype=np.float64)
        estimate = float(diff_arr.mean())
        low, high = _bootstrap_1d(diff_arr, rng)
        p_value = _sign_flip_pvalue(diff_arr)
        rows.append(
            {
                "test": "paired_accuracy_gain",
                "measure": "mean_accuracy_gain",
                "comparison": f"{method}_vs_FedAvg-LoRA",
                "estimate": estimate,
                "ci_low": low,
                "ci_high": high,
                "p_value": p_value,
                "supports": bool(estimate > 0 and low > 0),
            }
        )
    return rows


def _ensure_failure_control_fields(pair_rows):
    rows = [dict(row) for row in pair_rows]
    if not rows:
        return rows
    if all("receiver_residual_aggregation_failure" in row for row in rows):
        return rows
    by_receiver = {}
    by_pair = {}
    for row in rows:
        failure = float(row["aggregation_failure"])
        receiver_key = row["client_i"]
        pair_key = tuple(sorted((str(row["client_i"]), str(row["client_j"]))))
        by_receiver.setdefault(receiver_key, []).append(failure)
        by_pair.setdefault(pair_key, []).append(failure)
    receiver_mean = {key: float(np.mean(values)) for key, values in by_receiver.items()}
    pair_mean = {key: float(np.mean(values)) for key, values in by_pair.items()}
    pair_max = {key: float(np.max(values)) for key, values in by_pair.items()}
    for row in rows:
        failure = float(row["aggregation_failure"])
        receiver_key = row["client_i"]
        pair_key = tuple(sorted((str(row["client_i"]), str(row["client_j"]))))
        row["receiver_mean_aggregation_failure"] = receiver_mean.get(receiver_key, 0.0)
        row["receiver_residual_aggregation_failure"] = failure - receiver_mean.get(receiver_key, 0.0)
        row["pair_mean_aggregation_failure"] = pair_mean.get(pair_key, failure)
        row["pair_max_aggregation_failure"] = pair_max.get(pair_key, failure)
    return rows


def _pearson_no_import(x, y):
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    if x.size < 2:
        return float("nan")
    x = x - x.mean()
    y = y - y.mean()
    denom = np.sqrt(np.sum(x * x) * np.sum(y * y))
    if denom <= 1e-12:
        return float("nan")
    return float(np.sum(x * y) / denom)


def _bootstrap_stat(x, y, fn, rng, n_boot=1000):
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    if x.size < 2:
        return float("nan"), float("nan")
    values = []
    for _ in range(int(n_boot)):
        idx = rng.integers(0, x.size, size=x.size)
        value = fn(x[idx], y[idx])
        if np.isfinite(value):
            values.append(value)
    if not values:
        return float("nan"), float("nan")
    arr = np.asarray(values, dtype=np.float64)
    return float(np.quantile(arr, 0.025)), float(np.quantile(arr, 0.975))


def _bootstrap_1d(values, rng, n_boot=1000):
    values = np.asarray(values, dtype=np.float64)
    if values.size == 0:
        return float("nan"), float("nan")
    means = []
    for _ in range(int(n_boot)):
        idx = rng.integers(0, values.size, size=values.size)
        means.append(float(values[idx].mean()))
    arr = np.asarray(means, dtype=np.float64)
    return float(np.quantile(arr, 0.025)), float(np.quantile(arr, 0.975))


def _permutation_corr_pvalue(x, y, observed, rng, n_perm=2000):
    if not np.isfinite(observed):
        return float("nan")
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    count = 1
    total = 1
    for _ in range(int(n_perm)):
        value = _pearson_no_import(x, rng.permutation(y))
        if np.isfinite(value):
            total += 1
            if value >= observed:
                count += 1
    return float(count / total)


def _sign_flip_pvalue(diffs):
    diffs = np.asarray(diffs, dtype=np.float64)
    diffs = diffs[np.isfinite(diffs)]
    if diffs.size == 0:
        return float("nan")
    observed = float(diffs.mean())
    if diffs.size > 12:
        signs = np.random.default_rng(0).choice([-1.0, 1.0], size=(4096, diffs.size))
        means = signs @ diffs / diffs.size
        return float((np.sum(means >= observed) + 1) / (means.size + 1))
    count = 0
    total = 2 ** int(diffs.size)
    for mask in range(total):
        signs = np.array([1.0 if (mask >> i) & 1 else -1.0 for i in range(diffs.size)])
        if float((signs * diffs).mean()) >= observed:
            count += 1
    return float(count / total)


def _local_generalization_rows(per_client_metrics):
    rows = []
    for row in per_client_metrics:
        if row.get("method") != "Local-LoRA":
            continue
        train_acc = float(row["train_accuracy"])
        test_acc = float(row["test_accuracy"])
        train_loss = float(row["train_loss"])
        test_loss = float(row["test_loss"])
        rows.append(
            {
                "client_id": row["client_id"],
                "domain": row["domain"],
                "rank": row["rank"],
                "train_accuracy": train_acc,
                "test_accuracy": test_acc,
                "accuracy_gap": train_acc - test_acc,
                "train_loss": train_loss,
                "test_loss": test_loss,
                "loss_gap": test_loss - train_loss,
            }
        )
    return rows


def _negative_transfer_rows(per_client_rows):
    local_by_client = {
        row["client_id"]: float(row["accuracy"])
        for row in per_client_rows
        if row["method"] == "Local-LoRA"
    }
    fedavg_by_client = {
        row["client_id"]: float(row["accuracy"])
        for row in per_client_rows
        if row["method"] == "FedAvg-LoRA"
    }
    detail_rows = []
    by_method: dict[str, list[dict]] = {}
    for row in per_client_rows:
        client_id = row["client_id"]
        if client_id not in local_by_client:
            continue
        method = row["method"]
        accuracy = float(row["accuracy"])
        local_accuracy = local_by_client[client_id]
        fedavg_accuracy = fedavg_by_client.get(client_id, float("nan"))
        negative_transfer = max(0.0, local_accuracy - accuracy)
        fedavg_negative_transfer = max(0.0, local_accuracy - fedavg_accuracy) if np.isfinite(fedavg_accuracy) else float("nan")
        row_out = {
            "method": method,
            "seed": row["seed"],
            "dataset": row["dataset"],
            "heterogeneity_setting": row["heterogeneity_setting"],
            "heterogeneity": row.get("heterogeneity", row["heterogeneity_setting"]),
            "round": row["round"],
            "client_id": client_id,
            "domain": row["domain"],
            "rank": row.get("rank", ""),
            "local_lora_accuracy": local_accuracy,
            "method_accuracy": accuracy,
            "fedavg_lora_accuracy": fedavg_accuracy,
            "accuracy_gain_vs_fedavg": accuracy - fedavg_accuracy if np.isfinite(fedavg_accuracy) else "",
            "negative_transfer_vs_local": negative_transfer,
            "fedavg_negative_transfer_vs_local": fedavg_negative_transfer,
            "negative_transfer_reduction_vs_fedavg": fedavg_negative_transfer - negative_transfer
            if np.isfinite(fedavg_negative_transfer)
            else "",
            "is_harmed_vs_local": bool(negative_transfer > 1e-12),
            "is_helped_vs_fedavg": bool(np.isfinite(fedavg_accuracy) and accuracy > fedavg_accuracy),
        }
        detail_rows.append(row_out)
        by_method.setdefault(method, []).append(row_out)

    summary_rows = []
    for method, rows in by_method.items():
        nt = np.asarray([float(row["negative_transfer_vs_local"]) for row in rows], dtype=np.float64)
        gains = np.asarray(
            [
                float(row["negative_transfer_reduction_vs_fedavg"])
                for row in rows
                if row["negative_transfer_reduction_vs_fedavg"] != ""
            ],
            dtype=np.float64,
        )
        acc_gains = np.asarray(
            [
                float(row["accuracy_gain_vs_fedavg"])
                for row in rows
                if row["accuracy_gain_vs_fedavg"] != ""
            ],
            dtype=np.float64,
        )
        summary_rows.append(
            {
                "method": method,
                "seed": rows[0]["seed"],
                "dataset": rows[0]["dataset"],
                "heterogeneity_setting": rows[0]["heterogeneity_setting"],
                "heterogeneity": rows[0].get("heterogeneity", rows[0]["heterogeneity_setting"]),
                "round": rows[0]["round"],
                "mean_negative_transfer_vs_local": float(nt.mean()) if nt.size else float("nan"),
                "max_negative_transfer_vs_local": float(nt.max()) if nt.size else float("nan"),
                "harmed_client_count": int(np.sum(nt > 1e-12)),
                "num_clients": len(rows),
                "mean_negative_transfer_reduction_vs_fedavg": float(gains.mean()) if gains.size else "",
                "min_negative_transfer_reduction_vs_fedavg": float(gains.min()) if gains.size else "",
                "mean_accuracy_gain_vs_fedavg": float(acc_gains.mean()) if acc_gains.size else "",
                "helped_vs_fedavg_client_count": int(np.sum(acc_gains > 1e-12)) if acc_gains.size else "",
            }
        )
    return detail_rows, summary_rows


def _risk_metric_rows(per_client_rows, method_adapters, local_adapters, graph):
    rows = []
    local_accuracy = {
        row["client_id"]: float(row["accuracy"])
        for row in per_client_rows
        if row["method"] == "Local-LoRA"
    }
    by_method: dict[str, list[dict]] = {}
    for row in per_client_rows:
        by_method.setdefault(row["method"], []).append(row)

    for method, metrics in by_method.items():
        accuracy = np.asarray([float(row["accuracy"]) for row in metrics], dtype=np.float64)
        losses = []
        for row in metrics:
            baseline = local_accuracy.get(row["client_id"], float("nan"))
            if np.isfinite(baseline):
                losses.append(max(0.0, baseline - float(row["accuracy"])))
        drift = np.asarray(losses, dtype=np.float64)
        adapters = method_adapters.get(method)
        update_conflict = ""
        max_update_conflict = ""
        graph_conflict = ""
        if adapters is not None:
            distances = np.asarray(
                [
                    _adapter_update_distance(adapter, local_adapters[idx])
                    for idx, adapter in enumerate(adapters)
                ],
                dtype=np.float64,
            )
            update_conflict = float(distances.mean())
            max_update_conflict = float(distances.max())
            graph_conflict = _graph_update_conflict(adapters, graph)
        rows.append(
            {
                "method": method,
                "seed": metrics[0]["seed"],
                "dataset": metrics[0]["dataset"],
                "heterogeneity_setting": metrics[0]["heterogeneity_setting"],
                "heterogeneity": metrics[0].get("heterogeneity", metrics[0]["heterogeneity_setting"]),
                "round": metrics[0]["round"],
                "worst_client_accuracy": float(accuracy.min()) if accuracy.size else float("nan"),
                "worst_client_risk": float(1.0 - accuracy.min()) if accuracy.size else float("nan"),
                "mean_client_drift_vs_local": float(drift.mean()) if drift.size else float("nan"),
                "max_client_drift_vs_local": float(drift.max()) if drift.size else float("nan"),
                "mean_update_conflict_vs_local": update_conflict,
                "max_update_conflict_vs_local": max_update_conflict,
                "mean_graph_neighbor_update_conflict": graph_conflict,
                "num_clients": int(accuracy.size),
            }
        )
    return rows


def _add_geometry_auxiliary_scores(per_client_rows, clients, geometry) -> None:
    by_client = {client.client_id: idx for idx, client in enumerate(clients)}
    for row in per_client_rows:
        idx = by_client.get(row.get("client_id"))
        if idx is None:
            continue
        row["geometry_signal_for_manifold"] = "d_geo+geometry_graph"
        row["risk_signal_usage"] = "auxiliary_prior_only"
        row["risk_geo_score"] = _optional_float_at(geometry.risk_geo_scores, idx)
        row["feature_energy_deficit"] = _optional_float_at(geometry.feature_energy_deficit, idx)


def _optional_float_at(values, idx):
    if values is None:
        return ""
    arr = np.asarray(values, dtype=np.float64)
    if idx >= arr.size or not np.isfinite(arr[idx]):
        return ""
    return float(arr[idx])


def _geometry_signal_role_rows(geometry) -> list[dict]:
    return [
        {
            "signal": "d_geo",
            "source": "d_geo_round_t.npy",
            "role": "main_adapter_manifold_distance",
            "used_for": "compatibility, adapter graph distance, bank clustering, routing prior",
            "is_main_manifold": True,
        },
        {
            "signal": "geometry_graph",
            "source": "geometry_graph_round_t.npy",
            "role": "main_adapter_sharing_graph",
            "used_for": "client neighborhood, graph-compatible adapter sharing",
            "is_main_manifold": True,
        },
        {
            "signal": "prototypes",
            "source": "prototypes_round_t.pkl",
            "role": "class_conditional_routing_anchor",
            "used_for": "adapter-bank feature/prototype routing",
            "is_main_manifold": True,
        },
        {
            "signal": "risk_geo_score",
            "source": "risk_geo_scores_round_t.csv",
            "role": "auxiliary_rare_mode_fairness_prior",
            "used_for": "optional risk-aware rank capacity ablation only",
            "is_main_manifold": False,
            "available": geometry.risk_geo_scores is not None,
        },
        {
            "signal": "feature_energy_deficit",
            "source": "feature_energy_deficit_round_t.csv",
            "role": "auxiliary_reliability_energy_prior",
            "used_for": "optional risk-aware rank capacity ablation only",
            "is_main_manifold": False,
            "available": geometry.feature_energy_deficit is not None,
        },
    ]


def _adapter_update_distance(adapter_a, adapter_b):
    delta_a = adapter_a.delta()
    delta_b = adapter_b.delta()
    denom = np.linalg.norm(delta_a) + np.linalg.norm(delta_b)
    if denom <= 1e-12:
        return 0.0
    return float(2.0 * np.linalg.norm(delta_a - delta_b) / denom)


def _graph_update_conflict(adapters, graph):
    graph = np.asarray(graph, dtype=np.float64)
    values = []
    weights = []
    for i in range(len(adapters)):
        for j in range(i + 1, len(adapters)):
            weight = float(max(graph[i, j], graph[j, i]))
            if weight > 1e-12:
                values.append(_adapter_update_distance(adapters[i], adapters[j]))
                weights.append(weight)
    if not values:
        return ""
    return float(np.average(np.asarray(values, dtype=np.float64), weights=np.asarray(weights, dtype=np.float64)))


def _rank_rows(
    clients,
    ranks,
    requested_policy,
    effective_policy,
    geometry,
    conflict_probe,
    conflict_probe_r,
    conflict_probe_passed,
    fallback_reason,
):
    return [
        {
            "client_id": client.client_id,
            "domain": client.domain,
            "rank_policy": requested_policy,
            "effective_rank_policy": effective_policy,
            "rank": ranks[idx],
            "novelty": float(geometry.novelty[idx]),
            "coverage": float(geometry.coverage[idx]),
            "risk_geo_score": _optional_float_at(geometry.risk_geo_scores, idx),
            "feature_energy_deficit": _optional_float_at(geometry.feature_energy_deficit, idx),
            "risk_signal_usage": "auxiliary_capacity_prior" if requested_policy == "risk-aware" else "logged_only",
            "conflict_probe": "" if conflict_probe is None else float(conflict_probe[idx]),
            "conflict_probe_r": "" if conflict_probe_r is None else float(conflict_probe_r),
            "conflict_probe_passed": "" if conflict_probe_passed is None else bool(conflict_probe_passed),
            "fallback_reason": fallback_reason,
        }
        for idx, client in enumerate(clients)
    ]


def _write_report(
    output_dir,
    args,
    incompatibility_diagnostic_r,
    raw_subspace_diagnostic_r,
    update_diagnostic_r,
    geo_diagnostic_r,
    label_diagnostic_r,
    combined_diagnostic_r,
    distance_rows,
    diagnostic_passed,
    provider,
    bank_built,
    class_names,
):
    status = "PASS" if diagnostic_passed else "FAIL"
    text = [
        "FedAdapterManifold diagnostic report",
        f"dataset={args.dataset}",
        f"classes={','.join(class_names)}",
        f"geometry_provider={provider}",
        "main_manifold_signals=d_geo,geometry_graph,prototypes",
        "auxiliary_risk_signals=risk_geo_score,feature_energy_deficit",
        f"rank_policy={args.rank_policy}",
        f"adapter_incompatibility_failure_pearson_r={incompatibility_diagnostic_r:.6f}",
        f"raw_subspace_failure_pearson_r={raw_subspace_diagnostic_r:.6f}",
        f"update_failure_pearson_r={update_diagnostic_r:.6f}",
        f"geo_failure_pearson_r={geo_diagnostic_r:.6f}",
        f"label_failure_pearson_r={label_diagnostic_r:.6f}",
        f"combined_failure_pearson_r={combined_diagnostic_r:.6f}",
        f"diagnostic_threshold={args.diagnostic_threshold:.6f}",
        f"killer_diagnostic={status}",
        f"adapter_bank_built={bank_built}",
    ]
    complementarity = _distance_row(distance_rows, "joint_model", "subspace_plus_geo")
    if complementarity:
        text.append(f"subspace_plus_geo_r2={float(complementarity.get('r2', float('nan'))):.6f}")
        text.append(f"subspace_plus_geo_incremental_r2={float(complementarity.get('incremental_r2_vs_subspace', float('nan'))):.6f}")
        text.append(f"geo_subspace_complementarity={complementarity.get('supports_geo_subspace_complementarity')}")
    if not diagnostic_passed and not args.continue_on_failed_diagnostic:
        text.append("Stopped before expanding AdapterBank because the killer diagnostic failed.")
    path = Path(output_dir) / "diagnostic_report.txt"
    path.write_text("\n".join(text) + "\n", encoding="utf-8")


def _distance_row(rows, diagnostic_type, measure):
    for row in rows:
        if row.get("diagnostic_type") == diagnostic_type and row.get("measure") == measure:
            return row
    return None


if __name__ == "__main__":
    raise SystemExit(main())
