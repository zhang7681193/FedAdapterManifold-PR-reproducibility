from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .adapters import LoRAAdapter


Array = np.ndarray


@dataclass
class PairSubspaceMetrics:
    i: int
    j: int
    d_u: float
    d_v: float
    d_sub: float
    mean_angle_u_deg: float
    mean_angle_v_deg: float


def orthonormal_basis(matrix: Array, eps: float = 1e-10) -> Array:
    matrix = np.asarray(matrix, dtype=np.float64)
    if matrix.size == 0:
        return np.zeros((matrix.shape[0], 0), dtype=np.float64)
    u, s, _ = np.linalg.svd(matrix, full_matrices=False)
    rank = int((s > eps).sum())
    return u[:, :rank]


def principal_angles(basis_a: Array, basis_b: Array) -> Array:
    qa = orthonormal_basis(basis_a)
    qb = orthonormal_basis(basis_b)
    ra = qa.shape[1]
    rb = qb.shape[1]
    if ra == 0 and rb == 0:
        return np.zeros(0, dtype=np.float64)
    if ra == 0 or rb == 0:
        return np.full(max(ra, rb), np.pi / 2.0, dtype=np.float64)
    singular_values = np.linalg.svd(qa.T @ qb, compute_uv=False)
    singular_values = np.clip(singular_values, -1.0, 1.0)
    angles = np.arccos(singular_values)
    if ra != rb:
        pad = np.full(abs(ra - rb), np.pi / 2.0, dtype=np.float64)
        angles = np.concatenate([angles, pad])
    return angles


def grassmann_distance(basis_a: Array, basis_b: Array) -> float:
    angles = principal_angles(basis_a, basis_b)
    return float(np.sqrt(np.sum(angles**2)))


def adapter_subspace_distance(adapter_a: LoRAAdapter, adapter_b: LoRAAdapter) -> PairSubspaceMetrics:
    # U = span(B), V = span(A.T)
    angles_u = principal_angles(adapter_a.B, adapter_b.B)
    angles_v = principal_angles(adapter_a.A.T, adapter_b.A.T)
    d_u = float(np.sqrt(np.sum(angles_u**2)))
    d_v = float(np.sqrt(np.sum(angles_v**2)))
    mean_u = float(np.degrees(angles_u).mean()) if angles_u.size else 0.0
    mean_v = float(np.degrees(angles_v).mean()) if angles_v.size else 0.0
    return PairSubspaceMetrics(
        i=-1,
        j=-1,
        d_u=d_u,
        d_v=d_v,
        d_sub=d_u + d_v,
        mean_angle_u_deg=mean_u,
        mean_angle_v_deg=mean_v,
    )


def subspace_distance_matrix(adapters: list[LoRAAdapter]) -> tuple[Array, list[PairSubspaceMetrics]]:
    n = len(adapters)
    distances = np.zeros((n, n), dtype=np.float64)
    records: list[PairSubspaceMetrics] = []
    for i in range(n):
        for j in range(i + 1, n):
            metrics = adapter_subspace_distance(adapters[i], adapters[j])
            metrics.i = i
            metrics.j = j
            distances[i, j] = distances[j, i] = metrics.d_sub
            records.append(metrics)
    return distances, records
