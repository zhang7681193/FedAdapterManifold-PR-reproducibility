# FedAdapterManifold PR 实验公平性与历史论文对比审查报告

生成日期：2026-06-16

## 1. 总体结论

当前 FedAdapterManifold 的实验结果整体是公平、合理、可解释的。更准确地说：

- **内部受控比较是公平的**：主实验在同一数据集、同一 client split、同一 seed、同一 backbone/feature、同一 LoRA 适配协议和同一 evaluation set 下比较 FedAvg-LoRA、Geo-only、FedPer/Ditto/FedAMP/SCAFFOLD 等 LoRA 化 baseline 与 FedAdapterManifold。
- **实验数据没有发现明显数值造假或路径缺失问题**：我检查了论文中引用的 `results/...` 路径、主表 CSV、paired significance CSV、VFM/DINOv2 CSV、stability audit CSV。当前论文里 31 个结果路径均存在。
- **结果稳定性总体支持论文主张**：FedAvg-LoRA repair 在主要数据集和 VFM 审计中稳定为正；弱支持点也被如实暴露，例如 BloodMNIST 相对 Geo-only 的 paired accuracy interval 跨零，OfficeHome feature-level 对 Ditto 是 no-regret 追平而不是显著超越。
- **不能把我们的 accuracy 直接和历史论文公开表格做硬横向 SOTA 对比**：PACS、OfficeHome、DomainNet、MedMNIST 的很多已发表结果来自单机训练、domain adaptation、domain generalization、full fine-tuning 或不同 split/backbone。我们的任务是 federated LoRA / adapter routing，因此最公平的对比是“把已有 FL/PEFT 方法思想改造成同一联邦 LoRA 协议下的 baseline”，而不是直接拿不同论文的原始 accuracy 比高低。

一句话：**可以投，但要保持当前克制叙事：不是 universal SOTA，而是 LoRA adapter subspace incompatibility 诊断 + FedAvg-LoRA repair + safe no-regret routing/composition。**

## 2. 我实际核对了什么

### 2.1 结果路径完整性

检查对象：

- `paper/fedadaptermanifold_pr_main.tex`
- `paper/fedadaptermanifold_pr_supplement.tex`
- `results/fam_pr_evidence_pack_v15`
- `results/fam_pr_stability_audit_v1`
- full OfficeHome DINOv2 / CLIP 审计目录

结果：

- 论文中通过 `\url{results/...}` 引用的 **31 个路径全部存在**。
- 原本根目录缺少 `results/fam_pr_evidence_pack_v15`，已修复：从可复现包同步了干净的 PR evidence pack。
- `results/fam_pr_evidence_pack_v15` 与 `submission/fam_pr_repro_20260601_clean/results/fam_pr_evidence_pack_v15` 当前一致。
- PR evidence pack 内不再残留 `PAMI/TPAMI` 文本；只保留 PR 投稿语境。

### 2.2 主表数据完整性

主表数据来自：

- `results/fam_pr_evidence_pack_v15/main_accuracy_with_strong_baselines.csv`

该表包含 84 行，核心字段包括：

- `dataset`
- `method`
- `mean_accuracy`
- `std`
- `num_observations`
- `source`
- `status`
- `note`

五个主数据集均为 5 个 audited seeds：

| Dataset | min seeds | max seeds |
|---|---:|---:|
| PACS | 5 | 5 |
| OfficeCaltech | 5 | 5 |
| OfficeHomeFull | 5 | 5 |
| DomainNetMini | 5 | 5 |
| BloodMNIST | 5 | 5 |

核心均值核对如下：

| Dataset | FedAvg-LoRA | Geo-only | Selective FAM | Anchor/Expanded | Strong personalized anchor |
|---|---:|---:|---:|---:|---:|
| PACS | 0.5891 | 0.7547 | 0.7547 | 0.8022 | FedPer-FAM 0.8156 / FedPer-LoRA 0.8141 |
| Office-Caltech | 0.8866 | 0.9050 | 0.9430 | 0.9496 | FedPer-LoRA 0.9458 |
| OfficeHome | 0.7232 | 0.7454 | 0.7454 | 0.7503 | Ditto-FAM/Ditto-LoRA 0.7559 |
| DomainNetMini | 0.7915 | 0.8044 | 0.8047 | 0.8068 | FedPer-LoRA 0.8049 |
| BloodMNIST | 0.4253 | 0.7635 | 0.7654 | 0.7690 | Ditto-LoRA 0.7666 |

解释：

- FedAdapterManifold 对 FedAvg-LoRA 的修复非常稳定。
- 对最强个性化 baseline，不是所有数据集都显著胜出；PACS 和 OfficeHome 是 personalization ceiling / no-regret composition。
- 这和论文当前表述一致，没有发现“表格硬吹超过所有 baseline”的问题。

## 3. 实验公平性审查

### 3.1 内部 baseline 是否公平？

总体公平。原因：

1. 同一数据集内部使用相同 client split、seed、backbone/feature、evaluation set。
2. FedAvg-LoRA、FedProx-LoRA、SCAFFOLD-LoRA、FedPer-LoRA、Ditto-LoRA、FedAMP-LoRA 等都在同一实验协议下 LoRA 化，而不是直接引用不同论文里的原始表格。
3. Geo-only Agg 已经明确写成内部 geometry-only control，implementation key 是 `GeoAgg`，不是把未发表的 FedGeo 当作外部已发表 baseline。
4. Anchor/Expanded candidate pool 在 test evaluation 前固定，test accuracy 不参与选择。
5. 有 held-out calibration sweep，说明 safe selector 不是 test-set oracle。

### 3.2 最容易被质疑的点

#### 风险 A：Anchor/Expanded 是否像“候选池越大越好”的后验选择？

当前处理是合理的，但必须继续保留以下表述：

- candidate pool fixed before test evaluation；
- calibration 来自 training side 或声明的 held-out split；
- test labels 只在 adapter 选定后用于最终报告；
- StrongSelective 只作为 legacy implementation label，论文中用 `FAM-Anchor-Expanded` 或 expanded anchored audit。

这能挡住“你是不是在测试集上挑最好方法”的攻击。

#### 风险 B：Geo-only / FedGeo 依赖是否公平？

当前写法基本正确：

- Geo-only Agg 是内部控制变量，不是外部未发表方法 baseline。
- visual geometry 是 conditioning signal，不是论文核心贡献。
- 核心贡献仍是 LoRA adapter subspace incompatibility 诊断和 safe routing。

建议继续避免在主文中写“FedGeo-Agg 击败/被击败”这种外部 baseline 口吻。

#### 风险 C：某些数据集没有显著超过强 personalized baseline

这不是数据问题，是科学边界：

- PACS：FedPer-LoRA 很强，FedPer-FAM 仅小幅均值超过，paired interval 跨零。
- OfficeHome：guarded Ditto-FAM 追平 Ditto-LoRA，不是额外显著 gain。
- BloodMNIST：相对 Geo-only 的 accuracy gain 区间跨零。
- DomainNetMini：subspace-only 解释较弱，geometry-dominated。

论文当前已经把这些写成 claim boundaries，是正确做法。

## 4. 稳定性审查

稳定性审计来自：

- `results/fam_pr_stability_audit_v1/key_paired_seed_gains.csv`
- `results/fam_pr_stability_audit_v1/key_method_seed_stability.csv`
- `results/fam_pr_stability_audit_v1/local_training_volatility.csv`

### 4.1 支持稳定的证据

关键 paired seed gains 显示：

- PACS FedPer-FAM vs FedAvg-LoRA：5/5 seeds 正增益，平均 +0.2266。
- PACS Anchor-Expanded vs Geo-only：5/5 seeds 正增益，平均 +0.0475。
- Office-Caltech Anchor-Expanded vs FedAvg-LoRA：5/5 seeds 正增益，平均 +0.0629。
- Office-Caltech Anchor-Expanded vs Geo-only：5/5 seeds 正增益，平均 +0.0445。
- OfficeHome Ditto-FAM vs FedAvg-LoRA：5/5 seeds 正增益，平均 +0.0327。
- DomainNetMini Anchor-Expanded vs FedAvg-LoRA：正增益稳定。
- DINOv2/CLIP full OfficeHome 审计也给出正 paired CI。

### 4.2 高波动来自哪里？

最大波动主要来自 baseline：

- BloodMNIST FedAvg-LoRA：CV 约 0.218。
- BloodMNIST FedAvg-Lift：CV 约 0.223。
- PACS FedAvg-LoRA：CV 约 0.051。
- DINOv2-PACS FedAvg-LoRA：CV 约 0.036。

FedAdapterManifold 在 BloodMNIST 也有一定波动，但低于 FedAvg-LoRA/FedAvg-Lift，说明它不是靠单一幸运 seed 撑起来的。

### 4.3 稳定性结论

训练波动没有推翻论文结论。相反，它支持一个更准确的说法：

> 在视觉异构和 label-skew 场景中，FedAvg-LoRA 本身可能高度不稳定；FedAdapterManifold 的价值是通过 adapter compatibility 和 anchor fallback 修复或控制这种负迁移。

## 5. 与历史论文结果如何公平比较

### 5.1 不能直接比较 raw accuracy 的原因

历史论文常见设置和我们不同：

- PACS 原始论文是 domain generalization benchmark，不是 federated LoRA。
- OfficeHome 原始论文是 domain adaptation / hashing benchmark，不是 federated PEFT。
- DomainNet 是 multi-source domain adaptation 大数据集，我们使用 DomainNetMini/DomainNetMini-60 子设置。
- MedMNIST/BloodMNIST 是医学图像 benchmark，我们这里是 medical label-skew federated setting。
- CLIP/DINOv2 是 pretrained visual backbone，我们的 LoRA/adapter routing 协议不是传统 full fine-tuning。

因此，不能说：

> 我们的 0.9488 直接超过某篇 PACS 论文，所以 SOTA。

应该说：

> 在相同 federated LoRA protocol 下，我们比较了 FedAvg/FedProx/SCAFFOLD/FedPer/Ditto/FedAMP/FedProto/FedRot-style controls 等强 baseline，证明 adapter subspace routing 能修复 FedAvg-LoRA 负迁移，并在若干强 stress cases 中超过或 no-regret 匹配强 personalization anchor。

### 5.2 已发表/近期工作的关系

下面是最相关的外部工作及其和我们实验的关系：

- FedAvg 提出模型平均的联邦学习基本协议；我们的 FedAvg-LoRA 是其 LoRA/adapter 化版本，用来测试“单一全局 adapter 是否足够”。
- FedProx 和 SCAFFOLD 处理 non-IID / client drift；我们的 FedProx-LoRA 和 SCAFFOLD-LoRA 是重要控制 baseline。
- FedPer、Ditto、FedAMP、FedProto 等 personalized/prototype FL 处理个性化和异构；我们把它们作为强 anchor，不把它们当作弱 baseline。
- FedRot-LoRA / FedGaLore 等近期 federated LoRA 工作指出 rotational mismatch、subspace/state alignment 等代数问题；我们的差异是进一步问：即使代数错位被控制，视觉语义 adapter 子空间是否仍然不兼容。
- CLIP 和 DINOv2 提供现代视觉 backbone；我们的 VFM/backbone audits 用它们验证机制不是单一 feature extractor artifact。

### 5.3 外部论文对比结论

和已有论文对比时，我们的说法应当是：

1. **我们覆盖了已有 FL/pFL/PEFT baseline 的核心思想**：FedAvg、FedProx、SCAFFOLD、FedPer、Ditto、FedAMP、FedProto、FedRot-style control、FedAvg-Lift。
2. **我们不是直接复刻每篇论文的原始配置**：因为原始论文的任务、数据、模型、split 不同。
3. **我们的公平性来自内部统一协议**：所有 baseline 在相同 federated visual LoRA/adapter setting 下跑。
4. **我们不宣称公开 leaderboard SOTA**：主张是 mechanism validity 和 negative-transfer repair。

## 6. 每个数据集的合理性判断

### 6.1 PACS

结果合理。

- FedAvg-LoRA 低，说明强 domain heterogeneity 下单一平均 adapter 失败。
- FedPer-LoRA 很强，符合 PACS 个性化 ceiling。
- FedPer-FAM 小幅超过 FedPer-LoRA，但不显著；论文正确写成 no-regret composition。
- DINOv2-PACS 结果很高，符合 DINOv2 pretrained feature 强、PACS 类别少的直觉；但强 anchor 间差距小，因此不应吹显著 dominance。

### 6.2 Office-Caltech

结果合理。

- Office-Caltech 类别少、上限高，因此 absolute accuracy 高是正常的。
- FedRot-LoRA 接近 FedAvg-LoRA，说明 rotational alignment 不能单独解决语义 adapter conflict；这支持本文差异。
- Anchor-Expanded 最高，但相对 FedPer-LoRA 的 margin 小；论文已经写成 safe-routing gain case + no-regret composition。

### 6.3 OfficeHome

结果合理，但要谨慎表述。

- full 65-class OfficeHome 更难，0.72--0.76 区间是合理的。
- Ditto-LoRA 很强，guarded Ditto-FAM 追平它，这是 no-regret 证据，不是额外 SOTA gain。
- OfficeHome-DINOv2 full-data 20-round 结果非常关键：它相对 FedAvg、Geo-only、Ditto 都有正 paired CI，是目前最有力的大规模 VFM/backbone 证据之一。

### 6.4 DomainNetMini

结果合理，但机制解释要保守。

- DomainNetMini/DomainNetMini-60 是自定义 federated subset，不可与完整 DomainNet 公开 SOTA 直接比较。
- Anchor-Expanded 小幅超过强 baseline，但 margin 不大。
- larger CLIP split 显示 FedAvg repair 明确，但相对 Geo-only 不显著，且更 geometry-dominated。
- 这说明 DomainNetMini 是 multi-signal routing case，不应写成纯 subspace-only 成功。

### 6.5 BloodMNIST

结果合理，但波动较大。

- FedAvg-LoRA 低且高波动，符合 label-skew medical setting 中全局平均失败的直觉。
- Geo-only 已经很强，FedAdapterManifold 相对 Geo-only 的 accuracy gain 小且区间跨零。
- 但 update conflict reduction 和 FedAvg repair 支持方法价值。
- 应继续写成 medical conflict/risk support，而不是决定性 accuracy dominance。

## 7. 是否需要修改论文表述

需要保留当前克制写法，并建议再强化三点：

1. **不要写 universal SOTA**  
   正确表述：FedAvg-LoRA repair、adapter conflict diagnosis、safe no-regret composition。

2. **Geo-only 是内部控制，不是外部未发表方法 baseline**  
   正确表述：`Geo-only Agg (implementation key: GeoAgg)`。

3. **外部论文结果只用于定位和动机，不用于 raw accuracy 硬横比**  
   正确表述：prior papers motivate baselines and datasets; our claims are made under a controlled federated LoRA protocol。

## 8. 最终审查意见

### 可以强说的结论

- LoRA adapter subspace incompatibility 与 FedAvg-LoRA failure 有稳定正相关。
- FedAdapterManifold 能稳定修复 FedAvg-LoRA。
- Anchor/safe routing 能避免把强 personalized anchor 破坏掉。
- full OfficeHome-DINOv2 和 CLIP 审计支持方法不是单一 backbone artifact。
- raw geometry graph 不能直接裸平均，必须结合 adapter compatibility 和 safe routing。

### 只能弱说或边界化表达的结论

- 不能说全面显著超过 FedPer/Ditto 等强 personalized baselines。
- 不能说所有数据集都是 subspace-only 机制；DomainNetMini 更像 geometry-dominated。
- 不能说 BloodMNIST decisive accuracy win over Geo-only。
- 不能和历史 PACS/OfficeHome/DomainNet 单机论文直接比 raw accuracy。

### 最终判断

实验是公平和合理的；数据路径、主表、paired statistics、稳定性审计目前没有发现硬伤。最大的风险不是数据本身，而是**审稿人误解对比口径**。只要文章继续保持现在的边界：

> FedAdapterManifold is a mechanism and safe-routing framework for federated visual LoRA adapters, not a universal leaderboard SOTA method.

那么当前实验是可以支撑 Pattern Recognition 投稿的。

## 9. 核对中用到的主要外部资料

- LoRA: https://arxiv.org/abs/2106.09685
- FedAvg: https://arxiv.org/abs/1602.05629
- FedProx: https://arxiv.org/abs/1812.06127
- SCAFFOLD: https://arxiv.org/abs/1910.06378
- Ditto: https://arxiv.org/abs/2012.04221
- FedPer: https://arxiv.org/abs/1912.00818
- FedAMP: https://arxiv.org/abs/2007.03797
- FedProto: https://arxiv.org/abs/2105.00243
- PACS: https://arxiv.org/abs/1710.03077
- OfficeHome: https://arxiv.org/abs/1706.07522
- DomainNet: https://arxiv.org/abs/1812.01754
- MedMNIST v2: https://arxiv.org/abs/2110.14795
- CLIP: https://arxiv.org/abs/2103.00020
- DINOv2: https://arxiv.org/abs/2304.07193
- FedRot-LoRA: https://arxiv.org/abs/2602.23638
- FedGaLore: https://arxiv.org/abs/2602.01746
- Federated PEFT survey: https://arxiv.org/abs/2504.21099

