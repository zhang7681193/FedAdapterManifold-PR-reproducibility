# End-to-End CLIP ViT LoRA Main Supplement

Setting: DomainNetMini, six domains, 20 classes, rank-4 LoRA in the last two CLIP ViT-B/16 visual attention blocks, two epochs.

- CLIP-ZeroShot: accuracy 0.7711 +/- 0.0000, loss 0.7376
- EndToEnd-CLIPViT-LoRA: accuracy 0.8313 +/- 0.0060, loss 0.5707
- Paired seed gain over CLIP-ZeroShot: 0.0602 +/- 0.0060; all 3 seeds positive; exact two-sided sign-flip p=0.2500.
