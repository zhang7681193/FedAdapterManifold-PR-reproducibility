# End-to-end CLIP ViT LoRA smoke

This run injects trainable LoRA factors into the visual transformer attention block(s) of OpenAI CLIP ViT and backpropagates through the image encoder.
It is intentionally tiny and is used only as an implementation sanity check. It should not be mixed with the main feature-level FedAdapterManifold evidence table.