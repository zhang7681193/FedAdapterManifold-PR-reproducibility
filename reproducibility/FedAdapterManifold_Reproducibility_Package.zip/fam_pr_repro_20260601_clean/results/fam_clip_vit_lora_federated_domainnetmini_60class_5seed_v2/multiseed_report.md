# Federated End-to-End CLIP ViT LoRA 60-Class DomainNetMini 5-Seed Report (Graph Support v2)

Setting: 6 domains, 60 shared classes, CLIP ViT-B/16 visual attention LoRA, rank 4, last 2 blocks, 2 local epochs, FedGeo active-sparse50 round 4 geometry. FedGeo graph is interpreted as kNN manifold support to avoid affinity underflow collapsing to self-only.

## Method Summary

| Rank | Method | Acc | CI low | Worst risk | Conflict |
|---:|---|---:|---:|---:|---:|
| 1 | FedAdapterManifold-Selective-CLIP-LoRA | 0.7926 | 0.7896 | 0.6222 | 0.0000 |
| 2 | Local-CLIP-LoRA | 0.7926 | 0.7896 | 0.6222 | 0.0000 |
| 3 | FedAdapterManifold-CLIP-LoRA | 0.7807 | 0.7769 | 0.6485 | 0.0119 |
| 4 | FedGeo-Agg-CLIP-LoRA | 0.7804 | 0.7769 | 0.6566 | 0.0122 |
| 5 | FedAvg-Lift-CLIP-LoRA | 0.7754 | 0.7745 | 0.6646 | 0.0172 |
| 6 | CLIP-ZeroShot | 0.7745 | 0.7745 | 0.6667 | 0.0181 |
| 7 | FedAvg-CLIP-LoRA | 0.7745 | 0.7745 | 0.6667 | 0.0181 |

## Key Paired Tests

| Method | Baseline | Units | Diff | CI low | p | Support |
|---|---|---:|---:|---:|---:|---|
| FedAdapterManifold-CLIP-LoRA | FedAvg-CLIP-LoRA | 30 | 0.0062 | 0.0028 | 0.001648 | True |
| FedAdapterManifold-CLIP-LoRA | FedGeo-Agg-CLIP-LoRA | 30 | 0.0003 | -0.0023 | 0.8729 | False |
| FedAdapterManifold-CLIP-LoRA | Local-CLIP-LoRA | 30 | -0.0119 | -0.0160 | 0 | False |
| FedAdapterManifold-Selective-CLIP-LoRA | FedAvg-CLIP-LoRA | 30 | 0.0181 | 0.0125 | 0 | True |
| FedAdapterManifold-Selective-CLIP-LoRA | FedGeo-Agg-CLIP-LoRA | 30 | 0.0122 | 0.0076 | 0 | True |
| FedAdapterManifold-Selective-CLIP-LoRA | Local-CLIP-LoRA | 30 | 0.0000 | 0.0000 | 1 | False |
| FedAvg-Lift-CLIP-LoRA | FedAvg-CLIP-LoRA | 30 | 0.0009 | 0.0000 | 0.502 | False |
| FedAvg-Lift-CLIP-LoRA | FedGeo-Agg-CLIP-LoRA | 30 | -0.0050 | -0.0079 | 0.00293 | False |
| FedAvg-Lift-CLIP-LoRA | Local-CLIP-LoRA | 30 | -0.0172 | -0.0230 | 0 | False |
| FedGeo-Agg-CLIP-LoRA | FedAvg-CLIP-LoRA | 30 | 0.0059 | 0.0029 | 0.001099 | True |
| FedGeo-Agg-CLIP-LoRA | Local-CLIP-LoRA | 30 | -0.0122 | -0.0170 | 0 | False |

## Diagnostics

- subspace_failure_pearson_r: 0.1382 +/- 0.1285, CI low 0.0265, positive seeds 4/5
- geometry_failure_pearson_r: -0.0502 +/- 0.1376, CI low -0.1642, positive seeds 2/5
