# Federated CLIP ViT LoRA Multiseed Report

| Method | Mean accuracy | CI low | CI high |
|---|---:|---:|---:|
| Local-CLIP-LoRA | 0.7941 | 0.7928 | 0.7966 |
| FedAdapterManifold-Selective-CLIP-LoRA | 0.7927 | 0.7897 | 0.7962 |
| FedGeo-Agg-CLIP-LoRA | 0.7896 | 0.7882 | 0.7918 |
| FedAdapterManifold-CLIP-LoRA | 0.7892 | 0.7886 | 0.7899 |
| FedAvg-Lift-CLIP-LoRA | 0.7820 | 0.7792 | 0.7847 |
| CLIP-ZeroShot | 0.7745 | 0.7745 | 0.7745 |
| FedAvg-CLIP-LoRA | 0.7745 | 0.7745 | 0.7745 |

## Key paired gains

| Method | Baseline | Diff | CI low | Supports |
|---|---|---:|---:|---|
| FedAdapterManifold-Selective-CLIP-LoRA | FedAvg-CLIP-LoRA | 0.0182 | 0.0112 | True |
| FedAdapterManifold-Selective-CLIP-LoRA | FedGeo-Agg-CLIP-LoRA | 0.0030 | -0.0011 | False |
| FedAdapterManifold-Selective-CLIP-LoRA | Local-CLIP-LoRA | -0.0015 | -0.0040 | False |
| FedAdapterManifold-Selective-CLIP-LoRA | CLIP-ZeroShot | 0.0182 | 0.0112 | True |
