# Federated End-to-End CLIP ViT LoRA Office-Caltech 10-Class 5-Seed Report

Setting: Office-Caltech 4 domains, 10 semantic object classes, CLIP ViT-B/16 visual attention LoRA, rank 4, last 2 blocks, 2 local epochs, FedAvg-source FedGeo round 4 geometry.

## Method Summary

| Rank | Method | Acc | CI low | Worst risk | Conflict |
|---:|---|---:|---:|---:|---:|
| 1 | FedAvg-Lift-CLIP-LoRA | 0.9786 | 0.9773 | 0.0448 | 0.0010 |
| 2 | FedAdapterManifold-CLIP-LoRA | 0.9774 | 0.9755 | 0.0437 | 0.0008 |
| 3 | FedGeo-Agg-CLIP-LoRA | 0.9769 | 0.9752 | 0.0448 | 0.0010 |
| 4 | Local-CLIP-LoRA | 0.9766 | 0.9746 | 0.0448 | 0.0000 |
| 5 | FedAdapterManifold-Selective-CLIP-LoRA | 0.9763 | 0.9746 | 0.0448 | 0.0003 |
| 6 | FedAvg-CLIP-LoRA | 0.9732 | 0.9727 | 0.0604 | 0.0060 |
| 7 | CLIP-ZeroShot | 0.9706 | 0.9701 | 0.0708 | 0.0086 |

## Key Paired Tests

| Method | Baseline | Units | Diff | CI low | p | Support |
|---|---|---:|---:|---:|---:|---|
| FedAdapterManifold-CLIP-LoRA | FedAvg-CLIP-LoRA | 20 | 0.0043 | -0.0003 | 0.08594 | False |
| FedAdapterManifold-CLIP-LoRA | FedGeo-Agg-CLIP-LoRA | 20 | 0.0005 | 0.0000 | 0.5076 | False |
| FedAdapterManifold-CLIP-LoRA | Local-CLIP-LoRA | 20 | 0.0009 | -0.0010 | 0.6548 | False |
| FedAdapterManifold-Selective-CLIP-LoRA | FedAvg-CLIP-LoRA | 20 | 0.0031 | -0.0017 | 0.2062 | False |
| FedAdapterManifold-Selective-CLIP-LoRA | FedGeo-Agg-CLIP-LoRA | 20 | -0.0006 | -0.0028 | 0.8075 | False |
| FedAdapterManifold-Selective-CLIP-LoRA | Local-CLIP-LoRA | 20 | -0.0003 | -0.0008 | 1 | False |
| FedAvg-Lift-CLIP-LoRA | FedAvg-CLIP-LoRA | 20 | 0.0055 | 0.0026 | 0.002502 | True |
| FedAvg-Lift-CLIP-LoRA | FedGeo-Agg-CLIP-LoRA | 20 | 0.0017 | -0.0003 | 0.3788 | False |
| FedAvg-Lift-CLIP-LoRA | Local-CLIP-LoRA | 20 | 0.0021 | -0.0008 | 0.2334 | False |
| FedGeo-Agg-CLIP-LoRA | FedAvg-CLIP-LoRA | 20 | 0.0037 | -0.0007 | 0.1178 | False |
| FedGeo-Agg-CLIP-LoRA | Local-CLIP-LoRA | 20 | 0.0003 | -0.0016 | 0.9022 | False |

## Diagnostics

- subspace_failure_pearson_r: 0.0881 +/- 0.2379, CI low -0.1278, positive seeds 4/5
- geometry_failure_pearson_r: -0.0411 +/- 0.2955, CI low -0.3765, positive seeds 2/5
