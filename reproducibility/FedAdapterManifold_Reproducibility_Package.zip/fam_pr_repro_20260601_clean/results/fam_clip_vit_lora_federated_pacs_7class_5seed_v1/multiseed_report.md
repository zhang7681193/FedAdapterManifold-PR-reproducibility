# Federated End-to-End CLIP ViT LoRA PACS 7-Class 5-Seed Report

Setting: PACS 4 domains, 7 semantic classes, CLIP ViT-B/16 visual attention LoRA, rank 4, last 2 blocks, 2 local epochs, FedAvg-source FedGeo round 9 geometry.

## Method Summary

| Rank | Method | Acc | CI low | Worst risk | Conflict |
|---:|---|---:|---:|---:|---:|
| 1 | FedAdapterManifold-Selective-CLIP-LoRA | 0.9758 | 0.9733 | 0.0667 | 0.0000 |
| 2 | Local-CLIP-LoRA | 0.9758 | 0.9733 | 0.0667 | 0.0000 |
| 3 | FedAdapterManifold-CLIP-LoRA | 0.9728 | 0.9698 | 0.0803 | 0.0034 |
| 4 | FedGeo-Agg-CLIP-LoRA | 0.9709 | 0.9680 | 0.0879 | 0.0057 |
| 5 | FedAvg-Lift-CLIP-LoRA | 0.9694 | 0.9660 | 0.0939 | 0.0072 |
| 6 | CLIP-ZeroShot | 0.9679 | 0.9659 | 0.1000 | 0.0094 |
| 7 | FedAvg-CLIP-LoRA | 0.9675 | 0.9649 | 0.1000 | 0.0087 |

## Key Paired Tests

| Method | Baseline | Units | Diff | CI low | p | Support |
|---|---|---:|---:|---:|---:|---|
| FedAdapterManifold-CLIP-LoRA | FedAvg-CLIP-LoRA | 20 | 0.0053 | 0.0015 | 0.03125 | True |
| FedAdapterManifold-CLIP-LoRA | FedGeo-Agg-CLIP-LoRA | 20 | 0.0019 | 0.0000 | 0.09479 | True |
| FedAdapterManifold-CLIP-LoRA | Local-CLIP-LoRA | 20 | -0.0031 | -0.0064 | 0.06311 | False |
| FedAdapterManifold-Selective-CLIP-LoRA | FedAvg-CLIP-LoRA | 20 | 0.0083 | 0.0023 | 0.04645 | True |
| FedAdapterManifold-Selective-CLIP-LoRA | FedGeo-Agg-CLIP-LoRA | 20 | 0.0049 | 0.0008 | 0.05511 | True |
| FedAdapterManifold-Selective-CLIP-LoRA | Local-CLIP-LoRA | 20 | 0.0000 | 0.0000 | 1 | False |
| FedAvg-Lift-CLIP-LoRA | FedAvg-CLIP-LoRA | 20 | 0.0019 | 0.0004 | 0.124 | True |
| FedAvg-Lift-CLIP-LoRA | FedGeo-Agg-CLIP-LoRA | 20 | -0.0015 | -0.0042 | 0.3717 | False |
| FedAvg-Lift-CLIP-LoRA | Local-CLIP-LoRA | 20 | -0.0065 | -0.0129 | 0.06238 | False |
| FedGeo-Agg-CLIP-LoRA | FedAvg-CLIP-LoRA | 20 | 0.0034 | 0.0011 | 0.03009 | True |
| FedGeo-Agg-CLIP-LoRA | Local-CLIP-LoRA | 20 | -0.0049 | -0.0098 | 0.05511 | False |

## Diagnostics

- subspace_failure_pearson_r: 0.1200 +/- 0.2039, CI low -0.0401, positive seeds 3/5
- geometry_failure_pearson_r: 0.4714 +/- 0.0871, CI low 0.4175, positive seeds 5/5
