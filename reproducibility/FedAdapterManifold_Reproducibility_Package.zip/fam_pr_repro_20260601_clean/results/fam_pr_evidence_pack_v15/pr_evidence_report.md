# FedAdapterManifold PR Evidence Pack

## Bottom Line

- The core mechanism is supported strongly enough to continue: adapter incompatibility/subspace conflict correlates with FedAvg-LoRA failure in the pooled PACS 5-seed result and in multiple prior roots.
- The strongest caveat is no longer FedAvg; it is personalized baselines such as FedPer-LoRA and Ditto-LoRA. PACS supports a compositional fix: FedPer-FAM slightly exceeds FedPer-LoRA in mean accuracy, though the paired margin is small. OfficeHome supports the complementary no-regret case: guarded Ditto-FAM matches Ditto-LoRA while retaining the FAM branch when local calibration warrants it.
- The VFM evidence now includes five-seed CLIP ViT-B/16 attention-LoRA on DomainNetMini-60, a larger DomainNetMini-60 8/8-shot split, PACS-7, and Office-Caltech-10, plus DINOv2-S/14 anchored audits on PACS and full-data 65-class, 20-round OfficeHome splits for both DINOv2-S/14 and CLIP ViT-B/16. PACS-DINOv2 resolves the mean-accuracy ceiling caveat and supports FedAvg/GeoAgg repair; OfficeHome-DINOv2 supports the anchored selector against FedAvg, GeoAgg, and Ditto with stable positive paired CIs; OfficeHome-CLIP supports full-data FedAvg/GeoAgg repair; the larger DomainNetMini CLIP split supports FedAvg repair but is geometry-dominated relative to GeoAgg.
- The paper positions the method as geometry-conditioned adapter sharing/routing/personalization with safety gates, not as a universal mean-accuracy winner on every dataset.

## Top Methods By Dataset

| Dataset | Rank | Method | Accuracy |
|---|---:|---|---:|
| PACS | 1 | FedPer-FAM | 0.8156 |
| PACS | 2 | FedPer-FAM-Selective | 0.8156 |
| PACS | 3 | FedPer-LoRA | 0.8141 |
| PACS | 4 | FedAdapterManifold-StrongSelective | 0.8022 |
| PACS | 5 | FedAMP-LoRA | 0.7634 |
| OfficeCaltech | 1 | FedAdapterManifold-StrongSelective | 0.9496 |
| OfficeCaltech | 2 | FedPer-LoRA | 0.9458 |
| OfficeCaltech | 3 | FedPer-FAM | 0.9458 |
| OfficeCaltech | 4 | FedPer-FAM-Selective | 0.9458 |
| OfficeCaltech | 5 | FedAdapterManifold-Selective | 0.9430 |
| OfficeHomeFull | 1 | Ditto-LoRA | 0.7559 |
| OfficeHomeFull | 2 | Ditto-FAM | 0.7559 |
| OfficeHomeFull | 3 | Ditto-FAM-Selective | 0.7559 |
| OfficeHomeFull | 4 | FedAdapterManifold-StrongSelective | 0.7503 |
| OfficeHomeFull | 5 | FedAMP-LoRA | 0.7457 |
| DomainNetMini | 1 | FedAdapterManifold-StrongSelective | 0.8068 |
| DomainNetMini | 2 | FedPer-LoRA | 0.8049 |
| DomainNetMini | 3 | FedPer-FAM | 0.8049 |
| DomainNetMini | 4 | FedPer-FAM-Selective | 0.8049 |
| DomainNetMini | 5 | FedAdapterManifold-Selective | 0.8047 |
| BloodMNIST | 1 | FedAdapterManifold-StrongSelective | 0.7690 |
| BloodMNIST | 2 | Ditto-LoRA | 0.7666 |
| BloodMNIST | 3 | FedAdapterManifold | 0.7654 |
| BloodMNIST | 4 | FedAdapterManifold-Selective | 0.7654 |
| BloodMNIST | 5 | FedPer-FAM | 0.7649 |

## Key Diagnostics

| Dataset | Claim | Support | Estimate | CI Low | Action |
|---|---|---|---:|---:|---|
| PACS | adapter_incompatibility_failure_correlation | True | 0.3333 | 0.0974 | claim_as_supported |
| PACS | adapter_bank_gain_vs_fedavg | True | 0.1656 | 0.1441 | claim_as_supported |
| PACS | adapter_bank_gain_vs_fedgeo_agg | False | 0.0000 | 0.0000 | revise_or_rerun_core_claim |
| PACS | update_conflict_reduction_vs_fedavg | True | 0.7234 | 0.7073 | claim_as_supported |
| OfficeCaltech | adapter_incompatibility_failure_correlation | True | 0.2773 | 0.0854 | claim_as_supported |
| OfficeCaltech | adapter_bank_gain_vs_fedavg | True | 0.0564 | 0.0424 | claim_as_supported |
| OfficeCaltech | adapter_bank_gain_vs_fedgeo_agg | True | 0.0380 | 0.0141 | claim_as_supported |
| OfficeCaltech | update_conflict_reduction_vs_fedavg | True | 0.5170 | 0.4650 | claim_as_supported |
| OfficeHomeFull | adapter_incompatibility_failure_correlation | True | 0.7388 | 0.6313 | claim_as_supported |
| OfficeHomeFull | adapter_bank_gain_vs_fedavg | True | 0.0222 | 0.0139 | claim_as_supported |
| OfficeHomeFull | adapter_bank_gain_vs_fedgeo_agg | False | 0.0000 | 0.0000 | revise_or_rerun_core_claim |
| OfficeHomeFull | update_conflict_reduction_vs_fedavg | True | 0.7876 | 0.7699 | claim_as_supported |
| DomainNetMini | adapter_incompatibility_failure_correlation | True | 0.1932 | 0.0592 | claim_as_supported |
| DomainNetMini | adapter_bank_gain_vs_fedavg | True | 0.0132 | 0.0058 | claim_as_supported |
| DomainNetMini | adapter_bank_gain_vs_fedgeo_agg | False | 0.0003 | -0.0008 | revise_or_rerun_core_claim |
| DomainNetMini | update_conflict_reduction_vs_fedavg | True | 1.2309 | 1.0105 | claim_as_supported |
| BloodMNIST | adapter_incompatibility_failure_correlation | True | 0.3441 | 0.2403 | claim_as_supported |
| BloodMNIST | adapter_bank_gain_vs_fedavg | True | 0.3401 | 0.2662 | claim_as_supported |
| BloodMNIST | adapter_bank_gain_vs_fedgeo_agg | False | 0.0020 | -0.0041 | revise_or_rerun_core_claim |
| BloodMNIST | update_conflict_reduction_vs_fedavg | True | 0.9242 | 0.8288 | claim_as_supported |

## Seven-Item Status

- **Strong PEFT-FL baselines**: completed_for_main_claims. FedProx, Ditto, Clustered, FedAMP across main roots; FedProto/FedPer/FedPer-FAM added on PACS 5-seed, Office-Caltech neighbor-aware 5-seed, DomainNetMini text-head, and BloodMNIST 5-seed. OfficeHome adds a guarded Ditto-FAM audit that matches the strongest Ditto-LoRA ceiling by conservative personal fallback. Risk: PACS shows FedPer-LoRA is a very strong personalization ceiling; FedPer-FAM slightly improves the mean but the paired gain over FedPer is small. OfficeHome shows no-regret composability rather than an extra gain beyond Ditto-LoRA. Frame FAM as geometry-conditioned safe routing and personalization composition, not universal winner.
- **Visual foundation/pretrained backbone evidence**: completed_with_federated_end_to_end_clip_vit_and_dinov2_audits. 5-seed federated CLIP ViT-B/16 attention-LoRA runs on DomainNetMini 60-class, a larger DomainNetMini 60-class 8/8-shot split, PACS 7-class, and Office-Caltech 10-class; supplementary CLIP ViT-B/32 and ResNet18-pretrained audits; a PACS DINOv2-S/14 calib20 anchored audit where StrongSelective has the best mean accuracy and improves over FedAvg/GeoAgg with positive paired CIs; a full-data OfficeHome-DINOv2 65-class, 20-round, calib20 anchored-no-regret audit where StrongSelective improves over FedAvg, GeoAgg, and Ditto with positive paired CIs; and a full-data OfficeHome-CLIP ViT-B/16 65-class, 20-round, calib20 audit where StrongSelective improves over FedAvg and GeoAgg with positive paired CIs. Risk: Office-Caltech is a high-ceiling setting with small non-significant gains; PACS DINOv2 resolves the mean-accuracy caveat but does not significantly dominate every strong anchor such as FedPer-LoRA; the larger DomainNetMini CLIP split is geometry-dominated and repairs FedAvg but does not significantly beat GeoAgg; full OfficeHome-CLIP improves over FedAvg/GeoAgg but not significantly over Ditto; capped OfficeHome-DINOv2 240/160 runs are excluded as invalid main evidence.
- **5 seeds + CI/significance**: completed_for_main_claims. PACS, Office-Caltech, OfficeHome, DomainNetMini, and BloodMNIST feature-level roots are five-seed; end-to-end CLIP ViT DomainNetMini/PACS/Office-Caltech are five-seed; DomainNetMini also has a larger 60-class 8/8-shot CLIP-LoRA audit; all roots produce bootstrap CIs and paired significance pack. Risk: DomainNetMini has both a five-seed text-head stress run and five-seed end-to-end DomainNetMini 60-class CLIP-LoRA stress tests. The 8/8-shot split is evidence for FedAvg repair and geometry-dominated routing, not for a subspace-only story.
- **Gate legality/no test leakage**: completed. candidate_selector_calibration_fraction and Office-Caltech 5/10/20% calibration sweep. Risk: Held-out calibration reduces training data; report accuracy/risk tradeoff.
- **Full distance/component ablation**: completed_with_mixed_support. OfficeCaltech and DomainNetMini distance ablation tables. Risk: Do not claim all components always dominate; claim complementary roles.
- **Negative controls**: completed. Office-Caltech safe-gated, forced raw graph, and self-anchor graph controls. Risk: Raw graph sharing can hurt, which supports safe routing but weakens naked graph-sharing claims.
- **Claim/title positioning**: completed. Title and abstract weakened; evidence pack separates main, caveat, and supplement claims. Risk: PR still needs careful wording around the unpublished geometry-provider dependency and feature-level adaptation.
