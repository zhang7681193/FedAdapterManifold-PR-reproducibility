# FedAdapterManifold Stability Audit

Scope: final manuscript result roots only; early exploratory runs are excluded.

## Conclusion
- Main/VFM FedAvg-LoRA repair comparisons are 5/5 positive across the audited comparisons: `True`.
- No evidence of a systemic training-collapse pattern in the deployable FAM results.
- Higher seed variance is concentrated in BloodMNIST, PACS FedAvg-LoRA, DINOv2-PACS FedAvg-LoRA, and some strong-control baselines such as Office-Caltech SCAFFOLD / FedRot / pFedMe histories.
- BloodMNIST should remain framed as FedAvg repair plus conflict/risk support; gains over Geo-only/Ditto are mean-positive but seed-mixed.
- OfficeHome feature-level should remain a no-regret composition case; DINOv2 OfficeHome is the stronger stable full-data VFM evidence.

## High-Variance Key Rows
| dataset | method | mean | std | min | max | range | cv |
| --- | --- | --- | --- | --- | --- | --- | --- |
| BloodMNIST | FedAvg-Lift | 0.4977 | 0.1111 | 0.3070 | 0.5941 | 0.2871 | 0.2232 |
| BloodMNIST | FedAvg-LoRA | 0.4253 | 0.0926 | 0.2774 | 0.5286 | 0.2512 | 0.2178 |
| OfficeCaltech | SCAFFOLD-LoRA | 0.8041 | 0.0477 | 0.7537 | 0.8635 | 0.1098 | 0.0593 |
| BloodMNIST | Ditto-LoRA | 0.7666 | 0.0364 | 0.7155 | 0.8112 | 0.0957 | 0.0475 |
| BloodMNIST | Geo-only Agg | 0.7635 | 0.0353 | 0.7165 | 0.8119 | 0.0953 | 0.0462 |
| BloodMNIST | FedPer-LoRA | 0.7648 | 0.0350 | 0.7183 | 0.8050 | 0.0867 | 0.0457 |
| BloodMNIST | FedPer-FAM | 0.7649 | 0.0349 | 0.7183 | 0.8050 | 0.0867 | 0.0456 |
| DINOv2-PACS | FedAvg-LoRA | 0.8938 | 0.0322 | 0.8391 | 0.9234 | 0.0844 | 0.0361 |
| BloodMNIST | FedAdapterManifold-Anchor-Expanded | 0.7690 | 0.0316 | 0.7266 | 0.8082 | 0.0816 | 0.0411 |
| PACS | FedAvg-LoRA | 0.5891 | 0.0302 | 0.5469 | 0.6250 | 0.0781 | 0.0513 |
| CLIP-OfficeHomeFull | FedAvg-Lift | 0.4598 | 0.0246 | 0.4348 | 0.4921 | 0.0573 | 0.0535 |
| PACS | SCAFFOLD-LoRA | 0.7625 | 0.0216 | 0.7391 | 0.7875 | 0.0484 | 0.0283 |

## Key Paired Seed Gains
| dataset | method | baseline | mean_gain | min_gain | max_gain | positive_seeds | nonnegative_seeds |
| --- | --- | --- | --- | --- | --- | --- | --- |
| PACS | FedPer-FAM | FedAvg-LoRA | 0.2266 | 0.1781 | 0.2625 | 5 | 5 |
| PACS | FedPer-FAM | FedPer-LoRA | 0.0016 | -0.0062 | 0.0109 | 3 | 3 |
| PACS | FedAdapterManifold-Anchor-Expanded | Geo-only Agg | 0.0475 | 0.0406 | 0.0531 | 5 | 5 |
| OfficeCaltech | FedAdapterManifold-Anchor-Expanded | FedAvg-LoRA | 0.0629 | 0.0521 | 0.0789 | 5 | 5 |
| OfficeCaltech | FedAdapterManifold-Anchor-Expanded | Geo-only Agg | 0.0445 | 0.0356 | 0.0624 | 5 | 5 |
| OfficeCaltech | FedAdapterManifold-Anchor-Expanded | FedPer-LoRA | 0.0037 | -0.0078 | 0.0141 | 4 | 4 |
| OfficeHomeFull | Ditto-FAM | FedAvg-LoRA | 0.0327 | 0.0181 | 0.0443 | 5 | 5 |
| OfficeHomeFull | Ditto-FAM | Geo-only Agg | 0.0105 | -0.0020 | 0.0248 | 3 | 3 |
| OfficeHomeFull | Ditto-FAM | Ditto-LoRA | 0.0000 | 0.0000 | 0.0000 | 0 | 5 |
| OfficeHomeFull | FedAdapterManifold-Anchor-Expanded | FedAvg-LoRA | 0.0271 | 0.0069 | 0.0464 | 5 | 5 |
| DomainNetMini | FedAdapterManifold-Anchor-Expanded | FedAvg-LoRA | 0.0153 | 0.0115 | 0.0256 | 5 | 5 |
| DomainNetMini | FedAdapterManifold-Anchor-Expanded | Geo-only Agg | 0.0024 | 0.0013 | 0.0027 | 5 | 5 |
| DomainNetMini | FedAdapterManifold-Anchor-Expanded | FedPer-LoRA | 0.0019 | 0.0000 | 0.0027 | 4 | 5 |
| BloodMNIST | FedAdapterManifold-Anchor-Expanded | FedAvg-LoRA | 0.3437 | 0.2206 | 0.5020 | 5 | 5 |
| BloodMNIST | FedAdapterManifold-Anchor-Expanded | Geo-only Agg | 0.0055 | -0.0036 | 0.0198 | 3 | 3 |
| BloodMNIST | FedAdapterManifold-Anchor-Expanded | Ditto-LoRA | 0.0024 | -0.0029 | 0.0111 | 3 | 3 |
| CLIP-DomainNetMini60 | FedAdapterManifold-Selective-CLIP-LoRA | FedAvg-CLIP-LoRA | 0.0181 | 0.0141 | 0.0221 | 5 | 5 |
| CLIP-DomainNetMini60 | FedAdapterManifold-Selective-CLIP-LoRA | Geo-only Agg-CLIP-LoRA | 0.0122 | 0.0077 | 0.0151 | 5 | 5 |
| CLIP-DomainNetMini60-8shot | FedAdapterManifold-Selective-CLIP-LoRA | FedAvg-CLIP-LoRA | 0.0182 | 0.0132 | 0.0245 | 5 | 5 |
| CLIP-DomainNetMini60-8shot | FedAdapterManifold-Selective-CLIP-LoRA | Geo-only Agg-CLIP-LoRA | 0.0030 | -0.0059 | 0.0108 | 4 | 4 |
| CLIP-PACS7 | FedAdapterManifold-Selective-CLIP-LoRA | FedAvg-CLIP-LoRA | 0.0083 | 0.0057 | 0.0113 | 5 | 5 |
| CLIP-PACS7 | FedAdapterManifold-Selective-CLIP-LoRA | Geo-only Agg-CLIP-LoRA | 0.0049 | 0.0020 | 0.0076 | 5 | 5 |
| CLIP-OfficeCaltech10 | FedAdapterManifold-Selective-CLIP-LoRA | FedAvg-CLIP-LoRA | 0.0031 | 0.0009 | 0.0065 | 5 | 5 |
| CLIP-OfficeCaltech10 | FedAdapterManifold-Selective-CLIP-LoRA | Geo-only Agg-CLIP-LoRA | -0.0006 | -0.0043 | 0.0013 | 2 | 3 |
| DINOv2-PACS | FedAdapterManifold-Anchor-Expanded | FedAvg-LoRA | 0.0550 | 0.0281 | 0.1141 | 5 | 5 |
| DINOv2-PACS | FedAdapterManifold-Anchor-Expanded | Geo-only Agg | 0.0319 | 0.0250 | 0.0437 | 5 | 5 |
| DINOv2-PACS | FedAdapterManifold-Anchor-Expanded | FedPer-LoRA | 0.0003 | -0.0031 | 0.0047 | 2 | 3 |
| DINOv2-PACS | FedAdapterManifold-Anchor-Expanded | FedAvg-Lift | 0.0016 | -0.0031 | 0.0062 | 3 | 3 |
| DINOv2-PACS | FedAdapterManifold-Anchor-Expanded | SCAFFOLD-LoRA | 0.0037 | 0.0016 | 0.0062 | 5 | 5 |
| DINOv2-OfficeHomeFull | FedAdapterManifold-Anchor-Expanded | FedAvg-LoRA | 0.0316 | 0.0212 | 0.0374 | 5 | 5 |
| DINOv2-OfficeHomeFull | FedAdapterManifold-Anchor-Expanded | Geo-only Agg | 0.0086 | 0.0005 | 0.0141 | 5 | 5 |
| DINOv2-OfficeHomeFull | FedAdapterManifold-Anchor-Expanded | Ditto-LoRA | 0.0093 | 0.0017 | 0.0148 | 5 | 5 |
| CLIP-OfficeHomeFull | FedAdapterManifold-Anchor-Expanded | FedAvg-LoRA | 0.0300 | 0.0166 | 0.0404 | 5 | 5 |
| CLIP-OfficeHomeFull | FedAdapterManifold-Anchor-Expanded | Geo-only Agg | 0.0100 | 0.0044 | 0.0162 | 5 | 5 |
| CLIP-OfficeHomeFull | FedAdapterManifold-Anchor-Expanded | Ditto-LoRA | 0.0036 | -0.0072 | 0.0122 | 4 | 4 |