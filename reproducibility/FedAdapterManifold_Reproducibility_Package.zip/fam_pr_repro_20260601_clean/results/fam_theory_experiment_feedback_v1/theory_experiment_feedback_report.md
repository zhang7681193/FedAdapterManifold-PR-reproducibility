# Theory-Experiment Feedback Audit

This pack converts the remaining reviewer risks into explicit experimental failure modes, a theory response, and a revised experiment/claim.

## Main Feedback Loop

| Dataset | Experimental problem | Theory response | Feedback to experiment | Paper claim |
|---|---|---|---|---|
| BloodMNIST | expanded_selector_resolves_personalized_ceiling; geometry ceiling: gain-vs-GeoAgg=0.0055, CI-low=-0.0009; mechanism=positive_but_moderate_subspace_mechanism, r=0.3441 | Geometry-ceiling corollary: when geometry aggregation is already strong, accuracy gaps may be small while conflict/risk diagnostics remain the relevant improvement target. | Report FedAvg repair and conflict/risk support; avoid claiming decisive improvement over Geometry-Agg. | Medical application with strong FedAvg repair and conflict support; Geometry-Agg accuracy gain is mixed. |
| DomainNetMini | personalized ceiling: hybrid-best=0.0000; mechanism=geometry_dominated_hard_case_with_positive_raw_subspace_signal, r=0.1932 | Multi-signal compatibility corollary: subspace conflict can be positive but not dominant; visual geometry can control routing in hard multi-domain regimes. | Keep the gain beyond Geometry-Agg as positive evidence. | Geometry-dominated hard case: supports multi-signal routing, not a subspace-only explanation. |
| OfficeCaltech | missing_hybrid_or_baseline; mechanism=positive_but_moderate_subspace_mechanism, r=0.2773 | Safe selection corollary: fixed candidate pools allow routing gains without test-set oracle selection. | Keep the gain beyond Geometry-Agg as positive evidence. | Safe routing improves beyond geometry-only control and strong baselines. |
| OfficeHomeFull | personalized ceiling: hybrid-best=0.0000; geometry ceiling: gain-vs-GeoAgg=0.0048, CI-low=0.0000; mechanism=strong_subspace_mechanism, r=0.7388 | Hybrid no-regret corollary: include the strong personalized branch and select against local calibration loss; the expected risk is bounded by the best pre-registered branch plus finite-sample error. | Use guarded Ditto-FAM as a no-regret audit: it matches Ditto-LoRA and prevents the expanded selector drop, but do not claim an extra accuracy win. | Strong mechanism plus no-regret composability with Ditto; not universal SOTA. |
| PACS | personalized ceiling: hybrid-best=0.0016; mechanism=positive_but_moderate_subspace_mechanism, r=0.3333 | Hybrid no-regret corollary: include the strong personalized branch and select against local calibration loss; the expected risk is bounded by the best pre-registered branch plus finite-sample error. | Use FedPer-FAM to resolve the FedPer ceiling in mean accuracy; report the paired interval as small/mixed rather than significant dominance. | Personalization/manifold composition resolves the main PACS benchmark caveat. |

## Hybrid No-Regret Paired Audit

| Dataset | Hybrid | Baseline | Units | Mean diff | CI low | CI high | Diagnosis |
|---|---|---|---:|---:|---:|---:|---|
| BloodMNIST | FedPer-FAM | Ditto-LoRA | 40 | -0.0017 | -0.0079 | 0.0049 | no_regret_or_tied_hybrid_gain |
| DomainNetMini | FedPer-FAM | FedPer-LoRA | 30 | 0.0000 | 0.0000 | 0.0000 | no_regret_or_tied_hybrid_gain |
| OfficeHomeFull | Ditto-FAM | Ditto-LoRA | 20 | 0.0000 | 0.0000 | 0.0000 | no_regret_or_tied_hybrid_gain |
| PACS | FedPer-FAM | FedPer-LoRA | 20 | 0.0016 | -0.0031 | 0.0063 | no_regret_or_tied_hybrid_gain |

## Geometry Ceiling Audit

| Dataset | Gain vs GeoAgg | CI low | Conflict reduction vs FedAvg | Diagnosis |
|---|---:|---:|---:|---|
| BloodMNIST | 0.0055 | -0.0009 | 0.9242 | geometry_ceiling_no_decisive_accuracy_gain |
| DomainNetMini | 0.0024 | 0.0003 | 1.2309 | accuracy_gain_beyond_geometry_control |
| OfficeCaltech | 0.0420 | 0.0172 | 0.5631 | accuracy_gain_beyond_geometry_control |
| OfficeHomeFull | 0.0048 | 0.0000 | 0.7876 | geometry_ceiling_no_decisive_accuracy_gain |
| PACS | 0.0475 | 0.0303 | 0.7234 | accuracy_gain_beyond_geometry_control |

## Mechanism Signal Audit

| Dataset | Adapter/failure r | CI low | Diagnosis |
|---|---:|---:|---|
| PACS | 0.3333 | 0.0974 | positive_but_moderate_subspace_mechanism |
| OfficeCaltech | 0.2773 | 0.0854 | positive_but_moderate_subspace_mechanism |
| OfficeHomeFull | 0.7388 | 0.6313 | strong_subspace_mechanism |
| DomainNetMini | 0.1932 | 0.0592 | geometry_dominated_hard_case_with_positive_raw_subspace_signal |
| BloodMNIST | 0.3441 | 0.2403 | positive_but_moderate_subspace_mechanism |
