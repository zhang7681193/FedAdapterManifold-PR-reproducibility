from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path
from typing import Iterable


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Aggregate completed federated CLIP ViT LoRA seed directories.")
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--seed-dir", action="append", default=[], help="Repeated mapping seed=path/to/seed_dir.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    seed_dirs = [_parse_seed_dir(value) for value in args.seed_dir]
    if not seed_dirs:
        raise ValueError("At least one --seed-dir seed=path is required.")

    runs: list[dict] = []
    metrics: list[dict] = []
    per_client: list[dict] = []
    subspace: list[dict] = []
    conflicts: list[dict] = []
    bank_weights: list[dict] = []
    selection: list[dict] = []
    for seed, seed_dir in seed_dirs:
        missing = [name for name in ["metrics.csv", "per_client_metrics.csv", "subspace_metrics.csv"] if not (seed_dir / name).exists()]
        if missing:
            raise FileNotFoundError(f"Seed {seed} is incomplete at {seed_dir}: missing {', '.join(missing)}")
        runs.append({"seed": seed, "output_dir": str(seed_dir), "exit_code": 0})
        for rows, name in [
            (metrics, "metrics.csv"),
            (per_client, "per_client_metrics.csv"),
            (subspace, "subspace_metrics.csv"),
            (conflicts, "adapter_conflict.csv"),
            (bank_weights, "adapter_bank_weights.csv"),
            (selection, "candidate_selection.csv"),
        ]:
            for row in read_csv(seed_dir / name):
                row["source_seed"] = seed
                rows.append(row)

    write_csv(output_root / "runs.csv", runs)
    write_csv(output_root / "multiseed_metrics.csv", aggregate_metrics(metrics))
    write_csv(output_root / "multiseed_per_client_metrics.csv", per_client)
    write_csv(output_root / "multiseed_subspace_metrics.csv", subspace)
    write_csv(output_root / "multiseed_adapter_conflict.csv", conflicts)
    write_csv(output_root / "multiseed_adapter_bank_weights.csv", bank_weights)
    write_csv(output_root / "multiseed_candidate_selection.csv", selection)
    write_csv(output_root / "paired_significance.csv", paired_significance(per_client))
    write_csv(output_root / "subspace_correlation_summary.csv", subspace_summary(subspace))
    write_report(output_root / "multiseed_report.md", output_root)
    return 0


def aggregate_metrics(rows: list[dict]) -> list[dict]:
    out: list[dict] = []
    methods = sorted({row.get("method", "") for row in rows if row.get("method")})
    for method in methods:
        group = [row for row in rows if row.get("method") == method]
        acc = [fnum(row.get("mean_accuracy")) for row in group]
        loss = [fnum(row.get("mean_loss")) for row in group]
        risk = [fnum(row.get("worst_client_risk")) for row in group]
        conflict = [fnum(row.get("mean_update_conflict_vs_local")) for row in group]
        first = group[0] if group else {}
        ci_low, ci_high = bootstrap_ci(acc)
        out.append(
            {
                "method": method,
                "mean_accuracy": mean(acc),
                "std_accuracy": std(acc),
                "ci_low_accuracy": ci_low,
                "ci_high_accuracy": ci_high,
                "mean_loss": mean(loss),
                "mean_worst_client_risk": mean(risk),
                "mean_update_conflict_vs_local": mean(conflict),
                "num_seeds": len({row.get("source_seed") for row in group}),
                "num_observations": len(group),
                "dataset": first.get("dataset", ""),
                "heterogeneity": first.get("heterogeneity", ""),
                "round": first.get("round", ""),
            }
        )
    return out


def paired_significance(rows: list[dict]) -> list[dict]:
    methods = sorted({row.get("method", "") for row in rows if row.get("method")})
    baselines = ["FedAvg-CLIP-LoRA", "FedGeo-Agg-CLIP-LoRA", "Local-CLIP-LoRA", "CLIP-ZeroShot"]
    by_key: dict[tuple[str, str], dict[str, float]] = {}
    for row in rows:
        key = (row.get("source_seed", row.get("seed", "")), row.get("client_id", ""))
        by_key.setdefault(key, {})
        by_key[key][row.get("method", "")] = fnum(row.get("accuracy"))
    out: list[dict] = []
    for method in methods:
        for baseline in baselines:
            if method == baseline:
                continue
            diffs = [
                vals[method] - vals[baseline]
                for vals in by_key.values()
                if method in vals and baseline in vals and math.isfinite(vals[method]) and math.isfinite(vals[baseline])
            ]
            if not diffs:
                continue
            ci_low, ci_high = bootstrap_ci(diffs)
            out.append(
                {
                    "method": method,
                    "baseline": baseline,
                    "paired_units": len(diffs),
                    "mean_accuracy_diff": mean(diffs),
                    "ci_low": ci_low,
                    "ci_high": ci_high,
                    "sign_flip_p_value": sign_flip_p_value(diffs),
                    "supports_positive_gain": bool(mean(diffs) > 0.0 and ci_low > 0.0),
                }
            )
    return out


def subspace_summary(rows: list[dict]) -> list[dict]:
    by_seed: dict[str, dict[str, float]] = {}
    for row in rows:
        seed = row.get("source_seed", row.get("seed", ""))
        by_seed.setdefault(seed, {})
        for key in ["subspace_failure_pearson_r", "geometry_failure_pearson_r"]:
            value = fnum(row.get(key))
            if math.isfinite(value):
                by_seed[seed][key] = value
    out: list[dict] = []
    for key in ["subspace_failure_pearson_r", "geometry_failure_pearson_r"]:
        values = [item[key] for item in by_seed.values() if key in item]
        ci_low, ci_high = bootstrap_ci(values)
        out.append(
            {
                "measure": key,
                "mean": mean(values),
                "std": std(values),
                "ci_low": ci_low,
                "ci_high": ci_high,
                "num_seeds": len(values),
                "positive_seed_count": sum(1 for value in values if value > 0),
            }
        )
    return out


def read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    if not fieldnames:
        fieldnames = ["empty"]
        rows = [{"empty": ""}]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_report(path: Path, output_root: Path) -> None:
    metrics = read_csv(output_root / "multiseed_metrics.csv")
    paired = read_csv(output_root / "paired_significance.csv")
    lines = [
        "# Federated CLIP ViT LoRA Multiseed Report",
        "",
        "| Method | Mean accuracy | CI low | CI high |",
        "|---|---:|---:|---:|",
    ]
    for row in sorted(metrics, key=lambda item: fnum(item.get("mean_accuracy")), reverse=True):
        lines.append(
            f"| {row.get('method','')} | {fnum(row.get('mean_accuracy')):.4f} | {fnum(row.get('ci_low_accuracy')):.4f} | {fnum(row.get('ci_high_accuracy')):.4f} |"
        )
    lines.extend(["", "## Key paired gains", "", "| Method | Baseline | Diff | CI low | Supports |", "|---|---|---:|---:|---|"])
    for row in paired:
        if row.get("method") == "FedAdapterManifold-Selective-CLIP-LoRA":
            lines.append(
                f"| {row.get('method','')} | {row.get('baseline','')} | {fnum(row.get('mean_accuracy_diff')):.4f} | {fnum(row.get('ci_low')):.4f} | {row.get('supports_positive_gain','')} |"
            )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def bootstrap_ci(values: Iterable[float], reps: int = 4000) -> tuple[float, float]:
    vals = [float(value) for value in values if math.isfinite(float(value))]
    if not vals:
        return float("nan"), float("nan")
    if len(vals) == 1:
        return vals[0], vals[0]
    rng = deterministic_rng(29 + len(vals))
    means: list[float] = []
    n = len(vals)
    for _ in range(reps):
        total = 0.0
        for _ in range(n):
            total += vals[int(next(rng) * n) % n]
        means.append(total / n)
    means.sort()
    return means[int(0.025 * reps)], means[int(0.975 * reps)]


def sign_flip_p_value(values: list[float], reps: int = 8192) -> float:
    if not values:
        return float("nan")
    observed = abs(mean(values))
    if len(values) <= 20:
        total = 1 << len(values)
        extreme = 0
        for mask in range(total):
            flipped = 0.0
            for idx, value in enumerate(values):
                flipped += value if (mask >> idx) & 1 else -value
            if abs(flipped / len(values)) >= observed - 1e-12:
                extreme += 1
        return extreme / total
    rng = deterministic_rng(913 + len(values))
    extreme = 0
    for _ in range(reps):
        flipped = sum(value if next(rng) >= 0.5 else -value for value in values)
        if abs(flipped / len(values)) >= observed - 1e-12:
            extreme += 1
    return extreme / reps


def deterministic_rng(seed: int):
    state = int(seed) & 0x7FFFFFFF
    while True:
        state = (1103515245 * state + 12345) & 0x7FFFFFFF
        yield state / 0x80000000


def mean(values: Iterable[float]) -> float:
    vals = [float(value) for value in values if math.isfinite(float(value))]
    return sum(vals) / len(vals) if vals else float("nan")


def std(values: Iterable[float]) -> float:
    vals = [float(value) for value in values if math.isfinite(float(value))]
    if len(vals) <= 1:
        return 0.0 if vals else float("nan")
    mu = mean(vals)
    return math.sqrt(sum((value - mu) ** 2 for value in vals) / (len(vals) - 1))


def fnum(value, default: float = float("nan")) -> float:
    try:
        if value in {"", None}:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _parse_seed_dir(value: str) -> tuple[int, Path]:
    if "=" not in value:
        raise ValueError(f"Invalid --seed-dir {value!r}; expected seed=path")
    seed, path = value.split("=", 1)
    return int(seed.strip()), Path(path.strip())


if __name__ == "__main__":
    raise SystemExit(main())
