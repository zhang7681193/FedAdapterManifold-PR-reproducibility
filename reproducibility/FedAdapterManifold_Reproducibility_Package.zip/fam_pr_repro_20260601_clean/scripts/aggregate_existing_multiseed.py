from __future__ import annotations

from pathlib import Path
import argparse
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.claims import build_multiseed_claim_report, core_claims_supported
from fedadaptermanifold.reporting import ensure_dir, write_csv
from scripts.run_fedgeo_multiseed import (
    _method_accuracy_summary,
    _paired_gain_stats,
    _paired_risk_reduction_stats,
    _pooled_distance_stats,
    _read_csv,
    _risk_summary,
)


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Aggregate already completed FedAdapterManifold seed directories.")
    parser.add_argument("--output-root", type=str, required=True)
    parser.add_argument(
        "--seed-dir",
        action="append",
        default=[],
        help="Repeated mapping seed=path/to/seed_dir. The seed dir must contain metrics.csv and related CSVs.",
    )
    parser.add_argument("--strict-support-exit", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    output_root = ensure_dir(args.output_root)
    seed_dirs = [_parse_seed_dir(value) for value in args.seed_dir]
    if not seed_dirs:
        raise ValueError("At least one --seed-dir seed=path mapping is required.")

    run_rows = []
    all_metrics: list[dict] = []
    all_per_client: list[dict] = []
    all_risk: list[dict] = []
    all_conflicts: list[dict] = []
    all_idea: list[dict] = []
    for seed, seed_dir in seed_dirs:
        missing = _missing_required(seed_dir)
        if missing:
            raise FileNotFoundError(f"Seed {seed} is incomplete at {seed_dir}: missing {', '.join(missing)}")
        run_rows.append({"seed": seed, "output_dir": str(seed_dir), "exit_code": 0})
        metrics = _read_csv(seed_dir / "metrics.csv")
        per_client = _read_csv(seed_dir / "per_client_metrics.csv")
        risk = _read_csv(seed_dir / "risk_metrics.csv")
        conflicts = _read_csv(seed_dir / "adapter_conflict.csv")
        idea = _read_csv(seed_dir / "idea_support.csv")
        for rows in [metrics, per_client, risk, conflicts, idea]:
            for row in rows:
                row["source_seed"] = seed
        all_metrics.extend(metrics)
        all_per_client.extend(per_client)
        all_risk.extend(risk)
        all_conflicts.extend(conflicts)
        all_idea.extend(idea)

    summary_rows = []
    summary_rows.extend(_method_accuracy_summary(all_metrics))
    summary_rows.extend(_risk_summary(all_risk))
    summary_rows.extend(_paired_risk_reduction_stats(all_risk, baseline="FedAvg-LoRA"))
    summary_rows.extend(_paired_risk_reduction_stats(all_risk, baseline="FedGeo-Agg"))
    summary_rows.extend(_pooled_distance_stats(all_conflicts))
    summary_rows.extend(_paired_gain_stats(all_per_client, baseline="FedAvg-LoRA"))
    summary_rows.extend(_paired_gain_stats(all_per_client, baseline="FedGeo-Agg"))
    claim_rows = build_multiseed_claim_report(summary_rows)

    write_csv(output_root / "runs.csv", run_rows)
    write_csv(output_root / "multiseed_metrics.csv", all_metrics)
    write_csv(output_root / "multiseed_per_client_metrics.csv", all_per_client)
    write_csv(output_root / "multiseed_risk_metrics.csv", all_risk)
    write_csv(output_root / "multiseed_adapter_conflict.csv", all_conflicts)
    write_csv(output_root / "multiseed_idea_support.csv", all_idea)
    write_csv(output_root / "multiseed_summary.csv", summary_rows)
    write_csv(output_root / "multiseed_claim_report.csv", claim_rows)
    if args.strict_support_exit:
        return 0 if core_claims_supported(claim_rows) else 2
    return 0


def _parse_seed_dir(value: str) -> tuple[int, Path]:
    if "=" not in value:
        raise ValueError(f"Invalid --seed-dir {value!r}; expected seed=path")
    seed_text, path_text = value.split("=", 1)
    return int(seed_text.strip()), Path(path_text.strip())


def _missing_required(seed_dir: Path) -> list[str]:
    required = [
        "metrics.csv",
        "per_client_metrics.csv",
        "risk_metrics.csv",
        "adapter_conflict.csv",
        "idea_support.csv",
    ]
    return [name for name in required if not (seed_dir / name).exists()]


if __name__ == "__main__":
    raise SystemExit(main())
