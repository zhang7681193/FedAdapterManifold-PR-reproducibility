from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv


REQUIRED_RESULT_FILES = [
    "config.yaml",
    "metrics.csv",
    "per_client_metrics.csv",
]

SHARED_LOG_FIELDS = ["method", "seed", "dataset", "heterogeneity_setting", "round"]
MAIN_MANIFOLD_SIGNALS = ["d_geo", "geometry_graph", "prototypes"]
AUXILIARY_RISK_SIGNALS = ["risk_geo_score", "feature_energy_deficit"]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Audit FedAdapterManifold shared protocol compliance.")
    parser.add_argument(
        "--run",
        action="append",
        default=[],
        help="Repeated spec: dataset|result_dir. The result dir can be a single-seed or multiseed directory.",
    )
    parser.add_argument("--output-dir", type=str, default="results/fedadaptermanifold_protocol_audit")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    if not args.run:
        raise ValueError("At least one --run dataset|result_dir is required")
    output_dir = ensure_dir(args.output_dir)

    rows: list[dict] = []
    for spec in args.run:
        dataset, result_dir = _parse_run(spec)
        rows.extend(_audit_result_dir(dataset, Path(result_dir)))

    summary_rows = _summary_rows(rows)
    write_csv(output_dir / "protocol_audit.csv", rows)
    write_csv(output_dir / "protocol_audit_summary.csv", summary_rows)
    _write_markdown(output_dir / "protocol_audit.md", rows, summary_rows)
    return 0 if all(row["status"] != "fail" for row in rows) else 2


def _parse_run(spec: str) -> tuple[str, str]:
    parts = [part.strip() for part in spec.split("|")]
    if len(parts) != 2:
        raise ValueError(f"Expected dataset|result_dir, got: {spec}")
    return parts[0], parts[1]


def _audit_result_dir(dataset: str, result_dir: Path) -> list[dict]:
    rows: list[dict] = []
    seed_dirs = _seed_dirs(result_dir)
    rows.append(
        _row(
            dataset,
            str(result_dir),
            "result_dir_discovery",
            "pass" if seed_dirs else "fail",
            len(seed_dirs),
            "Discovered seed result directories.",
        )
    )
    for seed_dir in seed_dirs:
        rows.extend(_audit_seed_dir(dataset, seed_dir))
    rows.extend(_audit_multiseed_dir(dataset, result_dir))
    return rows


def _seed_dirs(result_dir: Path) -> list[Path]:
    if (result_dir / "metrics.csv").exists():
        return [result_dir]
    run_rows = _read_csv(result_dir / "runs.csv")
    dirs = []
    for row in run_rows:
        if str(row.get("exit_code", "0")) not in {"", "0"}:
            continue
        output_dir = row.get("output_dir", "")
        if not output_dir:
            continue
        path = Path(output_dir)
        if not path.exists():
            candidate = result_dir / output_dir
            path = candidate if candidate.exists() else path
        if (path / "metrics.csv").exists():
            dirs.append(path)
    if dirs:
        return dirs
    return [path.parent for path in sorted(result_dir.glob("seed_*/metrics.csv"))]


def _audit_seed_dir(dataset: str, seed_dir: Path) -> list[dict]:
    rows: list[dict] = []
    for filename in REQUIRED_RESULT_FILES:
        rows.append(
            _row(
                dataset,
                str(seed_dir),
                f"required_file:{filename}",
                "pass" if (seed_dir / filename).exists() else "fail",
                filename,
                "Required shared project artifact.",
            )
        )
    rows.extend(_audit_csv_fields(dataset, seed_dir, "metrics.csv", SHARED_LOG_FIELDS))
    rows.extend(_audit_csv_fields(dataset, seed_dir, "per_client_metrics.csv", SHARED_LOG_FIELDS + ["client_id"]))
    rows.extend(_audit_geometry_roles(dataset, seed_dir))
    rows.extend(_audit_per_client_signal_usage(dataset, seed_dir))
    rows.extend(_audit_config(dataset, seed_dir))
    return rows


def _audit_multiseed_dir(dataset: str, result_dir: Path) -> list[dict]:
    rows: list[dict] = []
    if not (result_dir / "multiseed_metrics.csv").exists() and not (result_dir / "runs.csv").exists():
        return rows
    for filename in ["runs.csv", "multiseed_metrics.csv", "multiseed_per_client_metrics.csv"]:
        if (result_dir / filename).exists():
            status = "pass"
        elif filename == "runs.csv":
            status = "warn"
        else:
            status = "fail"
        rows.append(
            _row(
                dataset,
                str(result_dir),
                f"multiseed_file:{filename}",
                status,
                filename,
                "Required or recommended multiseed aggregate artifact.",
            )
        )
    rows.extend(_audit_csv_fields(dataset, result_dir, "multiseed_metrics.csv", SHARED_LOG_FIELDS, required=False))
    rows.extend(
        _audit_csv_fields(
            dataset,
            result_dir,
            "multiseed_per_client_metrics.csv",
            SHARED_LOG_FIELDS + ["client_id"],
            required=False,
        )
    )
    return rows


def _audit_csv_fields(
    dataset: str,
    root: Path,
    filename: str,
    required_fields: list[str],
    required: bool = True,
) -> list[dict]:
    path = root / filename
    if not path.exists():
        return [
            _row(
                dataset,
                str(root),
                f"csv_fields:{filename}",
                "fail" if required else "warn",
                "",
                f"{filename} is missing.",
            )
        ]
    header = _csv_header(path)
    rows = []
    for field in required_fields:
        rows.append(
            _row(
                dataset,
                str(root),
                f"csv_field:{filename}:{field}",
                "pass" if field in header else "fail",
                field,
                "Shared logging field.",
            )
        )
    return rows


def _audit_geometry_roles(dataset: str, seed_dir: Path) -> list[dict]:
    path = seed_dir / "geometry_signal_roles.csv"
    if not path.exists():
        return [
            _row(
                dataset,
                str(seed_dir),
                "geometry_roles:file",
                "fail",
                "",
                "geometry_signal_roles.csv must document manifold vs auxiliary signals.",
            )
        ]
    rows = _read_csv(path)
    by_signal = {row.get("signal", ""): row for row in rows}
    out = []
    for signal in MAIN_MANIFOLD_SIGNALS:
        row = by_signal.get(signal)
        ok = row is not None and _truthy(row.get("is_main_manifold"))
        out.append(
            _row(
                dataset,
                str(seed_dir),
                f"geometry_roles:main:{signal}",
                "pass" if ok else "fail",
                row.get("role", "") if row else "",
                "FedGeo manifold signal must be marked as main.",
            )
        )
    for signal in AUXILIARY_RISK_SIGNALS:
        row = by_signal.get(signal)
        if row is None:
            out.append(
                _row(
                    dataset,
                    str(seed_dir),
                    f"geometry_roles:auxiliary:{signal}",
                    "warn",
                    "missing",
                    "Auxiliary risk signal is optional.",
                )
            )
            continue
        ok = not _truthy(row.get("is_main_manifold")) and "auxiliary" in str(row.get("role", "")).lower()
        out.append(
            _row(
                dataset,
                str(seed_dir),
                f"geometry_roles:auxiliary:{signal}",
                "pass" if ok else "fail",
                row.get("role", ""),
                "Risk/reliability signal must not replace d_geo as the adapter manifold.",
            )
        )
    return out


def _audit_per_client_signal_usage(dataset: str, seed_dir: Path) -> list[dict]:
    path = seed_dir / "per_client_metrics.csv"
    if not path.exists():
        return []
    rows = _read_csv(path)
    manifold_values = {row.get("geometry_signal_for_manifold", "") for row in rows if "geometry_signal_for_manifold" in row}
    risk_values = {row.get("risk_signal_usage", "") for row in rows if "risk_signal_usage" in row}
    return [
        _row(
            dataset,
            str(seed_dir),
            "per_client:geometry_signal_for_manifold",
            "pass" if manifold_values == {"d_geo+geometry_graph"} else "fail",
            ";".join(sorted(manifold_values)),
            "Per-client rows should record d_geo+geometry_graph as the manifold signal.",
        ),
        _row(
            dataset,
            str(seed_dir),
            "per_client:risk_signal_usage",
            "pass" if risk_values == {"auxiliary_prior_only"} else "fail",
            ";".join(sorted(risk_values)),
            "Risk signals should be logged as auxiliary priors only.",
        ),
    ]


def _audit_config(dataset: str, seed_dir: Path) -> list[dict]:
    path = seed_dir / "config.yaml"
    if not path.exists():
        return []
    text = path.read_text(encoding="utf-8", errors="replace")
    checks = [
        ("config:geometry_outputs_dir", "geometry_outputs_dir:"),
        ("config:round_id", "round_id:"),
        ("config:dataset", "dataset:"),
        ("config:heterogeneity_setting", "heterogeneity_setting:"),
    ]
    return [
        _row(
            dataset,
            str(seed_dir),
            name,
            "pass" if token in text else "fail",
            token,
            "Required YAML config entry.",
        )
        for name, token in checks
    ]


def _summary_rows(rows: list[dict]) -> list[dict]:
    by_dataset: dict[str, list[dict]] = {}
    for row in rows:
        by_dataset.setdefault(row["dataset"], []).append(row)
    summary = []
    for dataset, dataset_rows in sorted(by_dataset.items()):
        counts = {status: sum(1 for row in dataset_rows if row["status"] == status) for status in ["pass", "warn", "fail"]}
        summary.append(
            {
                "dataset": dataset,
                "pass": counts["pass"],
                "warn": counts["warn"],
                "fail": counts["fail"],
                "overall_status": "fail" if counts["fail"] else ("warn" if counts["warn"] else "pass"),
            }
        )
    return summary


def _csv_header(path: Path) -> list[str]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.reader(handle)
        return next(reader, [])


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def _truthy(value) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes"}


def _row(dataset: str, path: str, check: str, status: str, value, details: str) -> dict:
    return {
        "dataset": dataset,
        "path": path,
        "check": check,
        "status": status,
        "value": value,
        "details": details,
    }


def _write_markdown(path: Path, rows: list[dict], summary_rows: list[dict]) -> None:
    lines = [
        "# FedAdapterManifold Protocol Audit",
        "",
        "| Dataset | Pass | Warn | Fail | Overall |",
        "|---|---:|---:|---:|---|",
    ]
    for row in summary_rows:
        lines.append(
            "| {dataset} | {passed} | {warn} | {fail} | {overall} |".format(
                dataset=row["dataset"],
                passed=row["pass"],
                warn=row["warn"],
                fail=row["fail"],
                overall=row["overall_status"],
            )
        )
    failing = [row for row in rows if row["status"] in {"fail", "warn"}]
    if failing:
        lines.extend(["", "## Warnings And Failures", "", "| Dataset | Check | Status | Value | Details |", "|---|---|---|---|---|"])
        for row in failing:
            lines.append(
                "| {dataset} | {check} | {status} | {value} | {details} |".format(
                    dataset=row["dataset"],
                    check=row["check"],
                    status=row["status"],
                    value=str(row["value"]).replace("|", "/"),
                    details=row["details"].replace("|", "/"),
                )
            )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
