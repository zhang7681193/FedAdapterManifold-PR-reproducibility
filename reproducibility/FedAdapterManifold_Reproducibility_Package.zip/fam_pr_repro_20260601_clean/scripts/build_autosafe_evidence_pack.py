from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv


METHOD = "FedAdapterManifold"
BASELINES = ["FedAvg-LoRA", "FedGeo-Agg"]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build paper-facing evidence tables for the auto-safe FedAdapterManifold configuration."
    )
    parser.add_argument(
        "--run",
        action="append",
        default=[],
        help="Repeated spec: dataset|result_dir|num_classes",
    )
    parser.add_argument("--output-dir", type=str, default="results/fedadaptermanifold_autosafe_evidence_pack")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    runs = [_parse_run(spec) for spec in args.run]
    if not runs:
        raise ValueError("At least one --run dataset|result_dir|num_classes is required")
    output_dir = ensure_dir(args.output_dir)

    main_rows: list[dict] = []
    risk_rows: list[dict] = []
    per_client_rows: list[dict] = []
    gate_rows: list[dict] = []
    for run in runs:
        result_dir = Path(run["result_dir"])
        summary = _read_csv(result_dir / "multiseed_summary.csv")
        claims = _read_csv(result_dir / "multiseed_claim_report.csv")
        risk = _read_csv(result_dir / "multiseed_risk_metrics.csv")
        per_client = _read_csv(result_dir / "multiseed_per_client_metrics.csv")
        main_rows.append(_main_row(run, summary, claims, per_client))
        risk_rows.extend(_risk_rows(run, summary, risk))
        per_client_rows.extend(_per_client_gain_rows(run, per_client))
        gate_rows.extend(_gate_rows(run))

    write_csv(output_dir / "autosafe_main_results.csv", main_rows)
    write_csv(output_dir / "autosafe_risk_results.csv", risk_rows)
    write_csv(output_dir / "autosafe_per_client_gains.csv", per_client_rows)
    write_csv(output_dir / "autosafe_gate_summary.csv", gate_rows)
    _write_markdown(output_dir / "autosafe_paper_table.md", main_rows, risk_rows, per_client_rows, gate_rows)
    return 0


def _parse_run(spec: str) -> dict:
    parts = [part.strip() for part in spec.split("|")]
    if len(parts) != 3:
        raise ValueError(f"Expected dataset|result_dir|num_classes, got: {spec}")
    return {"dataset": parts[0], "result_dir": parts[1], "num_classes": int(parts[2])}


def _main_row(run: dict, summary: list[dict], claims: list[dict], per_client: list[dict]) -> dict:
    num_classes = int(run["num_classes"])
    chance = 1.0 / float(num_classes)
    local = _summary(summary, "method_accuracy", "Local-LoRA", "", "mean_accuracy")
    fedavg = _summary(summary, "method_accuracy", "FedAvg-LoRA", "", "mean_accuracy")
    fedgeo = _summary(summary, "method_accuracy", "FedGeo-Agg", "", "mean_accuracy")
    current = _summary(summary, "method_accuracy", METHOD, "", "mean_accuracy")
    local_gap = max(local - chance, 1e-12)
    fedavg_gap = max(local - fedavg, 1e-12)
    fedgeo_gap = max(local - fedgeo, 1e-12)
    return {
        "dataset": run["dataset"],
        "num_classes": num_classes,
        "chance_accuracy": chance,
        "local_lora_accuracy": local,
        "fedavg_lora_accuracy": fedavg,
        "fedgeo_agg_accuracy": fedgeo,
        "fedadapter_accuracy": current,
        "gain_vs_fedavg": _claim(claims, "adapter_bank_gain_vs_fedavg"),
        "gain_vs_fedavg_ci_low": _claim(claims, "adapter_bank_gain_vs_fedavg", "ci_low"),
        "gain_vs_fedgeo_agg": _claim(claims, "adapter_bank_gain_vs_fedgeo_agg"),
        "gain_vs_fedgeo_agg_ci_low": _claim(claims, "adapter_bank_gain_vs_fedgeo_agg", "ci_low"),
        "adapter_incompatibility_failure_r": _claim(claims, "adapter_incompatibility_failure_correlation"),
        "adapter_incompatibility_failure_ci_low": _claim(
            claims, "adapter_incompatibility_failure_correlation", "ci_low"
        ),
        "raw_adapter_incompatibility_failure_r": _claim(
            claims, "raw_adapter_incompatibility_directional_failure_correlation"
        ),
        "fedavg_to_local_gap_closed": (current - fedavg) / fedavg_gap,
        "fedgeo_to_local_gap_closed": (current - fedgeo) / fedgeo_gap,
        "local_ceiling_recovery": (current - chance) / local_gap,
        "win_rate_vs_fedavg": _win_rate(per_client, METHOD, "FedAvg-LoRA"),
        "win_rate_vs_fedgeo_agg": _win_rate(per_client, METHOD, "FedGeo-Agg"),
        "result_dir": run["result_dir"],
    }


def _risk_rows(run: dict, summary: list[dict], risk_rows: list[dict]) -> list[dict]:
    rows = []
    for method in ["FedAvg-LoRA", "FedGeo-Agg", METHOD]:
        rows.append(
            {
                "dataset": run["dataset"],
                "method": method,
                "worst_client_risk": _summary(summary, "risk", method, "", "worst_client_risk"),
                "mean_client_drift_vs_local": _summary(summary, "risk", method, "", "mean_client_drift_vs_local"),
                "mean_update_conflict_vs_local": _summary(summary, "risk", method, "", "mean_update_conflict_vs_local"),
                "mean_graph_neighbor_update_conflict": _summary(
                    summary, "risk", method, "", "mean_graph_neighbor_update_conflict"
                ),
            }
        )
    for baseline in BASELINES:
        rows.append(
            {
                "dataset": run["dataset"],
                "method": METHOD,
                "baseline": baseline,
                "worst_client_risk_reduction": _summary(
                    summary, "paired_risk_reduction", METHOD, baseline, "worst_client_risk"
                ),
                "client_drift_reduction": _summary(
                    summary, "paired_risk_reduction", METHOD, baseline, "mean_client_drift_vs_local"
                ),
                "update_conflict_reduction": _summary(
                    summary, "paired_risk_reduction", METHOD, baseline, "mean_update_conflict_vs_local"
                ),
                "graph_neighbor_conflict_reduction": _summary(
                    summary, "paired_risk_reduction", METHOD, baseline, "mean_graph_neighbor_update_conflict"
                ),
                "update_conflict_reduction_percent": _risk_reduction_percent(
                    risk_rows, METHOD, baseline, "mean_update_conflict_vs_local"
                ),
            }
        )
    return rows


def _per_client_gain_rows(run: dict, rows: list[dict]) -> list[dict]:
    out = []
    for baseline in BASELINES:
        units = _unit_accuracy(rows, METHOD, baseline)
        by_domain: dict[str, list[float]] = {}
        for unit in units:
            by_domain.setdefault(unit["domain"], []).append(unit["diff"])
        for domain, diffs in sorted(by_domain.items()):
            arr = np.asarray(diffs, dtype=np.float64)
            out.append(
                {
                    "dataset": run["dataset"],
                    "domain": domain,
                    "method": METHOD,
                    "baseline": baseline,
                    "num_client_seed_units": int(arr.size),
                    "mean_accuracy_gain": float(arr.mean()) if arr.size else float("nan"),
                    "min_accuracy_gain": float(arr.min()) if arr.size else float("nan"),
                    "max_accuracy_gain": float(arr.max()) if arr.size else float("nan"),
                    "wins": int(np.sum(arr > 1e-12)),
                    "ties": int(np.sum(np.abs(arr) <= 1e-12)),
                    "losses": int(np.sum(arr < -1e-12)),
                    "win_rate": float(np.mean(arr > 1e-12)) if arr.size else float("nan"),
                }
            )
    return out


def _gate_rows(run: dict) -> list[dict]:
    result_dir = Path(run["result_dir"])
    run_rows = _read_csv(result_dir / "runs.csv")
    out = []
    for run_row in run_rows:
        seed = str(run_row.get("seed", ""))
        seed_dir = Path(run_row.get("output_dir", ""))
        if not seed_dir.is_absolute():
            seed_dir = ROOT / seed_dir
        weight_rows = _read_csv(seed_dir / "adapter_bank_weights.csv")
        sample_rows = _read_csv(seed_dir / "adapter_bank_sample_routing.csv")
        seen_clients = set()
        for row in weight_rows:
            client_id = row.get("client_id", "")
            if client_id in seen_clients:
                continue
            seen_clients.add(client_id)
            out.append(
                {
                    "dataset": run["dataset"],
                    "seed": seed,
                    "client_id": client_id,
                    "domain": row.get("domain", ""),
                    "personal_weight": _to_float(row.get("personal_weight", "")),
                    "personal_weight_policy": row.get("personal_weight_policy", ""),
                    "client_smoothing_weight": _to_float(row.get("client_smoothing_weight", "")),
                    "smoothing_policy": row.get("smoothing_policy", ""),
                    "selected_routing_mode": row.get("selected_routing_mode", ""),
                    "safe_smoothing_fallback": _safe_fallback_for_client(sample_rows, client_id),
                }
            )
    return out


def _safe_fallback_for_client(rows: list[dict], client_id: str) -> str:
    for row in rows:
        if row.get("client_id") == client_id and row.get("safe_smoothing_fallback", "") != "":
            return row.get("safe_smoothing_fallback", "")
    return ""


def _unit_accuracy(rows: list[dict], method: str, baseline: str) -> list[dict]:
    by_unit: dict[tuple[str, str], dict[str, dict]] = {}
    for row in rows:
        if row.get("accuracy", "") == "":
            continue
        unit = (str(row.get("source_seed", row.get("seed", ""))), str(row.get("client_id", "")))
        by_unit.setdefault(unit, {})[row.get("method", "")] = row
    out = []
    for (_seed, _client), values in by_unit.items():
        if method not in values or baseline not in values:
            continue
        current = values[method]
        base = values[baseline]
        out.append(
            {
                "domain": current.get("domain", ""),
                "diff": float(current["accuracy"]) - float(base["accuracy"]),
            }
        )
    return out


def _win_rate(rows: list[dict], method: str, baseline: str) -> float:
    units = _unit_accuracy(rows, method, baseline)
    if not units:
        return float("nan")
    diffs = np.asarray([unit["diff"] for unit in units], dtype=np.float64)
    return float(np.mean(diffs > 1e-12))


def _risk_reduction_percent(rows: list[dict], method: str, baseline: str, measure: str) -> float:
    by_key = {
        (row.get("method", ""), str(row.get("source_seed", row.get("seed", "")))): row
        for row in rows
    }
    values = []
    for (row_method, seed), current in by_key.items():
        if row_method != method:
            continue
        base = by_key.get((baseline, seed))
        if base is None:
            continue
        base_value = _to_float(base.get(measure, ""))
        current_value = _to_float(current.get(measure, ""))
        if np.isfinite(base_value) and abs(base_value) > 1e-12 and np.isfinite(current_value):
            values.append((base_value - current_value) / base_value)
    return float(np.mean(values)) if values else float("nan")


def _summary(
    rows: list[dict],
    test: str,
    method: str,
    baseline: str,
    measure: str,
    field: str = "estimate",
) -> float:
    for row in rows:
        if row.get("test", "") != test:
            continue
        if method and row.get("method", "") != method:
            continue
        if baseline and row.get("baseline", "") != baseline:
            continue
        if measure and row.get("measure", "") != measure:
            continue
        return _to_float(row.get(field, ""))
    return float("nan")


def _claim(rows: list[dict], claim_id: str, field: str = "estimate") -> float:
    for row in rows:
        if row.get("claim_id", "") == claim_id:
            return _to_float(row.get(field, ""))
    return float("nan")


def _to_float(value) -> float:
    try:
        if value in {"", None}:
            return float("nan")
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _write_markdown(path: Path, main_rows: list[dict], risk_rows: list[dict], gain_rows: list[dict], gate_rows: list[dict]) -> None:
    lines = [
        "# FedAdapterManifold Auto-Safe Evidence",
        "",
        "Auto-safe uses uncertainty-constrained personalization plus safe-cluster-loss-constrained smoothing.",
        "",
        "## Main Results",
        "",
        "| Dataset | Local | FedAvg | FedGeo-Agg | FedAdapter | Gain vs FedAvg | Gain vs FedGeo | Adapter-Failure r |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in main_rows:
        lines.append(
            "| {dataset} | {local} | {fedavg} | {fedgeo} | {current} | {gain_avg} | {gain_geo} | {corr} |".format(
                dataset=row["dataset"],
                local=_fmt(row["local_lora_accuracy"]),
                fedavg=_fmt(row["fedavg_lora_accuracy"]),
                fedgeo=_fmt(row["fedgeo_agg_accuracy"]),
                current=_fmt(row["fedadapter_accuracy"]),
                gain_avg=_fmt(row["gain_vs_fedavg"]),
                gain_geo=_fmt(row["gain_vs_fedgeo_agg"]),
                corr=_fmt(row["adapter_incompatibility_failure_r"]),
            )
        )
    lines.extend(["", "## Risk And Conflict", ""])
    lines.append("| Dataset | Baseline | Worst-Risk Reduction | Drift Reduction | Update-Conflict Reduction | Conflict Reduction % |")
    lines.append("|---|---|---:|---:|---:|---:|")
    for row in risk_rows:
        if row.get("baseline", "") == "":
            continue
        lines.append(
            "| {dataset} | {baseline} | {risk} | {drift} | {conflict} | {pct} |".format(
                dataset=row["dataset"],
                baseline=row["baseline"],
                risk=_fmt(row.get("worst_client_risk_reduction")),
                drift=_fmt(row.get("client_drift_reduction")),
                conflict=_fmt(row.get("update_conflict_reduction")),
                pct=_fmt(row.get("update_conflict_reduction_percent")),
            )
        )
    lines.extend(["", "## Gate Summary", ""])
    lines.append("| Dataset | Mean Personal | Mean Smoothing | Safe Fallback Rate |")
    lines.append("|---|---:|---:|---:|")
    for dataset in sorted({row["dataset"] for row in gate_rows}):
        subset = [row for row in gate_rows if row["dataset"] == dataset]
        personal = np.asarray([_to_float(row["personal_weight"]) for row in subset], dtype=np.float64)
        smoothing = np.asarray([_to_float(row["client_smoothing_weight"]) for row in subset], dtype=np.float64)
        fallback = np.asarray([str(row.get("safe_smoothing_fallback", "")).lower() == "true" for row in subset])
        lines.append(
            f"| {dataset} | {_fmt(np.nanmean(personal))} | {_fmt(np.nanmean(smoothing))} | {_fmt(np.mean(fallback))} |"
        )
    ensure_dir(path.parent)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _fmt(value) -> str:
    value = _to_float(value)
    if not np.isfinite(value):
        return ""
    return f"{value:.4f}"


if __name__ == "__main__":
    raise SystemExit(main())
