from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv


METHOD = "FedAdapterManifold"


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Compare global safe fallback with cluster-local safe smoothing.")
    parser.add_argument(
        "--pair",
        action="append",
        default=[],
        help=(
            "Repeated spec: dataset|global_safe_dir|cluster_safe_dir, optionally "
            "dataset|global_safe_dir|cluster_safe_dir|global_gate_dirs|cluster_gate_dirs. "
            "Multiple gate dirs can be joined with '+'."
        ),
    )
    parser.add_argument("--output-dir", type=str, default="results/cluster_safe_ablation")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    if not args.pair:
        raise ValueError("At least one --pair dataset|global_safe_dir|cluster_safe_dir is required")
    output_dir = ensure_dir(args.output_dir)
    rows = []
    for spec in args.pair:
        dataset, global_dir, cluster_dir, global_gate_dirs, cluster_gate_dirs = _parse_pair(spec)
        rows.append(
            _compare_pair(
                dataset,
                Path(global_dir),
                Path(cluster_dir),
                [Path(path) for path in global_gate_dirs],
                [Path(path) for path in cluster_gate_dirs],
            )
        )
    write_csv(output_dir / "cluster_safe_ablation.csv", rows)
    _write_markdown(output_dir / "cluster_safe_ablation.md", rows)
    return 0


def _parse_pair(spec: str) -> tuple[str, str, str, list[str], list[str]]:
    parts = [part.strip() for part in spec.split("|")]
    if len(parts) not in {3, 5}:
        raise ValueError(
            "Expected dataset|global_safe_dir|cluster_safe_dir or "
            f"dataset|global_safe_dir|cluster_safe_dir|global_gate_dirs|cluster_gate_dirs, got: {spec}"
        )
    if len(parts) == 3:
        return parts[0], parts[1], parts[2], [parts[1]], [parts[2]]
    return parts[0], parts[1], parts[2], _split_dirs(parts[3]), _split_dirs(parts[4])


def _split_dirs(spec: str) -> list[str]:
    return [part.strip() for part in spec.split("+") if part.strip()]


def _compare_pair(
    dataset: str,
    global_dir: Path,
    cluster_dir: Path,
    global_gate_dirs: list[Path],
    cluster_gate_dirs: list[Path],
) -> dict:
    global_summary = _read_csv(global_dir / "multiseed_summary.csv")
    cluster_summary = _read_csv(cluster_dir / "multiseed_summary.csv")
    global_claims = _read_csv(global_dir / "multiseed_claim_report.csv")
    cluster_claims = _read_csv(cluster_dir / "multiseed_claim_report.csv")
    global_gates = _gate_stats(global_gate_dirs)
    cluster_gates = _gate_stats(cluster_gate_dirs)

    global_acc = _method_accuracy(global_summary, METHOD)
    cluster_acc = _method_accuracy(cluster_summary, METHOD)
    global_fedgeo = _method_accuracy(global_summary, "FedGeo-Agg")
    cluster_fedgeo = _method_accuracy(cluster_summary, "FedGeo-Agg")
    global_gain = _claim(global_claims, "adapter_bank_gain_vs_fedgeo_agg")
    cluster_gain = _claim(cluster_claims, "adapter_bank_gain_vs_fedgeo_agg")
    global_conflict = _claim(global_claims, "update_conflict_reduction_vs_fedgeo_agg")
    cluster_conflict = _claim(cluster_claims, "update_conflict_reduction_vs_fedgeo_agg")

    return {
        "dataset": dataset,
        "global_safe_dir": str(global_dir),
        "cluster_safe_dir": str(cluster_dir),
        "global_fedadapter_accuracy": global_acc,
        "cluster_safe_fedadapter_accuracy": cluster_acc,
        "fedadapter_accuracy_delta": cluster_acc - global_acc,
        "global_fedgeo_agg_accuracy": global_fedgeo,
        "cluster_safe_fedgeo_agg_accuracy": cluster_fedgeo,
        "global_gain_vs_fedgeo_agg": global_gain,
        "cluster_safe_gain_vs_fedgeo_agg": cluster_gain,
        "gain_vs_fedgeo_delta": cluster_gain - global_gain,
        "global_conflict_reduction_vs_fedgeo_agg": global_conflict,
        "cluster_safe_conflict_reduction_vs_fedgeo_agg": cluster_conflict,
        "conflict_reduction_delta": cluster_conflict - global_conflict,
        "global_mean_smoothing_weight": global_gates["mean_smoothing_weight"],
        "cluster_safe_mean_smoothing_weight": cluster_gates["mean_smoothing_weight"],
        "mean_smoothing_delta": cluster_gates["mean_smoothing_weight"] - global_gates["mean_smoothing_weight"],
        "global_safe_fallback_rate": global_gates["safe_fallback_rate"],
        "cluster_safe_fallback_rate": cluster_gates["safe_fallback_rate"],
        "safe_fallback_rate_delta": cluster_gates["safe_fallback_rate"] - global_gates["safe_fallback_rate"],
        "global_active_graph_rate": global_gates["active_graph_rate"],
        "cluster_safe_active_graph_rate": cluster_gates["active_graph_rate"],
        "active_graph_rate_delta": cluster_gates["active_graph_rate"] - global_gates["active_graph_rate"],
        "interpretation": _interpret(cluster_gain - global_gain, cluster_conflict - global_conflict, cluster_gates["active_graph_rate"] - global_gates["active_graph_rate"]),
    }


def _gate_stats(result_dirs: list[Path]) -> dict:
    rows = []
    for result_dir in result_dirs:
        for path in sorted(result_dir.glob("seed_*/adapter_bank_sample_routing.csv")):
            seed_rows = _read_csv(path)
            smoothing_rows = [row for row in seed_rows if row.get("selected_smoothing_weight", "") not in {"", None}]
            selected_rows = [row for row in smoothing_rows if str(row.get("selected", "")).lower() == "true"]
            if selected_rows:
                smoothing_rows = selected_rows
            rows.extend(smoothing_rows)
    if not rows:
        for result_dir in result_dirs:
            for path in sorted(result_dir.glob("seed_*/adapter_bank_weights.csv")):
                weight_rows = _read_csv(path)
                seen = set()
                for row in weight_rows:
                    key = (path.parent.name, row.get("client_id", ""))
                    if key in seen:
                        continue
                    seen.add(key)
                    rows.append(
                        {
                            "selected_smoothing_weight": row.get("client_smoothing_weight", ""),
                            "safe_smoothing_fallback": "",
                        }
                    )
    weights = np.asarray([_float(row.get("selected_smoothing_weight")) for row in rows], dtype=np.float64)
    weights = weights[np.isfinite(weights)]
    fallback = [str(row.get("safe_smoothing_fallback", "")).lower() == "true" for row in rows]
    return {
        "num_gate_rows": int(len(rows)),
        "mean_smoothing_weight": float(weights.mean()) if weights.size else float("nan"),
        "safe_fallback_rate": float(np.mean(fallback)) if fallback else float("nan"),
        "active_graph_rate": float(np.mean(weights < 1.0 - 1e-12)) if weights.size else float("nan"),
    }


def _method_accuracy(rows: list[dict], method: str) -> float:
    for row in rows:
        if row.get("test") == "method_accuracy" and row.get("method") == method:
            return _float(row.get("estimate"))
    return float("nan")


def _claim(rows: list[dict], claim_id: str) -> float:
    for row in rows:
        if row.get("claim_id") == claim_id:
            return _float(row.get("estimate"))
    return float("nan")


def _interpret(gain_delta: float, conflict_delta: float, active_delta: float) -> str:
    if active_delta > 1e-12 and gain_delta > 0.0 and conflict_delta > 0.0:
        return "improves_accuracy_conflict_and_active_sharing"
    if active_delta > 1e-12 and conflict_delta > 0.0:
        return "improves_conflict_and_active_sharing"
    if active_delta > 1e-12 and gain_delta >= -1e-3:
        return "more_active_with_near_no_regret_accuracy"
    if gain_delta < 0.0:
        return "accuracy_tradeoff"
    return "neutral"


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def _float(value) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _write_markdown(path: Path, rows: list[dict]) -> None:
    lines = [
        "# Cluster-Local Safe Smoothing Ablation",
        "",
        "This table compares the previous global safe fallback with the cluster-local safe gate under matched settings. Positive active-graph deltas mean fewer clients are collapsed to the FedGeo-Agg endpoint.",
        "",
        "| Dataset | Acc Delta | Gain-vs-FedGeo Delta | Conflict Delta | Fallback Rate Delta | Active Graph Delta | Interpretation |",
        "|---|---:|---:|---:|---:|---:|---|",
    ]
    for row in rows:
        lines.append(
            "| {dataset} | {acc} | {gain} | {conflict} | {fallback} | {active} | {interp} |".format(
                dataset=row["dataset"],
                acc=_fmt(row["fedadapter_accuracy_delta"]),
                gain=_fmt(row["gain_vs_fedgeo_delta"]),
                conflict=_fmt(row["conflict_reduction_delta"]),
                fallback=_fmt(row["safe_fallback_rate_delta"]),
                active=_fmt(row["active_graph_rate_delta"]),
                interp=row["interpretation"],
            )
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _fmt(value) -> str:
    try:
        return f"{float(value):.4f}"
    except (TypeError, ValueError):
        return ""


if __name__ == "__main__":
    raise SystemExit(main())
