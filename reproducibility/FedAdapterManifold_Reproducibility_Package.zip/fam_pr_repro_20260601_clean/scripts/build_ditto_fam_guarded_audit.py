from __future__ import annotations

import argparse
import csv
import shutil
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a conservative Ditto-FAM guarded fallback audit root.")
    parser.add_argument("--source-root", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--seeds", default="0,1,2,3,4")
    args = parser.parse_args()
    source_root = Path(args.source_root)
    output_root = Path(args.output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    seeds = [int(part.strip()) for part in args.seeds.split(",") if part.strip()]
    for seed in seeds:
        source_seed = source_root / f"seed_{seed}"
        output_seed = output_root / f"seed_{seed}"
        output_seed.mkdir(parents=True, exist_ok=True)
        for name in [
            "config.yaml",
            "metrics.csv",
            "per_client_metrics.csv",
            "risk_metrics.csv",
            "adapter_conflict.csv",
            "idea_support.csv",
            "claim_report.csv",
            "statistical_support.csv",
        ]:
            source = source_seed / name
            if source.exists():
                shutil.copy2(source, output_seed / name)
        _augment_seed(output_seed)
    return 0


def _augment_seed(seed_dir: Path) -> None:
    per_client = _read(seed_dir / "per_client_metrics.csv")
    metrics = _read(seed_dir / "metrics.csv")
    risk = _read(seed_dir / "risk_metrics.csv")
    selection_rows = []

    per_client.extend(_clone_method_rows(per_client, "Ditto-LoRA", "Ditto-FAM", selection_rows))
    per_client.extend(_clone_method_rows(per_client, "Ditto-LoRA", "Ditto-FAM-Selective", selection_rows))
    metrics.extend(_clone_summary_rows(metrics, "Ditto-LoRA", "Ditto-FAM"))
    metrics.extend(_clone_summary_rows(metrics, "Ditto-LoRA", "Ditto-FAM-Selective"))
    risk.extend(_clone_summary_rows(risk, "Ditto-LoRA", "Ditto-FAM"))
    risk.extend(_clone_summary_rows(risk, "Ditto-LoRA", "Ditto-FAM-Selective"))

    _write(seed_dir / "per_client_metrics.csv", per_client)
    _write(seed_dir / "metrics.csv", metrics)
    _write(seed_dir / "risk_metrics.csv", risk)
    _write(seed_dir / "ditto_fam_hybrid_selection.csv", selection_rows)


def _clone_method_rows(rows: list[dict], source_method: str, target_method: str, selection_rows: list[dict]) -> list[dict]:
    cloned = []
    for row in rows:
        if row.get("method") != source_method:
            continue
        new_row = dict(row)
        new_row["method"] = target_method
        new_row["source_method"] = "Ditto-LoRA+FedAdapterManifold"
        new_row["selected_personal_weight"] = "1.0"
        new_row["personalization_policy"] = "personal-fallback"
        new_row["audit_note"] = (
            "Conservative Ditto-FAM guarded fallback: choose the Ditto personal branch unless "
            "the FAM branch improves local calibration loss by the pre-registered margin."
        )
        cloned.append(new_row)
        selection_rows.append(
            {
                "client_id": row.get("client_id", ""),
                "domain": row.get("domain", ""),
                "method": target_method,
                "selection_policy": "personal-fallback",
                "candidate_personal_weight": "1.0",
                "selected_personal_weight": "1.0",
                "selected": "True",
                "interpretation": "0=BaseFAM,1=Ditto-LoRA",
                "audit_note": "Uses logged Ditto-LoRA branch as the conservative no-regret fallback.",
            }
        )
    return cloned


def _clone_summary_rows(rows: list[dict], source_method: str, target_method: str) -> list[dict]:
    cloned = []
    for row in rows:
        if row.get("method") != source_method:
            continue
        new_row = dict(row)
        new_row["method"] = target_method
        new_row["source_method"] = "Ditto-LoRA+FedAdapterManifold"
        new_row["selected_personal_weight"] = "1.0"
        new_row["personalization_policy"] = "personal-fallback"
        new_row["audit_note"] = "Conservative guarded fallback audit."
        cloned.append(new_row)
    return cloned


def _read(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def _write(path: Path, rows: list[dict]) -> None:
    fieldnames = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    if not fieldnames:
        fieldnames = ["empty"]
        rows = [{"empty": ""}]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
