from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build a compact FedAdapterManifold result pack.")
    parser.add_argument("--output-dir", type=str, default="results/fedadaptermanifold_report_pack")
    parser.add_argument("--main-summary", type=str, required=True)
    parser.add_argument("--mechanism-summary", type=str, required=True)
    parser.add_argument("--mechanism-win-rates", type=str, required=True)
    parser.add_argument("--rank-summary", type=str, required=True)
    parser.add_argument("--component-ablation", type=str, default="")
    parser.add_argument("--pairwise-gap-summary", type=str, default="")
    parser.add_argument("--heterogeneity-sweep", type=str, default="")
    parser.add_argument("--distance-delta-r2", type=str, default="")
    parser.add_argument("--distance-model-r2", type=str, default="")
    parser.add_argument("--graph-active-ablation", type=str, default="")
    parser.add_argument("--backbone-smoke", type=str, default="")
    parser.add_argument("--risk-aware-rank-ablation", type=str, default="")
    parser.add_argument("--autosafe-main", type=str, default="")
    parser.add_argument("--autosafe-risk", type=str, default="")
    parser.add_argument("--autosafe-gates", type=str, default="")
    parser.add_argument("--k-selection-ablation", type=str, default="")
    parser.add_argument("--graph-sharing-rank-ablation", type=str, default="")
    parser.add_argument("--claim-matrix", type=str, default="")
    parser.add_argument("--cluster-safe-ablation", type=str, default="")
    parser.add_argument("--protocol-audit", type=str, default="")
    parser.add_argument(
        "--experiment-note",
        type=str,
        default="CPU/debug numpy feature validation. Absolute accuracies are not final visual-foundation-model results.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    output_dir = ensure_dir(args.output_dir)

    main_rows = _read_csv(Path(args.main_summary))
    mechanism_rows = _read_csv(Path(args.mechanism_summary))
    win_rows = _read_csv(Path(args.mechanism_win_rates))
    rank_rows = _read_csv(Path(args.rank_summary))
    ablation_rows = _read_csv(Path(args.component_ablation)) if args.component_ablation else []
    pairwise_rows = _read_csv(Path(args.pairwise_gap_summary)) if args.pairwise_gap_summary else []
    heterogeneity_rows = _read_csv(Path(args.heterogeneity_sweep)) if args.heterogeneity_sweep else []
    distance_delta_rows = _read_csv(Path(args.distance_delta_r2)) if args.distance_delta_r2 else []
    distance_model_rows = _read_csv(Path(args.distance_model_r2)) if args.distance_model_r2 else []
    graph_active_rows = _read_csv(Path(args.graph_active_ablation)) if args.graph_active_ablation else []
    backbone_rows = _read_csv(Path(args.backbone_smoke)) if args.backbone_smoke else []
    risk_rank_rows = _read_csv(Path(args.risk_aware_rank_ablation)) if args.risk_aware_rank_ablation else []
    autosafe_rows = _read_csv(Path(args.autosafe_main)) if args.autosafe_main else []
    autosafe_risk_rows = _read_csv(Path(args.autosafe_risk)) if args.autosafe_risk else []
    autosafe_gate_rows = _read_csv(Path(args.autosafe_gates)) if args.autosafe_gates else []
    k_selection_rows = _read_csv(Path(args.k_selection_ablation)) if args.k_selection_ablation else []
    graph_rank_rows = _read_csv(Path(args.graph_sharing_rank_ablation)) if args.graph_sharing_rank_ablation else []
    claim_matrix_rows = _read_csv(Path(args.claim_matrix)) if args.claim_matrix else []
    cluster_safe_rows = _read_csv(Path(args.cluster_safe_ablation)) if args.cluster_safe_ablation else []
    protocol_audit_rows = _read_csv(Path(args.protocol_audit)) if args.protocol_audit else []

    write_csv(output_dir / "main_results.csv", _main_table(main_rows))
    write_csv(output_dir / "mechanism_validation.csv", _mechanism_table(mechanism_rows))
    write_csv(output_dir / "per_client_win_rates.csv", _win_table(win_rows))
    write_csv(output_dir / "rank_robustness.csv", _rank_table(rank_rows))
    if ablation_rows:
        write_csv(output_dir / "component_ablation.csv", _ablation_table(ablation_rows))
    if pairwise_rows:
        write_csv(output_dir / "pairwise_conflict_bins.csv", _pairwise_table(pairwise_rows))
    if heterogeneity_rows:
        write_csv(output_dir / "heterogeneity_sweep.csv", _heterogeneity_table(heterogeneity_rows))
    if distance_delta_rows:
        write_csv(output_dir / "distance_complementarity_delta_r2.csv", _distance_delta_table(distance_delta_rows))
    if distance_model_rows:
        write_csv(output_dir / "distance_complementarity_model_r2.csv", _distance_model_table(distance_model_rows))
    if graph_active_rows:
        write_csv(output_dir / "graph_active_ablation.csv", _graph_active_table(graph_active_rows))
    if backbone_rows:
        write_csv(output_dir / "backbone_smoke.csv", _backbone_table(backbone_rows))
    if risk_rank_rows:
        write_csv(output_dir / "risk_aware_rank_ablation.csv", _backbone_table(risk_rank_rows))
    if autosafe_rows:
        write_csv(output_dir / "autosafe_main_results.csv", autosafe_rows)
    if autosafe_risk_rows:
        write_csv(output_dir / "autosafe_risk_results.csv", autosafe_risk_rows)
    if autosafe_gate_rows:
        write_csv(output_dir / "autosafe_gate_summary.csv", autosafe_gate_rows)
    if k_selection_rows:
        write_csv(output_dir / "k_selection_ablation.csv", k_selection_rows)
    if graph_rank_rows:
        write_csv(output_dir / "graph_sharing_rank_ablation.csv", _rank_table(graph_rank_rows))
    if claim_matrix_rows:
        write_csv(output_dir / "claim_matrix.csv", claim_matrix_rows)
    if cluster_safe_rows:
        write_csv(output_dir / "cluster_safe_ablation.csv", cluster_safe_rows)
    if protocol_audit_rows:
        write_csv(output_dir / "protocol_audit_summary.csv", protocol_audit_rows)
    _write_markdown_summary(
        output_dir / "paper_ready_summary.md",
        note=args.experiment_note,
        main_rows=main_rows,
        mechanism_rows=mechanism_rows,
        rank_rows=rank_rows,
        ablation_rows=ablation_rows,
        pairwise_rows=pairwise_rows,
        heterogeneity_rows=heterogeneity_rows,
        distance_delta_rows=distance_delta_rows,
        distance_model_rows=distance_model_rows,
        graph_active_rows=graph_active_rows,
        backbone_rows=backbone_rows,
        risk_rank_rows=risk_rank_rows,
        autosafe_rows=autosafe_rows,
        autosafe_risk_rows=autosafe_risk_rows,
        autosafe_gate_rows=autosafe_gate_rows,
        k_selection_rows=k_selection_rows,
        graph_rank_rows=graph_rank_rows,
        claim_matrix_rows=claim_matrix_rows,
        cluster_safe_rows=cluster_safe_rows,
        protocol_audit_rows=protocol_audit_rows,
    )
    return 0


def _main_table(rows: list[dict]) -> list[dict]:
    out = []
    for row in rows:
        out.append(
            {
                "dataset": row.get("dataset", ""),
                "overall_core_support": row.get("overall_core_support", ""),
                "fedavg_accuracy": row.get("fedavg_accuracy", ""),
                "fedgeo_agg_accuracy": row.get("fedgeo_agg_accuracy", ""),
                "fedadapter_accuracy": row.get("fedadapter_accuracy", ""),
                "gain_vs_fedavg": row.get("gain_vs_fedavg", ""),
                "gain_vs_fedavg_ci_low": row.get("gain_vs_fedavg_ci_low", ""),
                "gain_vs_fedgeo_agg": row.get("gain_vs_fedgeo_agg", ""),
                "gain_vs_fedgeo_agg_ci_low": row.get("gain_vs_fedgeo_agg_ci_low", ""),
                "adapter_incompatibility_failure_r": row.get("adapter_incompatibility_failure_r", ""),
                "adapter_incompatibility_failure_ci_low": row.get("adapter_incompatibility_failure_ci_low", ""),
                "update_conflict_reduction_vs_fedgeo_agg": row.get("update_conflict_reduction_vs_fedgeo_agg", ""),
                "update_conflict_reduction_ci_low": row.get("update_conflict_reduction_ci_low", ""),
                "secondary_caveats": row.get("secondary_caveats", ""),
            }
        )
    return out


def _mechanism_table(rows: list[dict]) -> list[dict]:
    keys = [
        "dataset",
        "num_classes",
        "chance_accuracy",
        "fedadapter_chance_adjusted_accuracy",
        "local_ceiling_recovery",
        "fedavg_to_local_gap_closed",
        "fedgeo_agg_to_local_gap_closed",
        "win_rate_vs_fedavg_lora",
        "win_rate_vs_fedgeo_agg",
        "mean_update_conflict_reduction_percent_vs_fedgeo_agg",
        "mean_drift_reduction_percent_vs_fedgeo_agg",
        "overall_core_support",
        "secondary_caveats",
    ]
    return [{key: row.get(key, "") for key in keys} for row in rows]


def _win_table(rows: list[dict]) -> list[dict]:
    keys = [
        "dataset",
        "method",
        "baseline",
        "num_client_seed_units",
        "wins",
        "ties",
        "losses",
        "win_rate",
        "tie_rate",
        "mean_accuracy_diff",
        "min_accuracy_diff",
        "max_accuracy_diff",
    ]
    return [{key: row.get(key, "") for key in keys} for row in rows]


def _rank_table(rows: list[dict]) -> list[dict]:
    keys = [
        "dataset",
        "rank_policy",
        "overall_core_support",
        "fedadapter_accuracy",
        "fedgeo_agg_accuracy",
        "gain_vs_fedgeo_agg",
        "gain_vs_fedgeo_agg_ci_low",
        "update_conflict_reduction_vs_fedgeo_agg",
        "adapter_incompatibility_failure_r",
        "adapter_incompatibility_failure_ci_low",
        "mean_rank",
        "min_rank",
        "max_rank",
        "effective_rank_policies",
        "secondary_caveats",
    ]
    return [{key: row.get(key, "") for key in keys} for row in rows]


def _ablation_table(rows: list[dict]) -> list[dict]:
    keys = [
        "dataset",
        "seed_scope",
        "ablation",
        "overall_core_support",
        "fedadapter_accuracy",
        "gain_vs_fedgeo_agg",
        "gain_vs_fedgeo_agg_supports",
        "update_conflict_reduction_vs_fedgeo_agg",
        "update_conflict_supports",
        "adapter_incompatibility_r",
        "secondary_caveats",
        "description",
    ]
    return [{key: row.get(key, "") for key in keys} for row in rows]


def _pairwise_table(rows: list[dict]) -> list[dict]:
    keys = [
        "dataset",
        "measure",
        "num_pairs",
        "bottom_bin_failure_mean",
        "top_bin_failure_mean",
        "top_minus_bottom_failure",
        "top_minus_bottom_ci_low",
        "top_minus_bottom_ci_high",
        "failure_ratio_top_over_bottom",
        "supports_high_conflict_failure",
        "pearson_r",
    ]
    return [{key: row.get(key, "") for key in keys} for row in rows]


def _heterogeneity_table(rows: list[dict]) -> list[dict]:
    keys = [
        "alpha",
        "overall_core_support",
        "local_lora_accuracy",
        "fedavg_accuracy",
        "fedgeo_agg_accuracy",
        "fedadapter_accuracy",
        "local_minus_fedavg",
        "gain_vs_fedavg",
        "gain_vs_fedgeo_agg",
        "gain_vs_fedgeo_agg_ci_low",
        "update_conflict_reduction_vs_fedgeo_agg",
        "adapter_incompatibility_failure_r",
        "secondary_caveats",
    ]
    sorted_rows = sorted(rows, key=lambda row: _float_or_inf(row.get("alpha", "")))
    return [{key: row.get(key, "") for key in keys} for row in sorted_rows]


def _distance_delta_table(rows: list[dict]) -> list[dict]:
    keys = [
        "dataset",
        "comparison",
        "richer_model",
        "base_model",
        "delta_r2",
        "delta_r2_ci_low",
        "delta_r2_ci_high",
        "supports_complementarity",
        "num_pairs",
    ]
    return [{key: row.get(key, "") for key in keys} for row in rows]


def _distance_model_table(rows: list[dict]) -> list[dict]:
    keys = [
        "dataset",
        "model",
        "predictors",
        "r2",
        "r2_ci_low",
        "r2_ci_high",
        "num_pairs",
    ]
    return [{key: row.get(key, "") for key in keys} for row in rows]


def _graph_active_table(rows: list[dict]) -> list[dict]:
    keys = [
        "dataset",
        "scope",
        "graph_mode",
        "adapter_graph_self_weight",
        "overall_core_support",
        "fedadapter_accuracy",
        "gain_vs_fedgeo_agg",
        "update_conflict_reduction_vs_fedgeo_agg",
        "client_drift_reduction_vs_fedgeo_agg",
        "mean_selected_graph_mix_weight",
        "graph_mix_accept_rate",
        "secondary_caveats",
    ]
    return [{key: row.get(key, "") for key in keys} for row in rows]


def _backbone_table(rows: list[dict]) -> list[dict]:
    keys = [
        "dataset",
        "feature_backbone",
        "scope",
        "overall_core_support",
        "local_lora_accuracy",
        "fedavg_lora_accuracy",
        "fedgeo_agg_accuracy",
        "fedadapter_accuracy",
        "gain_vs_fedavg",
        "gain_vs_fedgeo_agg",
        "adapter_incompatibility_failure_r",
        "update_conflict_reduction_vs_fedavg",
        "update_conflict_reduction_vs_fedgeo_agg",
        "secondary_caveats",
    ]
    return [{key: row.get(key, "") for key in keys} for row in rows]


def _write_markdown_summary(
    path: Path,
    note: str,
    main_rows: list[dict],
    mechanism_rows: list[dict],
    rank_rows: list[dict],
    ablation_rows: list[dict],
    pairwise_rows: list[dict],
    heterogeneity_rows: list[dict],
    distance_delta_rows: list[dict],
    distance_model_rows: list[dict],
    graph_active_rows: list[dict],
    backbone_rows: list[dict],
    risk_rank_rows: list[dict],
    autosafe_rows: list[dict],
    autosafe_risk_rows: list[dict],
    autosafe_gate_rows: list[dict],
    k_selection_rows: list[dict],
    graph_rank_rows: list[dict],
    claim_matrix_rows: list[dict],
    cluster_safe_rows: list[dict],
    protocol_audit_rows: list[dict],
) -> None:
    lines = [
        "# FedAdapterManifold Result Pack",
        "",
        f"Note: {note}",
        "",
        "## Main Claims",
        "",
        "| Dataset | Core | FedAdapter | FedGeo-Agg | Gain vs FedGeo-Agg | Conflict Reduction | Adapter-Failure r |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in main_rows:
        lines.append(
            "| {dataset} | {core} | {fedadapter} | {fedgeo} | {gain} | {conflict} | {r} |".format(
                dataset=row.get("dataset", ""),
                core=row.get("overall_core_support", ""),
                fedadapter=_fmt(row.get("fedadapter_accuracy", "")),
                fedgeo=_fmt(row.get("fedgeo_agg_accuracy", "")),
                gain=_fmt(row.get("gain_vs_fedgeo_agg", "")),
                conflict=_fmt(row.get("update_conflict_reduction_vs_fedgeo_agg", "")),
                r=_fmt(row.get("adapter_incompatibility_failure_r", "")),
            )
        )

    if autosafe_rows:
        lines.extend(
            [
                "",
                "## Auto-Safe Main Configuration",
                "",
                "Auto-safe uses uncertainty-constrained personalization plus cluster-local safe smoothing. Each adapter-manifold cluster can fall back to the FedGeo-Agg endpoint only when that endpoint is statistically indistinguishable on local train loss, while other clusters keep graph sharing active.",
                "",
                "| Dataset | Local | FedAvg | FedGeo-Agg | FedAdapter | Gain vs FedAvg | Gain vs FedGeo-Agg | Adapter-Failure r | Win vs FedAvg | Win vs FedGeo-Agg |",
                "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for row in autosafe_rows:
            lines.append(
                "| {dataset} | {local} | {fedavg} | {fedgeo} | {adapter} | {gain_avg} | {gain_geo} | {r} | {win_avg} | {win_geo} |".format(
                    dataset=row.get("dataset", ""),
                    local=_fmt(row.get("local_lora_accuracy", "")),
                    fedavg=_fmt(row.get("fedavg_lora_accuracy", "")),
                    fedgeo=_fmt(row.get("fedgeo_agg_accuracy", "")),
                    adapter=_fmt(row.get("fedadapter_accuracy", "")),
                    gain_avg=_fmt(row.get("gain_vs_fedavg", "")),
                    gain_geo=_fmt(row.get("gain_vs_fedgeo_agg", "")),
                    r=_fmt(row.get("adapter_incompatibility_failure_r", "")),
                    win_avg=_fmt(row.get("win_rate_vs_fedavg", "")),
                    win_geo=_fmt(row.get("win_rate_vs_fedgeo_agg", "")),
                )
            )

    if claim_matrix_rows:
        lines.extend(
            [
                "",
                "## Claim Matrix",
                "",
                "Support labels separate strong claims from positive-mean or caveated results. This keeps the main narrative focused on adapter incompatibility and conflict reduction without overstating every accuracy comparison.",
                "",
                "| Dataset | Diagnostic | Acc vs FedAvg | Acc vs FedGeo-Agg | Conflict vs FedAvg | Conflict vs FedGeo-Agg | Paper Position |",
                "|---|---|---|---|---|---|---|",
            ]
        )
        for row in claim_matrix_rows:
            lines.append(
                "| {dataset} | {diag} | {avg} | {geo} | {cavg} | {cgeo} | {pos} |".format(
                    dataset=row.get("dataset", ""),
                    diag=row.get("diagnostic_support", ""),
                    avg=row.get("accuracy_vs_fedavg_support", ""),
                    geo=row.get("accuracy_vs_fedgeo_support", ""),
                    cavg=row.get("conflict_reduction_vs_fedavg_support", ""),
                    cgeo=row.get("conflict_reduction_vs_fedgeo_support", ""),
                    pos=row.get("paper_position", ""),
                )
            )

    if cluster_safe_rows:
        lines.extend(
            [
                "",
                "## Cluster-Local Safe Smoothing Ablation",
                "",
                "Matched comparisons isolate the gate change from other settings. Positive active-graph deltas mean the new gate keeps more clients on graph sharing instead of collapsing to FedGeo-Agg.",
                "",
                "| Dataset | Acc Delta | Gain-vs-FedGeo Delta | Conflict Delta | Fallback Delta | Active Graph Delta | Interpretation |",
                "|---|---:|---:|---:|---:|---:|---|",
            ]
        )
        for row in cluster_safe_rows:
            lines.append(
                "| {dataset} | {acc} | {gain} | {conflict} | {fallback} | {active} | {interp} |".format(
                    dataset=row.get("dataset", ""),
                    acc=_fmt(row.get("fedadapter_accuracy_delta", "")),
                    gain=_fmt(row.get("gain_vs_fedgeo_delta", "")),
                    conflict=_fmt(row.get("conflict_reduction_delta", "")),
                    fallback=_fmt(row.get("safe_fallback_rate_delta", "")),
                    active=_fmt(row.get("active_graph_rate_delta", "")),
                    interp=row.get("interpretation", ""),
                )
            )

    if autosafe_risk_rows:
        lines.extend(
            [
                "",
                "## Auto-Safe Risk And Conflict",
                "",
                "| Dataset | Baseline | Worst-Risk Reduction | Drift Reduction | Update-Conflict Reduction | Conflict Reduction % |",
                "|---|---|---:|---:|---:|---:|",
            ]
        )
        for row in autosafe_risk_rows:
            if not row.get("baseline", ""):
                continue
            lines.append(
                "| {dataset} | {baseline} | {risk} | {drift} | {conflict} | {pct} |".format(
                    dataset=row.get("dataset", ""),
                    baseline=row.get("baseline", ""),
                    risk=_fmt(row.get("worst_client_risk_reduction", "")),
                    drift=_fmt(row.get("client_drift_reduction", "")),
                    conflict=_fmt(row.get("update_conflict_reduction", "")),
                    pct=_fmt(row.get("update_conflict_reduction_percent", "")),
                )
            )

    if autosafe_gate_rows:
        lines.extend(
            [
                "",
                "## Auto-Safe Gate Behavior",
                "",
                "| Dataset | Mean Personal | Mean Smoothing | Safe Fallback Rate |",
                "|---|---:|---:|---:|",
            ]
        )
        for row in _gate_summary_rows(autosafe_gate_rows):
            lines.append(
                "| {dataset} | {personal} | {smoothing} | {fallback} |".format(
                    dataset=row["dataset"],
                    personal=_fmt(row["mean_personal_weight"]),
                    smoothing=_fmt(row["mean_smoothing_weight"]),
                    fallback=_fmt(row["safe_fallback_rate"]),
                )
            )

    if protocol_audit_rows:
        lines.extend(
            [
                "",
                "## Shared Protocol Audit",
                "",
                "The audit checks required config copies, metrics/per-client logging fields, FedGeo manifold signal roles, and the separation between d_geo/geometry_graph and auxiliary risk signals.",
                "",
                "| Dataset | Pass | Warn | Fail | Overall |",
                "|---|---:|---:|---:|---|",
            ]
        )
        for row in protocol_audit_rows:
            lines.append(
                "| {dataset} | {passed} | {warn} | {fail} | {overall} |".format(
                    dataset=row.get("dataset", ""),
                    passed=row.get("pass", ""),
                    warn=row.get("warn", ""),
                    fail=row.get("fail", ""),
                    overall=row.get("overall_status", ""),
                )
            )

    if k_selection_rows:
        lines.extend(
            [
                "",
                "## Adapter Bank K Selection",
                "",
                "Auto-K is a no-domain-count-prior variant. It is useful as evidence for multiple adapter manifolds, but it is intentionally more conservative than the fixed high-capacity bank used for the main visual-backbone setting.",
                "",
                "| Dataset | Setting | Selected K | FedAdapter | Gain vs FedAvg | Gain vs FedGeo-Agg | Adapter-Failure r |",
                "|---|---|---:|---:|---:|---:|---:|",
            ]
        )
        for row in k_selection_rows:
            if row.get("setting") == "auto-minus-fixed":
                continue
            lines.append(
                "| {dataset} | {setting} | {k} | {adapter} | {gain_avg} | {gain_geo} | {r} |".format(
                    dataset=row.get("dataset", ""),
                    setting=row.get("setting", ""),
                    k=row.get("selected_k_values", ""),
                    adapter=_fmt(row.get("fedadapter_accuracy", "")),
                    gain_avg=_fmt(row.get("gain_vs_fedavg", "")),
                    gain_geo=_fmt(row.get("gain_vs_fedgeo_agg", "")),
                    r=_fmt(row.get("adapter_incompatibility_failure_r", "")),
                )
            )

    if graph_rank_rows:
        lines.extend(
            [
                "",
                "## DomainNetMini CLIP Graph-Sharing Rank Ablation",
                "",
                "This focused ablation separates graph sharing from the fully conservative auto-safe fallback. The useful regime is not the largest rank: low or conflict-aware rank keeps graph sharing non-inferior or mildly positive while reducing update conflict against FedGeo-Agg.",
                "",
                "| Setting | Policy | FedAdapter | FedGeo-Agg | Gain vs FedGeo-Agg | Conflict Reduction vs FedGeo-Agg | Adapter-Failure r |",
                "|---|---|---:|---:|---:|---:|---:|",
            ]
        )
        for row in graph_rank_rows:
            lines.append(
                "| {dataset} | {policy} | {adapter} | {fedgeo} | {gain} | {conflict} | {r} |".format(
                    dataset=row.get("dataset", ""),
                    policy=row.get("rank_policy", ""),
                    adapter=_fmt(row.get("fedadapter_accuracy", "")),
                    fedgeo=_fmt(row.get("fedgeo_agg_accuracy", "")),
                    gain=_fmt(row.get("gain_vs_fedgeo_agg", "")),
                    conflict=_fmt(row.get("update_conflict_reduction_vs_fedgeo_agg", "")),
                    r=_fmt(row.get("adapter_incompatibility_failure_r", "")),
                )
            )

    lines.extend(
        [
            "",
            "## Mechanism Validation",
            "",
            "| Dataset | Local-Ceiling Recovery | Win vs FedGeo-Agg | Conflict Reduction % | Drift Reduction % |",
            "|---|---:|---:|---:|---:|",
        ]
    )
    for row in mechanism_rows:
        lines.append(
            "| {dataset} | {recovery} | {win} | {conflict} | {drift} |".format(
                dataset=row.get("dataset", ""),
                recovery=_fmt(row.get("local_ceiling_recovery", "")),
                win=_fmt(row.get("win_rate_vs_fedgeo_agg", "")),
                conflict=_fmt(row.get("mean_update_conflict_reduction_percent_vs_fedgeo_agg", "")),
                drift=_fmt(row.get("mean_drift_reduction_percent_vs_fedgeo_agg", "")),
            )
        )

    if pairwise_rows:
        lines.extend(
            [
                "",
                "## Pairwise Conflict Bins",
                "",
                "Top-vs-bottom equal-count bins directly test whether high-distance client pairs suffer larger pairwise aggregation failure.",
                "",
                "| Dataset | Measure | Supported | Bottom Failure | Top Failure | Top-Bottom Gap | Ratio | Pearson r |",
                "|---|---|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for row in pairwise_rows:
            if row.get("measure") != "d_adapter_incompatibility":
                continue
            lines.append(
                "| {dataset} | {measure} | {support} | {bottom} | {top} | {gap} | {ratio} | {r} |".format(
                    dataset=row.get("dataset", ""),
                    measure=row.get("measure", ""),
                    support=row.get("supports_high_conflict_failure", ""),
                    bottom=_fmt(row.get("bottom_bin_failure_mean", "")),
                    top=_fmt(row.get("top_bin_failure_mean", "")),
                    gap=_fmt(row.get("top_minus_bottom_failure", "")),
                    ratio=_fmt(row.get("failure_ratio_top_over_bottom", "")),
                    r=_fmt(row.get("pearson_r", "")),
                )
            )

    if heterogeneity_rows:
        lines.extend(
            [
                "",
                "## Heterogeneity Strength Sweep",
                "",
                "CIFAR-10 Dirichlet label-skew sweep uses local prototype geometry for alpha-specific geometry; smaller alpha means stronger label heterogeneity.",
                "",
                "| Alpha | Core | Local-FedAvg Gap | Gain vs FedGeo-Agg | Conflict Reduction | Adapter-Failure r |",
                "|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for row in sorted(heterogeneity_rows, key=lambda item: _float_or_inf(item.get("alpha", ""))):
            lines.append(
                "| {alpha} | {core} | {local_gap} | {gain} | {conflict} | {r} |".format(
                    alpha=row.get("alpha", ""),
                    core=row.get("overall_core_support", ""),
                    local_gap=_fmt(row.get("local_minus_fedavg", "")),
                    gain=_fmt(row.get("gain_vs_fedgeo_agg", "")),
                    conflict=_fmt(row.get("update_conflict_reduction_vs_fedgeo_agg", "")),
                    r=_fmt(row.get("adapter_incompatibility_failure_r", "")),
                )
            )

    if distance_delta_rows:
        lines.extend(
            [
                "",
                "## Distance Complementarity",
                "",
                "Incremental R2 tests whether visual geometry and adapter subspace distance provide non-redundant signal for pairwise FedAvg-LoRA failure.",
                "",
                "| Dataset | Add Geo to Subspace | Supported | Add Subspace to Geo | Supported |",
                "|---|---:|---:|---:|---:|",
            ]
        )
        by_dataset: dict[str, dict[str, dict]] = {}
        for row in distance_delta_rows:
            by_dataset.setdefault(row.get("dataset", ""), {})[row.get("comparison", "")] = row
        for dataset in sorted(by_dataset):
            add_geo = by_dataset[dataset].get("add_geo_to_subspace", {})
            add_sub = by_dataset[dataset].get("add_subspace_to_geo", {})
            lines.append(
                "| {dataset} | {add_geo} | {geo_support} | {add_sub} | {sub_support} |".format(
                    dataset=dataset,
                    add_geo=_fmt(add_geo.get("delta_r2", "")),
                    geo_support=add_geo.get("supports_complementarity", ""),
                    add_sub=_fmt(add_sub.get("delta_r2", "")),
                    sub_support=add_sub.get("supports_complementarity", ""),
                )
            )
        if distance_model_rows:
            lines.extend(
                [
                    "",
                    "Distance model R2 summary: raw combinations are dataset-dependent, so the paper should claim complementary signals rather than a universal dominance of any single distance formula.",
                    "",
                    "| Dataset | Subspace Only | Geo Only | Adapter Incompatibility | Raw Combined | Full Distance Set |",
                    "|---|---:|---:|---:|---:|---:|",
                ]
            )
            model_by_dataset: dict[str, dict[str, dict]] = {}
            for row in distance_model_rows:
                model_by_dataset.setdefault(row.get("dataset", ""), {})[row.get("model", "")] = row
            for dataset in sorted(model_by_dataset):
                models = model_by_dataset[dataset]
                lines.append(
                    "| {dataset} | {sub} | {geo} | {compat} | {raw} | {full} |".format(
                        dataset=dataset,
                        sub=_fmt(models.get("subspace_only", {}).get("r2", "")),
                        geo=_fmt(models.get("geo_only", {}).get("r2", "")),
                        compat=_fmt(models.get("adapter_incompatibility", {}).get("r2", "")),
                        raw=_fmt(models.get("raw_combined", {}).get("r2", "")),
                        full=_fmt(models.get("full_distance_set", {}).get("r2", "")),
                    )
        )

    if backbone_rows:
        lines.extend(
            [
                "",
                "## Visual Backbone Runs",
                "",
                "These runs use a stronger frozen visual feature extractor than the CPU/debug numpy descriptor. They are not yet the full CLIP/DINO study, but they check whether the mechanism survives a real pretrained visual backbone.",
                "",
                "| Dataset | Backbone | Scope | Core | Local | FedAvg | FedGeo-Agg | FedAdapter | Gain vs FedGeo-Agg | Adapter-Failure r | Conflict vs FedAvg | Conflict vs FedGeo-Agg |",
                "|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for row in backbone_rows:
            lines.append(
                "| {dataset} | {backbone} | {scope} | {core} | {local} | {fedavg} | {fedgeo} | {adapter} | {gain} | {r} | {conflict_fedavg} | {conflict_fedgeo} |".format(
                    dataset=row.get("dataset", ""),
                    backbone=row.get("feature_backbone", ""),
                    scope=row.get("scope", ""),
                    core=row.get("overall_core_support", ""),
                    local=_fmt(row.get("local_lora_accuracy", "")),
                    fedavg=_fmt(row.get("fedavg_lora_accuracy", "")),
                    fedgeo=_fmt(row.get("fedgeo_agg_accuracy", "")),
                    adapter=_fmt(row.get("fedadapter_accuracy", "")),
                    gain=_fmt(row.get("gain_vs_fedgeo_agg", "")),
                    r=_fmt(row.get("adapter_incompatibility_failure_r", "")),
                    conflict_fedavg=_fmt(row.get("update_conflict_reduction_vs_fedavg", "")),
                    conflict_fedgeo=_fmt(row.get("update_conflict_reduction_vs_fedgeo_agg", "")),
                )
            )
        lines.extend(
            [
                "",
                "Interpretation: when FedGeo-Agg is already near or above the Local-LoRA ceiling, accuracy gain can saturate even while the adapter-conflict diagnostic remains strong. The robust claim is therefore gain under residual negative transfer; in saturated regimes, a FedGeo-safe smoothing fallback should be reported as no-regret matching rather than as an extra accuracy gain.",
            ]
        )

    if risk_rank_rows:
        lines.extend(
            [
                "",
                "## Auxiliary Risk Prior Ablation",
                "",
                "Risk signals are not used as the adapter manifold adjacency. This ablation keeps d_geo/geometry_graph/prototypes as the main manifold and uses risk_geo_score only as an optional rank-capacity prior.",
                "",
                "| Dataset | Policy | Scope | Core | Local | FedGeo-Agg | FedAdapter | Gain vs FedGeo-Agg | Adapter-Failure r | Conflict Reduction |",
                "|---|---|---|---:|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for row in risk_rank_rows:
            lines.append(
                "| {dataset} | {policy} | {scope} | {core} | {local} | {fedgeo} | {adapter} | {gain} | {r} | {conflict} |".format(
                    dataset=row.get("dataset", ""),
                    policy=row.get("feature_backbone", ""),
                    scope=row.get("scope", ""),
                    core=row.get("overall_core_support", ""),
                    local=_fmt(row.get("local_lora_accuracy", "")),
                    fedgeo=_fmt(row.get("fedgeo_agg_accuracy", "")),
                    adapter=_fmt(row.get("fedadapter_accuracy", "")),
                    gain=_fmt(row.get("gain_vs_fedgeo_agg", "")),
                    r=_fmt(row.get("adapter_incompatibility_failure_r", "")),
                    conflict=_fmt(row.get("update_conflict_reduction_vs_fedgeo_agg", "")),
                )
            )
        lines.extend(
            [
                "",
                "Interpretation: shrink-style risk-aware rank allocation can make heterogeneous-rank FedAvg an unfairly weak baseline. The plus-capacity variant is the cleaner auxiliary prior: it improves FedAdapter accuracy and worst-client risk on the tested settings, but slightly weakens conflict reduction, so it should be reported as an optional fairness/capacity module rather than the main method.",
            ]
        )

    if graph_active_rows:
        lines.extend(
            [
                "",
                "## Graph-Active Stress Test",
                "",
                "This stress test lowers adapter graph self-weight and reduces bank/personal capacity to force cross-client graph sharing. It is a mechanism-boundary test, not the primary accuracy setting.",
                "",
                "| Dataset | Scope | Graph | Self Weight | Mix Weight | Accept Rate | Core | FedAdapter | Gain vs FedGeo-Agg | Conflict Reduction |",
                "|---|---|---|---:|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for row in graph_active_rows:
            lines.append(
                "| {dataset} | {scope} | {mode} | {self_weight} | {mix_weight} | {accept} | {core} | {acc} | {gain} | {conflict} |".format(
                    dataset=row.get("dataset", ""),
                    scope=row.get("scope", ""),
                    mode=row.get("graph_mode", ""),
                    self_weight=_fmt(row.get("adapter_graph_self_weight", "")),
                    mix_weight=_fmt(row.get("mean_selected_graph_mix_weight", "")),
                    accept=_fmt(row.get("graph_mix_accept_rate", "")),
                    core=row.get("overall_core_support", ""),
                    acc=_fmt(row.get("fedadapter_accuracy", "")),
                    gain=_fmt(row.get("gain_vs_fedgeo_agg", "")),
                    conflict=_fmt(row.get("update_conflict_reduction_vs_fedgeo_agg", "")),
                )
            )
        lines.extend(
            [
                "",
                "Interpretation: forced graph sharing can be neutral or harmful in the current debug representation, so geometry_graph should be described as a gated sharing prior rather than an unconditional source of gains.",
            ]
        )

    lines.extend(
        [
            "",
            "## Rank Robustness",
            "",
            "Recommended primary rank policies for the current debug setting: fixed rank and conflict-aware rank. "
            "Novelty-aware rank allocation should be reported as a baseline because sparse many-class data can make the diagnostic unstable.",
            "",
            "| Dataset | Policy | Core | Gain vs FedGeo-Agg | Adapter-Failure r |",
            "|---|---|---:|---:|---:|",
        ]
    )
    for row in rank_rows:
        lines.append(
            "| {dataset} | {policy} | {core} | {gain} | {r} |".format(
                dataset=row.get("dataset", ""),
                policy=row.get("rank_policy", ""),
                core=row.get("overall_core_support", ""),
                gain=_fmt(row.get("gain_vs_fedgeo_agg", "")),
                r=_fmt(row.get("adapter_incompatibility_failure_r", "")),
            )
        )

    if ablation_rows:
        lines.extend(
            [
                "",
                "## Component Ablation",
                "",
                "| Dataset | Scope | Ablation | Core | FedAdapter | Gain vs FedGeo-Agg | Conflict Reduction |",
                "|---|---|---|---:|---:|---:|---:|",
            ]
        )
        for row in ablation_rows:
            lines.append(
                "| {dataset} | {scope} | {name} | {core} | {acc} | {gain} | {conflict} |".format(
                    dataset=row.get("dataset", ""),
                    scope=row.get("seed_scope", ""),
                    name=row.get("ablation", ""),
                    core=row.get("overall_core_support", ""),
                    acc=_fmt(row.get("fedadapter_accuracy", "")),
                    gain=_fmt(row.get("gain_vs_fedgeo_agg", "")),
                    conflict=_fmt(row.get("update_conflict_reduction_vs_fedgeo_agg", "")),
                )
            )
    lines.append("")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def _gate_summary_rows(rows: list[dict]) -> list[dict]:
    grouped: dict[str, list[dict]] = {}
    for row in rows:
        grouped.setdefault(row.get("dataset", ""), []).append(row)
    out = []
    for dataset in sorted(grouped):
        subset = grouped[dataset]
        personal = [_float_or_nan(row.get("personal_weight", "")) for row in subset]
        smoothing = [_float_or_nan(row.get("client_smoothing_weight", "")) for row in subset]
        fallback = [str(row.get("safe_smoothing_fallback", "")).strip().lower() == "true" for row in subset]
        out.append(
            {
                "dataset": dataset,
                "mean_personal_weight": _mean(personal),
                "mean_smoothing_weight": _mean(smoothing),
                "safe_fallback_rate": sum(1 for value in fallback if value) / max(len(fallback), 1),
            }
        )
    return out


def _mean(values: list[float]) -> float:
    finite = [value for value in values if value == value]
    if not finite:
        return float("nan")
    return sum(finite) / len(finite)


def _float_or_nan(value) -> float:
    try:
        if value in {"", None}:
            return float("nan")
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _fmt(value) -> str:
    try:
        return f"{float(value):.4f}"
    except (TypeError, ValueError):
        return str(value)


def _float_or_inf(value) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("inf")


def _read_csv(path: Path) -> list[dict]:
    if not path or not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


if __name__ == "__main__":
    raise SystemExit(main())
