from __future__ import annotations

from pathlib import Path
import argparse
import shlex
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.config import flatten_config, load_yaml
from fedadaptermanifold.reporting import ensure_dir, write_csv
from scripts.run_fedgeo_multiseed import main as run_multiseed


OPTIONAL_OVERRIDES = [
    "rounds",
    "local_epochs",
    "rank",
    "rank_policy",
    "min_rank",
    "max_rank",
    "adapter_bank_k",
    "personal_weight",
    "personal_weight_policy",
    "personal_weight_candidates",
    "personal_weight_tolerance",
    "manifold_smoothing_policy",
    "manifold_smoothing_candidates",
    "manifold_smoothing_tolerance",
    "base_head_init",
    "base_head_scale",
    "class_prompt_template",
]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build or execute formal FedAdapterManifold experiment commands.")
    parser.add_argument("--plan", type=str, default="configs/formal_experiment_plan.yaml")
    parser.add_argument("--output-dir", type=str, default="")
    parser.add_argument("--data-root-template", type=str, default="")
    parser.add_argument("--data-root-map", type=str, default="", help="Semicolon-separated dataset=path overrides.")
    parser.add_argument("--geometry-outputs-map-template", type=str, default="")
    parser.add_argument(
        "--geometry-outputs-map-map",
        type=str,
        default="",
        help="Semicolon-separated dataset=path overrides for FedGeo geometry map CSVs.",
    )
    parser.add_argument("--feature-cache-dir-template", type=str, default="")
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--allow-missing", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    plan = flatten_config(load_yaml(args.plan))
    output_dir = ensure_dir(args.output_dir or plan.get("plan_output_dir", Path(plan.get("output_root", "results/fedadaptermanifold_formal_full_v1")) / "_plan"))
    rows = build_plan_rows(plan, args)
    write_csv(output_dir / "formal_experiment_plan.csv", rows)
    _write_markdown(output_dir / "formal_experiment_plan.md", rows)
    _write_powershell(output_dir / "run_formal_experiments.ps1", rows)
    if not args.execute:
        return 0

    failed = False
    run_rows = []
    for row in rows:
        if row["ready"] != "true":
            failed = True
            run_rows.append({**row, "exit_code": 2})
            if not args.allow_missing:
                continue
        code = run_multiseed(_argv_from_row(row))
        failed = failed or code != 0
        run_rows.append({**row, "exit_code": code})
    write_csv(output_dir / "formal_experiment_runs.csv", run_rows)
    return 2 if failed else 0


def build_plan_rows(plan: dict, args: argparse.Namespace | None = None) -> list[dict]:
    args = args or argparse.Namespace(
        data_root_template="",
        data_root_map="",
        geometry_outputs_map_template="",
        geometry_outputs_map_map="",
        feature_cache_dir_template="",
    )
    rows = []
    output_root = Path(str(plan.get("output_root", "results/fedadaptermanifold_formal_full_v1")))
    python_executable = str(plan.get("python_executable", "python"))
    seeds = str(plan.get("seeds", "0,1,2"))
    round_id = str(plan.get("round_id", 0))
    feature_backbone = str(plan.get("feature_backbone", ""))
    backbone_slug = _slug(feature_backbone or "backbone")
    device = str(plan.get("device", ""))
    configs = _split_csv(plan.get("configs", ""))
    for config_path_text in configs:
        config_path = Path(config_path_text)
        config = flatten_config(load_yaml(config_path)) if config_path.exists() else {}
        dataset_key = _dataset_key(config_path, config)
        data_root = _dataset_value(
            plan,
            args.data_root_template,
            args.data_root_map,
            dataset_key,
            "data_root",
            config.get("data_root", ""),
        )
        geometry_map = _dataset_value(
            plan,
            args.geometry_outputs_map_template,
            args.geometry_outputs_map_map,
            dataset_key,
            "geometry_outputs_map",
            "",
        )
        cache_template = args.feature_cache_dir_template or str(plan.get("feature_cache_dir_template", ""))
        feature_cache_dir = _format_template(cache_template, dataset_key, config_path, backbone_slug) if cache_template else str(config.get("feature_cache_dir", ""))
        output_dir = output_root / dataset_key
        ready, reason = _ready_status(config_path, data_root, geometry_map)
        row = {
            "dataset_key": dataset_key,
            "config": str(config_path),
            "output_dir": str(output_dir),
            "data_root": data_root,
            "geometry_outputs_map": geometry_map,
            "feature_cache_dir": feature_cache_dir,
            "seeds": seeds,
            "round_id": round_id,
            "feature_backbone": feature_backbone or str(config.get("feature_backbone", "")),
            "device": device or str(config.get("device", "")),
            "no_cpu_debug": str(plan.get("no_cpu_debug", config.get("cpu_debug", False) is False)).lower(),
            "continue_on_failed_diagnostic": str(plan.get("continue_on_failed_diagnostic", config.get("continue_on_failed_diagnostic", False))).lower(),
            "strict_support_exit": str(plan.get("strict_support_exit", False)).lower(),
            "ready": "true" if ready else "false",
            "skip_reason": reason,
        }
        for key in OPTIONAL_OVERRIDES:
            if key in plan and str(plan.get(key, "")) != "":
                row[key] = str(plan[key])
        row["argv"] = " ".join(_quote(arg) for arg in _argv_from_row(row))
        row["powershell_command"] = _powershell_command(python_executable, row)
        rows.append(row)
    return rows


def _argv_from_row(row: dict) -> list[str]:
    argv = [
        "--config",
        row["config"],
        "--output-root",
        row["output_dir"],
        "--seeds",
        row["seeds"],
        "--round-id",
        str(row["round_id"]),
        "--data-root",
        row["data_root"],
        "--geometry-outputs-map",
        row["geometry_outputs_map"],
    ]
    for cli_key, row_key in [
        ("--feature-backbone", "feature_backbone"),
        ("--feature-cache-dir", "feature_cache_dir"),
        ("--device", "device"),
    ]:
        if row.get(row_key):
            argv.extend([cli_key, str(row[row_key])])
    for key in OPTIONAL_OVERRIDES:
        if row.get(key, "") != "":
            argv.extend(["--" + key.replace("_", "-"), str(row[key])])
    if str(row.get("no_cpu_debug", "")).lower() == "true":
        argv.append("--no-cpu-debug")
    if str(row.get("continue_on_failed_diagnostic", "")).lower() == "true":
        argv.append("--continue-on-failed-diagnostic")
    if str(row.get("strict_support_exit", "")).lower() == "true":
        argv.append("--strict-support-exit")
    return argv


def _dataset_value(plan: dict, template_override: str, map_override: str, dataset_key: str, suffix: str, default: str) -> str:
    mapped = _lookup_dataset_map(map_override, dataset_key)
    if mapped:
        return mapped
    specific = str(plan.get(f"{dataset_key}_{suffix}", "") or "")
    if specific:
        return specific
    aliases = _dataset_aliases(dataset_key)
    for alias in aliases:
        value = str(plan.get(f"{alias}_{suffix}", "") or "")
        if value:
            return value
    template = template_override or str(plan.get(f"{suffix}_template", "") or "")
    if template:
        return _format_template(template, dataset_key, Path(""), _slug(str(plan.get("feature_backbone", "backbone"))))
    return str(default or "")


def _lookup_dataset_map(spec: str, dataset_key: str) -> str:
    if not spec:
        return ""
    aliases = set(_dataset_aliases(dataset_key))
    for part in str(spec).split(";"):
        if not part.strip() or "=" not in part:
            continue
        key, value = part.split("=", 1)
        if key.strip() in aliases:
            return value.strip()
    return ""


def _ready_status(config_path: Path, data_root: str, geometry_map: str) -> tuple[bool, str]:
    missing = []
    if not config_path.exists():
        missing.append("config")
    if not data_root or not Path(data_root).exists():
        missing.append("data_root")
    if not geometry_map or not Path(geometry_map).exists():
        missing.append("geometry_outputs_map")
    return not missing, ";".join(missing)


def _dataset_key(config_path: Path, config: dict) -> str:
    text = " ".join([config_path.stem, str(config.get("heterogeneity_setting", "")), str(config.get("output_dir", ""))]).lower()
    if "office" in text:
        return "office_home"
    if "domainnetmini" in text or "domainnet" in text:
        return "domainnetmini"
    if "pacs" in text:
        return "pacs"
    return config_path.stem.replace("full_", "").replace("_clip_vit_b16", "").replace("-", "_")


def _dataset_aliases(dataset_key: str) -> list[str]:
    aliases = [dataset_key]
    aliases.append(dataset_key.replace("_", ""))
    aliases.append(dataset_key.replace("_", "-"))
    if dataset_key == "office_home":
        aliases.extend(["officehome", "office_home"])
    return list(dict.fromkeys(aliases))


def _format_template(template: str, dataset_key: str, config_path: Path, backbone_slug: str) -> str:
    return str(template).format(
        dataset_key=dataset_key,
        dataset=dataset_key,
        config=config_path.name,
        config_stem=config_path.stem,
        backbone_slug=backbone_slug,
        seed="{seed}",
        round_id="{round_id}",
    )


def _powershell_command(python_executable: str, row: dict) -> str:
    parts = [python_executable, "scripts\\run_fedgeo_multiseed.py", *_argv_from_row(row)]
    return " ".join(_ps_quote(part) for part in parts)


def _write_markdown(path: Path, rows: list[dict]) -> None:
    lines = [
        "# Formal FedAdapterManifold Experiment Plan",
        "",
        "| Dataset | Ready | Reason | Config | Seeds | Backbone | Output |",
        "|---|---:|---|---|---|---|---|",
    ]
    for row in rows:
        lines.append(
            "| {dataset} | {ready} | {reason} | {config} | {seeds} | {backbone} | {output} |".format(
                dataset=row["dataset_key"],
                ready=row["ready"],
                reason=row["skip_reason"],
                config=row["config"],
                seeds=row["seeds"],
                backbone=row["feature_backbone"],
                output=row["output_dir"],
            )
        )
    lines.extend(["", "## Commands", ""])
    for row in rows:
        lines.extend([f"### {row['dataset_key']}", "", "```powershell", row["powershell_command"], "```", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def _write_powershell(path: Path, rows: list[dict]) -> None:
    lines = [
        "# Generated by scripts/build_formal_experiment_plan.py",
        "$ErrorActionPreference = 'Stop'",
        "",
    ]
    for row in rows:
        lines.append(f"# {row['dataset_key']} ready={row['ready']} reason={row['skip_reason']}")
        lines.append(row["powershell_command"])
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def _split_csv(value) -> list[str]:
    return [part.strip() for part in str(value or "").split(",") if part.strip()]


def _quote(value: str) -> str:
    return shlex.quote(str(value))


def _ps_quote(value: str) -> str:
    text = str(value)
    if not text or any(ch.isspace() for ch in text) or any(ch in text for ch in "'&()[]{};,"):
        return "'" + text.replace("'", "''") + "'"
    return text


def _slug(value: str) -> str:
    return str(value).lower().replace("/", "").replace("-", "_").replace(" ", "_")


if __name__ == "__main__":
    raise SystemExit(main())
