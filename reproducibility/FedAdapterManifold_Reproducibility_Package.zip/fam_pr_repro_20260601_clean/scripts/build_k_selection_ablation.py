from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv


METHOD = "FedAdapterManifold"


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Summarize fixed-vs-auto adapter-bank K selection ablations.")
    parser.add_argument(
        "--run",
        action="append",
        default=[],
        help="Repeated spec: dataset|fixed_result_dir|autok_result_dir",
    )
    parser.add_argument("--output-dir", type=str, default="results/fedadaptermanifold_k_selection_ablation")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    runs = [_parse_run(spec) for spec in args.run]
    if not runs:
        raise ValueError("At least one --run dataset|fixed_result_dir|autok_result_dir is required")
    output_dir = ensure_dir(args.output_dir)

    rows = []
    for run in runs:
        fixed = _result_row(run["dataset"], "fixed-k", Path(run["fixed_dir"]))
        autok = _result_row(run["dataset"], "auto-k", Path(run["autok_dir"]))
        rows.extend([fixed, autok])
        rows.append(_delta_row(run["dataset"], fixed, autok))
    write_csv(output_dir / "k_selection_ablation.csv", rows)
    _write_markdown(output_dir / "k_selection_ablation.md", rows)
    return 0


def _parse_run(spec: str) -> dict:
    parts = [part.strip() for part in spec.split("|")]
    if len(parts) != 3:
        raise ValueError(f"Expected dataset|fixed_result_dir|autok_result_dir, got: {spec}")
    return {"dataset": parts[0], "fixed_dir": parts[1], "autok_dir": parts[2]}


def _result_row(dataset: str, setting: str, result_dir: Path) -> dict:
    summary = _read_csv(result_dir / "multiseed_summary.csv")
    claims = _read_csv(result_dir / "multiseed_claim_report.csv")
    return {
        "dataset": dataset,
        "setting": setting,
        "selected_k_values": _selected_k_values(result_dir),
        "mean_selected_k": _mean_selected_k(result_dir),
        "local_lora_accuracy": _summary(summary, "method_accuracy", "Local-LoRA", "", "mean_accuracy"),
        "fedavg_lora_accuracy": _summary(summary, "method_accuracy", "FedAvg-LoRA", "", "mean_accuracy"),
        "fedgeo_agg_accuracy": _summary(summary, "method_accuracy", "FedGeo-Agg", "", "mean_accuracy"),
        "fedadapter_accuracy": _summary(summary, "method_accuracy", METHOD, "", "mean_accuracy"),
        "gain_vs_fedavg": _claim(claims, "adapter_bank_gain_vs_fedavg"),
        "gain_vs_fedgeo_agg": _claim(claims, "adapter_bank_gain_vs_fedgeo_agg"),
        "adapter_incompatibility_failure_r": _claim(claims, "adapter_incompatibility_failure_correlation"),
        "update_conflict_reduction_vs_fedavg": _claim(claims, "update_conflict_reduction_vs_fedavg"),
        "update_conflict_reduction_vs_fedgeo_agg": _claim(claims, "update_conflict_reduction_vs_fedgeo_agg"),
        "overall_core_support": _claim_text(claims, "overall_core_support", "supports"),
        "result_dir": str(result_dir),
    }


def _delta_row(dataset: str, fixed: dict, autok: dict) -> dict:
    return {
        "dataset": dataset,
        "setting": "auto-minus-fixed",
        "selected_k_values": "",
        "mean_selected_k": _to_float(autok.get("mean_selected_k")) - _to_float(fixed.get("mean_selected_k")),
        "fedadapter_accuracy": _to_float(autok.get("fedadapter_accuracy")) - _to_float(fixed.get("fedadapter_accuracy")),
        "gain_vs_fedavg": _to_float(autok.get("gain_vs_fedavg")) - _to_float(fixed.get("gain_vs_fedavg")),
        "gain_vs_fedgeo_agg": _to_float(autok.get("gain_vs_fedgeo_agg")) - _to_float(fixed.get("gain_vs_fedgeo_agg")),
        "update_conflict_reduction_vs_fedavg": _to_float(autok.get("update_conflict_reduction_vs_fedavg"))
        - _to_float(fixed.get("update_conflict_reduction_vs_fedavg")),
        "update_conflict_reduction_vs_fedgeo_agg": _to_float(autok.get("update_conflict_reduction_vs_fedgeo_agg"))
        - _to_float(fixed.get("update_conflict_reduction_vs_fedgeo_agg")),
    }


def _selected_k_values(result_dir: Path) -> str:
    values = _selected_k_list(result_dir)
    return ",".join(str(value) for value in values)


def _mean_selected_k(result_dir: Path) -> float:
    values = _selected_k_list(result_dir)
    return float(np.mean(values)) if values else float("nan")


def _selected_k_list(result_dir: Path) -> list[int]:
    run_rows = _read_csv(result_dir / "runs.csv")
    values = []
    for row in run_rows:
        seed_dir = Path(row.get("output_dir", ""))
        if not seed_dir.is_absolute():
            seed_dir = ROOT / seed_dir
        selection_rows = _read_csv(seed_dir / "adapter_bank_k_selection.csv")
        for selection in selection_rows:
            if _truthy(selection.get("selected", "")):
                values.append(int(float(selection.get("candidate_k", "nan"))))
                break
    return values


def _summary(rows: list[dict], test: str, method: str, baseline: str, measure: str) -> float:
    for row in rows:
        if row.get("test") != test:
            continue
        if method and row.get("method") != method:
            continue
        if baseline and row.get("baseline") != baseline:
            continue
        if measure and row.get("measure") != measure:
            continue
        return _to_float(row.get("estimate", ""))
    return float("nan")


def _claim(rows: list[dict], claim_id: str) -> float:
    return _to_float(_claim_text(rows, claim_id, "estimate"))


def _claim_text(rows: list[dict], claim_id: str, field: str) -> str:
    for row in rows:
        if row.get("claim_id") == claim_id:
            return row.get(field, "")
    return ""


def _truthy(value) -> bool:
    return str(value).strip().lower() in {"1", "true", "yes"}


def _to_float(value) -> float:
    try:
        if value in {"", None}:
            return float("nan")
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _write_markdown(path: Path, rows: list[dict]) -> None:
    lines = [
        "# Adapter Bank K Selection Ablation",
        "",
        "| Dataset | Setting | Selected K | FedAdapter | Gain vs FedAvg | Gain vs FedGeo | Adapter-Failure r |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        if row["setting"] == "auto-minus-fixed":
            continue
        lines.append(
            "| {dataset} | {setting} | {k} | {acc} | {gain_avg} | {gain_geo} | {corr} |".format(
                dataset=row["dataset"],
                setting=row["setting"],
                k=row.get("selected_k_values", ""),
                acc=_fmt(row.get("fedadapter_accuracy")),
                gain_avg=_fmt(row.get("gain_vs_fedavg")),
                gain_geo=_fmt(row.get("gain_vs_fedgeo_agg")),
                corr=_fmt(row.get("adapter_incompatibility_failure_r")),
            )
        )
    lines.extend(
        [
            "",
            "Auto-K is a no-domain-count-prior variant. It is intentionally more conservative than fixed high-capacity banks.",
        ]
    )
    ensure_dir(path.parent)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _fmt(value) -> str:
    value = _to_float(value)
    if not np.isfinite(value):
        return ""
    return f"{value:.4f}"


if __name__ == "__main__":
    raise SystemExit(main())
