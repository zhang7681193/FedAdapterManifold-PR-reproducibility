from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build a paper-facing FedAdapterManifold claim matrix.")
    parser.add_argument("--autosafe-main", type=str, required=True)
    parser.add_argument("--autosafe-risk", type=str, required=True)
    parser.add_argument("--graph-rank-ablation", type=str, default="")
    parser.add_argument("--output-dir", type=str, default="results/fedadaptermanifold_claim_matrix")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    output_dir = ensure_dir(args.output_dir)
    main_rows = _read_csv(Path(args.autosafe_main))
    risk_rows = _read_csv(Path(args.autosafe_risk))
    graph_rows = _read_csv(Path(args.graph_rank_ablation)) if args.graph_rank_ablation else []

    matrix = [_dataset_claim_row(row, risk_rows) for row in main_rows]
    graph_matrix = [_graph_claim_row(row) for row in graph_rows]

    write_csv(output_dir / "claim_matrix.csv", matrix)
    if graph_matrix:
        write_csv(output_dir / "graph_rank_claim_matrix.csv", graph_matrix)
    _write_markdown(output_dir / "claim_matrix.md", matrix, graph_matrix)
    return 0


def _dataset_claim_row(row: dict, risk_rows: list[dict]) -> dict:
    dataset = row.get("dataset", "")
    fedavg_gain = _float(row.get("gain_vs_fedavg"))
    fedavg_gain_ci = _float(row.get("gain_vs_fedavg_ci_low"))
    fedgeo_gain = _float(row.get("gain_vs_fedgeo_agg"))
    fedgeo_gain_ci = _float(row.get("gain_vs_fedgeo_agg_ci_low"))
    diagnostic = _float(row.get("adapter_incompatibility_failure_r"))
    diagnostic_ci = _float(row.get("adapter_incompatibility_failure_ci_low"))
    conflict_vs_fedavg = _risk_value(risk_rows, dataset, "FedAvg-LoRA", "update_conflict_reduction")
    conflict_vs_fedavg_ci = _risk_value(risk_rows, dataset, "FedAvg-LoRA", "update_conflict_reduction")
    conflict_vs_fedgeo = _risk_value(risk_rows, dataset, "FedGeo-Agg", "update_conflict_reduction")

    fedavg_support = _support_level(fedavg_gain, fedavg_gain_ci)
    fedgeo_support = _support_level(fedgeo_gain, fedgeo_gain_ci)
    diagnostic_support = _support_level(diagnostic, diagnostic_ci)
    conflict_fedavg_support = _sign_support(conflict_vs_fedavg)
    conflict_fedgeo_support = _sign_support(conflict_vs_fedgeo)

    return {
        "dataset": dataset,
        "diagnostic_claim": "adapter incompatibility predicts FedAvg failure",
        "diagnostic_estimate": diagnostic,
        "diagnostic_ci_low": diagnostic_ci,
        "diagnostic_support": diagnostic_support,
        "accuracy_vs_fedavg_estimate": fedavg_gain,
        "accuracy_vs_fedavg_ci_low": fedavg_gain_ci,
        "accuracy_vs_fedavg_support": fedavg_support,
        "accuracy_vs_fedgeo_estimate": fedgeo_gain,
        "accuracy_vs_fedgeo_ci_low": fedgeo_gain_ci,
        "accuracy_vs_fedgeo_support": fedgeo_support,
        "conflict_reduction_vs_fedavg": conflict_vs_fedavg,
        "conflict_reduction_vs_fedavg_support": conflict_fedavg_support,
        "conflict_reduction_vs_fedgeo": conflict_vs_fedgeo,
        "conflict_reduction_vs_fedgeo_support": conflict_fedgeo_support,
        "paper_position": _paper_position(
            diagnostic_support,
            fedavg_support,
            fedgeo_support,
            conflict_fedavg_support,
            conflict_fedgeo_support,
        ),
    }


def _graph_claim_row(row: dict) -> dict:
    gain = _float(row.get("gain_vs_fedgeo_agg"))
    gain_ci = _float(row.get("gain_vs_fedgeo_agg_ci_low"))
    conflict = _float(row.get("update_conflict_reduction_vs_fedgeo_agg"))
    conflict_ci = _float(row.get("update_conflict_reduction_ci_low"))
    diagnostic = _float(row.get("adapter_incompatibility_failure_r"))
    diagnostic_ci = _float(row.get("adapter_incompatibility_failure_ci_low"))
    return {
        "setting": row.get("dataset", ""),
        "rank_policy": row.get("rank_policy", ""),
        "mean_rank": row.get("mean_rank", ""),
        "accuracy_vs_fedgeo_estimate": gain,
        "accuracy_vs_fedgeo_ci_low": gain_ci,
        "accuracy_vs_fedgeo_support": _support_level(gain, gain_ci),
        "conflict_reduction_vs_fedgeo": conflict,
        "conflict_reduction_vs_fedgeo_ci_low": conflict_ci,
        "conflict_reduction_support": _support_level(conflict, conflict_ci),
        "diagnostic_estimate": diagnostic,
        "diagnostic_ci_low": diagnostic_ci,
        "diagnostic_support": _support_level(diagnostic, diagnostic_ci),
        "paper_position": _graph_position(gain, gain_ci, conflict, conflict_ci, diagnostic, diagnostic_ci),
    }


def _paper_position(
    diagnostic: str,
    fedavg: str,
    fedgeo: str,
    conflict_fedavg: str,
    conflict_fedgeo: str,
) -> str:
    if diagnostic == "strong" and fedavg in {"strong", "positive_mean_mixed_ci"}:
        if fedgeo == "strong" and conflict_fedgeo == "strong":
            return "main_positive_result"
        if fedgeo in {"strong", "positive_mean_mixed_ci"}:
            return "main_positive_with_ci_caveat"
        if conflict_fedgeo == "strong":
            return "conflict_control_result"
    if diagnostic == "strong" and conflict_fedavg == "strong":
        return "diagnostic_and_fedavg_failure_result"
    return "caveat_or_ablation"


def _graph_position(gain: float, gain_ci: float, conflict: float, conflict_ci: float, diagnostic: float, diagnostic_ci: float) -> str:
    gain_support = _support_level(gain, gain_ci)
    conflict_support = _support_level(conflict, conflict_ci)
    diagnostic_support = _support_level(diagnostic, diagnostic_ci)
    if gain_support == "strong" and conflict_support == "strong":
        return "graph_sharing_positive"
    if gain > 0.0 and conflict_support == "strong" and diagnostic_support == "strong":
        return "noninferior_positive_mean_conflict_reduction"
    if gain < 0.0 and conflict_support == "strong":
        return "accuracy_conflict_tradeoff"
    return "boundary_or_negative_control"


def _support_level(estimate: float, ci_low: float) -> str:
    if estimate > 0.0 and ci_low > 0.0:
        return "strong"
    if estimate > 0.0 and ci_low >= -1e-3:
        return "near_strong_boundary"
    if estimate > 0.0:
        return "positive_mean_mixed_ci"
    if abs(estimate) <= 1e-12:
        return "tie"
    return "negative_or_caveat"


def _sign_support(value: float) -> str:
    if value > 1e-12:
        return "strong"
    if abs(value) <= 1e-12:
        return "tie"
    return "negative_or_caveat"


def _risk_value(rows: list[dict], dataset: str, baseline: str, key: str) -> float:
    for row in rows:
        if row.get("dataset") == dataset and row.get("baseline") == baseline:
            return _float(row.get(key))
    return float("nan")


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def _float(value) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _write_markdown(path: Path, matrix: list[dict], graph_matrix: list[dict]) -> None:
    lines = [
        "# FedAdapterManifold Claim Matrix",
        "",
        "## Main Visual-Backbone Claims",
        "",
        "| Dataset | Diagnostic | Acc vs FedAvg | Acc vs FedGeo-Agg | Conflict vs FedAvg | Conflict vs FedGeo-Agg | Paper Position |",
        "|---|---|---|---|---|---|---|",
    ]
    for row in matrix:
        lines.append(
            "| {dataset} | {diag} ({diag_est}) | {avg} ({avg_est}) | {geo} ({geo_est}) | {cavg} ({cavg_est}) | {cgeo} ({cgeo_est}) | {pos} |".format(
                dataset=row["dataset"],
                diag=row["diagnostic_support"],
                diag_est=_fmt(row["diagnostic_estimate"]),
                avg=row["accuracy_vs_fedavg_support"],
                avg_est=_fmt(row["accuracy_vs_fedavg_estimate"]),
                geo=row["accuracy_vs_fedgeo_support"],
                geo_est=_fmt(row["accuracy_vs_fedgeo_estimate"]),
                cavg=row["conflict_reduction_vs_fedavg_support"],
                cavg_est=_fmt(row["conflict_reduction_vs_fedavg"]),
                cgeo=row["conflict_reduction_vs_fedgeo_support"],
                cgeo_est=_fmt(row["conflict_reduction_vs_fedgeo"]),
                pos=row["paper_position"],
            )
        )
    if graph_matrix:
        lines.extend(
            [
                "",
                "## DomainNetMini CLIP Graph-Sharing Rank Claims",
                "",
                "| Setting | Policy | Accuracy vs FedGeo-Agg | Conflict vs FedGeo-Agg | Diagnostic | Paper Position |",
                "|---|---|---|---|---|---|",
            ]
        )
        for row in graph_matrix:
            lines.append(
                "| {setting} | {policy} | {acc} ({acc_est}) | {conflict} ({conf_est}) | {diag} ({diag_est}) | {pos} |".format(
                    setting=row["setting"],
                    policy=row["rank_policy"],
                    acc=row["accuracy_vs_fedgeo_support"],
                    acc_est=_fmt(row["accuracy_vs_fedgeo_estimate"]),
                    conflict=row["conflict_reduction_support"],
                    conf_est=_fmt(row["conflict_reduction_vs_fedgeo"]),
                    diag=row["diagnostic_support"],
                    diag_est=_fmt(row["diagnostic_estimate"]),
                    pos=row["paper_position"],
                )
            )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _fmt(value) -> str:
    try:
        return f"{float(value):.4f}"
    except (TypeError, ValueError):
        return ""


if __name__ == "__main__":
    raise SystemExit(main())
