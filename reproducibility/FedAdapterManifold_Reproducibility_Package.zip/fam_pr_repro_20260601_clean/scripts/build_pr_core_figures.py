from __future__ import annotations

import csv
import argparse
import math
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "paper" / "figures"
PACK = ROOT / "results" / "fam_pr_evidence_pack_v15"


COLORS = {
    "FedAvg-LoRA": "#8E8E93",
    "FedGeo-Agg": "#4C78A8",
    "GeoAgg": "#4C78A8",
    "Geo-only": "#4C78A8",
    "FedAdapterManifold-Selective": "#72B7B2",
    "Hybrid-FAM": "#F58518",
    "FedPer-FAM": "#F58518",
    "Ditto-FAM": "#F58518",
    "FedAdapterManifold-StrongSelective": "#54A24B",
    "Best non-FAM": "#B279A2",
    "FedAvg-CLIP-LoRA": "#8E8E93",
    "FedGeo-Agg-CLIP-LoRA": "#4C78A8",
    "GeoAgg-CLIP-LoRA": "#4C78A8",
    "Geo-only CLIP": "#4C78A8",
    "FedAdapterManifold-CLIP-LoRA": "#72B7B2",
    "FedAdapterManifold-Selective-CLIP-LoRA": "#54A24B",
    "FedAvg-Lift": "#E45756",
    "SCAFFOLD-LoRA": "#B279A2",
    "Ditto-LoRA": "#FF9DA6",
}

DISPLAY_LABELS = {
    "FedAdapterManifold": "FAM",
    "FedAdapterManifold-Selective": "FAM-Selective",
    "FedAdapterManifold-StrongSelective": "FAM-Anchor-Expanded",
    "FedAdapterManifold-ClientRoute": "FAM-ClientRoute",
    "FedAdapterManifold-CLIP-LoRA": "FAM-CLIP",
    "FedAdapterManifold-Selective-CLIP-LoRA": "FAM-Selective-CLIP",
    "FedGeo-Agg": "Geo-only",
    "FedGeo-Agg-CLIP-LoRA": "Geo-only CLIP",
    "GeoAgg-CLIP-LoRA": "Geo-only CLIP",
    "FedAvg-CLIP-LoRA": "FedAvg-CLIP",
}


def display_label(method: str) -> str:
    if method in DISPLAY_LABELS:
        return DISPLAY_LABELS[method]
    return method.replace("FedAdapterManifold-", "FAM-").replace("-CLIP-LoRA", "")


def main() -> int:
    global OUT, PACK
    args = parse_args()
    OUT = Path(args.output_dir)
    PACK = Path(args.evidence_dir)
    OUT.mkdir(parents=True, exist_ok=True)
    draw_main_accuracy()
    draw_adapter_diagnostic()
    draw_safety_controls()
    draw_clip_vit_evidence()
    draw_dinov2_evidence()
    write_manifest()
    return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build FedAdapterManifold PR figure PNGs.")
    parser.add_argument("--output-dir", default=str(OUT), help="Directory for generated figures.")
    parser.add_argument("--evidence-dir", default=str(PACK), help="Directory containing the PR evidence CSV pack.")
    return parser.parse_args()


def read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def fnum(value, default: float = float("nan")) -> float:
    try:
        if value in {"", None}:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        Path(r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf"),
        Path(r"C:\Windows\Fonts\calibrib.ttf" if bold else r"C:\Windows\Fonts\calibri.ttf"),
    ]
    for path in candidates:
        if path.exists():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


def text(draw: ImageDraw.ImageDraw, xy: tuple[int, int], value: str, size: int = 22, fill: str = "#222222", bold: bool = False) -> None:
    draw.text(xy, value, font=font(size, bold=bold), fill=fill)


def draw_main_accuracy() -> None:
    rows = read_csv(PACK / "main_accuracy_with_strong_baselines.csv")
    datasets = ["PACS", "OfficeCaltech", "OfficeHomeFull", "DomainNetMini", "BloodMNIST"]
    labels = ["PACS", "Office-Caltech", "OfficeHome", "DomainNetMini", "BloodMNIST"]
    methods = [
        "FedAvg-LoRA",
        "Geo-only",
        "FedAdapterManifold-Selective",
        "Hybrid-FAM",
        "FedAdapterManifold-StrongSelective",
        "Best non-FAM",
    ]
    table: dict[tuple[str, str], float] = {}
    by_dataset: dict[str, list[dict]] = {}
    for row in rows:
        ds = row.get("dataset", "")
        by_dataset.setdefault(ds, []).append(row)
        table[(ds, row.get("method", ""))] = fnum(row.get("mean_accuracy"))
        if row.get("method", "") == "FedGeo-Agg":
            table[(ds, "Geo-only")] = fnum(row.get("mean_accuracy"))
    fam_family = {
        "FedAdapterManifold",
        "FedAdapterManifold-Selective",
        "FedAdapterManifold-StrongSelective",
        "FedPer-FAM",
        "FedPer-FAM-Selective",
        "Geo-only",
        "Ditto-FAM",
        "Ditto-FAM-Selective",
    }
    for ds, ds_rows in by_dataset.items():
        hybrid = table.get((ds, "Ditto-FAM"))
        if hybrid is None or math.isnan(hybrid):
            hybrid = table.get((ds, "FedPer-FAM"))
        if hybrid is not None and not math.isnan(hybrid):
            table[(ds, "Hybrid-FAM")] = hybrid
        best = max((r for r in ds_rows if r.get("method") not in fam_family), key=lambda r: fnum(r.get("mean_accuracy")), default={})
        if best:
            table[(ds, "Best non-FAM")] = fnum(best.get("mean_accuracy"))

    img = Image.new("RGB", (1800, 1050), "white")
    draw = ImageDraw.Draw(img)
    text(draw, (55, 35), "Main 5-seed evidence: FedAvg repair, geometry ceilings, and safe composition", 34, bold=True)
    draw_grouped_bars(
        draw,
        box=(95, 115, 1690, 885),
        datasets=datasets,
        dataset_labels=labels,
        methods=methods,
        values=table,
        ymin=0.40,
        ymax=1.00,
        ylabel="Mean accuracy",
    )
    legend(draw, methods, x=115, y=930, wrap=3)
    img.save(OUT / "main_accuracy_summary.png", quality=95)


def draw_clip_vit_evidence() -> None:
    rows = read_csv(PACK / "end_to_end_vfm_summary.csv")
    datasets = ["DomainNetMini60", "DomainNetMini60-8shot", "PACS7", "OfficeCaltech10"]
    labels = ["DNMini-60", "DNMini-60 8/8", "PACS-7", "Office-Caltech-10"]
    methods = [
        "FedAvg-CLIP-LoRA",
        "Geo-only CLIP",
        "FedAdapterManifold-CLIP-LoRA",
        "FedAdapterManifold-Selective-CLIP-LoRA",
    ]
    values: dict[tuple[str, str], float] = {}
    for row in rows:
        if row.get("evidence_type") != "5-seed_federated_CLIP_ViT_attention_LoRA":
            continue
        ds = row.get("dataset_alias", "")
        method = row.get("method", "")
        if method == "FedGeo-Agg-CLIP-LoRA":
            values[(ds, "Geo-only CLIP")] = fnum(row.get("mean_accuracy"))
        if ds in datasets and method in methods:
            values[(ds, method)] = fnum(row.get("mean_accuracy"))
    img = Image.new("RGB", (1500, 900), "white")
    draw = ImageDraw.Draw(img)
    text(draw, (55, 35), "Federated end-to-end CLIP ViT-B/16 attention-LoRA", 34, bold=True)
    draw_grouped_bars(
        draw,
        box=(95, 115, 1390, 735),
        datasets=datasets,
        dataset_labels=labels,
        methods=methods,
        values=values,
        ymin=0.74,
        ymax=1.00,
        ylabel="Mean accuracy",
    )
    legend(draw, methods, x=115, y=785, wrap=2)
    img.save(OUT / "clip_vit_lora_evidence.png", quality=95)


def draw_dinov2_evidence() -> None:
    rows = read_csv(PACK / "dinov2_evidence_summary.csv")
    datasets = ["PACS", "OfficeHome"]
    labels = ["PACS DINOv2", "OfficeHome DINOv2"]
    methods = [
        "FedAvg-LoRA",
        "FedAdapterManifold-Selective",
        "FedAdapterManifold-StrongSelective",
        "Best non-FAM",
    ]
    values: dict[tuple[str, str], float] = {}
    by_dataset: dict[str, list[dict]] = {}
    fam_family = {
        "FedAdapterManifold",
        "FedAdapterManifold-Selective",
        "FedAdapterManifold-StrongSelective",
        "FedAdapterManifold-ClientRoute",
        "FedPer-FAM",
        "FedPer-FAM-Selective",
        "Ditto-FAM",
        "Ditto-FAM-Selective",
        "Subspace-Compatible",
    }
    for row in rows:
        if row.get("evidence_type") != "DINOv2-S/14 frozen-feature LoRA audit":
            continue
        if row.get("test") != "method_accuracy":
            continue
        ds = row.get("dataset_alias", "")
        method = row.get("method", "")
        by_dataset.setdefault(ds, []).append(row)
        if ds in datasets and method in methods:
            values[(ds, method)] = fnum(row.get("estimate"))
    for ds, ds_rows in by_dataset.items():
        best = max((r for r in ds_rows if r.get("method") not in fam_family), key=lambda r: fnum(r.get("estimate")), default={})
        if best:
            values[(ds, "Best non-FAM")] = fnum(best.get("estimate"))
    img = Image.new("RGB", (1400, 820), "white")
    draw = ImageDraw.Draw(img)
    text(draw, (55, 35), "DINOv2-S/14 frozen-feature LoRA audits", 34, bold=True)
    draw_grouped_bars(
        draw,
        box=(95, 115, 1295, 655),
        datasets=datasets,
        dataset_labels=labels,
        methods=methods,
        values=values,
        ymin=0.70,
        ymax=0.98,
        ylabel="Mean accuracy",
    )
    legend(draw, methods, x=115, y=705, wrap=2)
    text(
        draw,
        (95, 770),
        "OfficeHome uses the full 65-class calib20 anchored selector; capped 240/160 DINOv2 runs are excluded.",
        22,
        "#444444",
    )
    img.save(OUT / "dinov2_backbone_evidence.png", quality=95)


def draw_adapter_diagnostic() -> None:
    root = ROOT / "results" / "fam_officehome_full_guardfull_fedper_fam_5seed_v1" / "seed_0"
    metrics = read_csv(root / "subspace_metrics.csv")
    conflict = read_csv(root / "adapter_conflict.csv")
    img = Image.new("RGB", (1800, 1050), "white")
    draw = ImageDraw.Draw(img)
    text(draw, (55, 35), "Adapter manifold diagnostic: subspace geometry predicts aggregation failure", 34, bold=True)

    heatmap_panel(draw, metrics, (70, 125, 570, 800), "A. LoRA adapter subspace distance")
    scatter_panel(
        draw,
        conflict,
        (650, 125, 1200, 800),
        "B. Incompatibility vs receiver residual failure",
        "d_adapter_incompatibility",
        "receiver_residual_aggregation_failure",
        "Adapter incompatibility",
        "Receiver residual failure",
    )
    scatter_panel(
        draw,
        metrics,
        (1280, 125, 1735, 800),
        "C. Visual prototype distance vs subspace",
        "d_geo",
        "d_sub",
        "d_geo",
        "d_sub",
    )
    text(
        draw,
        (80, 865),
        "OfficeHome seed 0 is shown as a representative mechanism panel; the manuscript reports five-seed pooled correlations.",
        24,
        "#444444",
    )
    img.save(OUT / "adapter_subspace_diagnostic.png", quality=95)


def draw_safety_controls() -> None:
    graph_rows = read_csv(ROOT / "results" / "fam_officecaltech_graph_negative_control_v2_forced" / "graph_active_summary.csv")
    cal_rows = read_csv(ROOT / "results" / "fam_officecaltech_calibration_gate_ablation_v1" / "calibration_gate_accuracy.csv")
    quality_rows = read_csv(PACK / "geometry_quality_overview.csv")
    img = Image.new("RGB", (1800, 1050), "white")
    draw = ImageDraw.Draw(img)
    text(draw, (55, 35), "Safety checks: raw graph sharing can hurt; gates use calibration, not test selection", 34, bold=True)

    simple_bar_panel(
        draw,
        graph_rows,
        (80, 130, 610, 795),
        "A. Forced raw graph sharing",
        label_key="graph_mode",
        value_key="fedadapter_accuracy",
        ymin=0.80,
        ymax=0.92,
        ylabel="Accuracy",
    )
    calibration_panel(draw, cal_rows, (690, 130, 1215, 795), "B. Held-out calibration gate")
    simple_bar_panel(
        draw,
        quality_rows,
        (1290, 130, 1725, 795),
        "C. Geometry/conflict signal",
        label_key="dataset",
        value_key="corr_mean",
        ymin=0.00,
        ymax=0.60,
        ylabel="Mean corr.",
    )
    text(draw, (85, 865), "Negative controls support the paper's wording: geometry is a conditioning prior, not an unconditional averaging rule.", 24, "#444444")
    img.save(OUT / "safe_routing_controls.png", quality=95)


def draw_grouped_bars(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    datasets: list[str],
    dataset_labels: list[str],
    methods: list[str],
    values: dict[tuple[str, str], float],
    ymin: float,
    ymax: float,
    ylabel: str,
) -> None:
    x0, y0, x1, y1 = box
    plot_x0, plot_y0 = x0 + 90, y0 + 20
    plot_x1, plot_y1 = x1 - 20, y1 - 85
    axes(draw, (plot_x0, plot_y0, plot_x1, plot_y1), ymin, ymax, ylabel)
    group_w = (plot_x1 - plot_x0) / len(datasets)
    gap = 12
    bar_w = max(8, int((group_w - 2 * gap) / len(methods)))
    for gi, ds in enumerate(datasets):
        base_x = plot_x0 + gi * group_w + gap
        for mi, method in enumerate(methods):
            value = values.get((ds, method), float("nan"))
            bx0 = int(base_x + mi * bar_w)
            bx1 = int(bx0 + bar_w * 0.82)
            if math.isnan(value):
                placeholder_top = plot_y1 - 42
                outline = COLORS.get(method, "#999999")
                draw.rectangle([bx0, placeholder_top, bx1, plot_y1], outline=outline, width=2)
                for hx in range(bx0 - 28, bx1 + 4, 10):
                    draw.line([hx, plot_y1, hx + 42, placeholder_top], fill=outline, width=1)
                na = "N/A"
                tw = draw.textlength(na, font=font(12, bold=True))
                draw.text((bx0 + (bx1 - bx0 - tw) / 2, placeholder_top - 18), na, fill=outline, font=font(12, bold=True))
                continue
            h = (value - ymin) / (ymax - ymin) * (plot_y1 - plot_y0)
            by0 = int(plot_y1 - h)
            draw.rectangle([bx0, by0, bx1, plot_y1], fill=COLORS.get(method, "#999999"))
            draw.line([bx0, by0, bx1, by0], fill="#222222", width=1)
        label = dataset_labels[gi]
        tw = draw.textlength(label, font=font(18))
        draw.text((int(plot_x0 + gi * group_w + group_w / 2 - tw / 2), plot_y1 + 18), label, fill="#222222", font=font(18))


def heatmap_panel(draw: ImageDraw.ImageDraw, rows: list[dict], box: tuple[int, int, int, int], title: str) -> None:
    x0, y0, x1, y1 = box
    text(draw, (x0, y0 - 45), title, 24, bold=True)
    domains: list[str] = []
    for row in rows:
        for key in ["domain_i", "domain_j"]:
            if row.get(key) and row[key] not in domains:
                domains.append(row[key])
    n = len(domains)
    values = [[0.0 for _ in range(n)] for _ in range(n)]
    max_v = 1e-9
    for row in rows:
        i, j = domains.index(row["domain_i"]), domains.index(row["domain_j"])
        v = fnum(row.get("d_adapter_incompatibility"))
        values[i][j] = values[j][i] = v
        max_v = max(max_v, v)
    cell = min((x1 - x0 - 110) // n, (y1 - y0 - 110) // n)
    hx, hy = x0 + 85, y0 + 40
    for i in range(n):
        for j in range(n):
            intensity = values[i][j] / max_v if max_v else 0.0
            color = lerp("#F4F7FB", "#255C99", intensity)
            draw.rectangle([hx + j * cell, hy + i * cell, hx + (j + 1) * cell - 2, hy + (i + 1) * cell - 2], fill=color)
            label = f"{values[i][j]:.2f}"
            draw.text((hx + j * cell + 8, hy + i * cell + cell // 2 - 10), label, fill="#111111", font=font(16))
    for i, domain in enumerate(domains):
        draw.text((hx - 70, hy + i * cell + cell // 2 - 10), short_domain(domain), fill="#222222", font=font(16))
        draw.text((hx + i * cell + 8, hy + n * cell + 12), short_domain(domain), fill="#222222", font=font(16))


def scatter_panel(
    draw: ImageDraw.ImageDraw,
    rows: list[dict],
    box: tuple[int, int, int, int],
    title: str,
    x_key: str,
    y_key: str,
    x_label: str,
    y_label: str,
) -> None:
    x0, y0, x1, y1 = box
    text(draw, (x0, y0 - 45), title, 24, bold=True)
    xs = [fnum(r.get(x_key)) for r in rows if not math.isnan(fnum(r.get(x_key))) and not math.isnan(fnum(r.get(y_key)))]
    ys = [fnum(r.get(y_key)) for r in rows if not math.isnan(fnum(r.get(x_key))) and not math.isnan(fnum(r.get(y_key)))]
    if not xs:
        return
    xmin, xmax = nice_range(min(xs), max(xs))
    ymin, ymax = nice_range(min(ys), max(ys))
    px0, py0, px1, py1 = x0 + 75, y0 + 35, x1 - 25, y1 - 85
    axes(draw, (px0, py0, px1, py1), ymin, ymax, y_label, xmin=xmin, xmax=xmax, xlabel=x_label)
    for x, y in zip(xs, ys):
        px = px0 + (x - xmin) / (xmax - xmin) * (px1 - px0)
        py = py1 - (y - ymin) / (ymax - ymin) * (py1 - py0)
        draw.ellipse([px - 5, py - 5, px + 5, py + 5], fill="#1F77B4", outline="#0E3A5B")
    r = pearson(xs, ys)
    draw_fit_line(draw, xs, ys, (px0, py0, px1, py1), xmin, xmax, ymin, ymax)
    text(draw, (px0 + 12, py0 + 12), f"Pearson r={r:.3f}", 18, "#222222")


def simple_bar_panel(
    draw: ImageDraw.ImageDraw,
    rows: list[dict],
    box: tuple[int, int, int, int],
    title: str,
    label_key: str,
    value_key: str,
    ymin: float,
    ymax: float,
    ylabel: str,
) -> None:
    x0, y0, x1, y1 = box
    text(draw, (x0, y0 - 45), title, 24, bold=True)
    labels = [str(r.get(label_key, "")) for r in rows]
    values = [fnum(r.get(value_key)) for r in rows]
    px0, py0, px1, py1 = x0 + 85, y0 + 35, x1 - 20, y1 - 85
    axes(draw, (px0, py0, px1, py1), ymin, ymax, ylabel)
    if not rows:
        return
    bar_w = (px1 - px0) / len(rows) * 0.62
    for i, (label, value) in enumerate(zip(labels, values)):
        cx = px0 + (i + 0.5) * (px1 - px0) / len(rows)
        h = (value - ymin) / (ymax - ymin) * (py1 - py0)
        draw.rectangle([cx - bar_w / 2, py1 - h, cx + bar_w / 2, py1], fill="#4C78A8")
        draw.text((cx - draw.textlength(short_domain(label), font=font(16)) / 2, py1 + 16), short_domain(label), fill="#222222", font=font(16))
        draw.text((cx - 28, py1 - h - 25), f"{value:.3f}", fill="#222222", font=font(15))


def calibration_panel(draw: ImageDraw.ImageDraw, rows: list[dict], box: tuple[int, int, int, int], title: str) -> None:
    x0, y0, x1, y1 = box
    text(draw, (x0, y0 - 45), title, 24, bold=True)
    methods = ["FedAvg-LoRA", "FedAvg-Lift", "FedAdapterManifold-Selective", "FedAdapterManifold-StrongSelective"]
    fractions = sorted({fnum(r.get("calibration_fraction")) for r in rows})
    data = {(fnum(r.get("calibration_fraction")), r.get("method", "")): fnum(r.get("mean_accuracy")) for r in rows}
    # Leave enough vertical space for x ticks, x-axis title, and a two-row legend.
    # The previous layout placed the legend only 13 px below the x-axis title,
    # which looked cramped after LaTeX scaling.
    px0, py0, px1, py1 = x0 + 85, y0 + 35, x1 - 25, y1 - 150
    axes(draw, (px0, py0, px1, py1), 0.72, 0.96, "Accuracy", xmin=0.04, xmax=0.21, xlabel="Calibration fraction")
    for method in methods:
        points = []
        for frac in fractions:
            value = data.get((frac, method), float("nan"))
            if math.isnan(value):
                continue
            px = px0 + (frac - 0.04) / (0.21 - 0.04) * (px1 - px0)
            py = py1 - (value - 0.72) / (0.96 - 0.72) * (py1 - py0)
            points.append((px, py))
        if len(points) >= 2:
            draw.line(points, fill=COLORS.get(method, "#999999"), width=4)
        for px, py in points:
            draw.ellipse([px - 5, py - 5, px + 5, py + 5], fill=COLORS.get(method, "#999999"))
    for idx, method in enumerate(methods):
        lx = px0 + (idx % 2) * 210
        ly = py1 + 86 + (idx // 2) * 30
        draw.line([lx, ly + 8, lx + 35, ly + 8], fill=COLORS.get(method, "#999999"), width=4)
        draw.text((lx + 45, ly - 3), display_label(method), fill="#222222", font=font(14))


def axes(
    draw: ImageDraw.ImageDraw,
    box: tuple[int, int, int, int],
    ymin: float,
    ymax: float,
    ylabel: str,
    xmin: float | None = None,
    xmax: float | None = None,
    xlabel: str | None = None,
) -> None:
    x0, y0, x1, y1 = box
    draw.rectangle([x0, y0, x1, y1], outline="#333333", width=2)
    for k in range(5):
        frac = k / 4
        y = y1 - frac * (y1 - y0)
        value = ymin + frac * (ymax - ymin)
        draw.line([x0, y, x1, y], fill="#E6E6E6", width=1)
        draw.text((x0 - 68, y - 10), f"{value:.2f}", fill="#333333", font=font(16))
    draw.text((x0 - 80, y0 - 32), ylabel, fill="#222222", font=font(17))
    if xmin is not None and xmax is not None:
        for k in range(4):
            frac = k / 3
            x = x0 + frac * (x1 - x0)
            value = xmin + frac * (xmax - xmin)
            draw.text((x - 20, y1 + 13), f"{value:.2f}", fill="#333333", font=font(15))
    if xlabel:
        draw.text((x0 + (x1 - x0) // 2 - 75, y1 + 45), xlabel, fill="#222222", font=font(17))


def legend(draw: ImageDraw.ImageDraw, methods: list[str], x: int, y: int, wrap: int = 3) -> None:
    for idx, method in enumerate(methods):
        row = idx // wrap
        col = idx % wrap
        lx = x + col * 520
        ly = y + row * 42
        draw.rectangle([lx, ly, lx + 28, ly + 20], fill=COLORS.get(method, "#999999"))
        draw.text((lx + 38, ly - 2), display_label(method), fill="#222222", font=font(20))


def pearson(xs: list[float], ys: list[float]) -> float:
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    denx = math.sqrt(sum((x - mx) ** 2 for x in xs))
    deny = math.sqrt(sum((y - my) ** 2 for y in ys))
    return num / (denx * deny) if denx and deny else float("nan")


def draw_fit_line(draw: ImageDraw.ImageDraw, xs, ys, box, xmin, xmax, ymin, ymax) -> None:
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    denom = sum((x - mx) ** 2 for x in xs)
    if denom <= 0:
        return
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / denom
    intercept = my - slope * mx
    x0, y0, x1, y1 = box
    pts = []
    for x in [xmin, xmax]:
        y = slope * x + intercept
        px = x0 + (x - xmin) / (xmax - xmin) * (x1 - x0)
        py = y1 - (y - ymin) / (ymax - ymin) * (y1 - y0)
        pts.append((px, py))
    draw.line(pts, fill="#D62728", width=3)


def nice_range(vmin: float, vmax: float) -> tuple[float, float]:
    if vmin == vmax:
        return vmin - 1, vmax + 1
    pad = 0.08 * (vmax - vmin)
    return vmin - pad, vmax + pad


def lerp(c1: str, c2: str, t: float) -> str:
    t = max(0.0, min(1.0, t))
    a = tuple(int(c1[i : i + 2], 16) for i in (1, 3, 5))
    b = tuple(int(c2[i : i + 2], 16) for i in (1, 3, 5))
    return "#" + "".join(f"{round(a[i] + (b[i] - a[i]) * t):02x}" for i in range(3))


def short_domain(label: str) -> str:
    mapping = {
        "Real World": "Real",
        "OfficeHomeFull": "OfficeHome",
        "domainnetmini": "DomainNet",
        "bloodmnist": "Blood",
        "office_home": "OfficeHome",
    }
    return mapping.get(label, label[:12])


def write_manifest() -> None:
    rows = [
        {
            "figure": "main_accuracy_summary.png",
            "source": "results/fam_pr_evidence_pack_v15/main_accuracy_with_strong_baselines.csv",
            "caption_role": "main accuracy and strong-baseline evidence",
        },
        {
            "figure": "adapter_subspace_diagnostic.png",
            "source": "OfficeHome seed_0 subspace_metrics.csv and adapter_conflict.csv",
            "caption_role": "mechanism diagnostic: heatmap, failure correlation, geometry/subspace complementarity",
        },
        {
            "figure": "safe_routing_controls.png",
            "source": "graph negative control, calibration sweep, geometry quality overview",
            "caption_role": "safe routing legality and raw graph negative control",
        },
        {
            "figure": "clip_vit_lora_evidence.png",
            "source": "results/fam_pr_evidence_pack_v15/end_to_end_vfm_summary.csv",
            "caption_role": "end-to-end CLIP ViT LoRA evidence",
        },
        {
            "figure": "dinov2_backbone_evidence.png",
            "source": "results/fam_pr_evidence_pack_v15/dinov2_evidence_summary.csv",
            "caption_role": "DINOv2-S/14 backbone audit with OfficeHome full-data anchored selector",
        },
    ]
    with (OUT / "figure_manifest.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    raise SystemExit(main())
