"""Build a compact PR evidence audit from existing FedAdapterManifold runs.

The audit is intentionally conservative: it separates current-code results,
full-data runs that are verified by a current-code spot check, and ablations
that should remain supplemental.
"""

from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class EvidenceRun:
    dataset: str
    role: str
    status: str
    path: str
    note: str


RUNS: tuple[EvidenceRun, ...] = (
    EvidenceRun(
        "PACS",
        "safe current main",
        "usable_main",
        "results/fam_pacs_geometry_source_v1_3seed/fedgeo_full",
        "Current capped PACS protocol; strong FedAvg repair. FAM reaches the GeoAgg/local ceiling, so do not claim pure graph sharing beats GeoAgg here.",
    ),
    EvidenceRun(
        "PACS",
        "pure FAM control",
        "usable_ablation",
        "results/fam_pacs_geometry_sensitivity_v2_nosmooth/fedgeo_full",
        "Pure no-smoothing FAM repairs FedAvg but trails GeoAgg; useful as a mechanism/control result.",
    ),
    EvidenceRun(
        "OfficeCaltech",
        "safe current main",
        "usable_main",
        "results/fam_officecaltech_component_v5_3seed/full",
        "Clean current protocol; safe selection improves beyond both FedAvg and GeoAgg.",
    ),
    EvidenceRun(
        "OfficeCaltech",
        "pure FAM control",
        "usable_ablation",
        "results/fam_officecaltech_pure_v1_nosmooth_fixed_3seed",
        "Pure no-smoothing FAM improves over GeoAgg on mean accuracy; CI lower bound is near zero.",
    ),
    EvidenceRun(
        "BloodMNIST",
        "medical application",
        "usable_application",
        "results/fam_blood_v1_3seed_reagg",
        "Medical label-skew application; strong FedAvg repair and conflict reduction. Do not describe it as hospital-domain split.",
    ),
    EvidenceRun(
        "DomainNetMini",
        "hard dataset current cap",
        "usable_supplementary_hard_case",
        "results/fam_dnmini_current_safe_v1_3seed",
        "Current capped hard-case result. Accuracy gain is small, but conflict reduction and subspace/failure correlation remain positive.",
    ),
    EvidenceRun(
        "OfficeHome",
        "full-data 3-seed current-verified",
        "usable_main_with_verification_note",
        "results/fedadaptermanifold_formal_full_v1/office_home_selective_v3_3seed",
        "Full-data effective sample counts for all seeds; current-code full-data seed0 reproduces the old seed0 metrics exactly.",
    ),
)

METHODS = {
    "BaseHead": "Base-Head",
    "Local": "Local-LoRA",
    "FedAvg": "FedAvg-LoRA",
    "FedAvgLift": "FedAvg-Lift",
    "GeoDiag": "FedGeo-Diag",
    "GeoAgg": "FedGeo-Agg",
    "Subspace": "Subspace-Compatible",
    "FAM": "FedAdapterManifold",
    "ClientRoute": "FedAdapterManifold-ClientRoute",
    "Selective": "FedAdapterManifold-Selective",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def find_summary(root: Path) -> list[dict[str, str]]:
    for name in ("multiseed_summary.csv", "summary.csv"):
        rows = read_csv(root / name)
        if rows:
            return rows
    return []


def find_claims(root: Path) -> list[dict[str, str]]:
    for name in ("multiseed_claim_report.csv", "claim_report.csv"):
        rows = read_csv(root / name)
        if rows:
            return rows
    return []


def method_accuracy(summary: Iterable[dict[str, str]], method: str) -> str:
    for row in summary:
        if row.get("test") == "method_accuracy" and row.get("method") == method:
            return row.get("estimate", "")
    return ""


def claim_value(
    claims: Iterable[dict[str, str]],
    claim_id: str,
    field: str = "estimate",
) -> str:
    for row in claims:
        if row.get("claim_id") == claim_id:
            return row.get(field, "")
    return ""


def metric_value(
    summary: Iterable[dict[str, str]],
    test: str,
    method: str,
    baseline: str,
    measure: str,
    field: str = "estimate",
) -> str:
    for row in summary:
        if (
            row.get("test") == test
            and row.get("method") == method
            and row.get("baseline") == baseline
            and row.get("measure") == measure
        ):
            return row.get(field, "")
    return ""


def verify_officehome_seed0(repo_root: Path) -> dict[str, str]:
    current = repo_root / "results/fam_officehome_full_current_safe_v1_3seed/seed_0/metrics.csv"
    formal = repo_root / "results/fedadaptermanifold_formal_full_v1/office_home_selective_v3_3seed/seed_0/metrics.csv"
    current_rows = read_csv(current)
    formal_rows = read_csv(formal)
    fields = (
        "method",
        "mean_accuracy",
        "mean_loss",
        "subspace_failure_pearson_r",
        "adapter_incompatibility_failure_pearson_r",
    )
    diffs = []
    for left, right in zip(current_rows, formal_rows):
        for field in fields:
            if left.get(field) != right.get(field):
                diffs.append(f"{left.get('method')}:{field}")
    return {
        "current_seed0_metrics": str(current),
        "formal_seed0_metrics": str(formal),
        "rows_compared": str(min(len(current_rows), len(formal_rows))),
        "exact_match": str(bool(current_rows and formal_rows and not diffs)),
        "diff_fields": ";".join(diffs),
    }


def write_csv(path: Path, rows: list[dict[str, str]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def fmt(value: str) -> str:
    if value == "":
        return ""
    try:
        return f"{float(value):.4f}"
    except ValueError:
        return value


def build_audit(repo_root: Path, output_dir: Path) -> None:
    audit_rows: list[dict[str, str]] = []
    for run in RUNS:
        root = repo_root / run.path
        summary = find_summary(root)
        claims = find_claims(root)
        audit_rows.append(
            {
                "dataset": run.dataset,
                "role": run.role,
                "status": run.status,
                "path": run.path,
                "fedavg": method_accuracy(summary, METHODS["FedAvg"]),
                "geoagg": method_accuracy(summary, METHODS["GeoAgg"]),
                "subspace": method_accuracy(summary, METHODS["Subspace"]),
                "fam": method_accuracy(summary, METHODS["FAM"]),
                "selective": method_accuracy(summary, METHODS["Selective"]),
                "adapter_r": claim_value(claims, "adapter_incompatibility_failure_correlation")
                or metric_value(
                    summary,
                    "distance_receiver_residual_failure_correlation",
                    "",
                    "",
                    "d_adapter_incompatibility",
                ),
                "adapter_r_ci_low": claim_value(
                    claims,
                    "adapter_incompatibility_failure_correlation",
                    "ci_low",
                )
                or metric_value(
                    summary,
                    "distance_receiver_residual_failure_correlation",
                    "",
                    "",
                    "d_adapter_incompatibility",
                    "ci_low",
                ),
                "gain_vs_fedavg": claim_value(claims, "adapter_bank_gain_vs_fedavg")
                or metric_value(
                    summary,
                    "paired_accuracy_gain",
                    METHODS["Selective"],
                    METHODS["FedAvg"],
                    "mean_accuracy_gain",
                ),
                "gain_vs_fedavg_ci_low": claim_value(
                    claims,
                    "adapter_bank_gain_vs_fedavg",
                    "ci_low",
                )
                or metric_value(
                    summary,
                    "paired_accuracy_gain",
                    METHODS["Selective"],
                    METHODS["FedAvg"],
                    "mean_accuracy_gain",
                    "ci_low",
                ),
                "gain_vs_geoagg": claim_value(claims, "adapter_bank_gain_vs_fedgeo_agg")
                or metric_value(
                    summary,
                    "paired_accuracy_gain",
                    METHODS["Selective"],
                    METHODS["GeoAgg"],
                    "mean_accuracy_gain",
                ),
                "gain_vs_geoagg_ci_low": claim_value(
                    claims,
                    "adapter_bank_gain_vs_fedgeo_agg",
                    "ci_low",
                )
                or metric_value(
                    summary,
                    "paired_accuracy_gain",
                    METHODS["Selective"],
                    METHODS["GeoAgg"],
                    "mean_accuracy_gain",
                    "ci_low",
                ),
                "conflict_reduction_vs_fedavg": claim_value(
                    claims,
                    "update_conflict_reduction_vs_fedavg",
                )
                or metric_value(
                    summary,
                    "paired_risk_reduction",
                    METHODS["Selective"],
                    METHODS["FedAvg"],
                    "mean_update_conflict_vs_local",
                ),
                "conflict_reduction_vs_fedavg_ci_low": claim_value(
                    claims,
                    "update_conflict_reduction_vs_fedavg",
                    "ci_low",
                )
                or metric_value(
                    summary,
                    "paired_risk_reduction",
                    METHODS["Selective"],
                    METHODS["FedAvg"],
                    "mean_update_conflict_vs_local",
                    "ci_low",
                ),
                "note": run.note,
            }
        )

    officehome_check = verify_officehome_seed0(repo_root)
    supplement_rows: list[dict[str, str]] = []
    for row in read_csv(repo_root / "results/fam_pacs_rank_v5_3seed/rank_policy_summary.csv"):
        supplement_rows.append(
            {
                "evidence_type": "rank_policy",
                "variant": row.get("rank_policy", ""),
                "fedavg": row.get("fedavg_accuracy", ""),
                "geoagg": row.get("fedgeo_agg_accuracy", ""),
                "fam_or_selective": row.get("fedadapter_accuracy", ""),
                "gain_vs_fedavg": row.get("gain_vs_fedavg", ""),
                "gain_vs_geoagg": row.get("gain_vs_fedgeo_agg", ""),
                "adapter_r": row.get("adapter_incompatibility_failure_r", ""),
                "ci_low": row.get("adapter_incompatibility_failure_ci_low", ""),
                "note": "Resource heterogeneity; all policies repair FedAvg, while GeoAgg ceiling remains hard to exceed on PACS.",
            }
        )
    for row in read_csv(
        repo_root / "results/fam_pacs_geometry_source_v1_3seed/geometry_source_summary.csv"
    ):
        supplement_rows.append(
            {
                "evidence_type": "geometry_source",
                "variant": row.get("geometry_source", ""),
                "fedavg": row.get("fedavg_lora_acc", ""),
                "geoagg": row.get("fedgeo_agg_acc", ""),
                "fam_or_selective": row.get("selective_acc", ""),
                "gain_vs_fedavg": row.get("selective_minus_fedavg", ""),
                "gain_vs_geoagg": row.get("selective_minus_fedgeo_agg", ""),
                "adapter_r": row.get("adapter_incompatibility_failure_correlation", ""),
                "ci_low": row.get(
                    "adapter_incompatibility_failure_correlation_ci_low",
                    "",
                ),
                "note": "Geometry-source robustness; PACS FedGeo graphs are nearly isomorphic, so avoid source-superiority claims.",
            }
        )
    graph_control_rows = _graph_control_rows(repo_root)
    for row in graph_control_rows:
        supplement_rows.append(
            {
                "evidence_type": "graph_negative_control",
                "variant": row["variant"],
                "fedavg": "",
                "geoagg": "",
                "fam_or_selective": row["fedadapter_accuracy"],
                "gain_vs_fedavg": "",
                "gain_vs_geoagg": row["gain_vs_fedgeo_agg"],
                "adapter_r": row["adapter_incompatibility_r"],
                "ci_low": "",
                "note": row["interpretation"],
            }
        )
    reviewer_rows = [
        {
            "reviewer_question": "Is this just FedAvg-LoRA plus prototypes?",
            "answer_status": "covered",
            "evidence": "FedAvg-Lift, Subspace-Compatible, GeoAgg, pure FAM, safe FAM, routing, rank/resource and conflict diagnostics are all reported separately.",
        },
        {
            "reviewer_question": "Does subspace/adaptor incompatibility really explain failure?",
            "answer_status": "covered",
            "evidence": "Main datasets show positive receiver-normalized adapter incompatibility to FedAvg failure correlations; OfficeHome full-data r is about 0.756.",
        },
        {
            "reviewer_question": "Does the method beat geometry-only aggregation?",
            "answer_status": "covered_with_nuance",
            "evidence": "OfficeCaltech and OfficeHome support gains beyond GeoAgg; PACS/BloodMNIST saturate at a local/GeoAgg ceiling, so report no-regret and conflict reduction there.",
        },
        {
            "reviewer_question": "Are results tied to one data source?",
            "answer_status": "mostly_covered",
            "evidence": "PACS, OfficeCaltech, OfficeHome full-data, DomainNetMini hard case, and BloodMNIST medical label skew are included.",
        },
        {
            "reviewer_question": "Was OfficeHome run with the current loader?",
            "answer_status": "covered_with_verification_note",
            "evidence": f"Current full-data seed0 exactly matches formal full-data seed0: {officehome_check['exact_match']}; all formal seeds log full effective sample counts.",
        },
        {
            "reviewer_question": "Does graph sharing itself help?",
            "answer_status": "covered_with_nuance",
            "evidence": "Pure no-smoothing FAM helps on OfficeCaltech and repairs PACS FedAvg, but safe/no-regret routing is the main method where graph-only mixing saturates or hurts.",
        },
    ]

    missing_rows = [
        {
            "priority": "P0",
            "experiment": "No blocking core experiment",
            "reason": "Core diagnostic, main accuracy/conflict results, rank/source supplements, and graph negative controls are now covered.",
            "status": "no_blocking_gap",
        },
        {
            "priority": "P1",
            "experiment": "Optional current-code OfficeHome seed1/seed2 rerun",
            "reason": "Not strictly required after full-data effective logs and exact seed0 verification, but it would remove a wording caveat.",
            "status": "optional_if_machine_stable",
        },
        {
            "priority": "P1",
            "experiment": "5-seed PACS and OfficeCaltech",
            "reason": "Statistical polish for PR; not necessary for deciding whether the core mechanism is supported.",
            "status": "optional",
        },
    ]

    audit_fields = [
        "dataset",
        "role",
        "status",
        "path",
        "fedavg",
        "geoagg",
        "subspace",
        "fam",
        "selective",
        "adapter_r",
        "adapter_r_ci_low",
        "gain_vs_fedavg",
        "gain_vs_fedavg_ci_low",
        "gain_vs_geoagg",
        "gain_vs_geoagg_ci_low",
        "conflict_reduction_vs_fedavg",
        "conflict_reduction_vs_fedavg_ci_low",
        "note",
    ]
    write_csv(output_dir / "result_audit.csv", audit_rows, audit_fields)
    write_csv(
        output_dir / "officehome_current_verification.csv",
        [officehome_check],
        list(officehome_check.keys()),
    )
    write_csv(
        output_dir / "reviewer_objection_matrix.csv",
        reviewer_rows,
        ["reviewer_question", "answer_status", "evidence"],
    )
    write_csv(
        output_dir / "missing_experiment_plan.csv",
        missing_rows,
        ["priority", "experiment", "reason", "status"],
    )
    write_csv(
        output_dir / "supplement_evidence.csv",
        supplement_rows,
        [
            "evidence_type",
            "variant",
            "fedavg",
            "geoagg",
            "fam_or_selective",
            "gain_vs_fedavg",
            "gain_vs_geoagg",
            "adapter_r",
            "ci_low",
            "note",
        ],
    )
    write_csv(
        output_dir / "graph_negative_control.csv",
        graph_control_rows,
        [
            "experiment",
            "variant",
            "graph_mode",
            "self_weight",
            "fedadapter_accuracy",
            "gain_vs_fedgeo_agg",
            "update_conflict_reduction_vs_fedgeo_agg",
            "adapter_incompatibility_r",
            "interpretation",
        ],
    )

    lines = [
        "# FedAdapterManifold PR Evidence Audit v4",
        "",
        "## Main Read",
        "",
        "- Core idea is supported: adapter incompatibility/subspace conflict correlates with FedAvg-LoRA failure, and geometry-conditioned adapter routing reduces update conflict.",
        "- Accuracy gains are strongest on OfficeCaltech and OfficeHome full-data; PACS and BloodMNIST mostly saturate at a local/GeoAgg ceiling, where the right claim is FedAvg repair and no-regret conflict reduction.",
        "- DomainNetMini remains a hard-case supplement: small accuracy gain, but positive subspace/failure diagnostic and strong conflict reduction.",
        "- OfficeHome is now usable with a verification note: formal 3-seed runs log full effective sample counts, and current-code full-data seed0 exactly reproduces formal seed0 metrics.",
        "",
        "## Result Table",
        "",
        "| Dataset | Role | Status | FedAvg | GeoAgg | FAM | Selective | r | Note |",
        "|---|---|---|---:|---:|---:|---:|---:|---|",
    ]
    for row in audit_rows:
        lines.append(
            "| {dataset} | {role} | {status} | {fedavg} | {geoagg} | {fam} | {selective} | {adapter_r} | {note} |".format(
                dataset=row["dataset"],
                role=row["role"],
                status=row["status"],
                fedavg=fmt(row["fedavg"]),
                geoagg=fmt(row["geoagg"]),
                fam=fmt(row["fam"]),
                selective=fmt(row["selective"]),
                adapter_r=fmt(row["adapter_r"]),
                note=row["note"],
            )
        )
    lines.extend(
        [
            "",
            "## Supplement Evidence",
            "",
            "| Type | Variant | FedAvg | GeoAgg | FAM/Selective | Gain vs FedAvg | r | Note |",
            "|---|---|---:|---:|---:|---:|---:|---|",
        ]
    )
    for row in supplement_rows:
        lines.append(
            "| {evidence_type} | {variant} | {fedavg} | {geoagg} | {fam_or_selective} | {gain_vs_fedavg} | {adapter_r} | {note} |".format(
                evidence_type=row["evidence_type"],
                variant=row["variant"],
                fedavg=fmt(row["fedavg"]),
                geoagg=fmt(row["geoagg"]),
                fam_or_selective=fmt(row["fam_or_selective"]),
                gain_vs_fedavg=fmt(row["gain_vs_fedavg"]),
                adapter_r=fmt(row["adapter_r"]),
                note=row["note"],
            )
        )
    lines.extend(
        [
            "",
            "### Graph Negative-Control Read",
            "",
            "- Safety-gated OfficeCaltech graph controls collapse to the same result, which means the gate is absorbing graph differences.",
            "- Forced raw graph sharing hurts; `self/no-sharing` is best under the harsh control, so raw adjacency is not the contribution by itself.",
            "- With a moderate self anchor, graph variants become no-regret and indistinguishable. The correct paper claim is therefore safe geometry-conditioned adapter routing/personalization, not naked graph averaging.",
        ]
    )
    lines.extend(
        [
            "",
            "## OfficeHome Verification",
            "",
            f"- Current full-data seed0 metrics: `{officehome_check['current_seed0_metrics']}`",
            f"- Formal full-data seed0 metrics: `{officehome_check['formal_seed0_metrics']}`",
            f"- Exact metric match on compared fields: `{officehome_check['exact_match']}`",
            f"- Rows compared: `{officehome_check['rows_compared']}`",
            "",
            "## Remaining Gaps",
            "",
        ]
    )
    for row in missing_rows:
        lines.append(
            f"- {row['priority']} `{row['experiment']}`: {row['reason']} ({row['status']})"
        )
    lines.append("")
    (output_dir / "pr_evidence_audit.md").write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def _graph_control_rows(repo_root: Path) -> list[dict[str, str]]:
    experiments = [
        (
            "safety_gated",
            repo_root / "results/fam_officecaltech_graph_negative_control_v1/graph_active_summary.csv",
            "Safety gate absorbs graph differences; use as no-overclaim evidence.",
        ),
        (
            "forced_raw_graph",
            repo_root / "results/fam_officecaltech_graph_negative_control_v2_forced/graph_active_summary.csv",
            "Forced raw graph sharing hurts on OfficeCaltech; this supports the need for safe/personalized routing.",
        ),
        (
            "self_anchor_0p25",
            repo_root / "results/fam_officecaltech_graph_negative_control_v3_self025/graph_active_summary.csv",
            "Moderate self anchoring makes graph variants no-regret and indistinguishable.",
        ),
    ]
    rows: list[dict[str, str]] = []
    for experiment, path, interpretation in experiments:
        for row in read_csv(path):
            graph_mode = row.get("graph_mode", "")
            self_weight = row.get("adapter_graph_self_weight", "")
            rows.append(
                {
                    "experiment": experiment,
                    "variant": f"{experiment}:{graph_mode}:self{self_weight}",
                    "graph_mode": graph_mode,
                    "self_weight": self_weight,
                    "fedadapter_accuracy": row.get("fedadapter_accuracy", ""),
                    "gain_vs_fedgeo_agg": row.get("gain_vs_fedgeo_agg", ""),
                    "update_conflict_reduction_vs_fedgeo_agg": row.get(
                        "update_conflict_reduction_vs_fedgeo_agg",
                        "",
                    ),
                    "adapter_incompatibility_r": row.get("adapter_incompatibility_r", ""),
                    "interpretation": interpretation,
                }
            )
    return rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        default="results/fam_pr_evidence_audit_v3",
        help="Directory where audit CSV/Markdown files will be written.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    repo_root = Path.cwd()
    build_audit(repo_root, Path(args.output_dir))


if __name__ == "__main__":
    main()
