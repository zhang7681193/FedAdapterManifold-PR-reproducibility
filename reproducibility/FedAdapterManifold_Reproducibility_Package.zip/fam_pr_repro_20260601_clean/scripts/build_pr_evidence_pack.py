from __future__ import annotations

import argparse
import csv
import math
import os
from pathlib import Path
from typing import Iterable


MAIN_RUNS = [
    {
        "dataset": "PACS",
        "root": "results/fam_pacs_manifest_fedavg_fedper_fam_5seed_v1",
        "role": "5-seed ResNet18-pretrained with shared-geometry-manifest FedAvg geometry and FedPer-FAM hybrid",
    },
    {
        "dataset": "OfficeCaltech",
        "root": "results/fam_officecaltech_neighbor_selector_fedrot_w050_v1",
        "role": "5-seed ResNet18-pretrained plus strong PEFT-FL baselines, FedRot-LoRA alignment control, and equal local/geometry-neighbor selector scoring",
    },
    {
        "dataset": "OfficeHomeFull",
        "root": "results/fam_officehome_ditto_fam_guarded_audit_5seed_v1",
        "role": "5-seed OfficeHome full-data guarded Ditto-FAM no-regret audit",
    },
    {
        "dataset": "DomainNetMini",
        "root": "results/fam_domainnetmini_manifest_fedavg_fedper_fam_5seed_v1",
        "role": "5-seed hard dataset CLIP text-head run with shared-geometry-manifest FedAvg geometry",
    },
    {
        "dataset": "BloodMNIST",
        "root": "results/fam_blood_manifest_fedavg_fedper_fam_5seed_v1",
        "role": "5-seed medical label-skew application with shared-geometry-manifest FedAvg geometry",
    },
]

FEDGEO_GEOMETRY_REPORT_DIR = Path(
    os.environ.get("GEOMETRY_REPORT_DIR", "results/fedadapter_geometry_reports")
)


METHOD_ORDER = [
    "FedAdapterManifold-StrongSelective",
    "FedAdapterManifold-Selective",
    "FedAdapterManifold",
    "Ditto-FAM-Selective",
    "Ditto-FAM",
    "FedPer-FAM-Selective",
    "FedPer-FAM",
    "FedPer-LoRA",
    "pFedMe-LoRA",
    "SCAFFOLD-LoRA",
    "FedProto-LoRA",
    "FedAMP-LoRA",
    "Ditto-LoRA",
    "Clustered-LoRA",
    "FedAvg-Lift",
    "FedRot-LoRA",
    "FedProx-LoRA",
    "FedGeo-Agg",
    "FedAvg-LoRA",
    "Local-LoRA",
]


def main() -> int:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    accuracy_rows: list[dict] = []
    ranking_rows: list[dict] = []
    diagnostic_rows: list[dict] = []
    significance_rows: list[dict] = []
    complexity_rows: list[dict] = []

    for run in MAIN_RUNS:
        root = Path(run["root"])
        summary = read_csv(root / "multiseed_summary.csv")
        claims = read_csv(root / "multiseed_claim_report.csv")
        per_client = read_csv(root / "multiseed_per_client_metrics.csv")
        if not summary:
            accuracy_rows.append(
                {
                    "dataset": run["dataset"],
                    "method": "",
                    "mean_accuracy": "",
                    "std": "",
                    "num_observations": "",
                    "source": run["root"],
                    "status": "missing_summary",
                    "note": run["role"],
                }
            )
            continue

        method_rows = [
            row
            for row in summary
            if row.get("test") == "method_accuracy" and row.get("method") in METHOD_ORDER
        ]
        for row in method_rows:
            accuracy_rows.append(
                {
                    "dataset": run["dataset"],
                    "method": row.get("method", ""),
                    "mean_accuracy": row.get("estimate", ""),
                    "std": row.get("std", ""),
                    "num_observations": row.get("num_observations", ""),
                    "source": run["root"],
                    "status": "usable",
                    "note": run["role"],
                }
            )
        ranked = sorted(method_rows, key=lambda row: fnum(row.get("estimate")), reverse=True)
        for rank, row in enumerate(ranked, start=1):
            ranking_rows.append(
                {
                    "dataset": run["dataset"],
                    "rank": rank,
                    "method": row.get("method", ""),
                    "mean_accuracy": row.get("estimate", ""),
                    "source": run["root"],
                }
            )

        diagnostic_rows.extend(claim_rows(run["dataset"], run["root"], claims, summary))
        if per_client:
            for method in [
                "FedAdapterManifold-StrongSelective",
                "FedAdapterManifold-Selective",
                "FedAdapterManifold",
                "FedPer-FAM-Selective",
                "FedPer-FAM",
                "FedPer-LoRA",
                "FedAMP-LoRA",
                "FedAvg-Lift",
                "FedRot-LoRA",
            ]:
                for baseline in ["FedAvg-LoRA", "FedGeo-Agg"]:
                    if has_method(per_client, method) and has_method(per_client, baseline):
                        significance_rows.append(
                            paired_stats(run["dataset"], run["root"], per_client, method, baseline)
                        )
        complexity_rows.append(complexity_row(run["dataset"], run["root"], root))

    write_csv(output_dir / "main_accuracy_with_strong_baselines.csv", accuracy_rows)
    write_csv(output_dir / "method_rankings.csv", ranking_rows)
    write_csv(output_dir / "mechanism_diagnostics.csv", diagnostic_rows)
    write_csv(output_dir / "paired_significance.csv", significance_rows)
    write_csv(output_dir / "complexity_and_communication.csv", complexity_rows)
    write_csv(output_dir / "calibration_gate_summary.csv", calibration_rows())
    write_csv(output_dir / "distance_ablation_summary.csv", distance_ablation_rows())
    write_csv(output_dir / "graph_negative_control_summary.csv", graph_control_rows())
    geometry_quality = fedgeo_geometry_quality_rows()
    geometry_manifest = fedgeo_geometry_manifest_rows()
    write_csv(output_dir / "geometry_quality_overview.csv", geometry_quality)
    write_csv(output_dir / "geometry_manifest.csv", geometry_manifest)
    write_csv(output_dir / "fedgeo_geometry_quality_overview.csv", geometry_quality)
    write_csv(output_dir / "fedgeo_geometry_manifest.csv", geometry_manifest)
    vfm_rows = end_to_end_vfm_rows()
    write_csv(output_dir / "end_to_end_vfm_summary.csv", vfm_rows)
    write_csv(output_dir / "end_to_end_vfm_smoke.csv", vfm_rows)
    write_csv(output_dir / "pretrained_backbone_audit.csv", pretrained_backbone_rows())
    write_csv(output_dir / "dinov2_evidence_summary.csv", dinov2_evidence_rows())
    write_csv(output_dir / "vfm_anchor_claims.csv", vfm_anchor_claim_rows())
    write_csv(output_dir / "seven_item_status.csv", seven_item_status_rows())
    write_markdown(output_dir / "pr_evidence_report.md", accuracy_rows, diagnostic_rows, ranking_rows)
    return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build PR evidence pack.")
    parser.add_argument("--output-dir", default="results/fam_pr_evidence_pack_v1")
    return parser.parse_args()


def read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    if not fieldnames:
        fieldnames = ["empty"]
        rows = [{"empty": ""}]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def claim_rows(dataset: str, source: str, claims: list[dict], summary: list[dict]) -> list[dict]:
    ids = [
        "adapter_incompatibility_failure_correlation",
        "adapter_bank_gain_vs_fedavg",
        "adapter_bank_gain_vs_fedgeo_agg",
        "update_conflict_reduction_vs_fedavg",
        "worst_client_risk_reduction_vs_fedgeo_agg",
        "update_conflict_reduction_vs_fedgeo_agg",
    ]
    rows: list[dict] = []
    for claim_id in ids:
        claim = find(claims, "claim_id", claim_id)
        rows.append(
            {
                "dataset": dataset,
                "claim_id": claim_id,
                "supports": claim.get("supports", "") if claim else "",
                "estimate": claim.get("estimate", "") if claim else "",
                "ci_low": claim.get("ci_low", "") if claim else "",
                "ci_high": claim.get("ci_high", "") if claim else "",
                "n": claim.get("num_observations", "") if claim else "",
                "narrative_action": claim.get("narrative_action", "") if claim else "",
                "source": source,
            }
        )
    if not claims:
        row = find_metric(summary, "distance_receiver_residual_failure_correlation", "", "", "d_adapter_incompatibility")
        if row:
            rows.append(
                {
                    "dataset": dataset,
                    "claim_id": "adapter_incompatibility_failure_correlation_from_summary",
                    "supports": row.get("supports", ""),
                    "estimate": row.get("estimate", ""),
                    "ci_low": row.get("ci_low", ""),
                    "ci_high": row.get("ci_high", ""),
                    "n": row.get("num_observations", ""),
                    "narrative_action": "summary_only",
                    "source": source,
                }
            )
    return rows


def paired_stats(dataset: str, source: str, rows: list[dict], method: str, baseline: str) -> dict:
    by_key: dict[tuple[str, str], dict[str, float]] = {}
    for row in rows:
        key = (row.get("source_seed") or row.get("seed", ""), row.get("client_id", ""))
        by_key.setdefault(key, {})
        if row.get("method") in {method, baseline}:
            by_key[key][row.get("method", "")] = fnum(row.get("accuracy"))
    diffs = [vals[method] - vals[baseline] for vals in by_key.values() if method in vals and baseline in vals]
    mean = sum(diffs) / len(diffs) if diffs else float("nan")
    ci_low, ci_high = bootstrap_ci(diffs)
    p_value = sign_flip_p_value(diffs)
    return {
        "dataset": dataset,
        "method": method,
        "baseline": baseline,
        "paired_units": len(diffs),
        "mean_accuracy_diff": mean,
        "ci_low": ci_low,
        "ci_high": ci_high,
        "sign_flip_p_value": p_value,
        "supports_positive_gain": bool(diffs and mean > 0.0 and ci_low > 0.0),
        "source": source,
    }


def bootstrap_ci(values: list[float], reps: int = 4000) -> tuple[float, float]:
    if not values:
        return float("nan"), float("nan")
    if len(values) == 1:
        return values[0], values[0]
    rng = deterministic_rng(17 + len(values))
    means = []
    n = len(values)
    for _ in range(reps):
        total = 0.0
        for _ in range(n):
            total += values[int(next(rng) * n) % n]
        means.append(total / n)
    means.sort()
    return means[int(0.025 * reps)], means[int(0.975 * reps)]


def sign_flip_p_value(values: list[float], reps: int = 8192) -> float:
    if not values:
        return float("nan")
    observed = abs(sum(values) / len(values))
    if len(values) <= 20:
        total = 1 << len(values)
        extreme = 0
        for mask in range(total):
            flipped = 0.0
            for idx, value in enumerate(values):
                flipped += value if (mask >> idx) & 1 else -value
            if abs(flipped / len(values)) >= observed - 1e-12:
                extreme += 1
        return extreme / total
    rng = deterministic_rng(913 + len(values))
    extreme = 0
    for _ in range(reps):
        flipped = sum(value if next(rng) >= 0.5 else -value for value in values)
        if abs(flipped / len(values)) >= observed - 1e-12:
            extreme += 1
    return extreme / reps


def deterministic_rng(seed: int):
    state = int(seed) & 0x7FFFFFFF
    while True:
        state = (1103515245 * state + 12345) & 0x7FFFFFFF
        yield state / 0x80000000


def complexity_row(dataset: str, source: str, root: Path) -> dict:
    config = read_simple_yaml(next_seed_file(root, "config.yaml"))
    rank = int(float(config.get("rank", 0) or config.get("max_rank", 0) or 0))
    feature_dim = int(float(config.get("effective_feature_dim", 0) or 0))
    classes = int(float(config.get("effective_num_classes", 0) or config.get("num_classes", 0) or 0))
    if feature_dim and classes and rank:
        adapter_params = rank * (feature_dim + classes)
        full_delta_params = feature_dim * classes
    else:
        adapter_params = ""
        full_delta_params = ""
    return {
        "dataset": dataset,
        "feature_backbone": config.get("feature_backbone", ""),
        "rank": rank or "",
        "feature_dim": feature_dim or "",
        "num_classes": classes or "",
        "single_lora_adapter_params": adapter_params,
        "full_delta_params": full_delta_params,
        "fedavg_lora_upload_per_client": "r*(d+C)",
        "fedavg_lift_server_merge": "average full Delta_W then SVD-project; can transmit LoRA factors or full delta depending implementation",
        "adapter_bank_storage": "shared + K domain adapters + optional personal adapters",
        "source": source,
    }


def next_seed_file(root: Path, name: str) -> Path:
    for path in sorted(root.glob(f"seed_*/{name}")):
        return path
    return root / name


def read_simple_yaml(path: Path) -> dict[str, str]:
    out: dict[str, str] = {}
    if not path.exists():
        return out
    for line in path.read_text(encoding="utf-8").splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        value = value.strip().strip("'\"")
        out[key.strip()] = value
    return out


def calibration_rows() -> list[dict]:
    rows = read_csv(Path("results/fam_officecaltech_calibration_gate_ablation_v1/calibration_gate_accuracy.csv"))
    return rows or [{"status": "missing", "source": "results/fam_officecaltech_calibration_gate_ablation_v1"}]


def distance_ablation_rows() -> list[dict]:
    out: list[dict] = []
    for dataset, path in [
        ("OfficeCaltech", "results/fam_officecaltech_distance_ablation_v1/distance_ablation_accuracy.csv"),
        ("DomainNetMini", "results/fam_domainnetmini_distance_ablation_v1/distance_ablation_accuracy.csv"),
    ]:
        for row in read_csv(Path(path)):
            row["dataset"] = dataset
            row["source"] = path
            out.append(row)
    return out or [{"status": "missing"}]


def graph_control_rows() -> list[dict]:
    out: list[dict] = []
    for label, path in [
        ("safe_gated", "results/fam_officecaltech_graph_negative_control_v1/graph_active_summary.csv"),
        ("forced_raw", "results/fam_officecaltech_graph_negative_control_v2_forced/graph_active_summary.csv"),
        ("self_anchor_0p25", "results/fam_officecaltech_graph_negative_control_v3_self025/graph_active_summary.csv"),
    ]:
        for row in read_csv(Path(path)):
            row["control_group"] = label
            row["source"] = path
            out.append(row)
    return out or [{"status": "missing"}]


def fedgeo_geometry_quality_rows() -> list[dict]:
    path = FEDGEO_GEOMETRY_REPORT_DIR / "fedadapter_geometry_quality_overview.csv"
    rows = read_csv(path)
    for row in rows:
        row["source"] = str(path)
    return rows or [{"status": "missing", "source": str(path)}]


def fedgeo_geometry_manifest_rows() -> list[dict]:
    path = FEDGEO_GEOMETRY_REPORT_DIR / "fedadapter_geometry_manifest.csv"
    rows = read_csv(path)
    for row in rows:
        row["source"] = str(path)
    return rows or [{"status": "missing", "source": str(path)}]


def end_to_end_vfm_rows() -> list[dict]:
    rows: list[dict] = []
    for dataset, root in [
        ("DomainNetMini60", Path("results/fam_clip_vit_lora_federated_domainnetmini_60class_5seed_v2")),
        ("DomainNetMini60-8shot", Path("results/fam_clip_vit_lora_federated_domainnetmini_60class_8shot_5seed_v1")),
        ("PACS7", Path("results/fam_clip_vit_lora_federated_pacs_7class_5seed_v1")),
        ("OfficeCaltech10", Path("results/fam_clip_vit_lora_federated_officecaltech_10class_5seed_v1")),
    ]:
        for row in read_csv(root / "multiseed_metrics.csv"):
            row["dataset_alias"] = dataset
            row["source"] = str(root / "multiseed_metrics.csv")
            row["status"] = "usable_federated_end_to_end_vfm"
            row["evidence_type"] = "5-seed_federated_CLIP_ViT_attention_LoRA"
            rows.append(row)
        for row in read_csv(root / "paired_significance.csv"):
            row["dataset_alias"] = dataset
            row["source"] = str(root / "paired_significance.csv")
            row["status"] = "usable_federated_end_to_end_vfm"
            row["evidence_type"] = "paired_client_seed_gain"
            rows.append(row)
        for row in read_csv(root / "subspace_correlation_summary.csv"):
            row["dataset_alias"] = dataset
            row["source"] = str(root / "subspace_correlation_summary.csv")
            row["status"] = "usable_federated_end_to_end_vfm"
            row["evidence_type"] = "vfm_failure_diagnostic"
            rows.append(row)
    main_root = Path("results/fam_clip_vit_lora_end_to_end_main_v1")
    for row in read_csv(main_root / "multiseed_metrics.csv"):
        row["source"] = str(main_root / "multiseed_metrics.csv")
        row["status"] = "usable_main_supplement"
        row["evidence_type"] = "6-domain_20-class_3-seed_CLIP_ViT_attention_LoRA"
        rows.append(row)
    for row in read_csv(main_root / "vfm_lora_gain_summary.csv"):
        row["source"] = str(main_root / "vfm_lora_gain_summary.csv")
        row["status"] = "usable_main_supplement"
        row["evidence_type"] = "paired_seed_gain"
        rows.append(row)
    smoke_path = Path("results/fam_clip_vit_lora_end_to_end_smoke_v1/metrics.csv")
    for row in read_csv(smoke_path):
        row["source"] = str(smoke_path)
        row["status"] = "usable_smoke_only"
        row["evidence_type"] = "tiny_codepath_smoke"
        rows.append(row)
    return rows or [{"status": "missing", "source": str(main_root)}]


def pretrained_backbone_rows() -> list[dict]:
    path = Path("results/backbone_visual_summary_dynamic_v14.csv")
    rows = read_csv(path)
    keep = []
    for row in rows:
        backbone = row.get("feature_backbone", "")
        if backbone in {
            "CLIP ViT-B/32",
            "CLIP ViT-B/32 auto-safe",
            "ResNet18-pretrained",
        }:
            row["source"] = str(path)
            row["status"] = "usable_pretrained_backbone_audit"
            keep.append(row)
    return keep or [{"status": "missing", "source": str(path)}]


def dinov2_evidence_rows() -> list[dict]:
    rows: list[dict] = []
    for dataset, root, status in [
        (
            "PACS",
            Path("results/fam_dinov2_pacs_calib20_noregret_5seed_v1"),
            "usable_5seed_dinov2_calib20_anchored_no_regret_audit",
        ),
        (
            "OfficeHome",
            Path("results/fam_dinov2_officehome_full_calib20_noregret_5seed_v1"),
            "usable_5seed_dinov2_full_calib20_anchored_no_regret_audit",
        ),
    ]:
        for row in read_csv(root / "multiseed_summary.csv"):
            row["dataset_alias"] = dataset
            row["source"] = str(root / "multiseed_summary.csv")
            row["status"] = status
            row["evidence_type"] = "DINOv2-S/14 frozen-feature LoRA audit"
            rows.append(row)
        for row in read_csv(root / "multiseed_claim_report.csv"):
            row["dataset_alias"] = dataset
            row["source"] = str(root / "multiseed_claim_report.csv")
            if row.get("claim_id") == "overall_core_support" and row.get("supports") == "False":
                row["status"] = "generic_claim_report_saturation_flag_not_vfm_selector_failure"
                row["narrative_action"] = "use_paired_anchor_rows_for_vfm_claim"
            else:
                row["status"] = status
            row["evidence_type"] = "DINOv2-S/14 mechanism diagnostics"
            rows.append(row)
        for row in read_csv(root / "dinov2_officehome_calib20_paired_summary.csv"):
            row["dataset_alias"] = dataset
            row["source"] = str(root / "dinov2_officehome_calib20_paired_summary.csv")
            row["status"] = status
            row["evidence_type"] = "DINOv2-S/14 anchored no-regret paired selector gain"
            rows.append(row)
        for row in read_csv(root / "dinov2_pacs_calib20_paired_summary.csv"):
            row["dataset_alias"] = dataset
            row["source"] = str(root / "dinov2_pacs_calib20_paired_summary.csv")
            row["status"] = status
            row["evidence_type"] = "DINOv2-S/14 anchored no-regret paired selector gain"
            rows.append(row)
        if not (root / "multiseed_summary.csv").exists():
            completed = len(list(root.glob("seed_*/metrics.csv")))
            rows.append(
                {
                    "dataset_alias": dataset,
                    "source": str(root),
                    "status": "running_or_missing",
                    "evidence_type": "DINOv2-S/14 frozen-feature LoRA audit",
                    "completed_seed_metrics": completed,
                }
            )
    for dataset, root in [
        ("OfficeHome", Path("results/fam_dinov2_officehome_capped_5seed_v1")),
        ("OfficeHome", Path("results/fam_dinov2_officehome_capped_noregret_5seed_v1")),
        ("OfficeHome", Path("results/fam_dinov2_officehome_capped_noregret_debug_seed0")),
    ]:
        rows.append(
            {
                "dataset_alias": dataset,
                "source": str(root),
                "status": "excluded_exploratory_capped_split",
                "evidence_type": "invalid_for_main_65class_officehome_claim",
                "reason": "The 240/160 capped OfficeHome-DINOv2 protocol is too sparse for 65 classes; use the full-data calib20 anchored-no-regret run instead.",
                "completed_seed_metrics": len(list(root.glob("seed_*/metrics.csv"))) if root.exists() else 0,
            }
        )
    return rows or [{"status": "missing"}]


def vfm_anchor_claim_rows() -> list[dict]:
    rows: list[dict] = []
    pacs_root = Path("results/fam_dinov2_pacs_calib20_noregret_5seed_v1")
    for row in read_csv(pacs_root / "dinov2_pacs_calib20_paired_summary.csv"):
        comparison = row.get("comparison", "")
        baseline = {
            "fedavg": "FedAvg-LoRA",
            "geoagg": "GeoAgg",
            "scaffold": "SCAFFOLD-LoRA",
            "fedavg_lift": "FedAvg-Lift",
            "fedper": "FedPer-LoRA",
        }.get(comparison.replace("StrongSelective_vs_", ""), comparison.replace("StrongSelective_vs_", ""))
        rows.append(
            {
                "dataset": "PACS",
                "backbone": "DINOv2-S/14 frozen features",
                "split": "PACS 7-class, 20% held-out calibration",
                "method": "FedAdapterManifold-StrongSelective",
                "baseline": baseline,
                "paired_units": row.get("paired_units", ""),
                "mean_gain": row.get("mean_gain", ""),
                "ci_low": row.get("ci_low", ""),
                "ci_high": row.get("ci_high", ""),
                "sign_p_two_sided": row.get("sign_p_two_sided", ""),
                "signflip_p_two_sided": row.get("signflip_p_two_sided", ""),
                "supports": bool(fnum(row.get("mean_gain")) > 0 and fnum(row.get("ci_low")) > 0),
                "claim_scope": "anchored_no_regret_vfm_selector",
                "narrative_action": "claim_as_supported" if fnum(row.get("ci_low")) > 0 else "report_as_mean_ceiling_or_caveat",
                "source": str(pacs_root / "dinov2_pacs_calib20_paired_summary.csv"),
            }
        )
    office_root = Path("results/fam_dinov2_officehome_full_calib20_noregret_5seed_v1")
    for row in read_csv(office_root / "dinov2_officehome_calib20_paired_summary.csv"):
        comparison = row.get("comparison", "")
        baseline = {
            "fedavg": "FedAvg-LoRA",
            "geoagg": "GeoAgg",
            "ditto": "Ditto-LoRA",
            "selective": "FedAdapterManifold-Selective",
        }.get(comparison.replace("StrongSelective_vs_", ""), comparison.replace("StrongSelective_vs_", ""))
        rows.append(
            {
                "dataset": "OfficeHome",
                "backbone": "DINOv2-S/14 frozen features",
                "split": "full OfficeHome 65-class, 20% held-out calibration",
                "method": "FedAdapterManifold-StrongSelective",
                "baseline": baseline,
                "paired_units": row.get("paired_units", ""),
                "mean_gain": row.get("mean_gain", ""),
                "ci_low": row.get("ci_low", ""),
                "ci_high": row.get("ci_high", ""),
                "sign_p_two_sided": row.get("sign_p_two_sided", ""),
                "signflip_p_two_sided": row.get("signflip_p_two_sided", ""),
                "supports": bool(fnum(row.get("mean_gain")) > 0 and fnum(row.get("ci_low")) > 0),
                "claim_scope": "anchored_no_regret_vfm_selector",
                "narrative_action": "claim_as_supported" if fnum(row.get("ci_low")) > 0 else "report_as_no_regret_or_caveat",
                "source": str(office_root / "dinov2_officehome_calib20_paired_summary.csv"),
            }
        )
    office_clip_root = Path("results/fam_clip_officehome_full_calib20_noregret_5seed_v2")
    for row in read_csv(office_clip_root / "clip_officehome_calib20_paired_summary.csv"):
        comparison = row.get("comparison", "")
        baseline = {
            "fedavg": "FedAvg-LoRA",
            "geoagg": "GeoAgg",
            "ditto": "Ditto-LoRA",
            "selective": "FedAdapterManifold-Selective",
        }.get(comparison.replace("StrongSelective_vs_", "").replace("DittoFAM_vs_", ""), comparison)
        rows.append(
            {
                "dataset": "OfficeHome",
                "backbone": "CLIP ViT-B/16 frozen features",
                "split": "full OfficeHome 65-class, 20-round, 20% held-out calibration",
                "method": "FedAdapterManifold-StrongSelective" if comparison.startswith("StrongSelective") else "Ditto-FAM",
                "baseline": baseline,
                "paired_units": row.get("paired_units", ""),
                "mean_gain": row.get("mean_gain", ""),
                "ci_low": row.get("ci_low", ""),
                "ci_high": row.get("ci_high", ""),
                "sign_p_two_sided": row.get("sign_p_two_sided", ""),
                "signflip_p_two_sided": row.get("signflip_p_two_sided", ""),
                "supports": bool(fnum(row.get("mean_gain")) > 0 and fnum(row.get("ci_low")) > 0),
                "claim_scope": "full_data_multiround_clip_vit_feature_lora",
                "narrative_action": "claim_as_supported" if fnum(row.get("ci_low")) > 0 else "report_as_no_regret_or_caveat",
                "source": str(office_clip_root / "clip_officehome_calib20_paired_summary.csv"),
            }
        )
    for dataset, root in [
        ("DomainNetMini60", Path("results/fam_clip_vit_lora_federated_domainnetmini_60class_5seed_v2")),
        ("DomainNetMini60-8shot", Path("results/fam_clip_vit_lora_federated_domainnetmini_60class_8shot_5seed_v1")),
        ("PACS7", Path("results/fam_clip_vit_lora_federated_pacs_7class_5seed_v1")),
        ("OfficeCaltech10", Path("results/fam_clip_vit_lora_federated_officecaltech_10class_5seed_v1")),
    ]:
        for row in read_csv(root / "paired_significance.csv"):
            if row.get("method") != "FedAdapterManifold-Selective-CLIP-LoRA":
                continue
            if row.get("baseline") not in {"FedAvg-CLIP-LoRA", "FedGeo-Agg-CLIP-LoRA"}:
                continue
            baseline = row.get("baseline", "")
            if baseline == "FedGeo-Agg-CLIP-LoRA":
                baseline = "GeoAgg-CLIP-LoRA"
            rows.append(
                {
                    "dataset": dataset,
                    "backbone": "CLIP ViT-B/16 attention-LoRA",
                    "split": "federated end-to-end VFM split",
                    "method": row.get("method", ""),
                    "baseline": baseline,
                    "paired_units": row.get("paired_units", ""),
                    "mean_gain": row.get("mean_accuracy_diff", ""),
                    "ci_low": row.get("ci_low", ""),
                    "ci_high": row.get("ci_high", ""),
                    "supports": row.get("supports_positive_gain", ""),
                    "claim_scope": "end_to_end_clip_vit_lora",
                    "narrative_action": "claim_as_supported" if row.get("supports_positive_gain") == "True" else "report_as_high_ceiling_caveat",
                    "source": str(root / "paired_significance.csv"),
                }
            )
    rows.append(
        {
            "dataset": "OfficeHome",
            "backbone": "DINOv2-S/14 frozen features",
            "split": "capped 240/160 exploratory split",
            "method": "",
            "baseline": "",
            "supports": False,
            "claim_scope": "excluded",
            "narrative_action": "do_not_use_as_main_evidence",
            "source": "results/fam_dinov2_officehome_capped_*",
            "reason": "Sample cap is too small for 65-class OfficeHome; retained only to document the failed audit path.",
        }
    )
    return rows or [{"status": "missing"}]


def seven_item_status_rows() -> list[dict]:
    return [
        {
            "item": "Strong PEFT-FL baselines",
            "status": "completed_for_main_claims",
            "evidence": "FedProx, Ditto, Clustered, FedAMP across main roots; FedProto/FedPer/FedPer-FAM added on PACS 5-seed, Office-Caltech neighbor-aware 5-seed, DomainNetMini text-head, and BloodMNIST 5-seed. OfficeHome adds a guarded Ditto-FAM audit that matches the strongest Ditto-LoRA ceiling by conservative personal fallback.",
            "risk": "PACS shows FedPer-LoRA is a very strong personalization ceiling; FedPer-FAM slightly improves the mean but the paired gain over FedPer is small. OfficeHome shows no-regret composability rather than an extra gain beyond Ditto-LoRA. Frame FAM as geometry-conditioned safe routing and personalization composition, not universal winner.",
        },
        {
            "item": "Visual foundation/pretrained backbone evidence",
            "status": "completed_with_federated_end_to_end_clip_vit_and_dinov2_audits",
            "evidence": "5-seed federated CLIP ViT-B/16 attention-LoRA runs on DomainNetMini 60-class, a larger DomainNetMini 60-class 8/8-shot split, PACS 7-class, and Office-Caltech 10-class; supplementary CLIP ViT-B/32 and ResNet18-pretrained audits; a PACS DINOv2-S/14 calib20 anchored audit where StrongSelective has the best mean accuracy and improves over FedAvg/GeoAgg with positive paired CIs; a full-data OfficeHome-DINOv2 65-class, 20-round, calib20 anchored-no-regret audit where StrongSelective improves over FedAvg, GeoAgg, and Ditto with positive paired CIs; and a full-data OfficeHome-CLIP ViT-B/16 65-class, 20-round, calib20 audit where StrongSelective improves over FedAvg and GeoAgg with positive paired CIs.",
            "risk": "Office-Caltech is a high-ceiling setting with small non-significant gains; PACS DINOv2 resolves the mean-accuracy caveat but does not significantly dominate every strong anchor such as FedPer-LoRA; the larger DomainNetMini CLIP split is geometry-dominated and repairs FedAvg but does not significantly beat GeoAgg; full OfficeHome-CLIP improves over FedAvg/GeoAgg but not significantly over Ditto; capped OfficeHome-DINOv2 240/160 runs are excluded as invalid main evidence.",
        },
        {
            "item": "5 seeds + CI/significance",
            "status": "completed_for_main_claims",
            "evidence": "PACS, Office-Caltech, OfficeHome, DomainNetMini, and BloodMNIST feature-level roots are five-seed; end-to-end CLIP ViT DomainNetMini/PACS/Office-Caltech are five-seed; DomainNetMini also has a larger 60-class 8/8-shot CLIP-LoRA audit; all roots produce bootstrap CIs and paired significance pack.",
            "risk": "DomainNetMini has both a five-seed text-head stress run and five-seed end-to-end DomainNetMini 60-class CLIP-LoRA stress tests. The 8/8-shot split is evidence for FedAvg repair and geometry-dominated routing, not for a subspace-only story.",
        },
        {
            "item": "Gate legality/no test leakage",
            "status": "completed",
            "evidence": "candidate_selector_calibration_fraction and Office-Caltech 5/10/20% calibration sweep.",
            "risk": "Held-out calibration reduces training data; report accuracy/risk tradeoff.",
        },
        {
            "item": "Full distance/component ablation",
            "status": "completed_with_mixed_support",
            "evidence": "OfficeCaltech and DomainNetMini distance ablation tables.",
            "risk": "Do not claim all components always dominate; claim complementary roles.",
        },
        {
            "item": "Negative controls",
            "status": "completed",
            "evidence": "Office-Caltech safe-gated, forced raw graph, and self-anchor graph controls.",
            "risk": "Raw graph sharing can hurt, which supports safe routing but weakens naked graph-sharing claims.",
        },
        {
            "item": "Claim/title positioning",
            "status": "completed",
            "evidence": "Title and abstract weakened; evidence pack separates main, caveat, and supplement claims.",
            "risk": "PR still needs careful wording around the unpublished geometry-provider dependency and feature-level adaptation.",
        },
    ]


def write_markdown(path: Path, accuracy_rows: list[dict], diagnostic_rows: list[dict], ranking_rows: list[dict]) -> None:
    lines = [
        "# FedAdapterManifold PR Evidence Pack",
        "",
        "## Bottom Line",
        "",
        "- The core mechanism is supported strongly enough to continue: adapter incompatibility/subspace conflict correlates with FedAvg-LoRA failure in the pooled PACS 5-seed result and in multiple prior roots.",
        "- The strongest caveat is no longer FedAvg; it is personalized baselines such as FedPer-LoRA and Ditto-LoRA. PACS supports a compositional fix: FedPer-FAM slightly exceeds FedPer-LoRA in mean accuracy, though the paired margin is small. OfficeHome supports the complementary no-regret case: guarded Ditto-FAM matches Ditto-LoRA while retaining the FAM branch when local calibration warrants it.",
        "- The VFM evidence now includes five-seed CLIP ViT-B/16 attention-LoRA on DomainNetMini-60, a larger DomainNetMini-60 8/8-shot split, PACS-7, and Office-Caltech-10, plus DINOv2-S/14 anchored audits on PACS and full-data 65-class, 20-round OfficeHome splits for both DINOv2-S/14 and CLIP ViT-B/16. PACS-DINOv2 resolves the mean-accuracy ceiling caveat and supports FedAvg/GeoAgg repair; OfficeHome-DINOv2 supports the anchored selector against FedAvg, GeoAgg, and Ditto with stable positive paired CIs; OfficeHome-CLIP supports full-data FedAvg/GeoAgg repair; the larger DomainNetMini CLIP split supports FedAvg repair but is geometry-dominated relative to GeoAgg.",
        "- The paper positions the method as geometry-conditioned adapter sharing/routing/personalization with safety gates, not as a universal mean-accuracy winner on every dataset.",
        "",
        "## Top Methods By Dataset",
        "",
        "| Dataset | Rank | Method | Accuracy |",
        "|---|---:|---|---:|",
    ]
    for row in ranking_rows:
        if int(row.get("rank", 999)) <= 5:
            lines.append(
                f"| {row.get('dataset','')} | {row.get('rank','')} | {row.get('method','')} | {fmt(row.get('mean_accuracy',''))} |"
            )
    lines.extend(
        [
            "",
            "## Key Diagnostics",
            "",
            "| Dataset | Claim | Support | Estimate | CI Low | Action |",
            "|---|---|---|---:|---:|---|",
        ]
    )
    for row in diagnostic_rows:
        if row.get("claim_id") in {
            "adapter_incompatibility_failure_correlation",
            "adapter_bank_gain_vs_fedavg",
            "adapter_bank_gain_vs_fedgeo_agg",
            "update_conflict_reduction_vs_fedavg",
        }:
            lines.append(
                "| {dataset} | {claim} | {support} | {estimate} | {ci_low} | {action} |".format(
                    dataset=row.get("dataset", ""),
                    claim=row.get("claim_id", ""),
                    support=row.get("supports", ""),
                    estimate=fmt(row.get("estimate", "")),
                    ci_low=fmt(row.get("ci_low", "")),
                    action=row.get("narrative_action", ""),
                )
            )
    lines.extend(["", "## Seven-Item Status", ""])
    for row in seven_item_status_rows():
        lines.append(f"- **{row['item']}**: {row['status']}. {row['evidence']} Risk: {row['risk']}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def find(rows: Iterable[dict], key: str, value: str) -> dict:
    for row in rows:
        if row.get(key) == value:
            return row
    return {}


def find_metric(rows: Iterable[dict], test: str, method: str, baseline: str, measure: str) -> dict:
    for row in rows:
        if (
            row.get("test") == test
            and row.get("method", "") == method
            and row.get("baseline", "") == baseline
            and row.get("measure", "") == measure
        ):
            return row
    return {}


def has_method(rows: list[dict], method: str) -> bool:
    return any(row.get("method") == method for row in rows)


def fnum(value) -> float:
    try:
        if value in {"", None}:
            return float("nan")
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def fmt(value) -> str:
    number = fnum(value)
    if math.isnan(number):
        return ""
    return f"{number:.4f}"


if __name__ == "__main__":
    raise SystemExit(main())
