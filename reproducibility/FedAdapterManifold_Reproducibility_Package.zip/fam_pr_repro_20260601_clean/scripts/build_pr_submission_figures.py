from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
import math


ROOT = Path(__file__).resolve().parents[1]
FIG_DIR = ROOT / "paper" / "figures"
FIG_DIR.mkdir(parents=True, exist_ok=True)


def font(size, bold=False):
    candidates = [
        "C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf",
        "C:/Windows/Fonts/calibrib.ttf" if bold else "C:/Windows/Fonts/calibri.ttf",
    ]
    for c in candidates:
        p = Path(c)
        if p.exists():
            return ImageFont.truetype(str(p), size)
    return ImageFont.load_default()


F_TITLE = font(36, True)
F_HEAD = font(26, True)
F_BODY = font(20)
F_SMALL = font(17)
F_TINY = font(15)
F_MICRO = font(14)


COLORS = {
    "ink": (31, 41, 55),
    "muted": (91, 103, 120),
    "blue": (44, 123, 229),
    "blue_light": (224, 239, 255),
    "green": (47, 158, 68),
    "green_light": (224, 245, 232),
    "orange": (230, 126, 34),
    "orange_light": (255, 239, 222),
    "red": (211, 47, 47),
    "red_light": (255, 230, 230),
    "purple": (116, 86, 174),
    "purple_light": (239, 235, 249),
    "gray": (226, 232, 240),
    "line": (120, 132, 150),
    "white": (255, 255, 255),
}


def rounded(draw, box, fill, outline=None, width=2, radius=18):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def text_center(draw, xy, text, fnt, fill=COLORS["ink"]):
    bbox = draw.textbbox((0, 0), text, font=fnt)
    x = xy[0] - (bbox[2] - bbox[0]) / 2
    y = xy[1] - (bbox[3] - bbox[1]) / 2
    draw.text((x, y), text, font=fnt, fill=fill)


def arrow(draw, start, end, fill=COLORS["line"], width=4):
    draw.line([start, end], fill=fill, width=width)
    ang = math.atan2(end[1] - start[1], end[0] - start[0])
    L = 14
    a1 = ang + math.pi * 0.82
    a2 = ang - math.pi * 0.82
    pts = [
        end,
        (end[0] + L * math.cos(a1), end[1] + L * math.sin(a1)),
        (end[0] + L * math.cos(a2), end[1] + L * math.sin(a2)),
    ]
    draw.polygon(pts, fill=fill)


def wrap(draw, text, fnt, max_width):
    words = text.split()
    lines, line = [], ""
    for w in words:
        cand = (line + " " + w).strip()
        if draw.textbbox((0, 0), cand, font=fnt)[2] <= max_width:
            line = cand
        else:
            if line:
                lines.append(line)
            line = w
    if line:
        lines.append(line)
    return lines


def draw_wrapped(draw, x, y, text, fnt, max_width, fill=COLORS["ink"], leading=6):
    for line in wrap(draw, text, fnt, max_width):
        draw.text((x, y), line, font=fnt, fill=fill)
        y += fnt.size + leading
    return y


def build_overview():
    W, H = 1900, 820
    img = Image.new("RGB", (W, H), COLORS["white"])
    d = ImageDraw.Draw(img)
    d.text((60, 36), "FedAdapterManifold: adapter-subspace routing for federated visual recognition", font=F_TITLE, fill=COLORS["ink"])
    d.text((62, 82), "The visual question: when are low-rank adaptation directions compatible enough to share?", font=F_BODY, fill=COLORS["muted"])

    panels = [
        (60, 145, 430, 650, COLORS["blue_light"], COLORS["blue"], "1  Visual domains"),
        (520, 145, 890, 650, COLORS["red_light"], COLORS["red"], "2  Bad averaging"),
        (980, 145, 1350, 650, COLORS["purple_light"], COLORS["purple"], "3  Subspace test"),
        (1440, 145, 1810, 650, COLORS["green_light"], COLORS["green"], "4  Safe routing"),
    ]
    for box in panels:
        x1, y1, x2, y2, fill, outline, title = box
        rounded(d, (x1, y1, x2, y2), fill, outline, 3)
        d.text((x1 + 24, y1 + 22), title, font=F_HEAD, fill=outline)

    # Panel 1: domain clients
    domains = [("Photo", COLORS["blue"]), ("Sketch", COLORS["orange"]), ("Clipart", COLORS["purple"]), ("Product", COLORS["green"])]
    coords = [(135, 275), (310, 265), (145, 455), (315, 450)]
    for (name, color), (x, y) in zip(domains, coords):
        d.ellipse((x - 48, y - 48, x + 48, y + 48), fill=COLORS["white"], outline=color, width=5)
        text_center(d, (x, y), name, F_SMALL, color)
        d.rectangle((x - 30, y + 62, x + 30, y + 100), fill=(245, 248, 252), outline=color, width=2)
        d.line((x - 30, y + 75, x + 30, y + 75), fill=color, width=2)
        d.line((x - 10, y + 62, x - 10, y + 100), fill=color, width=2)
        d.line((x + 10, y + 62, x + 10, y + 100), fill=color, width=2)
    text_center(d, (245, 584), "same task, different domains", F_SMALL, COLORS["muted"])
    text_center(d, (245, 620), "adapters point differently", F_SMALL, COLORS["muted"])

    # Panel 2: averaging conflict
    for offset, color in [(-22, COLORS["blue"]), (22, COLORS["orange"])]:
        d.line((625, 390, 790, 285 + offset), fill=color, width=8)
        d.ellipse((778, 273 + offset, 802, 297 + offset), fill=color)
    d.line((625, 390, 805, 390), fill=COLORS["red"], width=8)
    d.ellipse((793, 378, 817, 402), fill=COLORS["red"])
    text_center(d, (705, 418), "global average", F_MICRO, COLORS["red"])
    text_center(d, (705, 494), "mixes incompatible directions", F_SMALL, COLORS["ink"])
    text_center(d, (705, 558), "accuracy drop | drift | conflict", F_SMALL, COLORS["muted"])
    text_center(d, (705, 250), "FedAvg-LoRA", F_HEAD, COLORS["red"])
    d.line((575, 250, 840, 450), fill=(180, 40, 40), width=3)
    d.line((840, 250, 575, 450), fill=(180, 40, 40), width=3)

    # Panel 3: subspace diagnostic
    d.arc((1035, 270, 1205, 440), 205, 335, fill=COLORS["purple"], width=8)
    d.arc((1110, 270, 1280, 440), 205, 335, fill=COLORS["orange"], width=8)
    d.line((1120, 360, 1195, 310), fill=COLORS["line"], width=3)
    d.text((1030, 470), "measure LoRA subspace distance", font=F_SMALL, fill=COLORS["ink"])
    d.text((1030, 502), "with Grassmannian angles", font=F_SMALL, fill=COLORS["ink"])
    d.text((1030, 565), "test: distance predicts failure", font=F_SMALL, fill=COLORS["purple"])
    for p in [(1050, 330), (1105, 345), (1180, 320), (1245, 345)]:
        d.ellipse((p[0] - 7, p[1] - 7, p[0] + 7, p[1] + 7), fill=COLORS["purple"])

    # Panel 4: safe routing
    nodes = [("Local", 1525, 300, COLORS["orange"]), ("Geo-only", 1725, 300, COLORS["blue"]), ("FAM", 1525, 455, COLORS["purple"]), ("Anchor", 1725, 455, COLORS["green"])]
    for name, x, y, c in nodes:
        d.rounded_rectangle((x - 72, y - 32, x + 72, y + 32), radius=14, fill=COLORS["white"], outline=c, width=4)
        text_center(d, (x, y), name, F_SMALL, c)
    arrow(d, (1600, 300), (1650, 300), COLORS["line"], 3)
    arrow(d, (1525, 335), (1525, 418), COLORS["line"], 3)
    arrow(d, (1725, 335), (1725, 418), COLORS["line"], 3)
    arrow(d, (1600, 455), (1650, 455), COLORS["line"], 3)
    d.rounded_rectangle((1575, 540, 1675, 595), radius=18, fill=COLORS["green"], outline=COLORS["green"], width=3)
    text_center(d, (1625, 568), "select", F_SMALL, COLORS["white"])
    d.text((1468, 665), "fixed candidates before test", font=F_SMALL, fill=COLORS["muted"])
    d.text((1468, 692), "calibration gate avoids oracle choice", font=F_SMALL, fill=COLORS["muted"])

    # arrows between panels
    arrow(d, (435, 390), (510, 390), COLORS["line"], 5)
    arrow(d, (895, 390), (970, 390), COLORS["line"], 5)
    arrow(d, (1355, 390), (1430, 390), COLORS["line"], 5)

    img.save(FIG_DIR / "fam_pr_overview.png", dpi=(220, 220))


def build_vfm_summary():
    W, H = 1500, 860
    img = Image.new("RGB", (W, H), COLORS["white"])
    d = ImageDraw.Draw(img)
    d.text((55, 32), "Full-data VFM/backbone audits: OfficeHome 65-class, 20 rounds, five seeds", font=F_TITLE, fill=COLORS["ink"])
    d.text((58, 82), "Anchored safe routing is compared against the single global adapter, geometry-only aggregation, and a strong personalized anchor.", font=F_BODY, fill=COLORS["muted"])

    groups = [
        ("DINOv2-S/14", [("FedAvg-LoRA", 0.7276), ("Geo-only", 0.7506), ("Ditto-LoRA", 0.7499), ("FAM-Anchor", 0.7592)]),
        ("CLIP ViT-B/16", [("FedAvg-LoRA", 0.7081), ("Geo-only", 0.7280), ("Ditto-LoRA", 0.7344), ("FAM-Anchor", 0.7380)]),
    ]
    colors = {
        "FedAvg-LoRA": COLORS["red"],
        "Geo-only": COLORS["blue"],
        "Ditto-LoRA": COLORS["orange"],
        "FAM-Anchor": COLORS["green"],
    }

    chart_x, chart_y = 110, 160
    chart_w, chart_h = 1180, 400
    min_y, max_y = 0.68, 0.77
    d.line((chart_x, chart_y + chart_h, chart_x + chart_w, chart_y + chart_h), fill=COLORS["line"], width=3)
    d.line((chart_x, chart_y, chart_x, chart_y + chart_h), fill=COLORS["line"], width=3)
    for val in [0.68, 0.70, 0.72, 0.74, 0.76]:
        y = chart_y + chart_h - (val - min_y) / (max_y - min_y) * chart_h
        d.line((chart_x - 8, y, chart_x + chart_w, y), fill=(235, 239, 245), width=1)
        d.text((45, y - 11), f"{val:.2f}", font=F_SMALL, fill=COLORS["muted"])
    d.text((25, chart_y + 145), "Accuracy", font=F_SMALL, fill=COLORS["ink"])

    group_centers = [390, 900]
    bar_w = 58
    gap = 16
    for (gname, vals), gc in zip(groups, group_centers):
        start = gc - (4 * bar_w + 3 * gap) / 2
        for idx, (name, val) in enumerate(vals):
            x1 = start + idx * (bar_w + gap)
            x2 = x1 + bar_w
            y = chart_y + chart_h - (val - min_y) / (max_y - min_y) * chart_h
            d.rounded_rectangle((x1, y, x2, chart_y + chart_h), radius=8, fill=colors[name])
            text_center(d, ((x1 + x2) / 2, y - 18), f"{val:.4f}", F_TINY, COLORS["ink"])
        text_center(d, (gc, chart_y + chart_h + 50), gname, F_HEAD, COLORS["ink"])
        d.text((gc - 210, chart_y + chart_h + 82), "Full 65 classes, 20 FL rounds, five audited seeds", font=F_SMALL, fill=COLORS["muted"])

    # legend
    lx, ly = 1060, 170
    for i, name in enumerate(["FedAvg-LoRA", "Geo-only", "Ditto-LoRA", "FAM-Anchor"]):
        y = ly + i * 38
        d.rectangle((lx, y, lx + 24, y + 24), fill=colors[name])
        d.text((lx + 34, y - 1), name, font=F_SMALL, fill=COLORS["ink"])

    # paired gain callouts
    callouts = [
        ("DINOv2 gains", "+0.0316 vs FedAvg\n+0.0086 vs Geo-only\n+0.0093 vs Ditto"),
        ("CLIP gains", "+0.0300 vs FedAvg\n+0.0100 vs Geo-only\n+0.0036 vs Ditto (mean +)"),
    ]
    for i, (title, body) in enumerate(callouts):
        x1 = 120 + i * 640
        y1 = 735
        d.rounded_rectangle((x1, y1, x1 + 560, y1 + 82), radius=16, fill=(246, 248, 252), outline=COLORS["gray"], width=2)
        d.text((x1 + 18, y1 + 14), title, font=F_HEAD, fill=COLORS["green"])
        for k, line in enumerate(body.split("\n")):
            d.text((x1 + 250, y1 + 10 + k * 22), line, font=F_SMALL, fill=COLORS["ink"])

    d.text((112, 675), "Takeaway: full-data VFM audits support FedAvg/Geo-only repair without claiming universal dominance over every personalized anchor.", font=F_BODY, fill=COLORS["ink"])
    img.save(FIG_DIR / "vfm_full_data_summary.png", dpi=(220, 220))


def build_dinov2_backbone():
    W, H = 1500, 900
    img = Image.new("RGB", (W, H), COLORS["white"])
    d = ImageDraw.Draw(img)
    d.text((55, 38), "DINOv2-S/14 frozen-feature LoRA audits", font=F_TITLE, fill=COLORS["ink"])
    d.text((58, 88), "PACS resolves the mean-accuracy caveat; OfficeHome gives full-data multi-round evidence.", font=F_BODY, fill=COLORS["muted"])

    methods = ["FedAvg-LoRA", "FAM-Selective", "FAM-Anchor", "Best non-FAM"]
    colors = {
        "FedAvg-LoRA": (145, 146, 151),
        "FAM-Selective": (112, 181, 174),
        "FAM-Anchor": (82, 163, 75),
        "Best non-FAM": (179, 122, 166),
    }
    groups = [
        ("PACS DINOv2", [0.8938, 0.9169, 0.9488, 0.9484]),
        ("OfficeHome DINOv2", [0.7276, 0.7506, 0.7592, 0.7499]),
    ]

    chart_x, chart_y = 120, 155
    chart_w, chart_h = 1120, 430
    min_y, max_y = 0.70, 0.98
    d.line((chart_x, chart_y + chart_h, chart_x + chart_w, chart_y + chart_h), fill=COLORS["line"], width=3)
    d.line((chart_x, chart_y, chart_x, chart_y + chart_h), fill=COLORS["line"], width=3)
    for val in [0.70, 0.77, 0.84, 0.91, 0.98]:
        y = chart_y + chart_h - (val - min_y) / (max_y - min_y) * chart_h
        d.line((chart_x - 8, y, chart_x + chart_w, y), fill=(235, 239, 245), width=1)
        d.text((58, y - 11), f"{val:.2f}", font=F_SMALL, fill=COLORS["muted"])
    d.text((65, chart_y - 34), "Mean accuracy", font=F_SMALL, fill=COLORS["ink"])

    group_centers = [395, 895]
    bar_w = 72
    gap = 22
    for (gname, vals), gc in zip(groups, group_centers):
        start = gc - (4 * bar_w + 3 * gap) / 2
        for idx, (m, val) in enumerate(zip(methods, vals)):
            x1 = start + idx * (bar_w + gap)
            x2 = x1 + bar_w
            y = chart_y + chart_h - (val - min_y) / (max_y - min_y) * chart_h
            d.rectangle((x1, y, x2, chart_y + chart_h), fill=colors[m])
            d.text((x1 + 5, y - 24), f"{val:.4f}", font=F_TINY, fill=COLORS["ink"])
        text_center(d, (gc, chart_y + chart_h + 48), gname, F_HEAD, COLORS["ink"])

    lx, ly = 1240, 180
    for i, m in enumerate(methods):
        y = ly + i * 42
        d.rectangle((lx, y, lx + 25, y + 25), fill=colors[m])
        d.text((lx + 36, y - 1), m, font=F_SMALL, fill=COLORS["ink"])

    # Bottom notes with enough breathing room.
    notes = [
        ("PACS", "FAM-Anchor: 0.9488\n+0.0550 vs FedAvg\n+0.0319 vs Geo-only"),
        ("OfficeHome", "FAM-Anchor: 0.7592\n+0.0316 vs FedAvg\n+0.0086 vs Geo-only\n+0.0093 vs Ditto"),
    ]
    for i, (title, body) in enumerate(notes):
        x1 = 120 + i * 620
        y1 = 680
        d.rounded_rectangle((x1, y1, x1 + 560, y1 + 150), radius=16, fill=(246, 248, 252), outline=COLORS["gray"], width=2)
        d.text((x1 + 18, y1 + 16), title, font=F_HEAD, fill=COLORS["green"])
        for k, line in enumerate(body.split("\n")):
            d.text((x1 + 210, y1 + 14 + k * 28), line, font=F_SMALL, fill=COLORS["ink"])

    d.text((120, 845), "Capped 240/160 OfficeHome-DINOv2 runs are excluded because they are too sparse for the 65-class label space.", font=F_SMALL, fill=COLORS["muted"])
    img.save(FIG_DIR / "dinov2_backbone_evidence.png", dpi=(220, 220))


if __name__ == "__main__":
    build_overview()
    build_vfm_summary()
    build_dinov2_backbone()
    print(FIG_DIR / "fam_pr_overview.png")
    print(FIG_DIR / "vfm_full_data_summary.png")
    print(FIG_DIR / "dinov2_backbone_evidence.png")
