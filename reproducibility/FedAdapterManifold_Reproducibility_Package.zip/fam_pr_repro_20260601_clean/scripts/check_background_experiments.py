from __future__ import annotations

import argparse
import ctypes
import json
import os
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Summarize background experiment launcher metadata.")
    parser.add_argument("--log-dir", default="results/fedadaptermanifold_background_logs")
    parser.add_argument("--name", default="", help="Optional exact run name to inspect.")
    parser.add_argument("--tail", type=int, default=8, help="Number of stderr/stdout tail lines to show.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    log_dir = Path(args.log_dir)
    if not log_dir.is_absolute():
        log_dir = (ROOT / log_dir).resolve()
    pattern = f"{args.name}.json" if args.name else "*.json"
    paths = sorted(log_dir.glob(pattern))
    if not paths:
        print(f"No background experiment metadata found in {log_dir}.")
        return 0

    for path in paths:
        metadata = _read_json(path)
        if not metadata:
            continue
        pid = metadata.get("pid")
        child_pid = metadata.get("child_pid")
        status = metadata.get("status", "unknown")
        exit_code = metadata.get("exit_code", "")
        live = _pid_is_running(pid) if isinstance(pid, int) else False
        child_live = _pid_is_running(child_pid) if isinstance(child_pid, int) else False
        print(
            f"{metadata.get('name', path.stem)} | status={status} | "
            f"pid={pid} live={live} | child_pid={child_pid} child_live={child_live} | exit={exit_code}"
        )
        print(f"  metadata: {path}")
        stdout = Path(str(metadata.get("stdout", "")))
        stderr = Path(str(metadata.get("stderr", "")))
        if stdout.exists():
            print(f"  stdout: {stdout}")
            _print_tail(stdout, args.tail, prefix="    out> ")
        if stderr.exists():
            print(f"  stderr: {stderr}")
            _print_tail(stderr, args.tail, prefix="    err> ")
    return 0


def _read_json(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _pid_is_running(pid: int | None) -> bool:
    if not isinstance(pid, int) or pid <= 0:
        return False
    if os.name == "nt":
        return _windows_pid_is_running(pid)
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _windows_pid_is_running(pid: int) -> bool:
    process_query_limited_information = 0x1000
    still_active = 259
    handle = ctypes.windll.kernel32.OpenProcess(process_query_limited_information, False, pid)
    if not handle:
        return False
    try:
        exit_code = ctypes.c_ulong()
        ok = ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code))
        return bool(ok) and exit_code.value == still_active
    finally:
        ctypes.windll.kernel32.CloseHandle(handle)


def _print_tail(path: Path, n: int, *, prefix: str) -> None:
    if n <= 0:
        return
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return
    for line in lines[-n:]:
        _safe_print(f"{prefix}{line}")


def _safe_print(text: str) -> None:
    encoding = getattr(sys.stdout, "encoding", None) or "utf-8"
    print(text.encode(encoding, errors="replace").decode(encoding, errors="replace"))


if __name__ == "__main__":
    raise SystemExit(main())
