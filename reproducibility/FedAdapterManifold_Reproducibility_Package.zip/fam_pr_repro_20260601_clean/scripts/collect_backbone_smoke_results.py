from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Collect backbone smoke-test summaries.")
    parser.add_argument("--run", action="append", default=[], help="Repeated spec: dataset|backbone|result_dir|scope")
    parser.add_argument("--output", type=str, default="results/backbone_smoke_summary.csv")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    rows = []
    for spec in args.run:
        dataset, backbone, result_dir, scope = _parse_spec(spec)
        rows.append(_summarize(dataset, backbone, Path(result_dir), scope))
    output = Path(args.output)
    ensure_dir(output.parent)
    write_csv(output, rows)
    return 0


def _summarize(dataset: str, backbone: str, result_dir: Path, scope: str) -> dict:
    claims = {row.get("claim_id", ""): row for row in _read_csv(result_dir / "multiseed_claim_report.csv")}
    metrics = {
        (row.get("test", ""), row.get("method", ""), row.get("baseline", ""), row.get("measure", "")): row
        for row in _read_csv(result_dir / "multiseed_summary.csv")
    }
    return {
        "dataset": dataset,
        "feature_backbone": backbone,
        "scope": scope,
        "overall_core_support": claims.get("overall_core_support", {}).get("supports", ""),
        "local_lora_accuracy": _metric(metrics, "method_accuracy", "Local-LoRA", "", "mean_accuracy"),
        "fedavg_lora_accuracy": _metric(metrics, "method_accuracy", "FedAvg-LoRA", "", "mean_accuracy"),
        "fedgeo_agg_accuracy": _metric(metrics, "method_accuracy", "FedGeo-Agg", "", "mean_accuracy"),
        "fedadapter_accuracy": _metric(metrics, "method_accuracy", "FedAdapterManifold", "", "mean_accuracy"),
        "gain_vs_fedavg": _claim(claims, "adapter_bank_gain_vs_fedavg", "estimate"),
        "gain_vs_fedavg_ci_low": _claim(claims, "adapter_bank_gain_vs_fedavg", "ci_low"),
        "gain_vs_fedgeo_agg": _claim(claims, "adapter_bank_gain_vs_fedgeo_agg", "estimate"),
        "gain_vs_fedgeo_agg_ci_low": _claim(claims, "adapter_bank_gain_vs_fedgeo_agg", "ci_low"),
        "adapter_incompatibility_failure_r": _claim(
            claims, "adapter_incompatibility_failure_correlation", "estimate"
        ),
        "adapter_incompatibility_failure_ci_low": _claim(
            claims, "adapter_incompatibility_failure_correlation", "ci_low"
        ),
        "update_conflict_reduction_vs_fedavg": _claim(
            claims, "update_conflict_reduction_vs_fedavg", "estimate"
        ),
        "update_conflict_reduction_vs_fedavg_ci_low": _claim(
            claims, "update_conflict_reduction_vs_fedavg", "ci_low"
        ),
        "update_conflict_reduction_vs_fedgeo_agg": _claim(
            claims, "update_conflict_reduction_vs_fedgeo_agg", "estimate"
        ),
        "update_conflict_reduction_ci_low": _claim(claims, "update_conflict_reduction_vs_fedgeo_agg", "ci_low"),
        "secondary_caveats": claims.get("overall_core_support", {}).get("secondary_caveats", ""),
        "result_dir": str(result_dir),
    }


def _metric(metrics: dict[tuple[str, str, str, str], dict], test: str, method: str, baseline: str, measure: str) -> str:
    return metrics.get((test, method, baseline, measure), {}).get("estimate", "")


def _claim(claims: dict[str, dict], claim_id: str, key: str) -> str:
    return claims.get(claim_id, {}).get(key, "")


def _parse_spec(spec: str) -> tuple[str, str, str, str]:
    parts = str(spec).split("|")
    if len(parts) != 4:
        raise ValueError(f"Invalid --run {spec!r}; expected dataset|backbone|result_dir|scope")
    return parts[0].strip(), parts[1].strip(), parts[2].strip(), parts[3].strip()


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


if __name__ == "__main__":
    raise SystemExit(main())
