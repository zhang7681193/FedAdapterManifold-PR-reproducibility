from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Collect component ablation summaries across result roots.")
    parser.add_argument(
        "--run",
        action="append",
        default=[],
        help="Repeated spec: dataset|component_ablation_root|seed_scope",
    )
    parser.add_argument("--output", type=str, default="results/component_ablation_cross_dataset_summary.csv")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    rows: list[dict] = []
    for spec in args.run:
        dataset, root, seed_scope = _parse_spec(spec)
        rows.extend(_collect(dataset, Path(root), seed_scope))
    output = Path(args.output)
    ensure_dir(output.parent)
    write_csv(output, rows)
    return 0


def _collect(dataset: str, root: Path, seed_scope: str) -> list[dict]:
    existing_summary = root / "component_ablation_summary.csv"
    if existing_summary.exists():
        rows = _read_csv(existing_summary)
    else:
        rows = []
        for subdir in sorted(path for path in root.iterdir() if path.is_dir()):
            row = _summarize_ablation_dir(subdir)
            if row is not None:
                rows.append(row)
    out = []
    for row in rows:
        row = dict(row)
        row["dataset"] = dataset
        row["seed_scope"] = seed_scope
        row["component_root"] = str(root)
        out.append(row)
    return out


def _summarize_ablation_dir(path: Path) -> dict | None:
    ablation = path.name
    summary_rows = _read_csv(path / "multiseed_summary.csv")
    claim_rows = _read_csv(path / "multiseed_claim_report.csv")
    if not summary_rows and not claim_rows:
        return None
    by_claim = {row.get("claim_id", ""): row for row in claim_rows}
    by_metric = {
        (row.get("test", ""), row.get("method", ""), row.get("baseline", ""), row.get("measure", "")): row
        for row in summary_rows
    }
    overall = by_claim.get("overall_core_support", {})
    return {
        "ablation": ablation,
        "description": "",
        "exit_code": "",
        "overall_core_support": overall.get("supports", ""),
        "secondary_caveats": overall.get("secondary_caveats", ""),
        "adapter_incompatibility_r": _claim_estimate(by_claim, "adapter_incompatibility_failure_correlation"),
        "adapter_incompatibility_supports": _claim_supports(by_claim, "adapter_incompatibility_failure_correlation"),
        "raw_subspace_r": _claim_estimate(by_claim, "raw_subspace_failure_correlation"),
        "raw_subspace_supports": _claim_supports(by_claim, "raw_subspace_failure_correlation"),
        "geo_r": _claim_estimate(by_claim, "geometry_failure_correlation"),
        "geo_supports": _claim_supports(by_claim, "geometry_failure_correlation"),
        "fedavg_accuracy": _metric(by_metric, "method_accuracy", "FedAvg-LoRA", "", "mean_accuracy"),
        "fedgeo_agg_accuracy": _metric(by_metric, "method_accuracy", "FedGeo-Agg", "", "mean_accuracy"),
        "fedadapter_accuracy": _metric(by_metric, "method_accuracy", "FedAdapterManifold", "", "mean_accuracy"),
        "gain_vs_fedavg": _claim_estimate(by_claim, "adapter_bank_gain_vs_fedavg"),
        "gain_vs_fedavg_supports": _claim_supports(by_claim, "adapter_bank_gain_vs_fedavg"),
        "gain_vs_fedgeo_agg": _claim_estimate(by_claim, "adapter_bank_gain_vs_fedgeo_agg"),
        "gain_vs_fedgeo_agg_supports": _claim_supports(by_claim, "adapter_bank_gain_vs_fedgeo_agg"),
        "worst_risk_reduction_vs_fedgeo_agg": _claim_estimate(by_claim, "worst_client_risk_reduction_vs_fedgeo_agg"),
        "worst_risk_supports": _claim_supports(by_claim, "worst_client_risk_reduction_vs_fedgeo_agg"),
        "update_conflict_reduction_vs_fedgeo_agg": _claim_estimate(by_claim, "update_conflict_reduction_vs_fedgeo_agg"),
        "update_conflict_supports": _claim_supports(by_claim, "update_conflict_reduction_vs_fedgeo_agg"),
        "client_drift_reduction_vs_fedgeo_agg": _claim_estimate(by_claim, "client_drift_reduction_vs_fedgeo_agg"),
        "graph_neighbor_conflict_reduction_vs_fedgeo_agg": _claim_estimate(
            by_claim, "graph_neighbor_conflict_reduction_vs_fedgeo_agg"
        ),
        "output_dir": str(path),
    }


def _metric(by_metric: dict[tuple[str, str, str, str], dict], test: str, method: str, baseline: str, measure: str) -> str:
    return by_metric.get((test, method, baseline, measure), {}).get("estimate", "")


def _claim_estimate(by_claim: dict[str, dict], claim_id: str) -> str:
    return by_claim.get(claim_id, {}).get("estimate", "")


def _claim_supports(by_claim: dict[str, dict], claim_id: str) -> str:
    return by_claim.get(claim_id, {}).get("supports", "")


def _parse_spec(spec: str) -> tuple[str, str, str]:
    parts = str(spec).split("|")
    if len(parts) != 3:
        raise ValueError(f"Invalid --run {spec!r}; expected dataset|component_root|seed_scope")
    return parts[0].strip(), parts[1].strip(), parts[2].strip()


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


if __name__ == "__main__":
    raise SystemExit(main())
