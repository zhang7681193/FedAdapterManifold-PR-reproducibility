from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Collect graph-active ablation summaries.")
    parser.add_argument("--run", action="append", default=[], help="Repeated spec: dataset|graph_active_root|scope")
    parser.add_argument("--output", type=str, default="results/graph_active_ablation_summary.csv")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    rows = []
    for spec in args.run:
        dataset, root, scope = _parse_spec(spec)
        root_path = Path(root)
        summary_path = root_path / "graph_active_summary.csv"
        for row in _read_csv(summary_path):
            out = dict(row)
            out["dataset"] = dataset
            out["scope"] = scope
            out["graph_active_root"] = root
            out.update(_graph_mix_stats(root_path / row.get("label", "")))
            rows.append(out)
    output = Path(args.output)
    ensure_dir(output.parent)
    write_csv(output, rows)
    return 0


def _parse_spec(spec: str) -> tuple[str, str, str]:
    parts = str(spec).split("|")
    if len(parts) != 3:
        raise ValueError(f"Invalid --run {spec!r}; expected dataset|graph_active_root|scope")
    return parts[0].strip(), parts[1].strip(), parts[2].strip()


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _graph_mix_stats(run_dir: Path) -> dict:
    weights = []
    for path in run_dir.glob("seed_*/adapter_graph_mixing.csv"):
        for row in _read_csv(path):
            if str(row.get("selected", "")).lower() != "true":
                continue
            try:
                weights.append(float(row.get("selected_graph_mix_weight", "")))
            except ValueError:
                continue
    if not weights:
        return {
            "mean_selected_graph_mix_weight": "",
            "graph_mix_accept_rate": "",
            "num_graph_mix_selections": 0,
        }
    accepted = [weight for weight in weights if weight > 1e-12]
    return {
        "mean_selected_graph_mix_weight": sum(weights) / len(weights),
        "graph_mix_accept_rate": len(accepted) / len(weights),
        "num_graph_mix_selections": len(weights),
    }


if __name__ == "__main__":
    raise SystemExit(main())
