from __future__ import annotations

import argparse
import ctypes
import json
import os
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Launch a long-running experiment in the background and write logs/PID metadata."
    )
    parser.add_argument("--name", required=True, help="Short run name used for log and metadata files.")
    parser.add_argument("--log-dir", default="results/fedadaptermanifold_background_logs")
    parser.add_argument("--cwd", default=str(ROOT))
    parser.add_argument("--force", action="store_true", help="Start even if an existing PID file appears active.")
    parser.add_argument("--internal-monitor", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("command", nargs=argparse.REMAINDER, help="Command to launch after '--'.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    command = list(args.command)
    if command and command[0] == "--":
        command = command[1:]
    if not command:
        print("No command provided after '--'.", file=sys.stderr)
        return 2

    cwd = Path(args.cwd).resolve()
    log_dir = Path(args.log_dir)
    if not log_dir.is_absolute():
        log_dir = (ROOT / log_dir).resolve()
    log_dir.mkdir(parents=True, exist_ok=True)

    meta_path = log_dir / f"{args.name}.json"
    stdout_path = log_dir / f"{args.name}.out.log"
    stderr_path = log_dir / f"{args.name}.err.log"
    monitor_log_path = log_dir / f"{args.name}.monitor.log"

    existing = _read_json(meta_path)
    if existing and not args.force:
        existing_pid = existing.get("pid")
        if isinstance(existing_pid, int) and _pid_is_running(existing_pid):
            print(
                json.dumps(
                    {
                        "status": "already_running",
                        "pid": existing_pid,
                        "metadata": str(meta_path),
                        "stdout": str(stdout_path),
                        "stderr": str(stderr_path),
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
            return 0

    if args.internal_monitor:
        return _run_monitor(
            name=args.name,
            command=command,
            cwd=cwd,
            meta_path=meta_path,
            stdout_path=stdout_path,
            stderr_path=stderr_path,
        )

    creationflags = 0
    if os.name == "nt":
        creationflags |= getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        creationflags |= getattr(subprocess, "DETACHED_PROCESS", 0)
        creationflags |= getattr(subprocess, "CREATE_NO_WINDOW", 0)

    monitor_python = _monitor_python()
    monitor_command = [
        monitor_python,
        str(Path(__file__).resolve()),
        "--internal-monitor",
        "--name",
        args.name,
        "--log-dir",
        str(log_dir),
        "--cwd",
        str(cwd),
        "--force",
        "--",
        *command,
    ]

    with monitor_log_path.open("ab") as monitor_handle:
        process = subprocess.Popen(
            monitor_command,
            cwd=str(ROOT),
            stdin=subprocess.DEVNULL,
            stdout=monitor_handle,
            stderr=monitor_handle,
            close_fds=True,
            creationflags=creationflags,
        )

    metadata = {
        "status": "monitor_started",
        "pid": process.pid,
        "monitor_pid": process.pid,
        "name": args.name,
        "cwd": str(cwd),
        "command": command,
        "monitor_python": monitor_python,
        "stdout": str(stdout_path),
        "stderr": str(stderr_path),
        "monitor_log": str(monitor_log_path),
        "started_at_unix": time.time(),
    }
    meta_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({**metadata, "metadata": str(meta_path)}, ensure_ascii=False, indent=2))
    return 0


def _run_monitor(
    *,
    name: str,
    command: list[str],
    cwd: Path,
    meta_path: Path,
    stdout_path: Path,
    stderr_path: Path,
) -> int:
    metadata = {
        "status": "running",
        "pid": os.getpid(),
        "monitor_pid": os.getpid(),
        "child_pid": None,
        "name": name,
        "cwd": str(cwd),
        "command": command,
        "stdout": str(stdout_path),
        "stderr": str(stderr_path),
        "started_at_unix": time.time(),
    }
    meta_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    try:
        with stdout_path.open("ab") as stdout_handle, stderr_path.open("ab") as stderr_handle:
            child = subprocess.Popen(
                command,
                cwd=str(cwd),
                stdin=subprocess.DEVNULL,
                stdout=stdout_handle,
                stderr=stderr_handle,
                close_fds=True,
            )
            metadata["child_pid"] = child.pid
            meta_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
            exit_code = child.wait()
    except BaseException as exc:
        metadata.update(
            {
                "status": "launcher_error",
                "error_type": type(exc).__name__,
                "error": str(exc),
                "ended_at_unix": time.time(),
            }
        )
        meta_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
        return 1

    metadata.update({"status": "completed", "exit_code": exit_code, "ended_at_unix": time.time()})
    meta_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    return int(exit_code)


def _read_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


def _pid_is_running(pid: int) -> bool:
    if pid <= 0:
        return False
    if os.name == "nt":
        return _windows_pid_is_running(pid)
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def _windows_pid_is_running(pid: int) -> bool:
    process_query_limited_information = 0x1000
    still_active = 259
    handle = ctypes.windll.kernel32.OpenProcess(process_query_limited_information, False, pid)
    if not handle:
        return False
    try:
        exit_code = ctypes.c_ulong()
        ok = ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code))
        return bool(ok) and exit_code.value == still_active
    finally:
        ctypes.windll.kernel32.CloseHandle(handle)


def _monitor_python() -> str:
    if os.name != "nt":
        return sys.executable
    executable = Path(sys.executable)
    pythonw = executable.with_name("pythonw.exe")
    if pythonw.exists():
        return str(pythonw)
    return sys.executable


if __name__ == "__main__":
    raise SystemExit(main())
