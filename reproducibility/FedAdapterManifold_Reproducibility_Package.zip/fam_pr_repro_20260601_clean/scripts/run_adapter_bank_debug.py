from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.baselines import (
    run_adapter_bank_baseline,
    run_fedavg_lora_baseline,
    run_local_lora,
    summarize_method,
)
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.diagnostics import run_subspace_failure_diagnostic
from fedadaptermanifold.geometry import LocalPrototypeGeometry
from fedadaptermanifold.reporting import ensure_dir, save_routing_heatmap, write_csv


def main() -> int:
    output_dir = ensure_dir("results/fedadaptermanifold_step6")
    figures_dir = ensure_dir(output_dir / "figures")
    clients, base_weight = make_synthetic_manifold_clients(
        num_clients=4,
        num_classes=7,
        feature_dim=48,
        train_per_client=240,
        test_per_client=160,
        rank=4,
        seed=0,
    )
    ranks = [4, 4, 4, 4]
    local = run_local_lora(
        clients,
        base_weight,
        ranks=ranks,
        epochs=54,
        lr=0.45,
        batch_size=32,
        seed=0,
        dataset="pacs-debug",
        heterogeneity_setting="domain-adapter-manifold-debug",
        round_id=3,
    )
    geometry = LocalPrototypeGeometry().build(clients, num_classes=base_weight.shape[0], round_id=0)
    diagnostic = run_subspace_failure_diagnostic(
        clients,
        base_weight,
        local.adapters,
        d_geo=geometry.d_geo,
        lambda_geo=0.5,
        lambda_label=0.25,
        tau=1.0,
        diagnostic_threshold=0.05,
    )
    fedavg = run_fedavg_lora_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=3,
        local_epochs=18,
        lr=0.45,
        batch_size=32,
        seed=0,
        dataset="pacs-debug",
        heterogeneity_setting="domain-adapter-manifold-debug",
    )
    combined = diagnostic.d_sub + 0.5 * geometry.d_geo + 0.25 * diagnostic.d_label
    bank = run_adapter_bank_baseline(
        clients,
        base_weight,
        local.adapters,
        d_geo=geometry.d_geo,
        combined_distance=combined,
        ranks=ranks,
        k=2,
        route_tau=1.0,
        shared_weight=0.25,
        personal_weight=0.10,
        seed=0,
        dataset="pacs-debug",
        heterogeneity_setting="domain-adapter-manifold-debug",
        round_id=3,
    )
    per_client = []
    per_client.extend(local.per_client_metrics)
    per_client.extend(fedavg.per_client_metrics)
    per_client.extend(bank.per_client_metrics)
    metrics = summarize_method(per_client, diagnostic.pearson_r)
    by_method = {row["method"]: row for row in metrics}
    supports_idea = (
        diagnostic.passed
        and by_method["Local-LoRA"]["mean_accuracy"] > by_method["FedAvg-LoRA"]["mean_accuracy"]
        and by_method["FedAdapterManifold"]["mean_accuracy"] > by_method["FedAvg-LoRA"]["mean_accuracy"]
    )
    write_csv(output_dir / "metrics.csv", metrics)
    write_csv(output_dir / "per_client_metrics.csv", per_client)
    write_csv(output_dir / "adapter_bank_weights.csv", bank.routing_rows)
    write_csv(
        output_dir / "idea_support.csv",
        [
            {
                "supports_idea": supports_idea,
                "subspace_failure_pearson_r": diagnostic.pearson_r,
                "local_minus_fedavg_lora": by_method["Local-LoRA"]["mean_accuracy"] - by_method["FedAvg-LoRA"]["mean_accuracy"],
                "adapter_bank_minus_fedavg_lora": by_method["FedAdapterManifold"]["mean_accuracy"] - by_method["FedAvg-LoRA"]["mean_accuracy"],
            }
        ],
    )
    save_routing_heatmap(bank.bank.routing_weights, [client.domain for client in clients], figures_dir / "adapter_bank_routing.png")
    return 0 if supports_idea else 2


if __name__ == "__main__":
    raise SystemExit(main())
