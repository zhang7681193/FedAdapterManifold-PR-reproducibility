from __future__ import annotations

from pathlib import Path
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv
from fedadaptermanifold.run_experiment import main as run_experiment


DATASETS = [
    ("pacs-debug", "configs/pacs_debug.yaml"),
    ("cifar10-debug", "configs/cifar10_debug.yaml"),
]
SEEDS = [0, 1, 2]
BANK_K = [1, 2, 4]


def _read_metrics(path: Path) -> dict[str, dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return {row["method"]: row for row in csv.DictReader(handle)}


def _read_first_row(path: Path) -> dict:
    with path.open("r", newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    return rows[0] if rows else {}


def main() -> int:
    root = ensure_dir("results/fedadaptermanifold_k_sweep")
    detail_rows = []
    for dataset_name, config_path in DATASETS:
        for seed in SEEDS:
            for k in BANK_K:
                output_dir = root / dataset_name / f"seed_{seed}" / f"k_{k}"
                code = run_experiment(
                    [
                        "--config",
                        config_path,
                        "--seed",
                        str(seed),
                        "--rank-policy",
                        "fixed",
                        "--adapter-bank-k",
                        str(k),
                        "--personal-weight",
                        "0.0",
                        "--output-dir",
                        str(output_dir),
                    ]
                )
                metrics = _read_metrics(output_dir / "metrics.csv")
                support = _read_first_row(output_dir / "idea_support.csv")
                fedavg = metrics["FedAvg-LoRA"]
                local = metrics["Local-LoRA"]
                bank = metrics.get("FedAdapterManifold", {"mean_accuracy": "nan"})
                client_route = metrics.get("FedAdapterManifold-ClientRoute", {"mean_accuracy": "nan"})
                detail_rows.append(
                    {
                        "dataset": dataset_name,
                        "seed": seed,
                        "adapter_bank_k": k,
                        "supports_idea": support.get("supports_idea", code == 0),
                        "exit_code": code,
                        "fedavg_lora_accuracy": float(fedavg["mean_accuracy"]),
                        "local_accuracy": float(local["mean_accuracy"]),
                        "adapter_bank_accuracy": float(bank["mean_accuracy"]),
                        "client_route_accuracy": float(client_route["mean_accuracy"]),
                        "adapter_bank_minus_fedavg_lora": float(bank["mean_accuracy"]) - float(fedavg["mean_accuracy"]),
                        "adapter_bank_minus_k1": "",
                        "subspace_failure_pearson_r": float(bank["subspace_failure_pearson_r"]),
                        "geo_failure_pearson_r": float(bank.get("geo_failure_pearson_r", "nan")),
                        "output_dir": str(output_dir),
                    }
                )

    _add_k1_deltas(detail_rows)
    summary_rows = []
    for dataset_name, _ in DATASETS:
        dataset_rows = [row for row in detail_rows if row["dataset"] == dataset_name]
        k1_by_seed = {
            int(row["seed"]): float(row["adapter_bank_accuracy"])
            for row in dataset_rows
            if int(row["adapter_bank_k"]) == 1
        }
        for k in BANK_K:
            rows = [row for row in dataset_rows if int(row["adapter_bank_k"]) == k]
            support_count = sum(str(row["supports_idea"]).lower() == "true" for row in rows)
            k1_gain_count = sum(
                1
                for row in rows
                if k > 1 and float(row["adapter_bank_accuracy"]) > k1_by_seed[int(row["seed"])]
            )
            summary_rows.append(
                {
                    "dataset": dataset_name,
                    "adapter_bank_k": k,
                    "support_count": support_count,
                    "total_runs": len(rows),
                    "support_rate": support_count / len(rows),
                    "beats_k1_count": "" if k == 1 else k1_gain_count,
                    "beats_k1_rate": "" if k == 1 else k1_gain_count / len(rows),
                    "mean_adapter_bank_accuracy": _mean(rows, "adapter_bank_accuracy"),
                    "mean_adapter_bank_minus_fedavg_lora": _mean(rows, "adapter_bank_minus_fedavg_lora"),
                    "mean_adapter_bank_minus_k1": "" if k == 1 else _mean(rows, "adapter_bank_minus_k1"),
                    "mean_subspace_failure_pearson_r": _mean(rows, "subspace_failure_pearson_r"),
                    "mean_geo_failure_pearson_r": _mean(rows, "geo_failure_pearson_r"),
                }
            )

    write_csv(root / "adapter_bank_k_sweep_details.csv", detail_rows)
    write_csv(root / "adapter_bank_k_sweep_summary.csv", summary_rows)
    multi_bank_rows = [row for row in summary_rows if int(row["adapter_bank_k"]) > 1]
    return 0 if all(float(row["support_rate"]) >= 1.0 for row in multi_bank_rows) else 2


def _add_k1_deltas(rows: list[dict]) -> None:
    k1 = {
        (row["dataset"], int(row["seed"])): float(row["adapter_bank_accuracy"])
        for row in rows
        if int(row["adapter_bank_k"]) == 1
    }
    for row in rows:
        key = (row["dataset"], int(row["seed"]))
        row["adapter_bank_minus_k1"] = float(row["adapter_bank_accuracy"]) - k1[key]


def _mean(rows: list[dict], key: str) -> float:
    values = [float(row[key]) for row in rows if row.get(key) not in {"", None}]
    return sum(values) / len(values) if values else float("nan")


if __name__ == "__main__":
    raise SystemExit(main())
