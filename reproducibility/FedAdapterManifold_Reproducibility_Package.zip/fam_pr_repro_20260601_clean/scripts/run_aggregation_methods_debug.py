from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.baselines import (
    run_fedavg_lift_baseline,
    run_fedavg_lora_baseline,
    run_local_lora,
    run_subspace_compatible_baseline,
    summarize_method,
)
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.diagnostics import run_subspace_failure_diagnostic
from fedadaptermanifold.geometry import LocalPrototypeGeometry
from fedadaptermanifold.reporting import ensure_dir, write_csv


def main() -> int:
    output_dir = ensure_dir("results/fedadaptermanifold_step5")
    clients, base_weight = make_synthetic_manifold_clients(
        num_clients=4,
        num_classes=7,
        feature_dim=48,
        train_per_client=240,
        test_per_client=160,
        rank=4,
        seed=0,
    )
    ranks = [4, 4, 4, 4]
    local = run_local_lora(
        clients,
        base_weight,
        ranks=ranks,
        epochs=54,
        lr=0.45,
        batch_size=32,
        seed=0,
        dataset="pacs-debug",
        heterogeneity_setting="domain-adapter-manifold-debug",
        round_id=3,
    )
    geometry = LocalPrototypeGeometry().build(clients, num_classes=base_weight.shape[0], round_id=0)
    diagnostic = run_subspace_failure_diagnostic(
        clients,
        base_weight,
        local.adapters,
        d_geo=geometry.d_geo,
        lambda_geo=0.5,
        lambda_label=0.25,
        tau=1.0,
        diagnostic_threshold=0.05,
    )
    fedavg_lora = run_fedavg_lora_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=3,
        local_epochs=18,
        lr=0.45,
        batch_size=32,
        seed=0,
        dataset="pacs-debug",
        heterogeneity_setting="domain-adapter-manifold-debug",
    )
    fedavg_lift = run_fedavg_lift_baseline(
        clients,
        base_weight,
        ranks=ranks,
        rounds=3,
        local_epochs=18,
        lr=0.45,
        batch_size=32,
        seed=0,
        dataset="pacs-debug",
        heterogeneity_setting="domain-adapter-manifold-debug",
    )
    subspace = run_subspace_compatible_baseline(
        clients,
        base_weight,
        local.adapters,
        diagnostic.compatibility,
        ranks=ranks,
        seed=0,
        dataset="pacs-debug",
        heterogeneity_setting="domain-adapter-manifold-debug",
        round_id=3,
    )
    per_client = []
    per_client.extend(local.per_client_metrics)
    per_client.extend(fedavg_lora.per_client_metrics)
    per_client.extend(fedavg_lift.per_client_metrics)
    per_client.extend(subspace.per_client_metrics)
    metrics = summarize_method(per_client, diagnostic.pearson_r)
    by_method = {row["method"]: row for row in metrics}
    supports_idea = (
        by_method["Local-LoRA"]["mean_accuracy"] > by_method["FedAvg-LoRA"]["mean_accuracy"]
        and diagnostic.passed
        and by_method["Subspace-Compatible"]["mean_accuracy"] >= by_method["FedAvg-LoRA"]["mean_accuracy"]
    )
    write_csv(output_dir / "metrics.csv", metrics)
    write_csv(output_dir / "per_client_metrics.csv", per_client)
    write_csv(output_dir / "fedavg_lora_history.csv", fedavg_lora.round_history)
    write_csv(output_dir / "fedavg_lift_history.csv", fedavg_lift.round_history)
    write_csv(output_dir / "idea_support.csv", [
        {
            "supports_idea": supports_idea,
            "subspace_failure_pearson_r": diagnostic.pearson_r,
            "local_minus_fedavg_lora": by_method["Local-LoRA"]["mean_accuracy"] - by_method["FedAvg-LoRA"]["mean_accuracy"],
            "subspace_minus_fedavg_lora": by_method["Subspace-Compatible"]["mean_accuracy"] - by_method["FedAvg-LoRA"]["mean_accuracy"],
        }
    ])
    return 0 if supports_idea else 2


if __name__ == "__main__":
    raise SystemExit(main())
