from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv
from scripts.run_fedgeo_multiseed import main as run_multiseed


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run CIFAR-10 Dirichlet label-skew heterogeneity sweep.")
    parser.add_argument("--config", type=str, default="configs/cifar10_numpy.yaml")
    parser.add_argument("--output-root", type=str, default="results/cifar10_heterogeneity_sweep")
    parser.add_argument("--data-root", type=str, required=True)
    parser.add_argument("--alphas", type=str, default="0.1,0.3,1.0,10.0")
    parser.add_argument("--seeds", type=str, default="0,1,2")
    parser.add_argument("--round-id", type=int, default=0)
    parser.add_argument("--train-per-client", type=str, default="")
    parser.add_argument("--test-per-client", type=str, default="")
    parser.add_argument("--rounds", type=str, default="")
    parser.add_argument("--local-epochs", type=str, default="")
    parser.add_argument("--min-train-size", type=str, default="")
    parser.add_argument("--continue-on-failed-diagnostic", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    output_root = ensure_dir(args.output_root)
    run_rows = []
    summary_rows = []
    failed = False
    for alpha in _split_csv(args.alphas):
        alpha_tag = str(alpha).replace(".", "p")
        out_dir = output_root / f"alpha_{alpha_tag}"
        multiseed_args = [
            "--config",
            args.config,
            "--output-root",
            str(out_dir),
            "--data-root",
            args.data_root,
            "--seeds",
            args.seeds,
            "--round-id",
            str(args.round_id),
            "--dirichlet-alpha",
            str(alpha),
        ]
        for cli_name, value in [
            ("--train-per-client", args.train_per_client),
            ("--test-per-client", args.test_per_client),
            ("--rounds", args.rounds),
            ("--local-epochs", args.local_epochs),
            ("--min-train-size", args.min_train_size),
        ]:
            if value != "":
                multiseed_args.extend([cli_name, value])
        if args.continue_on_failed_diagnostic:
            multiseed_args.append("--continue-on-failed-diagnostic")
        code = run_multiseed(multiseed_args)
        failed = failed or code != 0
        run_rows.append({"alpha": alpha, "exit_code": code, "output_dir": str(out_dir)})
        summary_rows.append(_summarize_alpha(alpha, out_dir, code))

    write_csv(output_root / "heterogeneity_sweep_runs.csv", run_rows)
    write_csv(output_root / "heterogeneity_sweep_summary.csv", summary_rows)
    return 2 if failed else 0


def _summarize_alpha(alpha: str, out_dir: Path, code: int) -> dict:
    summary = _read_csv(out_dir / "multiseed_summary.csv")
    claims = _read_csv(out_dir / "multiseed_claim_report.csv")
    metrics = {
        (row.get("test", ""), row.get("method", ""), row.get("baseline", ""), row.get("measure", "")): row
        for row in summary
    }
    claim = {row.get("claim_id", ""): row for row in claims}
    return {
        "alpha": alpha,
        "exit_code": code,
        "overall_core_support": claim.get("overall_core_support", {}).get("supports", ""),
        "secondary_caveats": claim.get("overall_core_support", {}).get("secondary_caveats", ""),
        "fedavg_accuracy": _metric(metrics, "method_accuracy", "FedAvg-LoRA", "", "mean_accuracy"),
        "fedgeo_agg_accuracy": _metric(metrics, "method_accuracy", "FedGeo-Agg", "", "mean_accuracy"),
        "fedadapter_accuracy": _metric(metrics, "method_accuracy", "FedAdapterManifold", "", "mean_accuracy"),
        "local_lora_accuracy": _metric(metrics, "method_accuracy", "Local-LoRA", "", "mean_accuracy"),
        "local_minus_fedavg": _diff(
            _metric(metrics, "method_accuracy", "Local-LoRA", "", "mean_accuracy"),
            _metric(metrics, "method_accuracy", "FedAvg-LoRA", "", "mean_accuracy"),
        ),
        "gain_vs_fedavg": _claim(claim, "adapter_bank_gain_vs_fedavg", "estimate"),
        "gain_vs_fedavg_ci_low": _claim(claim, "adapter_bank_gain_vs_fedavg", "ci_low"),
        "gain_vs_fedgeo_agg": _claim(claim, "adapter_bank_gain_vs_fedgeo_agg", "estimate"),
        "gain_vs_fedgeo_agg_ci_low": _claim(claim, "adapter_bank_gain_vs_fedgeo_agg", "ci_low"),
        "update_conflict_reduction_vs_fedgeo_agg": _claim(claim, "update_conflict_reduction_vs_fedgeo_agg", "estimate"),
        "update_conflict_reduction_ci_low": _claim(claim, "update_conflict_reduction_vs_fedgeo_agg", "ci_low"),
        "adapter_incompatibility_failure_r": _claim(claim, "adapter_incompatibility_failure_correlation", "estimate"),
        "adapter_incompatibility_failure_ci_low": _claim(claim, "adapter_incompatibility_failure_correlation", "ci_low"),
        "raw_subspace_failure_r": _claim(claim, "raw_subspace_failure_correlation", "estimate"),
        "d_geo_failure_r": _claim(claim, "geometry_failure_correlation", "estimate"),
        "output_dir": str(out_dir),
    }


def _metric(metrics: dict[tuple[str, str, str, str], dict], test: str, method: str, baseline: str, measure: str) -> str:
    return metrics.get((test, method, baseline, measure), {}).get("estimate", "")


def _claim(claim: dict[str, dict], claim_id: str, field: str) -> str:
    return claim.get(claim_id, {}).get(field, "")


def _diff(left: str, right: str) -> str:
    try:
        return str(float(left) - float(right))
    except (TypeError, ValueError):
        return ""


def _split_csv(text: str) -> list[str]:
    return [part.strip() for part in str(text).split(",") if part.strip()]


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


if __name__ == "__main__":
    raise SystemExit(main())
