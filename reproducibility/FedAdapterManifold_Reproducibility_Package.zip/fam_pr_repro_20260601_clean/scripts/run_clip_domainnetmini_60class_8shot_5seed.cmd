@echo off
setlocal

if "%PYTHON_EXE%"=="" set "PYTHON_EXE=python"
if "%DATA_ROOT%"=="" set "DATA_ROOT=data\DomainNetMini"
if "%GEOMETRY_OUTPUTS_DIR%"=="" set "GEOMETRY_OUTPUTS_DIR=geometry_outputs\domainnetmini_round4"
if "%OUT_ROOT%"=="" set "OUT_ROOT=results\fam_clip_vit_lora_federated_domainnetmini_60class_8shot_5seed_v1"

if not exist "%OUT_ROOT%" mkdir "%OUT_ROOT%"
echo [%date% %time%] Starting DomainNetMini-60 CLIP ViT larger split 8/8-shot 5-seed run. > "%OUT_ROOT%\launcher_status.log"

for %%S in (0 1 2 3 4) do (
    if exist "%OUT_ROOT%\seed_%%S\metrics.csv" (
        echo [%date% %time%] Seed %%S already complete; skipping. >> "%OUT_ROOT%\launcher_status.log"
    ) else (
        echo [%date% %time%] Running seed %%S. >> "%OUT_ROOT%\launcher_status.log"
        "%PYTHON_EXE%" scripts\run_clip_vit_lora_federated_main.py ^
            --data-root "%DATA_ROOT%" ^
            --output-dir "%OUT_ROOT%\seed_%%S" ^
            --dataset DomainNetMini ^
            --domains clipart,infograph,painting,quickdraw,real,sketch ^
            --num-classes 60 ^
            --train-per-class 8 ^
            --test-per-class 8 ^
            --calibration-fraction 0.2 ^
            --local-epochs 2 ^
            --batch-size 8 ^
            --rank 4 ^
            --lr 0.0005 ^
            --seed %%S ^
            --device cuda ^
            --model-name ViT-B/16 ^
            --lora-blocks 2 ^
            --geometry-outputs-dir "%GEOMETRY_OUTPUTS_DIR%" ^
            --round-id 4 ^
            --graph-self-weight 0.35 ^
            --tau-geo 0.5 ^
            --tau-fam 0.75 ^
            --lambda-geo 0.35 ^
            --fam-self-weight 0.45 ^
            --graph-k 2
        if errorlevel 1 exit /b 1
        echo [%date% %time%] Completed seed %%S. >> "%OUT_ROOT%\launcher_status.log"
    )
)

echo [%date% %time%] Aggregating seeds. >> "%OUT_ROOT%\launcher_status.log"
"%PYTHON_EXE%" scripts\aggregate_clip_vit_lora_multiseed.py ^
    --output-root "%OUT_ROOT%" ^
    --seed-dir 0="%OUT_ROOT%\seed_0" ^
    --seed-dir 1="%OUT_ROOT%\seed_1" ^
    --seed-dir 2="%OUT_ROOT%\seed_2" ^
    --seed-dir 3="%OUT_ROOT%\seed_3" ^
    --seed-dir 4="%OUT_ROOT%\seed_4"
if errorlevel 1 exit /b 1

echo [%date% %time%] Finished DomainNetMini-60 CLIP ViT larger split 8/8-shot 5-seed run. >> "%OUT_ROOT%\launcher_status.log"
endlocal
