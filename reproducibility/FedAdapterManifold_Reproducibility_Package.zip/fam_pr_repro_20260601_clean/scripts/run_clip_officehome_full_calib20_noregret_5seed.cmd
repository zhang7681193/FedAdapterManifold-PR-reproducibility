@echo off
setlocal

set "ROOT=%~dp0.."
if "%PY%"=="" set "PY=python"
set "SOURCE_ROOT=%ROOT%\results\fam_officehome_ditto_fam_guarded_audit_5seed_v1"
if "%OUT_ROOT%"=="" set "OUT_ROOT=%ROOT%\results\fam_clip_officehome_full_calib20_noregret_5seed_v1"
set "FEATURE_CACHE=%ROOT%\results\feature_cache\office_home_clip_vit_b16"
set "STATUS_LOG=%OUT_ROOT%\launcher_status.log"

if not exist "%OUT_ROOT%" mkdir "%OUT_ROOT%"
echo [%date% %time%] Starting full OfficeHome-CLIP ViT-B/16 calib20 anchored-no-regret 5-seed run.>> "%STATUS_LOG%"

for %%S in (0 1 2 3 4) do (
    if not exist "%OUT_ROOT%\seed_%%S" mkdir "%OUT_ROOT%\seed_%%S"
    if exist "%OUT_ROOT%\seed_%%S\metrics.csv" (
        echo [%date% %time%] Seed %%S already complete; skipping.>> "%STATUS_LOG%"
    ) else (
        echo [%date% %time%] Running seed %%S.>> "%STATUS_LOG%"
        "%PY%" -m fedadaptermanifold.run_experiment ^
            --config "%SOURCE_ROOT%\seed_%%S\config.yaml" ^
            --seed %%S ^
            --feature-backbone clip-vit-b16 ^
            --feature-cache-dir "%FEATURE_CACHE%" ^
            --output-dir "%OUT_ROOT%\seed_%%S" ^
            --base-head-init zero ^
            --candidate-selector-calibration-fraction 0.2 ^
            --candidate-selector-policy diagnostic-gated ^
            --strong-candidate-selector-policy anchored-no-regret ^
            --no-cpu-debug ^
            --device cpu ^
            > "%OUT_ROOT%\seed_%%S\run.log" 2> "%OUT_ROOT%\seed_%%S\run.err.log"
        if errorlevel 1 (
            echo [%date% %time%] Seed %%S failed with errorlevel %ERRORLEVEL%.>> "%STATUS_LOG%"
            exit /b 1
        )
        if not exist "%OUT_ROOT%\seed_%%S\metrics.csv" (
            echo [%date% %time%] Seed %%S finished without metrics.csv.>> "%STATUS_LOG%"
            exit /b 2
        )
        echo [%date% %time%] Completed seed %%S.>> "%STATUS_LOG%"
    )
)

echo [%date% %time%] Aggregating seeds.>> "%STATUS_LOG%"
"%PY%" scripts\aggregate_existing_multiseed.py ^
    --output-root "%OUT_ROOT%" ^
    --seed-dir "0=%OUT_ROOT%\seed_0" ^
    --seed-dir "1=%OUT_ROOT%\seed_1" ^
    --seed-dir "2=%OUT_ROOT%\seed_2" ^
    --seed-dir "3=%OUT_ROOT%\seed_3" ^
    --seed-dir "4=%OUT_ROOT%\seed_4" ^
    > "%OUT_ROOT%\aggregate.log" 2> "%OUT_ROOT%\aggregate.err.log"
if errorlevel 1 (
    echo [%date% %time%] Aggregation failed with errorlevel %ERRORLEVEL%.>> "%STATUS_LOG%"
    exit /b 3
)

echo [%date% %time%] Finished full OfficeHome-CLIP ViT-B/16 calib20 anchored-no-regret 5-seed run.>> "%STATUS_LOG%"
exit /b 0
