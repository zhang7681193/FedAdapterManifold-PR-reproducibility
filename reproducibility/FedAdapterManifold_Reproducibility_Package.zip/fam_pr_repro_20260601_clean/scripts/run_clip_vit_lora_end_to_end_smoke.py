from __future__ import annotations

import argparse
import csv
import json
import random
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


@dataclass
class SmokeConfig:
    data_root: str
    output_dir: str
    domains: str
    num_classes: int
    train_per_class: int
    test_per_class: int
    epochs: int
    batch_size: int
    rank: int
    lr: float
    seed: int
    device: str
    model_name: str
    lora_blocks: int
    prompt_template: str
    method_name: str


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "End-to-end CLIP ViT LoRA experiment. Small defaults are suitable for "
            "a smoke test; larger domain/class/sample settings provide VFM evidence."
        )
    )
    parser.add_argument("--data-root", type=str, required=True)
    parser.add_argument("--output-dir", type=str, default="results/fam_clip_vit_lora_end_to_end_smoke_v1")
    parser.add_argument("--domains", type=str, default="clipart,real")
    parser.add_argument("--num-classes", type=int, default=8)
    parser.add_argument("--train-per-class", type=int, default=2)
    parser.add_argument("--test-per-class", type=int, default=2)
    parser.add_argument("--epochs", type=int, default=1)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--rank", type=int, default=2)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--model-name", type=str, default="ViT-B/16")
    parser.add_argument("--lora-blocks", type=int, default=1)
    parser.add_argument("--prompt-template", type=str, default="a photo of a {label}.")
    parser.add_argument("--method-name", type=str, default="EndToEnd-CLIPViT-LoRA")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    config = SmokeConfig(**vars(args))
    output_dir = Path(config.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        import clip
        import torch
        import torch.nn as nn
        import torch.nn.functional as F
        from PIL import Image
    except Exception as exc:  # pragma: no cover - depends on optional torch env
        _write_blocker(output_dir, config, f"Missing torch/clip/PIL dependency: {exc}")
        return 2

    device = config.device
    if device == "cuda" and not torch.cuda.is_available():
        device = "cpu"

    _set_seed(config.seed, torch)
    model, preprocess = clip.load(config.model_name, device=device)
    model.float()
    model.train()
    for param in model.parameters():
        param.requires_grad_(False)

    lora_modules = inject_visual_attention_lora(model, rank=config.rank, blocks=config.lora_blocks, torch=torch, nn=nn, F=F)
    for module in lora_modules:
        module.to(device)
    trainable = [param for module in lora_modules for param in module.parameters() if param.requires_grad]
    if not trainable:
        _write_blocker(output_dir, config, "No trainable LoRA parameters were injected.")
        return 2

    data_root = Path(config.data_root)
    domains = [value.strip() for value in config.domains.split(",") if value.strip()]
    class_names = _select_classes(data_root, domains, config.num_classes)
    if not class_names:
        _write_blocker(output_dir, config, "No shared classes found in the requested DomainNetMini domains.")
        return 2

    train_samples = _collect_samples(data_root, domains, class_names, "train", config.train_per_class, config.seed)
    test_samples = _collect_samples(data_root, domains, class_names, "test", config.test_per_class, config.seed + 17)
    if not train_samples or not test_samples:
        _write_blocker(output_dir, config, "Could not collect train/test images for the smoke test.")
        return 2

    text_features = _text_features(model, clip, class_names, config.prompt_template, device, torch)
    model.eval()
    baseline = _evaluate(
        model,
        preprocess,
        text_features,
        test_samples,
        class_names,
        device,
        config.batch_size,
        Image,
        torch,
        method="CLIP-ZeroShot",
    )

    optimizer = torch.optim.AdamW(trainable, lr=config.lr)
    history: list[dict[str, float | int]] = []
    model.train()
    for epoch in range(config.epochs):
        random.Random(config.seed + epoch).shuffle(train_samples)
        losses: list[float] = []
        for batch in _batches(train_samples, config.batch_size):
            images, labels = _load_batch(batch, preprocess, class_names, device, Image, torch)
            optimizer.zero_grad(set_to_none=True)
            image_features = model.encode_image(images)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True).clamp_min(1e-12)
            logits = model.logit_scale.exp().float() * image_features.float() @ text_features.float().t()
            loss = F.cross_entropy(logits, labels)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, 1.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
        history.append({"epoch": epoch, "mean_train_loss": sum(losses) / max(1, len(losses))})

    model.eval()
    adapted = _evaluate(
        model,
        preprocess,
        text_features,
        test_samples,
        class_names,
        device,
        config.batch_size,
        Image,
        torch,
        method=config.method_name,
    )

    _write_csv(
        output_dir / "metrics.csv",
        [
            {
                "method": "CLIP-ZeroShot",
                "seed": config.seed,
                "dataset": "DomainNetMini",
                "heterogeneity": config.domains,
                "num_classes": len(class_names),
                "accuracy": baseline["accuracy"],
                "loss": baseline["loss"],
                "num_samples": baseline["num_samples"],
            },
            {
                "method": config.method_name,
                "seed": config.seed,
                "dataset": "DomainNetMini",
                "heterogeneity": config.domains,
                "num_classes": len(class_names),
                "accuracy": adapted["accuracy"],
                "loss": adapted["loss"],
                "num_samples": adapted["num_samples"],
            },
        ],
    )
    _write_csv(output_dir / "per_domain_metrics.csv", baseline["per_domain"] + adapted["per_domain"])
    _write_csv(output_dir / "training_history.csv", history)
    config_payload = asdict(config)
    config_payload.update({"effective_device": device, "class_names": class_names})
    (output_dir / "config.json").write_text(json.dumps(config_payload, indent=2), encoding="utf-8")
    (output_dir / "README.md").write_text(
        "\n".join(
            [
                "# End-to-end CLIP ViT LoRA",
                "",
                "This run injects trainable LoRA factors into the visual transformer attention block(s) of OpenAI CLIP ViT and backpropagates through the image encoder.",
                "Tiny settings are used as an implementation sanity check; larger multi-domain settings are reported as end-to-end VFM evidence separate from the main feature-level FedAdapterManifold table.",
            ]
        ),
        encoding="utf-8",
    )
    return 0


def inject_visual_attention_lora(model, rank: int, blocks: int, torch, nn, F):
    resblocks = model.visual.transformer.resblocks
    modules = []
    for idx in range(len(resblocks) - max(1, blocks), len(resblocks)):
        base_attn = resblocks[idx].attn
        wrapped = LoRAMultiheadAttention(base_attn, rank=rank, torch=torch, nn=nn, F=F)
        resblocks[idx].attn = wrapped
        modules.append(wrapped)
    return modules


class LoRAMultiheadAttention:
    def __new__(cls, base_attn, rank: int, torch, nn, F):
        class _Wrapped(nn.Module):
            def __init__(self):
                super().__init__()
                self.base = base_attn
                self.rank = int(rank)
                self.scale = 1.0 / max(1, self.rank)
                embed_dim = int(base_attn.embed_dim)
                self.lora_a = nn.Parameter(torch.empty(self.rank, embed_dim))
                self.lora_b = nn.Parameter(torch.zeros(3 * embed_dim, self.rank))
                nn.init.kaiming_uniform_(self.lora_a, a=5**0.5)
                for param in self.base.parameters():
                    param.requires_grad_(False)

            def forward(self, query, key, value, key_padding_mask=None, need_weights=True, attn_mask=None):
                delta = (self.lora_b @ self.lora_a) * self.scale
                in_proj_weight = self.base.in_proj_weight + delta.to(dtype=self.base.in_proj_weight.dtype)
                return F.multi_head_attention_forward(
                    query,
                    key,
                    value,
                    self.base.embed_dim,
                    self.base.num_heads,
                    in_proj_weight,
                    self.base.in_proj_bias,
                    self.base.bias_k,
                    self.base.bias_v,
                    self.base.add_zero_attn,
                    self.base.dropout,
                    self.base.out_proj.weight,
                    self.base.out_proj.bias,
                    self.training,
                    key_padding_mask,
                    need_weights,
                    attn_mask,
                    use_separate_proj_weight=False,
                    average_attn_weights=True,
                )

        return _Wrapped()


def _select_classes(data_root: Path, domains: list[str], limit: int) -> list[str]:
    shared: set[str] | None = None
    for domain in domains:
        class_dir = data_root / domain / "train"
        names = {path.name for path in class_dir.iterdir() if path.is_dir()} if class_dir.exists() else set()
        shared = names if shared is None else shared & names
    return sorted(shared or [])[: max(1, limit)]


def _collect_samples(data_root: Path, domains: list[str], class_names: list[str], split: str, per_class: int, seed: int) -> list[dict[str, str]]:
    rng = random.Random(seed)
    samples: list[dict[str, str]] = []
    for domain in domains:
        for label in class_names:
            folder = data_root / domain / split / label
            files = sorted(path for path in folder.glob("*") if path.suffix.lower() in {".jpg", ".jpeg", ".png"})
            rng.shuffle(files)
            for path in files[:per_class]:
                samples.append({"path": str(path), "label": label, "domain": domain})
    rng.shuffle(samples)
    return samples


def _text_features(model, clip, class_names: list[str], template: str, device: str, torch):
    prompts = [template.format(label=name.replace("_", " ")) for name in class_names]
    with torch.no_grad():
        tokens = clip.tokenize(prompts, truncate=True).to(device)
        features = model.encode_text(tokens).float()
        return features / features.norm(dim=-1, keepdim=True).clamp_min(1e-12)


def _evaluate(model, preprocess, text_features, samples, class_names, device, batch_size, Image, torch, method: str):
    import torch.nn.functional as F

    correct = 0
    total = 0
    losses: list[float] = []
    domain_rows: dict[str, dict[str, float | str | int]] = {}
    with torch.no_grad():
        for batch in _batches(samples, batch_size):
            images, labels = _load_batch(batch, preprocess, class_names, device, Image, torch)
            image_features = model.encode_image(images)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True).clamp_min(1e-12)
            logits = model.logit_scale.exp().float() * image_features.float() @ text_features.float().t()
            losses.append(float(F.cross_entropy(logits, labels).detach().cpu()))
            preds = logits.argmax(dim=1)
            correct_mask = (preds == labels).detach().cpu().tolist()
            for sample, is_correct in zip(batch, correct_mask):
                row = domain_rows.setdefault(sample["domain"], {"domain": sample["domain"], "correct": 0, "num_samples": 0})
                row["correct"] = int(row["correct"]) + int(is_correct)
                row["num_samples"] = int(row["num_samples"]) + 1
            correct += int((preds == labels).sum().detach().cpu())
            total += int(labels.numel())
    per_domain = []
    for row in domain_rows.values():
        count = int(row["num_samples"])
        per_domain.append(
            {
                "method": method,
                "domain": row["domain"],
                "accuracy": float(row["correct"]) / max(1, count),
                "num_samples": count,
            }
        )
    return {"accuracy": correct / max(1, total), "loss": sum(losses) / max(1, len(losses)), "num_samples": total, "per_domain": per_domain}


def _load_batch(batch, preprocess, class_names, device, Image, torch):
    tensors = []
    labels = []
    for sample in batch:
        with Image.open(sample["path"]) as image:
            tensors.append(preprocess(image.convert("RGB")))
        labels.append(class_names.index(sample["label"]))
    return torch.stack(tensors, dim=0).to(device), torch.tensor(labels, dtype=torch.long, device=device)


def _batches(items, batch_size: int):
    for start in range(0, len(items), max(1, batch_size)):
        yield items[start : start + max(1, batch_size)]


def _set_seed(seed: int, torch) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames = sorted({key for row in rows for key in row.keys()})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _write_blocker(output_dir: Path, config: SmokeConfig, reason: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "blocker.json").write_text(json.dumps({"reason": reason, "config": asdict(config)}, indent=2), encoding="utf-8")
    _write_csv(output_dir / "metrics.csv", [{"method": config.method_name, "status": "blocked", "reason": reason}])


if __name__ == "__main__":
    raise SystemExit(main())
