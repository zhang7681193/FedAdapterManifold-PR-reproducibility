from __future__ import annotations

import argparse
import csv
import json
import math
import random
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


@dataclass
class Config:
    data_root: str
    output_dir: str
    dataset: str
    domains: str
    num_classes: int
    train_per_class: int
    test_per_class: int
    calibration_fraction: float
    local_epochs: int
    batch_size: int
    rank: int
    lr: float
    seed: int
    device: str
    model_name: str
    lora_blocks: int
    prompt_template: str
    class_labels: str
    geometry_outputs_dir: str
    round_id: int
    graph_self_weight: float
    tau_geo: float
    tau_fam: float
    lambda_geo: float
    fam_self_weight: float
    graph_k: int


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Federated end-to-end CLIP ViT LoRA experiment for FedAdapterManifold. "
            "Each domain is a client; local visual attention LoRA adapters are trained, "
            "then combined by FedAvg, lifted averaging, FedGeo graph aggregation, and "
            "subspace/geometry-conditioned FAM."
        )
    )
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--output-dir", default="results/fam_clip_vit_lora_federated_main_v1/seed_0")
    parser.add_argument("--dataset", default="DomainNetMini")
    parser.add_argument("--domains", default="clipart,infograph,painting,quickdraw,real,sketch")
    parser.add_argument("--num-classes", type=int, default=20)
    parser.add_argument("--train-per-class", type=int, default=4)
    parser.add_argument("--test-per-class", type=int, default=4)
    parser.add_argument("--calibration-fraction", type=float, default=0.2)
    parser.add_argument("--local-epochs", type=int, default=2)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--rank", type=int, default=4)
    parser.add_argument("--lr", type=float, default=5e-4)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--model-name", default="ViT-B/16")
    parser.add_argument("--lora-blocks", type=int, default=2)
    parser.add_argument("--prompt-template", default="a photo of a {label}.")
    parser.add_argument(
        "--class-labels",
        default="",
        help="Optional comma-separated semantic labels aligned with sorted class folders.",
    )
    parser.add_argument("--geometry-outputs-dir", default="")
    parser.add_argument("--round-id", type=int, default=0)
    parser.add_argument("--graph-self-weight", type=float, default=0.35)
    parser.add_argument("--tau-geo", type=float, default=0.5)
    parser.add_argument("--tau-fam", type=float, default=0.75)
    parser.add_argument("--lambda-geo", type=float, default=0.35)
    parser.add_argument("--fam-self-weight", type=float, default=0.45)
    parser.add_argument("--graph-k", type=int, default=2)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    config = Config(**vars(args))
    output_dir = Path(config.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    try:
        import clip
        import torch
        import torch.nn as nn
        import torch.nn.functional as F
        from PIL import Image
    except Exception as exc:  # pragma: no cover - optional runtime
        _write_blocker(output_dir, config, f"Missing torch/clip/PIL dependency: {exc}")
        return 2

    device = config.device
    if device == "cuda" and not torch.cuda.is_available():
        device = "cpu"
    _set_seed(config.seed, torch)

    data_root = Path(config.data_root)
    domains = [value.strip() for value in config.domains.split(",") if value.strip()]
    class_names = _select_classes(data_root, domains, config.num_classes)
    if not class_names:
        _write_blocker(output_dir, config, "No shared classes found for requested domains.")
        return 2

    clients = _build_clients(
        data_root=data_root,
        domains=domains,
        class_names=class_names,
        train_per_class=config.train_per_class,
        test_per_class=config.test_per_class,
        calibration_fraction=config.calibration_fraction,
        seed=config.seed,
    )
    if not clients or any(not client["train"] or not client["test"] for client in clients):
        _write_blocker(output_dir, config, "Could not collect non-empty train/test splits for every client.")
        return 2

    model, preprocess = clip.load(config.model_name, device=device)
    model.float()
    model.train()
    for param in model.parameters():
        param.requires_grad_(False)
    lora_modules = inject_visual_attention_lora(model, rank=config.rank, blocks=config.lora_blocks, torch=torch, nn=nn, F=F)
    for module in lora_modules:
        module.to(device)

    prompt_labels = _prompt_labels(class_names, config.class_labels)
    text_features = _text_features(model, clip, prompt_labels, config.prompt_template, device, torch)
    zero_state = zero_lora_state(lora_modules)

    d_geo, graph, geometry_provider = _load_geometry(config, clients)
    d_geo_norm = _normalize_distance(d_geo)
    graph_support = _support_from_graph(graph, d_geo_norm, k=config.graph_k)
    geo_weights = _graph_weights(graph_support, d_geo_norm, self_weight=config.graph_self_weight, tau=config.tau_geo)

    local_states: list[list[dict[str, np.ndarray]]] = []
    train_history: list[dict] = []
    for client in clients:
        state, history = _train_client(
            model=model,
            modules=lora_modules,
            preprocess=preprocess,
            text_features=text_features,
            samples=client["train"],
            class_names=class_names,
            device=device,
            batch_size=config.batch_size,
            epochs=config.local_epochs,
            lr=config.lr,
            seed=config.seed * 1009 + int(client["client_id"]),
            Image=Image,
            torch=torch,
            F=F,
        )
        local_states.append(state)
        for row in history:
            row.update(
                {
                    "client_id": client["client_id"],
                    "domain": client["domain"],
                    "method": "Local-CLIP-LoRA",
                    "seed": config.seed,
                    "dataset": config.dataset,
                    "round": config.round_id,
                }
            )
            train_history.append(row)

    d_sub = _subspace_distance_matrix(local_states)
    d_sub_norm = _normalize_distance(d_sub)
    fam_weights = _fam_weights(
        graph=graph_support,
        d_sub=d_sub_norm,
        d_geo=d_geo_norm,
        lambda_geo=config.lambda_geo,
        tau=config.tau_fam,
        self_weight=config.fam_self_weight,
    )

    uniform = np.full(len(clients), 1.0 / max(1, len(clients)), dtype=np.float64)
    fedavg_state = average_factor_state(local_states, uniform)
    fedavg_lift_state = average_lifted_state(local_states, uniform, rank=config.rank)
    fedgeo_states = [average_lifted_state(local_states, geo_weights[i], rank=config.rank) for i in range(len(clients))]
    fam_states = [average_lifted_state(local_states, fam_weights[i], rank=config.rank) for i in range(len(clients))]

    method_states: dict[str, list[list[dict[str, np.ndarray]]]] = {
        "CLIP-ZeroShot": [zero_state for _ in clients],
        "Local-CLIP-LoRA": local_states,
        "FedAvg-CLIP-LoRA": [fedavg_state for _ in clients],
        "FedAvg-Lift-CLIP-LoRA": [fedavg_lift_state for _ in clients],
        "FedGeo-Agg-CLIP-LoRA": fedgeo_states,
        "FedAdapterManifold-CLIP-LoRA": fam_states,
    }

    selective_states, selection_rows = _select_by_calibration(
        model=model,
        modules=lora_modules,
        preprocess=preprocess,
        text_features=text_features,
        clients=clients,
        method_states=method_states,
        class_names=class_names,
        device=device,
        batch_size=config.batch_size,
        Image=Image,
        torch=torch,
    )
    method_states["FedAdapterManifold-Selective-CLIP-LoRA"] = selective_states

    per_client_rows: list[dict] = []
    for method, states in method_states.items():
        for client_index, client in enumerate(clients):
            set_lora_state(lora_modules, states[client_index], device=device, torch=torch)
            metrics = _evaluate(
                model=model,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["test"],
                class_names=class_names,
                device=device,
                batch_size=config.batch_size,
                Image=Image,
                torch=torch,
            )
            per_client_rows.append(
                {
                    "method": method,
                    "seed": config.seed,
                    "dataset": config.dataset,
                    "heterogeneity": config.domains,
                    "round": config.round_id,
                    "client_id": client["client_id"],
                    "domain": client["domain"],
                    "accuracy": metrics["accuracy"],
                    "loss": metrics["loss"],
                    "num_samples": metrics["num_samples"],
                    "geometry_provider": geometry_provider,
                }
            )

    local_acc = {
        int(row["client_id"]): float(row["accuracy"])
        for row in per_client_rows
        if row["method"] == "Local-CLIP-LoRA"
    }
    for row in per_client_rows:
        cid = int(row["client_id"])
        row["accuracy_drop_vs_local"] = local_acc.get(cid, float("nan")) - float(row["accuracy"])
        row["update_conflict_vs_local"] = max(0.0, row["accuracy_drop_vs_local"])
        row["client_risk"] = 1.0 - float(row["accuracy"])

    metrics_rows = _aggregate_metrics(per_client_rows, config)
    subspace_rows = _subspace_failure_rows(
        model=model,
        modules=lora_modules,
        preprocess=preprocess,
        text_features=text_features,
        clients=clients,
        local_states=local_states,
        local_acc=local_acc,
        d_sub=d_sub,
        d_geo=d_geo,
        class_names=class_names,
        device=device,
        batch_size=config.batch_size,
        rank=config.rank,
        Image=Image,
        torch=torch,
    )
    conflict_rows = _conflict_rows(metrics_rows)
    bank_rows = _weight_rows(clients, "FedGeo-Agg-CLIP-LoRA", geo_weights) + _weight_rows(
        clients, "FedAdapterManifold-CLIP-LoRA", fam_weights
    )

    _write_csv(output_dir / "metrics.csv", metrics_rows)
    _write_csv(output_dir / "per_client_metrics.csv", per_client_rows)
    _write_csv(output_dir / "subspace_metrics.csv", subspace_rows)
    _write_csv(output_dir / "adapter_conflict.csv", conflict_rows)
    _write_csv(output_dir / "adapter_bank_weights.csv", bank_rows)
    _write_csv(output_dir / "candidate_selection.csv", selection_rows)
    _write_csv(output_dir / "training_history.csv", train_history)
    _write_config(output_dir / "config.yaml", config, class_names, geometry_provider, clients, prompt_labels)
    _write_report(output_dir / "run_report.md", metrics_rows, subspace_rows)
    set_lora_state(lora_modules, zero_state, device=device, torch=torch)
    return 0


def inject_visual_attention_lora(model, rank: int, blocks: int, torch, nn, F):
    resblocks = model.visual.transformer.resblocks
    modules = []
    for idx in range(len(resblocks) - max(1, blocks), len(resblocks)):
        base_attn = resblocks[idx].attn
        wrapped = LoRAMultiheadAttention(base_attn, rank=rank, torch=torch, nn=nn, F=F)
        resblocks[idx].attn = wrapped
        modules.append(wrapped)
    return modules


class LoRAMultiheadAttention:
    def __new__(cls, base_attn, rank: int, torch, nn, F):
        class _Wrapped(nn.Module):
            def __init__(self):
                super().__init__()
                self.base = base_attn
                self.rank = int(rank)
                self.scale = 1.0 / max(1, self.rank)
                embed_dim = int(base_attn.embed_dim)
                self.embed_dim = embed_dim
                self.lora_a = nn.Parameter(torch.empty(self.rank, embed_dim))
                self.lora_b = nn.Parameter(torch.zeros(3 * embed_dim, self.rank))
                nn.init.kaiming_uniform_(self.lora_a, a=5**0.5)
                for param in self.base.parameters():
                    param.requires_grad_(False)

            def forward(self, query, key, value, key_padding_mask=None, need_weights=True, attn_mask=None):
                delta = (self.lora_b @ self.lora_a) * self.scale
                in_proj_weight = self.base.in_proj_weight + delta.to(dtype=self.base.in_proj_weight.dtype)
                return F.multi_head_attention_forward(
                    query,
                    key,
                    value,
                    self.base.embed_dim,
                    self.base.num_heads,
                    in_proj_weight,
                    self.base.in_proj_bias,
                    self.base.bias_k,
                    self.base.bias_v,
                    self.base.add_zero_attn,
                    self.base.dropout,
                    self.base.out_proj.weight,
                    self.base.out_proj.bias,
                    self.training,
                    key_padding_mask,
                    need_weights,
                    attn_mask,
                    use_separate_proj_weight=False,
                    average_attn_weights=True,
                )

        return _Wrapped()


def _select_classes(data_root: Path, domains: list[str], limit: int) -> list[str]:
    shared: set[str] | None = None
    for domain in domains:
        class_dir = data_root / domain / "train"
        names = {path.name for path in class_dir.iterdir() if path.is_dir()} if class_dir.exists() else set()
        shared = names if shared is None else shared & names
    return sorted(shared or [])[: max(1, int(limit))]


def _build_clients(
    data_root: Path,
    domains: list[str],
    class_names: list[str],
    train_per_class: int,
    test_per_class: int,
    calibration_fraction: float,
    seed: int,
) -> list[dict]:
    clients = []
    for client_id, domain in enumerate(domains):
        train_all = _collect_domain_samples(data_root, domain, class_names, "train", train_per_class, seed + client_id * 13)
        test = _collect_domain_samples(data_root, domain, class_names, "test", test_per_class, seed + 1000 + client_id * 13)
        train, calibration = _split_train_calibration(train_all, calibration_fraction, seed + 2000 + client_id)
        if not calibration:
            calibration = train[:]
        clients.append(
            {
                "client_id": client_id,
                "domain": domain,
                "train": train,
                "calibration": calibration,
                "test": test,
                "num_train": len(train),
                "num_calibration": len(calibration),
                "num_test": len(test),
            }
        )
    return clients


def _collect_domain_samples(
    data_root: Path,
    domain: str,
    class_names: list[str],
    split: str,
    per_class: int,
    seed: int,
) -> list[dict[str, str]]:
    rng = random.Random(seed)
    samples: list[dict[str, str]] = []
    for label in class_names:
        folder = data_root / domain / split / label
        files = sorted(path for path in folder.glob("*") if path.suffix.lower() in IMAGE_SUFFIXES)
        rng.shuffle(files)
        for path in files[: max(1, per_class)]:
            samples.append({"path": str(path), "label": label, "domain": domain})
    rng.shuffle(samples)
    return samples


def _split_train_calibration(samples: list[dict[str, str]], fraction: float, seed: int) -> tuple[list[dict], list[dict]]:
    if not samples:
        return [], []
    by_label: dict[str, list[dict]] = {}
    for sample in samples:
        by_label.setdefault(sample["label"], []).append(sample)
    rng = random.Random(seed)
    train: list[dict] = []
    calibration: list[dict] = []
    for label_samples in by_label.values():
        items = label_samples[:]
        rng.shuffle(items)
        cal_count = int(round(len(items) * max(0.0, min(0.9, fraction))))
        if len(items) > 1:
            cal_count = max(1, min(len(items) - 1, cal_count))
        calibration.extend(items[:cal_count])
        train.extend(items[cal_count:])
    rng.shuffle(train)
    rng.shuffle(calibration)
    return train, calibration


def _text_features(model, clip, class_names: list[str], template: str, device: str, torch):
    prompts = [template.format(label=name.replace("_", " ")) for name in class_names]
    with torch.no_grad():
        tokens = clip.tokenize(prompts, truncate=True).to(device)
        features = model.encode_text(tokens).float()
        return features / features.norm(dim=-1, keepdim=True).clamp_min(1e-12)


def _prompt_labels(class_names: list[str], class_labels: str) -> list[str]:
    labels = [value.strip() for value in class_labels.split(",") if value.strip()]
    if not labels:
        return class_names
    if len(labels) != len(class_names):
        raise ValueError(f"--class-labels has {len(labels)} entries but {len(class_names)} classes were selected.")
    return labels


def _train_client(
    model,
    modules,
    preprocess,
    text_features,
    samples,
    class_names,
    device,
    batch_size,
    epochs,
    lr,
    seed,
    Image,
    torch,
    F,
) -> tuple[list[dict[str, np.ndarray]], list[dict]]:
    reset_lora_parameters(modules, seed=seed, torch=torch)
    trainable = [param for module in modules for param in module.parameters() if param.requires_grad]
    optimizer = torch.optim.AdamW(trainable, lr=lr)
    model.train()
    history: list[dict] = []
    rng = random.Random(seed)
    for epoch in range(max(1, epochs)):
        shuffled = samples[:]
        rng.shuffle(shuffled)
        losses: list[float] = []
        for batch in _batches(shuffled, batch_size):
            images, labels = _load_batch(batch, preprocess, class_names, device, Image, torch)
            optimizer.zero_grad(set_to_none=True)
            image_features = model.encode_image(images)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True).clamp_min(1e-12)
            logits = model.logit_scale.exp().float() * image_features.float() @ text_features.float().t()
            loss = F.cross_entropy(logits, labels)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, 1.0)
            optimizer.step()
            losses.append(float(loss.detach().cpu()))
        history.append({"epoch": epoch, "mean_train_loss": sum(losses) / max(1, len(losses))})
    model.eval()
    return get_lora_state(modules), history


def _evaluate(model, preprocess, text_features, samples, class_names, device, batch_size, Image, torch) -> dict[str, float]:
    import torch.nn.functional as F

    model.eval()
    correct = 0
    total = 0
    losses: list[float] = []
    with torch.no_grad():
        for batch in _batches(samples, batch_size):
            images, labels = _load_batch(batch, preprocess, class_names, device, Image, torch)
            image_features = model.encode_image(images)
            image_features = image_features / image_features.norm(dim=-1, keepdim=True).clamp_min(1e-12)
            logits = model.logit_scale.exp().float() * image_features.float() @ text_features.float().t()
            losses.append(float(F.cross_entropy(logits, labels).detach().cpu()))
            correct += int((logits.argmax(dim=1) == labels).sum().detach().cpu())
            total += int(labels.numel())
    return {"accuracy": correct / max(1, total), "loss": sum(losses) / max(1, len(losses)), "num_samples": total}


def _load_batch(batch, preprocess, class_names, device, Image, torch):
    tensors = []
    labels = []
    for sample in batch:
        with Image.open(sample["path"]) as image:
            tensors.append(preprocess(image.convert("RGB")))
        labels.append(class_names.index(sample["label"]))
    return torch.stack(tensors, dim=0).to(device), torch.tensor(labels, dtype=torch.long, device=device)


def _batches(items, batch_size: int):
    for start in range(0, len(items), max(1, batch_size)):
        yield items[start : start + max(1, batch_size)]


def reset_lora_parameters(modules, seed: int, torch) -> None:
    generator = torch.Generator(device=modules[0].lora_a.device if modules else "cpu")
    generator.manual_seed(int(seed))
    for module in modules:
        with torch.no_grad():
            module.lora_a.normal_(0.0, 1.0 / math.sqrt(max(1, module.embed_dim)), generator=generator)
            module.lora_b.zero_()


def get_lora_state(modules) -> list[dict[str, np.ndarray]]:
    out = []
    for module in modules:
        out.append(
            {
                "a": module.lora_a.detach().float().cpu().numpy().copy(),
                "b": module.lora_b.detach().float().cpu().numpy().copy(),
                "scale": np.array(float(module.scale), dtype=np.float64),
            }
        )
    return out


def zero_lora_state(modules) -> list[dict[str, np.ndarray]]:
    return [
        {
            "a": np.zeros_like(module.lora_a.detach().float().cpu().numpy()),
            "b": np.zeros_like(module.lora_b.detach().float().cpu().numpy()),
            "scale": np.array(float(module.scale), dtype=np.float64),
        }
        for module in modules
    ]


def set_lora_state(modules, state: list[dict[str, np.ndarray]], device: str, torch) -> None:
    for module, item in zip(modules, state):
        with torch.no_grad():
            module.lora_a.copy_(torch.as_tensor(item["a"], dtype=module.lora_a.dtype, device=device))
            module.lora_b.copy_(torch.as_tensor(item["b"], dtype=module.lora_b.dtype, device=device))


def average_factor_state(states: list[list[dict[str, np.ndarray]]], weights: np.ndarray) -> list[dict[str, np.ndarray]]:
    weights = _normalize_weights(weights)
    out = []
    for module_idx in range(len(states[0])):
        a = sum(float(weights[i]) * states[i][module_idx]["a"] for i in range(len(states)))
        b = sum(float(weights[i]) * states[i][module_idx]["b"] for i in range(len(states)))
        out.append({"a": a, "b": b, "scale": states[0][module_idx]["scale"]})
    return out


def average_lifted_state(states: list[list[dict[str, np.ndarray]]], weights: np.ndarray, rank: int) -> list[dict[str, np.ndarray]]:
    weights = _normalize_weights(weights)
    out = []
    for module_idx in range(len(states[0])):
        delta = None
        scale = float(states[0][module_idx]["scale"])
        for client_idx, state in enumerate(states):
            item = state[module_idx]
            local_delta = float(item["scale"]) * (item["b"] @ item["a"])
            delta = float(weights[client_idx]) * local_delta if delta is None else delta + float(weights[client_idx]) * local_delta
        out.append(_project_delta_to_lora(delta, rank=rank, scale=scale))
    return out


def _project_delta_to_lora(delta: np.ndarray, rank: int, scale: float) -> dict[str, np.ndarray]:
    rows, cols = delta.shape
    rank = int(max(1, min(rank, rows, cols)))
    delta = np.nan_to_num(delta.astype(np.float64), nan=0.0, posinf=1e4, neginf=-1e4)
    try:
        u, s, vt = np.linalg.svd(delta, full_matrices=False)
    except np.linalg.LinAlgError:
        u, s, vt = _fallback_svd(delta)
    u = u[:, :rank]
    s = s[:rank]
    vt = vt[:rank, :]
    b = u * (s / max(scale, 1e-12))[np.newaxis, :]
    return {"a": vt.astype(np.float32), "b": b.astype(np.float32), "scale": np.array(scale, dtype=np.float64)}


def _fallback_svd(delta: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    gram = np.nan_to_num(delta @ delta.T)
    eigvals, u = np.linalg.eigh(gram)
    order = np.argsort(np.maximum(eigvals, 0.0))[::-1]
    eigvals = np.maximum(eigvals[order], 0.0)
    u = u[:, order]
    s = np.sqrt(eigvals)
    vt = np.zeros((u.shape[1], delta.shape[1]), dtype=np.float64)
    nonzero = s > 1e-12
    vt[nonzero] = (u[:, nonzero].T @ delta) / s[nonzero, None]
    return u, s, vt


def _subspace_distance_matrix(states: list[list[dict[str, np.ndarray]]]) -> np.ndarray:
    n = len(states)
    out = np.zeros((n, n), dtype=np.float64)
    for i in range(n):
        for j in range(i + 1, n):
            total = 0.0
            for module_idx in range(len(states[i])):
                total += _grassmann(states[i][module_idx]["b"], states[j][module_idx]["b"])
                total += _grassmann(states[i][module_idx]["a"].T, states[j][module_idx]["a"].T)
            out[i, j] = out[j, i] = total
    return out


def _grassmann(x: np.ndarray, y: np.ndarray) -> float:
    qx = _orth(x)
    qy = _orth(y)
    if qx.size == 0 or qy.size == 0:
        return 0.0
    s = np.linalg.svd(qx.T @ qy, compute_uv=False)
    s = np.clip(s, -1.0, 1.0)
    return float(np.linalg.norm(np.arccos(s)))


def _orth(x: np.ndarray) -> np.ndarray:
    x = np.nan_to_num(np.asarray(x, dtype=np.float64))
    if x.ndim != 2 or min(x.shape) == 0 or np.linalg.norm(x) < 1e-12:
        return np.zeros((x.shape[0], 0), dtype=np.float64)
    q, r = np.linalg.qr(x)
    keep = np.abs(np.diag(r)) > 1e-10 if r.ndim == 2 else np.ones(q.shape[1], dtype=bool)
    return q[:, keep]


def _load_geometry(config: Config, clients: list[dict]) -> tuple[np.ndarray, np.ndarray, str]:
    n = len(clients)
    if config.geometry_outputs_dir:
        root = Path(config.geometry_outputs_dir)
        d_path = root / f"d_geo_round_{config.round_id}.npy"
        g_path = root / f"geometry_graph_round_{config.round_id}.npy"
        if d_path.exists():
            d_geo = np.asarray(np.load(d_path), dtype=np.float64)
            if d_geo.shape == (n, n):
                graph = np.asarray(np.load(g_path), dtype=np.float64) if g_path.exists() else _knn_graph(d_geo, config.graph_k)
                if graph.shape != (n, n):
                    graph = _knn_graph(d_geo, config.graph_k)
                return d_geo, graph, "FedGeo"
    d_geo = _domain_name_distance([client["domain"] for client in clients])
    return d_geo, _knn_graph(d_geo, config.graph_k), "domain_name_fallback"


def _domain_name_distance(domains: list[str]) -> np.ndarray:
    n = len(domains)
    out = np.ones((n, n), dtype=np.float64)
    np.fill_diagonal(out, 0.0)
    return out


def _knn_graph(d_geo: np.ndarray, k: int) -> np.ndarray:
    n = d_geo.shape[0]
    graph = np.zeros((n, n), dtype=np.float64)
    for i in range(n):
        order = np.argsort(d_geo[i])
        for j in order[1 : min(n, max(1, k) + 1)]:
            graph[i, j] = 1.0
            graph[j, i] = 1.0
    return graph


def _normalize_distance(matrix: np.ndarray) -> np.ndarray:
    matrix = np.asarray(matrix, dtype=np.float64)
    finite = matrix[np.isfinite(matrix)]
    if finite.size == 0:
        return np.zeros_like(matrix)
    off_diag = matrix[~np.eye(matrix.shape[0], dtype=bool)]
    scale = np.nanmax(off_diag) if off_diag.size else np.nanmax(finite)
    if not np.isfinite(scale) or scale <= 1e-12:
        return np.zeros_like(matrix)
    return np.nan_to_num(matrix / scale)


def _support_from_graph(graph: np.ndarray, d_geo: np.ndarray, k: int) -> np.ndarray:
    """Convert FedGeo graph output to an adjacency support.

    Some FedGeo providers store a weighted affinity graph whose off-diagonal
    values can be extremely small after kernel scaling. Treating those values as
    aggregation weights collapses graph sharing back to self-only. For adapter
    sharing we need the manifold support, so dense or underflowed weighted
    graphs are converted to a k-nearest-neighbor support using d_geo.
    """

    graph = np.nan_to_num(np.asarray(graph, dtype=np.float64))
    n = graph.shape[0]
    off_diag = graph[~np.eye(n, dtype=bool)]
    positive = off_diag[off_diag > 0.0]
    density = positive.size / max(1, off_diag.size)
    max_positive = float(np.max(positive)) if positive.size else 0.0
    if positive.size == 0 or density > 0.75 or max_positive < 1e-6:
        return _knn_graph(d_geo, k)
    support = (graph > 0.0).astype(np.float64)
    np.fill_diagonal(support, 0.0)
    support = np.maximum(support, support.T)
    return support


def _graph_weights(graph: np.ndarray, d_geo: np.ndarray, self_weight: float, tau: float) -> np.ndarray:
    n = graph.shape[0]
    weights = np.zeros((n, n), dtype=np.float64)
    affinity = np.exp(-np.nan_to_num(d_geo) / max(tau, 1e-6))
    for i in range(n):
        row = np.asarray(graph[i], dtype=np.float64) * affinity[i]
        row[i] = max(row[i], self_weight)
        if row.sum() <= 1e-12:
            row[i] = 1.0
        weights[i] = row / row.sum()
    return weights


def _fam_weights(
    graph: np.ndarray,
    d_sub: np.ndarray,
    d_geo: np.ndarray,
    lambda_geo: float,
    tau: float,
    self_weight: float,
) -> np.ndarray:
    n = graph.shape[0]
    combined = np.nan_to_num(d_sub) + float(lambda_geo) * np.nan_to_num(d_geo)
    affinity = np.exp(-combined / max(tau, 1e-6))
    weights = np.zeros((n, n), dtype=np.float64)
    support = (np.asarray(graph) > 0).astype(np.float64)
    for i in range(n):
        row = support[i] * affinity[i]
        row[i] = max(row[i], self_weight)
        if row.sum() <= 1e-12:
            row[i] = 1.0
        weights[i] = row / row.sum()
    return weights


def _normalize_weights(weights: np.ndarray) -> np.ndarray:
    weights = np.maximum(0.0, np.nan_to_num(np.asarray(weights, dtype=np.float64)))
    total = weights.sum()
    if total <= 1e-12:
        return np.full_like(weights, 1.0 / max(1, len(weights)))
    return weights / total


def _select_by_calibration(
    model,
    modules,
    preprocess,
    text_features,
    clients,
    method_states,
    class_names,
    device,
    batch_size,
    Image,
    torch,
) -> tuple[list[list[dict[str, np.ndarray]]], list[dict]]:
    selected_states = []
    rows: list[dict] = []
    candidates = [
        "Local-CLIP-LoRA",
        "FedAvg-CLIP-LoRA",
        "FedAvg-Lift-CLIP-LoRA",
        "FedGeo-Agg-CLIP-LoRA",
        "FedAdapterManifold-CLIP-LoRA",
    ]
    for client_idx, client in enumerate(clients):
        best_method = ""
        best_loss = float("inf")
        for method in candidates:
            set_lora_state(modules, method_states[method][client_idx], device=device, torch=torch)
            metrics = _evaluate(
                model=model,
                preprocess=preprocess,
                text_features=text_features,
                samples=client["calibration"],
                class_names=class_names,
                device=device,
                batch_size=batch_size,
                Image=Image,
                torch=torch,
            )
            rows.append(
                {
                    "client_id": client["client_id"],
                    "domain": client["domain"],
                    "candidate_method": method,
                    "calibration_loss": metrics["loss"],
                    "calibration_accuracy": metrics["accuracy"],
                    "num_calibration": metrics["num_samples"],
                }
            )
            if metrics["loss"] < best_loss:
                best_loss = metrics["loss"]
                best_method = method
        for row in rows:
            if row["client_id"] == client["client_id"] and row["candidate_method"] == best_method:
                row["selected"] = True
            elif row["client_id"] == client["client_id"]:
                row.setdefault("selected", False)
        selected_states.append(method_states[best_method][client_idx])
    return selected_states, rows


def _aggregate_metrics(per_client_rows: list[dict], config: Config) -> list[dict]:
    methods = sorted({row["method"] for row in per_client_rows})
    out = []
    for method in methods:
        rows = [row for row in per_client_rows if row["method"] == method]
        accuracies = [float(row["accuracy"]) for row in rows]
        losses = [float(row["loss"]) for row in rows]
        conflicts = [float(row["update_conflict_vs_local"]) for row in rows]
        risks = [float(row["client_risk"]) for row in rows]
        out.append(
            {
                "method": method,
                "seed": config.seed,
                "dataset": config.dataset,
                "heterogeneity": config.domains,
                "round": config.round_id,
                "mean_accuracy": _mean(accuracies),
                "std_accuracy": _std(accuracies),
                "mean_loss": _mean(losses),
                "worst_client_risk": max(risks) if risks else float("nan"),
                "mean_update_conflict_vs_local": _mean(conflicts),
                "num_clients": len(rows),
                "num_test_samples": sum(int(row["num_samples"]) for row in rows),
            }
        )
    return out


def _subspace_failure_rows(
    model,
    modules,
    preprocess,
    text_features,
    clients,
    local_states,
    local_acc,
    d_sub,
    d_geo,
    class_names,
    device,
    batch_size,
    rank,
    Image,
    torch,
) -> list[dict]:
    rows: list[dict] = []
    for receiver_idx, receiver in enumerate(clients):
        for donor_idx, donor in enumerate(clients):
            if receiver_idx == donor_idx:
                continue
            pair_state = average_lifted_state(
                [local_states[receiver_idx], local_states[donor_idx]],
                np.array([0.5, 0.5], dtype=np.float64),
                rank=rank,
            )
            set_lora_state(modules, pair_state, device=device, torch=torch)
            metrics = _evaluate(
                model=model,
                preprocess=preprocess,
                text_features=text_features,
                samples=receiver["test"],
                class_names=class_names,
                device=device,
                batch_size=batch_size,
                Image=Image,
                torch=torch,
            )
            failure = local_acc[int(receiver["client_id"])] - metrics["accuracy"]
            rows.append(
                {
                    "receiver_client_id": receiver["client_id"],
                    "receiver_domain": receiver["domain"],
                    "donor_client_id": donor["client_id"],
                    "donor_domain": donor["domain"],
                    "d_sub": float(d_sub[receiver_idx, donor_idx]),
                    "d_geo": float(d_geo[receiver_idx, donor_idx]),
                    "pair_accuracy": metrics["accuracy"],
                    "local_accuracy": local_acc[int(receiver["client_id"])],
                    "aggregation_failure": failure,
                    "positive_failure": max(0.0, failure),
                }
            )
    r_sub = _pearson([row["d_sub"] for row in rows], [row["aggregation_failure"] for row in rows])
    r_geo = _pearson([row["d_geo"] for row in rows], [row["aggregation_failure"] for row in rows])
    for row in rows:
        row["subspace_failure_pearson_r"] = r_sub
        row["geometry_failure_pearson_r"] = r_geo
    return rows


def _conflict_rows(metrics_rows: list[dict]) -> list[dict]:
    out = []
    local = _find(metrics_rows, "Local-CLIP-LoRA")
    fedavg = _find(metrics_rows, "FedAvg-CLIP-LoRA")
    for row in metrics_rows:
        out.append(
            {
                "method": row["method"],
                "seed": row["seed"],
                "dataset": row["dataset"],
                "round": row["round"],
                "mean_update_conflict_vs_local": row["mean_update_conflict_vs_local"],
                "worst_client_risk": row["worst_client_risk"],
                "mean_accuracy": row["mean_accuracy"],
                "accuracy_gain_vs_fedavg": float(row["mean_accuracy"]) - float(fedavg.get("mean_accuracy", float("nan"))),
                "accuracy_gain_vs_local": float(row["mean_accuracy"]) - float(local.get("mean_accuracy", float("nan"))),
            }
        )
    return out


def _weight_rows(clients: list[dict], method: str, weights: np.ndarray) -> list[dict]:
    rows = []
    for i, receiver in enumerate(clients):
        for j, donor in enumerate(clients):
            rows.append(
                {
                    "method": method,
                    "receiver_client_id": receiver["client_id"],
                    "receiver_domain": receiver["domain"],
                    "donor_client_id": donor["client_id"],
                    "donor_domain": donor["domain"],
                    "weight": float(weights[i, j]),
                }
            )
    return rows


def _find(rows: list[dict], method: str) -> dict:
    for row in rows:
        if row.get("method") == method:
            return row
    return {}


def _mean(values: Iterable[float]) -> float:
    vals = [float(v) for v in values if math.isfinite(float(v))]
    return sum(vals) / len(vals) if vals else float("nan")


def _std(values: Iterable[float]) -> float:
    vals = [float(v) for v in values if math.isfinite(float(v))]
    if len(vals) <= 1:
        return 0.0 if vals else float("nan")
    mu = _mean(vals)
    return math.sqrt(sum((v - mu) ** 2 for v in vals) / (len(vals) - 1))


def _pearson(xs: Iterable[float], ys: Iterable[float]) -> float:
    x = np.asarray(list(xs), dtype=np.float64)
    y = np.asarray(list(ys), dtype=np.float64)
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    if x.size < 3 or np.std(x) <= 1e-12 or np.std(y) <= 1e-12:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def _set_seed(seed: int, torch) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    if not fieldnames:
        fieldnames = ["empty"]
        rows = [{"empty": ""}]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _write_config(
    path: Path,
    config: Config,
    class_names: list[str],
    geometry_provider: str,
    clients: list[dict],
    prompt_labels: list[str],
) -> None:
    payload = asdict(config)
    payload["class_names"] = class_names
    payload["prompt_labels"] = prompt_labels
    payload["geometry_provider"] = geometry_provider
    payload["clients"] = [
        {
            "client_id": client["client_id"],
            "domain": client["domain"],
            "num_train": client["num_train"],
            "num_calibration": client["num_calibration"],
            "num_test": client["num_test"],
        }
        for client in clients
    ]
    lines = []
    for key, value in payload.items():
        if isinstance(value, (list, dict)):
            lines.append(f"{key}: {json.dumps(value)}")
        else:
            lines.append(f"{key}: {value}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _write_report(path: Path, metrics_rows: list[dict], subspace_rows: list[dict]) -> None:
    r_sub = subspace_rows[0].get("subspace_failure_pearson_r", "") if subspace_rows else ""
    lines = [
        "# Federated End-to-End CLIP ViT LoRA",
        "",
        "| Method | Mean accuracy | Worst-client risk | Conflict vs local |",
        "|---|---:|---:|---:|",
    ]
    for row in sorted(metrics_rows, key=lambda item: item["method"]):
        lines.append(
            f"| {row['method']} | {float(row['mean_accuracy']):.4f} | {float(row['worst_client_risk']):.4f} | {float(row['mean_update_conflict_vs_local']):.4f} |"
        )
    lines.extend(["", f"Subspace/failure Pearson r: {r_sub}", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def _write_blocker(output_dir: Path, config: Config, reason: str) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "blocker.json").write_text(json.dumps({"reason": reason, "config": asdict(config)}, indent=2), encoding="utf-8")
    _write_csv(output_dir / "metrics.csv", [{"method": "EndToEnd-Federated-CLIPViT-LoRA", "status": "blocked", "reason": reason}])


if __name__ == "__main__":
    raise SystemExit(main())
