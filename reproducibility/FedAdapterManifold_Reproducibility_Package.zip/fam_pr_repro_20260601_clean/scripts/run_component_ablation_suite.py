from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv
from scripts.run_fedgeo_multiseed import main as run_multiseed


ABLATIONS = [
    {
        "name": "full",
        "description": "Default FedAdapterManifold with geometry graph, prototype routing, shared/domain/personal mixing.",
        "args": [],
    },
    {
        "name": "client-routing",
        "description": "Removes input prototype-conditioned routing; routes by client geometry prior only.",
        "args": ["--adapter-bank-routing", "client"],
    },
    {
        "name": "pure-feature-routing",
        "description": "Uses class-conditional prototype routing without client prior blending.",
        "args": ["--adapter-bank-routing", "feature", "--adapter-bank-prior-weight", "0.0"],
    },
    {
        "name": "single-bank",
        "description": "Forces K=1 to test whether one domain adapter is insufficient.",
        "args": ["--adapter-bank-k", "1"],
    },
    {
        "name": "complete-adapter-graph",
        "description": "Replaces the FedGeo client manifold graph with a complete graph for adapter sharing.",
        "args": ["--adapter-graph-mode", "complete"],
    },
    {
        "name": "self-adapter-graph",
        "description": "Removes cross-client graph sharing before the adapter bank.",
        "args": ["--adapter-graph-mode", "self"],
    },
    {
        "name": "no-personal",
        "description": "Removes personal adapter residuals from the adapter bank mixture.",
        "args": ["--personal-weight-policy", "fixed", "--personal-weight", "0.0"],
    },
    {
        "name": "fixed-personal",
        "description": "Uses a fixed low personal gate to isolate the adaptive heterogeneity-aware gate.",
        "args": ["--personal-weight-policy", "fixed", "--personal-weight", "0.15"],
    },
    {
        "name": "no-shared",
        "description": "Removes the shared adapter component from the bank mixture.",
        "args": ["--shared-weight", "0.0"],
    },
    {
        "name": "adaptive-shared",
        "description": "Selects the shared adapter gate from local train loss under a small tolerance.",
        "args": [
            "--shared-weight-policy",
            "loss-constrained",
            "--shared-weight-candidates",
            "0,0.05,0.10,0.20,0.35",
            "--shared-weight-tolerance",
            "0.005",
        ],
    },
    {
        "name": "no-geo-term",
        "description": "Removes d_geo from compatibility distance while still allowing subspace/label signals.",
        "args": ["--lambda-geo", "0.0"],
    },
]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run FedAdapterManifold component ablations.")
    parser.add_argument("--config", type=str, default="configs/pacs_debug.yaml")
    parser.add_argument("--output-root", type=str, default="results/fedadaptermanifold_component_ablation")
    parser.add_argument("--seeds", type=str, default="0,1,2,3,4,5")
    parser.add_argument("--round-id", type=int, default=0)
    parser.add_argument("--data-root", type=str, default="")
    parser.add_argument("--geometry-outputs-dir", type=str, default="")
    parser.add_argument("--geometry-outputs-template", type=str, default="")
    parser.add_argument("--geometry-outputs-map", type=str, default="")
    parser.add_argument("--domains", type=str, default="")
    parser.add_argument("--adapter-graph-mode", type=str, default="")
    parser.add_argument("--adapter-graph-self-weight", type=str, default="")
    parser.add_argument("--adapter-graph-mix-weight", type=str, default="")
    parser.add_argument("--adapter-graph-mix-policy", type=str, default="")
    parser.add_argument("--adapter-graph-mix-tolerance", type=str, default="")
    parser.add_argument("--adapter-graph-mix-candidates", type=str, default="")
    parser.add_argument("--adapter-graph-distance", type=str, default="")
    parser.add_argument("--adapter-graph-compatibility", type=str, default="")
    parser.add_argument("--candidate-selector-policy", type=str, default="")
    parser.add_argument("--candidate-selector-scope", type=str, default="")
    parser.add_argument("--candidate-selector-loss-tolerance", type=str, default="")
    parser.add_argument("--candidate-selector-loss-tolerance-ratio", type=str, default="")
    parser.add_argument("--candidate-selector-neighbor-weight", type=str, default="")
    parser.add_argument("--rank", type=str, default="")
    parser.add_argument("--rank-policy", type=str, default="")
    parser.add_argument("--min-rank", type=str, default="")
    parser.add_argument("--max-rank", type=str, default="")
    parser.add_argument("--rounds", type=str, default="")
    parser.add_argument("--local-epochs", type=str, default="")
    parser.add_argument("--train-per-client", type=str, default="")
    parser.add_argument("--test-per-client", type=str, default="")
    parser.add_argument("--feature-backbone", type=str, default="")
    parser.add_argument("--feature-cache-dir", type=str, default="")
    parser.add_argument(
        "--ablations",
        type=str,
        default="",
        help="Optional comma-separated ablation names to run. Defaults to all ablations.",
    )
    parser.add_argument("--continue-on-failed-diagnostic", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    root = ensure_dir(args.output_root)
    run_rows = []
    summary_rows = []
    claim_rows_all = []

    selected_ablations = _select_ablations(args.ablations)
    for ablation in selected_ablations:
        output_dir = root / ablation["name"]
        multiseed_args = [
            "--config",
            args.config,
            "--output-root",
            str(output_dir),
            "--seeds",
            args.seeds,
            "--round-id",
            str(args.round_id),
            "--strict-support-exit",
            *ablation["args"],
        ]
        if args.geometry_outputs_dir:
            multiseed_args.extend(["--geometry-outputs-dir", args.geometry_outputs_dir])
        if args.geometry_outputs_template:
            multiseed_args.extend(["--geometry-outputs-template", args.geometry_outputs_template])
        if args.geometry_outputs_map:
            multiseed_args.extend(["--geometry-outputs-map", args.geometry_outputs_map])
        for cli_name, value in [
            ("--data-root", args.data_root),
            ("--domains", args.domains),
            ("--adapter-graph-mode", args.adapter_graph_mode),
            ("--adapter-graph-self-weight", args.adapter_graph_self_weight),
            ("--adapter-graph-mix-weight", args.adapter_graph_mix_weight),
            ("--adapter-graph-mix-policy", args.adapter_graph_mix_policy),
            ("--adapter-graph-mix-tolerance", args.adapter_graph_mix_tolerance),
            ("--adapter-graph-mix-candidates", args.adapter_graph_mix_candidates),
                ("--adapter-graph-distance", args.adapter_graph_distance),
                ("--adapter-graph-compatibility", args.adapter_graph_compatibility),
                ("--candidate-selector-policy", args.candidate_selector_policy),
                ("--candidate-selector-scope", args.candidate_selector_scope),
                ("--candidate-selector-loss-tolerance", args.candidate_selector_loss_tolerance),
                ("--candidate-selector-loss-tolerance-ratio", args.candidate_selector_loss_tolerance_ratio),
                ("--candidate-selector-neighbor-weight", args.candidate_selector_neighbor_weight),
                ("--rank", args.rank),
            ("--rank-policy", args.rank_policy),
            ("--min-rank", args.min_rank),
            ("--max-rank", args.max_rank),
            ("--rounds", args.rounds),
            ("--local-epochs", args.local_epochs),
            ("--train-per-client", args.train_per_client),
            ("--test-per-client", args.test_per_client),
            ("--feature-backbone", args.feature_backbone),
            ("--feature-cache-dir", args.feature_cache_dir),
        ]:
            if value != "":
                multiseed_args.extend([cli_name, value])
        if args.continue_on_failed_diagnostic:
            multiseed_args.append("--continue-on-failed-diagnostic")

        code = run_multiseed(multiseed_args)
        run_rows.append(
            {
                "ablation": ablation["name"],
                "description": ablation["description"],
                "exit_code": code,
                "output_dir": str(output_dir),
            }
        )
        claim_rows = _read_csv(output_dir / "multiseed_claim_report.csv")
        for row in claim_rows:
            row["ablation"] = ablation["name"]
            row["description"] = ablation["description"]
        claim_rows_all.extend(claim_rows)
        method_rows = _read_csv(output_dir / "multiseed_summary.csv")
        summary_rows.append(_summarize_ablation(ablation, output_dir, code, claim_rows, method_rows))

    write_csv(root / "component_ablation_runs.csv", run_rows)
    write_csv(root / "component_ablation_claims.csv", claim_rows_all)
    write_csv(root / "component_ablation_summary.csv", summary_rows)

    full = next((row for row in summary_rows if row["ablation"] == "full"), None)
    return 0 if full and str(full.get("overall_core_support")).lower() == "true" else 2


def _summarize_ablation(
    ablation: dict,
    output_dir: Path,
    code: int,
    claim_rows: list[dict],
    method_rows: list[dict],
) -> dict:
    by_claim = {row.get("claim_id", ""): row for row in claim_rows}
    overall = by_claim.get("overall_core_support", {})
    by_metric = {
        (row.get("test", ""), row.get("method", ""), row.get("baseline", ""), row.get("measure", "")): row
        for row in method_rows
    }
    fedadapter_acc = _summary_estimate(by_metric, "method_accuracy", "FedAdapterManifold", "", "mean_accuracy")
    fedgeo_agg_acc = _summary_estimate(by_metric, "method_accuracy", "FedGeo-Agg", "", "mean_accuracy")
    fedavg_acc = _summary_estimate(by_metric, "method_accuracy", "FedAvg-LoRA", "", "mean_accuracy")
    return {
        "ablation": ablation["name"],
        "description": ablation["description"],
        "exit_code": code,
        "overall_core_support": overall.get("supports", ""),
        "secondary_caveats": overall.get("secondary_caveats", ""),
        "adapter_incompatibility_r": _estimate(by_claim, "adapter_incompatibility_failure_correlation"),
        "adapter_incompatibility_supports": _supports(by_claim, "adapter_incompatibility_failure_correlation"),
        "raw_subspace_r": _estimate(by_claim, "raw_subspace_failure_correlation"),
        "raw_subspace_supports": _supports(by_claim, "raw_subspace_failure_correlation"),
        "geo_r": _estimate(by_claim, "geometry_failure_correlation"),
        "geo_supports": _supports(by_claim, "geometry_failure_correlation"),
        "fedavg_accuracy": fedavg_acc,
        "fedgeo_agg_accuracy": fedgeo_agg_acc,
        "fedadapter_accuracy": fedadapter_acc,
        "gain_vs_fedavg": _estimate(by_claim, "adapter_bank_gain_vs_fedavg"),
        "gain_vs_fedavg_supports": _supports(by_claim, "adapter_bank_gain_vs_fedavg"),
        "gain_vs_fedgeo_agg": _estimate(by_claim, "adapter_bank_gain_vs_fedgeo_agg"),
        "gain_vs_fedgeo_agg_supports": _supports(by_claim, "adapter_bank_gain_vs_fedgeo_agg"),
        "worst_risk_reduction_vs_fedgeo_agg": _estimate(by_claim, "worst_client_risk_reduction_vs_fedgeo_agg"),
        "worst_risk_supports": _supports(by_claim, "worst_client_risk_reduction_vs_fedgeo_agg"),
        "update_conflict_reduction_vs_fedgeo_agg": _estimate(by_claim, "update_conflict_reduction_vs_fedgeo_agg"),
        "update_conflict_supports": _supports(by_claim, "update_conflict_reduction_vs_fedgeo_agg"),
        "client_drift_reduction_vs_fedgeo_agg": _estimate(by_claim, "client_drift_reduction_vs_fedgeo_agg"),
        "graph_neighbor_conflict_reduction_vs_fedgeo_agg": _estimate(by_claim, "graph_neighbor_conflict_reduction_vs_fedgeo_agg"),
        "output_dir": str(output_dir),
    }


def _estimate(by_claim: dict[str, dict], claim_id: str) -> str:
    return by_claim.get(claim_id, {}).get("estimate", "")


def _supports(by_claim: dict[str, dict], claim_id: str) -> str:
    return by_claim.get(claim_id, {}).get("supports", "")


def _summary_estimate(
    by_metric: dict[tuple[str, str, str, str], dict],
    test: str,
    method: str,
    baseline: str,
    measure: str,
) -> str:
    return by_metric.get((test, method, baseline, measure), {}).get("estimate", "")


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _select_ablations(value: str) -> list[dict]:
    if not value:
        return list(ABLATIONS)
    requested = [part.strip() for part in str(value).split(",") if part.strip()]
    by_name = {ablation["name"]: ablation for ablation in ABLATIONS}
    missing = [name for name in requested if name not in by_name]
    if missing:
        valid = ", ".join(sorted(by_name))
        raise ValueError(f"Unknown ablation(s): {', '.join(missing)}. Valid names: {valid}")
    return [by_name[name] for name in requested]


if __name__ == "__main__":
    raise SystemExit(main())
