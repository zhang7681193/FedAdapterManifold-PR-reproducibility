from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv
from fedadaptermanifold.claims import build_multiseed_claim_report
from scripts.run_fedgeo_multiseed import main as run_multiseed


DATASETS = [
    ("pacs-debug", "configs/pacs_debug.yaml"),
    ("cifar10-debug", "configs/cifar10_debug.yaml"),
]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the FedAdapterManifold debug benchmark suite.")
    parser.add_argument("--output-root", type=str, default="results/fedadaptermanifold_debug_suite")
    parser.add_argument("--seeds", type=str, default="0,1,2,3,4,5")
    parser.add_argument("--round-id", type=int, default=0)
    parser.add_argument("--geometry-outputs-template", type=str, default="")
    parser.add_argument("--continue-on-failed-diagnostic", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    root = ensure_dir(args.output_root)
    all_summary: list[dict] = []
    run_rows: list[dict] = []
    exit_codes = []
    for dataset, config in DATASETS:
        output_dir = root / dataset
        multiseed_args = [
            "--config",
            config,
            "--output-root",
            str(output_dir),
            "--seeds",
            args.seeds,
            "--round-id",
            str(args.round_id),
            "--strict-support-exit",
        ]
        if args.geometry_outputs_template:
            template = args.geometry_outputs_template.format(dataset=dataset, seed="{seed}", round_id=args.round_id)
            multiseed_args.extend(["--geometry-outputs-template", template])
        if args.continue_on_failed_diagnostic:
            multiseed_args.append("--continue-on-failed-diagnostic")
        code = run_multiseed(multiseed_args)
        exit_codes.append(code)
        run_rows.append(
            {
                "dataset": dataset,
                "config": config,
                "output_dir": str(output_dir),
                "exit_code": code,
            }
        )
        for row in _read_csv(output_dir / "multiseed_summary.csv"):
            row["dataset"] = dataset
            all_summary.append(row)
    write_csv(root / "suite_runs.csv", run_rows)
    write_csv(root / "suite_summary.csv", all_summary)
    write_csv(root / "suite_claim_matrix.csv", _claim_matrix(all_summary))
    write_csv(root / "suite_claim_report.csv", _suite_claim_report(all_summary))
    return 0 if all(code == 0 for code in exit_codes) else 2


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _claim_matrix(rows: list[dict]) -> list[dict]:
    wanted = [
        ("distance_failure_correlation", "", "", "d_sub", "subspace_failure_correlation"),
        ("distance_failure_correlation", "", "", "d_geo", "geometry_failure_correlation"),
        ("paired_accuracy_gain", "FedAdapterManifold", "FedAvg-LoRA", "mean_accuracy_gain", "fam_gain_vs_fedavg"),
        ("paired_accuracy_gain", "FedAdapterManifold", "FedGeo-Agg", "mean_accuracy_gain", "fam_gain_vs_fedgeo_agg"),
        ("paired_risk_reduction", "FedAdapterManifold", "FedGeo-Agg", "worst_client_risk", "worst_risk_reduction_vs_fedgeo_agg"),
        ("paired_risk_reduction", "FedAdapterManifold", "FedGeo-Agg", "mean_update_conflict_vs_local", "update_conflict_reduction_vs_fedgeo_agg"),
        ("paired_risk_reduction", "FedAdapterManifold", "FedGeo-Agg", "mean_graph_neighbor_update_conflict", "graph_conflict_reduction_vs_fedgeo_agg"),
    ]
    out = []
    for dataset in sorted({row["dataset"] for row in rows}):
        dataset_rows = [row for row in rows if row["dataset"] == dataset]
        for test, method, baseline, measure, claim in wanted:
            match = None
            for row in dataset_rows:
                if (
                    row.get("test") == test
                    and row.get("method", "") == method
                    and row.get("baseline", "") == baseline
                    and row.get("measure") == measure
                ):
                    match = row
                    break
            if match is None:
                continue
            out.append(
                {
                    "dataset": dataset,
                    "claim": claim,
                    "test": test,
                    "method": method,
                    "baseline": baseline,
                    "measure": measure,
                    "estimate": match.get("estimate", ""),
                    "ci_low": match.get("ci_low", ""),
                    "ci_high": match.get("ci_high", ""),
                    "supports": match.get("supports", ""),
                }
            )
    return out


def _suite_claim_report(rows: list[dict]) -> list[dict]:
    out = []
    for dataset in sorted({row["dataset"] for row in rows}):
        dataset_rows = [row for row in rows if row["dataset"] == dataset]
        for claim_row in build_multiseed_claim_report(dataset_rows):
            claim_row = dict(claim_row)
            claim_row["dataset"] = dataset
            out.append(claim_row)
    return out


if __name__ == "__main__":
    raise SystemExit(main())
