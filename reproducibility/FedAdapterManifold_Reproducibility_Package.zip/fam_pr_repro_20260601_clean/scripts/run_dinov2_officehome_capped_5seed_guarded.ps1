param(
    [switch]$NoWaitGpu
)

$ErrorActionPreference = "Stop"

$Root = Resolve-Path (Join-Path $PSScriptRoot "..")
if (-not $Python) { $Python = "python" }
$SourceRoot = Join-Path $Root "results\fam_officehome_ditto_fam_guarded_audit_5seed_v1"
$OutputRoot = Join-Path $Root "results\fam_dinov2_officehome_capped_5seed_v1"
$FeatureCache = Join-Path $Root "results\feature_cache\officehome_dinov2_vits14"
$StatusLog = Join-Path $OutputRoot "launcher_status.log"

New-Item -ItemType Directory -Force -Path $OutputRoot | Out-Null

function Write-Status {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Message
    $line | Tee-Object -FilePath $StatusLog -Append
}

function Get-GpuPythonPids {
    $lines = & nvidia-smi --query-compute-apps=pid,process_name --format=csv,noheader 2>$null
    if (-not $lines) {
        return @()
    }
    $pids = @()
    foreach ($line in $lines) {
        $parts = $line.Split(",", 2)
        if ($parts.Count -lt 2) {
            continue
        }
        $pidText = $parts[0].Trim()
        $name = $parts[1].Trim()
        if ($name -like "*python.exe") {
            $pids += [int]$pidText
        }
    }
    return $pids
}

function Wait-GpuFree {
    while ($true) {
        $pids = Get-GpuPythonPids
        if ($pids.Count -eq 0) {
            Write-Status "GPU has no python compute process; starting/resuming DINOv2 OfficeHome run."
            return
        }
        Write-Status ("Waiting for other GPU python processes to finish: " + ($pids -join ","))
        Start-Sleep -Seconds 60
    }
}

Write-Status "Queued guarded OfficeHome-DINOv2 capped 5-seed run."
Write-Status "Output root: $OutputRoot"
Write-Status "Feature cache: $FeatureCache"

if ($NoWaitGpu) {
    Write-Status "NoWaitGpu set; starting immediately even if other GPU jobs are active."
} else {
    Wait-GpuFree
}

$seedDirs = @()
foreach ($seed in 0..4) {
    $seedName = "seed_$seed"
    $sourceConfig = Join-Path $SourceRoot "$seedName\config.yaml"
    $seedOut = Join-Path $OutputRoot $seedName
    $seedLog = Join-Path $seedOut "run.log"
    New-Item -ItemType Directory -Force -Path $seedOut | Out-Null
    $seedDirs += "$seed=$seedOut"

    if (Test-Path (Join-Path $seedOut "metrics.csv")) {
        Write-Status "Seed $seed already has metrics.csv; skipping."
        continue
    }
    if (-not (Test-Path $sourceConfig)) {
        throw "Missing source config for seed ${seed}: $sourceConfig"
    }

    Write-Status "Starting seed $seed."
    $seedErr = Join-Path $seedOut "run.err.log"
    $runArgs = @(
        "-m", "fedadaptermanifold.run_experiment",
        "--config", $sourceConfig,
        "--seed", "$seed",
        "--feature-backbone", "dinov2-vits14",
        "--feature-cache-dir", $FeatureCache,
        "--output-dir", $seedOut,
        "--base-head-init", "zero",
        "--train-per-client", "240",
        "--test-per-client", "160",
        "--candidate-selector-policy", "diagnostic-gated",
        "--strong-candidate-selector-policy", "anchored-no-regret",
        "--no-cpu-debug",
        "--device", "cpu"
    )
    Push-Location $Root
    try {
        & $Python @runArgs > $seedLog 2> $seedErr
        $exitCode = $LASTEXITCODE
    } finally {
        Pop-Location
    }
    Write-Status "Seed $seed python exit code: $exitCode."

    if (-not (Test-Path (Join-Path $seedOut "metrics.csv"))) {
        throw "Seed $seed finished without metrics.csv. See $seedLog and $seedErr"
    }
    Write-Status "Completed seed $seed."
}

Write-Status "Aggregating completed seeds."
$aggArgs = @("scripts\aggregate_existing_multiseed.py", "--output-root", $OutputRoot)
foreach ($seedDir in $seedDirs) {
    $aggArgs += "--seed-dir"
    $aggArgs += $seedDir
}
& $Python @aggArgs *>&1 | Tee-Object -FilePath (Join-Path $OutputRoot "aggregate.log")
Write-Status "Finished guarded OfficeHome-DINOv2 capped 5-seed run."
