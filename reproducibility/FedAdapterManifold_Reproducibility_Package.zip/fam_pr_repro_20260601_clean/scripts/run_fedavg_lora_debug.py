from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.baselines import run_fedavg_lora_baseline, summarize_method
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.reporting import ensure_dir, write_csv


def main() -> int:
    output_dir = ensure_dir("results/fedadaptermanifold_step3")
    clients, base_weight = make_synthetic_manifold_clients(
        num_clients=4,
        num_classes=7,
        feature_dim=48,
        train_per_client=240,
        test_per_client=160,
        rank=4,
        seed=0,
    )
    result = run_fedavg_lora_baseline(
        clients,
        base_weight,
        ranks=[4, 4, 4, 4],
        rounds=3,
        local_epochs=18,
        lr=0.45,
        batch_size=32,
        seed=0,
        dataset="pacs-debug",
        heterogeneity_setting="domain-adapter-manifold-debug",
    )
    write_csv(output_dir / "metrics.csv", summarize_method(result.per_client_metrics))
    write_csv(output_dir / "per_client_metrics.csv", result.per_client_metrics)
    write_csv(output_dir / "fedavg_lora_history.csv", result.round_history)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
