from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv
from fedadaptermanifold.run_experiment import main as run_experiment
from fedadaptermanifold.fedgeo_validation import validate_geometry_outputs
from fedadaptermanifold.claims import build_multiseed_claim_report, core_claims_supported


DEFAULT_SEEDS = [0, 1, 2]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run FedAdapterManifold over multiple seeds.")
    parser.add_argument("--config", type=str, default="configs/pacs_debug.yaml")
    parser.add_argument("--output-root", type=str, default="results/fedadaptermanifold_fedgeo_multiseed")
    parser.add_argument("--geometry-outputs-dir", type=str, default="")
    parser.add_argument(
        "--geometry-outputs-template",
        type=str,
        default="",
        help="Optional template such as results/fedgeo/seed_{seed}/geometry_outputs.",
    )
    parser.add_argument(
        "--geometry-outputs-map",
        type=str,
        default="",
        help="Optional seed mapping, either a CSV path with seed,geometry_outputs_dir or '0=path;1=path'.",
    )
    parser.add_argument("--round-id", type=int, default=0)
    parser.add_argument("--seeds", type=str, default="0,1,2")
    parser.add_argument("--data-root", type=str, default="")
    parser.add_argument("--domains", type=str, default="")
    parser.add_argument("--num-clients", type=str, default="")
    parser.add_argument("--num-classes", type=str, default="")
    parser.add_argument("--feature-dim", type=str, default="")
    parser.add_argument("--dirichlet-alpha", type=str, default="")
    parser.add_argument("--min-train-size", type=str, default="")
    parser.add_argument("--align-test-with-train", action="store_true")
    parser.add_argument("--no-align-test-with-train", action="store_true")
    parser.add_argument("--train-per-client", type=str, default="")
    parser.add_argument("--test-per-client", type=str, default="")
    parser.add_argument("--rounds", type=str, default="")
    parser.add_argument("--local-epochs", type=str, default="")
    parser.add_argument("--test-fraction", type=str, default="")
    parser.add_argument("--feature-backbone", type=str, default="")
    parser.add_argument("--feature-cache-dir", type=str, default="")
    parser.add_argument("--base-head-init", type=str, default="")
    parser.add_argument("--base-head-scale", type=str, default="")
    parser.add_argument("--class-prompt-template", type=str, default="")
    parser.add_argument("--device", type=str, default="")
    parser.add_argument("--cpu-debug", action="store_true")
    parser.add_argument("--no-cpu-debug", action="store_true")
    parser.add_argument("--shared-weight", type=str, default="")
    parser.add_argument("--shared-weight-policy", type=str, default="")
    parser.add_argument("--shared-weight-tolerance", type=str, default="")
    parser.add_argument("--shared-weight-candidates", type=str, default="")
    parser.add_argument("--personal-weight", type=str, default="")
    parser.add_argument("--personal-weight-policy", type=str, default="")
    parser.add_argument("--personal-weight-tolerance", type=str, default="")
    parser.add_argument("--personal-weight-candidates", type=str, default="")
    parser.add_argument("--manifold-smoothing-weight", type=str, default="")
    parser.add_argument("--manifold-smoothing-policy", type=str, default="")
    parser.add_argument("--manifold-smoothing-tolerance", type=str, default="")
    parser.add_argument("--manifold-smoothing-candidates", type=str, default="")
    parser.add_argument("--candidate-selector-policy", type=str, default="")
    parser.add_argument("--candidate-selector-scope", type=str, default="")
    parser.add_argument("--candidate-selector-loss-tolerance", type=str, default="")
    parser.add_argument("--candidate-selector-loss-tolerance-ratio", type=str, default="")
    parser.add_argument("--candidate-selector-neighbor-weight", type=str, default="")
    parser.add_argument("--tau", type=str, default="")
    parser.add_argument("--route-tau", type=str, default="")
    parser.add_argument("--adapter-graph-mode", type=str, default="")
    parser.add_argument("--adapter-graph-self-weight", type=str, default="")
    parser.add_argument("--adapter-graph-mix-weight", type=str, default="")
    parser.add_argument("--adapter-graph-mix-policy", type=str, default="")
    parser.add_argument("--adapter-graph-mix-tolerance", type=str, default="")
    parser.add_argument("--adapter-graph-mix-candidates", type=str, default="")
    parser.add_argument("--adapter-graph-distance", type=str, default="")
    parser.add_argument("--adapter-graph-compatibility", type=str, default="")
    parser.add_argument("--adapter-bank-k", type=str, default="")
    parser.add_argument("--adapter-bank-routing", type=str, default="")
    parser.add_argument("--adapter-bank-prior-weight", type=str, default="")
    parser.add_argument("--lambda-geo", type=str, default="")
    parser.add_argument("--lambda-label", type=str, default="")
    parser.add_argument("--rank", type=str, default="")
    parser.add_argument("--rank-policy", type=str, default="")
    parser.add_argument("--min-rank", type=str, default="")
    parser.add_argument("--max-rank", type=str, default="")
    parser.add_argument("--continue-on-failed-diagnostic", action="store_true")
    parser.add_argument("--strict-support-exit", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    seeds = _parse_seeds(args.seeds)
    output_root = ensure_dir(args.output_root)

    all_metrics: list[dict] = []
    all_per_client: list[dict] = []
    all_risk: list[dict] = []
    all_conflicts: list[dict] = []
    all_idea: list[dict] = []
    run_rows: list[dict] = []
    run_failed = False

    for seed in seeds:
        seed_output = output_root / f"seed_{seed}"
        geometry_dir = _geometry_dir_for_seed(args, seed)
        argv_seed = [
            "--config",
            args.config,
            "--seed",
            str(seed),
            "--output-dir",
            str(seed_output),
            "--round-id",
            str(args.round_id),
        ]
        if args.cpu_debug:
            argv_seed.append("--cpu-debug")
        if args.no_cpu_debug:
            argv_seed.append("--no-cpu-debug")
        if geometry_dir:
            validation_rows, validation_issues = validate_geometry_outputs(geometry_dir, round_id=args.round_id)
            validation_dir = ensure_dir(seed_output / "geometry_validation")
            write_csv(validation_dir / "geometry_validation.csv", validation_rows)
            write_csv(validation_dir / "geometry_validation_issues.csv", validation_issues)
            has_errors = any(issue.get("severity") == "error" for issue in validation_issues)
            if has_errors:
                run_rows.append(
                    {
                        "seed": seed,
                        "exit_code": 2,
                        "geometry_outputs_dir": geometry_dir,
                        "output_dir": str(seed_output),
                        "validation_errors": len([issue for issue in validation_issues if issue.get("severity") == "error"]),
                    }
                )
                run_failed = True
                continue
            argv_seed.extend(["--geometry-outputs-dir", geometry_dir])
        for cli_name, value in [
            ("--data-root", args.data_root),
            ("--domains", args.domains),
            ("--num-clients", args.num_clients),
            ("--num-classes", args.num_classes),
            ("--feature-dim", args.feature_dim),
            ("--dirichlet-alpha", args.dirichlet_alpha),
            ("--min-train-size", args.min_train_size),
            ("--train-per-client", args.train_per_client),
            ("--test-per-client", args.test_per_client),
            ("--rounds", args.rounds),
            ("--local-epochs", args.local_epochs),
            ("--test-fraction", args.test_fraction),
            ("--feature-backbone", args.feature_backbone),
            ("--feature-cache-dir", args.feature_cache_dir),
            ("--base-head-init", args.base_head_init),
            ("--base-head-scale", args.base_head_scale),
            ("--class-prompt-template", args.class_prompt_template),
            ("--device", args.device),
            ("--shared-weight", args.shared_weight),
            ("--shared-weight-policy", args.shared_weight_policy),
            ("--shared-weight-tolerance", args.shared_weight_tolerance),
            ("--shared-weight-candidates", args.shared_weight_candidates),
            ("--personal-weight", args.personal_weight),
            ("--personal-weight-policy", args.personal_weight_policy),
            ("--personal-weight-tolerance", args.personal_weight_tolerance),
            ("--personal-weight-candidates", args.personal_weight_candidates),
            ("--manifold-smoothing-weight", args.manifold_smoothing_weight),
            ("--manifold-smoothing-policy", args.manifold_smoothing_policy),
            ("--manifold-smoothing-tolerance", args.manifold_smoothing_tolerance),
            ("--manifold-smoothing-candidates", args.manifold_smoothing_candidates),
            ("--candidate-selector-policy", args.candidate_selector_policy),
            ("--candidate-selector-scope", args.candidate_selector_scope),
            ("--candidate-selector-loss-tolerance", args.candidate_selector_loss_tolerance),
            ("--candidate-selector-loss-tolerance-ratio", args.candidate_selector_loss_tolerance_ratio),
            ("--candidate-selector-neighbor-weight", args.candidate_selector_neighbor_weight),
            ("--tau", args.tau),
            ("--route-tau", args.route_tau),
            ("--adapter-graph-mode", args.adapter_graph_mode),
            ("--adapter-graph-self-weight", args.adapter_graph_self_weight),
            ("--adapter-graph-mix-weight", args.adapter_graph_mix_weight),
            ("--adapter-graph-mix-policy", args.adapter_graph_mix_policy),
            ("--adapter-graph-mix-tolerance", args.adapter_graph_mix_tolerance),
            ("--adapter-graph-mix-candidates", args.adapter_graph_mix_candidates),
            ("--adapter-graph-distance", args.adapter_graph_distance),
            ("--adapter-graph-compatibility", args.adapter_graph_compatibility),
            ("--adapter-bank-k", args.adapter_bank_k),
            ("--adapter-bank-routing", args.adapter_bank_routing),
            ("--adapter-bank-prior-weight", args.adapter_bank_prior_weight),
            ("--lambda-geo", args.lambda_geo),
            ("--lambda-label", args.lambda_label),
            ("--rank", args.rank),
            ("--rank-policy", args.rank_policy),
            ("--min-rank", args.min_rank),
            ("--max-rank", args.max_rank),
        ]:
            if value != "":
                argv_seed.extend([cli_name, str(value)])
        if args.align_test_with_train:
            argv_seed.append("--align-test-with-train")
        if args.no_align_test_with_train:
            argv_seed.append("--no-align-test-with-train")
        if args.continue_on_failed_diagnostic:
            argv_seed.append("--continue-on-failed-diagnostic")

        code = run_experiment(argv_seed)
        if code != 0:
            run_failed = True
        run_rows.append(
            {
                "seed": seed,
                "exit_code": code,
                "geometry_outputs_dir": geometry_dir,
                "output_dir": str(seed_output),
                "validation_errors": "",
            }
        )

        metrics = _read_csv(seed_output / "metrics.csv")
        per_client = _read_csv(seed_output / "per_client_metrics.csv")
        risk = _read_csv(seed_output / "risk_metrics.csv")
        conflicts = _read_csv(seed_output / "adapter_conflict.csv")
        idea = _read_csv(seed_output / "idea_support.csv")
        for rows in [metrics, per_client, risk, conflicts, idea]:
            for row in rows:
                row["source_seed"] = seed
        all_metrics.extend(metrics)
        all_per_client.extend(per_client)
        all_risk.extend(risk)
        all_conflicts.extend(conflicts)
        all_idea.extend(idea)

    summary_rows = []
    summary_rows.extend(_method_accuracy_summary(all_metrics))
    summary_rows.extend(_risk_summary(all_risk))
    summary_rows.extend(_paired_risk_reduction_stats(all_risk, baseline="FedAvg-LoRA"))
    summary_rows.extend(_paired_risk_reduction_stats(all_risk, baseline="FedGeo-Agg"))
    summary_rows.extend(_pooled_distance_stats(all_conflicts))
    summary_rows.extend(_paired_gain_stats(all_per_client, baseline="FedAvg-LoRA"))
    summary_rows.extend(_paired_gain_stats(all_per_client, baseline="FedGeo-Agg"))
    claim_rows = build_multiseed_claim_report(summary_rows)

    write_csv(output_root / "runs.csv", run_rows)
    write_csv(output_root / "multiseed_metrics.csv", all_metrics)
    write_csv(output_root / "multiseed_per_client_metrics.csv", all_per_client)
    write_csv(output_root / "multiseed_risk_metrics.csv", all_risk)
    write_csv(output_root / "multiseed_adapter_conflict.csv", all_conflicts)
    write_csv(output_root / "multiseed_idea_support.csv", all_idea)
    write_csv(output_root / "multiseed_summary.csv", summary_rows)
    write_csv(output_root / "multiseed_claim_report.csv", claim_rows)

    required = [
        row
        for row in summary_rows
        if row.get("test") == "paired_accuracy_gain"
        and row.get("baseline") == "FedAvg-LoRA"
        and row.get("method") == "FedAdapterManifold"
    ]
    required += [
        row
        for row in summary_rows
        if row.get("test") == "distance_failure_correlation" and row.get("measure") in {"d_adapter_incompatibility", "d_geo"}
    ]
    if run_failed:
        return 2
    if args.strict_support_exit:
        return 0 if required and core_claims_supported(claim_rows) else 2
    return 0


def _parse_seeds(text: str) -> list[int]:
    values = [part.strip() for part in str(text).split(",") if part.strip()]
    return [int(value) for value in values] if values else list(DEFAULT_SEEDS)


def _geometry_dir_for_seed(args: argparse.Namespace, seed: int) -> str:
    if args.geometry_outputs_map:
        mapping = _parse_geometry_map(args.geometry_outputs_map)
        return mapping.get(seed, "")
    if args.geometry_outputs_template:
        return args.geometry_outputs_template.format(seed=seed, round_id=args.round_id)
    return args.geometry_outputs_dir


def _parse_geometry_map(value: str) -> dict[int, str]:
    value = str(value)
    path = Path(value)
    if "=" not in value and path.exists():
        with path.open("r", newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
        return {
            int(row["seed"]): row.get("geometry_outputs_dir", row.get("path", ""))
            for row in rows
            if row.get("seed") not in {"", None}
        }
    out: dict[int, str] = {}
    for part in str(value).split(";"):
        if not part.strip() or "=" not in part:
            continue
        seed_text, geometry_dir = part.split("=", 1)
        out[int(seed_text.strip())] = geometry_dir.strip().strip('"').strip("'")
    return out


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _method_accuracy_summary(rows: list[dict]) -> list[dict]:
    grouped: dict[str, list[float]] = {}
    for row in rows:
        if "mean_accuracy" in row and row["mean_accuracy"] != "":
            grouped.setdefault(row["method"], []).append(float(row["mean_accuracy"]))
    out = []
    for method, values in grouped.items():
        arr = np.asarray(values, dtype=np.float64)
        out.append(
            {
                "test": "method_accuracy",
                "method": method,
                "baseline": "",
                "measure": "mean_accuracy",
                "estimate": float(arr.mean()),
                "std": float(arr.std()),
                "num_observations": int(arr.size),
                "supports": "",
            }
        )
    return out


def _risk_summary(rows: list[dict]) -> list[dict]:
    measures = [
        "worst_client_risk",
        "mean_client_drift_vs_local",
        "mean_update_conflict_vs_local",
        "mean_graph_neighbor_update_conflict",
    ]
    grouped: dict[tuple[str, str], list[float]] = {}
    for row in rows:
        method = row.get("method", "")
        for measure in measures:
            value = row.get(measure, "")
            if value == "":
                continue
            grouped.setdefault((method, measure), []).append(float(value))
    out = []
    for (method, measure), values in grouped.items():
        arr = np.asarray(values, dtype=np.float64)
        out.append(
            {
                "test": "risk",
                "method": method,
                "baseline": "",
                "measure": measure,
                "estimate": float(arr.mean()),
                "std": float(arr.std()),
                "num_observations": int(arr.size),
                "supports": "",
            }
        )
    return out


def _paired_risk_reduction_stats(rows: list[dict], baseline: str) -> list[dict]:
    out = []
    measures = [
        "worst_client_risk",
        "mean_client_drift_vs_local",
        "mean_update_conflict_vs_local",
        "mean_graph_neighbor_update_conflict",
    ]
    by_key = {
        (row["method"], row["source_seed"]): row
        for row in rows
    }
    methods = sorted({row["method"] for row in rows if row.get("method") != baseline})
    seeds = sorted({row["source_seed"] for row in rows})
    rng = np.random.default_rng(6151 + sum(ord(ch) for ch in baseline))
    for method in methods:
        for measure in measures:
            diffs = []
            for seed in seeds:
                base = by_key.get((baseline, seed))
                current = by_key.get((method, seed))
                if base is None or current is None:
                    continue
                base_value = base.get(measure, "")
                current_value = current.get(measure, "")
                if base_value == "" or current_value == "":
                    continue
                diffs.append(float(base_value) - float(current_value))
            if not diffs:
                continue
            values = np.asarray(diffs, dtype=np.float64)
            low, high = _bootstrap_mean(values, rng)
            estimate = float(values.mean())
            out.append(
                {
                    "test": "paired_risk_reduction",
                    "method": method,
                    "baseline": baseline,
                    "measure": measure,
                    "estimate": estimate,
                    "ci_low": low,
                    "ci_high": high,
                    "num_observations": int(values.size),
                    "supports": bool(estimate > 0 and low > 0),
                }
            )
    return out


def _pooled_distance_stats(conflict_rows: list[dict]) -> list[dict]:
    rows = []
    rng = np.random.default_rng(6101)
    if not conflict_rows:
        return rows
    conflict_rows = _ensure_failure_control_fields(conflict_rows)
    for measure in ["d_sub", "d_update", "d_adapter_incompatibility", "d_geo", "d_combined", "d_label"]:
        x = np.asarray([float(row[measure]) for row in conflict_rows], dtype=np.float64)
        for test_name, target_field in [
            ("distance_failure_correlation", "aggregation_failure"),
            ("distance_receiver_residual_failure_correlation", "receiver_residual_aggregation_failure"),
            ("distance_pair_mean_failure_correlation", "pair_mean_aggregation_failure"),
            ("distance_pair_max_failure_correlation", "pair_max_aggregation_failure"),
        ]:
            y = np.asarray([float(row[target_field]) for row in conflict_rows], dtype=np.float64)
            estimate = _pearson(x, y)
            low, high = _bootstrap_corr(x, y, rng)
            rows.append(
                {
                    "test": test_name,
                    "method": "",
                    "baseline": "",
                    "measure": measure,
                    "estimate": estimate,
                    "ci_low": low,
                    "ci_high": high,
                    "num_observations": len(conflict_rows),
                    "supports": bool(np.isfinite(estimate) and estimate > 0 and np.isfinite(low) and low > 0),
                }
            )
    return rows


def _ensure_failure_control_fields(conflict_rows: list[dict]) -> list[dict]:
    rows = [dict(row) for row in conflict_rows]
    if not rows:
        return rows
    if all("receiver_residual_aggregation_failure" in row for row in rows):
        return rows
    by_receiver: dict[tuple[str, str], list[float]] = {}
    by_pair: dict[tuple[str, str, str], list[float]] = {}
    for row in rows:
        seed = str(row.get("source_seed", row.get("seed", "")))
        failure = float(row["aggregation_failure"])
        receiver_key = (seed, str(row["client_i"]))
        pair_key = (seed,) + tuple(sorted((str(row["client_i"]), str(row["client_j"]))))
        by_receiver.setdefault(receiver_key, []).append(failure)
        by_pair.setdefault(pair_key, []).append(failure)
    receiver_mean = {key: float(np.mean(values)) for key, values in by_receiver.items()}
    pair_mean = {key: float(np.mean(values)) for key, values in by_pair.items()}
    pair_max = {key: float(np.max(values)) for key, values in by_pair.items()}
    for row in rows:
        seed = str(row.get("source_seed", row.get("seed", "")))
        failure = float(row["aggregation_failure"])
        receiver_key = (seed, str(row["client_i"]))
        pair_key = (seed,) + tuple(sorted((str(row["client_i"]), str(row["client_j"]))))
        row["receiver_mean_aggregation_failure"] = receiver_mean.get(receiver_key, 0.0)
        row["receiver_residual_aggregation_failure"] = failure - receiver_mean.get(receiver_key, 0.0)
        row["pair_mean_aggregation_failure"] = pair_mean.get(pair_key, failure)
        row["pair_max_aggregation_failure"] = pair_max.get(pair_key, failure)
    return rows


def _paired_gain_stats(per_client_rows: list[dict], baseline: str) -> list[dict]:
    rows = []
    by_key = {
        (row["method"], row["source_seed"], row["client_id"]): float(row["accuracy"])
        for row in per_client_rows
        if row.get("accuracy", "") != ""
    }
    units = sorted({(row["source_seed"], row["client_id"]) for row in per_client_rows})
    methods = sorted({row["method"] for row in per_client_rows if row.get("method") != baseline})
    rng = np.random.default_rng(6201 + sum(ord(ch) for ch in baseline))
    for method in methods:
        diffs = []
        for seed, client_id in units:
            base_key = (baseline, seed, client_id)
            method_key = (method, seed, client_id)
            if base_key in by_key and method_key in by_key:
                diffs.append(by_key[method_key] - by_key[base_key])
        if not diffs:
            continue
        values = np.asarray(diffs, dtype=np.float64)
        low, high = _bootstrap_mean(values, rng)
        estimate = float(values.mean())
        rows.append(
            {
                "test": "paired_accuracy_gain",
                "method": method,
                "baseline": baseline,
                "measure": "mean_accuracy_gain",
                "estimate": estimate,
                "ci_low": low,
                "ci_high": high,
                "num_observations": int(values.size),
                "supports": bool(estimate > 0 and low > 0),
            }
        )
    return rows


def _pearson(x, y) -> float:
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    if x.size < 2:
        return float("nan")
    x = x - x.mean()
    y = y - y.mean()
    denom = np.sqrt(np.sum(x * x) * np.sum(y * y))
    if denom <= 1e-12:
        return float("nan")
    return float(np.sum(x * y) / denom)


def _bootstrap_corr(x, y, rng, n_boot=1000):
    values = []
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    for _ in range(n_boot):
        idx = rng.integers(0, x.size, size=x.size)
        value = _pearson(x[idx], y[idx])
        if np.isfinite(value):
            values.append(value)
    if not values:
        return float("nan"), float("nan")
    arr = np.asarray(values, dtype=np.float64)
    return float(np.quantile(arr, 0.025)), float(np.quantile(arr, 0.975))


def _bootstrap_mean(values, rng, n_boot=1000):
    values = np.asarray(values, dtype=np.float64)
    means = []
    for _ in range(n_boot):
        idx = rng.integers(0, values.size, size=values.size)
        means.append(float(values[idx].mean()))
    arr = np.asarray(means, dtype=np.float64)
    return float(np.quantile(arr, 0.025)), float(np.quantile(arr, 0.975))


if __name__ == "__main__":
    raise SystemExit(main())
