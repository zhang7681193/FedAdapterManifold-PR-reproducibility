from __future__ import annotations

from pathlib import Path
import argparse
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv
from scripts.run_fedgeo_multiseed import main as run_multiseed


LOCAL_GEOMETRY_SOURCES = {"local", "local_prototype", "prototype", "temporary_prototype"}


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run FedAdapterManifold over multiple FedGeo geometry sources.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--data-root", required=True)
    parser.add_argument("--fedgeo-results-root", required=True)
    parser.add_argument("--source-template", default="{dataset_prefix}_seed{seed}/{source}/geometry_outputs")
    parser.add_argument("--dataset-prefix", default="pacs_pretrained_unfrozen_active_sparse30_10round_compare")
    parser.add_argument("--sources", default="fedavg,topk,utility_only,fedgeo_full")
    parser.add_argument("--seeds", default="0,1,2")
    parser.add_argument("--round-id", type=int, default=0)
    parser.add_argument("--feature-cache-dir", default="")
    parser.add_argument("--feature-backbone", default="")
    parser.add_argument("--device", default="")
    parser.add_argument("--no-cpu-debug", action="store_true")
    parser.add_argument("--continue-on-failed-diagnostic", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    output_root = ensure_dir(args.output_root)
    sources = [part.strip() for part in str(args.sources).split(",") if part.strip()]
    rows = []
    failed = False
    for source in sources:
        source_output = output_root / source
        geometry_map = _geometry_map(args, source)
        multiseed_argv = [
            "--config",
            args.config,
            "--output-root",
            str(source_output),
            "--seeds",
            args.seeds,
            "--round-id",
            str(args.round_id),
            "--data-root",
            args.data_root,
        ]
        if geometry_map:
            multiseed_argv.extend(["--geometry-outputs-map", geometry_map])
        for cli_key, value in [
            ("--feature-cache-dir", args.feature_cache_dir),
            ("--feature-backbone", args.feature_backbone),
            ("--device", args.device),
        ]:
            if value:
                multiseed_argv.extend([cli_key, value])
        if args.no_cpu_debug:
            multiseed_argv.append("--no-cpu-debug")
        if args.continue_on_failed_diagnostic:
            multiseed_argv.append("--continue-on-failed-diagnostic")
        code = run_multiseed(multiseed_argv)
        failed = failed or code != 0
        rows.append(
            {
                "source": source,
                "exit_code": code,
                "output_root": str(source_output),
                "geometry_outputs_map": geometry_map,
            }
        )
        write_csv(output_root / "geometry_source_ablation_runs.csv", rows)
    return 2 if failed else 0


def _geometry_map(args: argparse.Namespace, source: str) -> str:
    if source.strip().lower().replace("-", "_") in LOCAL_GEOMETRY_SOURCES:
        return ""
    root = Path(args.fedgeo_results_root)
    seeds = [part.strip() for part in str(args.seeds).split(",") if part.strip()]
    parts = []
    for seed in seeds:
        rel = args.source_template.format(dataset_prefix=args.dataset_prefix, seed=seed, source=source)
        parts.append(f"{seed}={root / rel}")
    return ";".join(parts)


if __name__ == "__main__":
    raise SystemExit(main())
