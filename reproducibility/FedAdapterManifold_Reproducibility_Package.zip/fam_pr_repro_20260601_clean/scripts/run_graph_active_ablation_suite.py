from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv
from scripts.run_fedgeo_multiseed import main as run_multiseed


GRAPH_MODES = ["fedgeo", "complete", "self", "random"]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run graph-active adapter sharing ablations.")
    parser.add_argument("--config", type=str, required=True)
    parser.add_argument("--output-root", type=str, default="results/graph_active_ablation")
    parser.add_argument("--seeds", type=str, default="0,1,2")
    parser.add_argument("--round-id", type=int, default=0)
    parser.add_argument("--data-root", type=str, default="")
    parser.add_argument("--domains", type=str, default="")
    parser.add_argument("--geometry-outputs-map", type=str, default="")
    parser.add_argument("--geometry-outputs-dir", type=str, default="")
    parser.add_argument("--graph-modes", type=str, default="fedgeo,complete,self,random")
    parser.add_argument("--self-weights", type=str, default="1.0,0.25")
    parser.add_argument("--rounds", type=str, default="")
    parser.add_argument("--local-epochs", type=str, default="")
    parser.add_argument("--train-per-client", type=str, default="")
    parser.add_argument("--test-per-client", type=str, default="")
    parser.add_argument("--feature-backbone", type=str, default="")
    parser.add_argument("--feature-cache-dir", type=str, default="")
    parser.add_argument("--device", type=str, default="")
    parser.add_argument("--cpu-debug", action="store_true")
    parser.add_argument("--no-cpu-debug", action="store_true")
    parser.add_argument("--shared-weight", type=str, default="")
    parser.add_argument("--shared-weight-policy", type=str, default="")
    parser.add_argument("--shared-weight-tolerance", type=str, default="")
    parser.add_argument("--shared-weight-candidates", type=str, default="")
    parser.add_argument("--personal-weight", type=str, default="")
    parser.add_argument("--personal-weight-policy", type=str, default="")
    parser.add_argument("--personal-weight-tolerance", type=str, default="")
    parser.add_argument("--personal-weight-candidates", type=str, default="")
    parser.add_argument("--manifold-smoothing-weight", type=str, default="")
    parser.add_argument("--manifold-smoothing-policy", type=str, default="")
    parser.add_argument("--manifold-smoothing-tolerance", type=str, default="")
    parser.add_argument("--manifold-smoothing-candidates", type=str, default="")
    parser.add_argument("--candidate-selector-policy", type=str, default="")
    parser.add_argument("--candidate-selector-scope", type=str, default="")
    parser.add_argument("--candidate-selector-loss-tolerance", type=str, default="")
    parser.add_argument("--candidate-selector-loss-tolerance-ratio", type=str, default="")
    parser.add_argument("--candidate-selector-neighbor-weight", type=str, default="")
    parser.add_argument("--adapter-bank-routing", type=str, default="")
    parser.add_argument("--adapter-bank-prior-weight", type=str, default="")
    parser.add_argument("--adapter-bank-k", type=str, default="")
    parser.add_argument("--tau", type=str, default="")
    parser.add_argument("--adapter-graph-mix-weight", type=str, default="")
    parser.add_argument("--adapter-graph-mix-policy", type=str, default="")
    parser.add_argument("--adapter-graph-mix-tolerance", type=str, default="")
    parser.add_argument("--adapter-graph-mix-candidates", type=str, default="")
    parser.add_argument("--adapter-graph-distance", type=str, default="")
    parser.add_argument("--adapter-graph-compatibility", type=str, default="")
    parser.add_argument("--continue-on-failed-diagnostic", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    output_root = ensure_dir(args.output_root)
    modes = _parse_list(args.graph_modes)
    invalid = [mode for mode in modes if mode not in GRAPH_MODES]
    if invalid:
        raise ValueError(f"Unknown graph mode(s): {', '.join(invalid)}")
    self_weights = [float(value) for value in _parse_list(args.self_weights)]

    run_rows = []
    summary_rows = []
    for self_weight in self_weights:
        for mode in modes:
            label = f"{mode}_selfw_{self_weight:g}".replace(".", "p")
            run_dir = output_root / label
            multiseed_args = [
                "--config",
                args.config,
                "--output-root",
                str(run_dir),
                "--seeds",
                args.seeds,
                "--round-id",
                str(args.round_id),
                "--adapter-graph-mode",
                mode,
                "--adapter-graph-self-weight",
                str(self_weight),
            ]
            if args.cpu_debug:
                multiseed_args.append("--cpu-debug")
            if args.no_cpu_debug:
                multiseed_args.append("--no-cpu-debug")
            for cli_name, value in [
                ("--data-root", args.data_root),
                ("--domains", args.domains),
                ("--geometry-outputs-map", args.geometry_outputs_map),
                ("--geometry-outputs-dir", args.geometry_outputs_dir),
                ("--rounds", args.rounds),
                ("--local-epochs", args.local_epochs),
                ("--train-per-client", args.train_per_client),
                ("--test-per-client", args.test_per_client),
                ("--feature-backbone", args.feature_backbone),
                ("--feature-cache-dir", args.feature_cache_dir),
                ("--device", args.device),
                ("--shared-weight", args.shared_weight),
                ("--shared-weight-policy", args.shared_weight_policy),
                ("--shared-weight-tolerance", args.shared_weight_tolerance),
                ("--shared-weight-candidates", args.shared_weight_candidates),
                ("--personal-weight-policy", args.personal_weight_policy),
                ("--personal-weight", args.personal_weight),
                ("--personal-weight-tolerance", args.personal_weight_tolerance),
                ("--personal-weight-candidates", args.personal_weight_candidates),
                ("--manifold-smoothing-weight", args.manifold_smoothing_weight),
                ("--manifold-smoothing-policy", args.manifold_smoothing_policy),
                ("--manifold-smoothing-tolerance", args.manifold_smoothing_tolerance),
                ("--manifold-smoothing-candidates", args.manifold_smoothing_candidates),
                ("--candidate-selector-policy", args.candidate_selector_policy),
                ("--candidate-selector-scope", args.candidate_selector_scope),
                ("--candidate-selector-loss-tolerance", args.candidate_selector_loss_tolerance),
                (
                    "--candidate-selector-loss-tolerance-ratio",
                    args.candidate_selector_loss_tolerance_ratio,
                ),
                ("--candidate-selector-neighbor-weight", args.candidate_selector_neighbor_weight),
                ("--adapter-bank-routing", args.adapter_bank_routing),
                ("--adapter-bank-prior-weight", args.adapter_bank_prior_weight),
                ("--adapter-bank-k", args.adapter_bank_k),
                ("--tau", args.tau),
                ("--adapter-graph-mix-weight", args.adapter_graph_mix_weight),
                ("--adapter-graph-mix-policy", args.adapter_graph_mix_policy),
                ("--adapter-graph-mix-tolerance", args.adapter_graph_mix_tolerance),
                ("--adapter-graph-mix-candidates", args.adapter_graph_mix_candidates),
                ("--adapter-graph-distance", args.adapter_graph_distance),
                ("--adapter-graph-compatibility", args.adapter_graph_compatibility),
            ]:
                if value != "":
                    multiseed_args.extend([cli_name, value])
            if args.continue_on_failed_diagnostic:
                multiseed_args.append("--continue-on-failed-diagnostic")

            exit_code = run_multiseed(multiseed_args)
            run_rows.append(
                {
                    "graph_mode": mode,
                    "adapter_graph_self_weight": self_weight,
                    "label": label,
                    "exit_code": exit_code,
                    "output_dir": str(run_dir),
                }
            )
            summary_rows.append(_summarize_run(mode, self_weight, label, run_dir, exit_code))

    write_csv(output_root / "graph_active_runs.csv", run_rows)
    write_csv(output_root / "graph_active_summary.csv", summary_rows)
    return 0


def _summarize_run(mode: str, self_weight: float, label: str, run_dir: Path, exit_code: int) -> dict:
    claims = {row.get("claim_id", ""): row for row in _read_csv(run_dir / "multiseed_claim_report.csv")}
    metrics = {
        (row.get("test", ""), row.get("method", ""), row.get("baseline", ""), row.get("measure", "")): row
        for row in _read_csv(run_dir / "multiseed_summary.csv")
    }
    return {
        "graph_mode": mode,
        "adapter_graph_self_weight": self_weight,
        "label": label,
        "exit_code": exit_code,
        "overall_core_support": claims.get("overall_core_support", {}).get("supports", ""),
        "secondary_caveats": claims.get("overall_core_support", {}).get("secondary_caveats", ""),
        "fedadapter_accuracy": _metric(metrics, "method_accuracy", "FedAdapterManifold", "", "mean_accuracy"),
        "fedadapter_client_route_accuracy": _metric(
            metrics, "method_accuracy", "FedAdapterManifold-ClientRoute", "", "mean_accuracy"
        ),
        "gain_vs_fedgeo_agg": _claim(claims, "adapter_bank_gain_vs_fedgeo_agg", "estimate"),
        "gain_vs_fedgeo_agg_supports": _claim(claims, "adapter_bank_gain_vs_fedgeo_agg", "supports"),
        "worst_risk_reduction_vs_fedgeo_agg": _claim(
            claims, "worst_client_risk_reduction_vs_fedgeo_agg", "estimate"
        ),
        "update_conflict_reduction_vs_fedgeo_agg": _claim(
            claims, "update_conflict_reduction_vs_fedgeo_agg", "estimate"
        ),
        "client_drift_reduction_vs_fedgeo_agg": _claim(claims, "client_drift_reduction_vs_fedgeo_agg", "estimate"),
        "adapter_incompatibility_r": _claim(claims, "adapter_incompatibility_failure_correlation", "estimate"),
        "output_dir": str(run_dir),
    }


def _metric(metrics: dict[tuple[str, str, str, str], dict], test: str, method: str, baseline: str, measure: str) -> str:
    return metrics.get((test, method, baseline, measure), {}).get("estimate", "")


def _claim(claims: dict[str, dict], claim_id: str, key: str) -> str:
    return claims.get(claim_id, {}).get(key, "")


def _parse_list(value: str) -> list[str]:
    return [part.strip() for part in str(value).split(",") if part.strip()]


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


if __name__ == "__main__":
    raise SystemExit(main())
