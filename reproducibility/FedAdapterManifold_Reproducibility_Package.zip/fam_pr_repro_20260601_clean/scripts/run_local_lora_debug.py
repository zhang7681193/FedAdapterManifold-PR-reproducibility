from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.baselines import run_local_lora, summarize_method
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.reporting import ensure_dir, write_csv


def main() -> int:
    output_dir = ensure_dir("results/fedadaptermanifold_step2")
    clients, base_weight = make_synthetic_manifold_clients(
        num_clients=4,
        num_classes=7,
        feature_dim=48,
        train_per_client=240,
        test_per_client=160,
        rank=4,
        seed=0,
    )
    result = run_local_lora(
        clients,
        base_weight,
        ranks=[4, 4, 4, 4],
        epochs=54,
        lr=0.45,
        batch_size=32,
        seed=0,
        dataset="pacs-debug",
        heterogeneity_setting="domain-adapter-manifold-debug",
        round_id=3,
    )
    write_csv(output_dir / "metrics.csv", summarize_method(result.per_client_metrics))
    write_csv(output_dir / "per_client_metrics.csv", result.per_client_metrics)
    write_csv(output_dir / "local_lora_training_summary.csv", result.training_summary)
    write_csv(output_dir / "local_lora_training_trace.csv", result.training_trace)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
