from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.reporting import ensure_dir, write_csv
from fedadaptermanifold.training import train_lora_adapter


def main() -> int:
    output_dir = ensure_dir("results/fedadaptermanifold_step1")
    clients, base_weight = make_synthetic_manifold_clients(
        num_clients=4,
        num_classes=7,
        feature_dim=48,
        train_per_client=240,
        test_per_client=160,
        rank=4,
        seed=0,
    )
    rows = []
    trace_rows = []
    for idx, client in enumerate(clients):
        adapter, stats = train_lora_adapter(
            client.x_train,
            client.y_train,
            base_weight,
            rank=4,
            epochs=18,
            lr=0.45,
            batch_size=32,
            seed=0,
            name=f"step1_{client.client_id}",
        )
        rows.append(
            {
                "client_id": client.client_id,
                "domain": client.domain,
                "rank": adapter.rank,
                "initial_loss": stats.initial_loss,
                "final_loss": stats.loss,
                "initial_accuracy": stats.initial_accuracy,
                "final_accuracy": stats.accuracy,
                "delta_fro_norm": float((adapter.delta() ** 2).sum() ** 0.5),
            }
        )
        for epoch, (loss, acc) in enumerate(zip(stats.loss_history or [], stats.accuracy_history or [])):
            trace_rows.append(
                {
                    "client_id": client.client_id,
                    "domain": client.domain,
                    "epoch": epoch,
                    "loss": loss,
                    "accuracy": acc,
                }
            )
    write_csv(output_dir / "lora_training_summary.csv", rows)
    write_csv(output_dir / "lora_training_trace.csv", trace_rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
