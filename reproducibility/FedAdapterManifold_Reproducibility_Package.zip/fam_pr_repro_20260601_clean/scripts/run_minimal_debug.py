from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.run_experiment import main


if __name__ == "__main__":
    raise SystemExit(
        main(
            [
                "--dataset",
                "synthetic",
                "--num-clients",
                "4",
                "--rank",
                "4",
                "--rounds",
                "3",
                "--local-epochs",
                "18",
                "--adapter-bank-k",
                "2",
            ]
        )
    )
