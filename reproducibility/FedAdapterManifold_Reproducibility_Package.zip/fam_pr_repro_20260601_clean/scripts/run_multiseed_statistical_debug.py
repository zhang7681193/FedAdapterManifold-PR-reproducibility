from __future__ import annotations

from pathlib import Path
import csv
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv
from fedadaptermanifold.run_experiment import main as run_experiment


DATASETS = [
    ("pacs-debug", "configs/pacs_debug.yaml"),
    ("cifar10-debug", "configs/cifar10_debug.yaml"),
]
SEEDS = [0, 1, 2]


def main() -> int:
    root = ensure_dir("results/fedadaptermanifold_multiseed_stats")
    detail_rows = []
    summary_rows = []
    for dataset_name, config_path in DATASETS:
        dataset_conflicts = []
        dataset_client_rows = []
        for seed in SEEDS:
            output_dir = root / dataset_name / f"seed_{seed}"
            code = run_experiment(
                [
                    "--config",
                    config_path,
                    "--seed",
                    str(seed),
                    "--rank-policy",
                    "fixed",
                    "--adapter-bank-k",
                    "0",
                    "--output-dir",
                    str(output_dir),
                ]
            )
            conflicts = _read_csv(output_dir / "adapter_conflict.csv")
            per_client = _read_csv(output_dir / "per_client_metrics.csv")
            for row in conflicts:
                row["dataset"] = dataset_name
                row["seed"] = seed
            for row in per_client:
                row["dataset"] = dataset_name
                row["seed"] = seed
            dataset_conflicts.extend(conflicts)
            dataset_client_rows.extend(per_client)
            idea = _read_csv(output_dir / "idea_support.csv")
            if idea:
                detail_rows.append({"dataset": dataset_name, "seed": seed, "exit_code": code, **idea[0]})

        summary_rows.extend(_pooled_distance_stats(dataset_name, dataset_conflicts))
        summary_rows.extend(_pooled_gain_stats(dataset_name, dataset_client_rows))

    write_csv(root / "multiseed_idea_support_details.csv", detail_rows)
    write_csv(root / "multiseed_statistical_summary.csv", summary_rows)
    required = [
        row
        for row in summary_rows
        if row["test"] in {"distance_failure_correlation", "paired_accuracy_gain"}
        and row["measure"] in {"d_sub", "d_geo", "FedAdapterManifold_vs_FedAvg-LoRA"}
    ]
    return 0 if all(str(row["supports"]).lower() == "true" for row in required) else 2


def _read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _pooled_distance_stats(dataset_name: str, conflict_rows: list[dict]) -> list[dict]:
    rows = []
    rng = np.random.default_rng(3001)
    y = np.asarray([float(row["aggregation_failure"]) for row in conflict_rows], dtype=np.float64)
    for measure in ["d_sub", "d_update", "d_geo", "d_combined", "d_label"]:
        x = np.asarray([float(row[measure]) for row in conflict_rows], dtype=np.float64)
        estimate = _pearson(x, y)
        low, high = _bootstrap_corr(x, y, rng)
        p_value = _permutation_corr_pvalue(x, y, estimate, rng)
        rows.append(
            {
                "dataset": dataset_name,
                "test": "distance_failure_correlation",
                "measure": measure,
                "comparison": f"{measure}_vs_aggregation_failure",
                "estimate": estimate,
                "ci_low": low,
                "ci_high": high,
                "p_value": p_value,
                "supports": bool(np.isfinite(estimate) and estimate > 0 and np.isfinite(low) and low > 0),
                "num_observations": len(conflict_rows),
            }
        )
    return rows


def _pooled_gain_stats(dataset_name: str, per_client_rows: list[dict]) -> list[dict]:
    rows = []
    rng = np.random.default_rng(4001)
    by_key = {
        (row["method"], row["seed"], row["client_id"]): float(row["accuracy"])
        for row in per_client_rows
    }
    units = sorted({(row["seed"], row["client_id"]) for row in per_client_rows})
    for method in ["Local-LoRA", "Subspace-Compatible", "FedAdapterManifold", "FedAdapterManifold-ClientRoute"]:
        diffs = []
        for seed, client_id in units:
            base_key = ("FedAvg-LoRA", seed, client_id)
            method_key = (method, seed, client_id)
            if base_key in by_key and method_key in by_key:
                diffs.append(by_key[method_key] - by_key[base_key])
        if not diffs:
            continue
        values = np.asarray(diffs, dtype=np.float64)
        estimate = float(values.mean())
        low, high = _bootstrap_mean(values, rng)
        p_value = _sign_flip_pvalue(values)
        rows.append(
            {
                "dataset": dataset_name,
                "test": "paired_accuracy_gain",
                "measure": f"{method}_vs_FedAvg-LoRA",
                "comparison": f"{method}_vs_FedAvg-LoRA",
                "estimate": estimate,
                "ci_low": low,
                "ci_high": high,
                "p_value": p_value,
                "supports": bool(estimate > 0 and low > 0),
                "num_observations": values.size,
            }
        )
    return rows


def _pearson(x, y) -> float:
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    if x.size < 2:
        return float("nan")
    x = x - x.mean()
    y = y - y.mean()
    denom = np.sqrt(np.sum(x * x) * np.sum(y * y))
    if denom <= 1e-12:
        return float("nan")
    return float(np.sum(x * y) / denom)


def _bootstrap_corr(x, y, rng, n_boot=1000):
    values = []
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    for _ in range(n_boot):
        idx = rng.integers(0, x.size, size=x.size)
        value = _pearson(x[idx], y[idx])
        if np.isfinite(value):
            values.append(value)
    if not values:
        return float("nan"), float("nan")
    values = np.asarray(values, dtype=np.float64)
    return float(np.quantile(values, 0.025)), float(np.quantile(values, 0.975))


def _bootstrap_mean(values, rng, n_boot=1000):
    values = np.asarray(values, dtype=np.float64)
    means = []
    for _ in range(n_boot):
        idx = rng.integers(0, values.size, size=values.size)
        means.append(float(values[idx].mean()))
    means = np.asarray(means, dtype=np.float64)
    return float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975))


def _permutation_corr_pvalue(x, y, observed, rng, n_perm=2000):
    if not np.isfinite(observed):
        return float("nan")
    count = 1
    total = 1
    for _ in range(n_perm):
        value = _pearson(x, rng.permutation(y))
        if np.isfinite(value):
            total += 1
            if value >= observed:
                count += 1
    return float(count / total)


def _sign_flip_pvalue(values):
    values = np.asarray(values, dtype=np.float64)
    observed = float(values.mean())
    if values.size > 12:
        rng = np.random.default_rng(5001)
        signs = rng.choice([-1.0, 1.0], size=(4096, values.size))
        means = signs @ values / values.size
        return float((np.sum(means >= observed) + 1) / (means.size + 1))
    count = 0
    total = 2 ** int(values.size)
    for mask in range(total):
        signs = np.array([1.0 if (mask >> i) & 1 else -1.0 for i in range(values.size)])
        if float((signs * values).mean()) >= observed:
            count += 1
    return float(count / total)


if __name__ == "__main__":
    raise SystemExit(main())
