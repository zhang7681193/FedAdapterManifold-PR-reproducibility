from __future__ import annotations

from pathlib import Path
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.run_experiment import main as run_experiment
from fedadaptermanifold.reporting import ensure_dir, write_csv


def _read_metrics(path: Path) -> dict[str, dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return {row["method"]: row for row in csv.DictReader(handle)}


def main() -> int:
    root = ensure_dir("results/fedadaptermanifold_step7")
    rows = []
    all_supported = True
    policies = ["fixed", "random", "novelty-aware", "conflict-aware"]
    for policy in policies:
        output_dir = root / policy
        code = run_experiment(
            [
                "--config",
                "configs/pacs_debug.yaml",
                "--rank-policy",
                policy,
                "--min-rank",
                "2",
                "--max-rank",
                "8",
                "--output-dir",
                str(output_dir),
            ]
        )
        metrics = _read_metrics(output_dir / "metrics.csv")
        local_acc = float(metrics["Local-LoRA"]["mean_accuracy"])
        fedavg_acc = float(metrics["FedAvg-LoRA"]["mean_accuracy"])
        bank_acc = float(metrics.get("FedAdapterManifold", {"mean_accuracy": "nan"})["mean_accuracy"])
        r_value = float(metrics["FedAvg-LoRA"]["subspace_failure_pearson_r"])
        supports = code == 0 and local_acc > fedavg_acc and bank_acc > fedavg_acc and r_value >= 0.05
        all_supported = all_supported and supports
        rows.append(
            {
                "rank_policy": policy,
                "supports_idea": supports,
                "subspace_failure_pearson_r": r_value,
                "local_accuracy": local_acc,
                "fedavg_lora_accuracy": fedavg_acc,
                "adapter_bank_accuracy": bank_acc,
                "local_minus_fedavg_lora": local_acc - fedavg_acc,
                "adapter_bank_minus_fedavg_lora": bank_acc - fedavg_acc,
                "output_dir": str(output_dir),
            }
        )
    write_csv(root / "rank_heterogeneity_summary.csv", rows)
    return 0 if all_supported else 2


if __name__ == "__main__":
    raise SystemExit(main())
