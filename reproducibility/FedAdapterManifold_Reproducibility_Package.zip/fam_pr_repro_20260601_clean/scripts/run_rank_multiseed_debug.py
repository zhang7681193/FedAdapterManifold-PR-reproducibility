from __future__ import annotations

from pathlib import Path
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv
from fedadaptermanifold.run_experiment import main as run_experiment


POLICIES = ["fixed", "random", "novelty-aware", "conflict-aware"]
SEEDS = [0, 1, 2]


def _read_metrics(path: Path) -> dict[str, dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return {row["method"]: row for row in csv.DictReader(handle)}


def _supports(metrics: dict[str, dict], code: int) -> tuple[bool, dict]:
    local_acc = float(metrics["Local-LoRA"]["mean_accuracy"])
    fedavg_acc = float(metrics["FedAvg-LoRA"]["mean_accuracy"])
    subspace_acc = float(metrics.get("Subspace-Compatible", {"mean_accuracy": "nan"})["mean_accuracy"])
    bank_acc = float(metrics.get("FedAdapterManifold", {"mean_accuracy": "nan"})["mean_accuracy"])
    r_value = float(metrics["FedAvg-LoRA"]["subspace_failure_pearson_r"])
    supports = (
        code == 0
        and r_value >= 0.05
        and local_acc > fedavg_acc
        and subspace_acc > fedavg_acc
        and bank_acc > fedavg_acc
    )
    return supports, {
        "subspace_failure_pearson_r": r_value,
        "local_accuracy": local_acc,
        "fedavg_lora_accuracy": fedavg_acc,
        "subspace_compatible_accuracy": subspace_acc,
        "adapter_bank_accuracy": bank_acc,
        "local_minus_fedavg_lora": local_acc - fedavg_acc,
        "subspace_minus_fedavg_lora": subspace_acc - fedavg_acc,
        "adapter_bank_minus_fedavg_lora": bank_acc - fedavg_acc,
    }


def main() -> int:
    root = ensure_dir("results/fedadaptermanifold_step8_multiseed")
    detail_rows = []
    for seed in SEEDS:
        for policy in POLICIES:
            output_dir = root / f"seed_{seed}" / policy
            code = run_experiment(
                [
                    "--config",
                    "configs/pacs_debug.yaml",
                    "--seed",
                    str(seed),
                    "--rank-policy",
                    policy,
                    "--min-rank",
                    "2",
                    "--max-rank",
                    "8",
                    "--output-dir",
                    str(output_dir),
                ]
            )
            metrics = _read_metrics(output_dir / "metrics.csv")
            supports, values = _supports(metrics, code)
            detail_rows.append(
                {
                    "seed": seed,
                    "rank_policy": policy,
                    "supports_idea": supports,
                    "exit_code": code,
                    "output_dir": str(output_dir),
                    **values,
                }
            )

    summary_rows = []
    for policy in POLICIES:
        rows = [row for row in detail_rows if row["rank_policy"] == policy]
        support_count = sum(1 for row in rows if row["supports_idea"])
        summary_rows.append(
            {
                "rank_policy": policy,
                "support_count": support_count,
                "total_runs": len(rows),
                "support_rate": support_count / len(rows),
                "mean_subspace_failure_pearson_r": sum(float(row["subspace_failure_pearson_r"]) for row in rows) / len(rows),
                "mean_local_minus_fedavg_lora": sum(float(row["local_minus_fedavg_lora"]) for row in rows) / len(rows),
                "mean_subspace_minus_fedavg_lora": sum(float(row["subspace_minus_fedavg_lora"]) for row in rows) / len(rows),
                "mean_adapter_bank_minus_fedavg_lora": sum(float(row["adapter_bank_minus_fedavg_lora"]) for row in rows) / len(rows),
            }
        )

    write_csv(root / "rank_multiseed_details.csv", detail_rows)
    write_csv(root / "rank_multiseed_summary.csv", summary_rows)
    return 0 if all(row["support_rate"] >= 2 / 3 for row in summary_rows) else 2


if __name__ == "__main__":
    raise SystemExit(main())
