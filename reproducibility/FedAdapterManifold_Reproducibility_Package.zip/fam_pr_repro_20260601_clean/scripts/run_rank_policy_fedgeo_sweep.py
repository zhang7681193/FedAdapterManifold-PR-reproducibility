from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv
from scripts.run_fedgeo_multiseed import main as run_fedgeo_multiseed


DEFAULT_POLICIES = ["fixed", "random", "novelty-aware", "conflict-aware"]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Sweep rank allocation policies over FedGeo-backed multiseed runs.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--geometry-outputs-map", required=True)
    parser.add_argument("--data-root", default="")
    parser.add_argument("--feature-backbone", default="")
    parser.add_argument("--feature-cache-dir", default="")
    parser.add_argument("--device", default="")
    parser.add_argument("--no-cpu-debug", action="store_true")
    parser.add_argument("--rounds", default="")
    parser.add_argument("--local-epochs", default="")
    parser.add_argument("--seeds", default="0,1,2")
    parser.add_argument("--round-id", default="0")
    parser.add_argument("--policies", default=",".join(DEFAULT_POLICIES))
    parser.add_argument("--rank", default="4")
    parser.add_argument("--min-rank", default="2")
    parser.add_argument("--max-rank", default="8")
    parser.add_argument("--adapter-bank-k", default="")
    parser.add_argument("--personal-weight", default="")
    parser.add_argument("--personal-weight-policy", default="")
    parser.add_argument("--personal-weight-candidates", default="")
    parser.add_argument("--personal-weight-tolerance", default="")
    parser.add_argument("--manifold-smoothing-policy", default="")
    parser.add_argument("--manifold-smoothing-candidates", default="")
    parser.add_argument("--manifold-smoothing-tolerance", default="")
    parser.add_argument("--continue-on-failed-diagnostic", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    output_root = ensure_dir(args.output_root)
    detail_rows: list[dict] = []
    summary_rows: list[dict] = []
    any_failed = False

    for policy in _parse_csv(args.policies):
        policy_dir = output_root / policy
        run_args = [
            "--config",
            args.config,
            "--output-root",
            str(policy_dir),
            "--geometry-outputs-map",
            args.geometry_outputs_map,
            "--seeds",
            args.seeds,
            "--round-id",
            str(args.round_id),
            "--rank-policy",
            policy,
            "--rank",
            str(args.rank),
            "--min-rank",
            str(args.min_rank),
            "--max-rank",
            str(args.max_rank),
        ]
        if args.data_root:
            run_args.extend(["--data-root", args.data_root])
        for cli_name, value in [
            ("--feature-backbone", args.feature_backbone),
            ("--feature-cache-dir", args.feature_cache_dir),
            ("--device", args.device),
            ("--rounds", args.rounds),
            ("--local-epochs", args.local_epochs),
            ("--adapter-bank-k", args.adapter_bank_k),
            ("--personal-weight", args.personal_weight),
            ("--personal-weight-policy", args.personal_weight_policy),
            ("--personal-weight-candidates", args.personal_weight_candidates),
            ("--personal-weight-tolerance", args.personal_weight_tolerance),
            ("--manifold-smoothing-policy", args.manifold_smoothing_policy),
            ("--manifold-smoothing-candidates", args.manifold_smoothing_candidates),
            ("--manifold-smoothing-tolerance", args.manifold_smoothing_tolerance),
        ]:
            if value != "":
                run_args.extend([cli_name, str(value)])
        if args.no_cpu_debug:
            run_args.append("--no-cpu-debug")
        if args.continue_on_failed_diagnostic:
            run_args.append("--continue-on-failed-diagnostic")
        code = run_fedgeo_multiseed(run_args)
        if code != 0:
            any_failed = True

        detail = _policy_detail_rows(policy, policy_dir, code)
        detail_rows.extend(detail)
        summary_rows.append(_policy_summary_row(policy, policy_dir, code, detail))

    write_csv(output_root / "rank_policy_details.csv", detail_rows)
    write_csv(output_root / "rank_policy_summary.csv", summary_rows)
    return 2 if any_failed else 0


def _policy_detail_rows(policy: str, policy_dir: Path, exit_code: int) -> list[dict]:
    rows = []
    metrics = _read_csv(policy_dir / "multiseed_summary.csv")
    claims = _read_csv(policy_dir / "multiseed_claim_report.csv")
    rank_rows = []
    for seed_dir in sorted(policy_dir.glob("seed_*")):
        for row in _read_csv(seed_dir / "rank_allocation.csv"):
            row["source_seed"] = seed_dir.name.replace("seed_", "", 1)
            rank_rows.append(row)

    base = {
        "rank_policy": policy,
        "exit_code": exit_code,
        "overall_core_support": claims[0].get("supports", "") if claims else "",
        "secondary_caveats": claims[0].get("secondary_caveats", "") if claims else "",
        "output_dir": str(policy_dir),
    }
    for row in metrics:
        if row.get("test") in {"method_accuracy", "paired_accuracy_gain", "paired_risk_reduction", "distance_failure_correlation"}:
            rows.append({**base, **row})
    for row in rank_rows:
        rows.append(
            {
                **base,
                "test": "rank_allocation",
                "method": "",
                "baseline": "",
                "measure": "rank",
                "estimate": row.get("rank", ""),
                "source_seed": row.get("source_seed", ""),
                "client_id": row.get("client_id", ""),
                "effective_rank_policy": row.get("effective_rank_policy", ""),
                "novelty": row.get("novelty", ""),
                "coverage": row.get("coverage", ""),
                "conflict_probe": row.get("conflict_probe", ""),
                "conflict_probe_r": row.get("conflict_probe_r", ""),
                "conflict_probe_passed": row.get("conflict_probe_passed", ""),
                "fallback_reason": row.get("fallback_reason", ""),
            }
        )
    return rows


def _policy_summary_row(policy: str, policy_dir: Path, exit_code: int, detail: list[dict]) -> dict:
    def metric(test: str, measure: str, method: str = "", baseline: str = "") -> dict:
        for row in detail:
            if row.get("test") != test or row.get("measure") != measure:
                continue
            if method and row.get("method") != method:
                continue
            if baseline and row.get("baseline") != baseline:
                continue
            return row
        return {}

    rank_values = [float(row["estimate"]) for row in detail if row.get("test") == "rank_allocation" and row.get("estimate") != ""]
    effective = sorted({row.get("effective_rank_policy", "") for row in detail if row.get("test") == "rank_allocation"})
    ranks = np.asarray(rank_values, dtype=np.float64) if rank_values else np.asarray([], dtype=np.float64)
    claims = _read_csv(policy_dir / "multiseed_claim_report.csv")
    return {
        "rank_policy": policy,
        "exit_code": exit_code,
        "overall_core_support": claims[0].get("supports", "") if claims else "",
        "secondary_caveats": claims[0].get("secondary_caveats", "") if claims else "",
        "fedadapter_accuracy": metric("method_accuracy", "mean_accuracy", method="FedAdapterManifold").get("estimate", ""),
        "fedavg_accuracy": metric("method_accuracy", "mean_accuracy", method="FedAvg-LoRA").get("estimate", ""),
        "fedgeo_agg_accuracy": metric("method_accuracy", "mean_accuracy", method="FedGeo-Agg").get("estimate", ""),
        "gain_vs_fedavg": metric("paired_accuracy_gain", "mean_accuracy_gain", method="FedAdapterManifold", baseline="FedAvg-LoRA").get("estimate", ""),
        "gain_vs_fedavg_ci_low": metric("paired_accuracy_gain", "mean_accuracy_gain", method="FedAdapterManifold", baseline="FedAvg-LoRA").get("ci_low", ""),
        "gain_vs_fedgeo_agg": metric("paired_accuracy_gain", "mean_accuracy_gain", method="FedAdapterManifold", baseline="FedGeo-Agg").get("estimate", ""),
        "gain_vs_fedgeo_agg_ci_low": metric("paired_accuracy_gain", "mean_accuracy_gain", method="FedAdapterManifold", baseline="FedGeo-Agg").get("ci_low", ""),
        "update_conflict_reduction_vs_fedgeo_agg": _claim(claims, "update_conflict_reduction_vs_fedgeo_agg", "estimate")
        or metric("paired_risk_reduction", "mean_update_conflict_vs_local", method="FedAdapterManifold", baseline="FedGeo-Agg").get("estimate", ""),
        "update_conflict_reduction_ci_low": _claim(claims, "update_conflict_reduction_vs_fedgeo_agg", "ci_low")
        or metric("paired_risk_reduction", "mean_update_conflict_vs_local", method="FedAdapterManifold", baseline="FedGeo-Agg").get("ci_low", ""),
        "adapter_incompatibility_failure_r": _claim(claims, "adapter_incompatibility_failure_correlation", "estimate")
        or metric("distance_failure_correlation", "d_adapter_incompatibility").get("estimate", ""),
        "adapter_incompatibility_failure_ci_low": _claim(claims, "adapter_incompatibility_failure_correlation", "ci_low")
        or metric("distance_failure_correlation", "d_adapter_incompatibility").get("ci_low", ""),
        "mean_rank": "" if ranks.size == 0 else float(ranks.mean()),
        "std_rank": "" if ranks.size == 0 else float(ranks.std()),
        "min_rank": "" if ranks.size == 0 else int(ranks.min()),
        "max_rank": "" if ranks.size == 0 else int(ranks.max()),
        "effective_rank_policies": ";".join(effective),
        "output_dir": str(policy_dir),
    }


def _parse_csv(text: str) -> list[str]:
    return [part.strip() for part in str(text).split(",") if part.strip()]


def _claim(rows: list[dict], claim_id: str, field: str) -> str:
    for row in rows:
        if row.get("claim_id", "") == claim_id:
            return row.get(field, "")
    return ""


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


if __name__ == "__main__":
    raise SystemExit(main())
