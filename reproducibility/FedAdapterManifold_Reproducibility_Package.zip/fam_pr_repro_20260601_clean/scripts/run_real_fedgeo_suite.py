from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.config import flatten_config, load_yaml
from fedadaptermanifold.reporting import ensure_dir, write_csv
from scripts.run_fedgeo_multiseed import main as run_multiseed


DEFAULT_CONFIGS = [
    "configs/pacs_image_folder.yaml",
    "configs/office_home_image_folder.yaml",
]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run real image-folder FedAdapterManifold experiments with FedGeo outputs.")
    parser.add_argument("--configs", type=str, default=",".join(DEFAULT_CONFIGS))
    parser.add_argument("--output-root", type=str, default="results/fedadaptermanifold_real_fedgeo_suite")
    parser.add_argument("--seeds", type=str, default="0,1,2")
    parser.add_argument("--round-id", type=int, default=0)
    parser.add_argument(
        "--data-root-template",
        type=str,
        default="",
        help="Optional template, e.g. data/{dataset}. Supports {dataset}, {config}, and {config_stem}.",
    )
    parser.add_argument(
        "--geometry-outputs-template",
        type=str,
        default="",
        help="Optional template, e.g. results/fedgeo/{dataset}/seed_{seed}/geometry_outputs.",
    )
    parser.add_argument("--feature-backbone", type=str, default="")
    parser.add_argument("--device", type=str, default="")
    parser.add_argument("--cpu-debug", action="store_true")
    parser.add_argument("--no-cpu-debug", action="store_true")
    parser.add_argument("--continue-on-failed-diagnostic", action="store_true")
    parser.add_argument("--strict-support-exit", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    root = ensure_dir(args.output_root)
    plans = build_run_plan(args)
    write_csv(root / "real_fedgeo_suite_plan.csv", plans)
    if args.dry_run:
        return 0

    run_rows = []
    summary_rows = []
    claim_rows = []
    failed = False
    for plan in plans:
        if str(plan["ready"]).lower() != "true":
            failed = True
            run_rows.append({**plan, "exit_code": 2})
            continue
        code = run_multiseed(_multiseed_args_from_plan(args, plan))
        failed = failed or code != 0
        run_rows.append({**plan, "exit_code": code})
        for row in _read_csv(Path(plan["output_dir"]) / "multiseed_summary.csv"):
            row["dataset_key"] = plan["dataset_key"]
            row["config"] = plan["config"]
            summary_rows.append(row)
        for row in _read_csv(Path(plan["output_dir"]) / "multiseed_claim_report.csv"):
            row["dataset_key"] = plan["dataset_key"]
            row["config"] = plan["config"]
            claim_rows.append(row)

    write_csv(root / "real_fedgeo_suite_runs.csv", run_rows)
    write_csv(root / "real_fedgeo_suite_summary.csv", summary_rows)
    write_csv(root / "real_fedgeo_suite_claim_report.csv", claim_rows)
    return 2 if failed else 0


def build_run_plan(args: argparse.Namespace) -> list[dict]:
    plans = []
    for config_text in _split_csv(args.configs):
        config_path = Path(config_text)
        config = flatten_config(load_yaml(config_path))
        dataset_key = _dataset_key(config_path, config)
        data_root = _resolve_data_root(config, args.data_root_template, dataset_key, config_path)
        geometry_template = _format_optional_template(args.geometry_outputs_template, dataset_key, config_path)
        output_dir = Path(args.output_root) / dataset_key
        data_exists = bool(data_root) and Path(data_root).exists()
        ready = data_exists
        reason = "" if ready else "missing_data_root"
        plans.append(
            {
                "dataset_key": dataset_key,
                "config": str(config_path),
                "data_root": data_root,
                "data_root_exists": data_exists,
                "geometry_outputs_template": geometry_template,
                "round_id": int(args.round_id),
                "seeds": args.seeds,
                "feature_backbone": args.feature_backbone or config.get("feature_backbone", ""),
                "device": args.device or config.get("device", ""),
                "cpu_debug_override": _cpu_debug_override(args),
                "output_dir": str(output_dir),
                "ready": ready,
                "skip_reason": reason,
            }
        )
    return plans


def _multiseed_args_from_plan(args: argparse.Namespace, plan: dict) -> list[str]:
    out = [
        "--config",
        plan["config"],
        "--output-root",
        plan["output_dir"],
        "--seeds",
        plan["seeds"],
        "--round-id",
        str(plan["round_id"]),
        "--data-root",
        plan["data_root"],
    ]
    if plan.get("geometry_outputs_template"):
        out.extend(["--geometry-outputs-template", plan["geometry_outputs_template"]])
    if args.feature_backbone:
        out.extend(["--feature-backbone", args.feature_backbone])
    if args.device:
        out.extend(["--device", args.device])
    if args.cpu_debug:
        out.append("--cpu-debug")
    if args.no_cpu_debug:
        out.append("--no-cpu-debug")
    if args.continue_on_failed_diagnostic:
        out.append("--continue-on-failed-diagnostic")
    if args.strict_support_exit:
        out.append("--strict-support-exit")
    return out


def _resolve_data_root(config: dict, template: str, dataset_key: str, config_path: Path) -> str:
    if template:
        return _format_template(template, dataset_key, config_path)
    return str(config.get("data_root", ""))


def _format_optional_template(template: str, dataset_key: str, config_path: Path) -> str:
    return _format_template(template, dataset_key, config_path) if template else ""


def _format_template(template: str, dataset_key: str, config_path: Path) -> str:
    return template.format(dataset=dataset_key, config=config_path.name, config_stem=config_path.stem, seed="{seed}", round_id="{round_id}")


def _dataset_key(config_path: Path, config: dict) -> str:
    heterogeneity = str(config.get("heterogeneity_setting", "")).replace("_", "-")
    if heterogeneity:
        for suffix in ["-domain-split", "-site-or-modality-split"]:
            heterogeneity = heterogeneity.replace(suffix, "")
        return heterogeneity
    return config_path.stem.replace("_image_folder", "").replace("_", "-")


def _cpu_debug_override(args: argparse.Namespace) -> str:
    if args.cpu_debug:
        return "true"
    if args.no_cpu_debug:
        return "false"
    return ""


def _split_csv(text: str) -> list[str]:
    return [part.strip() for part in str(text).split(",") if part.strip()]


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


if __name__ == "__main__":
    raise SystemExit(main())
