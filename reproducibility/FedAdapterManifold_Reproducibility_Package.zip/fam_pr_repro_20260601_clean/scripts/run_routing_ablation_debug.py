from __future__ import annotations

from pathlib import Path
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv
from fedadaptermanifold.run_experiment import main as run_experiment


SEEDS = [0, 1, 2]
ROUTING_SETTINGS = [
    {
        "name": "client",
        "args": ["--adapter-bank-routing", "client"],
    },
    {
        "name": "feature",
        "args": ["--adapter-bank-routing", "feature", "--route-tau", "0.05"],
    },
    {
        "name": "feature-prior-w010",
        "args": [
            "--adapter-bank-routing",
            "feature-prior",
            "--route-tau",
            "0.05",
            "--adapter-bank-prior-weight",
            "0.10",
        ],
    },
    {
        "name": "feature-prior-w050",
        "args": [
            "--adapter-bank-routing",
            "feature-prior",
            "--route-tau",
            "0.05",
            "--adapter-bank-prior-weight",
            "0.50",
        ],
    },
]


def _read_csv_by_key(path: Path, key: str) -> dict[str, dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return {row[key]: row for row in csv.DictReader(handle)}


def _read_first_csv_row(path: Path) -> dict:
    with path.open("r", newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    return rows[0] if rows else {}


def main() -> int:
    root = ensure_dir("results/fedadaptermanifold_routing_ablation")
    detail_rows = []
    for seed in SEEDS:
        for setting in ROUTING_SETTINGS:
            output_dir = root / f"seed_{seed}" / setting["name"]
            code = run_experiment(
                [
                    "--config",
                    "configs/pacs_debug.yaml",
                    "--seed",
                    str(seed),
                    "--rank-policy",
                    "fixed",
                    "--output-dir",
                    str(output_dir),
                    *setting["args"],
                ]
            )
            metrics = _read_csv_by_key(output_dir / "metrics.csv", "method")
            support = _read_first_csv_row(output_dir / "idea_support.csv")
            bank = metrics["FedAdapterManifold"]
            fedavg = metrics["FedAvg-LoRA"]
            local = metrics["Local-LoRA"]
            detail_rows.append(
                {
                    "seed": seed,
                    "routing_setting": setting["name"],
                    "supports_idea": support.get("supports_idea", code == 0),
                    "exit_code": code,
                    "fedavg_lora_accuracy": fedavg["mean_accuracy"],
                    "local_accuracy": local["mean_accuracy"],
                    "adapter_bank_accuracy": bank["mean_accuracy"],
                    "adapter_bank_minus_fedavg_lora": float(bank["mean_accuracy"]) - float(fedavg["mean_accuracy"]),
                    "subspace_failure_pearson_r": bank["subspace_failure_pearson_r"],
                    "geo_failure_pearson_r": bank.get("geo_failure_pearson_r", ""),
                    "combined_failure_pearson_r": bank.get("combined_failure_pearson_r", ""),
                    "output_dir": str(output_dir),
                }
            )

    summary_rows = []
    for setting in ROUTING_SETTINGS:
        rows = [row for row in detail_rows if row["routing_setting"] == setting["name"]]
        support_count = sum(str(row["supports_idea"]).lower() == "true" for row in rows)
        summary_rows.append(
            {
                "routing_setting": setting["name"],
                "support_count": support_count,
                "total_runs": len(rows),
                "support_rate": support_count / len(rows),
                "mean_adapter_bank_accuracy": _mean(rows, "adapter_bank_accuracy"),
                "mean_adapter_bank_minus_fedavg_lora": _mean(rows, "adapter_bank_minus_fedavg_lora"),
                "mean_subspace_failure_pearson_r": _mean(rows, "subspace_failure_pearson_r"),
                "mean_geo_failure_pearson_r": _mean(rows, "geo_failure_pearson_r"),
            }
        )

    write_csv(root / "routing_ablation_details.csv", detail_rows)
    write_csv(root / "routing_ablation_summary.csv", summary_rows)
    return 0 if all(row["support_rate"] >= 1.0 for row in summary_rows) else 2


def _mean(rows: list[dict], key: str) -> float:
    values = [float(row[key]) for row in rows if row.get(key) not in {"", None}]
    return sum(values) / len(values) if values else float("nan")


if __name__ == "__main__":
    raise SystemExit(main())
