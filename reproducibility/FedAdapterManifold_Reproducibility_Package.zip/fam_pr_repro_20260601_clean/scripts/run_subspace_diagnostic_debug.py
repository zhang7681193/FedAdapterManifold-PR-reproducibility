from __future__ import annotations

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.baselines import run_local_lora
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.diagnostics import run_subspace_failure_diagnostic, write_subspace_diagnostic_artifacts
from fedadaptermanifold.geometry import LocalPrototypeGeometry
from fedadaptermanifold.reporting import ensure_dir, write_csv


def main() -> int:
    output_dir = ensure_dir("results/fedadaptermanifold_step4")
    clients, base_weight = make_synthetic_manifold_clients(
        num_clients=4,
        num_classes=7,
        feature_dim=48,
        train_per_client=240,
        test_per_client=160,
        rank=4,
        seed=0,
    )
    local = run_local_lora(
        clients,
        base_weight,
        ranks=[4, 4, 4, 4],
        epochs=54,
        lr=0.45,
        batch_size=32,
        seed=0,
        dataset="pacs-debug",
        heterogeneity_setting="domain-adapter-manifold-debug",
        round_id=3,
    )
    geometry = LocalPrototypeGeometry().build(clients, num_classes=base_weight.shape[0], round_id=0)
    diagnostic = run_subspace_failure_diagnostic(
        clients,
        base_weight,
        local.adapters,
        d_geo=geometry.d_geo,
        lambda_geo=0.5,
        lambda_label=0.25,
        tau=1.0,
        diagnostic_threshold=0.05,
    )
    write_subspace_diagnostic_artifacts(diagnostic, clients, geometry.d_geo, output_dir)
    write_csv(
        output_dir / "diagnostic_summary.csv",
        [
            {
                "dataset": "pacs-debug",
                "seed": 0,
                "heterogeneity_setting": "domain-adapter-manifold-debug",
                "pearson_r": diagnostic.pearson_r,
                "diagnostic_threshold": 0.05,
                "passed": diagnostic.passed,
                "num_clients": len(clients),
                "num_pairwise_failures": len(diagnostic.conflict_rows),
            }
        ],
    )
    return 0 if diagnostic.passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
