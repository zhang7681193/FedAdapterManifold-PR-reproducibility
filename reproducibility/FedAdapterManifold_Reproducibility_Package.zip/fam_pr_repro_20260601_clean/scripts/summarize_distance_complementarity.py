from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv


MODELS = {
    "subspace_only": ["d_sub"],
    "geo_only": ["d_geo"],
    "label_only": ["d_label"],
    "update_only": ["d_update"],
    "adapter_incompatibility": ["d_adapter_incompatibility"],
    "subspace_plus_geo": ["d_sub", "d_geo"],
    "subspace_plus_label": ["d_sub", "d_label"],
    "geo_plus_label": ["d_geo", "d_label"],
    "raw_combined": ["d_sub", "d_geo", "d_label"],
    "full_distance_set": ["d_sub", "d_geo", "d_label", "d_update"],
}

DELTAS = [
    ("add_geo_to_subspace", "subspace_plus_geo", "subspace_only"),
    ("add_label_to_subspace", "subspace_plus_label", "subspace_only"),
    ("add_subspace_to_geo", "subspace_plus_geo", "geo_only"),
    ("add_label_to_geo", "geo_plus_label", "geo_only"),
    ("raw_combined_vs_best_single", "raw_combined", "best_single"),
    ("adapter_incompatibility_vs_raw_combined", "adapter_incompatibility", "raw_combined"),
]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Summarize complementary distance signals for aggregation failure.")
    parser.add_argument(
        "--run",
        action="append",
        default=[],
        help="Repeated spec: dataset|result_dir",
    )
    parser.add_argument("--output-dir", type=str, default="results/distance_complementarity")
    parser.add_argument("--bootstrap", type=int, default=2000)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    output_dir = ensure_dir(args.output_dir)
    runs = [_parse_run_spec(spec) for spec in args.run]
    if not runs:
        raise ValueError("At least one --run dataset|result_dir is required")

    model_rows: list[dict] = []
    delta_rows: list[dict] = []
    corr_rows: list[dict] = []
    for run in runs:
        rows = _read_csv(Path(run["result_dir"]) / "multiseed_adapter_conflict.csv")
        dataset_model_rows, dataset_delta_rows, dataset_corr_rows = summarize_dataset(
            run["dataset"],
            run["result_dir"],
            rows,
            n_boot=int(args.bootstrap),
        )
        model_rows.extend(dataset_model_rows)
        delta_rows.extend(dataset_delta_rows)
        corr_rows.extend(dataset_corr_rows)

    write_csv(output_dir / "distance_model_r2.csv", model_rows)
    write_csv(output_dir / "distance_model_delta_r2.csv", delta_rows)
    write_csv(output_dir / "distance_signal_correlations.csv", corr_rows)
    return 0


def summarize_dataset(dataset: str, result_dir: str, rows: list[dict], n_boot: int) -> tuple[list[dict], list[dict], list[dict]]:
    y = np.asarray([_to_float(row.get("aggregation_failure", "")) for row in rows], dtype=np.float64)
    values = {
        name: np.asarray([_to_float(row.get(name, "")) for row in rows], dtype=np.float64)
        for name in ["d_sub", "d_geo", "d_label", "d_update", "d_adapter_incompatibility"]
    }
    mask = np.isfinite(y)
    for arr in values.values():
        mask &= np.isfinite(arr)
    y = y[mask]
    values = {name: arr[mask] for name, arr in values.items()}

    model_scores = {}
    model_rows = []
    rng = np.random.default_rng(12031 + sum(ord(ch) for ch in dataset))
    for model_name, predictors in MODELS.items():
        score = _r2(y, _matrix(values, predictors))
        boot = _bootstrap_r2(y, values, predictors, rng, n_boot=n_boot)
        low, high = _quantiles(boot)
        model_scores[model_name] = score
        model_rows.append(
            {
                "dataset": dataset,
                "model": model_name,
                "predictors": ",".join(predictors),
                "r2": score,
                "r2_ci_low": low,
                "r2_ci_high": high,
                "num_pairs": int(y.size),
                "result_dir": result_dir,
            }
        )

    single_names = ["subspace_only", "geo_only", "label_only", "update_only"]
    model_scores["best_single"] = max(model_scores[name] for name in single_names)
    delta_rows = []
    for delta_name, richer, base in DELTAS:
        rich_predictors = MODELS[richer]
        base_predictors = None if base == "best_single" else MODELS[base]
        delta = model_scores[richer] - model_scores[base]
        boot = _bootstrap_delta_r2(
            y,
            values,
            rich_predictors=rich_predictors,
            base_predictors=base_predictors,
            rng=rng,
            n_boot=n_boot,
        )
        low, high = _quantiles(boot)
        delta_rows.append(
            {
                "dataset": dataset,
                "comparison": delta_name,
                "richer_model": richer,
                "base_model": base,
                "delta_r2": delta,
                "delta_r2_ci_low": low,
                "delta_r2_ci_high": high,
                "supports_complementarity": bool(delta > 0 and np.isfinite(low) and low > 0),
                "num_pairs": int(y.size),
                "result_dir": result_dir,
            }
        )

    corr_rows = []
    predictor_names = list(values.keys())
    for i, left in enumerate(predictor_names):
        for right in predictor_names[i + 1 :]:
            corr_rows.append(
                {
                    "dataset": dataset,
                    "left": left,
                    "right": right,
                    "pearson_r": _pearson(values[left], values[right]),
                    "num_pairs": int(y.size),
                    "result_dir": result_dir,
                }
            )
    return model_rows, delta_rows, corr_rows


def _matrix(values: dict[str, np.ndarray], predictors: list[str]) -> np.ndarray:
    return np.column_stack([values[name] for name in predictors])


def _r2(y: np.ndarray, x: np.ndarray) -> float:
    y = np.asarray(y, dtype=np.float64)
    x = np.asarray(x, dtype=np.float64)
    if y.size < 2:
        return float("nan")
    x = _standardize_columns(x)
    design = np.column_stack([np.ones(y.shape[0], dtype=np.float64), x])
    coef, *_ = np.linalg.lstsq(design, y, rcond=None)
    pred = design @ coef
    ss_res = float(np.sum((y - pred) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    if ss_tot <= 1e-12:
        return float("nan")
    return float(max(0.0, 1.0 - ss_res / ss_tot))


def _standardize_columns(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    if x.ndim == 1:
        x = x[:, None]
    return (x - x.mean(axis=0, keepdims=True)) / np.clip(x.std(axis=0, keepdims=True), 1e-12, None)


def _bootstrap_r2(
    y: np.ndarray,
    values: dict[str, np.ndarray],
    predictors: list[str],
    rng: np.random.Generator,
    n_boot: int,
) -> np.ndarray:
    out = []
    n = y.size
    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        x = np.column_stack([values[name][idx] for name in predictors])
        score = _r2(y[idx], x)
        if np.isfinite(score):
            out.append(score)
    return np.asarray(out, dtype=np.float64)


def _bootstrap_delta_r2(
    y: np.ndarray,
    values: dict[str, np.ndarray],
    rich_predictors: list[str],
    base_predictors: list[str] | None,
    rng: np.random.Generator,
    n_boot: int,
) -> np.ndarray:
    out = []
    n = y.size
    single_predictors = [MODELS[name] for name in ["subspace_only", "geo_only", "label_only", "update_only"]]
    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        rich = _r2(y[idx], np.column_stack([values[name][idx] for name in rich_predictors]))
        if base_predictors is None:
            base = max(_r2(y[idx], np.column_stack([values[name][idx] for name in predictors])) for predictors in single_predictors)
        else:
            base = _r2(y[idx], np.column_stack([values[name][idx] for name in base_predictors]))
        if np.isfinite(rich) and np.isfinite(base):
            out.append(rich - base)
    return np.asarray(out, dtype=np.float64)


def _quantiles(values: np.ndarray) -> tuple[float, float]:
    if values.size == 0 or not np.isfinite(values).any():
        return float("nan"), float("nan")
    values = values[np.isfinite(values)]
    return float(np.quantile(values, 0.025)), float(np.quantile(values, 0.975))


def _pearson(x: np.ndarray, y: np.ndarray) -> float:
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    if x.size < 2:
        return float("nan")
    x = x - x.mean()
    y = y - y.mean()
    denom = np.sqrt(np.sum(x * x) * np.sum(y * y))
    if denom <= 1e-12:
        return float("nan")
    return float(np.sum(x * y) / denom)


def _parse_run_spec(spec: str) -> dict:
    parts = str(spec).split("|")
    if len(parts) != 2:
        raise ValueError(f"Invalid --run {spec!r}; expected dataset|result_dir")
    return {"dataset": parts[0].strip(), "result_dir": parts[1].strip()}


def _to_float(value) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


if __name__ == "__main__":
    raise SystemExit(main())
