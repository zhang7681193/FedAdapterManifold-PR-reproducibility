from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, write_csv


DEFAULT_METHOD = "FedAdapterManifold"
BASELINES = ["FedAvg-LoRA", "FedGeo-Agg"]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Summarize FedAdapterManifold mechanism evidence with chance-adjusted "
            "accuracy, local-ceiling recovery, per-client win rates, and conflict diagnostics."
        )
    )
    parser.add_argument(
        "--run",
        action="append",
        default=[],
        help="Repeated run spec: dataset|result_dir|num_classes",
    )
    parser.add_argument("--output-dir", type=str, default="results/fedadaptermanifold_mechanism_validation")
    parser.add_argument("--method", type=str, default=DEFAULT_METHOD)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    output_dir = ensure_dir(args.output_dir)
    runs = [_parse_run_spec(spec) for spec in args.run]
    if not runs:
        raise ValueError("At least one --run dataset|result_dir|num_classes is required")

    summary_rows: list[dict] = []
    win_rows: list[dict] = []
    for run in runs:
        summary, wins = summarize_run(run, method=args.method)
        summary_rows.append(summary)
        win_rows.extend(wins)

    write_csv(output_dir / "mechanism_validation_summary.csv", summary_rows)
    write_csv(output_dir / "mechanism_validation_win_rates.csv", win_rows)
    return 0


def summarize_run(run: dict, method: str) -> tuple[dict, list[dict]]:
    result_dir = Path(run["result_dir"])
    summary = _read_csv(result_dir / "multiseed_summary.csv")
    per_client = _read_csv(result_dir / "multiseed_per_client_metrics.csv")
    claims = _read_csv(result_dir / "multiseed_claim_report.csv")
    risk = _read_csv(result_dir / "multiseed_risk_metrics.csv")

    num_classes = int(run["num_classes"])
    chance = 1.0 / float(num_classes)
    acc = _method_accuracy(summary)
    claim = {row.get("claim_id", ""): row for row in claims}

    local = acc.get("Local-LoRA", float("nan"))
    fedavg = acc.get("FedAvg-LoRA", float("nan"))
    fedgeo = acc.get("FedGeo-Agg", float("nan"))
    current = acc.get(method, float("nan"))

    rows = []
    for baseline in BASELINES:
        rows.append(_win_rate_row(run, per_client, method, baseline))

    local_gap = max(local - chance, 1e-12)
    fedgeo_to_local_gap = max(local - fedgeo, 1e-12)
    fedavg_to_local_gap = max(local - fedavg, 1e-12)
    update_conflict = _claim_float(claim, "update_conflict_reduction_vs_fedgeo_agg", "estimate")
    update_conflict_low = _claim_float(claim, "update_conflict_reduction_vs_fedgeo_agg", "ci_low")

    out = {
        "dataset": run["dataset"],
        "num_classes": num_classes,
        "chance_accuracy": chance,
        "local_lora_accuracy": local,
        "fedavg_lora_accuracy": fedavg,
        "fedgeo_agg_accuracy": fedgeo,
        "fedadapter_accuracy": current,
        "fedadapter_chance_adjusted_accuracy": _chance_adjusted(current, chance),
        "fedavg_chance_adjusted_accuracy": _chance_adjusted(fedavg, chance),
        "fedgeo_agg_chance_adjusted_accuracy": _chance_adjusted(fedgeo, chance),
        "local_ceiling_recovery": (current - chance) / local_gap,
        "fedavg_local_ceiling_recovery": (fedavg - chance) / local_gap,
        "fedgeo_agg_local_ceiling_recovery": (fedgeo - chance) / local_gap,
        "fedavg_to_local_gap_closed": (current - fedavg) / fedavg_to_local_gap,
        "fedgeo_agg_to_local_gap_closed": (current - fedgeo) / fedgeo_to_local_gap,
        "gain_vs_fedavg": _claim_float(claim, "adapter_bank_gain_vs_fedavg", "estimate"),
        "gain_vs_fedavg_ci_low": _claim_float(claim, "adapter_bank_gain_vs_fedavg", "ci_low"),
        "gain_vs_fedgeo_agg": _claim_float(claim, "adapter_bank_gain_vs_fedgeo_agg", "estimate"),
        "gain_vs_fedgeo_agg_ci_low": _claim_float(claim, "adapter_bank_gain_vs_fedgeo_agg", "ci_low"),
        "adapter_incompatibility_failure_r": _claim_float(claim, "adapter_incompatibility_failure_correlation", "estimate"),
        "adapter_incompatibility_failure_ci_low": _claim_float(claim, "adapter_incompatibility_failure_correlation", "ci_low"),
        "raw_subspace_failure_r": _claim_float(claim, "raw_subspace_failure_correlation", "estimate"),
        "d_geo_failure_r": _claim_float(claim, "geometry_failure_correlation", "estimate"),
        "update_conflict_reduction_vs_fedgeo_agg": update_conflict,
        "update_conflict_reduction_ci_low": update_conflict_low,
        "mean_update_conflict_reduction_percent_vs_fedgeo_agg": _risk_reduction_percent(
            risk, method, "FedGeo-Agg", "mean_update_conflict_vs_local"
        ),
        "mean_drift_reduction_percent_vs_fedgeo_agg": _risk_reduction_percent(
            risk, method, "FedGeo-Agg", "mean_client_drift_vs_local"
        ),
        "overall_core_support": claim.get("overall_core_support", {}).get("supports", ""),
        "secondary_caveats": claim.get("overall_core_support", {}).get("secondary_caveats", ""),
        "result_dir": str(result_dir),
    }
    for row in rows:
        baseline = row["baseline"].lower().replace("-", "_")
        out[f"win_rate_vs_{baseline}"] = row["win_rate"]
        out[f"tie_rate_vs_{baseline}"] = row["tie_rate"]
    return out, rows


def _win_rate_row(run: dict, rows: list[dict], method: str, baseline: str) -> dict:
    by_unit: dict[tuple[str, str], dict[str, float]] = {}
    for row in rows:
        unit = (str(row.get("source_seed", row.get("seed", ""))), str(row.get("client_id", "")))
        by_unit.setdefault(unit, {})
        if row.get("accuracy", "") != "":
            by_unit[unit][row.get("method", "")] = float(row["accuracy"])

    wins = 0
    ties = 0
    losses = 0
    diffs = []
    for values in by_unit.values():
        if method not in values or baseline not in values:
            continue
        diff = values[method] - values[baseline]
        diffs.append(diff)
        if diff > 1e-12:
            wins += 1
        elif diff < -1e-12:
            losses += 1
        else:
            ties += 1
    total = wins + ties + losses
    return {
        "dataset": run["dataset"],
        "method": method,
        "baseline": baseline,
        "num_client_seed_units": total,
        "wins": wins,
        "ties": ties,
        "losses": losses,
        "win_rate": wins / total if total else float("nan"),
        "tie_rate": ties / total if total else float("nan"),
        "mean_accuracy_diff": float(np.mean(diffs)) if diffs else float("nan"),
        "min_accuracy_diff": float(np.min(diffs)) if diffs else float("nan"),
        "max_accuracy_diff": float(np.max(diffs)) if diffs else float("nan"),
        "result_dir": run["result_dir"],
    }


def _risk_reduction_percent(rows: list[dict], method: str, baseline: str, measure: str) -> float:
    by_key = {
        (row.get("method", ""), str(row.get("source_seed", row.get("seed", "")))): row
        for row in rows
    }
    reductions = []
    for (row_method, seed), current in by_key.items():
        if row_method != method:
            continue
        base = by_key.get((baseline, seed))
        if base is None:
            continue
        base_value = _to_float(base.get(measure, ""))
        current_value = _to_float(current.get(measure, ""))
        if not np.isfinite(base_value) or not np.isfinite(current_value) or abs(base_value) <= 1e-12:
            continue
        reductions.append((base_value - current_value) / base_value)
    return float(np.mean(reductions)) if reductions else float("nan")


def _method_accuracy(rows: list[dict]) -> dict[str, float]:
    return {
        row["method"]: float(row["estimate"])
        for row in rows
        if row.get("test") == "method_accuracy" and row.get("estimate", "") != ""
    }


def _chance_adjusted(value: float, chance: float) -> float:
    if not np.isfinite(value):
        return float("nan")
    return (value - chance) / max(1.0 - chance, 1e-12)


def _claim_float(claims: dict[str, dict], claim_id: str, field: str) -> float:
    return _to_float(claims.get(claim_id, {}).get(field, ""))


def _to_float(value) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _parse_run_spec(spec: str) -> dict:
    parts = str(spec).split("|")
    if len(parts) != 3:
        raise ValueError(f"Invalid --run spec {spec!r}; expected dataset|result_dir|num_classes")
    dataset, result_dir, num_classes = parts
    return {
        "dataset": dataset.strip(),
        "result_dir": result_dir.strip(),
        "num_classes": int(num_classes),
    }


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


if __name__ == "__main__":
    raise SystemExit(main())
