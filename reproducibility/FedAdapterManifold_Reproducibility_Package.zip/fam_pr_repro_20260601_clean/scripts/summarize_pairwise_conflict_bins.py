from __future__ import annotations

from pathlib import Path
import argparse
import csv
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.reporting import ensure_dir, save_scatter, write_csv


DEFAULT_MEASURES = ["d_adapter_incompatibility", "d_sub", "d_geo", "d_update", "d_label"]


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Bin pairwise distance diagnostics by aggregation failure.")
    parser.add_argument(
        "--run",
        action="append",
        default=[],
        help="Repeated spec: dataset|result_dir",
    )
    parser.add_argument("--output-dir", type=str, default="results/pairwise_conflict_bins")
    parser.add_argument("--num-bins", type=int, default=4)
    parser.add_argument("--measures", type=str, default=",".join(DEFAULT_MEASURES))
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    output_dir = ensure_dir(args.output_dir)
    figures_dir = ensure_dir(output_dir / "figures")
    runs = [_parse_run_spec(spec) for spec in args.run]
    if not runs:
        raise ValueError("At least one --run dataset|result_dir is required")
    measures = [part.strip() for part in args.measures.split(",") if part.strip()]

    bin_rows: list[dict] = []
    gap_rows: list[dict] = []
    for run in runs:
        rows = _read_csv(Path(run["result_dir"]) / "multiseed_adapter_conflict.csv")
        for measure in measures:
            current_bins, current_gap = summarize_measure(
                rows,
                dataset=run["dataset"],
                result_dir=run["result_dir"],
                measure=measure,
                num_bins=args.num_bins,
            )
            bin_rows.extend(current_bins)
            gap_rows.append(current_gap)
            _plot_bins(figures_dir, run["dataset"], measure, current_bins)

    write_csv(output_dir / "pairwise_conflict_bins.csv", bin_rows)
    write_csv(output_dir / "pairwise_conflict_gap_summary.csv", gap_rows)
    return 0


def summarize_measure(
    rows: list[dict],
    dataset: str,
    result_dir: str,
    measure: str,
    num_bins: int,
) -> tuple[list[dict], dict]:
    x = np.asarray([_to_float(row.get(measure, "")) for row in rows], dtype=np.float64)
    y = np.asarray([_to_float(row.get("aggregation_failure", "")) for row in rows], dtype=np.float64)
    train_y = np.asarray([_to_float(row.get("train_aggregation_failure", "")) for row in rows], dtype=np.float64)
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    train_y = train_y[mask]
    if x.size == 0:
        return [], {
            "dataset": dataset,
            "measure": measure,
            "supports_high_conflict_failure": "",
            "reason": "no_valid_rows",
            "result_dir": result_dir,
        }

    order = np.argsort(x)
    bin_indices = np.array_split(order, max(1, min(int(num_bins), x.size)))
    bin_rows = []
    for bin_id, idx in enumerate(bin_indices):
        if idx.size == 0:
            continue
        bin_rows.append(
            {
                "dataset": dataset,
                "measure": measure,
                "bin_id": bin_id,
                "num_pairs": int(idx.size),
                "distance_min": float(np.min(x[idx])),
                "distance_max": float(np.max(x[idx])),
                "distance_mean": float(np.mean(x[idx])),
                "aggregation_failure_mean": float(np.mean(y[idx])),
                "aggregation_failure_std": float(np.std(y[idx])),
                "train_aggregation_failure_mean": float(np.nanmean(train_y[idx])) if np.isfinite(train_y[idx]).any() else "",
                "result_dir": result_dir,
            }
        )

    low = bin_indices[0]
    high = bin_indices[-1]
    diff_values = _bootstrap_top_bottom_diff(y, low, high, seed=9101 + sum(ord(ch) for ch in dataset + measure))
    top_mean = float(np.mean(y[high]))
    bottom_mean = float(np.mean(y[low]))
    gap = top_mean - bottom_mean
    ci_low, ci_high = _quantiles(diff_values)
    gap_row = {
        "dataset": dataset,
        "measure": measure,
        "num_pairs": int(x.size),
        "bottom_bin_failure_mean": bottom_mean,
        "top_bin_failure_mean": top_mean,
        "top_minus_bottom_failure": gap,
        "top_minus_bottom_ci_low": ci_low,
        "top_minus_bottom_ci_high": ci_high,
        "failure_ratio_top_over_bottom": top_mean / max(bottom_mean, 1e-12),
        "supports_high_conflict_failure": bool(gap > 0 and np.isfinite(ci_low) and ci_low > 0),
        "pearson_r": _pearson(x, y),
        "result_dir": result_dir,
    }
    return bin_rows, gap_row


def _plot_bins(figures_dir: Path, dataset: str, measure: str, rows: list[dict]) -> None:
    if not rows:
        return
    x = np.asarray([float(row["distance_mean"]) for row in rows], dtype=np.float64)
    y = np.asarray([float(row["aggregation_failure_mean"]) for row in rows], dtype=np.float64)
    safe_dataset = "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in dataset)
    safe_measure = "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in measure)
    save_scatter(
        x,
        y,
        figures_dir / f"{safe_dataset}_{safe_measure}_failure_bins.png",
        f"{dataset}: {measure} bins vs aggregation failure",
        measure,
        "Mean aggregation failure",
        caption="Each point is an equal-count distance bin.",
    )


def _bootstrap_top_bottom_diff(y: np.ndarray, low_idx: np.ndarray, high_idx: np.ndarray, seed: int, n_boot: int = 2000) -> np.ndarray:
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(n_boot):
        low = rng.choice(low_idx, size=low_idx.size, replace=True)
        high = rng.choice(high_idx, size=high_idx.size, replace=True)
        values.append(float(np.mean(y[high]) - np.mean(y[low])))
    return np.asarray(values, dtype=np.float64)


def _quantiles(values: np.ndarray) -> tuple[float, float]:
    values = np.asarray(values, dtype=np.float64)
    if values.size == 0 or not np.isfinite(values).any():
        return float("nan"), float("nan")
    values = values[np.isfinite(values)]
    return float(np.quantile(values, 0.025)), float(np.quantile(values, 0.975))


def _pearson(x: np.ndarray, y: np.ndarray) -> float:
    if x.size < 2:
        return float("nan")
    x = x - x.mean()
    y = y - y.mean()
    denom = np.sqrt(np.sum(x * x) * np.sum(y * y))
    if denom <= 1e-12:
        return float("nan")
    return float(np.sum(x * y) / denom)


def _parse_run_spec(spec: str) -> dict:
    parts = str(spec).split("|")
    if len(parts) != 2:
        raise ValueError(f"Invalid --run {spec!r}; expected dataset|result_dir")
    return {"dataset": parts[0].strip(), "result_dir": parts[1].strip()}


def _to_float(value) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def _read_csv(path: Path) -> list[dict]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


if __name__ == "__main__":
    raise SystemExit(main())
