from __future__ import annotations

from pathlib import Path
import argparse
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.fedgeo_validation import validate_geometry_outputs
from fedadaptermanifold.reporting import ensure_dir, write_csv


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Validate FedGeo geometry outputs for FedAdapterManifold.")
    parser.add_argument("--geometry-outputs-dir", type=str, required=True)
    parser.add_argument("--round-id", type=int, default=0)
    parser.add_argument("--output-dir", type=str, default="")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_arg_parser().parse_args(argv)
    rows, issues = validate_geometry_outputs(args.geometry_outputs_dir, round_id=args.round_id)
    output_dir = ensure_dir(args.output_dir or Path(args.geometry_outputs_dir) / "validation")
    write_csv(output_dir / "geometry_validation.csv", rows)
    write_csv(output_dir / "geometry_validation_issues.csv", issues)
    errors = [issue for issue in issues if issue.get("severity") == "error"]
    return 0 if not errors else 2


if __name__ == "__main__":
    raise SystemExit(main())
