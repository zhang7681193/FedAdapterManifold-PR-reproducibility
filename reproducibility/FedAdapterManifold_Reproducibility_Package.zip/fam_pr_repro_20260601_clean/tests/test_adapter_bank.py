import unittest

import numpy as np

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.baselines import (
    run_adapter_bank_baseline,
    run_local_lora,
    select_loss_constrained_graph_mix,
    select_loss_constrained_personal_weight,
    select_loss_constrained_smoothing_weights,
    select_train_loss_routing_modes,
)
from fedadaptermanifold.aggregation import k_medoids
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.diagnostics import run_subspace_failure_diagnostic
from fedadaptermanifold.geometry import LocalPrototypeGeometry, cluster_prototypes_from_clients


class AdapterBankBaselineTests(unittest.TestCase):
    def test_adapter_bank_baseline_outputs_metrics_and_routing(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=4,
            num_classes=5,
            feature_dim=20,
            train_per_client=36,
            test_per_client=20,
            rank=2,
            seed=15,
        )
        ranks = [2, 2, 2, 2]
        local = run_local_lora(
            clients,
            base_weight,
            ranks=ranks,
            epochs=4,
            lr=0.25,
            batch_size=12,
            seed=0,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        geometry = LocalPrototypeGeometry().build(clients, num_classes=base_weight.shape[0])
        diagnostic = run_subspace_failure_diagnostic(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            diagnostic_threshold=-1.0,
        )
        combined = diagnostic.d_sub + 0.5 * geometry.d_geo + 0.25 * diagnostic.d_label
        _, assignments = k_medoids(combined, 2)
        cluster_prototypes = cluster_prototypes_from_clients(clients, assignments, base_weight.shape[0])
        result = run_adapter_bank_baseline(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            combined_distance=combined,
            ranks=ranks,
            k=2,
            route_tau=1.0,
            shared_weight=0.25,
            personal_weight=0.10,
            cluster_prototypes=cluster_prototypes,
            routing_mode="feature",
            seed=0,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        self.assertEqual(len(result.client_adapters), 4)
        self.assertEqual(len(result.per_client_metrics), 4)
        self.assertEqual(len(result.routing_rows), 8)
        self.assertEqual(len(result.sample_routing_rows), 16)
        self.assertEqual(result.per_client_metrics[0]["method"], "FedAdapterManifold")
        self.assertEqual(result.per_client_metrics[0]["routing_mode"], "feature")

    def test_adapter_bank_can_blend_smoothing_adapters(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=16,
            train_per_client=30,
            test_per_client=12,
            rank=2,
            seed=21,
        )
        ranks = [2, 2, 2]
        local = run_local_lora(
            clients,
            base_weight,
            ranks=ranks,
            epochs=3,
            lr=0.2,
            batch_size=10,
            seed=1,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        geometry = LocalPrototypeGeometry().build(clients, num_classes=base_weight.shape[0])
        diagnostic = run_subspace_failure_diagnostic(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            diagnostic_threshold=-1.0,
        )
        combined = diagnostic.d_sub + 0.5 * geometry.d_geo
        plain = run_adapter_bank_baseline(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            combined_distance=combined,
            ranks=ranks,
            k=2,
            route_tau=1.0,
            shared_weight=0.25,
            personal_weight=0.10,
            seed=1,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        smoothed = run_adapter_bank_baseline(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            combined_distance=combined,
            ranks=ranks,
            k=2,
            route_tau=1.0,
            shared_weight=0.25,
            personal_weight=0.10,
            smoothing_adapters=local.adapters,
            smoothing_weight=0.5,
            seed=1,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        self.assertEqual(smoothed.bank.smoothing_weight, 0.5)
        self.assertGreater(np.linalg.norm(plain.client_adapters[0].delta() - smoothed.client_adapters[0].delta()), 0.0)

    def test_adapter_bank_cluster_loss_constrained_smoothing_reports_gate(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=16,
            train_per_client=30,
            test_per_client=12,
            rank=2,
            seed=22,
        )
        ranks = [2, 2, 2]
        local = run_local_lora(
            clients,
            base_weight,
            ranks=ranks,
            epochs=3,
            lr=0.2,
            batch_size=10,
            seed=2,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        geometry = LocalPrototypeGeometry().build(clients, num_classes=base_weight.shape[0])
        diagnostic = run_subspace_failure_diagnostic(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            diagnostic_threshold=-1.0,
        )
        combined = diagnostic.d_sub + 0.5 * geometry.d_geo
        result = run_adapter_bank_baseline(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            combined_distance=combined,
            ranks=ranks,
            k=2,
            route_tau=1.0,
            shared_weight=0.35,
            personal_weight=0.15,
            smoothing_adapters=local.adapters,
            smoothing_policy="cluster-loss-constrained",
            smoothing_tolerance=0.01,
            smoothing_candidates="0,0.1",
            seed=2,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        self.assertTrue(all("client_smoothing_weight" in row for row in result.routing_rows))
        self.assertTrue(any(row.get("smoothing_policy") == "cluster-loss-constrained" for row in result.sample_routing_rows))

    def test_adapter_bank_loss_constrained_shared_weight_reports_selection(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=16,
            train_per_client=30,
            test_per_client=12,
            rank=2,
            seed=23,
        )
        ranks = [2, 2, 2]
        local = run_local_lora(
            clients,
            base_weight,
            ranks=ranks,
            epochs=3,
            lr=0.2,
            batch_size=10,
            seed=3,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        geometry = LocalPrototypeGeometry().build(clients, num_classes=base_weight.shape[0])
        diagnostic = run_subspace_failure_diagnostic(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            diagnostic_threshold=-1.0,
        )
        combined = diagnostic.d_sub + 0.5 * geometry.d_geo
        result = run_adapter_bank_baseline(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            combined_distance=combined,
            ranks=ranks,
            k=2,
            route_tau=1.0,
            shared_weight=0.35,
            personal_weight=0.15,
            shared_weight_policy="loss-constrained",
            shared_weight_candidates="0,0.2,0.35",
            shared_weight_tolerance=0.01,
            seed=3,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        self.assertTrue(all(row.get("shared_weight_policy") == "loss-constrained" for row in result.routing_rows))
        self.assertTrue(any("selected_shared_weight" in row for row in result.sample_routing_rows))
        self.assertIn(result.bank.shared_weight, {0.0, 0.2, 0.35})

    def test_adapter_bank_heterogeneity_aware_personal_weight_reports_selection(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=10,
            feature_dim=18,
            train_per_client=20,
            test_per_client=10,
            rank=2,
            seed=24,
        )
        ranks = [2, 2, 2]
        local = run_local_lora(
            clients,
            base_weight,
            ranks=ranks,
            epochs=2,
            lr=0.2,
            batch_size=10,
            seed=4,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        geometry = LocalPrototypeGeometry().build(clients, num_classes=base_weight.shape[0])
        diagnostic = run_subspace_failure_diagnostic(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            diagnostic_threshold=-1.0,
        )
        combined = diagnostic.d_sub + 0.5 * geometry.d_geo
        result = run_adapter_bank_baseline(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            combined_distance=combined,
            ranks=ranks,
            k=2,
            route_tau=1.0,
            shared_weight=0.0,
            personal_weight=0.15,
            personal_weight_policy="heterogeneity-aware",
            personal_weight_candidates="0.15,0.30,0.50,0.70,0.90",
            seed=4,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        self.assertEqual(result.bank.personal_weight, 0.9)
        self.assertTrue(any(row.get("selected_personal_weight") == 0.9 for row in result.sample_routing_rows))
        self.assertTrue(any("personal_heterogeneity_score" in row for row in result.sample_routing_rows))

    def test_dynamic_routing_falls_back_to_client_when_losses_are_close(self):
        class Client:
            def __init__(self, idx):
                self.client_id = f"client_{idx}"
                self.domain = f"domain_{idx}"
                self.x_train = np.ones((2, 3), dtype=np.float64)
                self.y_train = np.zeros(2, dtype=np.int64)

        class Bank:
            cluster_assignments = np.asarray([0, 0])
            medoids = [0]
            routing_prior_weight = 0.1

            def logits_for_client(self, x, base_weight, client_index, mode="client"):
                if client_index == 0:
                    score = 5.0 if mode == "feature-prior" else 1.0
                else:
                    score = 1.02 if mode == "client" else 1.01
                return np.column_stack([np.full(x.shape[0], score), np.zeros(x.shape[0])])

            def routing_for_samples(self, x, client_index, mode="client"):
                if client_index == 0:
                    return np.tile(np.asarray([[0.95, 0.05]], dtype=np.float64), (x.shape[0], 1))
                return np.tile(np.asarray([[0.55, 0.45]], dtype=np.float64), (x.shape[0], 1))

        modes, rows = select_train_loss_routing_modes(
            [Client(0), Client(1)],
            np.zeros((2, 3), dtype=np.float64),
            Bank(),
            tolerance=0.005,
        )
        self.assertEqual(modes, ["feature-prior", "client"])
        self.assertTrue(any(row["selected_routing_mode"] == "client" for row in rows))

    def test_uncertainty_constrained_personal_weight_rejects_marginal_train_gain(self):
        class Client:
            def __init__(self, idx):
                self.client_id = f"client_{idx}"
                self.domain = f"domain_{idx}"
                self.x_train = np.ones((8, 3), dtype=np.float64)
                self.y_train = np.zeros(8, dtype=np.int64)

        class Bank:
            personal_weight = 0.0
            shared_weight = 0.0
            cluster_assignments = np.asarray([0, 0, 0, 0])
            medoids = [0]
            routing_prior_weight = 0.1

            def logits_for_client(self, x, base_weight, client_index, mode="client"):
                base_margin = [-2.5, -0.4, 0.9, 3.0][client_index]
                margin = base_margin + 0.4 * float(self.personal_weight)
                return np.column_stack([np.full(x.shape[0], margin), np.zeros(x.shape[0])])

        selected, rows = select_loss_constrained_personal_weight(
            [Client(idx) for idx in range(4)],
            np.zeros((2, 3), dtype=np.float64),
            Bank(),
            routing_mode="client",
            candidates="0,0.7",
            tolerance=0.0,
            policy="uncertainty-constrained",
        )
        self.assertEqual(selected, 0.0)
        self.assertTrue(any(row["personal_weight_uncertainty_penalty"] > 0.0 for row in rows))

    def test_safe_smoothing_can_fallback_to_fedgeo_endpoint(self):
        class Client:
            def __init__(self, idx):
                self.client_id = f"client_{idx}"
                self.domain = f"domain_{idx}"
                self.x_train = np.ones((8, 3), dtype=np.float64)
                self.y_train = np.zeros(8, dtype=np.int64)

        class Bank:
            smoothing_adapters = [object()]
            smoothing_weights = None
            cluster_assignments = np.asarray([0, 0, 0, 0])
            medoids = [0]
            routing_prior_weight = 0.1

            def logits_for_client(self, x, base_weight, client_index, mode="client"):
                weight = 0.0 if self.smoothing_weights is None else float(self.smoothing_weights[client_index])
                client_gain = [-0.02, -0.02, 0.02, 0.02][client_index]
                margin = 0.5 + weight * client_gain
                return np.column_stack([np.full(x.shape[0], margin), np.zeros(x.shape[0])])

        weights, rows = select_loss_constrained_smoothing_weights(
            [Client(idx) for idx in range(4)],
            np.zeros((2, 3), dtype=np.float64),
            Bank(),
            routing_mode="client",
            candidates="0,1",
            tolerance=0.0,
            policy="safe-loss-constrained",
        )
        self.assertTrue(np.allclose(weights, 1.0))
        self.assertTrue(all(row["safe_smoothing_fallback"] for row in rows))

    def test_safe_cluster_smoothing_fallback_is_cluster_local(self):
        class Client:
            def __init__(self, idx):
                self.client_id = f"client_{idx}"
                self.domain = f"domain_{idx}"
                self.x_train = np.ones((4, 3), dtype=np.float64)
                self.y_train = np.zeros(4, dtype=np.int64)

        class Bank:
            smoothing_adapters = [object()]
            smoothing_weights = None
            cluster_assignments = np.asarray([0, 0, 1, 1])
            medoids = [0, 2]
            routing_prior_weight = 0.1

            def logits_for_client(self, x, base_weight, client_index, mode="client"):
                weight = 0.0 if self.smoothing_weights is None else float(self.smoothing_weights[client_index])
                client_gain = [-0.04, -0.04, 0.04, 0.04][client_index]
                margin = 0.5 + weight * client_gain
                return np.column_stack([np.full(x.shape[0], margin), np.zeros(x.shape[0])])

        weights, rows = select_loss_constrained_smoothing_weights(
            [Client(idx) for idx in range(4)],
            np.zeros((2, 3), dtype=np.float64),
            Bank(),
            routing_mode="client",
            candidates="0,1",
            tolerance=0.0,
            policy="safe-cluster-loss-constrained",
        )
        self.assertTrue(np.allclose(weights, [0.0, 0.0, 1.0, 1.0]))
        fallback_by_client = {
            row["client_id"]: row["safe_smoothing_fallback"]
            for row in rows
            if row.get("selected")
        }
        self.assertEqual(
            fallback_by_client,
            {"client_0": False, "client_1": False, "client_2": True, "client_3": True},
        )

    def test_loss_constrained_graph_mix_can_reject_harmful_neighbor_sharing(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=2,
            num_classes=3,
            feature_dim=10,
            train_per_client=24,
            test_per_client=8,
            rank=2,
            seed=25,
        )
        local = run_local_lora(
            clients,
            base_weight,
            ranks=[2, 2],
            epochs=2,
            lr=0.2,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        harmful = [
            LoRAAdapter.from_delta(-3.0 * adapter.delta(), rank=2, alpha=2.0, name=f"harmful_{idx}")
            for idx, adapter in enumerate(local.adapters)
        ]
        mixed, rows = select_loss_constrained_graph_mix(
            clients,
            base_weight,
            local.adapters,
            harmful,
            ranks=[2, 2],
            candidates="0,1",
            tolerance=0.0,
            policy="loss-constrained",
        )
        self.assertEqual(len(mixed), 2)
        selected = [row for row in rows if row["selected"]]
        self.assertTrue(selected)
        self.assertTrue(all(row["selected_graph_mix_weight"] == 0.0 for row in selected))


if __name__ == "__main__":
    unittest.main()
