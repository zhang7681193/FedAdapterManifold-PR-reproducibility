import unittest

import numpy as np

from fedadaptermanifold.run_experiment import _select_adapter_graph


class AdapterGraphControlTest(unittest.TestCase):
    def test_random_graph_control_preserves_edge_count_and_weights(self):
        graph = np.array(
            [
                [0.0, 0.8, 0.0, 0.3],
                [0.8, 0.0, 0.5, 0.0],
                [0.0, 0.5, 0.0, 0.2],
                [0.3, 0.0, 0.2, 0.0],
            ],
            dtype=np.float64,
        )

        random_a = _select_adapter_graph(graph, "random", seed=7)
        random_b = _select_adapter_graph(graph, "random", seed=7)

        self.assertTrue(np.allclose(random_a, random_b))
        self.assertTrue(np.allclose(random_a, random_a.T))
        self.assertTrue(np.allclose(np.diag(random_a), 0.0))
        original_upper = graph[np.triu_indices(graph.shape[0], k=1)]
        random_upper = random_a[np.triu_indices(random_a.shape[0], k=1)]
        self.assertEqual(np.count_nonzero(original_upper), np.count_nonzero(random_upper))
        self.assertTrue(
            np.allclose(
                np.sort(original_upper[original_upper > 0.0]),
                np.sort(random_upper[random_upper > 0.0]),
            )
        )

    def test_self_and_complete_graph_controls(self):
        graph = np.array([[0.0, 0.4], [0.4, 0.0]], dtype=np.float64)

        self_graph = _select_adapter_graph(graph, "self")
        complete_graph = _select_adapter_graph(graph, "complete")

        self.assertTrue(np.allclose(self_graph, 0.0))
        self.assertTrue(np.allclose(complete_graph, np.array([[0.0, 1.0], [1.0, 0.0]])))


if __name__ == "__main__":
    unittest.main()
