import unittest

import numpy as np

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.aggregation import (
    compatibility_matrix,
    fedavg_lift,
    geo_weighted_aggregate,
    graph_weight_matrix,
    normalize_rows,
    select_adapter_bank_k,
)


class AggregationTests(unittest.TestCase):
    def test_fedavg_lift_matches_weighted_delta_shape(self):
        rng = np.random.default_rng(1)
        a1 = LoRAAdapter.random(5, 4, 2, rng, zero_b=False)
        a2 = LoRAAdapter.random(5, 4, 2, rng, zero_b=False)
        avg = fedavg_lift([a1, a2], weights=np.array([0.25, 0.75]), target_rank=2)
        self.assertEqual(avg.delta().shape, (4, 5))

    def test_compatibility_rows_can_normalize(self):
        d = np.array([[0.0, 1.0], [1.0, 0.0]])
        compat = compatibility_matrix(d, d, d, lambda_geo=0.5, lambda_label=0.5, tau=1.0)
        beta = normalize_rows(compat)
        np.testing.assert_allclose(beta.sum(axis=1), np.ones(2))
        self.assertGreater(beta[0, 0], beta[0, 1])

    def test_select_adapter_bank_k_prefers_two_clear_clusters(self):
        distance = np.array(
            [
                [0.0, 0.1, 3.0, 3.1],
                [0.1, 0.0, 3.2, 3.0],
                [3.0, 3.2, 0.0, 0.2],
                [3.1, 3.0, 0.2, 0.0],
            ]
        )
        selected, rows = select_adapter_bank_k(distance, max_k=4)
        self.assertEqual(selected, 2)
        self.assertTrue(any(row["selected"] for row in rows))

    def test_graph_weight_matrix_respects_adjacency(self):
        graph = np.array([[0.0, 1.0, 0.0], [1.0, 0.0, 1.0], [0.0, 1.0, 0.0]])
        distance = np.array([[0.0, 0.1, 9.0], [0.1, 0.0, 2.0], [9.0, 2.0, 0.0]])
        weights = graph_weight_matrix(graph, distance=distance, tau=1.0, self_weight=1.0)
        np.testing.assert_allclose(weights.sum(axis=1), np.ones(3))
        self.assertEqual(weights[0, 2], 0.0)
        self.assertGreater(weights[0, 0], weights[0, 1])

    def test_graph_weight_self_weight_controls_neighbor_sharing(self):
        graph = np.array([[0.0, 1.0], [1.0, 0.0]])
        distance = np.array([[0.0, 0.1], [0.1, 0.0]])
        conservative = graph_weight_matrix(graph, distance=distance, tau=1.0, self_weight=1.0)
        graph_active = graph_weight_matrix(graph, distance=distance, tau=1.0, self_weight=0.1)
        self.assertGreater(conservative[0, 0], graph_active[0, 0])
        self.assertGreater(graph_active[0, 1], conservative[0, 1])

    def test_geo_weighted_aggregate_returns_client_specific_adapters(self):
        rng = np.random.default_rng(2)
        adapters = [LoRAAdapter.random(5, 4, 2, rng, zero_b=False) for _ in range(3)]
        d_geo = np.array([[0.0, 0.2, 3.0], [0.2, 0.0, 1.0], [3.0, 1.0, 0.0]])
        graph = np.array([[0.0, 1.0, 0.0], [1.0, 0.0, 1.0], [0.0, 1.0, 0.0]])
        mixed = geo_weighted_aggregate(adapters, d_geo=d_geo, graph=graph, target_ranks=[2, 2, 2], tau=1.0)
        self.assertEqual(len(mixed), 3)
        self.assertEqual(mixed[0].delta().shape, adapters[0].delta().shape)


if __name__ == "__main__":
    unittest.main()
