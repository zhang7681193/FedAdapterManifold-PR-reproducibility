import unittest

from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.run_experiment import _split_clients_for_candidate_selection


class CandidateSelectorCalibrationTests(unittest.TestCase):
    def test_zero_fraction_uses_training_split_for_selector(self):
        clients, _ = make_synthetic_manifold_clients(num_clients=2, train_per_client=20, seed=41)
        train_clients, selector_clients, rows = _split_clients_for_candidate_selection(clients, fraction=0.0, seed=0)

        self.assertIs(train_clients, clients)
        self.assertIs(selector_clients, clients)
        self.assertEqual(rows[0]["selector_split"], "train")
        self.assertEqual(rows[0]["calibration_samples_for_selector"], 20)

    def test_positive_fraction_reserves_heldout_selector_subset(self):
        clients, _ = make_synthetic_manifold_clients(num_clients=2, train_per_client=20, seed=42)
        train_clients, selector_clients, rows = _split_clients_for_candidate_selection(clients, fraction=0.25, seed=0)

        self.assertEqual(train_clients[0].x_train.shape[0], 15)
        self.assertEqual(selector_clients[0].x_train.shape[0], 5)
        self.assertEqual(train_clients[0].x_test.shape[0], clients[0].x_test.shape[0])
        self.assertEqual(selector_clients[0].client_id, clients[0].client_id)
        self.assertEqual(rows[0]["selector_split"], "heldout_calibration")


if __name__ == "__main__":
    unittest.main()
