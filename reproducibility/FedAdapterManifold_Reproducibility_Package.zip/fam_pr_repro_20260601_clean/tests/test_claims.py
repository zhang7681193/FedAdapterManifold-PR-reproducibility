import unittest

from fedadaptermanifold.claims import (
    build_multiseed_claim_report,
    build_single_run_claim_report,
    core_claims_supported,
)


class ClaimReportTests(unittest.TestCase):
    def test_multiseed_core_support_ignores_secondary_graph_caveat(self):
        summary = [
            _summary("distance_failure_correlation", "", "", "d_adapter_incompatibility", 0.6, True),
            _summary("distance_failure_correlation", "", "", "d_sub", -0.2, False),
            _summary("distance_failure_correlation", "", "", "d_geo", 0.5, True),
            _summary("paired_accuracy_gain", "FedAdapterManifold", "FedAvg-LoRA", "mean_accuracy_gain", 0.1, True),
            _summary("paired_accuracy_gain", "FedAdapterManifold", "FedGeo-Agg", "mean_accuracy_gain", 0.02, True),
            _summary("paired_risk_reduction", "FedAdapterManifold", "FedAvg-LoRA", "mean_update_conflict_vs_local", 0.30, True),
            _summary("paired_risk_reduction", "FedAdapterManifold", "FedGeo-Agg", "worst_client_risk", 0.03, True),
            _summary("paired_risk_reduction", "FedAdapterManifold", "FedGeo-Agg", "mean_update_conflict_vs_local", -0.04, False),
            _summary("paired_risk_reduction", "FedAdapterManifold", "FedAvg-LoRA", "mean_client_drift_vs_local", 0.08, True),
            _summary("paired_risk_reduction", "FedAdapterManifold", "FedGeo-Agg", "mean_client_drift_vs_local", -0.01, False),
            _summary("paired_risk_reduction", "FedAdapterManifold", "FedGeo-Agg", "mean_graph_neighbor_update_conflict", -0.1, False),
        ]
        report = build_multiseed_claim_report(summary)
        overall = report[0]
        graph = _by_claim(report, "graph_neighbor_conflict_reduction_vs_fedgeo_agg")
        raw_subspace = _by_claim(report, "raw_subspace_failure_correlation")

        self.assertTrue(core_claims_supported(report))
        self.assertTrue(overall["supports"])
        self.assertFalse(raw_subspace["supports"])
        self.assertEqual(raw_subspace["claim_tier"], "secondary_caveat")
        self.assertFalse(raw_subspace["affects_main_theory"])
        self.assertFalse(graph["supports"])
        self.assertEqual(graph["claim_tier"], "secondary_caveat")
        self.assertFalse(graph["affects_main_theory"])

    def test_multiseed_claim_report_prefers_selective_primary_when_present(self):
        summary = [
            _summary("distance_failure_correlation", "", "", "d_adapter_incompatibility", 0.6, True),
            _summary("paired_accuracy_gain", "FedAdapterManifold", "FedAvg-LoRA", "mean_accuracy_gain", -0.01, False),
            _summary("paired_accuracy_gain", "FedAdapterManifold-Selective", "FedAvg-LoRA", "mean_accuracy_gain", 0.03, True),
            _summary("paired_accuracy_gain", "FedAdapterManifold", "FedGeo-Agg", "mean_accuracy_gain", 0.0, False),
            _summary("paired_accuracy_gain", "FedAdapterManifold-Selective", "FedGeo-Agg", "mean_accuracy_gain", 0.02, True),
            _summary("paired_risk_reduction", "FedAdapterManifold", "FedAvg-LoRA", "mean_update_conflict_vs_local", -0.1, False),
            _summary(
                "paired_risk_reduction",
                "FedAdapterManifold-Selective",
                "FedAvg-LoRA",
                "mean_update_conflict_vs_local",
                0.2,
                True,
            ),
        ]
        report = build_multiseed_claim_report(summary)
        gain = _by_claim(report, "adapter_bank_gain_vs_fedavg")
        conflict = _by_claim(report, "update_conflict_reduction_vs_fedavg")

        self.assertEqual(gain["method"], "FedAdapterManifold-Selective")
        self.assertEqual(conflict["method"], "FedAdapterManifold-Selective")
        self.assertTrue(gain["supports"])
        self.assertTrue(conflict["supports"])

    def test_single_run_claim_report_marks_core_failure(self):
        metrics = []
        risk = [
            {"method": "FedGeo-Agg", "worst_client_risk": 0.2, "mean_update_conflict_vs_local": 0.3},
            {"method": "FedAdapterManifold", "worst_client_risk": 0.25, "mean_update_conflict_vs_local": 0.35},
            {"method": "FedAvg-LoRA", "mean_client_drift_vs_local": 0.4, "mean_update_conflict_vs_local": 0.3},
        ]
        idea = [{"adapter_bank_minus_fedavg_lora": 0.1, "adapter_bank_minus_fedgeo_agg": 0.01}]
        statistical = [
            _summary("distance_failure_correlation", "", "", "d_adapter_incompatibility", 0.5, True),
            _summary("distance_failure_correlation", "", "", "d_sub", -0.2, False),
            _summary("distance_failure_correlation", "", "", "d_geo", 0.4, True),
        ]
        report = build_single_run_claim_report(metrics, risk, idea, statistical)
        worst = _by_claim(report, "worst_client_risk_reduction_vs_fedgeo_agg")
        update_fedavg = _by_claim(report, "update_conflict_reduction_vs_fedavg")
        update_fedgeo = _by_claim(report, "update_conflict_reduction_vs_fedgeo_agg")

        self.assertFalse(core_claims_supported(report))
        self.assertFalse(report[0]["supports"])
        self.assertFalse(worst["supports"])
        self.assertEqual(worst["narrative_action"], "report_as_mixed_support")
        self.assertEqual(worst["claim_tier"], "supporting")
        self.assertFalse(update_fedavg["supports"])
        self.assertEqual(update_fedavg["narrative_action"], "revise_or_rerun_core_claim")
        self.assertFalse(update_fedgeo["supports"])
        self.assertEqual(update_fedgeo["narrative_action"], "report_as_caveat")


def _summary(test, method, baseline, measure, estimate, supports):
    return {
        "test": test,
        "method": method,
        "baseline": baseline,
        "measure": measure,
        "estimate": estimate,
        "ci_low": 0.01 if supports else -0.01,
        "ci_high": estimate + 0.01,
        "supports": supports,
        "num_observations": 6,
    }


def _by_claim(rows, claim_id):
    for row in rows:
        if row["claim_id"] == claim_id:
            return row
    raise AssertionError(f"missing claim {claim_id}")


if __name__ == "__main__":
    unittest.main()
