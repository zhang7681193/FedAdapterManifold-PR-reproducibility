import unittest

import numpy as np

from fedadaptermanifold.baselines import run_local_lora
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.diagnostics import run_subspace_failure_diagnostic
from fedadaptermanifold.geometry import LocalPrototypeGeometry


class DiagnosticTests(unittest.TestCase):
    def test_subspace_failure_diagnostic_has_expected_shapes(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=4,
            num_classes=5,
            feature_dim=24,
            train_per_client=48,
            test_per_client=28,
            rank=2,
            seed=6,
        )
        local = run_local_lora(
            clients,
            base_weight,
            ranks=2,
            epochs=5,
            lr=0.3,
            batch_size=16,
            seed=0,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        geometry = LocalPrototypeGeometry().build(clients, num_classes=base_weight.shape[0])
        result = run_subspace_failure_diagnostic(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            diagnostic_threshold=-1.0,
        )

        self.assertEqual(result.d_sub.shape, (4, 4))
        self.assertEqual(result.d_adapter_incompatibility.shape, (4, 4))
        self.assertEqual(result.compatibility.shape, (4, 4))
        self.assertEqual(len(result.subspace_rows), 6)
        self.assertEqual(len(result.conflict_rows), 12)
        self.assertGreaterEqual(len(result.distance_rows), 7)
        self.assertGreaterEqual(len(result.calibration_rows), 4)
        self.assertIn("geo_pearson_r", result.__dict__)
        self.assertIn("incompatibility_pearson_r", result.__dict__)
        self.assertTrue(np.all(np.asarray(result.failure_y) >= 0.0))
        self.assertTrue(np.isfinite(result.pearson_r) or np.isnan(result.pearson_r))
        self.assertTrue(np.isfinite(result.incompatibility_pearson_r) or np.isnan(result.incompatibility_pearson_r))

    def test_diagnostic_rejects_mismatched_geo_shape(self):
        clients, base_weight = make_synthetic_manifold_clients(num_clients=3, seed=3)
        local = run_local_lora(
            clients,
            base_weight,
            ranks=2,
            epochs=1,
            lr=0.1,
            batch_size=8,
            seed=0,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        with self.assertRaises(ValueError):
            run_subspace_failure_diagnostic(
                clients,
                base_weight,
                local.adapters,
                d_geo=np.zeros((2, 2)),
            )


if __name__ == "__main__":
    unittest.main()
