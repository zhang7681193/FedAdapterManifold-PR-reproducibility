import unittest

import numpy as np

from fedadaptermanifold.run_experiment import _compatibility_from_distance, _manifold_distance_matrix


class DistanceAblationTests(unittest.TestCase):
    def test_manifold_distance_components_are_explicit(self):
        d_sub = np.array([[0.0, 1.0], [1.0, 0.0]])
        d_geo = np.array([[0.0, 2.0], [2.0, 0.0]])
        d_label = np.array([[0.0, 4.0], [4.0, 0.0]])

        self.assertAlmostEqual(
            _manifold_distance_matrix("all", d_sub, d_geo, d_label, lambda_geo=0.5, lambda_label=0.25)[0, 1],
            3.0,
        )
        self.assertAlmostEqual(
            _manifold_distance_matrix("d_geo", d_sub, d_geo, d_label, lambda_geo=0.5, lambda_label=0.25)[0, 1],
            1.0,
        )
        self.assertAlmostEqual(
            _manifold_distance_matrix("d_sub_d_label", d_sub, d_geo, d_label, lambda_geo=0.5, lambda_label=0.25)[0, 1],
            2.0,
        )

    def test_compatibility_from_distance_has_unit_diagonal(self):
        distance = np.array([[0.0, 2.0], [2.0, 0.0]])
        compat = _compatibility_from_distance(distance, tau=2.0)

        self.assertAlmostEqual(compat[0, 0], 1.0)
        self.assertAlmostEqual(compat[0, 1], np.exp(-1.0))


if __name__ == "__main__":
    unittest.main()
