import unittest

from fedadaptermanifold.baselines import run_fedavg_lift_baseline, run_fedavg_lora_baseline, summarize_method
from fedadaptermanifold.data import make_synthetic_manifold_clients


class FedAvgLoRATests(unittest.TestCase):
    def test_fedavg_lora_returns_global_adapter_and_protocol_metrics(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=16,
            train_per_client=36,
            test_per_client=20,
            rank=2,
            seed=13,
        )
        result = run_fedavg_lora_baseline(
            clients,
            base_weight,
            ranks=[1, 2, 3],
            rounds=2,
            local_epochs=2,
            lr=0.25,
            batch_size=12,
            seed=0,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
        )

        self.assertEqual(result.global_adapter.rank, 3)
        self.assertGreater(result.global_adapter.delta().var(), 0.0)
        self.assertEqual(len(result.per_client_metrics), 3)
        self.assertEqual(len(result.round_history), 6)
        row = result.per_client_metrics[0]
        for field in ["method", "seed", "dataset", "heterogeneity_setting", "round", "client_id", "accuracy"]:
            self.assertIn(field, row)
        self.assertEqual(row["method"], "FedAvg-LoRA")

    def test_fedavg_lora_summary_is_aggregatable(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=2,
            num_classes=3,
            feature_dim=12,
            train_per_client=20,
            test_per_client=12,
            rank=1,
            seed=5,
        )
        result = run_fedavg_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=2,
            dataset="cifar10-debug",
            heterogeneity_setting="unit-test",
        )
        summary = summarize_method(result.per_client_metrics)
        self.assertEqual(len(summary), 1)
        self.assertEqual(summary[0]["method"], "FedAvg-LoRA")
        self.assertEqual(summary[0]["num_clients"], 2)

    def test_rank_length_mismatch_is_rejected(self):
        clients, base_weight = make_synthetic_manifold_clients(num_clients=2, seed=1)
        with self.assertRaises(ValueError):
            run_fedavg_lora_baseline(
                clients,
                base_weight,
                ranks=[1],
                rounds=1,
                local_epochs=1,
                lr=0.1,
                batch_size=8,
                seed=0,
                dataset="pacs-debug",
                heterogeneity_setting="unit-test",
            )

    def test_fedavg_lift_baseline_returns_protocol_metrics(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=16,
            train_per_client=30,
            test_per_client=18,
            rank=2,
            seed=21,
        )
        result = run_fedavg_lift_baseline(
            clients,
            base_weight,
            ranks=[1, 2, 2],
            rounds=2,
            local_epochs=2,
            lr=0.2,
            batch_size=10,
            seed=0,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
        )
        self.assertEqual(result.global_adapter.rank, 2)
        self.assertEqual(len(result.per_client_metrics), 3)
        self.assertEqual(len(result.round_history), 6)
        self.assertEqual(result.per_client_metrics[0]["method"], "FedAvg-Lift")


if __name__ == "__main__":
    unittest.main()
