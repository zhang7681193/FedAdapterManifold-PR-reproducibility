import tempfile
import unittest
from pathlib import Path

import numpy as np

from fedadaptermanifold.fedgeo_validation import validate_geometry_outputs
from fedadaptermanifold.geometry import LocalPrototypeGeometry, write_geometry_outputs
from fedadaptermanifold.data import make_synthetic_manifold_clients


class FedGeoValidationTests(unittest.TestCase):
    def test_validates_local_geometry_contract(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=12,
            train_per_client=20,
            test_per_client=10,
            seed=7,
        )
        geometry = LocalPrototypeGeometry().build(clients, num_classes=base_weight.shape[0], round_id=2)
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            write_geometry_outputs(root, geometry, round_id=2)
            rows, issues = validate_geometry_outputs(root, round_id=2)
        errors = [issue for issue in issues if issue["severity"] == "error"]
        self.assertFalse(errors)
        checks = {row["check"]: row for row in rows}
        self.assertEqual(checks["num_clients"]["value"], 3)
        self.assertEqual(checks["d_geo_square"]["status"], "pass")
        self.assertEqual(checks["geometry_graph_nonnegative"]["status"], "pass")

    def test_reports_missing_required_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            rows, issues = validate_geometry_outputs(tmp, round_id=0)
        self.assertTrue(any(issue["severity"] == "error" for issue in issues))
        self.assertTrue(any(row["check"] == "required_file" and row["status"] == "fail" for row in rows))


if __name__ == "__main__":
    unittest.main()
