from __future__ import annotations

import argparse
import tempfile
import unittest
from pathlib import Path

from scripts.build_formal_experiment_plan import build_plan_rows, main as plan_main


class FormalExperimentPlanTest(unittest.TestCase):
    def test_build_plan_rows_expands_dataset_specific_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config = root / "full_pacs_clip_vit_b16.yaml"
            config.write_text(
                "\n".join(
                    [
                        "dataset: image-folder",
                        "heterogeneity_setting: pacs-domain-split",
                        "feature_backbone: clip-vit-b16",
                    ]
                ),
                encoding="utf-8",
            )
            data = root / "data" / "pacs"
            data.mkdir(parents=True)
            geo = root / "geo" / "pacs_map.csv"
            geo.parent.mkdir(parents=True)
            geo.write_text("seed,geometry_outputs_dir\n0,x\n", encoding="utf-8")
            plan = {
                "configs": str(config),
                "output_root": str(root / "out"),
                "python_executable": "python",
                "seeds": "0,1",
                "round_id": 0,
                "feature_backbone": "clip-vit-b16",
                "device": "cuda",
                "pacs_data_root": str(data),
                "pacs_geometry_outputs_map": str(geo),
                "feature_cache_dir_template": str(root / "cache" / "{dataset_key}_{backbone_slug}"),
                "no_cpu_debug": True,
                "continue_on_failed_diagnostic": True,
            }
            rows = build_plan_rows(
                plan,
                argparse.Namespace(
                    data_root_template="",
                    data_root_map="",
                    geometry_outputs_map_template="",
                    geometry_outputs_map_map="",
                    feature_cache_dir_template="",
                ),
            )

        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["dataset_key"], "pacs")
        self.assertEqual(rows[0]["ready"], "true")
        self.assertIn("--geometry-outputs-map", rows[0]["argv"])
        self.assertIn("clip_vit_b16", rows[0]["feature_cache_dir"])

    def test_plan_main_writes_commands_without_executing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            config = root / "full_domainnetmini_clip_vit_b16.yaml"
            config.write_text(
                "dataset: image-folder\nheterogeneity_setting: domainnetmini-domain-split\n",
                encoding="utf-8",
            )
            data = root / "data"
            data.mkdir()
            geo = root / "geo.csv"
            geo.write_text("seed,geometry_outputs_dir\n0,x\n", encoding="utf-8")
            plan = root / "plan.yaml"
            plan.write_text(
                "\n".join(
                    [
                        f"configs: {config}",
                        f"output_root: {root / 'results'}",
                        "python_executable: python",
                        "seeds: 0",
                        "round_id: 0",
                        "feature_backbone: clip-vit-b16",
                        f"domainnetmini_data_root: {data}",
                        f"domainnetmini_geometry_outputs_map: {geo}",
                    ]
                ),
                encoding="utf-8",
            )
            out = root / "plan_out"
            code = plan_main(["--plan", str(plan), "--output-dir", str(out)])

            self.assertEqual(code, 0)
            self.assertTrue((out / "formal_experiment_plan.csv").exists())
            command_text = (out / "run_formal_experiments.ps1").read_text(encoding="utf-8")
            self.assertIn("run_fedgeo_multiseed.py", command_text)


if __name__ == "__main__":
    unittest.main()
