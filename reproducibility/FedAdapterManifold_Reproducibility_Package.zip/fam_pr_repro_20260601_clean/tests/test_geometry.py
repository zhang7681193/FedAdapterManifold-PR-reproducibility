import unittest
import sys
import types
from dataclasses import dataclass

import numpy as np

from fedadaptermanifold.geometry import (
    FedGeoFileGeometryProvider,
    cluster_prototypes_from_geometry,
    semantic_prototype_signature,
)


@dataclass
class _TinyClient:
    client_id: str
    x_train: np.ndarray
    y_train: np.ndarray


class _FakeTensor:
    def __init__(self, value):
        self.value = np.asarray(value)

    def detach(self):
        return self

    def cpu(self):
        return self

    def numpy(self):
        return self.value


class GeometryTests(unittest.TestCase):
    def test_semantic_prototype_signature_removes_client_style_offset(self):
        prototypes = np.array(
            [
                [10.0, 11.0, 12.0],
                [12.0, 11.0, 10.0],
                [0.0, 0.0, 0.0],
            ]
        )
        signature = semantic_prototype_signature(prototypes, counts={0: 4, 1: 6, 2: 0})
        centered = signature.reshape(3, 3)
        np.testing.assert_allclose(centered[:2].mean(axis=0), np.zeros(3))
        np.testing.assert_allclose(centered[2], np.zeros(3))

    def test_cluster_prototypes_from_geometry_uses_fedgeo_anchors(self):
        prototypes = {
            "client_0": {0: np.array([1.0, 0.0]), 1: np.array([0.0, 1.0])},
            "client_1": {0: np.array([3.0, 0.0]), 1: np.array([0.0, 3.0])},
            "client_2": {0: np.array([10.0, 0.0]), 1: np.array([0.0, 10.0])},
        }
        anchors = cluster_prototypes_from_geometry(
            prototypes,
            ["client_0", "client_1", "client_2"],
            assignments=np.array([0, 0, 1]),
            num_classes=2,
        )
        self.assertEqual(anchors.shape, (2, 2, 2))
        np.testing.assert_allclose(anchors[0, 0], np.array([2.0, 0.0]))
        np.testing.assert_allclose(anchors[1, 1], np.array([0.0, 10.0]))

    def test_cluster_prototypes_fallback_when_anchor_dimension_mismatches_features(self):
        prototypes = {
            "client_0": {0: np.array([1.0, 0.0]), 1: np.array([0.0, 1.0])},
            "client_1": {0: np.array([3.0, 0.0]), 1: np.array([0.0, 3.0])},
        }
        clients = [
            _TinyClient("client_0", np.array([[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]]), np.array([0, 1])),
            _TinyClient("client_1", np.array([[0.0, 0.0, 1.0], [1.0, 1.0, 0.0]]), np.array([0, 1])),
        ]
        anchors = cluster_prototypes_from_geometry(
            prototypes,
            ["client_0", "client_1"],
            assignments=np.array([0, 1]),
            num_classes=2,
            fallback_clients=clients,
        )
        self.assertEqual(anchors.shape, (2, 2, 3))
        np.testing.assert_allclose(anchors[1, 0], np.array([0.0, 0.0, 1.0]))

    def test_fedgeo_provider_prefers_interop_loader(self):
        calls = []

        def fake_loader(path, round_id):
            calls.append((path, round_id))
            return {
                "client_ids": [1, 0],
                "d_geo": _FakeTensor([[0.0, 2.0], [2.0, 0.0]]),
                "geometry_graph": _FakeTensor([[0.0, 1.0], [1.0, 0.0]]),
                "prototypes": {
                    0: {0: _FakeTensor([1.0, 0.0]), 1: _FakeTensor([0.0, 1.0])},
                    1: {0: _FakeTensor([2.0, 0.0]), 1: _FakeTensor([0.0, 2.0])},
                },
                "client_signatures": [
                    {
                        "client_id": 1,
                        "round_id": 5,
                        "prototypes": {0: _FakeTensor([2.0, 0.0]), 1: _FakeTensor([0.0, 2.0])},
                        "variances": {0: _FakeTensor([0.1, 0.1]), 1: _FakeTensor([0.2, 0.2])},
                        "radii": {0: 0.1, 1: 0.2},
                        "uncertainties": {0: 0.3, 1: 0.4},
                        "counts": {0: 1, 1: 1},
                        "label_histogram": _FakeTensor([1, 1]),
                    },
                    {
                        "client_id": 0,
                        "round_id": 5,
                        "prototypes": {0: _FakeTensor([1.0, 0.0]), 1: _FakeTensor([0.0, 1.0])},
                        "variances": {0: _FakeTensor([0.1, 0.1]), 1: _FakeTensor([0.2, 0.2])},
                        "radii": {0: 0.1, 1: 0.2},
                        "uncertainties": {0: 0.3, 1: 0.4},
                        "counts": {0: 1, 1: 1},
                        "label_histogram": _FakeTensor([1, 1]),
                    },
                ],
                "novelty_scores": _FakeTensor([0.7, 0.3]),
                "coverage_deficit": _FakeTensor([0.2, 0.1]),
                "risk_geo_scores": [
                    {"client_id": 1, "risk_geo_score": 0.9},
                    {"client_id": 0, "risk_geo_score": 0.4},
                ],
                "feature_energy_deficit": _FakeTensor([0.6, 0.2]),
            }

        fake_pkg = types.ModuleType("fedgeo")
        fake_interop = types.ModuleType("fedgeo.interop")
        fake_interop.load_fedadaptermanifold_inputs = fake_loader
        old_pkg = sys.modules.get("fedgeo")
        old_interop = sys.modules.get("fedgeo.interop")
        sys.modules["fedgeo"] = fake_pkg
        sys.modules["fedgeo.interop"] = fake_interop
        try:
            clients = [
                _TinyClient("client_0", np.zeros((2, 2)), np.array([0, 1])),
                _TinyClient("client_1", np.zeros((2, 2)), np.array([0, 1])),
            ]
            geometry = FedGeoFileGeometryProvider("dummy_geometry").build(clients, num_classes=2, round_id=5)
        finally:
            if old_pkg is None:
                sys.modules.pop("fedgeo", None)
            else:
                sys.modules["fedgeo"] = old_pkg
            if old_interop is None:
                sys.modules.pop("fedgeo.interop", None)
            else:
                sys.modules["fedgeo.interop"] = old_interop

        self.assertEqual(calls, [("dummy_geometry", 5)])
        self.assertEqual(geometry.provider, "fedgeo_interop")
        self.assertEqual(geometry.client_ids, ["client_0", "client_1"])
        np.testing.assert_allclose(geometry.novelty, np.array([0.3, 0.7]))
        np.testing.assert_allclose(geometry.coverage, np.array([0.9, 0.8]))
        np.testing.assert_allclose(geometry.risk_geo_scores, np.array([0.4, 0.9]))
        np.testing.assert_allclose(geometry.feature_energy_deficit, np.array([0.2, 0.6]))
        np.testing.assert_allclose(geometry.prototypes["client_0"][0], np.array([1.0, 0.0]))


if __name__ == "__main__":
    unittest.main()
