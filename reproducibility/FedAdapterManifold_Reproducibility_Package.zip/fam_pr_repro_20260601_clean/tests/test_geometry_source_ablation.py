from __future__ import annotations

import argparse
import unittest
from pathlib import Path

from scripts.run_geometry_source_ablation import _geometry_map


class GeometrySourceAblationTests(unittest.TestCase):
    def test_local_prototype_source_uses_internal_geometry_provider(self):
        args = argparse.Namespace(
            fedgeo_results_root="fedgeo_results",
            seeds="0,1",
            source_template="{dataset_prefix}_seed{seed}/{source}/geometry_outputs",
            dataset_prefix="pacs_compare",
        )

        self.assertEqual(_geometry_map(args, "local_prototype"), "")

    def test_fedgeo_source_expands_seed_specific_paths(self):
        args = argparse.Namespace(
            fedgeo_results_root="fedgeo_results",
            seeds="0,1",
            source_template="{dataset_prefix}_seed{seed}/{source}/geometry_outputs",
            dataset_prefix="pacs_compare",
        )

        mapping = _geometry_map(args, "fedgeo_full")

        self.assertIn(f"0={Path('fedgeo_results') / 'pacs_compare_seed0' / 'fedgeo_full' / 'geometry_outputs'}", mapping)
        self.assertIn(f"1={Path('fedgeo_results') / 'pacs_compare_seed1' / 'fedgeo_full' / 'geometry_outputs'}", mapping)


if __name__ == "__main__":
    unittest.main()
