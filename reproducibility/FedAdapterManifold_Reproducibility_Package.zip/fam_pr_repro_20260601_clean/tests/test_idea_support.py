import unittest

from fedadaptermanifold.run_experiment import _idea_support_rows, _selector_candidate_pool


class IdeaSupportTests(unittest.TestCase):
    def test_subspace_compatible_is_not_core_gate(self):
        rows = _idea_support_rows(
            [
                _metric("Local-LoRA", 0.74),
                _metric("FedAvg-LoRA", 0.72, adapter_r=0.7, raw_subspace_r=0.5),
                _metric("Subspace-Compatible", 0.68),
                _metric("FedGeo-Agg", 0.73),
                _metric("FedAdapterManifold", 0.76),
            ],
            diagnostic_threshold=0.05,
        )

        self.assertEqual(len(rows), 1)
        self.assertTrue(rows[0]["supports_idea"])
        self.assertTrue(rows[0]["supports_vs_fedgeo_agg"])
        self.assertFalse(rows[0]["subspace_compatible_is_gate"])
        self.assertLess(rows[0]["subspace_minus_fedavg_lora"], 0.0)

    def test_fedgeo_agg_gain_remains_gate_when_available(self):
        rows = _idea_support_rows(
            [
                _metric("Local-LoRA", 0.74),
                _metric("FedAvg-LoRA", 0.72, adapter_r=0.7, raw_subspace_r=0.5),
                _metric("Subspace-Compatible", 0.71),
                _metric("FedGeo-Agg", 0.77),
                _metric("FedAdapterManifold", 0.76),
            ],
            diagnostic_threshold=0.05,
        )

        self.assertFalse(rows[0]["supports_idea"])
        self.assertFalse(rows[0]["supports_vs_fedgeo_agg"])

    def test_raw_adapter_signal_can_support_when_residual_is_unstable(self):
        rows = _idea_support_rows(
            [
                _metric("Local-LoRA", 0.20),
                _metric("FedAvg-LoRA", 0.05, adapter_r=0.35, controlled_adapter_r=-0.01, raw_subspace_r=0.38),
                _metric("Subspace-Compatible", 0.10),
                _metric("FedGeo-Agg", 0.14),
                _metric("FedAdapterManifold", 0.15),
            ],
            diagnostic_threshold=0.05,
        )

        self.assertTrue(rows[0]["supports_idea"])
        self.assertEqual(rows[0]["primary_adapter_incompatibility_signal"], "raw_directional")
        self.assertAlmostEqual(rows[0]["adapter_incompatibility_failure_pearson_r"], 0.35)

    def test_adapter_only_selector_scope_excludes_external_fallbacks(self):
        pool = _selector_candidate_pool(
            scope="adapter-only",
            local_adapters=["local"],
            fedgeo_agg_adapters=["geo"],
            subspace_adapters=["subspace"],
            bank_adapters=["bank"],
        )

        self.assertEqual(pool, {"FedAdapterManifold": ["bank"]})


def _metric(method, accuracy, adapter_r=0.7, controlled_adapter_r=None, raw_subspace_r=0.5):
    if controlled_adapter_r is None:
        controlled_adapter_r = adapter_r
    return {
        "method": method,
        "mean_accuracy": accuracy,
        "raw_subspace_failure_pearson_r": raw_subspace_r,
        "adapter_incompatibility_failure_pearson_r": adapter_r,
        "raw_adapter_incompatibility_failure_pearson_r": adapter_r,
        "receiver_residual_adapter_incompatibility_failure_pearson_r": controlled_adapter_r,
    }


if __name__ == "__main__":
    unittest.main()
