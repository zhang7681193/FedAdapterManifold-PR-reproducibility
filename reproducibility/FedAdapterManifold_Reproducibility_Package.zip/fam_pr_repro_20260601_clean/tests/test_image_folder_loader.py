import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from fedadaptermanifold.data import load_image_folder_clients, load_medmnist_npz_clients


class ImageFolderLoaderTests(unittest.TestCase):
    def test_domain_train_test_layout_uses_class_dirs_not_split_dirs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for domain_idx, domain in enumerate(["art_painting", "cartoon"]):
                for split in ["train", "test"]:
                    for class_name in ["0", "1", "10"]:
                        class_dir = root / domain / split / class_name
                        class_dir.mkdir(parents=True)
                        value = 20 * domain_idx + 5 * int(class_name) + (3 if split == "test" else 0)
                        _write_image(class_dir / "sample.png", value)

            clients, base_weight, class_names = load_image_folder_clients(
                root,
                domains=["art_painting", "cartoon"],
                feature_backbone="numpy",
                seed=0,
            )

        self.assertEqual(class_names, ["0", "1", "10"])
        self.assertEqual(len(clients), 2)
        self.assertEqual(base_weight.shape[0], 3)
        for client in clients:
            self.assertEqual(client.x_train.shape[0], 3)
            self.assertEqual(client.x_test.shape[0], 3)
            self.assertEqual(set(client.y_train.tolist()), {0, 1, 2})
            self.assertEqual(set(client.y_test.tolist()), {0, 1, 2})

    def test_feature_cache_reuses_extracted_image_folder_features(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "data"
            cache = Path(tmp) / "cache"
            for domain in ["art_painting"]:
                for class_name in ["0", "1"]:
                    class_dir = root / domain / class_name
                    class_dir.mkdir(parents=True)
                    _write_image(class_dir / "a.png", 10 + int(class_name))
                    _write_image(class_dir / "b.png", 20 + int(class_name))

            clients_a, _, _ = load_image_folder_clients(
                root,
                domains=["art_painting"],
                feature_backbone="numpy",
                seed=3,
                feature_cache_dir=cache,
            )
            cache_files = list(cache.glob("*.npz"))
            clients_b, _, _ = load_image_folder_clients(
                root,
                domains=["art_painting"],
                feature_backbone="numpy",
                seed=3,
                feature_cache_dir=cache,
            )

        self.assertTrue(cache_files)
        np.testing.assert_allclose(clients_a[0].x_train, clients_b[0].x_train)
        np.testing.assert_array_equal(clients_a[0].y_test, clients_b[0].y_test)

    def test_image_folder_loader_can_cap_domain_samples(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for class_name in ["0", "1"]:
                class_dir = root / "domain" / class_name
                class_dir.mkdir(parents=True)
                for idx in range(10):
                    _write_image(class_dir / f"{idx}.png", 10 * int(class_name) + idx)

            clients, _, _ = load_image_folder_clients(
                root,
                domains=["domain"],
                feature_backbone="numpy",
                seed=4,
                train_per_client=6,
                test_per_client=4,
            )

        self.assertEqual(clients[0].x_train.shape[0], 6)
        self.assertEqual(clients[0].x_test.shape[0], 4)
        self.assertEqual(set(clients[0].y_train.tolist()), {0, 1})
        self.assertEqual(set(clients[0].y_test.tolist()), {0, 1})

    def test_medmnist_npz_loader_builds_label_skew_clients(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / "toy_medmnist.npz"
            train_images = np.arange(80 * 8 * 8 * 3, dtype=np.uint8).reshape(80, 8, 8, 3)
            test_images = np.arange(48 * 8 * 8 * 3, dtype=np.uint8).reshape(48, 8, 8, 3)
            train_labels = (np.arange(80) % 4).reshape(-1, 1).astype(np.uint8)
            test_labels = (np.arange(48) % 4).reshape(-1, 1).astype(np.uint8)
            np.savez_compressed(
                path,
                train_images=train_images,
                train_labels=train_labels,
                test_images=test_images,
                test_labels=test_labels,
            )

            clients, base_weight, class_names = load_medmnist_npz_clients(
                path,
                num_clients=4,
                dirichlet_alpha=10.0,
                min_train_size=4,
                train_per_client=12,
                test_per_client=8,
                seed=2,
                feature_cache_dir=root / "cache",
            )

        self.assertEqual(len(clients), 4)
        self.assertEqual(class_names, ["class_0", "class_1", "class_2", "class_3"])
        self.assertEqual(base_weight.shape[0], 4)
        for client in clients:
            self.assertLessEqual(client.x_train.shape[0], 12)
            self.assertLessEqual(client.x_test.shape[0], 8)
            self.assertEqual(client.x_train.shape[1], base_weight.shape[1])


def _write_image(path: Path, value: int) -> None:
    arr = np.full((8, 8, 3), int(value), dtype=np.uint8)
    Image.fromarray(arr).save(path)


if __name__ == "__main__":
    unittest.main()
