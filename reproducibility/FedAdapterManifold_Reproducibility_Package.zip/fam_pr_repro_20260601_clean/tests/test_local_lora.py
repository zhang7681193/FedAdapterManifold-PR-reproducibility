import unittest

from fedadaptermanifold.baselines import run_local_lora, summarize_method
from fedadaptermanifold.data import make_synthetic_manifold_clients


class LocalLoRATests(unittest.TestCase):
    def test_local_lora_trains_one_adapter_per_client(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=16,
            train_per_client=40,
            test_per_client=24,
            rank=2,
            seed=9,
        )
        result = run_local_lora(
            clients,
            base_weight,
            ranks=[1, 2, 3],
            epochs=4,
            lr=0.3,
            batch_size=16,
            seed=0,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )

        self.assertEqual(len(result.adapters), 3)
        self.assertEqual([adapter.rank for adapter in result.adapters], [1, 2, 3])
        self.assertEqual(len(result.per_client_metrics), 3)
        self.assertEqual(len(result.training_summary), 3)
        self.assertEqual(len(result.training_trace), 15)
        self.assertEqual(result.per_client_metrics[0]["method"], "Local-LoRA")

    def test_summary_has_shared_protocol_fields(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=2,
            num_classes=3,
            feature_dim=12,
            train_per_client=20,
            test_per_client=12,
            rank=1,
            seed=4,
        )
        result = run_local_lora(
            clients,
            base_weight,
            ranks=1,
            epochs=2,
            lr=0.2,
            batch_size=8,
            seed=2,
            dataset="cifar10-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        summary = summarize_method(result.per_client_metrics)
        self.assertEqual(len(summary), 1)
        for field in ["method", "seed", "dataset", "heterogeneity_setting", "round", "mean_accuracy"]:
            self.assertIn(field, summary[0])

    def test_rank_length_mismatch_is_rejected(self):
        clients, base_weight = make_synthetic_manifold_clients(num_clients=2, seed=1)
        with self.assertRaises(ValueError):
            run_local_lora(
                clients,
                base_weight,
                ranks=[1],
                epochs=1,
                lr=0.1,
                batch_size=8,
                seed=0,
                dataset="pacs-debug",
                heterogeneity_setting="unit-test",
                round_id=1,
            )


if __name__ == "__main__":
    unittest.main()
