import unittest

from fedadaptermanifold.baselines import (
    run_clustered_lora_baseline,
    run_ditto_lora_baseline,
    run_fedamp_lora_baseline,
    run_fedavg_lora_baseline,
    run_fedavg_lift_baseline,
    run_fedper_lora_baseline,
    run_fedproto_lora_baseline,
    run_fedprox_lora_baseline,
    run_pfedme_lora_baseline,
    run_scaffold_lora_baseline,
    summarize_method,
)
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.diagnostics import run_subspace_failure_diagnostic


class PersonalizedLoRABaselineTests(unittest.TestCase):
    def test_fedprox_lora_returns_protocol_metrics(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=16,
            train_per_client=30,
            test_per_client=18,
            rank=2,
            seed=31,
        )
        result = run_fedprox_lora_baseline(
            clients,
            base_weight,
            ranks=[1, 2, 2],
            rounds=2,
            local_epochs=2,
            lr=0.2,
            batch_size=10,
            seed=0,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            prox_mu=0.02,
        )

        self.assertEqual(result.global_adapter.rank, 2)
        self.assertEqual(len(result.per_client_metrics), 3)
        self.assertEqual(len(result.round_history), 6)
        self.assertEqual(result.per_client_metrics[0]["method"], "FedProx-LoRA")
        self.assertEqual(result.round_history[0]["fedprox_mu"], 0.02)

    def test_fedprox_mu_zero_matches_fedavg_lora(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=2,
            num_classes=3,
            feature_dim=12,
            train_per_client=24,
            test_per_client=12,
            rank=1,
            seed=33,
        )
        fedavg = run_fedavg_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=2,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=4,
            dataset="cifar10-debug",
            heterogeneity_setting="unit-test",
        )
        fedprox = run_fedprox_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=2,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=4,
            dataset="cifar10-debug",
            heterogeneity_setting="unit-test",
            prox_mu=0.0,
        )

        self.assertLess(abs(fedavg.global_adapter.delta() - fedprox.global_adapter.delta()).max(), 1e-12)
        self.assertEqual(
            [row["accuracy"] for row in fedavg.per_client_metrics],
            [row["accuracy"] for row in fedprox.per_client_metrics],
        )

    def test_ditto_lora_returns_personal_adapters_and_summary(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=2,
            num_classes=3,
            feature_dim=12,
            train_per_client=24,
            test_per_client=12,
            rank=1,
            seed=32,
        )
        result = run_ditto_lora_baseline(
            clients,
            base_weight,
            ranks=[1, 2],
            rounds=2,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=2,
            dataset="cifar10-debug",
            heterogeneity_setting="unit-test",
            prox_mu=0.03,
        )

        self.assertEqual(result.global_adapter.rank, 2)
        self.assertEqual([adapter.rank for adapter in result.personal_adapters], [1, 2])
        self.assertEqual(len(result.per_client_metrics), 2)
        self.assertEqual(len(result.round_history), 8)
        self.assertEqual(result.per_client_metrics[0]["method"], "Ditto-LoRA")
        self.assertEqual(result.round_history[-1]["ditto_mu"], 0.03)
        summary = summarize_method(result.per_client_metrics)
        self.assertEqual(summary[0]["method"], "Ditto-LoRA")

    def test_clustered_and_fedamp_lora_return_client_adapters(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=16,
            train_per_client=24,
            test_per_client=12,
            rank=2,
            seed=34,
        )
        local = run_ditto_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=3,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            prox_mu=0.0,
        )
        diagnostic = run_subspace_failure_diagnostic(clients, base_weight, local.personal_adapters)
        clustered = run_clustered_lora_baseline(
            clients,
            base_weight,
            local.personal_adapters,
            distance=diagnostic.d_sub,
            ranks=2,
            k=2,
            seed=3,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        fedamp = run_fedamp_lora_baseline(
            clients,
            base_weight,
            local.personal_adapters,
            distance=diagnostic.d_sub,
            ranks=2,
            tau=1.0,
            seed=3,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )

        self.assertEqual(len(clustered.client_adapters), 3)
        self.assertEqual(len(fedamp.client_adapters), 3)
        self.assertEqual(clustered.per_client_metrics[0]["method"], "Clustered-LoRA")
        self.assertEqual(fedamp.per_client_metrics[0]["method"], "FedAMP-LoRA")

    def test_additional_personalized_and_proto_baselines_return_protocol_metrics(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=3,
            num_classes=4,
            feature_dim=16,
            train_per_client=24,
            test_per_client=12,
            rank=2,
            seed=35,
        )
        local = run_ditto_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            prox_mu=0.0,
        )
        lift = run_fedavg_lift_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
        )
        diagnostic = run_subspace_failure_diagnostic(clients, base_weight, local.personal_adapters)
        scaffold = run_scaffold_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
        )
        pfedme = run_pfedme_lora_baseline(
            clients,
            base_weight,
            ranks=2,
            rounds=1,
            local_epochs=1,
            lr=0.2,
            batch_size=8,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            prox_mu=0.02,
        )
        fedproto = run_fedproto_lora_baseline(
            clients,
            base_weight,
            local.personal_adapters,
            d_geo=diagnostic.d_sub,
            ranks=2,
            tau=1.0,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        fedper = run_fedper_lora_baseline(
            clients,
            base_weight,
            local.personal_adapters,
            shared_adapter=lift.global_adapter,
            ranks=2,
            seed=5,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )

        self.assertEqual(scaffold.per_client_metrics[0]["method"], "SCAFFOLD-LoRA")
        self.assertEqual(len(scaffold.round_history), 3)
        self.assertEqual(pfedme.per_client_metrics[0]["method"], "pFedMe-LoRA")
        self.assertEqual(fedproto.per_client_metrics[0]["method"], "FedProto-LoRA")
        self.assertEqual(fedper.per_client_metrics[0]["method"], "FedPer-LoRA")
        self.assertIn("selected_personal_weight", fedper.per_client_metrics[0])


if __name__ == "__main__":
    unittest.main()
