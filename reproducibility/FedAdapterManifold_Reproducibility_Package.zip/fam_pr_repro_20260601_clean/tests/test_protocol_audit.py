from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from fedadaptermanifold.reporting import write_csv
from scripts.audit_fedadaptermanifold_protocol import main as audit_main


class ProtocolAuditTest(unittest.TestCase):
    def test_protocol_audit_passes_for_expected_single_seed_outputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run = root / "seed_0"
            run.mkdir()
            (run / "config.yaml").write_text(
                "\n".join(
                    [
                        "dataset: image-folder",
                        "heterogeneity_setting: pacs-domain-split",
                        "geometry_outputs_dir: geometry_outputs",
                        "round_id: 0",
                    ]
                ),
                encoding="utf-8",
            )
            common = {
                "method": "FedAdapterManifold",
                "seed": 0,
                "dataset": "image-folder",
                "heterogeneity_setting": "pacs-domain-split",
                "round": 3,
            }
            write_csv(run / "metrics.csv", [{**common, "mean_accuracy": 0.8}])
            write_csv(
                run / "per_client_metrics.csv",
                [
                    {
                        **common,
                        "client_id": "client_0",
                        "geometry_signal_for_manifold": "d_geo+geometry_graph",
                        "risk_signal_usage": "auxiliary_prior_only",
                    }
                ],
            )
            write_csv(
                run / "geometry_signal_roles.csv",
                [
                    {"signal": "d_geo", "role": "main_adapter_manifold_distance", "is_main_manifold": True},
                    {"signal": "geometry_graph", "role": "main_adapter_sharing_graph", "is_main_manifold": True},
                    {"signal": "prototypes", "role": "class_conditional_routing_anchor", "is_main_manifold": True},
                    {"signal": "risk_geo_score", "role": "auxiliary_rare_mode_fairness_prior", "is_main_manifold": False},
                    {"signal": "feature_energy_deficit", "role": "auxiliary_reliability_energy_prior", "is_main_manifold": False},
                ],
            )
            out = root / "audit"
            code = audit_main(["--run", f"PACS|{run}", "--output-dir", str(out)])
            self.assertEqual(code, 0)
            summary = (out / "protocol_audit_summary.csv").read_text(encoding="utf-8")
            self.assertIn("pass", summary)

    def test_protocol_audit_rejects_risk_signal_as_main_manifold(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            run = root / "seed_0"
            run.mkdir()
            (run / "config.yaml").write_text(
                "dataset: image-folder\nheterogeneity_setting: test\ngeometry_outputs_dir: g\nround_id: 0\n",
                encoding="utf-8",
            )
            common = {
                "method": "FedAdapterManifold",
                "seed": 0,
                "dataset": "image-folder",
                "heterogeneity_setting": "test",
                "round": 3,
            }
            write_csv(run / "metrics.csv", [common])
            write_csv(
                run / "per_client_metrics.csv",
                [
                    {
                        **common,
                        "client_id": "client_0",
                        "geometry_signal_for_manifold": "d_geo+geometry_graph",
                        "risk_signal_usage": "auxiliary_prior_only",
                    }
                ],
            )
            write_csv(
                run / "geometry_signal_roles.csv",
                [
                    {"signal": "d_geo", "role": "main_adapter_manifold_distance", "is_main_manifold": True},
                    {"signal": "geometry_graph", "role": "main_adapter_sharing_graph", "is_main_manifold": True},
                    {"signal": "prototypes", "role": "class_conditional_routing_anchor", "is_main_manifold": True},
                    {"signal": "risk_geo_score", "role": "main_adapter_manifold_distance", "is_main_manifold": True},
                ],
            )
            out = root / "audit"
            code = audit_main(["--run", f"PACS|{run}", "--output-dir", str(out)])
            self.assertEqual(code, 2)
            audit = (out / "protocol_audit.csv").read_text(encoding="utf-8")
            self.assertIn("geometry_roles:auxiliary:risk_geo_score,fail", audit)


if __name__ == "__main__":
    unittest.main()
