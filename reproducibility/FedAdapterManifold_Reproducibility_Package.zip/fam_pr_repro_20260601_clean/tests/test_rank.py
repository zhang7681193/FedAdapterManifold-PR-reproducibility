import unittest

import numpy as np

from fedadaptermanifold.rank import allocate_ranks, auxiliary_risk_capacity_scores, conflict_scores_from_distance


class RankPolicyTests(unittest.TestCase):
    def test_fixed_rank_policy(self):
        self.assertEqual(allocate_ranks("fixed", 3, base_rank=4), [4, 4, 4])

    def test_random_rank_policy_is_bounded(self):
        ranks = allocate_ranks("random", 10, base_rank=4, min_rank=2, max_rank=6, seed=0)
        self.assertEqual(len(ranks), 10)
        self.assertTrue(all(2 <= rank <= 6 for rank in ranks))

    def test_novelty_aware_assigns_more_rank_to_high_score(self):
        ranks = allocate_ranks(
            "novelty-aware",
            3,
            base_rank=4,
            min_rank=2,
            max_rank=8,
            novelty=np.array([0.0, 0.5, 1.0]),
        )
        self.assertEqual(ranks[0], 2)
        self.assertEqual(ranks[-1], 8)

    def test_conflict_scores_from_distance(self):
        d_sub = np.array(
            [
                [0.0, 1.0, 3.0],
                [1.0, 0.0, 5.0],
                [3.0, 5.0, 0.0],
            ]
        )
        scores = conflict_scores_from_distance(d_sub)
        np.testing.assert_allclose(scores, np.array([2.0, 3.0, 4.0]))

    def test_conflict_aware_is_centered_near_base_rank(self):
        ranks = allocate_ranks(
            "conflict-aware",
            4,
            base_rank=4,
            min_rank=2,
            max_rank=8,
            novelty=np.array([0.0, 0.2, 0.8, 1.0]),
            conflict=np.array([0.0, 0.3, 0.7, 1.0]),
        )
        self.assertTrue(all(2 <= rank <= 6 for rank in ranks))
        self.assertGreaterEqual(ranks[-1], ranks[0])

    def test_risk_aware_is_auxiliary_capacity_prior(self):
        scores = auxiliary_risk_capacity_scores(
            risk=np.array([0.0, 0.9, 0.2]),
            feature_energy_deficit=np.array([0.0, 0.4, 1.0]),
            novelty=np.array([0.0, 0.1, 0.2]),
            num_clients=3,
        )
        self.assertEqual(scores.shape, (3,))
        self.assertGreater(scores[1], scores[0])
        ranks = allocate_ranks(
            "risk-aware",
            3,
            base_rank=4,
            min_rank=2,
            max_rank=8,
            risk=np.array([0.0, 0.9, 0.2]),
            feature_energy_deficit=np.array([0.0, 0.4, 1.0]),
            novelty=np.array([0.0, 0.1, 0.2]),
        )
        self.assertTrue(all(2 <= rank <= 8 for rank in ranks))
        self.assertGreaterEqual(ranks[1], ranks[0])

    def test_invalid_conflict_matrix_is_rejected(self):
        with self.assertRaises(ValueError):
            conflict_scores_from_distance(np.zeros((2, 3)))


if __name__ == "__main__":
    unittest.main()
