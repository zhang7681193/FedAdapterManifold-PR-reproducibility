import argparse
import tempfile
import unittest
from pathlib import Path

from scripts.run_real_fedgeo_suite import build_run_plan


class RealFedGeoSuiteTests(unittest.TestCase):
    def test_build_run_plan_expands_templates_without_running(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            data_root = root / "data" / "pacs"
            data_root.mkdir(parents=True)
            args = argparse.Namespace(
                configs="configs/pacs_image_folder.yaml",
                output_root=str(root / "out"),
                seeds="0,1",
                round_id=3,
                data_root_template=str(root / "data" / "{dataset}"),
                geometry_outputs_template=str(root / "fedgeo" / "{dataset}" / "seed_{seed}" / "geometry_outputs"),
                feature_backbone="numpy",
                device="cpu",
                cpu_debug=True,
                no_cpu_debug=False,
            )

            plan = build_run_plan(args)

        self.assertEqual(len(plan), 1)
        self.assertEqual(plan[0]["dataset_key"], "pacs")
        self.assertTrue(plan[0]["ready"])
        self.assertIn("seed_{seed}", plan[0]["geometry_outputs_template"])
        self.assertEqual(plan[0]["round_id"], 3)


if __name__ == "__main__":
    unittest.main()
