import unittest

import numpy as np

from fedadaptermanifold.adapters import LoRAAdapter
from fedadaptermanifold.subspace import grassmann_distance, subspace_distance_matrix


class SubspaceTests(unittest.TestCase):
    def test_identical_subspaces_have_zero_distance(self):
        basis = np.eye(4, 2)
        self.assertAlmostEqual(grassmann_distance(basis, basis), 0.0, places=8)

    def test_orthogonal_one_dimensional_subspaces(self):
        a = np.array([[1.0], [0.0]])
        b = np.array([[0.0], [1.0]])
        self.assertAlmostEqual(grassmann_distance(a, b), np.pi / 2.0, places=8)

    def test_adapter_distance_matrix_is_symmetric(self):
        rng = np.random.default_rng(0)
        a1 = LoRAAdapter.random(6, 3, 2, rng, zero_b=False)
        a2 = LoRAAdapter.random(6, 3, 2, rng, zero_b=False)
        matrix, _ = subspace_distance_matrix([a1, a2])
        self.assertEqual(matrix.shape, (2, 2))
        self.assertAlmostEqual(matrix[0, 1], matrix[1, 0], places=8)
        self.assertAlmostEqual(matrix[0, 0], 0.0, places=8)


if __name__ == "__main__":
    unittest.main()
