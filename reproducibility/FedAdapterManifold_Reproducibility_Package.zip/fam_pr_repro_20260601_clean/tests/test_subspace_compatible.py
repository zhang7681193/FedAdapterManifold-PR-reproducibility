import unittest

from fedadaptermanifold.baselines import run_local_lora, run_subspace_compatible_baseline
from fedadaptermanifold.data import make_synthetic_manifold_clients
from fedadaptermanifold.diagnostics import run_subspace_failure_diagnostic
from fedadaptermanifold.geometry import LocalPrototypeGeometry


class SubspaceCompatibleBaselineTests(unittest.TestCase):
    def test_subspace_compatible_baseline_returns_client_adapters(self):
        clients, base_weight = make_synthetic_manifold_clients(
            num_clients=4,
            num_classes=5,
            feature_dim=20,
            train_per_client=36,
            test_per_client=20,
            rank=2,
            seed=12,
        )
        local = run_local_lora(
            clients,
            base_weight,
            ranks=2,
            epochs=4,
            lr=0.25,
            batch_size=12,
            seed=0,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        geometry = LocalPrototypeGeometry().build(clients, num_classes=base_weight.shape[0])
        diagnostic = run_subspace_failure_diagnostic(
            clients,
            base_weight,
            local.adapters,
            d_geo=geometry.d_geo,
            diagnostic_threshold=-1.0,
        )
        result = run_subspace_compatible_baseline(
            clients,
            base_weight,
            local.adapters,
            diagnostic.compatibility,
            ranks=2,
            seed=0,
            dataset="pacs-debug",
            heterogeneity_setting="unit-test",
            round_id=1,
        )
        self.assertEqual(len(result.client_adapters), 4)
        self.assertEqual(len(result.per_client_metrics), 4)
        self.assertEqual(result.per_client_metrics[0]["method"], "Subspace-Compatible")


if __name__ == "__main__":
    unittest.main()
