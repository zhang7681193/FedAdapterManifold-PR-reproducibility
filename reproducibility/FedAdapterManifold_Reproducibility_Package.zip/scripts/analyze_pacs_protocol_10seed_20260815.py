from __future__ import annotations

import argparse
import csv
import itertools
import math
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Ten-seed PACS admission audit with BCa and exact inference.")
    parser.add_argument(
        "--internal-original",
        type=Path,
        default=ROOT / "results" / "fam_internal_generator_admission_v5_5seed_20260813",
    )
    parser.add_argument(
        "--internal-extension",
        type=Path,
        default=ROOT / "results" / "pacs_internal_seed5to9_20260815",
    )
    parser.add_argument(
        "--subspace-original",
        type=Path,
        default=ROOT / "results" / "subspace_reg_endpoint_admission_pacs_seed5to9_20260813",
    )
    parser.add_argument(
        "--subspace-extension",
        type=Path,
        default=ROOT / "results" / "pacs_subspacereg_seed0to4_20260815",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "results" / "pacs_protocol_10seed_audit_20260815",
    )
    parser.add_argument("--bootstrap-replicates", type=int, default=100000)
    parser.add_argument("--seed", type=int, default=20260815)
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def as_bool(value: object) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes"}


def normal_cdf(value: float) -> float:
    return 0.5 * (1.0 + math.erf(value / math.sqrt(2.0)))


def normal_ppf(probability: float) -> float:
    # Acklam's rational approximation, sufficient for bootstrap interval endpoints.
    if not 0.0 < probability < 1.0:
        return -math.inf if probability == 0.0 else math.inf
    a = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2,
         1.383577518672690e2, -3.066479806614716e1, 2.506628277459239]
    b = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2,
         6.680131188771972e1, -1.328068155288572e1]
    c = [-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838,
         -2.549732539343734, 4.374664141464968, 2.938163982698783]
    d = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996, 3.754408661907416]
    low, high = 0.02425, 1.0 - 0.02425
    if probability < low:
        q = math.sqrt(-2.0 * math.log(probability))
        return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / (
            ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q) + 1.0
        )
    if probability > high:
        q = math.sqrt(-2.0 * math.log(1.0 - probability))
        return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / (
            ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q) + 1.0
        )
    q = probability - 0.5
    r = q * q
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (
        (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r) + 1.0
    )


def bca_interval(values: np.ndarray, boot: np.ndarray, alpha: float = 0.05) -> tuple[float, float]:
    observed = float(values.mean())
    less = float(np.mean(boot < observed))
    equal = float(np.mean(boot == observed))
    z0 = normal_ppf(min(max(less + 0.5 * equal, 1e-8), 1.0 - 1e-8))
    jack = np.asarray([np.delete(values, index).mean() for index in range(len(values))])
    center = float(jack.mean())
    numerator = float(np.sum((center - jack) ** 3))
    denominator = 6.0 * float(np.sum((center - jack) ** 2)) ** 1.5
    acceleration = 0.0 if denominator == 0.0 else numerator / denominator
    probabilities = []
    for tail in (alpha / 2.0, 1.0 - alpha / 2.0):
        z = normal_ppf(tail)
        adjusted = normal_cdf(z0 + (z0 + z) / max(1e-12, 1.0 - acceleration * (z0 + z)))
        probabilities.append(min(max(adjusted, 0.0), 1.0))
    return tuple(float(value) for value in np.quantile(boot, probabilities))


def exact_sign_flip(values: np.ndarray) -> float:
    observed = float(values.mean())
    null = [
        float(np.mean(values * np.asarray(signs, dtype=np.float64)))
        for signs in itertools.product((-1.0, 1.0), repeat=len(values))
    ]
    return float(np.mean(np.asarray(null) >= observed - 1e-15))


def internal_units(roots: list[Path]) -> list[dict[str, object]]:
    units: list[dict[str, object]] = []
    for root in roots:
        path = root / "exact_receiver_admission_statistics" / "exact_receiver_units.csv"
        for row in read_csv(path):
            seed = int(row["seed"])
            run_dir = root / "pacs_resnet18" / f"seed_{seed}"
            certificates = read_csv(run_dir / "semantic_admission_exact_certificate.csv")
            selected = next(
                item
                for item in certificates
                if item["client_id"] == row["client_id"] and as_bool(item["selected"])
            )
            candidate = next(
                item
                for item in certificates
                if item["client_id"] == row["client_id"]
                and item["candidate_method"] == "FAM-InternalGeneratorEndpoint"
            )
            candidate_accuracy = float(candidate["test_accuracy_post_selection_audit"])
            anchor_accuracy = candidate_accuracy - float(row["fam_candidate_accuracy_gain_over_local"])
            deployed_accuracy = anchor_accuracy + float(row["selected_accuracy_gain_over_local"])
            units.append(
                {
                    "protocol": "Local/Geo/FAM",
                    "seed": seed,
                    "client_id": row["client_id"],
                    "gain": float(row["selected_accuracy_gain_over_local"]),
                    "anchor_accuracy": anchor_accuracy,
                    "candidate_accuracy": candidate_accuracy,
                    "deployed_accuracy": deployed_accuracy,
                    "admitted": as_bool(row["selected_nonlocal"]),
                    "harmful": as_bool(row["harmful_admission"]),
                    "uncertified": as_bool(row["uncertified_deployment"]),
                    "calibration_size": int(float(row["calibration_size"])),
                    "fam_local_discordant": int(float(selected["fam_vs_local_discordant"])),
                    "fam_geo_discordant": int(float(selected["fam_vs_geo_discordant"])),
                }
            )
    return units


def subspace_units(roots: list[Path]) -> list[dict[str, object]]:
    units: list[dict[str, object]] = []
    for root in roots:
        for path in sorted((root / "pacs_resnet18").glob("seed_*/subspacereg_anchor_endpoint_exact_certificate.csv")):
            seed = int(path.parent.name.split("_")[-1])
            certificates = read_csv(path)
            metrics = read_csv(path.parent / "per_client_metrics.csv")
            for client_id in sorted({row["client_id"] for row in certificates}):
                current = [row for row in certificates if row["client_id"] == client_id]
                selected = next(row for row in current if as_bool(row["selected"]))
                deployed = next(
                    row for row in metrics
                    if row["client_id"] == client_id
                    and row["method"] == "FedAdapterManifold-SubspaceRegAnchorEndpointAdmit"
                )
                anchor = next(
                    row for row in metrics
                    if row["client_id"] == client_id and row["method"] == "Subspace-Reg-LoRA-Visual-Port"
                )
                gain = float(deployed["accuracy"]) - float(anchor["accuracy"])
                candidate = next(
                    row
                    for row in current
                    if row["candidate_method"] == "FAM-InternalSemanticEndpoint"
                )
                units.append(
                    {
                        "protocol": "Subspace-Reg/FAM",
                        "seed": seed,
                        "client_id": client_id,
                        "gain": gain,
                        "anchor_accuracy": float(anchor["accuracy"]),
                        "candidate_accuracy": float(candidate["test_accuracy_post_selection_audit"]),
                        "deployed_accuracy": float(deployed["accuracy"]),
                        "admitted": selected["selected_method"] != "Subspace-Reg-LoRA-Visual-Port",
                        "harmful": gain < -1e-12,
                        "uncertified": False,
                        "calibration_size": int(float(selected["calibration_size"])),
                        "fam_local_discordant": int(float(selected["fam_vs_local_discordant"])),
                        "fam_geo_discordant": int(float(selected["fam_vs_geo_discordant"])),
                    }
                )
    return units


def summarize(protocol: str, units: list[dict[str, object]], n_boot: int, rng: np.random.Generator) -> dict[str, object]:
    seeds = sorted({int(row["seed"]) for row in units})
    if seeds != list(range(10)):
        raise RuntimeError(f"{protocol}: expected seeds 0--9, found {seeds}")
    if len(units) != 40:
        raise RuntimeError(f"{protocol}: expected 40 client-seed units, found {len(units)}")
    seed_values = np.asarray(
        [np.mean([float(row["gain"]) for row in units if int(row["seed"]) == seed]) for seed in seeds],
        dtype=np.float64,
    )
    boot = np.asarray(
        [rng.choice(seed_values, size=len(seed_values), replace=True).mean() for _ in range(n_boot)],
        dtype=np.float64,
    )
    percentile = tuple(float(value) for value in np.quantile(boot, [0.025, 0.975]))
    bca = bca_interval(seed_values, boot)
    unit_gains = np.asarray([float(row["gain"]) for row in units])
    return {
        "protocol": protocol,
        "seed_count": len(seeds),
        "client_seed_units": len(units),
        "mean_gain": float(seed_values.mean()),
        "mean_anchor_accuracy": float(np.mean([float(row["anchor_accuracy"]) for row in units])),
        "mean_candidate_accuracy": float(np.mean([float(row["candidate_accuracy"]) for row in units])),
        "mean_deployed_accuracy": float(np.mean([float(row["deployed_accuracy"]) for row in units])),
        "percentile_ci_low": percentile[0],
        "percentile_ci_high": percentile[1],
        "bca_ci_low": bca[0],
        "bca_ci_high": bca[1],
        "exact_sign_flip_p_one_sided": exact_sign_flip(seed_values),
        "seed_wins": int(np.sum(seed_values > 1e-12)),
        "seed_ties": int(np.sum(np.abs(seed_values) <= 1e-12)),
        "seed_losses": int(np.sum(seed_values < -1e-12)),
        "unit_wins": int(np.sum(unit_gains > 1e-12)),
        "unit_ties": int(np.sum(np.abs(unit_gains) <= 1e-12)),
        "unit_losses": int(np.sum(unit_gains < -1e-12)),
        "admitted_receivers": sum(bool(row["admitted"]) for row in units),
        "harmful_admissions": sum(bool(row["harmful"]) for row in units),
        "uncertified_deployments": sum(bool(row["uncertified"]) for row in units),
        "calibration_size_min": min(int(row["calibration_size"]) for row in units),
        "calibration_size_max": max(int(row["calibration_size"]) for row in units),
        "fam_local_discordance_mean": float(np.mean([int(row["fam_local_discordant"]) for row in units])),
        "fam_geo_discordance_mean": float(np.mean([int(row["fam_geo_discordant"]) for row in units])),
    }


def main() -> int:
    args = parse_args()
    rng = np.random.default_rng(args.seed)
    internal = internal_units([args.internal_original.resolve(), args.internal_extension.resolve()])
    subspace = subspace_units([args.subspace_extension.resolve(), args.subspace_original.resolve()])
    rows = [
        summarize("Local/Geo/FAM", internal, args.bootstrap_replicates, rng),
        summarize("Subspace-Reg/FAM", subspace, args.bootstrap_replicates, rng),
    ]
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / "pacs_10seed_protocol_summary.csv", rows)
    write_csv(output / "pacs_10seed_client_seed_units.csv", internal + subspace)
    report = [
        "# PACS ten-seed receiver-admission audit",
        "",
        "Both protocols combine their original frozen five-seed confirmation with the complementary independent seed extension. No result-dependent threshold, endpoint rule, or calibration budget was changed.",
        "",
    ]
    for row in rows:
        report.extend(
            [
                f"## {row['protocol']}",
                "",
                f"- Mean gain: {row['mean_gain']:+.6f}.",
                f"- Anchor / candidate / deployed accuracy: {row['mean_anchor_accuracy']:.6f} / {row['mean_candidate_accuracy']:.6f} / {row['mean_deployed_accuracy']:.6f}.",
                f"- Percentile 95% CI: [{row['percentile_ci_low']:+.6f}, {row['percentile_ci_high']:+.6f}].",
                f"- BCa 95% CI: [{row['bca_ci_low']:+.6f}, {row['bca_ci_high']:+.6f}].",
                f"- Exact one-sided seed sign-flip p: {row['exact_sign_flip_p_one_sided']:.6f}.",
                f"- Seed W/T/L: {row['seed_wins']}/{row['seed_ties']}/{row['seed_losses']}; client-seed W/T/L: {row['unit_wins']}/{row['unit_ties']}/{row['unit_losses']}.",
                f"- Admissions: {row['admitted_receivers']}/40; harmful: {row['harmful_admissions']}; uncertified: {row['uncertified_deployments']}.",
                f"- Calibration n: {row['calibration_size_min']}--{row['calibration_size_max']}; mean FAM/Local discordance: {row['fam_local_discordance_mean']:.2f}; mean FAM/Geo discordance: {row['fam_geo_discordance_mean']:.2f}.",
                "",
            ]
        )
    (output / "pacs_10seed_protocol_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
