from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path


PACKAGES = (
    ("01_upload_files", False),
    ("02_latex_source", True),
    ("03_reproducibility", False),
    ("04_frozen_geometry_payload", False),
)


def package_files(
    root: Path,
    *,
    exclude_build: bool,
    include_checksum: bool,
) -> list[Path]:
    files: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix == ".pyc":
            continue
        relative = path.relative_to(root)
        if not include_checksum and path.name == "SHA256SUMS.txt":
            continue
        if exclude_build and relative.parts and relative.parts[0].startswith("build_"):
            continue
        files.append(path)
    return sorted(files, key=lambda item: item.as_posix())


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_checksums(root: Path, *, exclude_build: bool) -> None:
    rows = [
        f"{sha256(path)}  {path.relative_to(root).as_posix()}"
        for path in package_files(
            root,
            exclude_build=exclude_build,
            include_checksum=False,
        )
    ]
    (root / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n", encoding="utf-8")


def write_zip(root: Path, destination: Path, *, exclude_build: bool, base: Path) -> None:
    if destination.resolve().parent != base:
        raise ValueError(f"unsafe ZIP target: {destination}")
    if destination.exists():
        destination.unlink()
    with zipfile.ZipFile(
        destination,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=6,
        allowZip64=True,
    ) as archive:
        for path in package_files(
            root,
            exclude_build=exclude_build,
            include_checksum=True,
        ):
            archive.write(path, f"{root.name}/{path.relative_to(root).as_posix()}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Rebuild the final FAM submission archives")
    parser.add_argument("--package-root", required=True)
    args = parser.parse_args()
    base = Path(args.package_root).resolve()

    for name, exclude_build in PACKAGES:
        write_checksums(base / name, exclude_build=exclude_build)

    archive_summary: list[dict[str, int | str]] = []
    for name, exclude_build in PACKAGES:
        destination = base / f"{name}.zip"
        write_zip(
            base / name,
            destination,
            exclude_build=exclude_build,
            base=base,
        )
        archive_summary.append(
            {"archive": destination.name, "bytes": destination.stat().st_size}
        )

    root_files: list[Path] = []
    for name, exclude_build in PACKAGES:
        root_files.extend(
            package_files(
                base / name,
                exclude_build=exclude_build,
                include_checksum=False,
            )
        )
    root_files.extend(
        path
        for path in base.iterdir()
        if path.is_file() and path.name != "SHA256SUMS.txt"
    )
    rows = [
        f"{sha256(path)}  {path.relative_to(base).as_posix()}"
        for path in sorted(root_files, key=lambda item: item.as_posix())
    ]
    (base / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n", encoding="utf-8")
    print(json.dumps(archive_summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
