from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fedadaptermanifold.function_space_transport import (
    audit_function_transport_risk,
    cross_entropy_from_logits,
    fit_convex_expert_teacher,
)


def _correct_logits(labels: np.ndarray, margin: float) -> np.ndarray:
    values = np.full((labels.size, 2), -float(margin), dtype=np.float64)
    values[np.arange(labels.size), labels] = float(margin)
    return values


def validate() -> dict:
    labels = np.asarray([0, 1] * 20, dtype=np.int64)
    folds = np.asarray([0, 0, 1, 1] * 10, dtype=np.int64)
    local = np.zeros((labels.size, 2), dtype=np.float64)
    donor_a = _correct_logits(labels, 2.5)
    donor_b = _correct_logits(labels, 2.5)
    donor_a[20:] = _correct_logits(1 - labels[20:], 2.5)
    donor_b[:20] = _correct_logits(1 - labels[:20], 2.5)
    geo_only = 0.5 * donor_a + 0.5 * donor_b
    prototype_fam = _correct_logits(labels, 2.5)
    experts = np.stack([local, geo_only, prototype_fam], axis=1)
    teacher = fit_convex_expert_teacher(
        experts,
        labels,
        folds,
        anchor_logits=local,
        expert_prior=np.asarray([0.5, 0.25, 0.25]),
        kl_strength=0.001,
        fold_temperature=0.05,
    )
    rng = np.random.default_rng(20260815)
    student = teacher.teacher_logits + rng.normal(
        scale=0.005, size=teacher.teacher_logits.shape
    )
    risk = audit_function_transport_risk(
        local,
        teacher.teacher_logits,
        student,
        labels,
        folds,
    )

    donor_updates = np.asarray([-1.0, 1.0])
    parameter_average = float(np.mean(donor_updates))
    parameter_endpoint = parameter_average ** 2
    function_average = float(np.mean(donor_updates ** 2))
    curvature_gap = abs(parameter_endpoint - function_average)
    hessian_bound = 2.0 / 2.0 * float(
        np.mean((donor_updates - parameter_average) ** 2)
    )
    report = {
        "ft1_parameter_function_gap": curvature_gap,
        "ft1_upper_bound": hessian_bound,
        "ft1_bound_holds": curvature_gap <= hessian_bound + 1e-12,
        "local_loss": cross_entropy_from_logits(local, labels),
        "geo_only_loss": cross_entropy_from_logits(geo_only, labels),
        "teacher_loss": cross_entropy_from_logits(teacher.teacher_logits, labels),
        "student_loss": cross_entropy_from_logits(student, labels),
        "expert_weights": teacher.expert_weights.tolist(),
        "teacher_optimality_gap": teacher.optimality_gap,
        "teacher_improves_every_fold": teacher.improves_every_training_fold,
        "student_improves_every_fold": risk.improves_every_training_fold,
        "ft3_lipschitz_certified": risk.certified_positive_utility,
        "synthetic_mechanism_passed": bool(
            curvature_gap > 0.0
            and curvature_gap <= hessian_bound + 1e-12
            and teacher.expert_weights[2] > 0.95
            and teacher.improves_every_training_fold
            and risk.improves_every_training_fold
        ),
        "uses_calibration_or_test_for_construction": False,
    }
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Synthetic function-transport validation")
    parser.add_argument("--output", default="")
    args = parser.parse_args(argv)
    report = validate()
    if args.output:
        path = Path(args.output)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["synthetic_mechanism_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
