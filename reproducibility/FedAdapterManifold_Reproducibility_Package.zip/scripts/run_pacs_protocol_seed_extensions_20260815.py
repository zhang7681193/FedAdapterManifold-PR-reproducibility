from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

import yaml


ROOT = Path(__file__).resolve().parents[1]
PYTHON = Path(sys.executable)
INTERNAL_STAGE = ROOT / "staging_internal"
SUBSPACE_STAGE = ROOT / "staging_subspace_reg_endpoint_v2_20260813"

INTERNAL_REFERENCE = (
    ROOT
    / "results"
    / "fam_internal_generator_admission_v5_5seed_20260813"
    / "configs"
    / "pacs_resnet18"
    / "seed_0.yaml"
)
SUBSPACE_REFERENCE = (
    ROOT
    / "results"
    / "subspace_reg_endpoint_admission_pacs_seed5to9_20260813"
    / "configs"
    / "seed_5.yaml"
)
GEOMETRY_CONFIGS_0_TO_4 = (
    ROOT / "results" / "fam_internal_generator_admission_v5_5seed_20260813" / "configs" / "pacs_resnet18"
)
GEOMETRY_CONFIGS_5_TO_9 = (
    ROOT / "results" / "subspace_reg_endpoint_admission_pacs_seed5to9_20260813" / "configs"
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Extend both frozen PACS receiver-admission confirmations to ten independent seeds."
    )
    parser.add_argument(
        "--internal-output",
        type=Path,
        default=ROOT / "results" / "pacs_internal_seed5to9_20260815",
    )
    parser.add_argument(
        "--subspace-output",
        type=Path,
        default=ROOT / "results" / "pacs_subspacereg_seed0to4_20260815",
    )
    parser.add_argument(
        "--phase",
        choices=["all", "internal", "subspace"],
        default="all",
    )
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--force", action="store_true")
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_yaml(path: Path) -> dict:
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def write_yaml(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(value, sort_keys=True), encoding="utf-8")


def geometry_path(seed: int) -> str:
    if seed <= 4:
        source = GEOMETRY_CONFIGS_0_TO_4 / f"seed_{seed}.yaml"
    else:
        source = GEOMETRY_CONFIGS_5_TO_9 / f"seed_{seed}.yaml"
    if not source.is_file():
        raise FileNotFoundError(source)
    value = str(read_yaml(source)["geometry_outputs_dir"])
    path = Path(value)
    if not path.is_dir():
        raise FileNotFoundError(f"Missing frozen geometry for seed {seed}: {path}")
    return str(path.resolve())


def staged_hashes(stage: Path, extra: list[Path]) -> dict[str, str]:
    paths = [
        stage / "fedadaptermanifold" / "run_experiment.py",
        stage / "fedadaptermanifold" / "signed_admissibility.py",
        stage / "fedadaptermanifold" / "geometry.py",
        *extra,
    ]
    return {str(path.relative_to(stage)): sha256(path) for path in paths}


def write_manifest(
    output: Path,
    protocol: str,
    seeds: list[int],
    reference: Path,
    stage: Path,
    prepared: list[Path],
    extra_frozen: list[Path],
) -> None:
    manifest = {
        "protocol": protocol,
        "purpose": "independent seed extension; no result-dependent parameter change",
        "seeds": seeds,
        "reference_config": str(reference.resolve()),
        "reference_config_sha256": sha256(reference),
        "geometry_protocol": "same per-seed frozen FedAvg geometry family as the original confirmation",
        "selection_data": "adapter-training plus declared disjoint held-out calibration only",
        "test_used_for_selection": False,
        "staged_implementation": str(stage.resolve()),
        "staged_hashes": staged_hashes(stage, extra_frozen),
        "prepared_configs": {
            str(path.relative_to(output)): {"sha256": sha256(path)} for path in prepared
        },
    }
    text = json.dumps(manifest, indent=2, sort_keys=True)
    (output / "frozen_seed_extension_manifest.json").write_text(text + "\n", encoding="utf-8")
    (output / "frozen_seed_extension_manifest.sha256").write_text(
        hashlib.sha256(text.encode("utf-8")).hexdigest() + "\n", encoding="ascii"
    )


def run_config(stage: Path, config: Path, log: Path, force: bool, done: list[Path]) -> None:
    if all(path.is_file() for path in done) and not force:
        print(f"SKIP complete: {config}", flush=True)
        return
    env = os.environ.copy()
    env["PYTHONPATH"] = os.pathsep.join([str(stage), str(ROOT)])
    log.parent.mkdir(parents=True, exist_ok=True)
    print(f"RUN {config}", flush=True)
    with log.open("w", encoding="utf-8") as stream:
        completed = subprocess.run(
            [str(PYTHON), "-m", "fedadaptermanifold.run_experiment", "--config", str(config)],
            cwd=stage,
            env=env,
            stdout=stream,
            stderr=subprocess.STDOUT,
            check=False,
        )
    if completed.returncode != 0:
        raise RuntimeError(f"Run failed ({completed.returncode}); inspect {log}")


def aggregate(root: Path, seeds: list[int], filenames: list[str]) -> None:
    for filename in filenames:
        rows: list[dict[str, str]] = []
        for seed in seeds:
            path = root / "pacs_resnet18" / f"seed_{seed}" / filename
            if not path.is_file():
                continue
            with path.open(newline="", encoding="utf-8-sig") as stream:
                rows.extend(csv.DictReader(stream))
        if not rows:
            continue
        fields = sorted({key for row in rows for key in row})
        with (root / f"all_seed_{filename}").open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)


def prepare_internal(output: Path) -> list[Path]:
    reference = read_yaml(INTERNAL_REFERENCE)
    prepared: list[Path] = []
    for seed in range(5, 10):
        config = dict(reference)
        run_dir = output / "pacs_resnet18" / f"seed_{seed}"
        config.update(
            {
                "seed": seed,
                "geometry_outputs_dir": geometry_path(seed),
                "output_dir": str(run_dir.resolve()),
                "feature_cache_dir": str((ROOT / "results" / "feature_cache" / "pacs_resnet18_pretrained").resolve()),
                "heterogeneity_setting": (
                    "pacs-resnet18-pretrained-unfrozen-active-sparse30-round9-"
                    "internal-manifold-generator-v5-seed5to9-extension"
                ),
            }
        )
        target = output / "configs" / "pacs_resnet18" / f"seed_{seed}.yaml"
        write_yaml(target, config)
        prepared.append(target)
    output.mkdir(parents=True, exist_ok=True)
    write_manifest(
        output,
        "canonical-local-geo-fam-v5-independent-seed-extension",
        list(range(5, 10)),
        INTERNAL_REFERENCE,
        INTERNAL_STAGE,
        prepared,
        [INTERNAL_STAGE / "run_internal_generator_confirmation.py"],
    )
    return prepared


def prepare_subspace(output: Path) -> list[Path]:
    reference = read_yaml(SUBSPACE_REFERENCE)
    prepared: list[Path] = []
    for seed in range(0, 5):
        config = dict(reference)
        run_dir = output / "pacs_resnet18" / f"seed_{seed}"
        config.update(
            {
                "seed": seed,
                "geometry_outputs_dir": geometry_path(seed),
                "output_dir": str(run_dir.resolve()),
                "feature_cache_dir": str((ROOT / "results" / "feature_cache" / "pacs_resnet18_pretrained").resolve()),
                "heterogeneity_setting": (
                    "pacs-domain-split-subspace-reg-anchor-endpoint-"
                    "training-fixed-cal20-seed0to4-extension"
                ),
            }
        )
        target = output / "configs" / f"seed_{seed}.yaml"
        write_yaml(target, config)
        prepared.append(target)
    output.mkdir(parents=True, exist_ok=True)
    write_manifest(
        output,
        "subspace-reg-anchor-endpoint-admission-v2-independent-seed-extension",
        list(range(0, 5)),
        SUBSPACE_REFERENCE,
        SUBSPACE_STAGE,
        prepared,
        [
            SUBSPACE_STAGE / "run_subspace_reg_endpoint_admission_confirmation.py",
            SUBSPACE_STAGE / "analyze_subspace_reg_endpoint_admission.py",
        ],
    )
    return prepared


def main() -> int:
    args = parse_args()
    internal_output = args.internal_output.resolve()
    subspace_output = args.subspace_output.resolve()
    if args.phase in {"all", "internal"}:
        prepared = prepare_internal(internal_output)
        if not args.prepare_only:
            for seed, config in zip(range(5, 10), prepared):
                run_dir = internal_output / "pacs_resnet18" / f"seed_{seed}"
                run_config(
                    INTERNAL_STAGE,
                    config,
                    internal_output / "logs" / f"seed_{seed}.log",
                    args.force,
                    [run_dir / "metrics.csv", run_dir / "semantic_admission_exact_certificate.csv"],
                )
            aggregate(
                internal_output,
                list(range(5, 10)),
                [
                    "metrics.csv",
                    "per_client_metrics.csv",
                    "semantic_admission_exact_certificate.csv",
                    "semantic_generator_training_screen.csv",
                ],
            )
            subprocess.run(
                [
                    str(PYTHON),
                    str(ROOT / "scripts" / "analyze_exact_receiver_admission.py"),
                    "--result-root",
                    str(internal_output),
                    "--certificate-file",
                    "semantic_admission_exact_certificate.csv",
                    "--bootstrap-replicates",
                    "50000",
                    "--seed",
                    "20260815",
                ],
                cwd=ROOT,
                check=True,
            )
    if args.phase in {"all", "subspace"}:
        prepared = prepare_subspace(subspace_output)
        if not args.prepare_only:
            for seed, config in zip(range(0, 5), prepared):
                run_dir = subspace_output / "pacs_resnet18" / f"seed_{seed}"
                run_config(
                    SUBSPACE_STAGE,
                    config,
                    subspace_output / "logs" / f"seed_{seed}.log",
                    args.force,
                    [run_dir / "metrics.csv", run_dir / "subspacereg_anchor_endpoint_exact_certificate.csv"],
                )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
