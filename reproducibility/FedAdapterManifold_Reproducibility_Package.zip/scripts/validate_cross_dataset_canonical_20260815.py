from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
import yaml


EXPECTED_DATASETS = {
    "domainnetmini_clip_60class": 6,
    "officehome_clip_full": 4,
}
EXPECTED_SEEDS = tuple(range(5))
EXPECTED_GENERATORS = {
    "FAM-InternalSemanticGenerator",
    "FAM-ReceiverAction-core",
    "FAM-ReceiverAction-column",
    "FAM-ReceiverAction-row",
    "FAM-ReceiverAction-tangent",
    "FAM-ReceiverAction-full",
}
EXPECTED_ENDPOINTS = {
    "Local-LoRA",
    "Geo-only-Agg",
    "FAM-InternalGeneratorEndpoint",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Independently validate the frozen cross-dataset canonical admission audit."
    )
    parser.add_argument("--result-root", required=True, type=Path)
    return parser.parse_args()


def _as_bool(series: pd.Series) -> pd.Series:
    return series.astype(str).str.lower().map({"true": True, "false": False})


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _exact_one_sided_sign_p(beneficial: int, harmful: int) -> float:
    discordant = beneficial + harmful
    # The frozen certificate uses the conservative directional convention:
    # a candidate with no strict majority of beneficial discordances receives
    # p=1 instead of a numerically smaller, but non-actionable, upper tail.
    if discordant == 0 or beneficial <= harmful:
        return 1.0
    return sum(math.comb(discordant, k) for k in range(beneficial, discordant + 1)) / 2**discordant


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def _numeric_equal(left: float, right: float, atol: float = 1e-12) -> bool:
    return bool(np.isclose(float(left), float(right), atol=atol, rtol=0.0, equal_nan=True))


def _validate_protocol(root: Path) -> dict:
    protocol_path = root / "preregistered_protocol.json"
    digest_path = root / "preregistered_protocol.sha256"
    _require(protocol_path.is_file(), f"Missing {protocol_path}")
    _require(digest_path.is_file(), f"Missing {digest_path}")
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    expected_digest = digest_path.read_text(encoding="ascii").strip()
    # The preregistration hashes the canonical sorted JSON before the final newline.
    canonical = json.dumps(protocol, indent=2, sort_keys=True).encode("utf-8")
    _require(hashlib.sha256(canonical).hexdigest() == expected_digest, "Protocol digest mismatch")
    _require(protocol["protocol"] == "cross-dataset-bank6-serial-holm-canonical-v1", "Wrong protocol")
    _require(protocol["seeds"] == list(EXPECTED_SEEDS), "Unexpected seed registry")
    _require(protocol["selection_constraint"].startswith("No test label"), "Selection constraint missing")
    return protocol


def _validate_config(path: Path, dataset_key: str, seed: int) -> dict:
    config = yaml.safe_load(path.read_text(encoding="utf-8"))
    required = {
        "seed": seed,
        "run_decoupled_transport": True,
        "decoupled_transport_modes": "core,column,row,tangent,full",
        "semantic_admission_internal_generator_screening": True,
        "semantic_admission_generator_screening": False,
        "semantic_admission_anchored_action_screening": False,
        "semantic_admission_crossfit_anchored_action_screening": False,
        "semantic_admission_exact_mode": "hierarchical-holm-deduplicated",
        "semantic_admission_exact_certificate": True,
        "semantic_admission_graph_scale_policy": "topology-calibrated",
        "semantic_admission_topology_top_k": 2,
        "semantic_admission_topology_neighbor_mass": 1.0,
        "run_recent_lora_baselines": False,
        "recent_lora_methods": "",
    }
    for key, expected in required.items():
        _require(config.get(key) == expected, f"{dataset_key}/seed_{seed}: {key}={config.get(key)!r}")
    _require(str(config["output_dir"]).endswith(f"{dataset_key}\\seed_{seed}"), "Output path mismatch")
    return config


def _validate_bank(screen: pd.DataFrame, dataset_key: str, seed: int, clients: int) -> None:
    _require(len(screen) == clients * 6, f"{dataset_key}/seed_{seed}: bank row count")
    _require(not screen.isna().any().any(), f"{dataset_key}/seed_{seed}: null in bank manifest")
    _require(set(screen["candidate_generator"]) == EXPECTED_GENERATORS, "Generator family mismatch")
    _require((_as_bool(screen["calibration_used"]) == False).all(), "Calibration used in bank construction")
    _require((_as_bool(screen["test_used"]) == False).all(), "Test used in bank construction")
    _require((screen["selection_split"] == "adapter_training").all(), "Wrong bank selection split")
    for client_id, block in screen.groupby("client_id", sort=False):
        _require(len(block) == 6, f"{dataset_key}/seed_{seed}/{client_id}: bank size != 6")
        _require(set(block["candidate_generator"]) == EXPECTED_GENERATORS, "Incomplete receiver bank")
        _require(block["candidate_sha256"].nunique() == 6, "Duplicate bank tensor hash")
        selected = block[_as_bool(block["selected"])]
        _require(len(selected) == 1, "Training screen must select exactly one endpoint")
        _require(selected.iloc[0]["candidate_generator"] == selected.iloc[0]["selected_generator"], "Selected label mismatch")


def _validate_graph_support(run_dir: Path, weights: pd.DataFrame, dataset_key: str, seed: int) -> None:
    graph = np.load(run_dir / "geometry_outputs" / "geometry_graph_round_4.npy")
    _require(graph.ndim == 2 and graph.shape[0] == graph.shape[1], "Invalid geometry graph")
    _require(np.isfinite(graph).all(), "Non-finite geometry graph")
    _require(np.allclose(graph.sum(axis=1), 1.0, atol=1e-8), "Geometry graph is not row stochastic")
    _require((weights["graph_scale_policy"] == "topology-calibrated").all(), "Wrong graph policy")
    _require((weights["topology_top_k"].astype(int) == 2).all(), "Wrong topology top-k")
    for (round_id, receiver), block in weights.groupby(["round", "receiver_client"], sort=False):
        _require(_numeric_equal(block["admission_weight"].sum(), 1.0, atol=2e-8), "Admission weights do not sum to one")
        receiver_idx = int(str(receiver).split("_")[-1])
        positive_nonself = 0
        for row in block.itertuples(index=False):
            donor_idx = int(str(row.donor_client).split("_")[-1])
            if donor_idx != receiver_idx and float(row.admission_weight) > 1e-14:
                positive_nonself += 1
                _require(graph[receiver_idx, donor_idx] > 0.0, "Invented edge outside supplied graph support")
        _require(positive_nonself <= 2, f"{dataset_key}/seed_{seed}: exceeds topology top-k")


def _validate_certificate(cert: pd.DataFrame, dataset_key: str, seed: int, clients: int) -> dict:
    _require(len(cert) == clients * 3, f"{dataset_key}/seed_{seed}: certificate row count")
    _require(not cert[["client_id", "candidate_method", "test_accuracy_post_selection_audit"]].isna().any().any(), "Missing certificate field")
    _require(set(cert["candidate_method"]) == EXPECTED_ENDPOINTS, "Endpoint set mismatch")
    _require((_as_bool(cert["candidate_training_fixed"]) == True).all(), "Candidate was not training-fixed")
    _require((_as_bool(cert["test_used_for_selection"]) == False).all(), "Test used for selection")
    _require((cert["certificate_hierarchy"] == "deduplicate;holm_local_safety;serial_fam_vs_geo").all(), "Wrong hierarchy")
    selected_units = 0
    harmful = 0
    uncertified = 0
    raw_fam_gains: list[float] = []
    deployed_gains: list[float] = []
    for client_id, block in cert.groupby("client_id", sort=False):
        _require(len(block) == 3 and set(block["candidate_method"]) == EXPECTED_ENDPOINTS, "Incomplete endpoint block")
        selected = block[_as_bool(block["selected"])]
        _require(len(selected) == 1, "Exactly one endpoint must be deployed")
        local = block[block["candidate_method"] == "Local-LoRA"].iloc[0]
        geo = block[block["candidate_method"] == "Geo-only-Agg"].iloc[0]
        fam = block[block["candidate_method"] == "FAM-InternalGeneratorEndpoint"].iloc[0]
        chosen = selected.iloc[0]
        _require(chosen["candidate_method"] == chosen["selected_method"], "Selected method mismatch")
        local_acc = float(local["test_accuracy_post_selection_audit"])
        chosen_acc = float(chosen["test_accuracy_post_selection_audit"])
        raw_fam_gains.append(float(fam["test_accuracy_post_selection_audit"]) - local_acc)
        deployed_gains.append(chosen_acc - local_acc)
        if bool(_as_bool(pd.Series([chosen["fell_back_to_local"]])).iloc[0]):
            _require(chosen["candidate_method"] == "Local-LoRA", "Fallback is not byte-identical Local endpoint")
            _require(_numeric_equal(chosen_acc, local_acc), "Fallback accuracy differs from Local")
        else:
            selected_units += 1
            harmful += int(chosen_acc < local_acc - 1e-12)
            if chosen["candidate_method"] == "Geo-only-Agg":
                uncertified += int(not bool(chosen["geo_deployable"]))
            elif chosen["candidate_method"] == "FAM-InternalGeneratorEndpoint":
                uncertified += int(not bool(chosen["fam_deployable"]))
        for prefix in ("geo_only_agg", "fam_vs_local", "fam_vs_geo"):
            beneficial = int(local[f"{prefix}_beneficial"])
            harmful_count = int(local[f"{prefix}_harmful"])
            reported = float(local[f"{prefix}_p_value"])
            recomputed = _exact_one_sided_sign_p(beneficial, harmful_count)
            _require(_numeric_equal(reported, recomputed), f"Exact p-value mismatch: {prefix}")
    return {
        "dataset_key": dataset_key,
        "seed": seed,
        "receivers": clients,
        "admitted_receivers": selected_units,
        "harmful_admissions": harmful,
        "uncertified_deployments": uncertified,
        "raw_fam_mean_gain": float(np.mean(raw_fam_gains)),
        "deployed_mean_gain": float(np.mean(deployed_gains)),
        "raw_fam_positive_tie_negative": [
            int(np.sum(np.asarray(raw_fam_gains) > 1e-12)),
            int(np.sum(np.abs(np.asarray(raw_fam_gains)) <= 1e-12)),
            int(np.sum(np.asarray(raw_fam_gains) < -1e-12)),
        ],
    }


def main() -> int:
    args = parse_args()
    root = args.result_root.resolve()
    _validate_protocol(root)
    summaries: list[dict] = []
    all_keys: list[tuple[str, int, str]] = []
    for dataset_key, clients in EXPECTED_DATASETS.items():
        for seed in EXPECTED_SEEDS:
            config_path = root / "configs" / dataset_key / f"seed_{seed}.yaml"
            run_dir = root / dataset_key / f"seed_{seed}"
            _require(config_path.is_file(), f"Missing {config_path}")
            _validate_config(config_path, dataset_key, seed)
            required_files = [
                run_dir / "metrics.csv",
                run_dir / "per_client_metrics.csv",
                run_dir / "semantic_generator_training_screen.csv",
                run_dir / "semantic_admission_exact_certificate.csv",
                run_dir / "semantic_admission_weights.csv",
                run_dir / "geometry_outputs" / "geometry_graph_round_4.npy",
            ]
            for path in required_files:
                _require(path.is_file(), f"Missing completed artifact: {path}")
            screen = pd.read_csv(required_files[2])
            cert = pd.read_csv(required_files[3])
            weights = pd.read_csv(required_files[4])
            _validate_bank(screen, dataset_key, seed, clients)
            _validate_graph_support(run_dir, weights, dataset_key, seed)
            summary = _validate_certificate(cert, dataset_key, seed, clients)
            summaries.append(summary)
            all_keys.extend((dataset_key, seed, str(client)) for client in cert["client_id"].drop_duplicates())
    _require(len(all_keys) == len(set(all_keys)) == 50, "Duplicate or missing dataset-seed-client key")
    summary_df = pd.DataFrame(summaries)
    dataset_summary = (
        summary_df.groupby("dataset_key", as_index=False)
        .agg(
            seeds=("seed", "nunique"),
            receivers=("receivers", "sum"),
            admitted_receivers=("admitted_receivers", "sum"),
            harmful_admissions=("harmful_admissions", "sum"),
            uncertified_deployments=("uncertified_deployments", "sum"),
            raw_fam_mean_gain=("raw_fam_mean_gain", "mean"),
            deployed_mean_gain=("deployed_mean_gain", "mean"),
        )
    )
    analysis = root / "independent_validation"
    analysis.mkdir(exist_ok=True)
    summary_df.to_csv(analysis / "seed_summary.csv", index=False)
    dataset_summary.to_csv(analysis / "dataset_summary.csv", index=False)
    report = {
        "status": "pass",
        "validator": str(Path(__file__).resolve()),
        "validator_sha256": _sha256(Path(__file__).resolve()),
        "result_root": str(root),
        "protocol_sha256": _sha256(root / "preregistered_protocol.json"),
        "units": 50,
        "datasets": dataset_summary.to_dict(orient="records"),
        "checks": {
            "bank_size_exactly_six": True,
            "training_only_generator_selection": True,
            "three_fixed_receiver_endpoints": True,
            "serial_holm_exact_p_values_recomputed": True,
            "test_not_used_for_selection": True,
            "immutable_local_fallback": True,
            "no_invented_graph_support": True,
            "no_duplicate_dataset_seed_client_keys": True,
        },
    }
    (analysis / "validation_report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
