from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate the single PR submission evidence registry.")
    parser.add_argument(
        "--registry",
        type=Path,
        default=ROOT / "paper_resubmit" / "final_evidence_registry.json",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "results" / "final_evidence_registry_audit_20260813",
    )
    parser.add_argument(
        "--require-final-ready",
        action="store_true",
        help="Exit nonzero while any required entry remains active or invalid.",
    )
    return parser.parse_args()


def _resolve_root(value: str, entry_id: str) -> Path:
    packaged = ROOT / "evidence" / entry_id
    if packaged.is_dir():
        resolved = packaged.resolve()
        if os.name == "nt" and not str(resolved).startswith("\\\\?\\"):
            return Path("\\\\?\\" + str(resolved))
        return resolved
    path = Path(value)
    return path if path.is_absolute() else ROOT / path


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _csv_rows(path: Path) -> int:
    with path.open(newline="", encoding="utf-8-sig") as stream:
        return sum(1 for _ in csv.DictReader(stream))


def main() -> int:
    args = parse_args()
    registry = json.loads(args.registry.read_text(encoding="utf-8"))
    rows: list[dict] = []
    hashes: list[dict] = []
    frozen_invalid = False
    required_active = False

    for entry in registry["entries"]:
        entry_id = entry["id"]
        status = entry["status"]
        required = bool(entry.get("required_for_final", False))
        submission_eligible = bool(entry.get("submission_eligible", True))
        root = _resolve_root(entry["root"], entry_id)
        failures: list[str] = []
        checked = 0
        if status == "frozen":
            for relative in entry.get("required_files", []):
                path = root / relative
                checked += 1
                if not path.is_file():
                    failures.append(f"missing:{relative}")
                else:
                    hashes.append(
                        {
                            "entry_id": entry_id,
                            "file": str(path),
                            "size": path.stat().st_size,
                            "sha256": _sha256(path),
                        }
                    )
            for check in entry.get("recursive_checks", []):
                matches = sorted(root.glob(check["glob"]))
                checked += 1
                expected = int(check["exact_count"])
                if len(matches) != expected:
                    failures.append(
                        f"glob_count:{check['glob']}:{len(matches)}!={expected}"
                    )
                for path in matches:
                    hashes.append(
                        {
                            "entry_id": entry_id,
                            "file": str(path),
                            "size": path.stat().st_size,
                            "sha256": _sha256(path),
                        }
                    )
            for check in entry.get("csv_checks", []):
                path = root / check["file"]
                checked += 1
                if not path.is_file():
                    failures.append(f"missing_csv:{check['file']}")
                    continue
                count = _csv_rows(path)
                if "exact_rows" in check and count != int(check["exact_rows"]):
                    failures.append(
                        f"csv_rows:{check['file']}:{count}!={int(check['exact_rows'])}"
                    )
                if "minimum_rows" in check and count < int(check["minimum_rows"]):
                    failures.append(
                        f"csv_min_rows:{check['file']}:{count}<{int(check['minimum_rows'])}"
                    )
            if checked == 0:
                failures.append("no_declared_checks")
            eligible = submission_eligible and not failures
            frozen_invalid = frozen_invalid or (submission_eligible and bool(failures))
        elif status == "active":
            eligible = False
            required_active = required_active or required
        elif status == "development":
            eligible = False
        else:
            failures.append(f"unknown_status:{status}")
            eligible = False
            frozen_invalid = True
        rows.append(
            {
                "entry_id": entry_id,
                "role": entry["role"],
                "status": status,
                "required_for_final": required,
                "submission_eligible": submission_eligible,
                "root": str(root),
                "checked_items": checked,
                "eligible_for_submission_tables": eligible,
                "failures": "|".join(failures),
            }
        )

    final_ready = not frozen_invalid and not required_active
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / "registry_validation.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    with (args.output / "frozen_evidence_hashes.csv").open("w", newline="", encoding="utf-8") as stream:
        fields = ["entry_id", "file", "size", "sha256"]
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(hashes)
    summary = {
        "registry_sha256": _sha256(args.registry),
        "frozen_invalid": frozen_invalid,
        "required_active": required_active,
        "final_ready": final_ready,
        "eligible_entries": [row["entry_id"] for row in rows if row["eligible_for_submission_tables"]],
        "ineligible_entries": [row["entry_id"] for row in rows if not row["eligible_for_submission_tables"]],
    }
    (args.output / "registry_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    report = [
        "# Final evidence registry audit",
        "",
        f"- Frozen evidence invalid: {frozen_invalid}.",
        f"- Required experiments still active: {required_active}.",
        f"- Final submission tables ready: {final_ready}.",
        "",
        "| Entry | Status | Required | Eligible | Failures |",
        "|---|---|---:|---:|---|",
    ]
    for row in rows:
        report.append(
            f"| {row['entry_id']} | {row['status']} | {row['required_for_final']} | "
            f"{row['eligible_for_submission_tables']} | {row['failures'] or '--'} |"
        )
    (args.output / "registry_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    if frozen_invalid:
        return 2
    if args.require_final_ready and not final_ready:
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
