from __future__ import annotations

import argparse
import csv
import hashlib
import json
import zipfile
from pathlib import Path

from docx import Document
from pypdf import PdfReader


ROOT = Path(__file__).resolve().parents[1]
CONFIRMATION_PROVIDER_SHA256 = (
    "03c38d946075d261ed48c3ab3f258be22ff5529812c780434ff999d9c586adc1"
)
TRAINING_EXPERT_PROTOCOL_SHA256 = (
    "436854ac0461fe830f8d2e8f7dfbf8349bb23045acf8357c01d59b453fa2b04d"
)
POWER_CONFIRMATION_PROTOCOL_SHA256 = (
    "ddb55089261670973d51d2a63c28e45526092684031d307c81f34ef83b6a9802"
)
POWER_CONFIRMATION_PROVIDER_SHA256 = (
    "60419a61177adbba1a048f9e39e570d8d82e800d945dce9a64ef20b31f3a9ba1"
)


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate the registry-driven final PR package.")
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "paper_resubmit" / "final_package_validation_20260813.md",
    )
    return parser.parse_args()


def validate_checksum_file(root: Path, checksum_path: Path) -> list[str]:
    errors: list[str] = []
    for line in checksum_path.read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        path = root / Path(relative)
        if not path.is_file():
            errors.append(f"missing checksum member: {path}")
        elif sha256(path) != expected:
            errors.append(f"checksum mismatch: {path}")
    return errors


def main() -> int:
    args = parse_args()
    package = args.package_root.resolve()
    errors: list[str] = []
    notes: list[str] = []

    audit = (package / "PACKAGE_AUDIT.md").read_text(encoding="utf-8")
    for token in ("Static validation: **PASS**", "Final evidence status: **READY**"):
        if token not in audit:
            errors.append(f"package audit missing token: {token}")
    if "## Errors\n\n- None." not in audit:
        errors.append("package audit does not report an empty error set")

    canonical = {
        package / "01_upload_files" / "Manuscript.pdf": ROOT
        / "paper_resubmit" / "fedadaptermanifold_pr_resubmit.pdf",
        package / "01_upload_files" / "Supplementary_Material.pdf": ROOT
        / "paper_resubmit" / "fedadaptermanifold_pr_resubmit_supplement.pdf",
        package / "01_upload_files" / "Cover_Letter.pdf": ROOT
        / "paper_resubmit" / "PR_D_26_08222_resubmission_cover_letter.pdf",
        package / "01_upload_files" / "FedAdapterManifold_Highlights.docx": ROOT
        / "paper_resubmit" / "ancillary" / "FedAdapterManifold_Highlights.docx",
        package / "01_upload_files" / "Declaration_of_Competing_Interests_No_Conflict.docx": ROOT
        / "paper_resubmit" / "ancillary" / "Declaration_of_Competing_Interests_No_Conflict.docx",
        package / "01_upload_files" / "FedAdapterManifold_Title_Page_with_Author_Details.docx": ROOT
        / "paper_resubmit" / "ancillary" / "FedAdapterManifold_Title_Page_with_Author_Details.docx",
        package / "01_upload_files" / "UPLOAD_MAP.md": ROOT
        / "paper_resubmit" / "ancillary" / "UPLOAD_MAP.md",
        package / "02_latex_source" / "fedadaptermanifold_pr_resubmit.tex": ROOT
        / "paper_resubmit" / "fedadaptermanifold_pr_resubmit.tex",
        package / "02_latex_source" / "fedadaptermanifold_pr_resubmit_supplement.tex": ROOT
        / "paper_resubmit" / "fedadaptermanifold_pr_resubmit_supplement.tex",
        package / "02_latex_source" / "fedadaptermanifold_upgrade_refs.bib": ROOT
        / "paper_resubmit" / "fedadaptermanifold_upgrade_refs.bib",
    }
    for packaged, source in canonical.items():
        if not packaged.is_file() or sha256(packaged) != sha256(source):
            errors.append(f"canonical mismatch: {packaged} != {source}")

    expected_pdfs = {
        package / "01_upload_files" / "Manuscript.pdf": (35, 35),
        # The 35-page limit applies to the regular manuscript. The separately
        # uploaded supplement is checked for non-emptiness and a sanity cap,
        # not a stale exact count that changes when an audit table is added.
        package / "01_upload_files" / "Supplementary_Material.pdf": (1, 80),
        package / "01_upload_files" / "Cover_Letter.pdf": (2, 2),
    }
    for path, (minimum_pages, maximum_pages) in expected_pdfs.items():
        reader = PdfReader(str(path))
        pages = len(reader.pages)
        width = float(reader.pages[0].mediabox.width)
        height = float(reader.pages[0].mediabox.height)
        notes.append(f"{path.name}: {pages} pages, {width:.1f} x {height:.1f} pt")
        if not minimum_pages <= pages <= maximum_pages:
            errors.append(
                f"unexpected page count: {path}: {pages} outside "
                f"[{minimum_pages}, {maximum_pages}]"
            )
        if abs(width - 612.0) > 0.5 or abs(height - 792.0) > 0.5:
            errors.append(f"non-Letter PDF: {path}")

    title = "FedAdapterManifold: Deciding When Federated Visual LoRA Adapters Are Safe to Share"
    highlights_path = package / "01_upload_files" / "FedAdapterManifold_Highlights.docx"
    highlights_document = Document(highlights_path)
    highlight_items = [
        paragraph.text.strip()
        for paragraph in highlights_document.paragraphs
        if paragraph.text.strip() and paragraph.text.strip() not in {"Highlights", title}
    ]
    if len(highlight_items) != 5:
        errors.append(f"highlights item count: {len(highlight_items)} != 5")
    for item in highlight_items:
        if len(item) > 85:
            errors.append(f"highlight exceeds 85 characters: {item}")
    notes.append(f"Highlights: {len(highlight_items)} items, max {max(map(len, highlight_items), default=0)} characters")

    for name in (
        "Declaration_of_Competing_Interests_No_Conflict.docx",
        "FedAdapterManifold_Title_Page_with_Author_Details.docx",
    ):
        document = Document(package / "01_upload_files" / name)
        text = "\n".join(paragraph.text for paragraph in document.paragraphs)
        if title not in text:
            errors.append(f"stale or missing manuscript title in {name}")

    for directory in (
        "01_upload_files",
        "02_latex_source",
        "03_reproducibility",
        "04_frozen_geometry_payload",
    ):
        root = package / directory
        checksum_path = root / "SHA256SUMS.txt"
        errors.extend(validate_checksum_file(root, checksum_path))
        archive_path = package / f"{directory}.zip"
        with zipfile.ZipFile(archive_path) as archive:
            bad = archive.testzip()
            if bad:
                errors.append(f"corrupt ZIP member: {archive_path}:{bad}")
            prefix = f"{directory}/"
            archived = {
                name[len(prefix) :]: sha256_bytes(archive.read(name))
                for name in archive.namelist()
                if name.startswith(prefix) and not name.endswith("/")
            }
        local = {}
        for path in root.rglob("*"):
            if not path.is_file() or path.suffix == ".pyc":
                continue
            relative = path.relative_to(root)
            if directory == "02_latex_source" and relative.parts[0].startswith("build_"):
                continue
            local[relative.as_posix()] = sha256(path)
        if archived != local:
            errors.append(f"ZIP/directory member mismatch: {archive_path}")
        notes.append(f"{archive_path.name}: {len(archived)} verified members")

    errors.extend(validate_checksum_file(package, package / "SHA256SUMS.txt"))

    registry = json.loads(
        (package / "03_reproducibility" / "audit" / "final_evidence_registry.json").read_text(
            encoding="utf-8"
        )
    )
    active_required = [
        entry["id"]
        for entry in registry["entries"]
        if entry.get("required_for_final") and entry.get("status") != "frozen"
    ]
    if active_required:
        errors.append(f"required entries are not frozen: {active_required}")

    compact_contract = package / "03_reproducibility" / "geometry_contract"
    payload_contract = package / "04_frozen_geometry_payload"
    for name in (
        "geometry_contract.json",
        "geometry_snapshot_manifest.csv",
        "geometry_file_manifest.csv",
    ):
        compact = compact_contract / name
        payload = payload_contract / name
        if not compact.is_file():
            errors.append(f"compact geometry contract missing: {name}")
        elif not payload.is_file():
            errors.append(f"payload geometry contract missing: {name}")
        elif sha256(compact) != sha256(payload):
            errors.append(f"geometry contract mismatch: {name}")
    snapshots = list((payload_contract / "snapshots").glob("*"))
    payload_files = list((payload_contract / "snapshots").glob("*/geometry_outputs/*"))
    if len(snapshots) != 45:
        errors.append(f"geometry snapshot count: {len(snapshots)} != 45")
    if len(payload_files) != 365:
        errors.append(f"geometry payload file count: {len(payload_files)} != 365")
    notes.append(
        f"Frozen geometry: {len(snapshots)} snapshots, {len(payload_files)} files"
    )

    confirmation_root = payload_contract / "officehome_confirmation_seed10_14"
    provider_registry_path = confirmation_root / "provider_snapshot_registry.json"
    if not provider_registry_path.is_file():
        errors.append("untouched-confirmation provider registry is missing")
    else:
        provider_hash = sha256(provider_registry_path)
        if provider_hash != CONFIRMATION_PROVIDER_SHA256:
            errors.append(
                "untouched-confirmation provider registry hash mismatch: "
                f"{provider_hash} != {CONFIRMATION_PROVIDER_SHA256}"
            )
        provider_registry = json.loads(provider_registry_path.read_text(encoding="utf-8"))
        provider_seeds = sorted(int(seed) for seed in provider_registry.get("seeds", []))
        if provider_seeds != [10, 11, 12, 13, 14]:
            errors.append(f"unexpected untouched-confirmation seeds: {provider_seeds}")
        provider_snapshots = provider_registry.get("snapshots", [])
        if len(provider_snapshots) != 5:
            errors.append(
                f"untouched-confirmation snapshot count: {len(provider_snapshots)} != 5"
            )
        confirmed_files = 0
        for snapshot in provider_snapshots:
            if snapshot.get("snapshot_status") != "frozen":
                errors.append(
                    f"provider seed {snapshot.get('seed')} is not marked frozen"
                )
            if not snapshot.get("no_calibration_or_test_used", False):
                errors.append(
                    f"provider seed {snapshot.get('seed')} is not training-only"
                )
            geometry_dir = confirmation_root / snapshot["relative_geometry_outputs"]
            for name, expected_hash in snapshot.get("output_sha256", {}).items():
                output_path = geometry_dir / name
                confirmed_files += 1
                if not output_path.is_file():
                    errors.append(f"missing untouched-confirmation output: {output_path}")
                elif sha256(output_path) != expected_hash:
                    errors.append(f"untouched-confirmation hash mismatch: {output_path}")
        if confirmed_files != 45:
            errors.append(
                f"untouched-confirmation output count: {confirmed_files} != 45"
            )
        notes.append(
            "Untouched confirmation: "
            f"{len(provider_snapshots)} frozen snapshots, {confirmed_files} hash-verified files"
        )

    confirmation_audit_path = (
        package
        / "03_reproducibility"
        / "evidence"
        / "officehome_function_transport_confirmation"
        / "confirmation_quality_audit.json"
    )
    if not confirmation_audit_path.is_file():
        errors.append("untouched-confirmation quality audit is missing")
    else:
        confirmation_audit = json.loads(
            confirmation_audit_path.read_text(encoding="utf-8")
        )
        if not confirmation_audit.get("passed", False):
            errors.append("untouched-confirmation quality audit did not pass")
        if confirmation_audit.get("check_count") != 35:
            errors.append(
                "untouched-confirmation audit check count: "
                f"{confirmation_audit.get('check_count')} != 35"
            )
        if confirmation_audit.get("failed_check_count") != 0:
            errors.append(
                "untouched-confirmation audit contains failed checks: "
                f"{confirmation_audit.get('failed_check_count')}"
            )
        notes.append(
            "Untouched confirmation audit: "
            f"{confirmation_audit.get('check_count', 0)} checks, "
            f"{confirmation_audit.get('failed_check_count', 0)} failures"
        )

    expert_root = (
        package
        / "03_reproducibility"
        / "evidence"
        / "officehome_training_expert_ablation"
    )
    expert_protocol_path = expert_root / "frozen_protocol.json"
    expert_report_path = expert_root / "expert_ablation_report.json"
    expert_rows_path = expert_root / "function_expert_ablation_all_seeds.csv"
    if not expert_protocol_path.is_file():
        errors.append("training-only expert-ablation protocol is missing")
    elif sha256(expert_protocol_path) != TRAINING_EXPERT_PROTOCOL_SHA256:
        errors.append("training-only expert-ablation protocol hash mismatch")
    else:
        protocol = json.loads(expert_protocol_path.read_text(encoding="utf-8"))
        if protocol.get("status") != "frozen_before_ablation_outputs":
            errors.append("training-only expert-ablation protocol is not frozen")
        if protocol.get("seeds") != [10, 11, 12, 13, 14]:
            errors.append("training-only expert-ablation seeds are not 10--14")
        if protocol.get("test_used_for_construction_selection_or_evaluation"):
            errors.append("training-only expert-ablation protocol used test data")
    if not expert_report_path.is_file():
        errors.append("training-only expert-ablation report is missing")
    else:
        expert_report = json.loads(expert_report_path.read_text(encoding="utf-8"))
        expected_report = {
            "receiver_seed_units": 20,
            "positive_seed_means": 5,
            "one_sided_seed_sign_p": 0.03125,
            "mean_fam_increment_given_geo": 0.0019616569642656183,
        }
        for key, expected in expected_report.items():
            value = expert_report.get(key)
            if value is None or abs(float(value) - float(expected)) > 1e-12:
                errors.append(
                    f"training-only expert report mismatch for {key}: {value} != {expected}"
                )
        ci = expert_report.get("seed_bootstrap_ci_fam_increment_given_geo", [])
        if len(ci) != 2 or float(ci[0]) <= 0.0:
            errors.append("training-only expert-ablation bootstrap interval is not positive")
        if not expert_report.get("stable_claim_gate_passed", False):
            errors.append("training-only expert-ablation stable claim gate failed")
        if expert_report.get("test_used_for_construction_selection_or_evaluation"):
            errors.append("training-only expert-ablation report records test use")
    if not expert_rows_path.is_file():
        errors.append("training-only expert-ablation receiver rows are missing")
    else:
        with expert_rows_path.open(newline="", encoding="utf-8") as handle:
            expert_rows = list(csv.DictReader(handle))
        positive_rows = sum(
            float(row["fam_increment_given_geo"]) > 0.0 for row in expert_rows
        )
        expert_seeds = sorted({int(row["seed"]) for row in expert_rows})
        if len(expert_rows) != 20 or positive_rows != 20:
            errors.append(
                "training-only expert-ablation receiver support: "
                f"{positive_rows}/{len(expert_rows)} != 20/20"
            )
        if expert_seeds != [10, 11, 12, 13, 14]:
            errors.append(f"training-only expert row seeds are invalid: {expert_seeds}")
        notes.append(
            "Training-only FAM|Geo audit: "
            f"{positive_rows}/{len(expert_rows)} positive receiver-seed units, "
            "5/5 positive seed means, no calibration/test forward"
        )

    power_root = (
        package
        / "03_reproducibility"
        / "evidence"
        / "officehome_top1_power_confirmation"
    )
    power_protocol_path = power_root / "frozen_protocol.json"
    power_report_path = power_root / "confirmation_report.json"
    power_validation_path = power_root / "independent_validation.json"
    power_units_path = power_root / "function_transport_top1_admission_all_seeds.csv"
    if not power_protocol_path.is_file():
        errors.append("power-calibrated top-1 protocol is missing")
    else:
        source_power_protocol_path = (
            ROOT
            / "results"
            / "function_transport_top1_powercal_confirmation_seed25to29_20260816"
            / "frozen_protocol.json"
        )
        if sha256(source_power_protocol_path) != POWER_CONFIRMATION_PROTOCOL_SHA256:
            errors.append("frozen source top-1 protocol hash mismatch")
        source_protocol = json.loads(
            source_power_protocol_path.read_text(encoding="utf-8")
        )
        packaged_protocol = json.loads(power_protocol_path.read_text(encoding="utf-8"))
        source_protocol["geometry_registry"] = (
            "${GEOMETRY_PROVIDER_ROOT}\\results\\"
            "office_home_confirmation_geometry_seed25to29_powercal_20260816\\"
            "provider_snapshot_registry.json"
        )
        if packaged_protocol != source_protocol:
            errors.append(
                "power-calibrated top-1 protocol differs from the frozen source "
                "beyond deterministic path sanitization"
            )
    if not power_report_path.is_file():
        errors.append("power-calibrated top-1 report is missing")
    else:
        power_report = json.loads(power_report_path.read_text(encoding="utf-8"))
        expected_power = {
            "receiver_seed_units": 20,
            "certified_nonlocal": 2,
            "mean_deployed_top1_gain_vs_local": 0.0008582015758850092,
            "exact_one_sided_seed_sign_flip_p": 0.25,
        }
        for key, expected in expected_power.items():
            value = power_report.get(key)
            if value is None or abs(float(value) - float(expected)) > 1e-12:
                errors.append(
                    f"power-calibrated top-1 report mismatch for {key}: "
                    f"{value} != {expected}"
                )
        if power_report.get("beneficial_tied_harmful_receivers") != [2, 18, 0]:
            errors.append("power-calibrated receiver outcomes are not 2/18/0")
        if power_report.get("test_used_for_construction_or_selection"):
            errors.append("power-calibrated protocol used test data for selection")
        if power_report.get("passes_frozen_confirmation"):
            errors.append("power-calibrated report incorrectly claims composite success")
        criteria = power_report.get("success_criteria", {})
        if criteria.get("positive_seed_bootstrap_lower_bound") is not False:
            errors.append("power-calibrated significance boundary is not retained")
    if not power_validation_path.is_file():
        errors.append("power-calibrated independent validation is missing")
    else:
        power_validation = json.loads(
            power_validation_path.read_text(encoding="utf-8")
        )
        if not power_validation.get("protocol_integrity_passes", False):
            errors.append("power-calibrated protocol integrity did not pass")
        if power_validation.get("scientific_confirmation_passes", True):
            errors.append("power-calibrated scientific boundary is not retained")
        if not all(power_validation.get("checks", {}).values()):
            errors.append("power-calibrated independent validation has failed checks")
    if not power_units_path.is_file():
        errors.append("power-calibrated receiver rows are missing")
    else:
        with power_units_path.open(newline="", encoding="utf-8") as handle:
            power_rows = list(csv.DictReader(handle))
        certified = [
            row for row in power_rows
            if row.get("certified", "").strip().lower() == "true"
        ]
        harmful = [
            row for row in certified
            if float(row["test_gain_vs_local"]) < 0.0
        ]
        if len(power_rows) != 20 or len(certified) != 2 or harmful:
            errors.append(
                "power-calibrated top-1 unit support mismatch: "
                f"units={len(power_rows)}, certified={len(certified)}, harm={len(harmful)}"
            )
        notes.append(
            "Power-calibrated E2E top-1: "
            f"{len(certified)}/20 positive non-local admissions, zero harm, "
            "five-seed interval lower bound retained at zero"
        )

    power_geometry_root = (
        package
        / "04_frozen_geometry_payload"
        / "officehome_power_confirmation_seed25_29"
    )
    power_provider_registry = power_geometry_root / "provider_snapshot_registry.json"
    if not power_provider_registry.is_file():
        errors.append("power-confirmation provider registry is missing")
    elif sha256(power_provider_registry) != POWER_CONFIRMATION_PROVIDER_SHA256:
        errors.append("power-confirmation provider registry hash mismatch")
    else:
        provider = json.loads(power_provider_registry.read_text(encoding="utf-8"))
        if provider.get("seeds") != [25, 26, 27, 28, 29]:
            errors.append("power-confirmation provider seeds are not 25--29")
        verified = 0
        for snapshot in provider.get("snapshots", []):
            seed = int(snapshot["seed"])
            if not snapshot.get("no_calibration_or_test_used", False):
                errors.append(f"power-confirmation provider seed {seed} is not training-only")
            geometry_dir = power_geometry_root / f"seed_{seed}" / "fedavg" / "geometry_outputs"
            for name, expected_hash in snapshot.get("output_sha256", {}).items():
                path = geometry_dir / name
                verified += 1
                if not path.is_file():
                    errors.append(f"missing power-confirmation geometry: {path}")
                elif sha256(path) != expected_hash:
                    errors.append(f"power-confirmation geometry hash mismatch: {path}")
        if verified != 45:
            errors.append(f"power-confirmation geometry file count: {verified} != 45")
        notes.append(
            "Power-confirmation geometry: 5 training-only snapshots, "
            f"{verified} hash-verified files"
        )

    report = [
        "# Final Pattern Recognition Package Validation",
        "",
        f"- Package: `{package}`",
        f"- Status: **{'PASS' if not errors else 'FAIL'}**",
        *[f"- {note}" for note in notes],
        "",
        "## Errors",
        "",
        *([f"- {error}" for error in errors] or ["- None."]),
    ]
    args.output.write_text("\n".join(report) + "\n", encoding="utf-8")
    print("\n".join(report))
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
