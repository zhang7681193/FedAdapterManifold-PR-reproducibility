from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np


EXPECTED_SEEDS = list(range(20, 25))
EXPECTED_DOMAINS = {0: "Art", 1: "Clipart", 2: "Product", 3: "Real_World"}
GEOMETRY_FILES = [
    "d_geo_round_4.npy",
    "geometry_graph_round_4.npy",
    "prototypes_round_4.pkl",
    "client_signatures_round_4.pkl",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def exact_sign_flip(values: list[float]) -> float:
    nonzero = [value for value in values if abs(value) > 1e-15]
    if not nonzero or float(np.mean(nonzero)) <= 0.0:
        return 1.0
    observed = float(np.mean(nonzero))
    count = 0
    for mask in range(1 << len(nonzero)):
        signed = [
            -value if mask & (1 << index) else value
            for index, value in enumerate(nonzero)
        ]
        if float(np.mean(signed)) >= observed - 1e-15:
            count += 1
    return count / float(1 << len(nonzero))


def seed_bootstrap(values: list[float], draws: int = 20000) -> tuple[float, float]:
    rng = np.random.default_rng(20260815)
    array = np.asarray(values, dtype=np.float64)
    sampled = rng.choice(array, size=(draws, array.size), replace=True).mean(axis=1)
    return float(np.quantile(sampled, 0.025)), float(np.quantile(sampled, 0.975))


def close(left: float, right: float, tolerance: float = 1e-12) -> bool:
    return bool(abs(float(left) - float(right)) <= tolerance)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Independently validate the frozen OfficeHome top-1 confirmation.")
    parser.add_argument("--result-root", required=True, type=Path)
    parser.add_argument("--geometry-registry", required=True, type=Path)
    parser.add_argument("--manifest-root", required=True, type=Path)
    args = parser.parse_args(argv)

    root = args.result_root.resolve()
    registry_path = args.geometry_registry.resolve()
    manifest_root = args.manifest_root.resolve()
    protocol = json.loads((root / "frozen_protocol.json").read_text(encoding="utf-8"))
    report = json.loads((root / "confirmation_report.json").read_text(encoding="utf-8"))
    registry = json.loads(registry_path.read_text(encoding="utf-8"))
    geometry = {
        int(item["seed"]): (
            registry_path.parent / item["relative_geometry_outputs"]
        ).resolve()
        for item in registry["snapshots"]
    }

    checks: dict[str, bool] = {
        "expected_protocol": protocol["protocol"]
        == "officehome65_clip_raw_student_single_candidate_confirmation_v3_schema_exact",
        "expected_seeds": protocol["seeds"] == EXPECTED_SEEDS,
        "registry_hash": protocol["geometry_registry_sha256"] == sha256(registry_path),
        "split_logic_match_recorded": bool(protocol["split_implementation_matches_staged_runner"]),
        "validator_hash": protocol["independent_validator_sha256"]
        == sha256(Path(__file__).resolve()),
    }
    rows: list[dict] = []
    for seed in EXPECTED_SEEDS:
        split = manifest_root / f"seed_{seed}" / "split_manifest.json"
        metadata = manifest_root / f"seed_{seed}" / "manifest_metadata.json"
        split_rows = json.loads(split.read_text(encoding="utf-8"))
        split_keys = [
            (
                int(row["client_id"]),
                str(row["domain"]),
                str(row["split"]),
                str(row["path"]),
                str(row["label"]),
            )
            for row in split_rows
        ]
        split_counts = {
            name: sum(str(row["split"]) == name for row in split_rows)
            for name in ["train", "calibration", "test"]
        }
        checks[f"split_schema_seed_{seed}"] = all(
            set(row) == {"client_id", "domain", "split", "path", "label"}
            for row in split_rows
        )
        checks[f"split_counts_seed_{seed}"] = split_counts == {
            "train": 1560,
            "calibration": 520,
            "test": 1903,
        }
        checks[f"split_unique_seed_{seed}"] = len(split_keys) == 3983 and len(set(split_keys)) == 3983
        checks[f"domain_client_map_seed_{seed}"] = all(
            EXPECTED_DOMAINS[int(row["client_id"])] == str(row["domain"])
            for row in split_rows
        )
        path_splits: dict[tuple[int, str], set[str]] = {}
        for row in split_rows:
            path_splits.setdefault(
                (int(row["client_id"]), str(row["path"])), set()
            ).add(str(row["split"]))
        checks[f"split_disjoint_seed_{seed}"] = all(
            len(values) == 1 for values in path_splits.values()
        )
        checks[f"split_hash_seed_{seed}"] = (
            protocol["frozen_split_manifest_sha256"][str(seed)] == sha256(split)
        )
        checks[f"metadata_hash_seed_{seed}"] = (
            protocol["manifest_metadata_sha256"][str(seed)] == sha256(metadata)
        )
        for name in GEOMETRY_FILES:
            checks[f"geometry_{name}_seed_{seed}"] = (
                protocol["geometry_snapshot_sha256"][str(seed)][name]
                == sha256(geometry[seed] / name)
            )
        run = root / f"seed_{seed}"
        provenance = json.loads((run / "run_provenance.json").read_text(encoding="utf-8"))
        checks[f"runner_hash_seed_{seed}"] = (
            provenance["entrypoint_sha256"] == protocol["runner_sha256"]
        )
        checks[f"run_split_hash_seed_{seed}"] = (
            provenance["split_manifest_sha256"] == sha256(split)
        )
        checks[f"test_free_seed_{seed}"] = not bool(provenance["test_used_for_selection"])
        current = read_csv(run / "function_transport_admission.csv")
        checks[f"four_receivers_seed_{seed}"] = len(current) == 4
        rows.extend(current)

    keys = [(int(row["seed"]), str(row["client_id"])) for row in rows]
    checks["twenty_unique_receiver_seed_units"] = len(rows) == 20 and len(set(keys)) == 20
    checks["all_rows_test_free"] = all(
        str(row["test_used_for_construction_or_selection"]).lower() == "false"
        for row in rows
    )

    seed_gains: list[float] = []
    for seed in EXPECTED_SEEDS:
        current = [row for row in rows if int(row["seed"]) == seed]
        seed_gains.append(
            float(
                np.mean(
                    [
                        float(row["deployed_test_accuracy"])
                        - float(row["local_test_accuracy"])
                        for row in current
                    ]
                )
            )
        )
    gains = [float(row["test_gain_vs_local"]) for row in rows]
    ci = seed_bootstrap(seed_gains)
    recomputed = {
        "mean_deployed_top1_gain_vs_local": float(np.mean(seed_gains)),
        "seed_bootstrap_ci": list(ci),
        "exact_one_sided_seed_sign_flip_p": exact_sign_flip(seed_gains),
        "positive_tied_negative_seeds": [
            sum(value > 1e-12 for value in seed_gains),
            sum(abs(value) <= 1e-12 for value in seed_gains),
            sum(value < -1e-12 for value in seed_gains),
        ],
        "certified_nonlocal": sum(
            str(row["certified"]).lower() == "true" for row in rows
        ),
        "beneficial_tied_harmful_receivers": [
            sum(value > 1e-12 for value in gains),
            sum(abs(value) <= 1e-12 for value in gains),
            sum(value < -1e-12 for value in gains),
        ],
    }
    checks["mean_matches_report"] = close(
        recomputed["mean_deployed_top1_gain_vs_local"],
        report["mean_deployed_top1_gain_vs_local"],
    )
    checks["ci_matches_report"] = all(
        close(left, right)
        for left, right in zip(recomputed["seed_bootstrap_ci"], report["seed_bootstrap_ci"])
    )
    checks["sign_flip_matches_report"] = close(
        recomputed["exact_one_sided_seed_sign_flip_p"],
        report["exact_one_sided_seed_sign_flip_p"],
    )
    checks["counts_match_report"] = (
        recomputed["positive_tied_negative_seeds"]
        == report["positive_tied_negative_seeds"]
        and recomputed["certified_nonlocal"] == report["certified_nonlocal"]
        and recomputed["beneficial_tied_harmful_receivers"]
        == report["beneficial_tied_harmful_receivers"]
    )
    checks["reported_success_is_derived"] = bool(report["passes_frozen_confirmation"]) == bool(
        all(report["success_criteria"].values())
    )
    validation = {
        "protocol_integrity_passes": all(checks.values()),
        "scientific_confirmation_passes": bool(report["passes_frozen_confirmation"]),
        "checks": checks,
        "recomputed": recomputed,
        "reported_success_criteria": report["success_criteria"],
    }
    (root / "independent_validation.json").write_text(
        json.dumps(validation, indent=2) + "\n", encoding="utf-8"
    )
    if not validation["protocol_integrity_passes"]:
        failed = [name for name, passed in checks.items() if not passed]
        raise RuntimeError(f"independent protocol validation failed: {failed}")
    print(json.dumps(validation, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
