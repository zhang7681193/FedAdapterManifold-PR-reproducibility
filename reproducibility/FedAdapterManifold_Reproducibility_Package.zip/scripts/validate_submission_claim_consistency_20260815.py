from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Check submission claims against frozen result summaries.")
    parser.add_argument("--workspace", type=Path, default=Path.cwd())
    return parser.parse_args()


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def _contains_all(text: str, tokens: list[str], label: str) -> None:
    missing = [token for token in tokens if token not in text]
    _require(not missing, f"{label}: missing claim tokens {missing}")


def main() -> int:
    workspace = parse_args().workspace.resolve()
    source = workspace / "submission" / "FAM_FINAL" / "02_latex_source"
    documents = {
        "main": source / "fedadaptermanifold_pr_resubmit.tex",
        "supplement": source / "fedadaptermanifold_pr_resubmit_supplement.tex",
        "cover_letter": source / "PR_D_26_08222_resubmission_cover_letter.tex",
    }
    texts = {name: path.read_text(encoding="utf-8") for name, path in documents.items()}

    pacs_path = workspace / "results" / "pacs_protocol_10seed_audit_20260815" / "pacs_10seed_protocol_summary.csv"
    pacs = pd.read_csv(pacs_path).set_index("protocol")
    canonical = pacs.loc["Local/Geo/FAM"]
    subreg = pacs.loc["Subspace-Reg/FAM"]
    nonpacs_path = (
        workspace
        / "results"
        / "npcanon_bank6_holm_5seed_20260815"
        / "independent_validation"
        / "validation_report.json"
    )
    nonpacs_report = json.loads(nonpacs_path.read_text(encoding="utf-8"))
    nonpacs = {item["dataset_key"]: item for item in nonpacs_report["datasets"]}
    power_path = (
        workspace
        / "results"
        / "function_transport_top1_powercal_confirmation_seed25to29_20260816"
        / "confirmation_report.json"
    )
    power = json.loads(power_path.read_text(encoding="utf-8"))

    expected = {
        "canonical": {
            "mean_gain": round(float(canonical["mean_gain"]), 4),
            "bca_low": round(float(canonical["bca_ci_low"]), 4),
            "bca_high": round(float(canonical["bca_ci_high"]), 4),
            "p": float(canonical["exact_sign_flip_p_one_sided"]),
            "admitted": int(canonical["admitted_receivers"]),
            "harmful": int(canonical["harmful_admissions"]),
        },
        "subspace_reg": {
            "mean_gain": round(float(subreg["mean_gain"]), 4),
            "bca_low": round(float(subreg["bca_ci_low"]), 4),
            "bca_high": round(float(subreg["bca_ci_high"]), 4),
            "p": float(subreg["exact_sign_flip_p_one_sided"]),
            "admitted": int(subreg["admitted_receivers"]),
            "harmful": int(subreg["harmful_admissions"]),
        },
        "nonpacs": {
            "status": str(nonpacs_report["status"]),
            "units": int(nonpacs_report["units"]),
            "domainnet_raw_gain": round(
                float(nonpacs["domainnetmini_clip_60class"]["raw_fam_mean_gain"]), 4
            ),
            "officehome_raw_gain": round(
                float(nonpacs["officehome_clip_full"]["raw_fam_mean_gain"]), 4
            ),
            "admitted": sum(int(item["admitted_receivers"]) for item in nonpacs.values()),
            "harmful": sum(int(item["harmful_admissions"]) for item in nonpacs.values()),
            "uncertified": sum(
                int(item["uncertified_deployments"]) for item in nonpacs.values()
            ),
        },
        "e2e_power": {
            "units": int(power["receiver_seed_units"]),
            "certified_nonlocal": int(power["certified_nonlocal"]),
            "gain": round(float(power["mean_deployed_top1_gain_vs_local"]), 6),
            "ci": [round(float(value), 6) for value in power["seed_bootstrap_ci"]],
            "seed_p": float(power["exact_one_sided_seed_sign_flip_p"]),
            "receiver_outcomes": list(power["beneficial_tied_harmful_receivers"]),
            "composite_success": bool(power["passes_frozen_confirmation"]),
        },
    }
    _require(expected["canonical"] == {
        "mean_gain": 0.0517,
        "bca_low": 0.0348,
        "bca_high": 0.0645,
        "p": 0.001953125,
        "admitted": 12,
        "harmful": 0,
    }, "Frozen canonical PACS summary changed")
    _require(expected["subspace_reg"] == {
        "mean_gain": 0.0128,
        "bca_low": 0.0048,
        "bca_high": 0.023,
        "p": 0.03125,
        "admitted": 5,
        "harmful": 0,
    }, "Frozen Subspace-Reg PACS summary changed")
    _require(expected["nonpacs"] == {
        "status": "pass",
        "units": 50,
        "domainnet_raw_gain": 0.0098,
        "officehome_raw_gain": 0.0016,
        "admitted": 0,
        "harmful": 0,
        "uncertified": 0,
    }, "Frozen non-PACS canonical validation changed")
    _require(expected["e2e_power"] == {
        "units": 20,
        "certified_nonlocal": 2,
        "gain": 0.000858,
        "ci": [0.0, 0.002051],
        "seed_p": 0.25,
        "receiver_outcomes": [2, 18, 0],
        "composite_success": False,
    }, "Frozen end-to-end power confirmation changed")

    _contains_all(
        texts["main"],
        [
            ".0506",
            ".0528",
            ".0116",
            ".0141",
            ".0625",
            ".03125",
            "$p=.25$",
            "$p=.125$",
            "descriptive pooled",
        ],
        "main PACS blockwise reporting",
    )
    _contains_all(texts["main"], ["12/40", "5/40", ".6545", ".7733", ".7063", ".7183", ".7745", ".7311"], "main")
    _contains_all(texts["main"], [".7980", ".8078", ".7243", ".7259", "0/30", "0/20", "all 50 units"], "main")
    _contains_all(
        texts["supplement"],
        [
            "Original 0--4",
            "Frozen replication 5--9",
            "Descriptive pooled",
            ".0506",
            ".0528",
            ".0116",
            ".0141",
            "12/40",
            "5/40",
            "not assigned a confirmatory $p$ value",
        ],
        "supplement PACS blockwise reporting",
    )
    _contains_all(texts["supplement"], [".7980", ".8078", ".7243", ".7259", "+.0098", "+.0016", "all 50 units"], "supplement")
    _contains_all(
        texts["main"],
        ["OfficeHome-65 FT-Power", ".7314", ".7323", "2/20", "interval touches zero"],
        "main power confirmation",
    )
    _contains_all(
        texts["supplement"],
        ["Exact top-1 power confirmation", ".73144", ".73230", "+.000858", "2/18/0"],
        "supplement power confirmation",
    )
    _contains_all(
        texts["cover_letter"],
        ["seeds 25--29", "2/20", "both improve top-1", "interval touches zero"],
        "cover_letter power confirmation",
    )
    _contains_all(
        texts["cover_letter"],
        [
            ".0506",
            ".0528",
            ".0116",
            ".0141",
            "pooled values are labelled descriptive",
        ],
        "cover_letter PACS blockwise reporting",
    )

    forbidden_current_claim_tokens = [
        "gain $+0.0506$",
        "gain $+0.0141$",
        "interval $[+0.0022,+0.0259]$",
        "FedAdapterManifoldimproves",
        "FedAdapterManifoldtherefore",
        "Two ten-seed PACS confirmations",
        "two frozen ten-seed PACS confirmations",
        "Independent ten-seed PACS confirmations",
        "AI-assisted initial explanatory draft",
        "ChatGPT image-generation service",
    ]
    for name, text in texts.items():
        present = [token for token in forbidden_current_claim_tokens if token in text]
        _require(not present, f"{name}: stale or malformed current claim {present}")

    report = {
        "status": "pass",
        "source_summary": [str(pacs_path), str(nonpacs_path), str(power_path)],
        "documents": {name: str(path) for name, path in documents.items()},
        "verified_claims": expected,
        "checks": {
            "main_claim_tokens": True,
            "supplement_claim_tokens": True,
            "cover_letter_claim_tokens": True,
            "nonpacs_independent_validation": True,
            "end_to_end_power_confirmation": True,
            "pacs_blocks_reported_separately": True,
            "pooled_p_value_not_claimed_as_prospective": True,
            "stale_five_seed_current_claims_absent": True,
            "macro_spacing_artifacts_absent": True,
        },
    }
    output = workspace / "results" / "submission_claim_consistency_20260815.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
