from __future__ import annotations

import numpy as np

from fedadaptermanifold.function_space_transport import (
    _teacher_objective,
    apply_function_teacher,
    audit_function_transport_risk,
    class_conditional_probability_teacher,
    crossfit_convex_expert_screen,
    cross_entropy_from_logits,
    fit_convex_expert_teacher,
    fit_robust_function_teacher,
    probability_mixture_teacher,
)


def _binary_logits(labels: np.ndarray, margin: float) -> np.ndarray:
    logits = np.full((labels.size, 2), -float(margin), dtype=np.float64)
    logits[np.arange(labels.size), labels] = float(margin)
    return logits


def test_robust_teacher_prefers_the_training_safe_donor():
    labels = np.asarray([0, 1] * 8, dtype=np.int64)
    folds = np.asarray([0, 0, 1, 1] * 4, dtype=np.int64)
    good = _binary_logits(labels, margin=3.0)
    harmful = _binary_logits(1 - labels, margin=3.0)
    donor_logits = np.stack([good, harmful], axis=1)

    teacher = fit_robust_function_teacher(
        donor_logits,
        labels,
        folds,
        kl_strength=0.001,
        fold_temperature=0.05,
    )

    assert np.mean(teacher.routing_weights[:, 0]) > 0.95
    assert np.argmax(teacher.teacher_logits, axis=1).tolist() == labels.tolist()
    assert np.max(teacher.fold_losses) < 0.01


def test_input_conditioned_prior_routes_complementary_donors_without_parameter_mixing():
    labels = np.asarray([0, 1, 0, 1, 0, 1, 0, 1], dtype=np.int64)
    folds = np.asarray([0, 0, 1, 1, 0, 0, 1, 1], dtype=np.int64)
    donor_zero = _binary_logits(labels, margin=3.0)
    donor_one = _binary_logits(labels, margin=3.0)
    donor_zero[4:] = _binary_logits(1 - labels[4:], margin=3.0)
    donor_one[:4] = _binary_logits(1 - labels[:4], margin=3.0)
    donor_logits = np.stack([donor_zero, donor_one], axis=1)
    prior = np.zeros((labels.size, 2), dtype=np.float64)
    prior[:4] = [0.999, 0.001]
    prior[4:] = [0.001, 0.999]

    teacher = fit_robust_function_teacher(
        donor_logits,
        labels,
        folds,
        routing_prior=prior,
        kl_strength=0.1,
    )

    assert np.all(teacher.routing_weights[:4, 0] > 0.99)
    assert np.all(teacher.routing_weights[4:, 1] > 0.99)
    assert np.argmax(teacher.teacher_logits, axis=1).tolist() == labels.tolist()


def test_fold_robust_objective_does_not_increase_from_the_declared_prior():
    labels = np.asarray([0, 1] * 6, dtype=np.int64)
    folds = np.asarray([0] * 8 + [1] * 4, dtype=np.int64)
    donor_zero = _binary_logits(labels, margin=1.2)
    donor_one = _binary_logits(1 - labels, margin=1.2)
    donor_zero[folds == 1] = _binary_logits(1 - labels[folds == 1], margin=4.0)
    donor_one[folds == 1] = _binary_logits(labels[folds == 1], margin=2.0)
    donor_logits = np.stack([donor_zero, donor_one], axis=1)
    prior = np.full((labels.size, 2), 0.5, dtype=np.float64)
    initial = _teacher_objective(
        donor_logits,
        labels,
        folds,
        np.unique(folds),
        prior,
        np.zeros(2, dtype=np.float64),
        kl_strength=0.02,
        fold_temperature=0.05,
    )[0]

    teacher = fit_robust_function_teacher(
        donor_logits,
        labels,
        folds,
        routing_prior=prior,
        kl_strength=0.02,
        fold_temperature=0.05,
    )

    assert teacher.objective <= initial + 1e-12
    assert np.all(np.isfinite(teacher.fold_losses))


def test_receiver_relative_teacher_reports_improvement_against_local_on_every_fold():
    labels = np.asarray([0, 1] * 8, dtype=np.int64)
    folds = np.asarray([0, 0, 1, 1] * 4, dtype=np.int64)
    local = _binary_logits(labels, margin=0.2)
    local[folds == 0] = _binary_logits(labels[folds == 0], margin=1.0)
    useful = _binary_logits(labels, margin=2.0)
    harmful = _binary_logits(1 - labels, margin=2.0)
    donor_logits = np.stack([useful, harmful], axis=1)

    teacher = fit_robust_function_teacher(
        donor_logits,
        labels,
        folds,
        anchor_logits=local,
        kl_strength=0.001,
        fold_temperature=0.02,
    )

    assert np.allclose(
        teacher.fold_regrets,
        teacher.fold_losses - teacher.fold_anchor_losses,
    )
    assert np.max(teacher.fold_regrets) < 0.0
    assert teacher.improves_every_training_fold


def test_convex_expert_teacher_has_small_global_optimality_gap():
    labels = np.asarray([0, 1] * 10, dtype=np.int64)
    folds = np.asarray([0, 0, 1, 1] * 5, dtype=np.int64)
    local = np.zeros((labels.size, 2), dtype=np.float64)
    useful = _binary_logits(labels, margin=2.5)
    harmful = _binary_logits(1 - labels, margin=2.5)
    experts = np.stack([local, useful, harmful], axis=1)

    teacher = fit_convex_expert_teacher(
        experts,
        labels,
        folds,
        anchor_logits=local,
        expert_prior=np.asarray([0.2, 0.4, 0.4]),
        kl_strength=0.001,
        tolerance=1e-7,
    )

    assert teacher.expert_weights[1] > 0.99
    assert teacher.optimality_gap < 1e-5
    assert teacher.improves_every_training_fold
    assert teacher.objective < 0.0


def test_fixed_input_conditioned_expert_can_encode_prototype_routing():
    labels = np.asarray([0, 1, 0, 1, 0, 1, 0, 1], dtype=np.int64)
    folds = np.asarray([0, 0, 1, 1, 0, 0, 1, 1], dtype=np.int64)
    local = np.zeros((labels.size, 2), dtype=np.float64)
    routed = _binary_logits(labels, margin=2.0)
    geometry_only = routed.copy()
    geometry_only[[1, 5]] = _binary_logits(1 - labels[[1, 5]], margin=2.0)
    experts = np.stack([local, routed, geometry_only], axis=1)

    teacher = fit_convex_expert_teacher(
        experts,
        labels,
        folds,
        anchor_logits=local,
        kl_strength=0.001,
    )

    assert teacher.expert_weights[1] > teacher.expert_weights[2]
    assert np.argmax(teacher.teacher_logits, axis=1).tolist() == labels.tolist()


def test_centered_smooth_regret_is_zero_for_zero_regret_prior():
    labels = np.asarray([0, 1] * 4, dtype=np.int64)
    folds = np.asarray([0, 0, 1, 1] * 2, dtype=np.int64)
    local = _binary_logits(labels, margin=1.0)
    experts = np.stack([local, local], axis=1)

    teacher = fit_convex_expert_teacher(
        experts,
        labels,
        folds,
        anchor_logits=local,
        expert_prior=np.asarray([0.5, 0.5]),
        kl_strength=0.01,
    )

    assert abs(teacher.smooth_worst_fold_regret) < 1e-12
    assert abs(teacher.objective) < 1e-12


def test_teacher_objective_gradient_matches_finite_differences():
    rng = np.random.default_rng(7)
    donor_logits = rng.normal(size=(10, 3, 4))
    labels = rng.integers(0, 4, size=10)
    folds = np.asarray([0, 1] * 5, dtype=np.int64)
    prior = rng.uniform(0.1, 1.0, size=(10, 3))
    prior /= np.sum(prior, axis=1, keepdims=True)
    bias = np.asarray([0.2, -0.1, -0.1], dtype=np.float64)
    objective = _teacher_objective(
        donor_logits,
        labels,
        folds,
        np.unique(folds),
        prior,
        bias,
        kl_strength=0.07,
        fold_temperature=0.11,
    )
    analytic = objective[1]
    numerical = np.zeros_like(analytic)
    step = 1e-6
    for index in range(bias.size):
        positive = bias.copy()
        negative = bias.copy()
        positive[index] += step
        negative[index] -= step
        positive_value = _teacher_objective(
            donor_logits,
            labels,
            folds,
            np.unique(folds),
            prior,
            positive,
            kl_strength=0.07,
            fold_temperature=0.11,
        )[0]
        negative_value = _teacher_objective(
            donor_logits,
            labels,
            folds,
            np.unique(folds),
            prior,
            negative,
            kl_strength=0.07,
            fold_temperature=0.11,
        )[0]
        numerical[index] = (positive_value - negative_value) / (2.0 * step)

    assert np.allclose(analytic, numerical, atol=2e-6, rtol=2e-5)


def test_positive_utility_bound_upper_bounds_empirical_student_gap():
    rng = np.random.default_rng(19)
    labels = rng.integers(0, 3, size=40)
    folds = np.asarray([0, 1] * 20, dtype=np.int64)
    local = rng.normal(scale=0.4, size=(40, 3))
    teacher = local + rng.normal(scale=0.2, size=(40, 3))
    student = teacher + rng.normal(scale=0.05, size=(40, 3))

    audit = audit_function_transport_risk(
        local,
        teacher,
        student,
        labels,
        folds,
    )

    assert audit.empirical_student_gap <= audit.positive_utility_upper_bound + 1e-12


def test_exact_distillation_of_a_better_teacher_certifies_positive_utility():
    labels = np.asarray([0, 1] * 12, dtype=np.int64)
    folds = np.asarray([0, 0, 1, 1] * 6, dtype=np.int64)
    local = np.zeros((labels.size, 2), dtype=np.float64)
    teacher = _binary_logits(labels, margin=2.0)

    audit = audit_function_transport_risk(
        local,
        teacher,
        teacher.copy(),
        labels,
        folds,
    )

    assert audit.teacher_margin > 0.0
    assert audit.mean_logit_distillation_error == 0.0
    assert audit.positive_utility_upper_bound < 0.0
    assert audit.certified_positive_utility
    assert audit.improves_every_training_fold


def test_exact_fold_regret_is_tighter_than_logit_lipschitz_audit():
    labels = np.asarray([0, 1] * 8, dtype=np.int64)
    folds = np.asarray([0, 0, 1, 1] * 4, dtype=np.int64)
    local = np.zeros((labels.size, 2), dtype=np.float64)
    teacher = _binary_logits(labels, margin=2.0)
    student = teacher + 100.0

    audit = audit_function_transport_risk(local, teacher, student, labels, folds)

    assert not audit.certified_positive_utility
    assert audit.improves_every_training_fold
    assert np.max(audit.fold_student_regrets) < 0.0


def test_apply_teacher_preserves_zero_support_and_rejects_misaligned_bias():
    donor_logits = np.asarray(
        [[[2.0, -2.0], [-2.0, 2.0]], [[-2.0, 2.0], [2.0, -2.0]]],
        dtype=np.float64,
    )
    prior = np.asarray([[1.0, 0.0], [0.0, 1.0]], dtype=np.float64)
    logits, weights = apply_function_teacher(
        donor_logits,
        prior,
        np.asarray([100.0, 100.0]),
    )
    assert np.array_equal(weights, prior)
    assert np.array_equal(logits, np.asarray([[2.0, -2.0], [2.0, -2.0]]))
    with np.testing.assert_raises_regex(ValueError, "one value per donor"):
        apply_function_teacher(donor_logits, prior, np.zeros(3))


def test_cross_entropy_rejects_nonfinite_logits():
    with np.testing.assert_raises_regex(ValueError, "finite"):
        cross_entropy_from_logits(
            np.asarray([[0.0, np.nan]], dtype=np.float64),
            np.asarray([0], dtype=np.int64),
        )


def test_class_conditional_probability_routing_uses_complementary_donors():
    donor_logits = np.asarray(
        [
            [[5.0, -2.0], [-1.0, 1.0]],
            [[1.0, -1.0], [-2.0, 5.0]],
        ],
        dtype=np.float64,
    )
    features = np.asarray([[1.0, 0.0], [0.0, 1.0]], dtype=np.float64)
    prototypes = np.asarray(
        [
            [[1.0, 0.0], [-1.0, 0.0]],
            [[0.0, -1.0], [0.0, 1.0]],
        ],
        dtype=np.float64,
    )
    mask = np.ones((2, 2), dtype=bool)

    teacher, routes = class_conditional_probability_teacher(
        donor_logits,
        features,
        prototypes,
        mask,
        compatibility=np.ones(2),
        receiver_index=0,
        temperature=0.05,
        exclude_receiver=False,
    )

    assert np.argmax(teacher, axis=1).tolist() == [0, 1]
    assert routes[0, 0, 0] > 0.99
    assert routes[1, 1, 1] > 0.99
    assert np.allclose(np.sum(routes, axis=1), 1.0)


def test_class_conditional_probability_routing_is_logit_shift_invariant():
    rng = np.random.default_rng(31)
    donor_logits = rng.normal(size=(5, 3, 4))
    features = rng.normal(size=(5, 6))
    prototypes = rng.normal(size=(3, 4, 6))
    mask = np.ones((3, 4), dtype=bool)
    compatibility = np.asarray([0.4, 0.3, 0.3])
    first, routes = class_conditional_probability_teacher(
        donor_logits,
        features,
        prototypes,
        mask,
        compatibility,
        receiver_index=0,
        exclude_receiver=False,
    )
    shifts = rng.normal(scale=100.0, size=(5, 3, 1))
    shifted, shifted_routes = class_conditional_probability_teacher(
        donor_logits + shifts,
        features,
        prototypes,
        mask,
        compatibility,
        receiver_index=0,
        exclude_receiver=False,
    )
    assert np.allclose(first, shifted, atol=1e-12)
    assert np.array_equal(routes, shifted_routes)


def test_probability_mixture_is_invariant_to_donor_logit_gauges():
    rng = np.random.default_rng(41)
    donor_logits = rng.normal(size=(9, 3, 4))
    weights = np.asarray([0.2, 0.3, 0.5], dtype=np.float64)
    first = probability_mixture_teacher(donor_logits, weights)
    shifts = rng.normal(scale=50.0, size=(9, 3, 1))
    second = probability_mixture_teacher(donor_logits + shifts, weights)

    assert np.allclose(first, second, atol=1e-12)


def test_nested_crossfit_screen_requires_unseen_fold_improvement():
    labels = np.asarray([0, 1] * 9, dtype=np.int64)
    folds = np.repeat(np.arange(3, dtype=np.int64), 6)
    local = np.zeros((labels.size, 2), dtype=np.float64)
    useful = _binary_logits(labels, margin=2.0)
    harmful = _binary_logits(1 - labels, margin=2.0)
    experts = np.stack([local, useful, harmful], axis=1)

    audit = crossfit_convex_expert_screen(
        experts,
        labels,
        folds,
        local,
        expert_prior=np.asarray([0.5, 0.25, 0.25]),
        kl_strength=0.001,
    )

    assert audit.all_heldout_regrets_negative
    assert np.max(audit.heldout_regrets) < -0.1
    assert audit.final_teacher.expert_weights[1] > 0.99
    assert np.max(audit.heldout_optimality_gaps) < 1e-5


def test_nested_crossfit_screen_rejects_fold_specific_overfit():
    labels = np.asarray([0, 1] * 9, dtype=np.int64)
    folds = np.repeat(np.arange(3, dtype=np.int64), 6)
    local = np.zeros((labels.size, 2), dtype=np.float64)
    experts = [local]
    for failed_fold in range(3):
        candidate = _binary_logits(labels, margin=3.0)
        mask = folds == failed_fold
        candidate[mask] = _binary_logits(1 - labels[mask], margin=6.0)
        experts.append(candidate)
    expert_values = np.stack(experts, axis=1)

    audit = crossfit_convex_expert_screen(
        expert_values,
        labels,
        folds,
        local,
        expert_prior=np.asarray([0.01, 0.33, 0.33, 0.33]),
        kl_strength=0.0,
    )

    assert not audit.all_heldout_regrets_negative
    assert np.max(audit.heldout_regrets) > 0.0
